package org.archive.manager.model;

/**
 * One node in the interactive relationship graph.
 *
 * @param id        the resource's full IRI (used as the vis-network node id)
 * @param label     display label
 * @param group     "rico", "oais", or "other" -- drives node colour, and lets
 *                  the graph visually distinguish the two source ontologies
 * @param title     tooltip text (IRI + type)
 * @param detailUrl where double-clicking the node should navigate to
 */
public record GraphNode(String id, String label, String group, String title, String detailUrl) {
}
