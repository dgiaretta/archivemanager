package org.archive.manager.model;

public record FacetCount(String label, long count) {
}
