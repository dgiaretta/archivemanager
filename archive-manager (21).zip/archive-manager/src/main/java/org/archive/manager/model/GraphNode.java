package org.archive.manager.model;

import java.util.List;

/**
 * One node in the interactive relationship graph.
 *
 * @param id        the resource's full IRI (used as the vis-network node id)
 * @param label     display label
 * @param group     "rico", "oais", or "other" -- drives node colour, and lets
 *                  the graph visually distinguish the two source ontologies
 * @param types     every rdf:type local name this resource has (e.g.
 *                  "Record", "InformationObject") -- carried through to the
 *                  client so the graph's entity-type highlight control can
 *                  filter by it; not used for node colour (that's {@code group}).
 * @param title     tooltip text (IRI + type)
 * @param detailUrl where double-clicking the node should navigate to
 */
public record GraphNode(String id, String label, String group, List<String> types, String title, String detailUrl) {
}
