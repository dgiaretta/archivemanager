package org.archive.manager.model;

public record LinkedResource(String propertyLocalName, ResourceSummary resource) {
}
