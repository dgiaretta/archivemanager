package org.archive.manager.service;

import org.archive.manager.model.ClassOption;
import org.archive.manager.model.GraphData;
import org.archive.manager.model.GraphEdge;
import org.archive.manager.model.GraphNode;
import org.archive.manager.rdf.Ns;
import org.archive.manager.rdf.QueryRunner;
import org.archive.manager.rdf.RdfStore;
import org.apache.jena.query.ReadWrite;
import org.springframework.stereotype.Service;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Builds the data behind the interactive relationship graph (rendered client-side
 * with vis-network). Only resource-to-resource triples become edges; literal
 * values are left to the regular detail pages. Every triple in the graph
 * comes straight from the data model via SPARQL -- nothing about which
 * properties exist is hard-coded here.
 */
@Service
public class GraphService {

    private static final int MAX_NODES = 300;

    private final RdfStore store;
    private final QueryRunner q;
    private final ArchiveService archive;
    private final Set<String> ricoClassLocalNames;
    private final Set<String> oaisClassLocalNames;
    private final Set<String> recordResourceLocalNames;
    private final Set<String> agentLocalNames;
    private final Set<String> eventLocalNames;
    private final Set<String> mandateLocalNames;

    public GraphService(RdfStore store, QueryRunner q, ArchiveService archive, OntologyService ontology) {
        this.store = store;
        this.q = q;
        this.archive = archive;
        // Group membership (rico / oais / other) and routing (which detail page a
        // node's type belongs to) are both resolved against the real ontology graph
        // -- class lists and hierarchy from rico-vocabulary.ttl / the OAIS schema --
        // rather than hard-coded Java lists of class names.
        //
        // This runs during Spring bean construction at application startup, which
        // is *outside* any HTTP request -- so TransactionInterceptor (which only
        // opens a transaction in preHandle, per-request) never runs for it. TDB2
        // requires an explicit transaction for every read, with no auto-commit
        // fallback, so one is opened and closed by hand here, the same way
        // RdfStore.init() manages its own startup-time transaction.
        boolean ok = false;
        store.beginTransaction(ReadWrite.READ);
        try {
            // "rico" grouping (for graph node colour) also covers the dc:/nam:
            // namespaces -- Dublin Core and NAM's small extension vocabulary are both
            // descriptive/archival-metadata concepts, not OAIS preservation ones, so
            // they read naturally as part of the same blue "rico" family visually
            // rather than needing two more colours of their own.
            this.ricoClassLocalNames = ontology.listClasses().stream()
                    .filter(c -> "rico".equals(c.source()) || "dc".equals(c.source()) || "nam".equals(c.source()))
                    .map(ClassOption::localName)
                    .collect(Collectors.toSet());
            this.oaisClassLocalNames = ontology.listClasses().stream()
                    .filter(c -> "oais".equals(c.source()))
                    .map(ClassOption::localName)
                    .collect(Collectors.toSet());
            this.recordResourceLocalNames = ontology.subclassLocalNames(Ns.RICO + "RecordResource");
            this.agentLocalNames = ontology.subclassLocalNames(Ns.RICO + "Agent");
            this.eventLocalNames = ontology.subclassLocalNames(Ns.RICO + "Event");
            this.mandateLocalNames = ontology.subclassLocalNames(Ns.RICO + "Mandate");
            ok = true;
        } finally {
            store.endTransaction(ok);
        }
    }

    private static final int MAX_FULL_GRAPH_TRIPLES = 1500;

    /**
     * Every resource-to-resource triple in the data graph, capped at
     * {@link #MAX_FULL_GRAPH_TRIPLES} -- an archive of any real size would
     * otherwise ship its entire graph to the browser as one JSON payload and
     * hand it to vis-network's physics simulation, which is the first thing
     * to become impractical long before TDB2 itself would notice the load.
     * Use the focused {@link #subgraph(String, int)} view for anything
     * larger; {@code GraphData.truncated()} tells the caller whether this cap
     * was hit.
     */
    public GraphData fullGraph() {
        String sparql = Ns.PREFIXES + """
                SELECT ?s ?p ?o WHERE {
                  ?s ?p ?o .
                  FILTER(isIRI(?o))
                  FILTER(?p != rdf:type)
                } LIMIT %d
                """.formatted(MAX_FULL_GRAPH_TRIPLES + 1);
        List<String[]> triples = new ArrayList<>();
        for (Map<String, String> row : q.select(store.dataModel(), sparql)) {
            triples.add(new String[]{row.get("s"), row.get("p"), row.get("o")});
        }
        boolean truncated = triples.size() > MAX_FULL_GRAPH_TRIPLES;
        if (truncated) {
            triples = triples.subList(0, MAX_FULL_GRAPH_TRIPLES);
        }
        return fromTriples(triples, truncated);
    }

    /** The subgraph reachable from {@code focusIri} within {@code depth} hops, in either direction. */
    public GraphData subgraph(String focusIri, int depth) {
        Map<String, String[]> triples = new LinkedHashMap<>(); // key: s|p|o
        Set<String> visited = new LinkedHashSet<>();
        Deque<String> queue = new ArrayDeque<>();
        Deque<Integer> depths = new ArrayDeque<>();
        queue.add(focusIri);
        depths.add(Math.max(depth, 0));

        while (!queue.isEmpty() && visited.size() < MAX_NODES) {
            String current = queue.poll();
            int remaining = depths.poll();
            if (!visited.add(current)) {
                continue;
            }

            String outSparql = Ns.PREFIXES + """
                    SELECT ?p ?o WHERE {
                      <%s> ?p ?o .
                      FILTER(isIRI(?o))
                      FILTER(?p != rdf:type)
                    }
                    """.formatted(current);
            for (Map<String, String> row : q.select(store.dataModel(), outSparql)) {
                String o = row.get("o");
                triples.put(current + "|" + row.get("p") + "|" + o, new String[]{current, row.get("p"), o});
                if (remaining > 0 && !visited.contains(o)) {
                    queue.add(o);
                    depths.add(remaining - 1);
                }
            }

            String inSparql = Ns.PREFIXES + """
                    SELECT ?p ?s WHERE {
                      ?s ?p <%s> .
                      FILTER(?p != rdf:type)
                    }
                    """.formatted(current);
            for (Map<String, String> row : q.select(store.dataModel(), inSparql)) {
                String s = row.get("s");
                triples.put(s + "|" + row.get("p") + "|" + current, new String[]{s, row.get("p"), current});
                if (remaining > 0 && !visited.contains(s)) {
                    queue.add(s);
                    depths.add(remaining - 1);
                }
            }
        }
        return fromTriples(triples.values(), visited.size() >= MAX_NODES);
    }

    private GraphData fromTriples(Collection<String[]> triples, boolean truncated) {
        Map<String, GraphNode> nodes = new LinkedHashMap<>();
        List<GraphEdge> edges = new ArrayList<>();
        for (String[] t : triples) {
            String s = t[0];
            String p = t[1];
            String o = t[2];
            nodes.computeIfAbsent(s, this::makeNode);
            nodes.computeIfAbsent(o, this::makeNode);
            boolean cross = !nodes.get(s).group().equals(nodes.get(o).group())
                    && !nodes.get(s).group().equals("other") && !nodes.get(o).group().equals("other");
            edges.add(new GraphEdge(s, o, q.localName(p), cross));
        }
        return new GraphData(new ArrayList<>(nodes.values()), edges, truncated);
    }

    private GraphNode makeNode(String iri) {
        List<String> types = archive.types(iri);
        String group = groupFor(types);
        String label = archive.label(iri);
        String title = iri + (types.isEmpty() ? "" : " (" + String.join(", ", types) + ")");
        return new GraphNode(iri, label, group, types, title, detailUrlFor(iri, types));
    }

    private String groupFor(List<String> typeLocalNames) {
        for (String t : typeLocalNames) {
            if (ricoClassLocalNames.contains(t)) {
                return "rico";
            }
            if (oaisClassLocalNames.contains(t)) {
                return "oais";
            }
        }
        return "other";
    }

    private String detailUrlFor(String iri, List<String> types) {
        for (String t : types) {
            if (recordResourceLocalNames.contains(t)) {
                return "/records/" + archive.encodeId(iri);
            }
            if (agentLocalNames.contains(t)) {
                return "/agents/" + archive.encodeId(iri);
            }
            if (eventLocalNames.contains(t)) {
                return "/activities/" + archive.encodeId(iri);
            }
            if (mandateLocalNames.contains(t)) {
                return "/mandates/" + archive.encodeId(iri);
            }
        }
        return "/resource/" + archive.encodeId(iri);
    }
}
