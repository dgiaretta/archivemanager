package org.archive.manager.model;

import java.util.List;

/**
 * @param truncated true if the graph hit a size cap and is not the complete
 *                   result -- the caller asked for more nodes/edges than this
 *                   view is willing to render in one go.
 */
public record GraphData(List<GraphNode> nodes, List<GraphEdge> edges, boolean truncated) {
}
