package org.archive.manager.model;

public record EditableRelationship(String propertyIri, String propertyLocalName, ResourceSummary target) {
}
