package org.archive.manager.model;

public record TypeOption(String iri, String label, long count) {
}
