/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultMutableNode;
import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.value.Value;

/**
 * Declaration of a general XML-Schema element.
 */
public class XsdElement extends XsdParticle implements NodeValidator
{

   // ======================================================
   // Static part.
   // ======================================================
   /**
    * element tag.
    */
   final static String TAG = "element";

   /**
    * name tag.
    */
   final static String NAME_TAG = "name";

   /**
    * ref tag.
    */
   final static String REF_TAG = "ref";

   /**
    * type tag.
    */
   final static String TYPE_TAG = "type";

   /**
    * default tag.
    */
   final static String DEFAULT_TAG = "default";

   /**
    * fixed tag.
    */
   final static String FIXED_TAG = "fixed";

   // =====================================================
   // Attributes part.
   // =====================================================
   /**
    * The name of this element.
    */
   private String name = null;

   /**
    * The type of this element.
    */
   private XsdType type = null;

   /**
    * The constraint of the element value.
    */
   private int constraint = 0;

   /**
    * The abstract property.
    */
   private boolean abstractDecl = false;

   /**
    * The substitution group affiliation.
    */
   private XsdElement substitutionGroupAffiliation = null;

   /**
    * The constraint value of this element.
    */
   private Value value = null;

   // ======================================================
   // Methods part.
   // ======================================================
   /**
    * Build an XML-Schema element.
    * 
    * @param min_occurs the minimum if the occurence
    * @param max_occurs the maximum of the occurence
    * @param name the name of the element
    * @param type the type of the element
    */
   public XsdElement(final int min_occurs, final int max_occurs,
         final String name, final XsdType type)
   {
      super(min_occurs, max_occurs);
      this.name = name;
      this.type = type;
   } // XsdElement

   /**
    * Build an XML-Schema element.
    * 
    * @param name the name if the element
    * @param type the type of the element
    */
   XsdElement(final String name, final XsdType type)
   {
      super(1, 1);
      this.name = name;
      this.type = type;
   } // XsdElement

   /**
    * Returns the name of this element.
    * 
    * @return The element name
    */
   public final String getName()
   {
      return this.name;
   } // getName

   /**
    * Say wether this element is abstract.
    * 
    * @return true if this element is abstract and false otherwise.
    */
   public final boolean isAbstract()
   {
      return this.abstractDecl;
   } // isAbstract

   /**
    * Change the abstract property of this element.
    * 
    * @param abstract_decl true if this element is abstract and false otherwise.
    */
   void setAbstract(final boolean abstract_decl)
   {
      this.abstractDecl = abstract_decl;
   } // setAbstract

   /**
    * Returns the type of this element.
    * 
    * @return The type of this element
    */
   public final XsdType getType()
   {
      return this.type;
   } // getType

   /**
    * Returns the substitution group affiliation.
    * 
    * @return The substitution group affiliation
    */
   public final XsdElement getSubstitutionGroupAffiliation()
   {
      return this.substitutionGroupAffiliation;
   } // getSubstitutionGroupAffiliation

   /**
    * Set the substitution group affiliation.
    * 
    * @param substitution_affiliation The substitution group affiliation
    */
   void setSubstitutionGroupAffiliation(
         final XsdElement substitution_affiliation)
   {
      this.substitutionGroupAffiliation = substitution_affiliation;
   } // setSubstitutionGroupAffiliation

   /**
    * Returns the value of this element.
    * 
    * @return The value
    */
   public final Value getValue()
   {
      return this.value;
   } // getValue

   /**
    * Returns the constraint of the value.
    * 
    * @return The constraint
    */
   public final int getConstraint()
   {
      return this.constraint;
   } // getConstraint

   /**
    * Returns the value constraint of this element.
    * 
    * @param value The value
    * @param constraint the constraint
    */
   final void setValueConstraint(final Value value, final int constraint)
   {
      this.value = value;
      this.constraint = constraint;
   } // setValueConstraint

   // ----------------------------------------------------------
   // XsdComponent class overloading
   // ----------------------------------------------------------
   /**
    * Format this component into a string.
    * 
    * @return The node
    */
   DrbNode toNode()
   {
      final DrbNode eltNode = new DrbDefaultMutableNode(this.TAG);
      eltNode.setNamespaceURI(Namespace.XML_SCHEMA_NAMESPACE);

      final DrbNode appNode = this.getAnnotation().toNode();
      if (appNode != null)
      {
         eltNode.appendChild(appNode);
      }

      final DrbDefaultAttributeList attributes = new DrbDefaultAttributeList();
      attributes.add(new DrbDefaultAttribute(this.NAME_TAG,
            new fr.gael.drb.value.String(this.getName()), eltNode));
      if (this.type == null)
      {
         attributes.add(new DrbDefaultAttribute(this.TYPE_TAG,
               new fr.gael.drb.value.String("xs:anyType"), eltNode));
      }
      else
      {
         /*
          * if (type.schema != null) //TBC { attributes.add( new
          * DrbDefaultAttribute( "ns", new
          * fr.gael.drb.value.String(type.schema.namespaces.toString()),
          * eltNode)); }
          */

         final XmlSchema schema = this.type.schema;
         if ((schema != null) && (this.type.getName() != null))
         {
            String type_name = this.type.getName();
            if (schema != null)
            {
               String prefix =
                  schema.namespaces.resolvePrefix(this.type
                        .getTargetNamespace());
               /*
                * if (prefix == null) prefix = schema.namespaces.toString();
                */
               if ((prefix == null)
                     && (Namespace.XML_SCHEMA_NAMESPACE.equals(this.type
                           .getTargetNamespace())))
               {
                  prefix = "xs";
               }

               if (prefix != null)
               {
                  type_name = prefix + ":" + this.type.getName();
               }
            }
            else
            {
               type_name =
                  this.type.getTargetNamespace() + ":" + this.type.getName();
            }
            attributes.add(new DrbDefaultAttribute(this.TYPE_TAG,
                  new fr.gael.drb.value.String(type_name), eltNode));
         }
         else
         // if (type.getName() == null) //anonymous
         {
            final DrbNode typeNode = this.type.toNode();
            if (typeNode != null)
            {
               eltNode.appendChild(typeNode);
            }
         }

      }

      if (this.getMinOccurs() != 1)
      {
         attributes.add(new DrbDefaultAttribute(MIN_OCCURS_TAG,
               new fr.gael.drb.value.Int(this.getMinOccurs()), eltNode));
      }
      if (this.getMaxOccurs() == UNBOUNDED_OCCURS)
      {
         attributes.add(new DrbDefaultAttribute(MAX_OCCURS_TAG,
               new fr.gael.drb.value.String(UNBOUNDED_OCCURS_TAG), eltNode));
      }
      else if (this.getMaxOccurs() != 1)
      {
         attributes.add(new DrbDefaultAttribute(MAX_OCCURS_TAG,
               new fr.gael.drb.value.Int(this.getMaxOccurs()), eltNode));
      }
      eltNode.setAttributes(attributes);
      /*
       * if (type != null) { DrbNode typeNode = type.toNode(); if (typeNode !=
       * null) eltNode.appendChild (typeNode); }
       */
      /*
       * if (getExternalNodes() != null) { for (int i=0; i<getExternalNodes().getLength();
       * i++) eltNode.appendChild(getExternalNodes().item(i)); }
       */
      return eltNode;
   } // toNode

   // ----------------------------------------------------
   // XsdParticle class overloading
   // ----------------------------------------------------
   /**
    * Returns the term attribute.
    * 
    * @return the term
    */
   public final int getTerm()
   {
      return XsdParticle.ELEMENT_TERM;
   } // getTerm

   // --------------------------------------------------------------
   // NodeValidator interface implementation
   // --------------------------------------------------------------
   /**
    * Validates this node.
    * 
    * @param node the node
    * @return XsdInvalid
    */
   public XsdInvalid isValid(final DrbNode node)
   {
      final DrbDefaultNodeList nodeList = new DrbDefaultNodeList();
      final XsdInvalidParticle invalid =
         new XsdInvalidParticle(nodeList, this, 0, 0);
      if (node == null)
      {
         return (this.getMinOccurs() == 0) ? null : invalid;
      }
      nodeList.add(node);
      if ((this.getName() == null) || !this.getName().equals(node.getName()))
      {
         return invalid;
      }
      XsdInvalid invalid_type = null;
      if ((this.type != null)
            && ((invalid_type = this.type.isValid(node)) != null))
      {
         return invalid_type;
      }
      return null;
   } // isValid

   // -----------------------------------------------------------
   // NodeListValidator interface implementation
   // -----------------------------------------------------------
   /**
    * Validates this node list.
    * 
    * @param node_list the node list
    * @return XsdInvalid
    */
   public XsdInvalid isValid(DrbNodeList node_list)
   {
      final XsdInvalidParticle invalid =
         new XsdInvalidParticle(node_list, this, 0, 0);
      // Node list must not be null
      if (node_list == null)
      {
         node_list = new DrbDefaultNodeList();
      }
      if (this.search(node_list, 0) == node_list.getLength())
      {
         return null;
      }
      return invalid;
   } // isValid

   /**
    * Search a pattern in the list.
    * 
    * @param node_list the list of nodes
    * @param start the begining of the list
    * @return -1 if it had nod been found, else this place in the list
    */
   public int search(final DrbNodeList node_list, final int start)
   {
      return this.search(node_list, start, new XsdInvalidParticle(node_list,
            this, start, start));
   } // search

   /**
    * Search a pattern in the list.
    * 
    * @param node_list the list of nodes
    * @param start the begining of the list
    * @param invalid The invalid particle
    * @return -1 if it had nod been found, else this place in the list
    */
   int search(DrbNodeList node_list, final int start,
         final XsdInvalidParticle invalid)
   {
      if (node_list == null)
      {
         node_list = new DrbDefaultNodeList();
      }
      if (start < 0)
      {
         return -1;
      }
      // Validate each node
      int occurs = 0;
      for (int i = start; i < node_list.getLength(); i++)
      {
         // Check occurrence
         // if (occurs == getMaxOccurs())
         // break;
         final DrbNode node = node_list.item(i);
         if (node == null)
         {
            return -1;
         }
         // Check name
         if ((this.getName() == null)
               || (!this.getName().equals(node.getName())))
         {
            break;
         }
         if (occurs == this.getMaxOccurs())
         {
            break;
         }
         occurs++;
         // Check type validity
         // if (!isValid (nodeList.item(i)))
         // return -1;
      }
      invalid.setStopIndex(start + occurs);
      if ((this.type != null) && this.type.isComplex())
      {
         if (occurs < this.getMinOccurs())
         {
            return -1;
         }
         if (occurs > this.getMaxOccurs())
         {
            return -1;
         }
      }
      /* Warning : TBC : occurrence checking removed for simple types */
      return start + occurs;
   } // search

} // XsdElement
