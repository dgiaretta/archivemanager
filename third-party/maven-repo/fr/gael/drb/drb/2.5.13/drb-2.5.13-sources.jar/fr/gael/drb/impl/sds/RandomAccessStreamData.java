/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.function.Function;

import fr.gael.drb.DrbFactory;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.streams.RandomAccessInputStream;

/**
 * Random Access Data.
 */
class RandomAccessStreamData extends RandomAccessData
{
   /**
    * The wrapped node.
    */
   DrbNodeImpl node;

   /**
    * The data input stream.
    */
   DataInput input;

   /**
    * The underlying input stream.
    */
   RandomAccessInputStream streamIn;

   /**
    * The data output stream.
    */
   DataOutput output;

   /**
    * The underlying output stream.
    */
   OutputStream streamOut;

   /**
    * The current position.
    */
   long position;

   /**
    * The length of this stream data or -1 if not known.
    */
   long length = -1L;

   /**
    * Creates a RandomAccessStreamData from the specified node.
    * 
    * @param node The ramdomAccessStream
    */
   protected RandomAccessStreamData(final DrbNodeImpl node)
   {
      this.node = node;
      this.reset(0L);
   } // RandomAccessStreamData

   /**
    * Reset this stream data.
    */
   private void reset(long pos)
   {
      this.position = pos;
      // System.out.println(">> RandomAccessStreamData.reset()");
      if (this.streamIn == null)
      {
         try
         {
            Function<Void, InputStream> fn = param -> getInputStream ();
            this.streamIn = new RandomAccessInputStream(fn, this.node.getPath());
         }
         catch (Throwable e)
         {
            throw new RandomAccessException(
               "Cannot initialize input stream for node \"" + 
               node.getPath() +"\"", e);
         }
      }
      
      try
      {
         this.streamIn.seek(pos);
      }
      catch (IOException e)
      {
         throw new RandomAccessException(
            "Cannot set stream position " + pos + " for node \"" + 
            node.getPath() +"\"", e);
      }
      
      if (this.streamIn != null)
      {
         this.input = new DataInputStream(this.streamIn);
      }
      if (this.streamOut != null)
      {
         this.output = new DataOutputStream(this.streamOut);
      }
      // System.out.println("<< RandomAccessStreamData.reset()");
   } // reset
   
   private InputStream getInputStream ()
   {
      return (InputStream)this.node.getImpl(java.io.InputStream.class);
   }

   // ---
   // DataInput implementation.
   // ---

   /**
    * Reads one input byte and returns true if that byte is nonzero, false if
    * that byte is zero.
    * 
    * @return true if the buffer's current position is superior than 0, else
    *         return false
    * @throws IOException if an I/O error occurs.
    */
   public boolean readBoolean() throws IOException
   {
      this.position += 1L;
      return this.input.readBoolean();
   }

   /**
    * Reads and returns one input byte.
    * 
    * @return The byte at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public byte readByte() throws IOException
   {
      this.position += 1L;
      return this.input.readByte();
   }

   /**
    * Reads an input char and returns the char value.
    * 
    * @return The char value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public char readChar() throws IOException
   {
      this.position += 2L;
      return this.input.readChar();
   }

   /**
    * Reads eight input bytes and returns a double value.
    * 
    * @return The double value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public double readDouble() throws IOException
   {
      this.position += 8L;
      return this.input.readDouble();
   }

   /**
    * Reads four input bytes and returns a float value.
    * 
    * @return The float the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public float readFloat() throws IOException
   {
      this.position += 4L;
      return this.input.readFloat();
   }

   /**
    * Reads some bytes from an input stream and stores them into the buffer
    * array b.
    * 
    * @param b The array into which bytes are to be read
    * @throws IOException if an I/O error occurs.
    */
   public void readFully(final byte[] b) throws IOException
   {
      // System.err.println(">>readFully(" + b.length + ")");
      if (b != null)
      {
         this.position += b.length;
      }
      this.input.readFully(b);
      // System.err.println("<<readFully(" + b.length + ")");
   }

   /**
    * Reads len bytes from an input stream.
    * 
    * @param b The array into which bytes are to be read
    * @param off The offset within the array of the first byte to be read; must
    *           be non-negative and no larger than <tt>b.len</tt>
    * @param len The maximum number of bytes to be read to the given array; must
    *           be non-negative and no larger than <tt>b.len - off</tt>
    * @throws IOException if an I/O error occurs.
    */
   public void readFully(final byte[] b, final int off, final int len)
         throws IOException
   {
      if (len > 0)
      {
         this.position += len;
      }
      this.input.readFully(b, off, len);
   }

   /**
    * Reads four input bytes and returns an int value.
    * 
    * @return The int value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public int readInt() throws IOException
   {
      this.position += 4L;
      return this.input.readInt();
   }

   /**
    * Reads the next line of text from the input stream.
    * 
    * @return The string value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public String readLine() throws IOException
   {
      final String line = this.input.readLine();
      if (line != null)
      {
         this.position += line.length();
      }
      return line;
   }

   /**
    * Reads eight input bytes and returns a long value.
    * 
    * @return The long value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public long readLong() throws IOException
   {
      this.position += 8L;
      return this.input.readLong();
   }

   /**
    * Reads two input bytes and returns a short value.
    * 
    * @return The short value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public short readShort() throws IOException
   {
      this.position += 2L;
      return this.input.readShort();
   }

   /**
    * Reads one input byte, zero-extends it to type int, and returns the result,
    * which is therefore in the range 0 through 255.
    * 
    * @return The input byte
    * @throws IOException if an I/O error occurs.
    */
   public int readUnsignedByte() throws IOException
   {
      this.position += 1L;
      return this.input.readUnsignedByte();
   }

   /**
    * Reads one input byte, zero-extends it to type int, and returns the result,
    * which is therefore in the range 0 through 255.
    * 
    * @return The input byte
    * @throws IOException if an I/O error occurs.
    */
   public int readUnsignedShort() throws IOException
   {
      this.position += 2L;
      return this.input.readUnsignedShort();
   }

   /**
    * Makes an attempt to skip over n bytes of data from the input stream,
    * discarding the skipped bytes.
    * 
    * @param n bytes to skip
    * @return The input byte
    * @throws IOException if an I/O error occurs.
    */
   public int skipBytes(int n) throws IOException
   {
      this.position += n;
      final byte[] skipBuf = new byte[8 * 1024];

      for (int num = n; num > 0;)
      {
         final int numRead =
            this.streamIn.read(skipBuf, 0,
                  (num > skipBuf.length ? skipBuf.length : num));

         if (numRead == -1)
         {
            n = n - num;
            break;
         }

         num -= numRead;
      }
      this.input = new DataInputStream(this.streamIn);
      return n;

      // return input.skipBytes(n);
   }

   /**
    * Reads in a string that has been encoded using a modified UTF-8 format.
    * 
    * @return The string
    * @throws IOException if an I/O error occurs.
    */
   public String readUTF() throws IOException
   {
      final String str = this.input.readUTF();
      if (str != null)
      {
         this.position += str.length();
      }
      return str;
   }

   // ---
   // DataOuput implementation.
   // ---

   /**
    * Writes a boolean value to this output stream.
    * 
    * @param v The boolean to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeBoolean(final boolean v) throws IOException
   {
      this.output.writeBoolean(v);
   }

   /**
    * Writes to the output stream the eight low- order bits of the argument v.
    * 
    * @param v The int to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeByte(final int v) throws IOException
   {
      this.output.writeByte(v);
   }

   /**
    * Writes a char value, wich is comprised of two bytes, to the output stream.
    * 
    * @param v The char to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeChar(final int v) throws IOException
   {
      this.output.writeChar(v);
   }

   /**
    * Writes every character in the string s, to the output stream, in order,
    * two bytes per character.
    * 
    * @param s The string to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeChars(final String s) throws IOException
   {
      this.output.writeChars(s);
   }

   /**
    * Writes a string to the output stream.
    * 
    * @param s The string to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeBytes(final String s) throws IOException
   {
      this.output.writeBytes(s);
   }

   /**
    * Writes a double value, which is comprised of eight bytes, to the output
    * stream.
    * 
    * @param v The double to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeDouble(final double v) throws IOException
   {
      this.output.writeDouble(v);
   }

   /**
    * Writes a float value, which is comprised of four bytes, to the output
    * stream.
    * 
    * @param v The float to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeFloat(final float v) throws IOException
   {
      this.output.writeFloat(v);
   }

   /**
    * Writes to the output stream all the bytes in array b.
    * 
    * @param b The byte[] to write
    * @throws IOException if an I/O error occurs.
    */
   public void write(final byte[] b) throws IOException
   {
      this.output.write(b);
   }

   /**
    * Writes len bytes from array b, in order, to the output stream.
    * 
    * @param b The array from which bytes are to be read
    * @param off The offset within the array of the first byte to be read; must
    *           be non-negative and no larger than <tt>array.length</tt>
    * @param len The number of bytes to be read from the given array; must be
    *           non-negative and no larger than <tt>array.length - offset</tt>
    * @throws IOException if an I/O error occurs.
    */
   public void write(final byte[] b, final int off, final int len)
         throws IOException
   {
      this.output.write(b, off, len);
   }

   /**
    * Writes an int value, which is comprised of four bytes, to the output
    * stream.
    * 
    * @param v The int to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeInt(final int v) throws IOException
   {
      this.output.writeInt(v);
   }

   /**
    * Writes to the output stream the eight low-order bits of the argument b.
    * 
    * @param v The int to write
    * @throws IOException if an I/O error occurs.
    */
   public void write(final int v) throws IOException
   {
      this.output.write(v);
   }

   /**
    * Writes a long value, which is comprised of eight bytes, to the output
    * stream.
    * 
    * @param v The long to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeLong(final long v) throws IOException
   {
      this.output.writeLong(v);
   }

   /**
    * Writes two bytes to the output stream to represent the value of the
    * argument.
    * 
    * @param v The int to write into short
    * @throws IOException if an I/O error occurs.
    */
   public void writeShort(final int v) throws IOException
   {
      this.output.writeShort(v);
   }

   /**
    * Writes two bytes of length information to the output stream, followed by
    * the Java modified UTF representation of every character in the string s
    * 
    * @param str The string to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeUTF(final String str) throws IOException
   {
      this.output.writeUTF(str);
   }

   /**
    * Closes this random access file stream and releases any system resources
    * associated with the stream.
    * 
    * @throws IOException if an I/O error occurs.
    */
   void close() throws java.io.IOException
   {
      if (this.streamIn != null)
      {
         this.streamIn.close();
      }
      if (this.streamOut != null)
      {
         this.streamOut.close();
      }
   }

   /**
    * Returns the number of bytes that can be read (or skipped over) from this
    * input stream without blocking by the next caller of a method for this
    * input stream. The next caller might be the same thread or or another
    * thread.
    * 
    * @throws java.io.IOException if an I/O error occurs.
    * @return the number of byte that can be read without blocking.
    */
   public long available() throws java.io.IOException
   {
      if (this.streamIn == null)
      {
         return 0;
      }
      return this.streamIn.available();
   }

   /**
    * Sets the data-pointer offset, measured from the beginning of this data, at
    * which the next read or write occurs.
    * 
    * @param pos The new position value; must be non-negative and no larger than
    *           the current limit
    * @throws IOException if an I/O error occurs.
    */
   void seek(final long pos) throws IOException
   {
      // System.err.println(">> RandomAccessStreamData.seek(" + pos + ")");
      this.reset(pos);
      /*
       * streamIn.skip(pos - this.position); this.input = new
       * DataInputStream(streamIn);
       */
      //this.skipBytes((int) (pos - this.position));
      //this.position = pos;
      // System.err.println("<< RandomAccessStreamData.seek()");
   }

   /**
    * Returns the length of this dta.
    * 
    * @return long The buffer capacity
    * @throws IOException if an I/O error occurs.
    */
   long length() throws java.io.IOException
   {
      // Compute the length of this stream if necessary.
      if (this.length < 0)
      {
         this.length = 0L;
         long skiped = 0;
         this.reset(0L);
         while ((skiped = this.streamIn.available()) > 0)
         {
            skiped = this.streamIn.skip(this.length+skiped);
            this.length += skiped;
         }
         this.reset(0L);
      }
      return this.length;
   }

   /**
    * Makes this class runnable for testing.
    * 
    * @param args the program arguments.
    */
   public static void main(final String[] args)
   {
      final DrbNodeImpl nodeImpl = (DrbNodeImpl) DrbFactory.open(args[0]);
      final RandomAccessStreamData data = new RandomAccessStreamData(nodeImpl);
      byte[] buf = new byte[10];
      // Read first data
      try
      {
         // System.err.println("length=" + data.length());

         data.seek(14L);
         data.readFully(buf);
         System.err.println("buf=" + new String(buf));

         data.seek(5L);
         data.readFully(buf);
         System.err.println("buf=" + new String(buf));

         data.seek(1L);
         data.readFully(buf);
         System.err.println("buf=" + new String(buf));

         data.seek(14L);
         data.readFully(buf);
         System.err.println("buf=" + new String(buf));

         data.seek(2L);
         data.readFully(buf);
         System.err.println("buf=" + new String(buf));

         buf = new byte[10];
      }
      catch (final Exception e)
      {
         // Empty
         e.printStackTrace();
      }

      System.err.println("Checking java memory...");
      for (int i = 0; i < 1000000; i++)
      {
         buf = new byte[1024];
         buf[0] = (byte) i;
         if ((i & 0xffffL) == 0)
         {
            System.err.println("i=" + i);
         }
      }
      System.err.println("done.");
   }
   
   class RandomAccessException extends RuntimeException
   {
      private static final long serialVersionUID = -1551563734039375399L;
      public RandomAccessException()
      {
         super ();
      }

      public RandomAccessException(String message)
      {
         super (message);
      }
      public RandomAccessException(String message, Throwable cause)
      {
         super (message, cause);
      }
      public RandomAccessException(Throwable cause)
      {
         super(cause);
      }
   }
} // RandomAccessStreamData
