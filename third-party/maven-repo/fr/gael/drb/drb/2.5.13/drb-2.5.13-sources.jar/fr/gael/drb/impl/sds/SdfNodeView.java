/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.query.Query;
import fr.gael.drb.value.ByteArray;
import fr.gael.drb.value.DoubleArray;
import fr.gael.drb.value.FloatArray;
import fr.gael.drb.value.IntArray;
import fr.gael.drb.value.LongArray;
import fr.gael.drb.value.Numeric;
import fr.gael.drb.value.NumericArray;
import fr.gael.drb.value.ShortArray;
import fr.gael.drb.value.UnsignedByteArray;
import fr.gael.drb.value.UnsignedIntArray;
import fr.gael.drb.value.UnsignedLongArray;
import fr.gael.drb.value.UnsignedShortArray;
import fr.gael.drb.value.Value;

/**
 * SdfNodeView class.
 */
class SdfNodeView extends DrbNodeImpl
{
   /**
    * Logger
    */
   private static Logger logger = Logger.getLogger(SdfNodeView.class);

   /**
    * Namespace of this node.
    */
   public final static String NAMESPACE = "sdf";

   /**
    * Map identifier.
    */
   public final static String MAP_ID = "view";

   /**
    * Base node.
    */
   protected DrbNode baseNode;

   /**
    * Parent node.
    */
   protected DrbNode parent;

   /**
    * Index in parent.
    */
   protected int index = -1;

   /**
    * Map.
    */
   protected SdfViewDescriptor map;

   /**
    * Name of the last children retrieved.
    */
   protected String lastChildName;

   /**
    * Map of the last children retrieved.
    */
   protected SdfViewDescriptor lastChildMap;

   /**
    * List of last children base.
    */
   protected DrbNodeList lastChildBase;

   /**
    * Class constructor.
    * 
    * @param map the map ?
    * @param base_node ???
    */
   public SdfNodeView(final SdfViewDescriptor map, final DrbNode base_node)
   {
      this.map = map;
      this.baseNode = base_node;
      this.parent = base_node.getParent();
      if ((base_node instanceof AbstractBlock) && (map.query != null))
      {
         System.err.println("Evaluating root view from " + base_node.getPath());
         final Query q = new Query(map.query);
         final DrbNodeList node_list = q.eval(this.baseNode);
         this.baseNode = node_list.item(0);
      }
   }

   /**
    * Class constructor.
    * 
    * @param map the map ?
    * @param base_node ???
    * @param parent ???
    */
   public SdfNodeView(final SdfViewDescriptor map, final DrbNode base_node,
         final DrbNode parent)
   {
      this(map, base_node);
      this.parent = parent;
   }

   /**
    * Class constructor.
    * 
    * @param map the map ?
    * @param base_node ???
    * @param parent ???
    * @param index ???
    */
   public SdfNodeView(final SdfViewDescriptor map, final DrbNode base_node,
         final DrbNode parent, final int index)
   {
      this(map, base_node, parent);
      this.index = index;
   }

   /**
    * Name of this node.
    * 
    * @return The name of this node.
    */
   public String getName()
   {
      return this.map.name;
   }

   /**
    * Index of the node. Returns the index of the node in its parent children
    * list. This index starts from 0 and takes into account all occurences of
    * nodes disregrading the type of nodes. If the node has not parent the index
    * may not be available: the operation returns therefore a negative value.
    * 
    * @return The index of the node or negative value.
    */
   public int getIndex()
   {
      return this.index;
   }

   /**
    * Root node. Returns the root node of the holding the current one. Is the
    * current node is already the root, the operation returns a reference to
    * itself. The root corresponds to the top level node. If the node is not
    * attached to a specific parent it has no root and therefore the current
    * operation returns null.
    * 
    * @return A reference to the root node or null.
    */
   public DrbNode getRoot()
   {
      if (this.parent == null)
      {
         return this;
      }
      return this.parent.getRoot();
   }

   /**
    * The full path of the node. The full path of a node goes through the
    * implementations. Each implementation is supposed to keep the URI (or an
    * equivalent means) of its parent to fullfil this operation. The returned
    * path is canonical so it does not necessarilly conrrespond to the path that
    * allowed the creation of the node. For instance the canonical path of a
    * node created with the URI "/step1/../step2/node" is "/step2/node". The
    * full path is an absolute path that begins with a "/". All steps are
    * composed of the name of the node (i.e. returned by getName()) and a
    * possible qualifier as defined in the XPath 2.0. For instance, if the
    * implementation supports multi-occurences of a node, the cannonical step
    * shall contain the occurence number in a step qualifier (e.g
    * "/step/node[2]/" ).
    * 
    * @return The absolute path of the current node.
    */
   public String getPath()
   {
      String path = "";
      if (this.parent != null)
      {
         path = this.parent.getPath();
         if (path == null)
         {
            path = "";
         }
      }
      path = path + "/" + this.getName();
      if (this.index > 0)
      {
         path = path + "[" + this.index + "]";
      }

      return path;
   }

   /**
    * Get namespace URI. The namespace URI of this node, or null if it is
    * unspecified. This is not a computed value that is the result of a
    * namespace lookup based on an examination of the namespace declarations in
    * scope. It is merely the namespace URI given at creation time. The
    * Namespaces on an attribute does not inherit its namespace from the element
    * it is attached to. If an attribute is not explicitly given a namespace, it
    * simply has no name space.
    * 
    * @return The namspace URI or null if unspecified.
    */
   public String getNamespaceURI()
   {
      return "http://www.gael.fr/drb/impl/map-20020814";
   }

   /**
    * The value type of the node. The node can embedded a particular value
    * according to the fr.gael.drb.value package. This operation returns the
    * type identifier of the content of the current node. The value of the node
    * depends on the implementation as well as on the node itself. If the node
    * does not contain any value, it shall return
    * fr.gael.drb.value.Value.NULL_ID identifier.
    * 
    * @return NULL_ID if the node does not provide value or any other valid type
    *         identifier otherwise.
    */
   public int getValueType()
   {
      return this.map.valueType;
   }

   /**
    * The value of the node. The value of the node means its content. The value
    * is expressed accoring to one of the types supported by the
    * fr.gael.drb.value package. Generally these types correspond to primitive
    * types (e.g. integer, floatting points, etc.) or very low level types (e.g.
    * string, date, etc.).
    * 
    * @return A reference to the value of the node or null if the node does not
    *         contains any value.
    */
   public Value getValue()
   {
      if (this.map.valueQuery != null)
      {
         try
         {
            this.logger.debug("\n getValue of " + this.map.valueQuery);
            final Query q = new Query(this.map.valueQuery);
            final DrbSequence node_list = q.evaluate(this.baseNode);
            if ((node_list != null) && (node_list.getLength() >= 1))
            {
               DrbItem node = node_list.getItem(0);
               Value value = (node == null) ? null : node.getValue();
               if ((node_list.getLength() >= 1) && (value != null)
                     && (value instanceof Numeric))
               {
                  NumericArray value_array = null;
                  int value_type = this.getValueType();
                  if (value_type == Value.UNKNOWN_ID)
                  {
                     value_type = value.getType();
                  }

                  this.logger.debug("------- value_type = " + value_type);
                  switch (value_type)
                  {
                     case Value.UNSIGNED_BYTE_ID:
                     {
                        value_array =
                           new UnsignedByteArray(node_list.getLength());
                        break;
                     }
                     case Value.BYTE_ID:
                     {
                        value_array = new ByteArray(node_list.getLength());
                        break;
                     }
                     case Value.UNSIGNED_SHORT_ID:
                     {
                        value_array =
                           new UnsignedShortArray(node_list.getLength());
                        break;
                     }
                     case Value.SHORT_ID:
                     {
                        value_array = new ShortArray(node_list.getLength());
                        break;
                     }
                     case Value.UNSIGNED_INT_ID:
                     {
                        value_array =
                           new UnsignedIntArray(node_list.getLength());
                        break;
                     }
                     case Value.INT_ID:
                     {
                        value_array = new IntArray(node_list.getLength());
                        break;
                     }
                     case Value.UNSIGNED_LONG_ID:
                     {
                        value_array =
                           new UnsignedLongArray(node_list.getLength());
                        break;
                     }
                     case Value.LONG_ID:
                     {
                        value_array = new LongArray(node_list.getLength());
                        break;
                     }
                     case Value.FLOAT_ID:
                     {
                        value_array = new FloatArray(node_list.getLength());
                        break;
                     }
                     case Value.DOUBLE_ID:
                     {
                        value_array = new DoubleArray(node_list.getLength());
                        break;
                     }
                  }

                  for (int i = 0; i < node_list.getLength(); i++)
                  {
                     node = node_list.getItem(i);
                     value = (node == null) ? null : node.getValue();
                     if (value != null)
                     {
                        value_array.assign(i, value);
                     }
                  }
                  return value_array;
               }
               else
               {
                  if (value == null)
                  {
                     return null;
                  }
                  else if (this.getValueType() == Value.UNKNOWN_ID)
                  {
                     // this.logger.warn("UNKNOWN_ID **** getValue = "+value+"
                     // (type="+value.getType()+")"+" of "+this);
                     return new fr.gael.drb.value.String("" + value);
                  }
                  else
                  {
                     return value.convertTo(this.getValueType());
                  }
               }
            }
         }
         catch (final Exception exception)
         {
            this.logger.error("SdfNodeView.getValue() exception="
                  + exception.getMessage());
            exception.printStackTrace();
         }
      }
      return null;
   }

   /**
    * The attributes of the nodes. This operation returns a list of attribute
    * owned by the current node is any.
    * 
    * @return The list attributes of the current node.
    */
   public DrbAttributeList getAttributes()
   {
      return null;
   }

   /**
    * The parent of this node. Returns a reference to the parent node of the
    * current node according to the current implementation. Most of the nodes
    * have a parent exept root nodes or if they have just been removed, etc. If
    * the node has no parent the operation returns null.
    * 
    * @return The parent of this node or null.
    */
   public DrbNode getParent()
   {
      if (this.parent == null)
      {
         return this;
      }
      return this.parent;
   }

   /**
    * The list of children of the current node. Returns a list of references to
    * the children of the current node. The current node may have no child and
    * the operation returns therefore a null reference.
    * 
    * @return The list of children if any null otherwise.
    */
   public DrbNodeList getChildren()
   {
      if (this.map.children == null)
      {
         System.err.println("getChildren: returning baseNode at "
               + this.baseNode.getPath());
         return this.baseNode.getChildren();
      }

      final DrbDefaultNodeList children = new DrbDefaultNodeList();
      for (int i = 0; i < this.map.children.size(); i++)
      {
         final SdfViewDescriptor child_map =
            (SdfViewDescriptor) this.map.children.get(i);
         final DrbNodeList node_map_list = this.getNamedChildren(child_map);
         // Add the children of this map
         if (node_map_list != null)
         {
            for (int j = 0; j < node_map_list.getLength(); j++)
            {
               children.add(node_map_list.item(j));
            }
         }
      }

      return children;
   }

   /**
    * Accessor of the childre named name.
    * 
    * @param name the name of the requested children.
    * @return the list of the children named name.
    */
   protected DrbNodeList getNamedChildren(final String name)
   {
      if ((this.lastChildName != null) && (this.lastChildName.equals(name)))
      {
         final DrbDefaultNodeList node_map_list = new DrbDefaultNodeList();
         for (int j = 0; j < this.lastChildBase.getLength(); j++)
         {
            final SdfNodeView child_node_map =
               new SdfNodeView(this.lastChildMap, this.lastChildBase.item(j),
                     this, j + 1);
            node_map_list.add(child_node_map);
         }
         return node_map_list;
      }

      for (int i = 0; i < this.map.children.size(); i++)
      {
         final SdfViewDescriptor child_map =
            (SdfViewDescriptor) this.map.children.get(i);
         if (child_map.name.equals(name))
         {
            return this.getNamedChildren(child_map);
         }

      }
      return null;
   }

   /**
    * ???
    * 
    * @param child_map ???
    * @return ???
    */
   protected DrbNodeList getNamedChildren(final SdfViewDescriptor child_map)
   {
      try
      {
         this.lastChildName = child_map.name;
         this.lastChildMap = child_map;
         this.lastChildBase = null;

         final Query q = new Query(child_map.query);
         DrbNodeList node_list = null;
         if (child_map.target == SdfViewDescriptor.SELF_TARGET)
         {
            System.err.println("Evaluating self query '" + child_map.query
                  + " on " + this.getPath());
            node_list = q.eval(this);
         }
         else
         {
            System.err.println("Evaluating query '" + child_map.query + " on "
                  + this.baseNode.getPath());
            node_list = q.eval(this.baseNode);
         }
         this.lastChildBase = node_list;

         if (node_list != null)
         {
            final DrbDefaultNodeList node_map_list = new DrbDefaultNodeList();
            for (int j = 0; j < node_list.getLength(); j++)
            {
               final SdfNodeView child_node_map =
                  new SdfNodeView(child_map, node_list.item(j), this, j + 1);
               node_map_list.add(child_node_map);
            }
            return node_map_list;
         }
      }
      catch (final Exception exception)
      {
         this.logger.error("SdfNodeView.getNamedChildren() : query='"
               + child_map.query, exception);
         exception.printStackTrace();
      }

      return null;
   }

   /**
    * Checks if child any child exists. Returns wheter the current node has at
    * least a child.
    * 
    * @return true if this node has any children, false otherwise.
    */
   public boolean hasChild()
   {
      if (this.map.children == null)
      {
         return this.baseNode.hasChild();
      }

      for (int i = 0; i < this.map.children.size(); i++)
      {
         try
         {
            final SdfViewDescriptor child_map =
               (SdfViewDescriptor) this.map.children.get(i);
            final Query q = new Query(child_map.query);
            DrbNodeList node_list = null;
            if (child_map.target == SdfViewDescriptor.SELF_TARGET)
            {
               node_list = q.eval(this);
            }
            else
            {
               node_list = q.eval(this.baseNode);
            }
            if ((node_list != null) && (node_list.getLength() > 0))
            {
               return true;
            }
         }
         catch (final Exception exception)
         {
            this.logger.error("SdfNodeView.hasChild() exception:", exception);
            exception.printStackTrace();
         }
      }

      return false;
   }

   /**
    * Returns an occurence of child matching a specific name. The occurence
    * number starts from 1. The name is a local name without any prefix.
    * 
    * @param name The name to match.
    * @param occurrence The occurrence number of the desired child.
    * @return A reference to the child or null is not found.
    */
   public DrbNode getNamedChild(final String name, final int occurrence)
   {
      /*
       * System.out.println("SdfNodeView:getNamedChild : " + name + "[" +
       * occurrence + "]" + " / " + baseNode.getName() + " / " +
       * getParent().getName() + (map.children == null ? "(*)" : ""));
       */
      if (this.map.children == null)
      {
         return this.baseNode.getNamedChild(name, occurrence);
      }

      if ((this.lastChildName != null) && (this.lastChildName.equals(name)))
      {
         if ((occurrence < 1) || (this.lastChildBase == null)
               || (occurrence > this.lastChildBase.getLength()))
         {
            return null;
         }
         return new SdfNodeView(this.lastChildMap, this.lastChildBase
               .item(occurrence - 1), this, occurrence);
      }

      this.logger.debug("getNamedChild : computing named children " + name
            + " for occurrence " + occurrence);

      final DrbNodeList node_list = this.getNamedChildren(name);
      if ((node_list == null) || (occurrence < 1)
            || (occurrence > node_list.getLength()))
      {
         return null;
      }

      return node_list.item(occurrence - 1);
   }

   /**
    * Reference to the first child of the current node. If the current node has
    * no child a null reference if returned. The children order depends on the
    * implementation. This operation time performance depends therefore from the
    * implementation. However, the implementations shall try to favourize the
    * firstChild() performances against the lastChild() as far as possible.
    * 
    * @return A reference to the first child or null if no such node.
    */
   public DrbNode getFirstChild()
   {
      if (this.map.children == null)
      {
         return this.baseNode.getFirstChild();
      }

      return this.getChildren().item(0);
   }

   /**
    * Reference to the last child of the current node. If the current node has
    * no child a null reference if returned. The children order depends on the
    * implementation. This operation time performance depends therefore from the
    * implementation. However, the implementations shall try to favourize the
    * firstChild() performances against the lastChild() as far as possible.
    * 
    * @return A reference to the last child or null if no such node.
    */
   public DrbNode getLastChild()
   {
      if (this.map.children == null)
      {
         return this.baseNode.getLastChild();
      }
      final DrbNodeList children = this.getChildren();
      return children.item(children.getLength() - 1);
   }

   /**
    * Reference to a specific child. The child is identified by its position
    * (i.e. index or sequence number) in the children list of this node. The
    * children order depends on the implementation. This operation time
    * performance depends therefore of this implemetation. The provided index
    * start from 0 and shall not be greater or equal to the number of children.
    * If the current node has no child a null reference is returned.
    * 
    * @param index The position of the node to retreive starting from 0 and not
    *           greater or equal to the number of children.
    * @return A reference to specified child or null if no such node.
    */
   public DrbNode getChildAt(final int index)
   {
      if (this.map.children == null)
      {
         return this.baseNode.getChildAt(index);
      }

      return this.getChildren().item(index);
   }

   /**
    * Number of children. Returns the number of children belonging to the
    * current node. According to the implementation the computation of children
    * number may require more or less time. The number of children may actually
    * require to parse a big file if it is not constant among socument
    * instances. It is therefore recommended to use this operation only if
    * required. It is preferrable to browse the tree from first children to last
    * using getFirstChild() and getNextSibling() operations. If the current node
    * has no child, 0 is returned.
    * 
    * @return The number of children of the current node.
    */
   public int getChildrenCount()
   {
      if (this.map.children == null)
      {
         return this.baseNode.getChildrenCount();
      }

      return this.getChildren().getLength();
   }

   /**
    * Previous sibling of the current node. Returns a reference to the previous
    * node in the children list of current node parent. This reference may be
    * null if the current node has no parent or if it is the first child of its
    * parent. The reference may be null if the current node has no previous
    * sibling. <b>TBC</b>
    * 
    * @return A reference to the previous sibling or null if no such node.
    */
   public DrbNode getPreviousSibling()
   {
      return null;
   }

   /**
    * Next sibling of the current node. Returns a reference to the next node in
    * the children list of current node parent. This reference may be null if
    * the current node has no parent or if it is the last child of its parent.
    * The reference may be null if the current node has no next sibling. <b>TBC</b>
    * 
    * @return A reference to the next sibling or null if no such node.
    */
   public DrbNode getNextSibling()
   {
      return null;
   }

   /**
    * Tests if a specific interface can be provided. This operations tests with
    * a minimum of time and memory consumption if the current implementation can
    * provide a specific interface. It important to consider that hasImpl()
    * provides information about the ability to provide such interface in
    * general cases but not focused on the current instance. It may therefore be
    * impossible to get a specific implementation from a node whereas hasImpl()
    * operation returns true.
    * 
    * @param api The class type to test.
    * @return true if an implementation of the interface can be provided and
    *         false otherwise.
    */
   public boolean hasImpl(final Class api)
   {
      if (api.equals(DrbNode.class))
      {
         return true;
      }
      else
      {
         return false;
      }
   }

   /**
    * Returns a specific implementation. This operation returns a reference to
    * an object implementing a specific interface. This mean is useful to
    * benefit by a specific and direct API instead of using the DrbNode
    * interface. The provided object shall represent the current node such as it
    * is possible after a call to this operation, to dismiss the reference to
    * the node. For instance, a file is usually wrapped as a drb.imple.file.File
    * class and thanks to this operation can be seen as a InputStream anabling
    * direct access to the handled file.
    * 
    * @param api The interface (or class) to be provided.
    * @return A reference to the object implementing the interface or a null
    *         reference otherwise.
    */
   public Object getImpl(final Class api)
   {
      if (api.equals(DrbNode.class))
      {
         return this;
      }
      return null;
   }

   /**
    * Closes this node and releases any system resources associated with the
    * implementation. A closed node cannot perform input or output operations
    * and cannot be reopened.
    * 
    * @param deep if this flag is disabled, the implementation shall not release
    *           the ressources shared with the descendants. WARNING: This
    *           parameter is not fully supported.
    */
   public void close(final boolean deep)
   {
      if (deep)
      {
         if (this.baseNode instanceof DrbNodeImpl)
         {
            ((DrbNodeImpl) this.baseNode).close(deep);
         }
      }
   }

   /**
    * ???
    */
   public void print(final String header, int occur)
   {
      final Value value = this.getValue();
      System.out
            .print(header
                  + this.getName()
                  + "["
                  + occur
                  + "] : "
                  + ((value instanceof fr.gael.drb.value.ValueArray) ? new fr.gael.drb.value.String(
                        "<array>")
                        : value)
                  + " ("
                  + ((value == null) ? "-1" : Integer.toString(value.getType()))
                  + " / " + this.getValueType() + " )" + " { base="
                  + this.baseNode.getName() + "@"
                  + this.baseNode.getNamespaceURI() + " ("
                  + this.baseNode.getValue() + ") }");
      occur = 1;
      String child_name = null;

      if (this.map.children == null)
      {
         System.out.println("(*)");
         // return;
      }
      else
      {
         System.out.println("");
      }
      final DrbNodeList children = this.getChildren();
      if (children == null)
      {
         return;
      }
      final int children_count = children.getLength();
      for (int i = 0; i < children_count; i++)
      {
         final DrbNode child_node = children.item(i);
         if ((child_name == null) || (!child_name.equals(child_node.getName())))
         {
            occur = 1;
         }
         else
         {
            occur++;
         }
         if (this.map.children == null)
         {
            print(child_node, header + "   ", occur);
         }
         else
         {
            ((SdfNodeView) child_node).print(header + "   ", occur);
         }
         child_name = child_node.getName();
      }
   }

   /**
    * ???
    */
   public static void print(final DrbNode node, final String header, int occur)
   {
      final Value value = node.getValue();
      System.out
            .print(header
                  + node.getName()
                  + "["
                  + occur
                  + "] : "
                  + ((value instanceof fr.gael.drb.value.ValueArray) ? new fr.gael.drb.value.String(
                        "<array>")
                        : value)
                  + " ("
                  + ((value == null) ? "-1" : Integer.toString(value.getType()))
                  + " )");
      occur = 1;
      String child_name = null;

      System.out.println("(*)");
      for (int i = 0; i < node.getChildrenCount(); i++)
      {
         if ((child_name == null)
               || (!child_name.equals(node.getChildAt(i).getName())))
         {
            occur = 1;
         }
         else
         {
            occur++;
         }
         print(node.getChildAt(i), header + "   ", occur);
         child_name = node.getChildAt(i).getName();
      }
   }

   /**
    * Returns a string representation of this SdfNodeView.
    */
   public String toString()
   {
      return this.getName();
   }
}
