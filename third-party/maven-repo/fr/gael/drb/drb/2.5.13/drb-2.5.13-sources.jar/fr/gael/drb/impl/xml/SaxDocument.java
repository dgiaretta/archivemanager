/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.xml;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.value.Value;

/**
 * SAX Document
 */
class SaxDocument extends DrbNodeImpl
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(SaxDocument.class);

   /**
    * baseNode
    */
   private DrbNode baseNode;

   /**
    * The root element.
    */
   private SaxNode rootNode;

   /**
    * Builds a new SaxDocument from a file node. This constructor initialises a
    * node based on the XML document encoded in the passed InputStream. TODO :
    * this operation shall raise an exception in case of null parameter.
    * 
    * @param base_node A reference to a the base node of an external
    *           implementation.
    */
   protected SaxDocument(final DrbNode base)
   {
      super();
      if (base == null)
      {
         throw new NullPointerException("The base node shall not be null.");
      }
      this.baseNode = base;
      this.rootNode = new SaxNode(this);
   } // SaxDocument

   /**
    * Indicates whether this node is "equal to" to another node.
    * 
    * @param obj another value.
    * @return true if this object is the same as the obj argument
    * @see java.lang.Object#equals(java.lang.Object) for the general contract of
    *      this method.
    */
   public boolean equals(final Object obj)
   {
      // Check reference equality
      if (this == obj)
      {
         return true;
      }

      // Check I/O
      if (obj instanceof SaxDocument)
      {
         final SaxDocument sax_doc = (SaxDocument) obj;
         return (this.rootNode == sax_doc.rootNode);
      }

      // Otherwise the object is different
      return false;
   } // equals

   /**
    * Name of the node. Read accessor to the previously set node name. The name
    * is never null but may be an empty string.
    * 
    * @return The name of the node.
    */
   public String getName()
   {
      return this.baseNode.getName();
   } // getName

   /**
    * Get namespace URI. The namespace URI of this node, or null if it is
    * unspecified. This is not a computed value that is the result of a
    * namespace lookup based on an examination of the namespace declarations in
    * scope. It is merely the namespace URI given at creation time.
    * 
    * @return The namspace URI or null if unspecified.
    */
   public String getNamespaceURI()
   {
      return this.baseNode.getNamespaceURI();
   } // getNamespaceURI

   /**
    * The full path of the node. The full path is the path of the parent node to
    * which is appended the name of the current node. If no parent have already
    * been set no absolute path is considered. A path considering the current
    * node has a root node is not valid for the factory and is therefore not
    * significant in the current implementation.
    * 
    * @return The absolute path of the current node.
    */
   public String getPath()
   {
      if (this.baseNode == null)
      {
         return "";
      }
      else
      {
         return this.baseNode.getPath();
      }
   }

   /**
    * Returns the index of the node. The index is the sequential position of the
    * current node in its parent children list.
    * 
    * @return The index of the current node in its parent children list.
    */
   public int getIndex()
   {
      return this.baseNode.getIndex();
   } // getIndex

   /**
    * The value type of the node. The value type is determined from the value
    * previously assigned to the node. If no speficic value has been previsouly
    * set, fr.gael.drb.value.Value.NULL_ID type is returned.
    * 
    * @return NULL_ID if the node does not provide value or any other valid type
    *         identifier otherwise.
    */
   public int getValueType()
   {
      return Value.NULL_ID;
   } // getValueType

   /**
    * The value of the node. The value is the one previously set.
    * 
    * @return A reference to the value of the node or null if no value has
    *         already been set.
    */
   public Value getValue()
   {
      return null;
   } // getValue

   /**
    * The attributes of the nodes. This operation returns a list of attribute
    * previously set (if any).
    * 
    * @return The list attributes of the current node or null if none.
    */
   public DrbAttributeList getAttributes()
   {
      final DrbAttributeList attributes = this.baseNode.getAttributes();
      if ((attributes == null) || (attributes.getLength() == 0))
      {
         return null;
      }
      final DrbDefaultAttributeList list = new DrbDefaultAttributeList();
      /**
       * Initialize the output attribute list.
       */
      for (int i = 0; i < attributes.getLength(); i++)
      {
         final DrbAttribute attrib = attributes.item(i);
         if (attrib != null)
         {
            list.add(new DrbDefaultAttribute(attrib.getName(), attrib
                  .getValue(), this));
         }
      }
      return list;
   }

   /**
    * The parent of this node. Returns a reference to the parent node of the
    * current node according to the current implementation. Most of the nodes
    * have a parent exept root nodes or if they have just been removed, etc. If
    * the node has no parent the operation returns null.
    * 
    * @return The parent of this node or null.
    */
   public DrbNode getParent()
   {
      return this.baseNode.getParent();
   }

   /**
    * Checks if any child exists. Returns wheter the current node has at least a
    * child.
    * 
    * @return true if this node has any children, false otherwise.
    */
   public final boolean hasChild()
   {
      return true;
   }

   /**
    * The list of children of the current node. Returns a list of references to
    * the children of the current node. The current node may have no child and
    * the operation returns therefore a null reference.
    * 
    * @return The list of children if any null otherwise.
    */
   public DrbNodeList getChildren()
   {
      final DrbDefaultNodeList list = new DrbDefaultNodeList();
      list.add(this.rootNode);
      return list;
   }

   /**
    * Tests if a specific interface can be provided. This operations tests with
    * a minimum of time and memory consumption if the current implementation can
    * provide a specific interface. It important to consider that hasImpl()
    * provides information about the ability to provide such interface in
    * general cases but not focused on the current instance. It may therefore be
    * impossible to get a specific implementation from a node whereas hasImpl()
    * operation returns true.
    * 
    * @param api The class type to test.
    * @return true if an implementation of the interface can be provided and
    *         false otherwise.
    */
   public boolean hasImpl(final Class api)
   {
      if ((this.baseNode != null) && (this.baseNode instanceof DrbNodeImpl))
      {
         return ((DrbNodeImpl) this.baseNode).hasImpl(api);
      }
      else
      {
         return super.hasImpl(api);
      }
   }

   /**
    * Returns a specific implementation. This operation returns a reference to
    * an object implementing a specific interface. This mean is useful to
    * benefit by a specific and direct API instead of using the DrbNode
    * interface. The provided object shall represent the current node such as it
    * is possible after a call to this operation, to dismiss the reference to
    * the node. For instance, a file is usually wrapped as a drb.impl.file.File
    * class and thanks to this operation can be seen as a InputStream anabling
    * direct access to the handled file.
    * 
    * @param api The interface (or class) to be provided.
    * @return A reference to the object implementing the interface or a null
    *         reference otherwise.
    */
   public Object getImpl(final Class api)
   {
      if ((this.baseNode != null) && (this.baseNode instanceof DrbNodeImpl))
      {
         return ((DrbNodeImpl) this.baseNode).getImpl(api);
      }
      else
      {
         return super.getImpl(api);
      }
   }
}
