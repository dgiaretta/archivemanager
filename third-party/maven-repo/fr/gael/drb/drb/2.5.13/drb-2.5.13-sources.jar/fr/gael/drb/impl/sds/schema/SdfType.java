/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds.schema;

/**
 * Declaration of an SDF type.
 */
public abstract class SdfType
{
   // =========================================================================
   // Attributes part.
   // =========================================================================

   /**
    * The content length in bytes. This class is used to manage the different
    * types of length: fixed or not. It permits to retreive the value for any
    * specific block occurrence.
    */
   protected SdfLength contentLength;

   /**
    * class Derivation
    */
   private class Derivation extends SdfSubstitution
   {
      /**
       * The base type definition.
       */
      protected SdfType baseType;
   }

   /**
    * The base.
    */
   protected Derivation base;

   /**
    * The delimiter.
    */
   protected String delimiter;

   /**
    * Returns the base of this type.
    * 
    * @return XsdType
    */
   final Derivation getBase()
   {
      return this.base;
   } // getBase
} // SdfType
