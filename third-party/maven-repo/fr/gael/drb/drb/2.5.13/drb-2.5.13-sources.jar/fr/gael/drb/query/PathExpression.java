/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbFactory;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbSequence;

/**
 * Wraps a abosulte or relative path expression of XQuery language.
 */
class PathExpression extends AbstractExpression
{
   /**
    * Logger
    */
   static private Logger logger = Logger.getLogger(PathExpression.class);

   /**
    * Steps of the path expression.
    */
   private List<GeneralStepExpression> steps =
      new ArrayList<GeneralStepExpression>();

   /**
    * Potential base expression.
    */
   private Expression expression;

   /**
    * Toggler between absolute and relative path expression.
    */
   private boolean absolute;

   /**
    * Convenient attribute for handling paths beginning with a URL scheme: e.g.
    * http://, ftp:, etc.
    */
   private String rootPrefix = null;

   /**
    * Builds a path expression.
    * 
    * @param token token related to the current expression.
    * @param root_prefix potential URL scheme, or null if unspecified.
    * @param base_expression root expression of the path (optional)
    * @param absolute true whether the path is an absolute path and false
    *           otherwise.
    */
   public PathExpression(final Token token, final String root_prefix,
         final Expression base_expression, final boolean absolute)
   {
      super("Path", token);

      this.absolute = absolute;

      this.rootPrefix = root_prefix;
      this.expression = base_expression;
   }

   /**
    * Adds a general step to the path.
    * 
    * @param step the general step expression to be appended to the path.
    */
   public void addStep(final GeneralStepExpression step)
   {
      if (step != null)
      {
         /**
          * Append step to the path.
          */
         this.steps.add(step);

         /**
          * Links the previous step to the new one.
          */
         if (this.steps.size() > 1)
         {
            (this.steps.get(this.steps.size() - 2)).setNextStep(step);
         }
      }
      else
      {
         logger.warn("Cannot add an null general step to the path \"" + this
               + "\".");
      }
   }

   /**
    * Assign the root prefix to the expression.
    * 
    * @param root_prefix the prefix to be considered.
    */
   public void setRootPrefix(final String root_prefix)
   {
      this.rootPrefix = root_prefix;
   }

   /**
    * Evaluate the step, considering a given dynamic context.
    * 
    * @param context dynamic evaluation context.
    * @return the evaluated sequence.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {
      /**
       * Compute the output expression.
       */
      final DrbDefaultSequence output_sequence = new DrbDefaultSequence();

      /**
       * Get the base sequence for further steps.
       */
      DrbSequence sequence = null;

      // Case of path starting from the output of a primary expression

      if (this.expression != null)
      {
         sequence = this.expression.evaluate(context);
      }

      // Case of absolute path

      else if (this.absolute)
      {
         DrbNode root_node;
         String root_path = null;

         try
         {
            if (this.rootPrefix == null)
            {
               root_path = "/";
            }
            else
            {
               root_path = this.rootPrefix; // + "/";
               if (root_path.equals("http:/"))
               {
                  root_path = "http://";
               }
               if (root_path.equals("ftp:/"))
               {
                  root_path = "ftp://";
               }
            }

            root_node = DrbFactory.openURI(root_path);
         }
         catch (final Exception exception)
         {
            throw new DynamicException(this, "Error while opening root \""
                  + root_path + "\" (" + exception.getMessage() + ")");
         }

         if (root_node == null)
         {
            return output_sequence;
         }

         sequence = new DrbDefaultSequence();

         ((DrbDefaultSequence) sequence).addItem(root_node);
      }

      // Case of relative path

      else
      {
         sequence = new DrbDefaultSequence(context.focus.getContextItem());
      }

      final DynamicContext inner_context = new DynamicContext(context);

      if (this.steps.size() == 0)
      {
         return sequence;
      }

      for (int item = 0; item < sequence.getLength(); item++)
      {
         inner_context.focus.setContextItem(sequence.getItem(item));
         inner_context.focus.setContextPosition(item + 1);
         inner_context.focus.setContextSize(sequence.getLength());

         final DrbSequence current_sequence =
            (this.steps.get(0)).evaluate(inner_context);

         /**
          * Concatenate the current results to the output sequence.
          */
         for (int jtem = 0; jtem < current_sequence.getLength(); jtem++)
         {
            output_sequence.add(current_sequence.getItem(jtem));
         }
      }

      /**
       * Return the output sequence.
       */
      return output_sequence;
   }

   /**
    * Returns a detailed description of the path.
    * 
    * @return the description of the current expression.
    */
   public String toString()
   {
      String output = "";

      /**
       * Print root information.
       */
      if (this.expression != null)
      {
         output += this.expression;
      }
      else if (this.rootPrefix != null)
      {
         output = this.rootPrefix;
      }

      if (this.absolute)
      {
         output += "/";
      }

      /**
       * Print step.
       */
      for (int i = 0; i < this.steps.size(); i++)
      {
         output += "/";

         output += this.steps.get(i);
      }

      return output;
   }
}
