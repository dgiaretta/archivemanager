/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds.schema;

import fr.gael.drb.xsd.XsdElement;

/**
 * Declaration of an SDF element.
 */
public class SdfElement extends SdfParticle
{
   /**
    * Inner-class gathering the padding informations.
    */
   class Padding
   {
      /**
       * The padding in bytes. This is the length to skip before to consider the
       * value in the block. Therefore the real offset of the block value is :
       * offset+headerPadding.
       */
      protected int length;

      /**
       * The padding content string. This is the string defining the content of
       * the padding.
       */
      protected String content;

      /**
       * Build a padding.
       */
      protected Padding(final int length, final String content)
      {
         this.length = length;
         this.content = content;
      }
   } // Padding

   // ==========================================================================
   // Attributes part.
   // ==========================================================================

   /**
    * The total length in bytes. This class is used to manage the different
    * types of length: fixed or not. It permits to retreive the value for any
    * specific block occurrence.
    */
   protected SdfLength length;

   /**
    * The offset from neighbour information. When absolute offset is not set
    * yet, it is usefull to keep the relative information given. For instance it
    * can be set that there is an offset of 8 from the end of the previous
    * sibling.
    */
   protected SdfOffset blockOffset;

   /**
    * The outer left padding. This is the length to skip before to consider the
    * value in the block. Therefore the real offset of the block value is :
    * offset+headerPadding.
    */
   protected Padding headerPadding;

   /**
    * The inner left padding. This is the length to skip before to consider the
    * value in the block. Therefore the real offset of the block value is :
    * offset+headerPadding.
    */
   protected Padding leading;

   /**
    * The outer right padding. This is the length to skip after the value in the
    * block. Therefore the real length of the block value is :
    * length-footerPadding.
    */
   protected Padding trailing;

   /**
    * The outer right padding. This is the length to skip after the value in the
    * block. Therefore the real length of the block value is :
    * length-footerPadding.
    */
   protected Padding footerPadding;

   // ==========================================================================
   // Methods part.
   // ==========================================================================
   /**
    * Build an element.
    * 
    * @param element the element declaration
    */
   protected SdfElement(final XsdElement element)
   {
      super(element);
   }

   /**
    * Returns the name of this element.
    * 
    * @return The element name
    */
   public final String getName()
   {
      return ((XsdElement) this.particle).getName();
   } // getName

} // SdfElement
