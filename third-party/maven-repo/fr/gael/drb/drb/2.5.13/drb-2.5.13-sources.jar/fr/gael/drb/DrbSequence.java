/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import fr.gael.drb.value.ValueArray;

/**
 * Collection of item. This interface provides primary operations to handle
 * collections of items.
 */
public interface DrbSequence
{
   /**
    * Returns a specific item of the list. The item is identified by its
    * position (i.e. index or sequence number) in the list of items. The order
    * depends on the implementation as well as from the operation that created
    * the list. The index starts from 0 and shall not be greater or equal to the
    * item count of the list. A null reference is returned if the provided index
    * is outside the list bounds.
    * 
    * @param index The position of the item starting from and not greater or
    *           equal to the item count in the list.
    * @return A reference to specified item or null if no such attribute.
    */
   public DrbItem getItem(int index);

   /**
    * The atomic values of this sequence. The value of the node means its
    * content. The value is expressed accoring to one of the types supported by
    * the fr.gael.drb.value package. Generally these types correspond to
    * primitive types (e.g. integer, floatting points etc.) or very low level
    * types (e.g. string, date, etc.).
    * 
    * @return A reference to the values of the sequence.
    */
   public ValueArray atomize();

   /**
    * The number of items in the list. This number can be 0 if the list is empty
    * but shall never be negative.
    * 
    * @return The number of items is the list.
    */
   public int getLength();

   /**
    * Inserts a item at a given position. The passed item is inserted in the
    * list of children at the given position The position is the expected index
    * of the item after insertion. All the previous item from the aimed position
    * to the end of the list are shift to the end of the new sequence (i.e.
    * their indices are shifted up of 1). If the given index is out of the
    * sequence bounds and therefore less than zero and greater or equal to the
    * current number of items,the operation raises an exception. An index equal
    * to the current number of item is allowed and the operation is therefore
    * equivalent to an append.
    * 
    * @param index The expected index of the item after the insertion.
    * @param item A reference to the item to be inserted.
    * @return A reference to the a sequence containing the inserted node.
    * @throws NullPointerException This exception is raised when the passed item
    *            a null reference. This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passe
    *            index is less than zero or if it is greater or equal to the
    *            number of item in the sequence prior the call
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested insertion for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbSequence addItem(int index, DrbItem item)
         throws NullPointerException, UnsupportedOperationException,
         IndexOutOfBoundsException;

   /**
    * Removes an existing item. The item at the given index is removed from the
    * sequence of the current item. The item is not modified by this operation.
    * The index of the item to be removed has to correspond to an existing item
    * index. If the index is less than zero or greater or equal to the current
    * number of items, an exception is thrown.
    * 
    * @param index Index of the item to be removed.
    * @return A reference to the a sequence after the removal of the item.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested removal for any
    *            reason.
    */
   public DrbSequence removeItem(int index) throws IndexOutOfBoundsException,
         UnsupportedOperationException;

   /**
    * Returns the item matching a specific name. The name is a local name
    * without any prefix.
    * 
    * @param name The name to match.
    * @param occurence The occurence number of the desired item.
    * @return A reference to specified items or null if no such item.
    */
   // public DrbItem getNamedItem(String name, int occurrence);
   /**
    * Returns the item matching a specific name. The name is a local name
    * without any prefix.
    * 
    * @param name The name to match.
    * @param namespace_uri The namespace URI to match.
    * @return A reference to specified items or null if no such item.
    */
   // public DrbItem getNamedItemNS(String name, String namespace_uri);
} // DrbSequence
