/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * Generic numeric array wrapper.
 */
public abstract class AbstractNumericArray extends AbstractValueArray implements
      NumericArray, ValueFormat
{

   /**
    * Returns the underlying object for optimization.    
    * @return a backing array.
    */
   public abstract Object getData();

   // ------------------------------------------------------------
   // ValueFormat interface implementation
   // -----------------------------------------------------------
   // see interface ValueFormat for more information.

   /**
    * Return a string containing the value with a fixed format.
    * 
    * @param length The expected length of the output string
    * @return The formatted string.
    */
   public java.lang.String getFormattedString(final int length)
   {
      throw new UnsupportedOperationException("String format is not supported");
   }

   /**
    * Return a byte buffer containing the value in a fixed format.
    * 
    * @return The formatted buffer.
    */
   public byte[] getFormattedBuffer()
   {
      throw new UnsupportedOperationException("Binary format is not supported");
   }

   /**
    * Returns the Array type
    * 
    * @return the array type as an int
    */
   public int getArrayType()
   {
      return Value.UNKNOWN_ID;
   }

   /**
    * Convert the array values into the specified type.
    * 
    * @param array_type The target element type.
    * @return The converted value.
    * @throws ClassCastException if the conversion is impossible.
    */
   public final ValueArray convertArrayTo(final int array_type)
         throws ClassCastException
   {
      if (array_type == this.getArrayType())
      {
         return this;
      }

      switch (array_type)
      {
         // Numeric -> Numeric conversion
         case Value.NUMERIC_ID:
            return this;

            // Numeric -> Int conversion
         case Value.INT_ID:
            return new IntArray(this.intValues());

            // Numeric -> Double conversion
         case Value.DOUBLE_ID:
            return new DoubleArray(this.doubleValues());

            // Numeric -> String conversion
            /*
             * case Value.STRING_ID :{ return new String(toString());
             */
            // Numeric -> Float conversion
         case Value.FLOAT_ID:
            return new FloatArray(this.floatValues());

            // Numeric -> Long conversion
         case Value.LONG_ID:
            return new LongArray(this.longValues());

            // Numeric -> Short conversion
         case Value.SHORT_ID:
            return new ShortArray(this.shortValues());

            // Numeric -> Byte conversion
         case Value.BYTE_ID:
            return new ByteArray(this.byteValues());

            // Numeric -> Boolean conversion
         case Value.BOOLEAN_ID:
            return new BooleanArray(this.booleanValues());

            // Numeric -> UnsignedLong conversion
         case Value.UNSIGNED_LONG_ID:
            return new UnsignedLongArray(this.longValues());

            // Numeric -> UnsignedInteger conversion
         case Value.UNSIGNED_INT_ID:
            return new UnsignedIntArray(this.intValues());

            // Numeric -> UnsignedShort conversion
         case Value.UNSIGNED_SHORT_ID:
            return new UnsignedShortArray(this.shortValues());

            // Numeric -> UnsignedByte conversion
         case Value.UNSIGNED_BYTE_ID:
            return new UnsignedByteArray(this.byteValues());

            // Numeric -> Integer conversion
            /*
             * case Value.INTEGER_ID :{ return new Integer(integerValue());
             */
            // Numeric -> Decimal conversion
            /*
             * case Value.DECIMAL_ID :{ return new Decimal(decimalValue());
             */
            // Numeric -> Unknown
         default:
            throw new ClassCastException(this.getClass().getName()
                  + ": cannot cast to " + array_type);
      }
   }

   /**
    * Returns this value as a boolean.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type byte.
    */
   public boolean[] booleanValues()
   {
      final boolean[] v = new boolean[this.length()];
      for (int i = 0; i < v.length; i++)
      {
         v[i] = this.booleanValue(i);
      }
      return v;
   }

   /**
    * Returns this value as a byte (signed 8 bits). The conversion may result in
    * a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type byte.
    */
   public byte[] byteValues()
   {
      final byte[] v = new byte[this.length()];
      for (int i = 0; i < v.length; i++)
      {
         v[i] = this.byteValue(i);
      }
      return v;
   }

   /**
    * Returns this value as a short integer (signed 16 bits). The conversion may
    * result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type short.
    */
   public short[] shortValues()
   {
      final short[] v = new short[this.length()];
      for (int i = 0; i < v.length; i++)
      {
         v[i] = this.shortValue(i);
      }
      return v;
   }

   /**
    * Returns this value as an integer (signed 32 bits). The conversion may
    * result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type int.
    */
   public int[] intValues()
   {
      final int[] v = new int[this.length()];
      for (int i = 0; i < v.length; i++)
      {
         v[i] = this.intValue(i);
      }
      return v;
   }

   /**
    * Returns this value as a long integer (signed 64 bits). The conversion may
    * result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type long.
    */
   public long[] longValues()
   {
      final long[] v = new long[this.length()];
      for (int i = 0; i < v.length; i++)
      {
         v[i] = this.longValue(i);
      }
      return v;
   }

   /**
    * Returns the item values as float (signed 32 bits IEEE 754). The conversion
    * may result in a loss of precision.
    * 
    * @return the numeric values represented by this object after conversion to
    *         type float.
    */
   public float[] floatValues()
   {
      final float[] v = new float[this.length()];
      for (int i = 0; i < v.length; i++)
      {
         v[i] = this.floatValue(i);
      }
      return v;
   }

   /**
    * Returns the item values as double (signed 64 bits IEEE 754). The
    * conversion may result in a loss of precision.
    * 
    * @return the numeric values represented by this object after conversion to
    *         type double.
    */
   public double[] doubleValues()
   {
      final double[] v = new double[this.length()];
      for (int i = 0; i < v.length; i++)
      {
         v[i] = this.doubleValue(i);
      }
      return v;
   }

   // --------------------------------------------------------------------------
   // NumericArray interface implementation
   // --------------------------------------------------------------------------

   /**
    * Returns this value as a boolean.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type boolean.
    */
   public boolean booleanValue(final int index)
   {
      return ((Numeric) this.getElement(index)).booleanValue();
   }

   /**
    * Returns this value as a byte (signed 8 bits).
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type byte.
    */
   public byte byteValue(final int index)
   {
      return ((Numeric) this.getElement(index)).byteValue();
   }

   /**
    * Returns this value as an integer (signed 32 bits). The conversion may
    * result in a loss of precision.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type int.
    */
   public int intValue(final int index)
   {
      return ((Numeric) this.getElement(index)).intValue();
   }

   /**
    * Returns this value as a long integer (signed 64 bits). The conversion may
    * result in a loss of precision.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type long.
    */
   public long longValue(final int index)
   {
      return ((Numeric) this.getElement(index)).longValue();
   }

   /**
    * Returns this value as a short integer (signed 16 bits). The conversion may
    * result in a loss of precision.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type short.
    */
   public short shortValue(final int index)
   {
      return ((Numeric) this.getElement(index)).shortValue();
   }

   /**
    * Returns this value as a float (signed 32 bits IEEE 754).
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type float.
    */
   public float floatValue(final int index)
   {
      return ((Numeric) this.getElement(index)).floatValue();
   }

   /**
    * Returns this value as a double
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion
    */
   public double doubleValue(final int index)
   {
      return ((Numeric) this.getElement(index)).doubleValue();
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a double.
    */
   public void assign(final int index, final boolean value)
   {
      this.assign(index, new Boolean(value));
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a double.
    */
   public void assign(final int index, final byte value)
   {
      this.assign(index, new Byte(value));
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a double.
    */
   public void assign(final int index, final int value)
   {
      this.assign(index, new Int(value));
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a double.
    */
   public void assign(final int index, final short value)
   {
      this.assign(index, new Short(value));
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a double.
    */
   public void assign(final int index, final long value)
   {
      this.assign(index, new Long(value));
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a double.
    */
   public void assign(final int index, final float value)
   {
      this.assign(index, new Float(value));
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a double.
    */
   public void assign(final int index, final double value)
   {
      this.assign(index, new Double(value));
   }
} // AbstractNumericArray
