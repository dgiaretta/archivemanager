/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import fr.gael.drb.xsd.Namespace;

/**
 * Environment of static analysis and dynamic evaluation of an XQuery.
 * <p>
 * The environment variable is provided to the query engine in input of its
 * processings. The query engine uses the environment as context either during
 * the static analysis or the dynamic evaluation phases.
 * </p>
 * <p>
 * The environment provides the active namespaces, the default namespace for
 * unprefixed elements, types or functions. The environment also provides the
 * base URI as well as mechanisms to resolve external variables that may be
 * required by the XQuery script to be processed.
 * </p>
 * <p>
 * The current implementation of the environment does not already support schema
 * definitions, external functions, collations, collections and validation
 * mechanism.
 * </p>
 * <p>
 * It is important to notice that environment provides information that may be
 * overrided during the different processing phases of the XQuery script. As an
 * example, the default namespace used during the processing may differ from the
 * environment is the XQuery defines explicitely a new one.
 * </p>
 */
public class Environment
{
   /**
    * Logger
    */
   Logger logger = Logger.getLogger(Environment.class);

   /**
    * Namespace for XPath built-in functions fn =
    * "http://www.w3.org/2005/xpath-functions"
    */
   public final static String XPATH_FUNCTIONS_URI =
      "http://www.w3.org/2005/xpath-functions";

   /**
    * Prefix for XPath and XQuery error codes and messages err =
    * "http://www.w3.org/2005/xqt-errors"
    */
   public final static String XQT_ERRORS_PREFIX = "err";

   /**
    * Namespace for XPath and XQuery error codes and messages err =
    * "http://www.w3.org/2005/xqt-errors"
    */
   public final static String XQT_ERRORS_URI =
      "http://www.w3.org/2005/xqt-errors";

   /**
    * Namespace for XPath and XQuery error codes and messages local =
    * "http://www.w3.org/2005/xquery-local-functions"
    */
   public final static String XQUERY_LOCAL_FUNCTIONS_URI =
      "http://www.w3.org/2005/xquery-local-functions";

   /**
    * Prefix for DRB built-in functions drb = "http://www.gael.fr/drb"
    */
   public final static String DRB_FUNCTIONS_PREFIX = "drb";

   /**
    * Namespace for GAEL built-in functions gael = "http://www.gael.fr"
    */
   public final static String GAEL_FUNCTIONS_URI = "http://www.gael.fr";

   /**
    * Namespace for DRB built-in functions drb = "http://www.gael.fr/drb"
    */
   public final static String DRB_FUNCTIONS_URI = "http://www.gael.fr/drb";

   /**
    * Namespace for Math built-in functions math = "http://exslt.org/math"
    */
   public final static String MATH_FUNCTIONS_URI = "http://exslt.org/math";

   /**
    * Namespaces. This attribute gathers all (prefix, URI) pairs defining the
    * namespaces to be considered. At creation, the namespace is augmented with
    * the default namespaces defined by the XQuery specifications (c.f.
    * Environment constructor commentary.
    */
   private Namespace namespace = new Namespace();

   /**
    * Default element/type namespace. This is a namespace URI. It is used for
    * any unprefixed QName appearing in a position where an element or type name
    * is expected. At creation the default namespace is null.
    */
   private String defaultElementNamespaceURI = null;

   /**
    * Default function namespace. This is a namespace URI. It is used for any
    * unprefixed QName appearing in a position where a function name is
    * expected. At creation the default namespace is
    * "http://www.w3.org/2003/11/xpath-functions".
    */
   private String defaultFunctionNamespaceURI = XPATH_FUNCTIONS_URI;

   /**
    * Base URI of the environment. This is a namespace URI, used when necessary
    * in the resolution of relative URIs.
    */
   private String baseURI = null;

   /**
    * External variables.
    */
   private Map<QName, ExternalVariable> externalVariable =
      new HashMap<QName, ExternalVariable>();

   /**
    * Host the deprecated parameter resolver.
    */
   // TODO: remove this attribute
   protected ParameterResolver resolver = null;

   /**
    * Denotes whether static and dynamic evaluations should attempt to support
    * depreciated syntaxes, expressions or behaviors. This mode does not
    * guarantee that all previous behaviors could be emulated and in particular
    * for more than one backward software version. Callers should not rely on
    * this mode but only for very short periods when the latest version is
    * required but efforts to adapt the software to all incompatible
    * improvements is too heavy, or in equivalent situation.
    */
   private boolean isBackwardCompatibilityMode = false;

   /**
    * True if the compatibility mode property has been set by the user or
    * deduced from the corresponding system property. False otherwise.
    */
   protected boolean isBackwardCompatibilityModeSet = false;

   /**
    * Environment constructor. This operations initialises the environment with
    * default values.
    * <p>
    * The following default namespaces are inserted:
    * <table>
    * <tr>
    * <td>xml</td>
    * <td>http://www.w3.org/XML/1998/namespace</td>
    * </tr>
    * <tr>
    * <td>fn</td>
    * <td>http://www.w3.org/2005/xpath-functions</td>
    * </tr>
    * <tr>
    * <td>xs</td>
    * <td>http://www.w3.org/2001/XMLSchema</td>
    * </tr>
    * <tr>
    * <td>xsi</td>
    * <td>http://www.w3.org/2001/XMLSchema-instance</td>
    * </tr>
    * <tr>
    * <td>xdt</td>
    * <td>http://www.w3.org/2003/11/xpath-datatypes</td>
    * </tr>
    * <tr>
    * <td>local</td>
    * <td>http://www.w3.org/2005/xquery-local-functions</td>
    * </tr>
    * <tr>
    * <td>drb</td>
    * <td>http://www.gael.fr/drb</td>
    * </tr>
    * <tr>
    * <td>math</td>
    * <td>http://exslt.org/math</td>
    * </tr>
    * <tr>
    * <td>gael</td>
    * <td>http://www.gael.fr</td>
    * </tr>
    * <tr>
    * <td>esa</td>
    * <td>http://www.esa.int</td>
    * </tr>
    * </table>
    */
   public Environment()
   {
      /**
       * Initialise namespace according to the XQuery specifications.
       */
      this.namespace.bind("xml", "http://www.w3.org/XML/1998/namespace");
      this.namespace.bind("fn", XPATH_FUNCTIONS_URI);
      this.namespace.bind("xs", Namespace.XML_SCHEMA_NAMESPACE);
      this.namespace.bind("xsi", Namespace.XML_SCHEMA_INSTANCE);
      this.namespace.bind("xdt", "http://www.w3.org/2003/11/xpath-datatypes");
      this.namespace.bind("local", XQUERY_LOCAL_FUNCTIONS_URI);

      this.namespace.bind("drb", DRB_FUNCTIONS_URI);
      this.namespace.bind("math", MATH_FUNCTIONS_URI);

      this.defaultFunctionNamespaceURI = XPATH_FUNCTIONS_URI;
   } // Environment constructor

   /**
    * Returns the namespace of the environment.
    * 
    * @return the namespace of the current environment.
    */
   public Namespace getNamespace()
   {
      return this.namespace;
   }

   /**
    * Returns a qualified name from its string form.
    * 
    * @return the qualified name of the passed string.
    */
   public QName resolveQName(final String name)
   {
      return this.resolveQName(name, null);
   }

   /**
    * Returns a qualified name from its string form.
    * 
    * @return the qualified name of the passed string.
    */
   public QName resolveQName(final String name, final String default_namespace)
   {
      // Extracts input variable name prefix
      final String prefix = Namespace.toPrefix(name);

      // Resolve corresponding namespace URI
      String ns = default_namespace;
      if (prefix != null)
      {
         ns = this.getNamespace().resolveNamespace(prefix);
      }

      return new QName(name, ns);
   }

   /**
    * Set the namespace provided in parameter. Any previous namespace will be
    * discarded.
    * 
    * @param namespace the namespace to be considered.
    */
   public void setNamespace(final Namespace namespace)
   {
      this.namespace = namespace;
   }

   /**
    * Returns the default namespace URI of elements and types.
    * 
    * @return the default namspace URI if exist or null otherwise.
    */
   public String getDefaultElementNamespaceURI()
   {
      return this.defaultElementNamespaceURI;
   }

   /**
    * Set the default namespace URI for elements and types. Any previous default
    * namespace URI will be overriden.
    * 
    * @param namespace_uri the new default namespace URI to consider.
    */
   public void setDefaultElementNamespaceURI(final String namespace_uri)
   {
      this.defaultElementNamespaceURI = namespace_uri;
   }

   /**
    * Returns the default namespace URI of functions.
    * 
    * @return the default namspace URI if exist or null otherwise.
    */
   public String getDefaultFunctionNamespaceURI()
   {
      return this.defaultFunctionNamespaceURI;
   }

   /**
    * Set the default namespace URI for functions. Any previous default
    * namespace URI will be overriden.
    * 
    * @param namespace_uri the new default namespace URI to consider.
    */
   public void setDefaultFunctionNamespaceURI(final String namespace_uri)
   {
      this.defaultFunctionNamespaceURI = namespace_uri;
   }

   /**
    * Returns the base URI of the enviroment.
    * 
    * @return the base URI if exist or null otherwise.
    */
   public String getBaseURI()
   {
      return this.baseURI;
   }

   /**
    * Set the base URI of the environment. Any previous base URI will be
    * overriden.
    * 
    * @param base_uri the new base URI to consider.
    */
   public void setBaseURI(final String base_uri)
   {
      this.baseURI = base_uri;
   }

   /**
    * Add external variables.
    * 
    * @param variable the external variable to be added.
    */
   protected void addExternalVariable(final ExternalVariable variable)
   {
      this.externalVariable.put(variable.getQName(), variable);
   }

   /**
    * Set a new external variable list. Any previous list will be discarded by
    * this operation. In order to keep the class consistent, null reference is
    * avoided. No object is duplicated.
    * 
    * @param variable_list new list of external variables.
    */
   protected void setExternalVariableMap(
      final Map<QName, ExternalVariable> variable_list)
   {
      if (variable_list == null)
      {
         throw new NullPointerException("Null external variable list.");
      }

      this.externalVariable = variable_list;
   }

   /**
    * Return a reference to the external variable list.
    * 
    * @return the external variable list.
    */
   protected Map<QName, ExternalVariable> getExternalVariableMap()
   {
      return this.externalVariable;
   }

   /**
    * Return an external variable if already declared. The external variable may
    * originate from the environment creator or may have been added during the
    * satic analysis phase of the XQuery processing.
    * 
    * @param name the string form of the variable qualified name.
    * @return the external variable.
    */
   public ExternalVariable getExternalVariable(final String name)
   {
      return this.getExternalVariable(this.resolveQName(name));
   }

   /**
    * Return an external variable if already declared. The external variable may
    * originate from the environment creator or may have been added during the
    * satic analysis phase of the XQuery processing.
    * 
    * @param name the variable qualified name.
    * @return the external variable.
    */
   public ExternalVariable getExternalVariable(final QName name)
   {
      return this.externalVariable.get(name);
   }

   /**
    * Returns the set of external variables. The external variable may originate
    * from the environment creator or may have been added during the satic
    * analysis phase of the XQuery processing.
    * 
    * @return the array of external variables, if any, or null otherwise.
    */
   public ExternalVariable[] getExternalVariables()
   {
      final Collection<ExternalVariable> variables =
         this.externalVariable.values();

      if (variables == null)
      {
         return null;
      }

      final Object[] vars = variables.toArray();

      if (vars.length > 0)
      {
         final ExternalVariable[] output = new ExternalVariable[vars.length];

         for (int ivar = 0; ivar < output.length; ivar++)
         {
            output[ivar] = (ExternalVariable) vars[ivar];
         }

         return output;
      }
      else
      {
         return null;
      }
   }

   /**
    * Check if an external variable is declared.
    * 
    * @param name string form of the qualified name of the external variable.
    * @return true if the variable is declared, false otherwise.
    */
   public boolean containsExternalVariable(final String name)
   {
      return this.containsExternalVariable(this.resolveQName(name));
   }

   /**
    * Check if an external variable is declared.
    * 
    * @param name string form of the qualified name of the external variable.
    * @return true if the variable is declared, false otherwise.
    */
   public boolean containsExternalVariable(final QName name)
   {
      return this.externalVariable.containsKey(name);
   }

   /**
    * True denotes whether static and dynamic evaluations should attempt to
    * support depreciated syntaxes, expressions or behaviors. This mode does not
    * guarantee that all previous behaviors could be emulated and in particular
    * for more than one backward software version. Callers should not rely on
    * this mode but only for very short periods when the latest version is
    * required but efforts to adapt the software to all incompatible
    * improvements is too heavy, or in equivalent situation.
    * 
    * @param isBackwardCompatibilityMode the mode to set.
    */
   public void setBackwardCompatibilityMode(boolean isBackwardCompatibilityMode)
   {
      this.isBackwardCompatibilityMode = isBackwardCompatibilityMode;
      this.isBackwardCompatibilityModeSet = true;
   } // End setBackwardCompatibilityMode(boolean)

   /**
    * True denotes whether static and dynamic evaluations should attempt to
    * support depreciated syntaxes, expressions or behaviors.
    * <p>
    * This mode does not guarantee that all previous behaviors could be emulated
    * and in particular for more than one backward software version. Callers
    * should not rely on this mode but only for very short periods when the
    * latest version is required but efforts to adapt the software to all
    * incompatible improvements is too heavy, or in equivalent situation.
    * </p>
    * <p>
    * The default value is false, unless an explicit user call to the
    * {@link #setBackwardCompatibilityMode(boolean)} method with a true
    * parameter or a 'true' value of the system property
    * <code>fr.gael.drb.query.BackwardCompatibilityMode</code>.
    * </p>
    * 
    * @return the backward compatibility mode
    * @see #setBackwardCompatibilityMode(boolean)
    */
   public boolean isBackwardCompatibilityMode()
   {
      // Deduce compatibility mode from system property: false if not set of
      // different from 'true'
      if (!this.isBackwardCompatibilityModeSet)
      {
         String mode =
            System.getProperty("fr.gael.drb.query.BackwardCompatibilityMode");

         if ((mode != null) && (mode.equals("true")))
         {
            this.setBackwardCompatibilityMode(true);
         }
         else
         {
            this.setBackwardCompatibilityMode(false);
         }
      }

      // Return mode
      return this.isBackwardCompatibilityMode;

   } // End isBackwardCompatibilityMode()

   /**
    * Returns relevant information of the environment.
    * 
    * @return environmental information.
    */
   @Override
   public String toString()
   {
      String string = "";

      string = string + "Namespaces:\n" + this.namespace;
      string =
         string + "Default element namespace URI: "
               + this.defaultElementNamespaceURI + "\n";
      string =
         string + "Default function namespace URI: "
               + this.defaultFunctionNamespaceURI + "\n";
      string = string + "External variables: \n";

      final ExternalVariable[] variables = this.getExternalVariables();

      if (variables != null)
      {
         for (int ivar = 0; ivar < variables.length; ivar++)
         {
            string += "   -> " + variables[ivar] + "\n";
         }
      }

      return string;
   }

   /**
    * Returns true if the given namespace is reserved; return false otherwise.
    * 
    * @param uri the namespace URI to match.
    * @return true if the given namespace is reserved; false otherwise.
    */
   static boolean isReservedNamespace(String uri)
   {
      return "http://www.w3.org/XML/1998/namespace".equals(uri)
            || XPATH_FUNCTIONS_URI.equals(uri)
            || Namespace.XML_SCHEMA_NAMESPACE.equals(uri)
            || Namespace.XML_SCHEMA_INSTANCE.equals(uri)
            || DRB_FUNCTIONS_URI.equals(uri);
   }
}
