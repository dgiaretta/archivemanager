/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import org.apache.log4j.Logger;

import fr.gael.drb.value.Value;
import fr.gael.drb.xsd.Namespace;

/**
 * This class provides a skeletal implementation of the DrbNode interface, to
 * minimize the effort required to implement this interface. The class is also a
 * node change producer so its possible to monitor the changed performed on each
 * instance.
 */
public abstract class DrbAbstractNode extends DrbDefaultNodesChangeProducer
      implements DrbNode, DrbMutableNode
{

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(DrbAbstractNode.class);

   // ----------------------------------------------
   // Object class overload
   // ----------------------------------------------
   /**
    * Indicates whether this node is "equal to" to another node. See
    * Object.equals() for the general contract of this method.
    * 
    * @param obj another value.
    * @return true if this object is the same as the obj argument
    */
   public boolean equals(final Object obj)
   {
      // Check reference equality
      if (this == obj)
      {
         return true;
      }

      // Otherwise the object is different
      return false;
   } // equals

   // ------------------------------------------------------------------
   // DrbItem implementation
   // ------------------------------------------------------------------

   /**
    * A code representing the type of the underlying object, as defined above.
    * 
    * @return The code of this item.
    */
   public int getItemType()
   {
      return NODE_ITEM;
   }

   // ------------------------------------------------------------------
   // DrbNode implementation
   // ------------------------------------------------------------------
   /**
    * Name of the node. Returns the name of the node. This name is the canonical
    * name of the node It does not contains any prefix, path and location part.
    * This name clearly identifies the node in its parent depending only from
    * its occurence number and its index. All nodes provided by an
    * implementation is named.Therefore this operation never returns null value.
    * An empty string is however allowed if the node is unique (e.g. non named
    * root node).
    * 
    * @return The name of the node.
    */
   public String getName()
   {
      return "";
   }

   /**
    * Name of the node. Returns the name of the node. This name is the canonical
    * name of the node It does not contains any prefix, path and location part.
    * This name clearly identifies the node in its parent depending only from
    * its occurence number and its index. All nodes provided by an
    * implementation is named.Therefore this operation never returns null value.
    * An empty string is however allowed if the node is unique (e.g. non named
    * root node).
    * 
    * @return The name of the node.
    */
   protected String getXPathName()
   {
      if (this.allowsMultiOccurrence())
      {
         final long occurrence = this.getOccurrence();
         boolean has_occurence = occurrence>1?true:false;
         
         DrbNode parent = this.getParent ();
         if ((parent!=null) &&
             (parent.getNamedChild (this.getName (), 2) != null))
            has_occurence=true;

         if (has_occurence)
         {
            return this.getName() + "[" + occurrence + "]";
         }
         else
         {
            return this.getName();
         }
      }
      else
      {
         return this.getName();
      }
   }

   /**
    * Name of the node. This method is provided to implement filtering
    * operations. It's simply call getXPathName() of the input node.
    * 
    * @param node node
    * @return The name of the node.
    */
   protected final String getXPathName(final DrbAbstractNode node)
   {
      return node.getXPathName();
   }

   /**
    * Index of the node. Returns the index of the node in its parent children
    * list. This index starts from 0 and takes into account all occurences of
    * nodes disregrading the type of nodes. If the node has not parent the index
    * may not be available: the operation returns therefore a negative value.
    * 
    * @return The index of the node or negative value.
    */
   public int getIndex()
   {
      /**
       * Check that this node has a valid parent.
       */
      final DrbNode parent = this.getParent();

      if (parent == null)
      {
         return -1;
      }
      final DrbNodeList parentChildren = parent.getChildren();

      if (parentChildren == null)
      {
         return -1;
      }
      /**
       * Check that this node has a valid name.
       */
      final String name = this.getName();

      if (name == null)
      {
         return -1;
      }

      /**
       * Search the current node into the parent children.
       */
      for (int inode = 0; inode < parentChildren.getLength(); inode++)
      {
         final DrbNode child = parentChildren.item(inode);

         if (this.equals(child))
         {
            return inode;
         }
      }
      return -1;
   } // getIndex

   /**
    * Occurrence of the node. Returns the occurrence of the node in its parent
    * children list. If the node has not parent the occurrence may not be
    * available: the operation returns therefore a negative value.
    * 
    * @return The index of the node or negative value.
    */
   public int getOccurrence()
   {
      if (!this.allowsMultiOccurrence())
      {
         return 1;
      }

      /**
       * Check that this node has a valid parent.
       */
      final DrbNode parent = this.getParent();

      if (parent == null)
      {
         return 1;
      }

      final DrbNodeList parentChildren = parent.getChildren();

      if (parentChildren == null)
      {
         return 1;
      }
      /**
       * Check that this node has a valid name.
       */
      final String name = this.getName();

      if (name == null)
      {
         return 1;
      }

      /**
       * Search the current node into the parent children.
       */
      int occurs = 1;
      for (int inode = 0; inode < parentChildren.getLength(); inode++)
      {
         final DrbNode sibling = parentChildren.item(inode);

         if (this.equals(sibling))
         {
            return occurs;
         }
         if (name.equals(sibling.getName()))
         {
            occurs++;
         }
      }

      return -1;
   } // getOccurrence

   /**
    * Check if this node may have multiple occurrence
    * 
    * @return true if the children may have a multiple occurrence and false
    *         otherwise.
    */
   public boolean allowsMultiOccurrence()
   {
      return true;
   } // allowsMultiOccurrence

   /**
    * Returns the root node. The root node retreival is delegated to the parent
    * node if any. If no parent has been declared for this node, the operation
    * returns therefore null.
    * 
    * @return A reference to the root node or null.
    */
   public DrbNode getRoot()
   {
      final DrbNode parent = this.getParent();
      if (parent != null)
      {
         return parent.getRoot();
      }
      else
      {
         return null;
      }
   }

   /**
    * The full path of the node. The full path is the full path of the parent
    * node to which is appended the name of the current node.
    * <p>
    * <b>Warning:</b> Because the occurence number of the current node is not
    * known in the parent, the occurence qualifier is not support by the current
    * implementation.A possible algorithm shall be to search a reference to the
    * current node in the list of children of the parent.
    * </p>
    * If no parent have already been set no absolute path is considered. A path
    * considering the current node has a root node is not valid for the factory
    * and is therefore not significant in the current implementation.
    * 
    * @return The absolute path of the current node.
    */
   public String getPath()
   {
      final DrbNode parent = this.getParent();
      final String nodePath = this.getXPathName();

      if (parent != null)
      {
         final String parentPath = parent.getPath();

         if (parentPath != null)
         {
            String path = parentPath + "/" + nodePath;

            if (parentPath.endsWith("/"))
            {
               path = parentPath + nodePath;
            }

            return path;
         }
      }

      return nodePath;
   }

   /**
    * Get namespace URI. The namespace URI of this node, or null if it is
    * unspecified. This is not a computed value that is the result of a
    * namespace lookup based on an examination of the namespace declarations in
    * scope. It is merely the namespace URI given at creation time. The
    * Namespaces on an attribute does not inherit its namespace from the element
    * it is attached to. If an attribute is not explicitly given a namespace, it
    * simply has no namespace
    * 
    * @return The namspace URI or null if unspecified.
    */
   public String getNamespaceURI()
   {
      return null;
   }

   /**
    * Get the namespace bindings.
    * 
    * @return The namespace bindings.
    */
   public Namespace getNamespaceBindings()
   {
      return null;
   }

   /**
    * The value type of the node. The value type is determined from the value
    * previously assigned to the node. If no speficic value has been previsouly
    * set, fr.gael.drb.value.Value.NULL_ID type is returned.
    * 
    * @return NULL_ID if the node does not provide value or any other valid type
    *         identifier otherwise.
    */
   public int getValueType()
   {
      return Value.NULL_ID;
   }

   /**
    * The value of the node. The value is the one previously set.
    * 
    * @return A reference to the value of the node or null if no value has
    *         already been set.
    */
   public Value getValue()
   {
      return null;
   }

   /**
    * The attributes of the nodes. This operation returns a list of attribute
    * previously set (if any).
    * 
    * @return The list attributes of the current node or null if none.
    */
   public DrbAttributeList getAttributes()
   {
      return new DrbDefaultAttributeList();
   }

   /**
    * Returns an attribute matching a specific name.
    * 
    * @param name The name to match.
    * @return A reference to the attribute or null is not found.
    */
   public DrbAttribute getAttribute(final String name)
   {
      final DrbAttributeList attribList = this.getAttributes();
      if (attribList == null)
      {
         return null;
      }
      else
      {
         return attribList.getNamedItem(name);
      }
   }

   /**
    * The parent of this node. Returns a reference to the parent node of the
    * current node according to the curren implementation. Most of the nodes
    * have a parent exept root nodes or if they have just been removed, etc. If
    * the node has no parent the operation returns null.
    * 
    * @return The parent of this node or null.
    */
   public abstract DrbNode getParent();

   /**
    * The list of children of the current node. Returns a list of references to
    * the children of the current node. The current node may have no child and
    * the operation returns therefore a null reference.
    * 
    * @return The list of children if any null otherwise.
    */
   public abstract DrbNodeList getChildren();

   /**
    * The content of the current node. Returns a sequence of nodes and atomic
    * values.
    * 
    * @return The content of this node.
    */
   public DrbSequence getContent()
   {
      final DrbNodeList children = this.getChildren();
      final Value value = this.getValue();
      // Case of element only children
      if (value == null)
      {
         return children;
      }
      // Case of atomic value
      if (children == null)
      {
         return new DrbDefaultSequence(value);
      }
      // Case of mixed content
      final DrbDefaultSequence content = new DrbDefaultSequence(children);
      content.addItem(value);

      return content;
   }

   /**
    * Checks if child any child exists. Returns wheter the current node has at
    * least a child. This check is performed on the list set previously (if
    * any). The list reference as well as the effective number of children are
    * checked.
    * 
    * @return true if this node has any children, false otherwise.
    */
   public boolean hasChild()
   {
      return this.getChildrenCount() > 0;
   }

   /**
    * Returns an occurence of the node matching the specified name.
    * 
    * @param name the String
    * @param occurence int
    * @return DrbNode
    */
   public DrbNode getNamedChild(final String name, final int occurence)
   {
      /**
       * Checks parameters.
       */
      if ((name == null) || (occurence <= 0))
      {
         this.logger.error("DrbAbstractNode.getNamedChild(): "
               + "Invalid parameter (name=\"" + name + "\", occurence="
               + occurence);
         return null;
      }

      /**
       * Check if the children list is empty.
       */
      final DrbNodeList children = this.getChildren();
      if (children == null)
      {
         return null;
      }

      /**
       * Search the matching node.
       */
      return children.getNamedItem(name, occurence);
   }

   /**
    * Reference to the first child of the current node. The reference to the
    * first child is retreived from the children list previously set.
    * 
    * @return A reference to the first child or null if no such node.
    */
   public DrbNode getFirstChild()
   {
      return this.getChildAt(0);
   } // getFirstChild

   /**
    * Reference to the last child of the current node. The reference to the last
    * child is retreived from the children list previously set.
    * 
    * @return A reference to the last child or null if no such node.
    */
   public DrbNode getLastChild()
   {
      final int childrenCount = this.getChildrenCount();
      if (childrenCount <= 0)
      {
         return null;
      }
      return this.getChildAt(childrenCount - 1);
   } // getLastChild

   /**
    * Reference to a specific child. The child is extracted from the children
    * list previously set.
    * 
    * @param index The position of the node to retreive starting from 0 and not
    *           greater or equal to the number of children.
    * @return A reference to specified child or null if no such node.
    */
   public DrbNode getChildAt(final int index)
   {
      final DrbNodeList children = this.getChildren();
      if (children != null)
      {
         return children.item(index);
      }
      else
      {
         return null;
      }
   } // getChildAt

   /**
    * Number of children. The number of children is retreived from the children
    * list previously set If the children list has not already been set, 0 is
    * returned.
    * 
    * @return The number of children of the current node.
    */
   public int getChildrenCount()
   {
      final DrbNodeList children = this.getChildren();
      if (children != null)
      {
         return children.getLength();
      }
      else
      {
         return 0;
      }
   } // getChildrenCount

   /**
    * Previous sibling of the current node. Returns a reference to the previous
    * node in the children list of current node parent. This reference may be
    * null if the current node has no parent or if it is the first child of its
    * parent. The reference may be null if the current node has no previous
    * sibling.
    * 
    * @return A reference to the previous sibling or null if no such node.
    */
   public DrbNode getPreviousSibling()
   {
      /**
       * Check that this node has a valid parent.
       */
      final DrbNode parent = this.getParent();
      if (parent == null)
      {
         return null;
      }
      final int index = this.getIndex();
      if (index == 0)
      {
         return null;
      }
      if (index > 0)
      {
         return parent.getChildAt(index - 1);
      }
      final DrbNodeList parentChildren = parent.getChildren();
      if (parentChildren == null)
      {
         return null;
      }

      /**
       * Search the current node into the parent children.
       */
      DrbNode previousNode = parentChildren.item(0);
      for (int inode = 1; inode < parentChildren.getLength(); inode++)
      {
         final DrbNode currentNode = parentChildren.item(inode);
         if (this.equals(currentNode))
         {
            return previousNode;
         }
         previousNode = currentNode;
      }
      return null;
   }

   /**
    * Next sibling of the current node. Returns a reference to the next node in
    * the children list of current node parent. This reference may be null if
    * the current node has no parent or if it is the last child of its parent.
    * The reference may be null if the current node has no next sibling.
    * 
    * @return A reference to the next sibling or null if no such node.
    */
   public DrbNode getNextSibling()
   {
      /**
       * Check that this node has a valid parent.
       */
      final DrbNode parent = this.getParent();
      if (parent == null)
      {
         return null;
      }
      final int index = this.getIndex();
      if (index >= 0)
      {
         return parent.getChildAt(index + 1);
      }

      final DrbNodeList parentChildren = parent.getChildren();
      if (parentChildren == null)
      {
         return null;
      }

      /**
       * Search the current node into the parent children.
       */
      for (int inode = 0; inode < parentChildren.getLength() - 1; inode++)
      {
         if (this.equals(parentChildren.item(inode)))
         {
            return parentChildren.item(inode + 1);
         }
      }
      return null;
   }

   // ----------------------------------------------------------
   // DrbMutableNode implementation
   // ----------------------------------------------------------
   /**
    * Changes the name of the node. The passed name may be an empty string but
    * never a null reference. The change is persistant such as further instance
    * of a same node (even in different sessions) will have this new name. If
    * the implementation does not suppot the rename operation it is supposerd to
    * throw a UnsupportedOperationException.
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current standing also as the source of the event. The called
    * opetation is the nodesChanged() of the listeners.
    * </p>
    * 
    * @param name Reference to the new name.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested rename for any
    *            reason (e.g. specific case or general incapability).
    * @throws NullPointerException This exception is raised when the passed name
    *            is a null reference.This exception may be overriden by an
    *            UnsupportedOperationException.
    */
   public void rename(final String name) throws NullPointerException,
         UnsupportedOperationException
   {
      throw new UnsupportedOperationException("DrbAbstractNode.rename() : "
            + "This operation is not supported by this implementation.");
   }

   /**
    * Changes the value of the node. This operation sets a new value of the
    * current node.The value type of the node shall be compatible with the node
    * implementation. If the type does not match exactly it is casted to a
    * compatible one based on the the fr.gael.drb.value capabilities. A
    * reference to the effectivelly assigned value is returned by the operation
    * so it is possible to check if a cast has been performed and therefore
    * assess the accuracy of the assignement. If the cast is not possible the
    * operation raises an UnsupportedOperationException. If the assignment is
    * possible and the node implementation has a physical representation the
    * value is updated in the physical source in order to persist among
    * sessions. It therefore possible that this operation consumses an variable
    * time.
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept value changes. For instance it may not be possible to change the
    * value of a file directory that has no immediate signification.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node changed event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node. The called operation is
    * the nodesChanged() of the listeners.
    * </p>
    * 
    * @param value The new value of the node. This value shall not be null.
    * @return The effectivelly assigned value.The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested assignment for
    *            any reason.
    */
   public Value setValue(final Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      throw new UnsupportedOperationException(
            "DrbAbstractNode.setValue(): This operation is not supported.");
   }

   /**
    * Set the attribute list of a node. If some attributes are already attached
    * to the current node they are first removed and then replaced by the new
    * ones. However the operation checks the compatibility of the passed
    * attribute according to the current implementation. The operation does
    * nothing if the compatibility check fails.
    * <p>
    * <b>Warning:</b> The input attributes maybe duplicated or re-instanciated
    * according to the targetted implementation. References to the effectively
    * inserted attributes can be reteived from the getAttributes() operation of
    * the DrbNode. It is highly recommended to discard the references to the
    * input attribuets if not mandatory.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept attribute changes. For instance it may not be possible to change
    * the size attribute of a file through this operation with would meant a
    * effective file resize that is not really relevant without additional data.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node.The called operation is the
    * nodesChanged() of the listeners.
    * </p>
    * 
    * @param attributes A reference to the new attribute list.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the attribute list is null. This exception may be
    *            overriden by an UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested attribute changes
    *            for any reason.
    */
   public void setAttributes(final DrbAttributeList attributes)
         throws NullPointerException, UnsupportedOperationException
   {
      throw new UnsupportedOperationException(
            "DrbAbstractNode.setAttributes(): This operation is not supported.");
   }

   /**
    * Sets a namespace resource identifier. The new namespace identifier shall
    * not be null.
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept namespace changes. For instance it may not be possible to change
    * the namespace of a file that is basically fixed.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node.The called operation is the
    * nodesChanged() of the listeners.
    * </p>
    * 
    * @param namespace_uri A reference to the new namespace identifier.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the new namespace identifier is null.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested namespace change
    *            for any reason (e.g. by definition or in the specific case).
    */
   public void setNamespaceURI(final String namespace_uri)
         throws NullPointerException, UnsupportedOperationException
   {
      throw new UnsupportedOperationException(
            "DrbAbstractNode.setNamespaceURI(): This operation is not supported.");
   }

   /**
    * Set the namespace bindings.
    * 
    * @param bindings The namespace bindings.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested namespace change
    *            for any reason (e.g. by definition or in the specific case).
    */
   public void setNamespaceBindings(final Namespace bindings)
         throws UnsupportedOperationException
   {
      throw new UnsupportedOperationException(
            "DrbAbstractNode.setNamespaceBindings():"
                  + " This operation is not supported.");
   }

   /**
    * Inserts a child at a given position. The passed node is inserted in the
    * list of children at the given position The position is the expected index
    * of the node after insertion. All the previous children from the aimed
    * position to the end of the list are shift to the end of the new children
    * list (i.e. their indices are shifted up of 1). If the given index is out
    * of the children bounds and therefore less than zero and greater or equal
    * to the current number of children,the operation raises an exception. An
    * index equal to the current number of children is allowed and the operation
    * is therefore equivalent to appendChild().
    * <p>
    * If the node has been inserted within the children list, the next sibling
    * indicies are increased of one. In addition the assiociations between the
    * inserted node and it previous and next siblings are updated (if any).
    * </p>
    * <p>
    * <b>Warning:</b> The inserted node may be duplicated or re-instanciated
    * according to the targetted implementation. A reference to the effectively
    * inserted node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned node.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to insert a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Case of unordered or specifically ordered implementations:</b> If the
    * implementation does not support ordered children or has specific ordering
    * rules, the node is inserted without taking into account the requested
    * index passed in parameter. For instance it may not be possible to impose
    * the file order in a directory: it generally depends on the lexicographical
    * order of the node names or their creation date.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the inserted node and the source is the current node. The called
    * operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param node A reference to the node to be inserted.
    * @param index The expected index of the node after the insertion.
    * @return A reference to the effectively inserted node. This reference may
    *         differ from the input one.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference.This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or if it is greater or equal to the
    *            number of children in the number of children prior the call
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested insertion for any
    *            reason(e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbNode insertChild(final DrbNode node, final int index)
         throws NullPointerException, UnsupportedOperationException,
         IndexOutOfBoundsException
   {
      throw new UnsupportedOperationException(
            "DrbAbstractNode.insertChild(): This operation is not supported.");
   } // insertChild

   /**
    * Appends a child at the end of the children list. The passed node is
    * inserted in the list of children at the end of the current list.
    * <p>
    * <b>Warning:</b> The appended node may be duplicated or re-instanciated
    * according to the targetted implementation. A reference to the effectively
    * appended node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned node.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to append a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Case of unordered or specifically ordered implementations:</b> If the
    * implementation does not support ordered children or has specific ordering
    * rules, the node may not be appended but only inserted according to these
    * rules. For instance it may not be possible to impose the file order in a
    * directory: it generally depends on the lexicographical order of the node
    * names or their creation date.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the appended node and the source is the current node. The called
    * operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param node A reference to the node to be appended.
    * @return A reference to the effectivelly appended node. This reference may
    *         differ from the input one.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference.This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested append for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbNode appendChild(final DrbNode node) throws NullPointerException,
         UnsupportedOperationException
   {
      throw new UnsupportedOperationException(
            "DrbAbstractNode.appendChild(): This operation is not supported.");

   } // appendChild

   /**
    * Replaces a child of the current node. This operation replaces a child in
    * the current children list by a new one The operation aborts when the index
    * is out of bound (index < 0 || index > size). In case of error, the
    * implementation has to restore the initial situation. It is therefore
    * recommended for any implementation to check the consistency prior to
    * perform the replacement.
    * <p>
    * <b>Warning:</b> The replacing node may be duplicated or re-instanciated
    * according to the targetted implementation.A reference to the effectively
    * replacing node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned one.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to insert a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the new node and the source is the current node.The called operation is
    * the structureChanged() structureChanged() of the listeners.
    * </p>
    * 
    * @param index Index of the node to be replaced. This index starts at 0 and
    *           shall be less than the number of children.
    * @param new_node A reference to the node that replaces the old one.
    * @return A reference to the effectivelly replacing node. This reference may
    *         differ from the new_node parameter.
    * @throws NullPointerException This exception is raised when the reference
    *            to the new node is null. This exception may be overriden by a
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested replace for any
    *            reason. In addition if the old_node is not retreived in the
    *            current children list, this exception is also raised.
    */
   public DrbNode replaceChild(final int index, final DrbNode new_node)
         throws NullPointerException, IndexOutOfBoundsException,
         UnsupportedOperationException
   {
      throw new UnsupportedOperationException(
            "DrbAbstractNode.replaceChild(): This operation is not supported.");
   }

   /**
    * Removes an existing child. The child at the given index is removed from
    * the children list of the current node. The child is not modified by this
    * operation. At the child point of view it keeps the same parent or any
    * common association depending on the implementation. However at the parent
    * (i.e. the current node) point of view the removed node is completely
    * dismissed and will never be re-instaciated from constructor operations
    * (e.g. getFirstChild(), etc. ). The index of the child to be removed has to
    * correspond to an existing children index. If the index is less than zero
    * or greater or equal to the current number of children, an exception is
    * thrown.
    * <p>
    * This operation takes into account the removal by updating the sibling
    * associations of the children nodes prior and next to the removed one. The
    * indicies of the nodes next to the removed one are decresed of one. Their
    * parents as well as their contents are left unchanged.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the removed node and the source is the current node. The called
    * operation is the nodesRemoved() of the listeners.
    * </p>
    * 
    * @param index Index of the child to be removed.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested removal for any
    *            reason.
    */
   public void removeChild(final int index) throws IndexOutOfBoundsException,
         UnsupportedOperationException
   {
      throw new UnsupportedOperationException(
            "DrbAbstractNode.removeChild(): This operation is not supported.");
   }

   /**
    * Append a child reference at the end of the children list. The passed node
    * is inserted in the list of children at the end of the current list.
    * <p>
    * <b>Case of unordered or specifically ordered implementations:</b> If the
    * implementation does not support ordered children or has specific ordering
    * rules, the node may not be appended but only inserted according to these
    * rules. For instance it may not be possible to impose the file order in a
    * directory: it generally depends on the lexicographical order of the node
    * names or their creation date.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the appended node and the source is the current node. The called
    * operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param node A reference a node.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference.This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested append for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    * @return nothing
    */
   public DrbNode appendReference(final DrbNode node)
         throws NullPointerException, UnsupportedOperationException
   {
      throw new UnsupportedOperationException(
            "DrbAbstractNode.appendReference(): This operation is not supported.");
   } // adoptChild

   /**
    * Returns the node as a string. This operation only prints the node name.
    * 
    * @return The string descibing the current node.
    */
   public String toString()
   {

      String outputString;

      if (this.getValue() != null)
      {
         outputString = "<" + this.getName() + ">";
         outputString = outputString + "   " + this.getValue();
         outputString = outputString + "</" + this.getName() + ">\n";
      }
      else
      {
         outputString = "<" + this.getName() + "/>";
      }

      return outputString;
   }
} // DrbAbstractNode
