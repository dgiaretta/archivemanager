/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

import fr.gael.drb.DrbSequence;

/**
 * Generic array value wrapper.
 */
public interface ValueArray extends Value // , Logic
      , DrbSequence
{
   /**
    * The type of the values embedded in the array.
    * 
    * @return an identifier of the element type.
    */
   int getArrayType();

   /**
    * Get the element located at the specified index.
    * ArrayIndexOutOfBoundException is thrown if the index is out of bound.
    * 
    * @param index position where to retrieve the value.
    * @return The element located at the index.
    */
   Value getElement(int index);

   /**
    * Replace the element at the specified position in the array with the
    * specified element.
    * 
    * @param index index of element to replace.
    * @param element element to be stored at the specified position.
    */
   void assign(int index, Value element);

   /**
    * Returns the number of elements in this array.
    * 
    * @return the number of elements in this array.
    */
   int length();
} // ValueArray
