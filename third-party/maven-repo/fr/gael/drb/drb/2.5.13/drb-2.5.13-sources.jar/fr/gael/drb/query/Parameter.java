/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.value.Value;

/**
 * A parameter to be or already resolved. This class identifies a parameter that
 * as to be resolved in query. The parameter is identified by a string which is
 * basicaly the name of the value it should bind. The type of the parameter is
 * specified by an integer matching exactly the types defined by the
 * fr.gael.drb.value package. If the parameter is not resolved, the default
 * value, if provided is used instead.
 */
public class Parameter
{

   /**
    * Identifier of the parameter. This string shall univocally identifies the
    * parmeter and shall never be null.
    */
   private String name;

   /**
    * Type of the parameter. The type is identified by an integer matching
    * exactly thedesired type defined in the gael.db.value package.
    */
   private int type;

   /**
    * Default value of the parameter. The default value is not mandatory.
    */
   private Value defaultValue;

   /**
    * Value of the parameter. The value is null until the parameter has been
    * resolved.
    */
   private Value value;

   /**
    * Builds a parameter class
    * 
    * @param name name of the parameter.
    * @param type type of the parameter.
    * @param default_value value of the parameter (may be null).
    */
   public Parameter(final String name, final int type, final Value default_value)
   {
      this.setName(name);
      this.setType(type);
      this.setDefaultValue(default_value);
   }

   /**
    * Set the parameter name.
    * 
    * @param name the name to be considered ofr the parameter.
    */
   protected void setName(final String name)
   {
      this.name = name;
   }

   /**
    * Returns the parameter name.
    * 
    * @return the paremeter name.
    */
   public String getName()
   {
      // TODO: the string shall be controlled here
      return this.name;
   }

   /**
    * Set the parameter type.
    * 
    * @param type the type of the parameter.
    */
   protected void setType(final int type)
   {
      // TODO: The type shall be controlled here.
      this.type = type;
   }

   /**
    * Returns the type of the parameter. The type matches extacly the types
    * defined in the fr.gael.drb.value package.
    * 
    * @return the parameter type.
    */
   public int getType()
   {
      return this.type;
   }

   /**
    * Set the default value of the parameter.
    * 
    * @param value the default value (may be null).
    */
   protected void setDefaultValue(final Value value)
   {
      this.defaultValue = value;
   }

   /**
    * Returns the default value of the parameter. The default value may be null.
    * 
    * @return default value fror this parameter.
    */
   public Value getDefaultValue()
   {
      return this.defaultValue;
   }

   /**
    * Set the value of the parameter. This operation resolves the parameter
    * value.
    * 
    * @param value the value resolving the parameter. It shall never be null.
    */
   public void setValue(final Value value)
   {
      /**
       * Checks the value is not null.
       */
      if (value == null)
      {
         throw new NullPointerException("The value shall never be null");
      }

      /**
       * Set the input value.
       */
      this.value = value;
   }

   /**
    * Returns the value of the parameter. The value may be null, meaning the
    * parameter has not already been solved. It shall be considered has solved
    * otherwise.
    * 
    * @return the value of the resolved parameter.
    */
   public Value getValue()
   {
      return this.value;
   }

   /**
    * Prints out a parameter.
    * 
    * @return the explicit attributes and values of the parameters.
    */
   public String toString()
   {
      return "Parameter \"" + this.name + "\" type=" + this.type
            + " default=\"" + this.defaultValue + "\"";
   }
}
