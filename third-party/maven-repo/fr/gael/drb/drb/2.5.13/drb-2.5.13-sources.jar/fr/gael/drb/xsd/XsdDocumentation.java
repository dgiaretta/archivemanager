/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbDefaultMutableNode;
import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbSequence;

/**
 * Declaration of an XML-Schema documentation.
 */
public class XsdDocumentation
{

   // =====================================================
   // Static part.
   // =====================================================
   /**
    * documentation tag name.
    */
   final static String TAG = "documentation";

   /**
    * Content of this documentation.
    */
   DrbSequence content;

   /**
    * Lang of this annotation.
    */
   String lang = "en";

   // ====================================================
   // Methods part.
   // ====================================================
   /**
    * Build a documentation.
    * 
    * @param item the item
    */
   public XsdDocumentation(final DrbItem item)
   {
      this.content = new DrbDefaultSequence(item);
   } // XsdDocumenation

   /**
    * Build a documentation.
    * 
    * @param content the nodes
    */
   public XsdDocumentation(final DrbSequence content)
   {
      this.content = content;
   } // XsdAppinfo

   /**
    * Lang of this documentation.
    * 
    * @return The language
    */
   public String getLang()
   {
      return this.lang;
   } // getLang

   /**
    * Content of this annotation.
    * 
    * @return content
    */
   public DrbSequence getContent()
   {
      return this.content;
   } // getContent

   /**
    * Format this component into a node.
    * 
    * @return the node
    */
   DrbNode toNode()
   {
      if ((this.content == null) || (this.content.getLength() == 0))
      {
         return null;
      }
      final DrbNode docNode = new DrbDefaultMutableNode(this.TAG);
      docNode.setNamespaceURI(Namespace.XML_SCHEMA_NAMESPACE);
      for (int i = 0; i < this.content.getLength(); i++)
      {
         if (this.content.getItem(i).getItemType() == DrbNode.VALUE_ITEM)
         {
            docNode.setValue(this.content.getItem(i).getValue());
         }
         else if (this.content.getItem(i).getItemType() == DrbNode.NODE_ITEM)
         {
            docNode.appendChild((DrbNode) this.content.getItem(i));
         }
      }
      return docNode;
   }
} // XsdDocumentation
