/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.Vector;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbFactory;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.impl.xml.XmlWriter;
import fr.gael.drb.value.AbstractNumericArray;
import fr.gael.drb.value.Arithmetic;
import fr.gael.drb.value.Comparison;
import fr.gael.drb.value.DateTime;
import fr.gael.drb.value.Decimal;
import fr.gael.drb.value.Double;
import fr.gael.drb.value.Float;
import fr.gael.drb.value.Int;
import fr.gael.drb.value.Integer;
import fr.gael.drb.value.Logic;
import fr.gael.drb.value.Numeric;
import fr.gael.drb.value.Value;
import fr.gael.drb.value.ValueArray;
import fr.gael.drb.xsd.Namespace;
import fr.gael.drb.xsd.XmlSchema;
import fr.gael.drb.xsd.XsdElement;
import fr.gael.drb.xsd.XsdFactory;
import fr.gael.drb.xsd.XsdNode;
import fr.gael.drb.xsd.XsdNodeImpl;
import fr.gael.drb.xsd.XsdSimpleType;
import fr.gael.drb.xsd.XsdType;

/**
 * Wraps a function call expression of the XQuery language.
 */
class FunctionCallExpression extends AbstractExpression
{
   /**
    * Logger
    */
   private Logger logger = Logger.getLogger(FunctionCallExpression.class);

   /**
    * Qualified name of the function.
    */
   private QName functionName;

   /**
    * Function parameters.
    */
   private Vector<Expression> parameters = new Vector<Expression>();

   /**
    * Absolute value function identifier of math module.
    */
   private final int MATH_FUNCTION_ABS = 1;

   /**
    * Square root function identifier of math module.
    */

   private final int MATH_FUNCTION_SQRT = 2;

   /**
    * Power function identifier of math module.
    */
   private final int MATH_FUNCTION_POWER = 3;

   /**
    * Logarithmic function identifier of the math module.
    */
   private final int MATH_FUNCTION_LOG = 4;

   /**
    * Random function identifier of the math module.
    */
   private final int MATH_FUNCTION_RANDOM = 5;

   /**
    * Sine function identifier of the math module.
    */
   private final int MATH_FUNCTION_SIN = 6;

   /**
    * Cosine function identifier of the math module.
    */
   private final int MATH_FUNCTION_COS = 7;

   /**
    * Tangeant function identifier of the math module.
    */
   private final int MATH_FUNCTION_TAN = 8;

   /**
    * Inverse sine function identifier of the math module.
    */
   private final int MATH_FUNCTION_ASIN = 9;

   /**
    * Inverse cosine function identifier of the math module.
    */
   private final int MATH_FUNCTION_ACOS = 10;

   /**
    * Inverse tangent function identifier of the math module.
    */
   private final int MATH_FUNCTION_ATAN = 11;

   /**
    * Inverse tangent two parameters function identifier of the math module.
    */
   private final int MATH_FUNCTION_ATAN2 = 12;

   /**
    * Exponential function identifier of the math module.
    */
   private final int MATH_FUNCTION_EXP = 13;

   /**
    * Standard schema types.
    */
   XmlSchema defaultSchema = null;

   /**
    * True if a replace() pattern matching zero-length string warning message
    * has already been printed: false otherwise. The warning message deals with
    * current type error tolerance observed for backward compatibility purpose.
    */
   private static boolean isZeroLengthMatchingWarningPrinted = false;

   /**
    * Builds a function call expression.
    * 
    * @param token the token related to the expression.
    * @param name string form of the sualified name of the function.
    */
   public FunctionCallExpression(final Token token, final String name)
   {
      super("Function call", token);
      this.functionName = new QName(name);
   }

   /**
    * Builds a function call expression.
    * 
    * @param token the token related to the expression.
    * @param name string form of the sualified name of the function.
    */
   public FunctionCallExpression(final Token token, final QName name)
   {
      super("Function call", token);
      this.functionName = new QName(name.getName(), name.getNamespaceURI());
   }

   /**
    * Add a parameter to the function call.
    * 
    * @param expression the expression to bind as parameter.
    */
   public void addParameter(final Expression expression)
   {
      this.parameters.add(expression);
   }

   /**
    * Evaluates the function. This operations detects the correct operation
    * according to its name. If the opreation is not found in the list of
    * built-in functions, the in-scope function is evaluated.
    * 
    * @param context the dynamic onctext providing the in-scope functions.
    * @return the sequence in output of the called function.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {
      /**
       * Built-in functions.
       */
      if (Environment.XPATH_FUNCTIONS_URI.equals (
         this.functionName.getNamespaceURI())        )
      {
         if (this.functionName.getLocalName().equals("count"))
         {
            return this.count(context);
         }
         else if (this.functionName.getLocalName().equals("position"))
         {
            return this.position(context);
         }
         else if (this.functionName.getLocalName().equals("last"))
         {
            return this.last(context);
         }
         else if (this.functionName.getLocalName().equals("name"))
         {
            return this.name(context);
         }
         else if (this.functionName.getLocalName().equals("namespace-uri"))
         {
            return this.namespaceURI(context);
         }
         else if (this.functionName.getLocalName().equals("node-name"))
         {
            return this.nodeName(context);
         }
         else if (this.functionName.getLocalName().equals("data"))
         {
            return this.data(context);
         }
         else if (this.functionName.getLocalName().equals("true"))
         {
            return this.trueBoolean(context);
         }
         else if (this.functionName.getLocalName().equals("false"))
         {
            return this.falseBoolean(context);
         }
         else if (this.functionName.getLocalName().equals("not"))
         {
            return this.not(context);
         }
         else if (this.functionName.getLocalName().equals("avg"))
         {
            return this.avg(context);
         }
         else if (this.functionName.getLocalName().equals("sum"))
         {
            return this.sum(context);
         }
         else if (this.functionName.getLocalName().equals("min"))
         {
            return this.min(context);
         }
         else if (this.functionName.getLocalName().equals("max"))
         {
            return this.max(context);
         }
         else if (this.functionName.getLocalName().equals("ceiling"))
         {
            return this.ceiling(context);
         }
         else if (this.functionName.getLocalName().equals("floor"))
         {
            return this.floor(context);
         }
         else if (this.functionName.getLocalName().equals("round"))
         {
            return this.round(context);
         }
         else if (this.functionName.getLocalName().equals("doc"))
         {
            return this.doc(context);
         }
         else if (this.functionName.getLocalName().equals("empty"))
         {
            return this.empty(context);
         }
         else if (this.functionName.getLocalName().equals("exists"))
         {
            return this.exists(context);
         }
         else if (this.functionName.getLocalName().equals("concat"))
         {
            return this.concat(context);
         }
         else if (this.functionName.getLocalName().equals("substring"))
         {
            return this.substring(context);
         }
         else if (this.functionName.getLocalName().equals("compare"))
         {
            return this.compare(context);
         }
         else if (this.functionName.getLocalName().equals("substring-before"))
         {
            return this.substringBeforeOrAfter(context, BEFORE);
         }
         else if (this.functionName.getLocalName().equals("substring-after"))
         {
            return this.substringBeforeOrAfter(context, AFTER);
         }
         else if (this.functionName.getLocalName().equals("string-length"))
         {
            return this.stringLength(context);
         }
         else if (this.functionName.getLocalName().equals("string-join"))
         {
            return this.stringJoin(context);
         }
         else if (this.functionName.getLocalName().equals("matches"))
         {
            return this.matches(context);
         }
         else if (this.functionName.getLocalName().equals("tokenize"))
         {
            return this.tokenize(context);
         }
         else if (this.functionName.getLocalName().equals("replace"))
         {
            return this.replace(context);
         }
         else if (this.functionName.getLocalName().equals("current-dateTime"))
         {
            return this.currentDateTime(context);
         }
         else if (this.functionName.getLocalName().equals("error"))
         {
            return this.error(context);
         }
         else if (this.functionName.getLocalName().equals("trace"))
         {
            return this.trace(context);
         }
         else if (this.functionName.getLocalName().equals("abs"))
         {
            return this.mathFunction(context, MATH_FUNCTION_ABS);
         }
         else if (this.functionName.getLocalName().equals("index"))
         {
            this.logger
               .warn("Built-in function index() is deprecated and "
                     + "should be replaced by the drb:index(). This deprecation "
                     + "has been performed to seggregate the standard function from the "
                     + "ones provided by the DRB API. The arity and functionality remain "
                     + "however, unchanged.");
         }
         else if (this.functionName.getLocalName().equals("evaluate-uri"))
         {
            this.logger
               .warn("Built-in function evaluate-uri() is deprecated and "
                     + "should be replaced by the drb:evaluate-uri(). This deprecation "
                     + "has been performed to seggregate the standard function from the "
                     + "ones provided by the DRB API. The arity and functionality remain "
                     + "however, unchanged.");
            return this.evaluateURI(context);
         }
         else if (this.functionName.getLocalName().equals("evaluate-string"))
         {
            this.logger
               .warn("Built-in function evaluate-string() is deprecated and "
                     + "should be replaced by the drb:evaluate-string(). This deprecation "
                     + "has been performed to seggregate the standard function from the "
                     + "ones provided by the DRB API. The arity and functionality remain "
                     + "however, unchanged.");
            return this.evaluateString(context);
         }
         else if (this.functionName.getLocalName().equals("deep-invalid"))
         {
            this.logger
               .warn("Built-in function deep-invalid() is deprecated and "
                     + "should be replaced by the drb:deep-invalid(). This deprecation "
                     + "has been performed to seggregate the standard function from the "
                     + "ones provided by the DRB API. The arity and functionality remain "
                     + "however, unchanged.");
            return this.deepInvalid(context);
         }
      } // fn functions
      else if (Namespace.XML_SCHEMA_NAMESPACE.equals (
         this.functionName.getNamespaceURI()))
      {
         return this.atomicTypeConstructor(context);
      }
      else if (Environment.DRB_FUNCTIONS_URI.equals (
         this.functionName.getNamespaceURI()))
      {
         if (this.functionName.getLocalName().equals("evaluate-string"))
         {
            return this.evaluateString(context);
         }
         else if (this.functionName.getLocalName().matches("xml-string"))
         {
            return this.xmlString(context);
         }
         else if (this.functionName.getLocalName().equals("deep-invalid"))
         {
            return this.deepInvalid(context);
         }
         else if (this.functionName.getLocalName().equals("import-doc"))
         {
            return this.importDoc(context);
         }
         else if (this.functionName.getLocalName().equals("evaluate-uri"))
         {
            return this.evaluateURI(context);
         }
         else if (this.functionName.getLocalName().matches("xml-doc"))
         {
            return this.xmlDoc(context);
         }
         else if (this.functionName.getLocalName().matches("insertInto"))
         {
            return this.insertInto(context);
         }
         else if (this.functionName.getLocalName().equals("index"))
         {
            return this.index(context);
         }
         else if (this.functionName.getLocalName().equals("path"))
         {
            return this.path(context);
         }
         else if (this.functionName.getLocalName().equals("Iso8601DateFormatter"))
         {
            return this.iso8601DateFormatter (context);
         }
         
      } // drb functions
      else if (Environment.MATH_FUNCTIONS_URI.equals (
         this.functionName.getNamespaceURI()))
      {
         if (this.functionName.getLocalName().equals("abs"))
         {
            return this.mathFunction(context, this.MATH_FUNCTION_ABS);
         }
         else if (this.functionName.getLocalName().equals("sqrt"))
         {
            return this.mathFunction(context, this.MATH_FUNCTION_SQRT);
         }
         else if (this.functionName.getLocalName().equals("power"))
         {
            return this.mathFunction(context, this.MATH_FUNCTION_POWER);
         }
         else if (this.functionName.getLocalName().equals("log"))
         {
            return this.mathFunction(context, this.MATH_FUNCTION_LOG);
         }
         else if (this.functionName.getLocalName().equals("random"))
         {
            return this.mathFunction(context, this.MATH_FUNCTION_RANDOM);
         }
         else if (this.functionName.getLocalName().equals("sin"))
         {
            return this.mathFunction(context, this.MATH_FUNCTION_SIN);
         }
         else if (this.functionName.getLocalName().equals("cos"))
         {
            return this.mathFunction(context, this.MATH_FUNCTION_COS);
         }
         else if (this.functionName.getLocalName().equals("tan"))
         {
            return this.mathFunction(context, this.MATH_FUNCTION_TAN);
         }
         else if (this.functionName.getLocalName().equals("asin"))
         {
            return this.mathFunction(context, this.MATH_FUNCTION_ASIN);
         }
         else if (this.functionName.getLocalName().equals("acos"))
         {
            return this.mathFunction(context, this.MATH_FUNCTION_ACOS);
         }
         else if (this.functionName.getLocalName().equals("atan"))
         {
            return this.mathFunction(context, this.MATH_FUNCTION_ATAN);
         }
         else if (this.functionName.getLocalName().equals("atan2"))
         {
            return this.mathFunction(context, this.MATH_FUNCTION_ATAN2);
         }
         else if (this.functionName.getLocalName().equals("exp"))
         {
            return this.mathFunction(context, this.MATH_FUNCTION_EXP);
            /*
             * else if (functionName.getName().equals("math:constant")) return
             * mathConstant(context); else if
             * (functionName.getName().equals("math:stdev")) return
             * stdev(context);
             */
         }
      } // math functions
      else if (this.functionName.getName().matches("esa:utc-to-mjd"))
      {
         return this.utcToMjd(context);
      }
      else if (this.functionName.getName().matches("gael:utc-to-mjd"))
      {
         this.logger
            .warn("Built-in function gael:utc-to-mjd() is deprecated and "
                  + "should be replaced by the esa:utc-to-mjd().");
         return this.utcToMjd(context);
      }

      /**
       * In-scope function of the context.
       */
      // TODO: the selection of the in-scope function shall not be based on the
      // function name only, but also on the complete signature, including the
      // parameter sequence types.
      final Function function = context.getInScopeFunction(this.functionName);

      if (function != null)
      {
         /**
          * Evaluate the parameters values.
          */
         final List<DrbSequence> values = new Vector<DrbSequence>();
         for (final Expression param_expr : this.parameters)
         {
            values.add(param_expr.evaluate(context));
         }
         return function.evaluate(context, values);
      }
      else if ((this.functionName.getNamespaceURI() != null)
            && this.functionName.getNamespaceURI().startsWith("java:"))
      {
         return javaFunction(context);
      }

      /**
       * Case of non-matching function call.
       */
      throw new DynamicException(this, "XP0017 - Function call "
            + this.functionName.getName()
            + "() does not match the name and arity of any built-in function");
   }

   /**
    * External Java functions.
    * 
    * @param context the dynamic context to consider.
    * @return the result of the function if any or an empty sequence.
    */
   private DrbSequence javaFunction(final DynamicContext context)
   {
      String nsuri = this.functionName.getNamespaceURI();
      String className = nsuri.replace("java:", "");
      String methodName = this.functionName.getLocalName();
      try
      {
         Class<?> java_class = Class.forName(className);
         Method[] java_methods = java_class.getMethods();
         Method match_method = null;
         int match_count = 0;
         for (Method method : java_methods)
         {
            if (method.getName().equals(methodName))
            {
               Class<?>[] param_types = method.getParameterTypes();
               if (method.isVarArgs()
                     || param_types.length == this.parameters.size())
               {
                  match_count++;
                  match_method = method;
               }
            }
         }

         if (match_count > 1)
         {
            logger.warn("Found " + match_count + " java functions matching "
                  + functionName);
         }

         if (match_method != null)
         {
            return javaFunction(context, match_method);
         }
      }
      catch (ClassNotFoundException e)
      {
         throw new DynamicException(this, "XP0017 - Function call "
               + this.functionName.getName()
               + "() does not match any java class");
      }
      throw new DynamicException(this, "XP0017 - Function call "
            + this.functionName.getName()
            + "() does not match the name and arity of any method in class "
            + className);
   }

   /**
    * External Java functions.
    * 
    * @param context the dynamic context to consider.
    * @return the result of the function if any or an empty sequence.
    */
   private DrbSequence javaFunction(final DynamicContext context,
      final Method method)
   {
      Class<?>[] arg_classes = method.getParameterTypes();
      Object[] args = new Object[this.parameters.size()];

      // Set parameters
      for (int i = 0; i < this.parameters.size(); i++)
      {
         /**
          * Get the current parameter.
          */
         final Expression expr = (Expression) this.parameters.get(i);

         if (expr == null)
         {
            throw new DynamicException(this, this.functionName
                  + "(): error while " + "evaluating the parameter " + (i + 1));
         }

         final DrbSequence param_sequence = expr.evaluate(context);

         if ((param_sequence == null) || (param_sequence.getLength() > 1))
         {
            throw new DynamicException(this, this.functionName
                  + "(): error while " + "evaluating the parameter " + (i + 1));
         }

         // Case of empty sequence
         if (param_sequence.getLength() == 0)
         {
            continue;
         }

         final Value value = param_sequence.getItem(0).getValue();
         if (fr.gael.drb.value.Value.class.isAssignableFrom(arg_classes[i]))
         {
            args[i] = value;
         }
         else
         {
            args[i] = toJava(value);
         }
      }

      try
      {
         DrbItem value = fromJava(method.invoke(null, args));
         if (value == null)
         {
            return new DrbDefaultSequence();
         }
         else
         {
            return new DrbDefaultSequence(value);
         }
      }
      catch (IllegalAccessException e)
      {
         throw new DynamicException(this, this.functionName + "(): "
               + e.getMessage());
      }
      catch (InvocationTargetException e)
      {
         throw new DynamicException(this, this.functionName + "(): "
               + e.getMessage());
      }
      catch (RuntimeException e)
      {
         throw new DynamicException(this, this.functionName + "(): "
               + e.getMessage());
      }
   }

   private static DrbItem fromJava(final Object obj)
   {
      if (obj == null)
      {
         return null;
      }

      if (obj instanceof DrbItem)
      {
         return (DrbItem) obj;
      }

      if (obj instanceof java.lang.Integer)
      {
         return new fr.gael.drb.value.Int(((Number) obj).intValue());
      }
      if (obj instanceof java.lang.Float)
      {
         return new fr.gael.drb.value.Float(((Number) obj).floatValue());
      }
      if (obj instanceof java.lang.Double)
      {
         return new fr.gael.drb.value.Double(((Number) obj).doubleValue());
      }
      if (obj instanceof java.lang.String)
      {
         return new fr.gael.drb.value.String(obj.toString());
      }
      if (obj instanceof java.lang.Boolean)
      {
         return new fr.gael.drb.value.Boolean(((java.lang.Boolean) obj)
            .booleanValue());
      }
      if (obj instanceof fr.gael.drb.value.Value)
      {
         return (Value) obj;
      }
      if (obj instanceof java.lang.Short)
      {
         return new fr.gael.drb.value.Short(((Number) obj).shortValue());
      }
      if (obj instanceof java.lang.Byte)
      {
         return new fr.gael.drb.value.Byte(((Number) obj).byteValue());
      }
      if (obj instanceof java.lang.Long)
      {
         return new fr.gael.drb.value.Long(((Number) obj).longValue());
      }
      if (obj instanceof java.math.BigInteger)
      {
         return new fr.gael.drb.value.Integer((BigInteger) obj);
      }
      if (obj instanceof java.math.BigDecimal)
      {
         return new fr.gael.drb.value.Decimal(obj.toString());
      }
      if (obj instanceof java.util.Date)
      {
         return new fr.gael.drb.value.DateTime(obj.toString());
      }
      if (obj instanceof int[])
      {
         return new fr.gael.drb.value.IntArray((int[]) obj);
      }
      if (obj instanceof float[])
      {
         return new fr.gael.drb.value.FloatArray((float[]) obj);
      }
      if (obj instanceof double[])
      {
         return new fr.gael.drb.value.DoubleArray((double[]) obj);
      }
      if (obj instanceof short[])
      {
         return new fr.gael.drb.value.ShortArray((short[]) obj);
      }
      if (obj instanceof byte[])
      {
         return new fr.gael.drb.value.ByteArray((byte[]) obj);
      }
      if (obj instanceof long[])
      {
         return new fr.gael.drb.value.LongArray((long[]) obj);
      }
      throw new UnsupportedOperationException("Unsupported value class  "
            + obj.getClass().getName());
   }

   private static Object toJava(final Value value)
   {
      // case of null value
      if (value == null)
      {
         return null;
      }

      if (value.getType() == Value.ARRAY_ID)
      {
         ValueArray array = (ValueArray) value;
         switch (array.getArrayType())
         {
            case Value.INT_ID:
            case Value.UNSIGNED_INT_ID:
               return ((AbstractNumericArray) array).intValues();
            case Value.DOUBLE_ID:
               return ((AbstractNumericArray) array).doubleValues();
            case Value.FLOAT_ID:
               return ((AbstractNumericArray) array).floatValues();
            case Value.BOOLEAN_ID:
               return ((AbstractNumericArray) array).booleanValues();
            case Value.LONG_ID:
            case Value.UNSIGNED_LONG_ID:
               return ((AbstractNumericArray) array).longValues();
            case Value.SHORT_ID:
            case Value.UNSIGNED_SHORT_ID:
               return ((AbstractNumericArray) array).shortValues();
            case Value.BYTE_ID:
            case Value.UNSIGNED_BYTE_ID:
               return ((AbstractNumericArray) array).byteValues();
         }
      }
      else
      {
         switch (value.getType())
         {
            case Value.INT_ID:
            case Value.UNSIGNED_SHORT_ID:
               return new java.lang.Integer(((Numeric) value).intValue());
            case Value.DOUBLE_ID:
               return new java.lang.Double(((Numeric) value).doubleValue());
            case Value.FLOAT_ID:
               return new java.lang.Float(((Numeric) value).floatValue());
            case Value.BOOLEAN_ID:
               return new java.lang.Boolean(((Logic) value).booleanValue());
            case Value.STRING_ID:
               return new java.lang.String(value.toString());
            case Value.LONG_ID:
            case Value.UNSIGNED_INT_ID:
               return new java.lang.Long(((Numeric) value).longValue());
            case Value.SHORT_ID:
            case Value.UNSIGNED_BYTE_ID:
               return new java.lang.Short(((Numeric) value).shortValue());
            case Value.BYTE_ID:
               return new java.lang.Byte(((Numeric) value).byteValue());
            case Value.INTEGER_ID:
            case Value.UNSIGNED_LONG_ID:
               return new java.math.BigInteger(value.toString());
            case Value.DECIMAL_ID:
               return new java.math.BigDecimal(value.toString());
            case Value.DATE_TIME_ID:
               return new java.sql.Timestamp(((DateTime) value).getTime());
         }
      }

      throw new UnsupportedOperationException("Unsupported value type "
            + value.getType());
   }

   /**
    * Returns -1, 0, or 1, depending on whether the first argument is
    * respectively less than, equal to, or greater than the second argument. If
    * either argument is the empty sequence, the result is the empty sequence.
    * 
    * @param context used to evaluate the parameters.
    * @return the replaced string or null is an error occurred.
    */
   private DrbSequence compare(final DynamicContext context)
   {
      /**
       * Check the input parameter number.
       */
      if (this.parameters.size() != 2)
      {
         throw new DynamicException(this, this.functionName + "() "
               + "requires two parameters");
      }

      /**
       * Get the source string from parameter. This parameter is mandatory and
       * shall be evaluable as an item convertible univocally in string.
       */
      final Expression first_string_expr = (Expression) this.parameters.get(0);

      if (first_string_expr == null)
      {
         throw new DynamicException(this, this.functionName + "(): error while "
               + "evaluating the first string parameter");
      }

      final DrbSequence first_string_sequence =
         first_string_expr.evaluate(context);

      if ((first_string_sequence == null)
            || (first_string_sequence.getLength() > 1))
      {
         throw new DynamicException(this, this.functionName + "(): error while "
               + "evaluating the first string parameter");
      }

      final DrbItem first_string_item = first_string_sequence.getItem(0);

      if (first_string_item == null)
      {
         return new DrbDefaultSequence();
      }

      final Value first_string_value = first_string_item.getValue();

      if (first_string_value == null)
      {
         return new DrbDefaultSequence();
      }

      if (first_string_value.getType() != fr.gael.drb.value.Value.STRING_ID)
      {
         throw new TypeException(this, this.functionName + "(): "
               + "the first parameter is not a string");
      }

      String first_string = first_string_value.toString();

      if (first_string == null)
      {
         first_string = "";
      }

      /**
       * Get the second string from parameter. This parameter is mandatory and
       * shall be evaluable as an item convertible univocally in string.
       */
      final Expression second_string_expr = (Expression) this.parameters.get(1);

      if (second_string_expr == null)
      {
         throw new DynamicException(this, this.functionName
               + "() operation requires a string in second parameter");
      }

      final DrbSequence second_string_sequence =
         second_string_expr.evaluate(context);

      if (second_string_sequence == null)

      {
         throw new DynamicException(this, this.functionName
               + "(): error while evaluating the second parameter");
      }
      if (second_string_sequence.getLength() > 1)

      {
         throw new DynamicException(this, this.functionName
               + "(): the second parameter cannot contains more than 1 item");
      }

      final DrbItem second_string_item = second_string_sequence.getItem(0);

      if (second_string_item == null)
      {
         return new DrbDefaultSequence();
      }

      final Value second_string_value = second_string_item.getValue();

      if (second_string_value == null)
      {
         return new DrbDefaultSequence();
      }

      if (second_string_value.getType() != fr.gael.drb.value.Value.STRING_ID)
      {
         throw new TypeException(this, this.functionName
               + "(): the second parameter is not a string");
      }

      String second_string = second_string_value.toString();

      if (second_string == null)
      {
         second_string = "";
      }

      /**
       * Returns the evaluation.
       */
      return (new DrbDefaultSequence(new fr.gael.drb.value.Int(first_string
         .compareTo(second_string))));
   } /* compare */

   /**
    * Replaces each non-overlapping sub-strings matching a regexp. The
    * parameters of the functions are : $source as xs:string $pattern as
    * xs:string $replacement as xs:string and returns a xs:string
    * 
    * @param context used to evaluate the parameters.
    * @return the replaced string or null is an error occurred.
    */
   private DrbSequence replace(final DynamicContext context)
   {
      /**
       * Check the input parameter number.
       */
      if (this.parameters.size() != 3)
      {
         throw new DynamicException(this, this.functionName + "() "
               + "requires three parameters");
      }

      /**
       * Get the source string from parameter. This parameter is mandatory and
       * shall be evaluable as an item convertible univocally in string.
       */
      final Expression source_string_expr = (Expression) this.parameters.get(0);

      if (source_string_expr == null)
      {
         throw new DynamicException(this, this.functionName + "(): error while "
               + "evaluating the source string parameter");
      }

      final DrbSequence source_string_sequence =
         source_string_expr.evaluate(context);

      if ((source_string_sequence == null)
            || (source_string_sequence.getLength() > 1))
      {
         throw new DynamicException(this, this.functionName + "(): error while "
               + "evaluating the source string parameter");
      }

      String source_string = "";

      final DrbItem source_string_item = source_string_sequence.getItem(0);

      if (source_string_item != null)
      {
         final Value source_string_value = source_string_item.getValue();

         if (source_string_value != null)
         {
            if (source_string_value.getType() != fr.gael.drb.value.Value.STRING_ID)
            {
               throw new TypeException(this, this.functionName + "(): "
                     + "the first parameter is not a string");
            }
            source_string = source_string_value.toString();
         }
      }

      /**
       * Get the pattern string from parameter. This parameter is mandatory and
       * shall be evaluable as an item convertible univocally in string.
       */
      final Expression pattern_string_expr = (Expression) this.parameters.get(1);

      if (pattern_string_expr == null)
      {
         throw new DynamicException(
            this,
            this.functionName
                  + "() operation requires a source string as \"pattern\" parameter");
      }

      final DrbSequence pattern_string_sequence =
         pattern_string_expr.evaluate(context);

      if ((pattern_string_sequence == null)
            || (pattern_string_sequence.getLength() != 1))
      {
         throw new DynamicException(this, this.functionName
               + "(): error while evaluating the \"pattern\" parameter");
      }

      final DrbItem pattern_string_item = pattern_string_sequence.getItem(0);
      final Value pattern_string_value = pattern_string_item.getValue();

      if ((pattern_string_value == null)
            || (pattern_string_value.getType() != Value.STRING_ID))
      {
         throw new TypeException(this, this.functionName
               + "(): \"pattern\" parameter is not an xs:string");
      }
      String pattern_string = pattern_string_value.toString();

      // The pattern cannot match the zero-length string
      if ("".matches(pattern_string))
      {
         DynamicException dynamic_exception =
            new DynamicException(this, this.functionName
                  + "(): \"pattern\" parameter equal to \"" + pattern_string
                  + "\" matches the zero-length string");

         if (!context.isBackwardCompatibilityMode())
         {
            throw dynamic_exception;
         }

         logger.error("Dynamic Exception: "
               + dynamic_exception.getMessage());

         if (!FunctionCallExpression.isZeroLengthMatchingWarningPrinted)
         {
            logger.warn("Previous pattern error did not "
                  + "interrupt the evaluation because the backward "
                  + "compatibility mode has been set. This compatibility may "
                  + "be disrupted in any future version so users are strongly "
                  + "invited to update their XQuery scripts to comply the W3C "
                  + "recommendation c.f. "
                  + "http://www.w3.org/TR/2007/REC-xquery-20070123"
                  + " (This message will not be repeated in this session).");

            FunctionCallExpression.isZeroLengthMatchingWarningPrinted = true;
         }
      }

      /**
       * Get the replacement string from parameter. This parameter is mandatory
       * and shall be evaluable as an item convertible univocally in string.
       */
      final Expression replacement_string_expr =
         (Expression) this.parameters.get(2);

      if (replacement_string_expr == null)
      {
         throw new DynamicException(this, this.functionName
               + "() operation requires a \"replacement\" string "
               + "as third parameter");
      }

      final DrbSequence replacement_string_sequence =
         replacement_string_expr.evaluate(context);

      if ((replacement_string_sequence == null)
            || (replacement_string_sequence.getLength() != 1))
      {
         throw new DynamicException(this, this.functionName
               + "(): error while evaluating the \"replacement\" parameter");
      }

      final DrbItem replacement_string_item =
         replacement_string_sequence.getItem(0);
      final Value replacement_string_value = replacement_string_item.getValue();

      if ((replacement_string_value == null)
            || (replacement_string_value.getType() != Value.STRING_ID))
      {
         throw new TypeException(this, this.functionName
               + "(): \"pattern\" parameter is not an xs:string");
      }

      String replacement_string = replacement_string_value.toString();

      /**
       * Returns the evaluation.
       */
      return (new DrbDefaultSequence(new fr.gael.drb.value.String(source_string
         .replaceAll(pattern_string, replacement_string))));
   } /* replace */

   /**
    * Returns a subpart of a string. The parameters of the functions are :
    * $sourceString as xs:string $startingLoc as xs:double $length as xs:double
    * (optional) where the $sourceString is the input string to be subdivided;
    * $startingLoc is the index of the first character of the substring in the
    * $sourceString (index starts at 1); $length is the number of charaters to
    * be kept while extracting the substring. The following rules apply: - If
    * the string is null, null is returned. - If $startingLoc is zero or
    * negative, the substring includes characters from the beginning of the
    * $sourceString. - If $length is not specified, the substring includes
    * characters to the end of $sourceString. - If $length is greater than the
    * number of characters in the value of $sourceString following $startingLoc,
    * the substring includes characters to the end of $sourceString. The first
    * character of a string is located at position 1, not position 0.
    * 
    * @param context used to evaluate the parameters.
    * @return the substring if no error occurred.
    */
   private DrbSequence substring(final DynamicContext context)
   {
      /**
       * Get the source string from parameter. This parameter is mandatory and
       * shall be evaluable as an item convertible univocally in string.
       */
      final Expression source_string_expr = (Expression) this.parameters.get(0);

      if (source_string_expr == null)
      {
         throw new DynamicException(this, this.functionName + "() operation "
               + "requires a source string as first parameter");
      }

      final DrbSequence source_string_sequence =
         source_string_expr.evaluate(context);

      if ((source_string_sequence == null)
            || (source_string_sequence.getLength() > 1))
      {
         throw new DynamicException(this, this.functionName + "(): error while "
               + "evaluating the \"source\" string parameter");
      }

      final DrbItem source_string_item = source_string_sequence.getItem(0);

      if (source_string_item == null)
      {
         return new DrbDefaultSequence();
      }

      final Value source_string_value = source_string_item.getValue();

      if (source_string_value == null)
      {
         return new DrbDefaultSequence();
      }

      if (source_string_value.getType() != fr.gael.drb.value.Value.STRING_ID)
      {
         throw new TypeException(this, this.functionName + "(): "
               + "the first \"source\" parameter is not a string");
      }

      final String source_string = source_string_value.toString();

      if (source_string == null)
      {
         return new DrbDefaultSequence();
      }

      /**
       * Get the start location of the substring in the source string. The
       * location starts at 1 for the first character of the source.
       */
      final Expression starting_loc_expr = (Expression) this.parameters.get(1);

      if (starting_loc_expr == null)
      {
         throw new DynamicException(
            this,
            this.functionName
                  + "() operation "
                  + "requires the \"substring starting location\" as second parameter");
      }

      final DrbSequence starting_loc_sequence =
         starting_loc_expr.evaluate(context);

      if ((starting_loc_sequence == null)
            || (starting_loc_sequence.getLength() != 1))
      {
         throw new DynamicException(this, this.functionName + "(): error while "
               + "evaluating the start location parameter");
      }

      final DrbItem starting_loc_item = starting_loc_sequence.getItem(0);

      if (starting_loc_item == null)
      {
         throw new DynamicException(this, this.functionName
               + "() : Error while " + "evaluating the start location parameter");
      }

      final Value starting_loc_value = starting_loc_item.getValue();

      if (!(starting_loc_value instanceof Numeric))
      {
         throw new DynamicException(this,
            "The second parameter of the function " + this.functionName
                  + "() is not a numeric value");
      }

      final Numeric starting_loc_numeric = (Numeric) starting_loc_value;

      double starting_loc = Math.floor(starting_loc_numeric.doubleValue() - 0.5);

      int begin_index =
         (int) Math.max(0, Math.min(starting_loc, (double) source_string
            .length()));

      /**
       * Get the expected of the substring in the source string. This parameter
       * is optional
       */

      int end_index = source_string.length();
      double end_loc = java.lang.Double.POSITIVE_INFINITY;

      if (this.parameters.size() >= 3)
      {
         final Expression length_expr = (Expression) this.parameters.get(2);

         if (length_expr == null)
         {
            throw new DynamicException(this, this.functionName + "() operation "
                  + "Cannot get the third parameter");
         }

         final DrbSequence length_sequence = length_expr.evaluate(context);

         if ((length_sequence == null) || (length_sequence.getLength() != 1))
         {
            throw new DynamicException(this, this.functionName
                  + "() : Error while " + "evaluating the length parameter");
         }

         final DrbItem length_item = length_sequence.getItem(0);
         final Value length_value = length_item.getValue();

         if (!(length_value instanceof Numeric))
         {
            throw new DynamicException(this, this.functionName + "() : "
                  + "The length parameter (#3) shall be " + "a numerical value");
         }

         final Numeric length_numeric = (Numeric) length_value;
         final double length = Math.floor(length_numeric.doubleValue() + 0.5);
         end_loc =
            Math.min((double) source_string.length(), starting_loc + length);
         if (java.lang.Double.isNaN(end_loc))
         {
            end_index = begin_index;
         }
         else
         {
            end_index = Math.max((int) end_loc, begin_index);
         }
      }

      /**
       * Returns the substring.
       */
      return (new DrbDefaultSequence(new fr.gael.drb.value.String(source_string
         .substring(begin_index, end_index))));
   } /* substring */

   /**
    * Indicates whether the substring is to perform before the search string.
    * Dedicated to substringBeforeOrAfter() operation.
    */
   private static int BEFORE = 0;

   /**
    * Indicates whether the substring is to perform before the search string.
    * Dedicated to substringBeforeOrAfter() operation.
    */
   private static int AFTER = 1;

   /**
    * Returns a subpart of a string preceding anothing string. The parameters of
    * the functions are : $arg1 as xs:string $arg2 as xs:string and returns a
    * xs:string
    * <p>
    * Returns the substring of the value of $arg1 that precedes in the value of
    * $arg1 the first occurrence of a string that is equal to the value of $arg2
    * according to the collation that is used.
    * </p>
    * <p>
    * If the value of $arg1 or $arg2 is the empty sequence, it is interpreted as
    * the zero-length string.
    * </p>
    * <p>
    * If the value of $arg2 is the zero-length string, then the function returns
    * the value of $arg1
    * </p>
    * <p>
    * If the value of $arg1 does not contain a string that is equal to the value
    * of $arg2, then the function returns the zero-length string.
    * </p>
    * <p>
    * <b>Note:</b> the substring-after() is the inverse function.
    * </p>
    * 
    * @param context used to evaluate the parameters.
    * @param direction indicates the direction of cut (i.e. BEFORE/AFTER).
    * @return the substring if no error occurred.
    */
   private DrbSequence substringBeforeOrAfter(final DynamicContext context,
      final int direction)
   {
      /**
       * Check the input parameter number.
       */
      if (this.parameters.size() != 2)
      {
         throw new DynamicException(this, this.functionName + "() operation "
               + "requires two parameters");
      }

      /**
       * Get the source string from parameter. This parameter is mandatory and
       * shall be evaluable as an item convertible univocally in string.
       */
      final Expression source_string_expr = (Expression) this.parameters.get(0);

      if (source_string_expr == null)
      {
         throw new DynamicException(this, this.functionName + "() operation "
               + "requires a source string as first " + "parameter");
      }

      final DrbSequence source_string_sequence =
         source_string_expr.evaluate(context);

      if ((source_string_sequence == null)
            || (source_string_sequence.getLength() > 1))
      {
         throw new DynamicException(this, this.functionName
               + "() : Error while " + "evaluating the source string parameter");
      }

      final DrbItem source_string_item = source_string_sequence.getItem(0);
      String source_string = "";

      if (source_string_item != null)
      {
         final Value source_string_value = source_string_item.getValue();

         if (source_string_value != null)
         {
            if (source_string_value.getType() != fr.gael.drb.value.Value.STRING_ID)
            {
               throw new TypeException(this, this.functionName + "() : "
                     + "The first parameter is not a string");
            }
            source_string = source_string_value.toString();
         }
      }

      /**
       * Get the search string from parameter. This parameter is mandatory and
       * shall be evaluable as an item convertible univocally in string.
       */
      final Expression search_string_expr = (Expression) this.parameters.get(1);

      if (search_string_expr == null)
      {
         throw new DynamicException(this, this.functionName + "() operation "
               + "requires the substring starting "
               + "location as second parameter");
      }

      final DrbSequence starting_loc_sequence =
         search_string_expr.evaluate(context);

      if ((starting_loc_sequence == null)
            || (starting_loc_sequence.getLength() > 1))
      {
         throw new DynamicException(this, this.functionName
               + "() : Error while " + "evaluating the start location parameter");
      }

      String search_string = "";

      final DrbItem search_string_item = starting_loc_sequence.getItem(0);
      if (search_string_item != null)
      {
         final Value search_string_value = search_string_item.getValue();

         if (search_string_value != null)
         {
            if (search_string_value.getType() != fr.gael.drb.value.Value.STRING_ID)
            {
               throw new TypeException(this, this.functionName + "() : "
                     + "The first parameter is not a string");
            }
            search_string = search_string_value.toString();
         }
      }

      if ((search_string == null) || (search_string.length() == 0))
      {
         return new DrbDefaultSequence(new fr.gael.drb.value.String(
            source_string));
      }

      /**
       * Processes the output string.
       */
      final int match_index = source_string.indexOf(search_string);

      if (match_index == -1)
      {
         return new DrbDefaultSequence(new fr.gael.drb.value.String(""));
      }

      String output_string;

      if (direction == BEFORE)
      {
         output_string = source_string.substring(0, match_index);
      }
      else
      {
         output_string =
            source_string.substring(match_index + search_string.length(),
               source_string.length());
      }

      /**
       * Returns the substring.
       */
      return (new DrbDefaultSequence(new fr.gael.drb.value.String(output_string)));
   } /* substring */

   /**
    * Return the number of item of the sequence.
    * 
    * @param context the dynamic context to be considered.
    * @return the singleton holding the number of items.
    */
   private DrbSequence count(final DynamicContext context)
   {
      /**
       * Checks parameters.
       */
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this,
            "XP0017 - fn:count() requires one and only one parameter");
      }

      /**
       * Evaluates the parameter.
       */
      final DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence == null)
      {
         throw new DynamicException(this,
            "Error while evaluating the parameter of count() function");
      }

      /**
       * Returns the number of item contained in the sequence.
       */
      return new DrbDefaultSequence(new fr.gael.drb.value.Int(sequence
         .getLength()));
   }

   /**
    * Returns the context position.
    * 
    * @param context the dynamic context to be considered.
    * @return the singleton holding the number of items.
    */
   private DrbSequence position(final DynamicContext context)
   {
      if (this.parameters.size() != 0)
      {
         throw new DynamicException(this,
            "XP0017 - fn:position() has no parameter");
      }

      final int position = context.focus.getContextPosition();

      return new DrbDefaultSequence(new Integer(position));
   }

   /**
    * Returns the context size.
    * 
    * @param context the dynamic context to be considered.
    * @return the singleton holding the size of the processing sequence.
    */
   private DrbSequence last(final DynamicContext context)
   {
      if (this.parameters.size() != 0)
      {
         throw new DynamicException(this, "XP0017 - fn:last() has no parameter");
      }

      final int last = context.focus.getContextSize();

      return new DrbDefaultSequence(new Integer(last));
   }

   /**
    * Returns a true boolean value.
    * 
    * @param context the dynamic context to be considered.
    * @return the singleton holding xs:boolean("true").
    */
   private DrbSequence trueBoolean(final DynamicContext context)
   {
      if (this.parameters.size() != 0)
      {
         throw new DynamicException(this, this.functionName
               + "() has no parameter");
      }

      return LiteralResult.TRUE;
   }

   /**
    * Returns a false boolean value.
    * 
    * @param context the dynamic context to be considered.
    * @return the singleton holding xs:boolean("true").
    */
   private DrbSequence falseBoolean(final DynamicContext context)
   {
      if (this.parameters.size() != 0)
      {
         throw new DynamicException(this, this.functionName
               + "() has no parameter");
      }

      return LiteralResult.FALSE;
   }

   /**
    * Inverts the xs:boolean value of the argument..
    * 
    * @param context the dynamic context to be considered.
    * @return the singleton holding xs:boolean("true").
    */
   private DrbSequence not(final DynamicContext context)
   {
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this, this.functionName
               + "() has one parameter");
      }

      final DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence == null)
      {
         throw new DynamicException(this,
            "Error while evaluating the parameter of not() function");
      }

      boolean ebv = Query.getEffectiveBooleanValue(sequence);
      if (ebv)
         return LiteralResult.FALSE;
      else
         return LiteralResult.TRUE;
   }

   /**
    * Returns the index of the node.
    * 
    * @param context the dynamic context to be considered.
    * @return the singleton holding the number of items.
    */
   private DrbSequence index(final DynamicContext context)
   {
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this,
            "XP0017 - index() requires one and only one parameter");
      }

      final DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if ((sequence.getLength() != 1)
            || (sequence.getItem(0).getItemType() != DrbItem.NODE_ITEM))
      {
         throw new DynamicException(this,
            "index() can only be applied on a node");
      }
      else
      {
         return new DrbDefaultSequence(new Integer(((DrbNode) sequence
            .getItem(0)).getIndex()));
      }
   }

   /**
    * Returns the string form of the qualified name of the node.
    * 
    * @param context the dynamic context to be considered.
    * @return the singleton holding the number of items.
    */
   private DrbSequence nodeName(final DynamicContext context)
   {
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this, this.functionName
               + "() requires one and only one parameter");
      }

      final DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence == null)
      {
         throw new DynamicException(this, this.functionName
               + "() : error while evaluating the parameter");
      }

      // If the argument is the empty sequence, the empty string is returned.
      if (sequence.getLength() <= 0)
      {
         return LiteralResult.EMPTY_STRING;
      }

      final DrbItem item = sequence.getItem(0);

      if (item == null)
      {
         throw new DynamicException(this, this.functionName
               + "(): the first item of the parameter sequence " + "is null");
      }

      if (item.getItemType() == DrbItem.VALUE_ITEM)
      {
         throw new DynamicException(this, this.functionName
               + "() requires a well-defined input node");
      }

      final String name = item.getName();

      // If the item has no name, the empty string is returned.
      if (name == null)
      {
         return LiteralResult.EMPTY_STRING;
      }
      // Return the name of the item
      else
      {
         return new DrbDefaultSequence(new fr.gael.drb.value.String(name));
      }
   }

   /**
    * Encodes the node item of a sequence in an XML formated string. If the
    * input sequence contains no item, the empty string is returned. Warning:
    * the input sequence shall not contain items different from nodes.
    * 
    * @param context the dynamic context to be considered.
    * @return the encoded string.
    */
   private DrbSequence xmlString(final DynamicContext context)
   {
      // Check parameter arity
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this, "XP0017 - " + this.functionName
               + "() requires one and only one parameter");
      }

      // Evaluates the parameter sequence
      final DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence == null)
      {
         throw new DynamicException(this, this.functionName
               + "() : error while evaluating the parameter");
      }

      final ByteArrayOutputStream output_stream = new ByteArrayOutputStream();
      final PrintStream print_stream = new PrintStream(output_stream);

      // Loop on resulting sequence items
      for (int iitem = 0; iitem < sequence.getLength(); iitem++)
      {
         final DrbItem item = sequence.getItem(iitem);

         // Case of inconsistent sequence with null references
         if (item == null)
         {
            throw new DynamicException(this, this.functionName
                  + "(): the item #" + (iitem + 1)
                  + " of the parameter sequence is null");
         }

         // The function does not dare any item different from a node
         if (item.getItemType() != DrbItem.NODE_ITEM)
         {
            throw new DynamicException(this, this.functionName
                  + "() cannot be applied for the item #" + (iitem + 1)
                  + " that is not a node");
         }

         // Add separator
         if (iitem != 0)
         {
            print_stream.print(" ");
         }

         // Encode XML node in the output stream
         XmlWriter.writeXML((DrbNode) item, print_stream, new XmlWriter.Context(
            context.getNamespace(), context.getDefaultElementNamespaceURI()),
            false);
      }

      // Build the output string
      final String output_string = "" + output_stream.toString();

      // Create the output sequence from the output string
      final DrbDefaultSequence output_sequence = new DrbDefaultSequence();
      output_sequence.add(new fr.gael.drb.value.String(output_string));

      return output_sequence;
   }

   /**
    * Returns the the value of the node.
    * 
    * @param context the dynamic context to be considered.
    * @return the value of the node.
    */
   private DrbSequence data(final DynamicContext context)
   {
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this,
            "XP0017 - fn:data() requires one and only one parameter");
      }

      final DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence.getLength() <= 1)
      {
         return sequence.atomize();
      }
      else
      {
         return new DataResult(sequence);
      }
   } // data

   /**
    * Check if the argument contains one or more items.
    * 
    * @param context the dynamic context to be considered.
    * @return If the argument is not the empty sequence, the function returns
    *         true; otherwise, the function returns false.
    */
   private DrbSequence exists(final DynamicContext context)
   {
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this,
            "XP0017 - fn:exists() requires one and only one parameter");
      }

      final DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence == null)
      {
         throw new DynamicException(this, this.functionName
               + "() : error while evaluating the parameter");
      }

      if (sequence.getLength() > 0)
      {
         return LiteralResult.TRUE;
      }
      else
      {
         return LiteralResult.FALSE;
      }
   } // exists

   /**
    * Check if the argument is the empty sequence.
    * 
    * @param context the dynamic context to be considered.
    * @return If the argument is the empty sequence, the function returns true;
    *         otherwise, the function returns false.
    */
   private DrbSequence empty(final DynamicContext context)
   {
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this,
            "XP0017 - fn:empty() requires one and only one parameter");
      }

      final DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence == null)
      {
         throw new DynamicException(this, this.functionName
               + "() : error while evaluating the parameter");
      }

      if (sequence.getLength() == 0)
      {
         return LiteralResult.TRUE;
      }
      else
      {
         return LiteralResult.FALSE;
      }
   } // empty

   /**
    * Returns the name of the node in parameter or from current context node.
    * 
    * @param context the dynamic context to be considered.
    * @return the singleton holding the node name.
    */
   private DrbSequence name(final DynamicContext context)
   {
      if ((this.parameters.size() < 0) || (this.parameters.size() > 1))
      {
         throw new DynamicException(this,
            "XP0017 - fn:name() requires zero or one parameter");
      }

      if (this.parameters.size() == 0)
      {
         if ((context.focus.getContextItem() == null)
               || (context.focus.getContextItem().getItemType() == DrbItem.VALUE_ITEM))
         {
            throw new DynamicException(this,
               "FONC0001 - fn:name() requires a well-defined context node");
         }
         final String name = context.focus.getContextItem().getName();

         // If the node has no name, the empty sequence is returned.
         if (name == null)
         {
            return LiteralResult.EMPTY_STRING;
            // Return the name of the node
         }
         else
         {
            return new DrbDefaultSequence(new fr.gael.drb.value.String(name));
         }
      }
      else
      {
         return this.nodeName(context);
      }
   } /* name () */

   /**
    * Returns the namescape URI of the node in parameter or from current context
    * node.
    * 
    * @param context the dynamic context to be considered.
    * @return the singleton holding the namespace URI.
    */
   private DrbSequence namespaceURI(final DynamicContext context)
   {
      if ((this.parameters.size() < 0) || (this.parameters.size() > 1))
      {
         throw new DynamicException(this,
            "XP0017 - fn:namespace-uri() requires zero or one parameter");
      }

      DrbItem item = null;
      if (this.parameters.size() == 0)
      {
         item = context.focus.getContextItem();
      }
      else
      {
         final DrbSequence sequence =
            ((Expression) this.parameters.get(0)).evaluate(context);

         if (sequence == null)
         {
            throw new DynamicException(this,
               "fn:namespace-uri() : error while evaluating the parameter");
         }

         // If the argument is the empty sequence, the empty string is returned
         if (sequence.getLength() <= 0)
         {
            return LiteralResult.EMPTY_STRING;
         }
         else
         {
            item = sequence.getItem(0);
         }
      }

      if ((item == null) || (item.getItemType() == DrbItem.VALUE_ITEM))
      {
         throw new DynamicException(this,
            "fn:namespace-uri() requires a well-defined input node");
      }

      final String uri = item.getNamespaceURI();

      // If the node has no name, the empty sequence is returned.
      if (uri == null)
      {
         return LiteralResult.EMPTY_STRING;
         // Return the name of the node
      }
      else
      {
         return new DrbDefaultSequence(new fr.gael.drb.value.String(uri));
      }
   } /* namespace-uri () */

   /**
    * Creates a value item according to the function name. The basic principle
    * of this operation is to extract the value of the unique parameter of the
    * XQuery function and comvert this value to the requested type. The reqested
    * type is deduced from the XQuery function name using the gael.drb.xsd
    * package for wrapping the name to the gael.drb.value type identifier.
    * 
    * @param context used to evaluate the parameters.
    * @return the new value if no error occurred.
    */
   private DrbSequence atomicTypeConstructor(final DynamicContext context)
   {
      /**
       * Retreive the gael.drb.value type identifier from the function name.
       */
      if (this.defaultSchema == null)
      {
         this.defaultSchema = XmlSchema.getDefaultSchema();
      }

      final XsdType[] default_types = this.defaultSchema.getGlobalTypes();

      int atomic_type_id = Value.UNKNOWN_ID;

      for (int itype = 0; itype < default_types.length; itype++)
      {
         final XsdSimpleType simple_type = default_types[itype].getDatatype();

         if (simple_type != null)
         {
            if (simple_type.getName().equals(this.functionName.getLocalName()))
            {
               atomic_type_id = simple_type.getTypeId();
               break;
            }
         }
      }
      // TODO: look spec type or dyn execption...
      if (atomic_type_id == Value.UNKNOWN_ID)
      {
         throw new DynamicException(this, "No constructor defined for \""
               + this.functionName + "\"");
      }

      /**
       * Get the parameter expression.
       */
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this, "XP0017 - " + this.functionName
               + " requires one and only " + "one parameter");
      }

      final Expression parameter_expr = (Expression) this.parameters.get(0);

      if (parameter_expr == null)
      {
         throw new DynamicException(this,
         // TODO: better message
            "Parameter is null");
      }

      /**
       * Evaluates the parameter expression with the context.
       */
      DrbSequence parameter_sequence = parameter_expr.evaluate(context);

      if (parameter_sequence == null)
      {
         throw new DynamicException(this,
         // TODO: better message
            "Evaluation of parameter is null");
      }

      parameter_sequence = parameter_sequence.atomize();

      /**
       * Checks the empty sequence.
       */
      if (parameter_sequence.getLength() == 0)
      {
         return new DrbDefaultSequence();
      }

      /**
       * Checks the item is an atomic value and extract it.
       */
      if (parameter_sequence.getLength() > 1)
      {
         throw new DynamicException(this, "Parameter is not an atomic value");
      }

      final Value parameter_value = (Value) parameter_sequence.getItem(0);

      if (parameter_value == null)
      {
         throw new DynamicException(this,
            "Cannot extract the value of the parameter");
      }

      /**
       * Converts the value to the desired type.
       */
      Value output_value;
      try
      {
         output_value = parameter_value.convertTo(atomic_type_id);
         if (this.functionName.getLocalName().equals("token"))
         {
            output_value = new fr.gael.drb.value.String(output_value.toString());
         }
      }
      catch (final Exception e)
      {
         throw new DynamicException(this,
            "Cannot convert parameter, evaluated as " + parameter_value
                  + ", to " + this.functionName + " type");
      }

      return new DrbDefaultSequence(output_value);
   } // atomicTypeConstructor

   /*
    * ======================================================================
    * Functions on string
    * ======================================================================
    */

   /**
    * Checks if a string matches a regular expression. The parameters of the
    * functions are : $source as xs:string $pattern as xs:string and returns a
    * xs:boolean. If $source is the empty sequence, it is interpreted as the
    * zero-length string.
    * 
    * @param context used to evaluate the parameters.
    * @return true if the $source matches the regular expression supplied as
    *         $pattern; otherwise it returns false.
    */
   private DrbSequence matches(final DynamicContext context)
   {
      /**
       * Check the input parameter number.
       */
      if (this.parameters.size() != 2)
      {
         throw new DynamicException(this,
            "XP0017 - fn:matches() requires to parameters");
      }

      /**
       * Get the source string from parameter. This parameter is mandatory and
       * shall be evaluable as an item convertible univocally in string.
       */
      final Expression source_string_expr = (Expression) this.parameters.get(0);

      if (source_string_expr == null)
      {
         throw new DynamicException(this,
            "fn:matches() operation requires a source string as first "
                  + "parameter");
      }

      DrbSequence source_string_sequence = source_string_expr.evaluate(context);

      if (source_string_sequence == null)
      {
         throw new DynamicException(this,
            "fn:matches() : error while evaluating the first parameter");
      }
      source_string_sequence = source_string_sequence.atomize();

      if (source_string_sequence.getLength() > 1)
      {
         throw new DynamicException(this,
            "fn:matches() : first parameter is a sequence of "
                  + source_string_sequence.getLength() + " item(s)");
      }

      Value source_string_value = null;

      if (source_string_sequence.getLength() == 1)
      {
         final DrbItem source_item = source_string_sequence.getItem(0);

         source_string_value = source_item.getValue();
      }

      String source_string = "";
      if (source_string_value != null)
      {
         if (source_string_value.getType() != fr.gael.drb.value.Value.STRING_ID)
         {
            throw new TypeException(this,
               "fn:matches() : first parameter is not a xs:string");
         }
         source_string = source_string_value.toString();
      }

      /**
       * Get the pattern string from parameter. This parameter is mandatory and
       * shall be evaluable as an item convertible univocally in string.
       */
      final Expression pattern_string_expr = (Expression) this.parameters.get(1);

      if (pattern_string_expr == null)
      {
         throw new DynamicException(this,
            "fn:matches() operation requires a source string as pattern "
                  + "parameter");
      }

      DrbSequence pattern_string_sequence =
         pattern_string_expr.evaluate(context);

      if (pattern_string_sequence == null)
      {
         throw new DynamicException(this,
            "fn:matches() : error while evaluating the pattern parameter");
      }
      pattern_string_sequence = pattern_string_sequence.atomize();

      if (pattern_string_sequence.getLength() != 1)
      {
         throw new DynamicException(this,
            "fn:matches() : 'pattern' parameter is a sequence of "
                  + pattern_string_sequence.getLength() + " item(s)");
      }

      final DrbItem pattern_item = pattern_string_sequence.getItem(0);

      final Value pattern_string_value = pattern_item.getValue();

      if (pattern_string_value.getType() != fr.gael.drb.value.Value.STRING_ID)
      {
         throw new TypeException(this,
            "fn:matches() : pattern parameter is not an xs:string");
      }

      String pattern_string = pattern_string_value.toString();

      if (pattern_string == null)
      {
         pattern_string = "";
      }

      /**
       * Returns the evaluation.
       */
      return (new DrbDefaultSequence(new fr.gael.drb.value.Boolean(source_string
         .matches(pattern_string))));
   } /* matches */

   /**
    * Break dow a string into a sequence of strings. The parameters of the
    * functions are : $source as xs:string $pattern as xs:string and returns a
    * sequence of strings. The operation does not already support the flag
    * parameter.
    * 
    * @param context used to evaluate the parameters.
    * @return true if the $source matches the regular expression supplied as
    *         $pattern; otherwise it returns false.
    */
   private DrbSequence tokenize(final DynamicContext context)
   {
      /**
       * Check the input parameter number.
       */
      if (this.parameters.size() != 2)
      {
         throw new DynamicException(this,
            "XP0017 - fn:tokenize() requires two parameters");
      }

      /**
       * Get the source string from first parameter. This parameter is mandatory
       * and shall be evaluable as an item convertible univocally in string.
       */
      final Expression source_string_expr = (Expression) this.parameters.get(0);

      if (source_string_expr == null)
      {
         throw new DynamicException(this,
            "fn:tokenize() operation requires a source string as first "
                  + "parameter");
      }

      final DrbSequence source_string_sequence =
         source_string_expr.evaluate(context);

      if (source_string_sequence == null)
      {
         throw new DynamicException(this,
            "fn:tokenize() : error while evaluating the first parameter");
      }

      // Case of empty sequence
      if (source_string_sequence.getLength() < 1)
      {
         return new DrbDefaultSequence();
      }

      if (source_string_sequence.getLength() > 1)
      {
         throw new DynamicException(this,
            "fn:tokenize() : first parameter is a sequence of "
                  + source_string_sequence.getLength() + " items");
      }

      final DrbItem source_item = source_string_sequence.getItem(0);
      final Value source_string_value = source_item.getValue();

      if (source_string_value == null)
      {
         return new DrbDefaultSequence();
      }

      if (source_string_value.getType() != fr.gael.drb.value.Value.STRING_ID)
      {
         throw new TypeException(this,
            "fn:tokenize() : first parameter is not a xs:string");
      }

      String source_string = source_string_value.toString();

      if (source_string == null)
      {
         source_string = "";
      }

      /**
       * Get the pattern string from parameter. This parameter is mandatory and
       * shall be evaluable as an item convertible univocally in string.
       */
      final Expression pattern_string_expr = (Expression) this.parameters.get(1);

      if (pattern_string_expr == null)
      {
         throw new DynamicException(this,
            "fn:tokenize() operation requires a source string as pattern "
                  + "parameter");
      }

      final DrbSequence pattern_string_sequence =
         pattern_string_expr.evaluate(context);

      if (pattern_string_sequence == null)
      {
         throw new DynamicException(this,
            "fn:tokenize() : error while evaluating the pattern parameter");
      }

      final DrbItem pattern_item = pattern_string_sequence.getItem(0);

      if (pattern_item.getItemType() != DrbItem.VALUE_ITEM)
      {
         throw new DynamicException(this,
            "fn:tokenize() : pattern parameter is not an atomic value");
      }

      final Value pattern_string_value = pattern_item.getValue();

      if (pattern_string_value.getType() != fr.gael.drb.value.Value.STRING_ID)
      {
         throw new TypeException(this,
            "fn:tokenize() : pattern parameter is not an xs:string");
      }

      String pattern_string = pattern_string_value.toString();

      if (pattern_string == null)
      {
         pattern_string = "";
      }

      /**
       * Builds the output sequence of strings.
       */
      final DrbDefaultSequence output_sequence = new DrbDefaultSequence();
      final StringTokenizer string_tokenizer =
         new StringTokenizer(source_string, pattern_string);

      while (string_tokenizer.hasMoreTokens())
      {
         output_sequence.add(new fr.gael.drb.value.String(string_tokenizer
            .nextToken()));
      }

      /**
       * Returns the evaluation.
       */
      return (output_sequence);
   } /* matches */

   /**
    * Returns the length in characters of a string value. The parameters of the
    * functions are : $arg as xs:string? and returns an xs:integer
    * 
    * @param context used to evaluate the parameters.
    * @return if the value of $arg is the empty sequence, the xs:integer 0 is
    *         returned; otherwise, the length of the string in argument.
    */
   private DrbSequence stringLength(final DynamicContext context)
   {
      /**
       * Check the input parameter number.
       */
      if (this.parameters.size() > 1)
      {
         throw new DynamicException(this,
            "XPDY0002 - fn:string-length() requires one parameter");
      }

      DrbSequence source_string_sequence = null;

      /**
       * Case of empty parameter list
       */
      if (this.parameters.size() == 0)
      {
         final DrbItem context_item = context.focus.getContextItem();

         if (context_item == null)
         {
            throw new DynamicException(this,
               "fn:string-length() with no argument requires a context item");
         }
         source_string_sequence = new DrbDefaultSequence(context_item);
      }
      else
      {
         /**
          * Get the source string from parameter. This parameter is mandatory
          * and shall be evaluable as an item convertible univocally in string.
          */
         final Expression source_string_expr =
            (Expression) this.parameters.get(0);

         if (source_string_expr == null)
         {
            throw new DynamicException(this,
               "fn:string-length() requires a string value as parameter");
         }

         source_string_sequence = source_string_expr.evaluate(context);
      }
      if (source_string_sequence == null)
      {
         throw new DynamicException(this,
            "fn:string-length() : error while evaluating the first parameter");
      }

      if (source_string_sequence.getLength() > 1)
      {
         throw new DynamicException(this,
            "fn:string-length() : first parameter is a sequence of "
                  + source_string_sequence.getLength() + " items");
      }

      /**
       * Case of empty sequence The xs:integer 0 is returned
       */
      if (source_string_sequence.getLength() == 0)
      {
         return (new DrbDefaultSequence(new fr.gael.drb.value.Int(0)));
      }

      /**
       * Case of singleton sequence The length of the string value is returned
       */
      final DrbItem source_item = source_string_sequence.getItem(0);
      final Value source_string_value = source_item.getValue();

      String source_string = "";

      if (source_string_value != null)
      {
         if (source_string_value.getType() != fr.gael.drb.value.Value.STRING_ID)
         {
            throw new TypeException(this,
               "fn:string-length() : first parameter is not a xs:string");
         }
         source_string = source_string_value.toString();
      }

      /**
       * Returns the evaluation.
       */
      return (new DrbDefaultSequence(new fr.gael.drb.value.Int(source_string
         .length())));
   }

   /**
    * fn:string-join() concatenates a string sequence with a separator. The
    * parameters of the functions are : $arg1 as xs:string* $arg2 as xs:string
    * and returns an xs:string
    * 
    * @param context used to evaluate the parameters.
    * @return if the value of $arg1 is the empty sequence, the zero-length
    *         string is returned; otherwise, the concatenation of the members of
    *         arg1 sequence using arg2 as a separator.
    */
   private DrbSequence stringJoin(final DynamicContext context)
   {
      /**
       * Check the input parameter number.
       */
      if (this.parameters.size() != 2)
      {
         throw new DynamicException(this,
            "XPST0017 - fn:string-join() requires two parameters");
      }

      DrbSequence source_string_sequence = null;

      /**
       * Get the source string from parameter. This parameter is mandatory and
       * shall be evaluable as an item convertible univocally in string.
       */
      final Expression source_string_expr = (Expression) this.parameters.get(0);

      if (source_string_expr == null)
      {
         throw new DynamicException(this,
            "fn:string-join() requires a string value as parameter");
      }

      source_string_sequence = source_string_expr.evaluate(context);
      if (source_string_sequence == null)
      {
         throw new DynamicException(this,
            "fn:string-join() : error while evaluating the first parameter");
      }

      source_string_sequence = source_string_sequence.atomize();

      /**
       * Get the separator string from parameter. This parameter is mandatory
       * and shall be evaluable as an item convertible univocally in string.
       */
      final Expression separator_expr = (Expression) this.parameters.get(1);

      if (separator_expr == null)
      {
         throw new DynamicException(this,
            "fn:string-join() requires a string value as parameter");
      }

      final DrbSequence separator_sequence = separator_expr.evaluate(context);
      if ((separator_sequence == null) || (separator_sequence.getLength() != 1))
      {
         throw new DynamicException(this,
            "fn:string-join() : Unexpected error while evaluating separator.");
      }

      final Value separator_value = separator_sequence.getItem(0).getValue();
      if (separator_value == null)
      {
         throw new DynamicException(this,
            "fn:string-join() : Invalid separator. The second argument"
                  + "must be a single string value");
      }

      String separator = separator_value.toString();
      if (separator.length() == 0)
      {
         separator = null;
      }

      /**
       * Case of empty sequence The zero-length string is returned
       */
      if (source_string_sequence.getLength() == 0)
      {
         return (new DrbDefaultSequence(new fr.gael.drb.value.String("")));
      }

      /**
       * Case of one ore more string values The concatenation of the string
       * value is returned
       */
      final StringBuffer strbuf =
         new StringBuffer(source_string_sequence.getLength() * 10);
      for (int i = 0; i < source_string_sequence.getLength(); i++)
      {
         final Value source_value = source_string_sequence.getItem(i).getValue();
         if (source_value == null)
         {
            throw new DynamicException(this, "fn:string-join() : the item " + i
                  + " has no string value");
         }

         final String source_string = source_value.toString();
         if ((separator != null) && (i != 0))
         {
            strbuf.append(separator);
         }
         strbuf.append(source_string);
      }

      /**
       * Returns the evaluation.
       */
      return (new DrbDefaultSequence(new fr.gael.drb.value.String(strbuf
         .toString())));
   } // string-join()

   /**
    * Check the validity of a node and its children. This function has two
    * arguments and returns a collection of nodes that are invalid. The output
    * nodes are wrapping the invalid nodes without keeping their hyerarchy. The
    * nodes may be accessed to know their exact path, sibling or any other
    * attribute. In addition to the attribute of the wrapped nodes, a set of
    * validation specific attributes is appended. In particular these attributes
    * are dedicated to the identification of the reason of invalidity. The first
    * parameter "node" specifies the node from which the validation shall start.
    * The node and its children, if any, are recursivly checked. The schema
    * parameter may specify a schema to be used for the validation. This
    * parameter is not mandatory if the specified node has already an associated
    * schema. If the provided node has already an associated schema but a schema
    * has also been provided through the present parameter, the new one overides
    * the existing one.
    * 
    * @param context the evaluation context of the function.
    * @return the list of invalid nodes or null if no invalid node has been
    *         detected.
    */
   private DrbSequence deepInvalid(final DynamicContext context)
   {
      /**
       * Checks that at least one node has been provided in input.
       */
      if (this.parameters.size() < 1)
      {
         throw new DynamicException(this,
            "XP0017 - drb:deep-invalid() requires at least one parameter");
      }

      /**
       * Evaluates the expression corresponding to the node to be validated.
       */
      DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence.getLength() != 1)
      {
         throw new DynamicException(this,
            "drb:deep-invalid() : the parameter matches several items");
      }

      DrbItem item = sequence.getItem(0);

      if (item.getItemType() != DrbItem.NODE_ITEM)
      {
         throw new DynamicException(this,
            "drb:deep-invalid() : the parameter is not a node");
      }

      /**
       * Keeps a shortcup to the input node.
       */
      DrbNode input_node = (DrbNode) item;

      /**
       * Check if a schema node has been provided.
       */
      XsdNode xsd_node;

      if (this.parameters.size() >= 2) // Case of schema provided in parameter
      {
         /**
          * Remove previous validator if any. If the input node has already an
          * XsdNode envelope, it is revoved first to avoid duplication of
          * attribute. This operation is repeated until the node is no longer an
          * XsdNode and thus the enveloped node.
          */
         while (input_node instanceof XsdNodeImpl)
         {
            input_node = ((XsdNodeImpl) input_node).getBase();
         }

         /**
          * Get the schema.
          */
         sequence = ((Expression) this.parameters.get(1)).evaluate(context);

         if (sequence.getLength() != 1)
         {
            throw new DynamicException(this, "drb:deep-invalid() : the schema "
                  + "parameter matches several items");
         }

         item = sequence.getItem(0);

         if (item.getItemType() != DrbItem.NODE_ITEM)
         {
            throw new DynamicException(this,
               "drb:deep-invalid() : the schema is not a node");
         }

         final DrbNode schema_root = ((DrbNode) item).getFirstChild();

         final XsdFactory xsd_factory = new XsdFactory();
         final XmlSchema xml_schema =
            xsd_factory.open(((DrbNode) item).getParent(), schema_root);

         if (xml_schema == null)
         {
            throw new DynamicException(this,
               "drb:deep-invalid() : unable to open the schema: \"" + xml_schema
                     + "\"");
         }

         final XsdElement root_element = xml_schema.getDefaultRootElement();

         if (root_element == null)
         {
            throw new DynamicException(this,
               "drb:deep-invalid() : the schema  \"" + xml_schema
                     + "\" has no root element");
         }

         final XsdType root_type = root_element.getType();
         xsd_node = XsdNodeImpl.getInstance(input_node, root_type);
      }
      else
      // Case of no schema provided in parameters
      {
         /**
          * Checks the node has already a schema. Otherwise the validation
          * cannot be performed.
          */
         if (input_node instanceof XsdNode)
         {
            xsd_node = (XsdNode) input_node;
         }
         else
         {
            throw new DynamicException(this,
               "drb:deep-invalid() : unable to retreive a validating schema");
            // TODO: veirfy this concept above. Not compliant.
         }
      }

      /**
       * Builds the output list of invalid nodes.
       */

      return this.getInvalidNodes(xsd_node);
   }

   /**
    * Concatenates two or more xs:strings. The parameters of the functions are :
    * $argN as xs:anyAtomicType? where N may vary from 0 to an unlimited posiive
    * integer number.
    * <p>
    * Accepts zero or more xs:strings as arguments. Returns the xs:string that
    * is the concatenation of the values of its arguments. The resulting
    * xs:string might not be normalized according to any Unicode or W3C
    * normalization form. If called with no arguments, returns the zero-length
    * string. If any of the arguments is the empty sequence, it is treated as
    * the zero-length string.
    * </p>
    * <p>
    * The concat() function is specified to allow an arbitrary number of
    * xs:string arguments that are concatenated together. This is the only
    * function specified in this document that has that characteristic. This
    * capability is retained for compatibility with XPath 1.0.
    * </p>
    * 
    * @param context used to evaluate the parameters.
    * @return the concatenated string if no error occurred and null otherwise.
    */
   private DrbSequence concat(final DynamicContext context)
   {
      final StringBuffer output_buf =
         new StringBuffer(this.parameters.size() * 10);

      for (int iparam = 0; iparam < this.parameters.size(); iparam++)
      {
         /**
          * Get the source string from parameter. This parameter is mandatory
          * and shall be evaluable as an item convertible univocally in string.
          */
         final Expression source_string_expr =
            (Expression) this.parameters.get(iparam);

         if (source_string_expr == null)
         {
            throw new DynamicException(this, this.functionName
                  + "() : cannot extract expression of parameter #"
                  + (iparam + 1));
         }

         DrbSequence source_string_sequence =
            source_string_expr.evaluate(context);

         if (source_string_sequence != null)
         {
            source_string_sequence = source_string_sequence.atomize();
         }

         if (source_string_sequence == null)
         {
            throw new DynamicException(this, this.functionName
                  + "() : error while evaluating the expression of parameter #"
                  + (iparam + 1));
         }

         if (source_string_sequence.getLength() == 0)
         {
            continue;
         }

         if ((source_string_sequence.getLength() != 1)
               || (source_string_sequence.getItem(0) == null))
         {
            throw new DynamicException(this, this.functionName
                  + "() : the evaluation of parameter #" + (iparam + 1)
                  + " does not result to a single value");
         }

         final Value source_string_value =
            (Value) source_string_sequence.getItem(0);
         final String source_string = source_string_value.toString();

         if (source_string == null)
         {
            throw new DynamicException(this, this.functionName
                  + "() : cannot extract string from parameter #" + (iparam + 1));
         }

         output_buf.append(source_string);
      }

      return new DrbDefaultSequence(new fr.gael.drb.value.String(output_buf
         .toString()));
   } /* concat */

   /**
    * Returns the invalid nodes.
    * 
    * @param node the schema node to make run.
    * @return the list of invalid nodes.
    */
   private DrbNodeList getInvalidNodes(final XsdNode node)
   {
      final DrbDefaultNodeList invalid_nodes = new DrbDefaultNodeList();

      /**
       * Adds the node itself if invalid.
       */
      if (node.isValid() != null)
      {
         invalid_nodes.add(node);
      }

      /**
       * Recursive loop on the nodes.
       */
      XsdNode child = (XsdNode) node.getFirstChild();

      while (child != null)
      {
         final DrbNodeList invalid_child_nodes = this.getInvalidNodes(child);

         for (int ichild = 0; ichild < invalid_child_nodes.getLength(); ichild++)
         {
            invalid_nodes.add(invalid_child_nodes.item(ichild));
         }

         child = (XsdNode) child.getNextSibling();
      }

      return invalid_nodes;
   }

   /**
    * Mathematical functions. These function are not compliant with the XQuery
    * core function library
    * 
    * @param context the dynamic context to consider.
    * @param function_type the kind of match function to apply.
    * @return the result of the function if any or an empty sequence.
    */
   private DrbSequence mathFunction(final DynamicContext context,
      final int function_type)
   {
      /**
       * Prepare parameters as double values if any.
       */
      DrbSequence sequence = null;
      Value value = null;
      Numeric first_value = null;
      Numeric second_value = null;

      int parameter_number = 0;
      double first_param = 0.0;
      double second_param = 0.0;

      /**
       * Extracts first parameter if any
       */
      if (this.parameters.size() > 0)
      {
         sequence = ((Expression) this.parameters.get(0)).evaluate(context);

         if (sequence != null)
         {
            sequence = sequence.atomize();
         }

         if ((sequence == null) || (sequence.getLength() > 1))
         {
            throw new DynamicException(this,
               "Error while evaluating the first parameter of the math "
                     + "function " + this.functionName);
         }

         if (sequence.getLength() < 1)
         {
            return new DrbDefaultSequence();
         }

         value = sequence.getItem(0).getValue();

         if (!(value instanceof Numeric))
         {
            throw new DynamicException(this,
               "The first parameter of the math function " + this.functionName
                     + " is not a numerical value");
         }

         first_value = (Numeric) value;
         first_param = first_value.doubleValue();

         parameter_number = parameter_number + 1;
      }

      /**
       * Extracts second parameter if any
       */
      if (this.parameters.size() > 1)
      {
         sequence = ((Expression) this.parameters.get(1)).evaluate(context);

         if (sequence != null)
         {
            sequence = sequence.atomize();
         }

         if ((sequence == null) || (sequence.getLength() <= 0))
         {
            throw new DynamicException(this,
               "Error while evaluating the second parameter of the math "
                     + "function " + this.functionName);
         }

         value = sequence.getItem(0).getValue();

         if (!(value instanceof Numeric))
         {
            throw new DynamicException(this,
               "The second parameter of the math function " + this.functionName
                     + " is not a numerical value");
         }

         second_value = (Numeric) value;
         second_param = second_value.doubleValue();

         parameter_number = parameter_number + 1;
      }

      /**
       * Declare output sequence. The default value is an empty sequence.
       */
      final DrbDefaultSequence output_sequence = new DrbDefaultSequence();

      /**
       * Switches to the right mathematical function.
       */
      switch (function_type)
      {
         case MATH_FUNCTION_ABS:

            if (parameter_number != 1)
            {
               throw new DynamicException(this, this.functionName
                     + ": requires one parameter");
            }

            output_sequence.add(new Double(Math.abs(first_param)));

            return output_sequence;

         case MATH_FUNCTION_SQRT:

            if (parameter_number != 1)
            {
               throw new DynamicException(this, this.functionName
                     + ": requires one parameter");
            }

            output_sequence.add(new Double(Math.sqrt(first_param)));

            return output_sequence;

         case MATH_FUNCTION_POWER:

            if (parameter_number != 2)
            {
               throw new DynamicException(this, this.functionName
                     + ": requires two parameter");
            }

            output_sequence.add(new Double(Math.pow(first_param, second_param)));

            return output_sequence;

         case MATH_FUNCTION_LOG:

            if (parameter_number != 1)
            {
               throw new DynamicException(this, this.functionName
                     + ": requires one parameter");
            }

            output_sequence.add(new Double(Math.log(first_param)));

            return output_sequence;

         case MATH_FUNCTION_RANDOM:

            if (parameter_number != 0)
            {
               throw new DynamicException(this, this.functionName
                     + ": has no parameter");
            }

            output_sequence.add(new Double(Math.random()));

            return output_sequence;

         case MATH_FUNCTION_SIN:

            if (parameter_number != 1)
            {
               throw new DynamicException(this, this.functionName
                     + ": requires one parameter");
            }

            output_sequence.add(new Double(Math.sin(first_param)));

            return output_sequence;

         case MATH_FUNCTION_COS:

            if (parameter_number != 1)
            {
               throw new DynamicException(this, this.functionName
                     + ": requires one parameter");
            }

            output_sequence.add(new Double(Math.cos(first_param)));

            return output_sequence;

         case MATH_FUNCTION_TAN:

            if (parameter_number != 1)
            {
               throw new DynamicException(this, this.functionName
                     + ": requires one parameter");
            }

            output_sequence.add(new Double(Math.tan(first_param)));

            return output_sequence;

         case MATH_FUNCTION_ASIN:

            if (parameter_number != 1)
            {
               throw new DynamicException(this, this.functionName
                     + ": requires one parameter");
            }

            output_sequence.add(new Double(Math.asin(first_param)));

            return output_sequence;

         case MATH_FUNCTION_ACOS:

            if (parameter_number != 1)
            {
               throw new DynamicException(this, this.functionName
                     + ": requires one parameter");
            }

            output_sequence.add(new Double(Math.acos(first_param)));

            return output_sequence;

         case MATH_FUNCTION_ATAN:

            if (parameter_number != 1)
            {
               throw new DynamicException(this, this.functionName
                     + ": requires one parameter");
            }

            output_sequence.add(new Double(Math.atan(first_param)));

            return output_sequence;

         case MATH_FUNCTION_ATAN2:

            if (parameter_number != 2)
            {
               throw new DynamicException(this, this.functionName
                     + ": requires two parameters");
            }

            output_sequence
               .add(new Double(Math.atan2(first_param, second_param)));

            return output_sequence;

         case MATH_FUNCTION_EXP:

            if (parameter_number != 1)
            {
               throw new DynamicException(this, this.functionName
                     + ": requires one parameter");
            }

            output_sequence.add(new Double(Math.exp(first_param)));

            return output_sequence;

         default:
            throw new DynamicException(this, this.functionName
                  + ": not supported");
      }
   }

   /**
    * fn:current-dateTime function.
    * 
    * @param context the dynamic context to consider.
    * @return the current dateTime.
    */
   private DrbSequence currentDateTime(final DynamicContext context)
   {
      /**
       * Check parameters.
       */
      if (this.parameters.size() != 0)
      {
         throw new DynamicException(this, this.functionName + "() has "
               + "no parameter");
      }

      /**
       * Return the current dateTime.
       */
      return new DrbDefaultSequence(context.currentDateTime);
   }

   /**
    * Minimum of the sequence.
    * 
    * @param context the dynamic context to consider.
    * @return the minimum value of the set.
    */
   private DrbSequence min(final DynamicContext context)
   {
      /**
       * Check parameters.
       */
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this, this.functionName + "() requires "
               + "one parameter");
      }

      /**
       * Evaluate the parameter.
       */
      DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence != null)
      {
         sequence = sequence.atomize();
      }

      if (sequence == null)
      {
         throw new DynamicException(this,
            "Error while evaluating the parameter of " + this.functionName
                  + "()");
      }

      // Case of empty sequence
      if (sequence.getLength() < 1)
      {
         return new DrbDefaultSequence();
      }

      /**
       * Get the first value of the list.
       */
      Value min_value = (Value) sequence.getItem(0);

      if (min_value == null)
      {
         throw new DynamicException(this, "Error while extracting first " +
            "value in " + this.functionName + "() function.");
      }

      if (min_value.getType() == Value.ARRAY_ID)
      {
         min_value = ((ValueArray) min_value).getElement(0);

         if (((ValueArray) min_value).length() > 0)
         {
            min_value = ((ValueArray) min_value).getElement(0);
         }
         else
         {
            throw new DynamicException(this, "Error while extracting first " +
               "array alenemnt in "
               + this.functionName + "() function.");
         }
      }

      /**
       * Compute the minimum value.
       */
      for (int ivalue = 0; ivalue < sequence.getLength(); ivalue++)
      {
         final Value element = (Value) sequence.getItem(ivalue);

         if (element == null)
         {
            throw new DynamicException(this, "Error while processing element #"
                  + (ivalue + 1) + " of " + this.functionName + "()");
         }

         try
         {
            if (element.getType() == Value.ARRAY_ID)
            {
               for (int iitem = 0; iitem < ((ValueArray) element).length(); iitem++)
               {
                  final Value array_item =
                     ((ValueArray) element).getElement(iitem);

                  if (array_item == null)
                  {
                     throw new DynamicException(this,
                        "Error while processing array element #" + (iitem + 1)
                              + " of " + this.functionName + "()");
                  }

                  if (((Comparison) array_item).compareTo(min_value) < 0)
                  {
                     min_value = array_item;
                  }
               }
            }
            else if (((Comparison) element).compareTo(min_value) < 0)
            {
               min_value = element;
            }
         }
         catch (final ClassCastException e)
         {
            throw new DynamicException(this,
               "Error while casting an element of the parameter sequence of "
                     + this.functionName + "()");
         }
      }

      /**
       * Return the minimum value.
       */
      return new DrbDefaultSequence(min_value);
   }

   /**
    * Maximum of the sequence.
    * 
    * @param context the dynamic context to consider.
    * @return the maximum value of the set.
    */
   private DrbSequence max(final DynamicContext context)
   {
      /**
       * Check parameters.
       */
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this, this.functionName + "() requires "
               + "one parameter");
      }

      /**
       * Evaluate the parameter.
       */
      DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence != null)
      {
         sequence = sequence.atomize();
      }

      if (sequence == null)
      {
         throw new DynamicException(this,
            "Error while evaluating the parameter of " + this.functionName
                  + "()");
      }

      // Case of empty sequence
      if (sequence.getLength() < 1)
      {
         return new DrbDefaultSequence();
      }

      /**
       * Get the first value of the list.
       */
      Value max_value = (Value) sequence.getItem(0);

      if (max_value == null)
      {
         throw new DynamicException(this, "Error while extracting first " +
            "value in " + this.functionName + "() function.");
      }

      if (max_value.getType() == Value.ARRAY_ID)
      {
         if (((ValueArray) max_value).length() > 0)
         {
            max_value = ((ValueArray) max_value).getElement(0);
         }
         else
         {
            throw new DynamicException(this, "Error while extracting first " +
               "array alenemnt in "
               + this.functionName + "() function.");
         }
      }

      /**
       * Compute the maximum value.
       */
      for (int ivalue = 0; ivalue < sequence.getLength(); ivalue++)
      {
         final Value element = (Value) sequence.getItem(ivalue);

         if (element == null)
         {
            throw new DynamicException(this, "Error while processing element #"
                  + (ivalue + 1) + " of " + this.functionName + "()");
         }

         try
         {
            if (element.getType() == Value.ARRAY_ID)
            {
               for (int iitem = 0; iitem < ((ValueArray) element).length(); iitem++)
               {
                  final Value array_item =
                     ((ValueArray) element).getElement(iitem);

                  if (array_item == null)
                  {
                     throw new DynamicException(this,
                        "Error while processing array element #" + (iitem + 1)
                              + " of " + this.functionName + "()");
                  }

                  if (((Comparison) array_item).compareTo(max_value) > 0)
                  {
                     max_value = array_item;
                  }
               }
            }
            else if (((Comparison) element).compareTo(max_value) > 0)
            {
               max_value = element;
            }
         }
         catch (final ClassCastException e)
         {
            throw new DynamicException(this,
               "Error while casting an element of the parameter sequence of "
                     + this.functionName + "()");
         }
      }

      /**
       * Return the maximum value.
       */
      return new DrbDefaultSequence(max_value);
   }

   /**
    * Average of the sequence.
    * 
    * @param context the dynamic context to consider.
    * @return the averaged value of the set.
    */
   private DrbSequence avg(final DynamicContext context)
   {
      /**
       * Check parameters.
       */
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this, this.functionName + "() requires "
               + "one parameter");
      }

      /**
       * Evaluate the parameter.
       */
      DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence != null)
      {
         sequence = sequence.atomize();
      }

      if (sequence == null)
      {
         throw new DynamicException(this,
            "Error while evaluating the parameter of " + this.functionName
                  + "()");
      }

      /**
       * Initialize counter
       */
      int count = 0;
      Arithmetic avg = null;

      /**
       * Compute the averaged value.
       */
      for (int ivalue = 0; ivalue < sequence.getLength(); ivalue++)
      {
         Value element = (Value) sequence.getItem(ivalue);

         if (element == null)
         {
            throw new DynamicException(this, "Error while processing element #"
                  + (ivalue + 1) + " of " + this.functionName + "()");
         }
         
         int type = element.getType();

         try
         {
            if (element.getType() == Value.ARRAY_ID)
            {
               for (int iitem = 0; iitem < ((ValueArray) element).length(); iitem++)
               {
                  final Value array_item =
                     ((ValueArray) element).getElement(iitem);

                  if (array_item == null)
                  {
                     throw new DynamicException(this,
                        "Error while processing array element #" + (iitem + 1)
                              + " of " + this.functionName + "()");
                  }

                  if (avg == null)
                  {
                     avg = (Arithmetic) array_item;
                  }
                  else
                  {
                     avg = (Arithmetic) avg.add(array_item);
                  }

                  count += 1;
               }
            }
            else
            {
               // xs:double promotion
               if ((type >= Value.BYTE_ID) && (type <= Value.LONG_ID))
               {
                  element = element.convertTo(Value.DOUBLE_ID);
               }
               if (avg == null)
               {
                  avg = (Arithmetic) element;
               }
               else
               {
                  avg = (Arithmetic) avg.add(element);
               }

               count += 1;
            }
         }
         catch (final ClassCastException e)
         {
            throw new DynamicException(this,
               "Error while casting an element of the parameter sequence of "
                     + this.functionName + "()");
         }
      }

      /**
       * Return the maximum value.
       */
      if ((avg != null) && (count > 0))
      {
         return new DrbDefaultSequence(avg.divide(new Int(count)));
      }
      else
      {
         return new DrbDefaultSequence();
      }
   }

   /**
    * Sum of the sequence.
    * 
    * @param context the dynamic context to consider.
    * @return the sum of the values.
    */
   private DrbSequence sum(final DynamicContext context)
   {
      /**
       * Check parameters.
       */
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this, this.functionName + "() requires "
               + "one parameter");
      }

      /**
       * Evaluate the parameter.
       */
      DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence != null)
      {
         sequence = sequence.atomize();
      }

      if (sequence == null)
      {
         throw new DynamicException(this,
            "Error while evaluating the parameter of " + this.functionName
                  + "()");
      }

      /**
       * Initialize counter
       */
      int count = 0;
      Arithmetic sum = new Integer(0);

      /**
       * Compute the sum.
       */
      for (int ivalue = 0; ivalue < sequence.getLength(); ivalue++)
      {
         Value element = (Value) sequence.getItem(ivalue);

         if (element == null)
         {
            throw new DynamicException(this, "Error while processing element #"
                  + (ivalue + 1) + " of " + this.functionName + "()");
         }
         
         if (element instanceof fr.gael.drb.value.String)
            element = element.convertTo (Value.DOUBLE_ID);

         try
         {
            int type = element.getType();
            if (type == Value.ARRAY_ID)
            {
               for (int iitem = 0; iitem < ((ValueArray) element).length(); iitem++)
               {
                  final Value array_item =
                     ((ValueArray) element).getElement(iitem);

                  if (array_item == null)
                  {
                     throw new DynamicException(this,
                        "Error while processing array element #" + (iitem + 1)
                              + " of " + this.functionName + "()");
                  }

                  if (count == 0)
                  {
                     sum = (Arithmetic) array_item;
                  }
                  else
                  {
                     sum = (Arithmetic) sum.add(array_item);
                  }

                  count += 1;
               }
            }
            else
            {
               if (count == 0)
               {
                  sum = (Arithmetic) element;
               }
               else
               {
                  // xs:long promotion
                  if ((type >= Value.BYTE_ID) && (type < Value.LONG_ID))
                  {
                     element = element.convertTo(Value.LONG_ID);
                  }
                  sum = (Arithmetic) sum.add(element);
               }

               count += 1;
            }
         }
         catch (final ClassCastException e)
         {
            e.printStackTrace ();
            throw new DynamicException(this,
               "Error while casting an element of the parameter sequence of "
                     + this.functionName + "()");
         }
      }

      /**
       * Return the sum.
       */
      return new DrbDefaultSequence((DrbItem) sum);
   }

   /**
    * Returns the smallest (closest to negative infinity) number with no
    * fractional part that is not less than the value of $arg. If type of $arg
    * is one of the four numeric types xs:float, xs:double, xs:decimal or
    * xs:integer the type of the result is the same as the type of $arg. If the
    * type of $arg is a type derived from one of the numeric types, the result
    * is an instance of the base numeric type.
    * 
    * @param context the dynamic context to consider.
    * @return the result of the function if any or an empty sequence.
    */
   private DrbSequence ceiling(final DynamicContext context)
   {
      /**
       * Check parameters.
       */
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this, this.functionName + "() requires "
               + "one parameter");
      }

      /**
       * Prepare parameters as double values if any.
       */
      DrbSequence sequence = null;
      Value value = null;
      Numeric num = null;

      /**
       * Extracts parameter if any
       */
      sequence = ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence != null)
      {
         sequence = sequence.atomize();
      }

      if ((sequence == null) || (sequence.getLength() > 1))
      {
         throw new DynamicException(this,
            "Error while evaluating the parameter of " + this.functionName
                  + "() function");
      }

      if (sequence.getLength() < 1)
      {
         return new DrbDefaultSequence();
      }

      value = sequence.getItem(0).getValue();

      if (!(value instanceof Numeric))
      {
         throw new DynamicException(this, "The parameter of "
               + this.functionName + "() is not a numerical value");
      }

      num = (Numeric) value;
      Value ceil = null;

      switch (num.getType())
      {
         case Value.FLOAT_ID:
            ceil = new Float((float) Math.ceil(num.doubleValue()));
            break;
         case Value.DOUBLE_ID:
            ceil = new Double(Math.ceil(num.doubleValue()));
            break;
         case Value.DECIMAL_ID:
            ceil = new Decimal(Math.ceil(num.doubleValue()));
            break;
         default:
            ceil = value.convertTo(Value.INTEGER_ID);
            break;
      }
      /**
       * Returns the ceiling value.
       */
      return new DrbDefaultSequence(ceil);
   } // ceiling

   /**
    * Returns the largest (closest to positive infinity) number with no
    * fractional part that is not greater than the value of $arg. If type of
    * $arg is one of the four numeric types xs:float, xs:double, xs:decimal or
    * xs:integer the type of the result is the same as the type of $arg. If the
    * type of $arg is a type derived from one of the numeric types, the result
    * is an instance of the base numeric type.
    * 
    * @param context the dynamic context to consider.
    * @return the result of the function if any or an empty sequence.
    */
   private DrbSequence floor(final DynamicContext context)
   {
      /**
       * Check parameters.
       */
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this, this.functionName + "() requires "
               + "one parameter");
      }

      /**
       * Prepare parameters as double values if any.
       */
      DrbSequence sequence = null;
      Value value = null;
      Numeric num = null;

      /**
       * Extracts parameter if any
       */
      sequence = ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence != null)
      {
         sequence = sequence.atomize();
      }

      if ((sequence == null) || (sequence.getLength() > 1))
      {
         throw new DynamicException(this,
            "Error while evaluating the parameter of " + this.functionName
                  + "() function");
      }

      if (sequence.getLength() < 1)
      {
         return new DrbDefaultSequence();
      }

      value = sequence.getItem(0).getValue();

      if (!(value instanceof Numeric))
      {
         throw new DynamicException(this, "The parameter of "
               + this.functionName + "() is not a numerical value");
      }

      num = (Numeric) value;
      Value floor = null;

      switch (num.getType())
      {
         case Value.FLOAT_ID:
            floor = new Float((float) Math.floor(num.doubleValue()));
            break;
         case Value.DOUBLE_ID:
            floor = new Double(Math.floor(num.doubleValue()));
            break;
         case Value.DECIMAL_ID:
            floor = new Decimal(Math.floor(num.doubleValue()));
            break;
         default:
            floor = value.convertTo(Value.INTEGER_ID);
            break;
      }
      /**
       * Returns the ceiling value.
       */
      return new DrbDefaultSequence(floor);
   } // floor

   /**
    * Returns the number with no fractional part that is closest to the
    * argument. If there are two such numbers, then the one that is closest to
    * positive infinity is returned. If type of $arg is one of the four numeric
    * types xs:float, xs:double, xs:decimal or xs:integer the type of the result
    * is the same as the type of $arg. If the type of $arg is a type derived
    * from one of the numeric types, the result is an instance of the base
    * numeric type.
    * 
    * @param context the dynamic context to consider.
    * @return the result of the function if any or an empty sequence.
    */
   private DrbSequence round(final DynamicContext context)
   {
      /**
       * Check parameters.
       */
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this, this.functionName + "() requires "
               + "one parameter");
      }

      /**
       * Prepare parameters as double values if any.
       */
      DrbSequence sequence = null;
      Value value = null;
      Numeric num = null;

      /**
       * Extracts parameter if any
       */
      sequence = ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence != null)
      {
         sequence = sequence.atomize();
      }

      if ((sequence == null) || (sequence.getLength() > 1))
      {
         throw new DynamicException(this,
            "Error while evaluating the parameter of " + this.functionName
                  + "() function");
      }

      if (sequence.getLength() < 1)
      {
         return new DrbDefaultSequence();
      }

      value = sequence.getItem(0).getValue();

      if (!(value instanceof Numeric))
      {
         throw new DynamicException(this, "The parameter of "
               + this.functionName + "() is not a numerical value");
      }

      num = (Numeric) value;
      Value round = null;

      switch (num.getType())
      {
         case Value.FLOAT_ID:
            round = new Float((float) Math.round(num.doubleValue()));
            break;
         case Value.DOUBLE_ID:
            round = new Double(Math.round(num.doubleValue()));
            break;
         case Value.DECIMAL_ID:
            round = new Decimal(Math.round(num.doubleValue()));
            break;
         default:
            round = value.convertTo(Value.INTEGER_ID);
            break;
      }
      /**
       * Returns the ceiling value.
       */
      return new DrbDefaultSequence(round);
   } // round

   /**
    * Time convertion.
    * 
    * @param context the dynamic context to consider.
    * @return the MST time.
    */
   private DrbSequence utcToMjd(final DynamicContext context)
   {
      /**
       * Check parameters.
       */
      if (this.parameters.size() != 2)
      {
         throw new DynamicException(this, this.functionName + "() requires "
               + "two parameters");
      }

      /**
       * Extracts UTC date.
       */
      DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence != null)
      {
         sequence = sequence.atomize();
      }

      if ((sequence == null) || (sequence.getLength() > 1))
      {
         throw new DynamicException(this,
            "Error while evaluating the UTC date parameter of "
                  + this.functionName + "()");
      }

      // Case of empty sequence
      if (sequence.getLength() == 0)
      {
         return new DrbDefaultSequence();
      }

      DrbItem item = sequence.getItem(0);

      if (!(item instanceof DateTime))
      {
         throw new DynamicException(this, "The first parameter of the function "
               + this.functionName + "() is not a time value");
      }

      final DateTime utc = (DateTime) item;

      /**
       * Extracts DUT1 [s].
       */
      sequence = ((Expression) this.parameters.get(1)).evaluate(context);

      if (sequence != null)
      {
         sequence = sequence.atomize();
      }

      if ((sequence == null) || (sequence.getLength() != 1))
      {
         throw new DynamicException(this,
            "Error while evaluating the DUT1 parameter of " + this.functionName
                  + "()");
      }

      item = sequence.getItem(0);

      if (!(item instanceof Numeric))
      {
         throw new DynamicException(this,
            "The first parameter of the math function " + this.functionName
                  + " is not a numerical value");
      }

      final double dut1 = ((Numeric) item).doubleValue();

      /**
       * Compute MJD (J2000,0)
       */
      final Calendar calendar =
         Calendar.getInstance(TimeZone.getTimeZone("GMT"));
      calendar.setTime(new Timestamp(utc.getTime()));

      final double year = (double) calendar.get(Calendar.YEAR);
      final double month = (double) calendar.get(Calendar.MONTH);
      final double mday = (double) calendar.get(Calendar.DAY_OF_MONTH);
      double hours = (double) calendar.get(Calendar.HOUR_OF_DAY);
      final double minutes = (double) calendar.get(Calendar.MINUTE);
      final double seconds = (double) calendar.get(Calendar.SECOND);
      final double mseconds =
         (double) calendar.get(Calendar.MILLISECOND) + dut1 * 1000;
      final double nseconds = (double) utc.getNanos() + dut1 * 1000000000;

      double jd; /* julian date */
      double day; /* day and time fraction of year */

      day = calendar.get(Calendar.DAY_OF_YEAR);
      day +=
         (double) ((hours * 3600 + minutes * 60 + seconds) * 1000 + mseconds + (nseconds - 1000000 * mseconds) * 1e-3)
               / (1000.0 * 86400.0);

      // Compute Julian time in century (J2000,0)
      hours =
         hours + (minutes / 60) + (seconds / 3600) + (mseconds / 3600e3)
               + (nseconds / 3600e9);
      double GGG = 1.0;
      if (year < 1582)
      {
         GGG = 0.0;
      }
      if ((year <= 1582) && (month < 10))
      {
         GGG = 0.0;
      }
      if ((year <= 1582) && (month == 10) && (mday < 5))
      {
         GGG = 0.0;
      }
      double JD =
         -1 * Math.floor(7.0 * (Math.floor((month + 9.0) / 12.0) + year) / 4.0);
      double S = 1.0;
      if ((month - 9) < 0)
      {
         S = -1.0;
      }
      final double A = Math.abs(month - 9.0);
      double J1 = Math.floor(year + S * Math.floor(A / 7.0));
      J1 = -1 * Math.floor((Math.floor(J1 / 100.0) + 1.0) * 3.0 / 4.0);
      JD = JD + Math.floor(275.0 * month / 9.0) + mday + (GGG * J1);
      JD = JD + 1721027 + 2.0 * GGG + 367.0 * year - 0.5;
      JD = JD + (hours / 24.0);

      jd = JD;

      return new DrbDefaultSequence(new Double(jd));
   }

   /**
    * Imports a document and returns its root node.
    * 
    * @param context the dynamic context to be considered.
    * @return the matching root node or an empty sequence otherwise.
    */
   private DrbSequence importDoc(final DynamicContext context)
   {
      /**
       * Check the input parameter number.
       */
      if (this.parameters.size() != 2)
      {
         throw new DynamicException(this,
            "XP0017 - drb:import-doc() requires two parameters");
      }

      /**
       * Get the source string from parameter. This parameter is mandatory and
       * shall be evaluable as an item convertible univocally in string.
       */
      final Expression source_string_expr = (Expression) this.parameters.get(0);

      if (source_string_expr == null)
      {
         throw new DynamicException(this,
            "drb:import-doc() operation requires a source string as first "
                  + "parameter");
      }

      final DrbSequence source_string_sequence =
         source_string_expr.evaluate(context);

      if (source_string_sequence == null)
      {
         throw new DynamicException(this,
            "drb:import-doc() : error while evaluating the first parameter");
      }

      if (source_string_sequence.getLength() != 1)
      {
         throw new DynamicException(this,
            "drb:import-doc() : first parameter is a sequence of "
                  + source_string_sequence.getLength() + " item(s)");
      }

      final DrbItem source_item = source_string_sequence.getItem(0);

      if (source_item.getItemType() != DrbItem.VALUE_ITEM)
      {
         throw new DynamicException(this,
            "drb:import-doc() : first parameter is not an atomic value");
      }

      final Value source_string_value = source_item.getValue();

      if (source_string_value == null)
      {
         return new DrbDefaultSequence();
      }

      if (source_string_value.getType() != fr.gael.drb.value.Value.STRING_ID)
      {
         throw new TypeException(this,
            "drb:import-doc() : first parameter is not a xs:string");
      }

      String source_string = source_string_value.toString();

      if (source_string == null)
      {
         source_string = "";
      }

      /**
       * Get the import format from parameter. This parameter is mandatory and
       * shall be evaluable as an item convertible univocally in string.
       */
      final Expression format_string_expr = (Expression) this.parameters.get(1);

      if (format_string_expr == null)
      {
         throw new DynamicException(this,
            "drb:import-doc() operation requires an input format as "
                  + "parameter");
      }

      final DrbSequence format_string_sequence =
         format_string_expr.evaluate(context);

      if (format_string_sequence == null)
      {
         throw new DynamicException(this,
            "drb:import-doc() : error while evaluating the format parameter");
      }

      final DrbItem format_item = format_string_sequence.getItem(0);
      final Value format_string_value = format_item.getValue();

      if (format_string_value == null)
      {
         throw new DynamicException(this,
            "drb:import-doc() : format parameter has no value");
      }

      if (format_string_value.getType() != fr.gael.drb.value.Value.STRING_ID)
      {
         throw new TypeException(this,
            "drb:import-doc() : format parameter is not an xs:string");
      }

      String format_string = format_string_value.toString();

      if (format_string == null)
      {
         format_string = "";
      }

      /**
       * Returns the evaluation.
       */
      return (new DrbDefaultSequence(fr.gael.drb.DrbFactory.openAs(
         source_string, format_string)));
   } /* importDoc */

   /**
    * Opens a document and returns its root node.
    * 
    * @param context the dynamic context to be considered.
    * @return the matching root node or an empty sequence otherwise.
    */
   private DrbSequence doc(final DynamicContext context)
   {
      /**
       * Check parameter number.
       */
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this, this.functionName
               + "() requires one and only one parameter");
      }

      /**
       * Evaluates the path.
       */
      DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence != null)
      {
         sequence = sequence.atomize();
      }

      // Returns the empty sequence if the parameter is the empty sequence
      if ((sequence != null) && (sequence.getLength() == 0))
      {
         return new DrbDefaultSequence();
      }

      if ((sequence == null) || (sequence.getLength() != 1)
            || (sequence.getItem(0) == null))
      {
         throw new DynamicException(this,
            "Error while evaluating the URL parameter of " + this.functionName
                  + "()");
      }

      final fr.gael.drb.value.String value =
         (fr.gael.drb.value.String) ((Value) sequence.getItem(0))
            .convertTo(Value.STRING_ID);

      /**
       * Converts the string parameter into a valid URL. If the provided path is
       * relative, it is prefixed with the baseURI of the dynamic context.
       */
      final Value uri = value;
      String input_uri = value.toString();
      if (context.getBaseURI() != null)
      {
         try
         {
            final URI local = new URI(context.getBaseURI());
            input_uri = local.resolve(input_uri).toString();
         }
         catch (final Exception exception)
         {
            throw new DynamicException(this,
               "FODC0005: Invalid URI reference \"" + input_uri + "\"");
         }
      }
      /**
       * Opens the output node.
       */
      final DrbNode node = DrbFactory.openURI(input_uri);

      /**
       * Returns the opened node.
       */
      if (node != null)
      {
         return new DrbDefaultSequence(node);
      }
      else
      {
         throw new DynamicException(this,
            "FODC0005: No mapping for the URI reference \"" + uri + "\"");
      }
   }

   /**
    * Opens a document and returns its root node.
    * 
    * @param context the dynamic context to be considered.
    * @return the matching root node or an empty sequence otherwise.
    */
   private DrbSequence xmlDoc(final DynamicContext context)
   {
      /**
       * Check parameter number.
       */
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this, this.functionName
               + "() requires one and only one parameter");
      }

      /**
       * Evaluates the path.
       */
      DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence != null)
      {
         sequence = sequence.atomize();
      }

      // Returns the empty sequence if the parameter is the empty sequence
      if ((sequence != null) && (sequence.getLength() == 0))
      {
         return new DrbDefaultSequence();
      }

      if ((sequence == null) || (sequence.getLength() != 1)
            || (sequence.getItem(0) == null))
      {
         throw new DynamicException(this,
            "Error while evaluating the URL parameter of " + this.functionName
                  + "()");
      }

      final fr.gael.drb.value.String value =
         (fr.gael.drb.value.String) ((Value) sequence.getItem(0))
            .convertTo(Value.STRING_ID);

      /**
       * Converts the string parameter into a valid URL. If the provided path is
       * relative, it is prefixed with the path of the context item.
       */
      final Value uri = value;
      String input_uri = value.toString();
      if (context.getBaseURI() != null)
      {
         try
         {
            final URI local = new URI(context.getBaseURI());
            input_uri = local.resolve(input_uri).toString();
         }
         catch (final Exception exception)
         {
            throw new DynamicException(this,
               "FODC0005: Invalid URI reference \"" + input_uri + "\""
                     + " Base URI = \"" + context.getBaseURI() + "\"");
         }
      }
      /**
       * Opens the output node.
       */
      DrbNode node = DrbFactory.openURI(input_uri);
      node = new fr.gael.drb.impl.xml.XmlFactory().open(node); // root element
      if (node != null)
      {
         node = node.getParent(); // go the XML document file
      }

      /**
       * Returns the opened node.
       */
      if (node != null)
      {
         return new DrbDefaultSequence(node);
      }
      else
      {
         throw new DynamicException(this,
            "FODC0005: No mapping for the URI reference \"" + uri + "\"");
      }
   }

   /**
    * Evaluates an XQuery from a file located in a dedicated URI.
    * 
    * @param context the dynamic context to be considered.
    * @return the matching root node or an empty sequence otherwise.
    */
   private DrbSequence evaluateURI(final DynamicContext context)
   {
      /**
       * Check parameter number.
       */
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this, this.functionName
               + "() requires one and only one parameter");
      }

      /**
       * Evaluates the path.
       */
      DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence != null)
      {
         sequence = sequence.atomize();
      }

      if ((sequence == null) || (sequence.getLength() != 1)
            || (sequence.getItem(0) == null))
      {
         throw new DynamicException(this,
            "Error while evaluating the URI parameter of " + this.functionName
                  + "()");
      }

      final fr.gael.drb.value.String value =
         (fr.gael.drb.value.String) ((Value) sequence.getItem(0))
            .convertTo(Value.STRING_ID);

      /**
       * Converts the string parameter into a valid URI. If the provided path is
       * relative, it is prefixed with the path of the context item.
       */
      URL url = null;

      try
      {
         final URL context_url =
            new URL(new URL("file:"), ((DrbNode) context.focus.getContextItem())
               .getPath()
                  + "/");
         // The trailing slash is important !!!

         url = new URL(context_url, value.toString());
      }
      catch (final MalformedURLException exception)
      {
         throw new DynamicException(this, this.functionName
               + "(): cannot convert parameter to a valid URL");
      }

      /**
       * Opens the output node.
       */
      InputStream stream = null;
      Query query = null;
      DrbSequence output_sequence = new DrbDefaultSequence();

      try
      {
         stream = url.openStream();
         //stream = new FileInputStream(url.getPath());

         query = new Query(stream, (StaticContext) context);

         output_sequence = query.evaluate(context.focus.getContextItem());
      }
      catch (final Exception exception)
      {
         throw new DynamicException(this, this.functionName + "(): " + exception);
      }

      /**
       * Returns empty sequence.
       */
      return output_sequence;
   }

   /**
    * Evaluates an XQuery from a string.
    * 
    * @param context the dynamic context to be considered.
    * @return the matching root node or an empty sequence otherwise.
    */
   private DrbSequence evaluateString(final DynamicContext context)
   {
      /**
       * Check parameter number.
       */
      if (this.parameters.size() != 1)
      {
         throw new DynamicException(this, this.functionName
               + "() requires one and only one parameter");
      }

      /**
       * Evaluates the path.
       */
      DrbSequence sequence =
         ((Expression) this.parameters.get(0)).evaluate(context);

      if (sequence != null)
      {
         sequence = sequence.atomize();
      }

      if ((sequence == null) || (sequence.getLength() != 1)
            || (sequence.getItem(0) == null))
      {
         throw new DynamicException(this,
            "Error while evaluating the URI parameter of " + this.functionName
                  + "()");
      }

      final fr.gael.drb.value.String value =
         (fr.gael.drb.value.String) ((Value) sequence.getItem(0))
            .convertTo(Value.STRING_ID);

      /**
       * Opens the output node.
       */
      Query query = null;
      DrbSequence output_sequence = new DrbDefaultSequence();

      try
      {
         query = new Query(value.toString(), (StaticContext) context);

         output_sequence = query.evaluate(context.focus.getContextItem());
      }
      catch (final Exception exception)
      {
         throw new DynamicException(this, this.functionName + "(): " + exception);
      }

      /**
       * Returns empty sequence.
       */
      return output_sequence;
   }

   /**
    * Raises a dynamic error.
    * 
    * @param context the dynamic context to be considered.
    * @return obviously nothing.
    */
   private DrbSequence error(final DynamicContext context)
   {
      String message = "";

      if (this.parameters.size() > 0)
      {
         DrbSequence sequence =
            ((Expression) this.parameters.get(0)).evaluate(context);

         if (sequence != null)
         {
            sequence = sequence.atomize();
         }

         if ((sequence == null) || (sequence.getLength() != 1)
               || (sequence.getItem(0) == null))
         {
            throw new DynamicException(this,
               "Error while evaluating the parameter of " + this.functionName
                     + "()");
         }

         final fr.gael.drb.value.String value =
            (fr.gael.drb.value.String) ((Value) sequence.getItem(0))
               .convertTo(Value.STRING_ID);

         message = value.toString();
      }

      throw new DynamicException(this, message);
   }

   /**
    * Interactive trace. The trace is printed out to the this.logger in DEBUG
    * mode.
    * 
    * @param context the dynamic context to be considered.
    * @return the given expression.
    */
   private DrbSequence trace(final DynamicContext context)
   {
      if (this.parameters.size() != 2)
      {
         throw new DynamicException(this, this.functionName
               + "(): expects to and only two parameters");
      }

      /**
       * Prints the trace message.
       */
      DrbSequence sequence =
         ((Expression) this.parameters.get(1)).evaluate(context);

      if (sequence != null)
      {
         sequence = sequence.atomize();
      }

      if ((sequence == null) || (sequence.getLength() != 1)
            || (sequence.getItem(0) == null))
      {
         throw new DynamicException(this,
            "Error while evaluating the label parameter of " + this.functionName
                  + "()");
      }

      final fr.gael.drb.value.String value =
         (fr.gael.drb.value.String) ((Value) sequence.getItem(0))
            .convertTo(Value.STRING_ID);

      this.logger.debug(value.toString());

      /**
       * Returns the evaluation of the expression.
       */
      return ((Expression) this.parameters.get(0)).evaluate(context);
   }

   /**
    * Inserts $content as the children of $target, in an implementation-defined
    * position. $target as node() $content as node()+ The semantics of
    * upd:insertInto are identical to the semantics of upd:insertBefore, except
    * that $target is substuted everywhere for parent($target), and Rule 2a is
    * changed as follows: The children property of $target is changed to include
    * the nodes in $content. The order among the new children, and their
    * position within the parent node, is implementation-dependent.
    * 
    * @param target $target must be an element or document node.
    * @param $content must be a sequence containing only element, text,
    *           processing instruction, and comment nodes.
    * @return a null sequence with pending update nodes.
    */
   private DrbSequence insertInto(final DynamicContext context)
   {
      /**
       * Check the input parameter number.
       */
      if (this.parameters.size() != 2)
      {
         throw new DynamicException(this,
            "XP0017 - drb:insertInto() requires two parameters");
      }

      /**
       * Get the target node from first parameter. This parameter is mandatory
       * and shall be evaluable as an element node.
       */
      final Expression target_expr = (Expression) this.parameters.get(0);

      if (target_expr == null)
      {
         throw new DynamicException(this,
            "drb:insertInto() operation requires a target node as first "
                  + "parameter");
      }

      final DrbSequence target_sequence = target_expr.evaluate(context);

      if (target_sequence == null)
      {
         throw new DynamicException(this,
            "drb:insertInto() : error while evaluating the first parameter");
      }

      if (target_sequence.getLength() != 1)
      {
         throw new DynamicException(this,
            "drb:insertInto() : first parameter must be a single element node "
                  + "or a single document node. Found a sequence of "
                  + target_sequence.getLength() + " item(s)");
      }

      final DrbItem target_item = target_sequence.getItem(0);

      if (target_item.getItemType() != DrbItem.NODE_ITEM)
      {
         throw new DynamicException(this,
            "drb:insertInto() : first parameter is not a single element node "
                  + "or a single document node");
      }

      final DrbNode target_node = (DrbNode) target_item;

      /**
       * Get the insertion sequence from parameter. This parameter is mandatory.
       */
      final Expression content_expr = (Expression) this.parameters.get(1);

      if (content_expr == null)
      {
         throw new DynamicException(this,
            "drb:insertInto() operation requires a content " + "parameter");
      }

      final DrbSequence content_sequence = content_expr.evaluate(context);

      if (content_sequence == null)
      {
         throw new DynamicException(this,
            "drb:insertInto() : error while evaluating the content parameter");
      }

      for (int ichild = 0; ichild < content_sequence.getLength(); ichild++)
      {
         final DrbItem content_item = content_sequence.getItem(ichild);
         if (content_item instanceof DrbNode)
         {
            target_node.appendChild((DrbNode) content_item);
         }
      }

      /**
       * Builds the output sequence of strings.
       */
      final DrbDefaultSequence output_sequence = new DrbDefaultSequence();

      /**
       * Returns the evaluation.
       */
      return (output_sequence);
   } /* insertIntoAsLast */
   
   
   private DrbSequence path (final DynamicContext context)
   {
      /**
       * Get the target node from first parameter. This parameter is mandatory
       * and shall be evaluable as an element node.
       */
      final Expression target_expr = (Expression) this.parameters.get(0);

      if (target_expr == null)
      {
         throw new DynamicException(this,
            "drb:path() operation requires a node as first parameter.");
      }

      final DrbSequence target_sequence = target_expr.evaluate(context);

      if (target_sequence == null)
      {
         throw new DynamicException(this,
            "drb:path() : error while evaluating the first parameter");
      }

      if (target_sequence.getLength() != 1)
      {
         throw new DynamicException(this,
            "drb:path() : first parameter must be a single element node "
                  + "or a single document node. Found a sequence of "
                  + target_sequence.getLength() + " item(s)");
      }

      final DrbItem element = target_sequence.getItem(0);

      if (element.getItemType() != DrbItem.NODE_ITEM)
      {
         throw new DynamicException(this,
            "drb:path() : first parameter is not a single element node "
                  + "or a single document node");
      }

      fr.gael.drb.value.String path = 
         new fr.gael.drb.value.String (((DrbNode)element).getPath()); 
      final DrbDefaultSequence output_sequence = new DrbDefaultSequence();
      output_sequence.addItem (path);
      
      return output_sequence;
   }

   /**
    * this method formats an ISO8601 formatted date to format output into
    * the specified format.
    *   1st parameter : the date to be parsed
    *   2nd parameter the expected output format (See Java Date format)
    * @param context
    * @return the string of the formatted date.
    */
   private DrbSequence iso8601DateFormatter (final DynamicContext context)
   {
      /**
       * Check parameters.
       */
      if ((this.parameters.size() != 2) && (this.parameters.size() != 3)) 
      {
         throw new DynamicException(this, this.functionName + 
            "(date, input_format, output_format) requires two parameter");
      }
      
      /**
       * First parameter : The date string from first parameter. 
       */
      final Expression iso_date_exp = (Expression) this.parameters.get(0);

      if (iso_date_exp == null)
      {
         throw new DynamicException(this, this.functionName + 
            "() operation requires a string as first parameter.");
      }
      

      final DrbSequence iso_date_sequence = iso_date_exp.evaluate(context);

      if (iso_date_sequence == null)
      {
         throw new DynamicException(this, this.functionName + 
            "() : error while evaluating the first parameter");
      }

      if (iso_date_sequence.getLength() != 1)
      {
         throw new DynamicException(this, this.functionName + 
            "() : first parameter must be a single element string "
                  + "Found a sequence of "
                  + iso_date_sequence.getLength() + " item(s)");
      }

      final DrbItem iso_date_item = iso_date_sequence.getItem(0);

      if (iso_date_item.getItemType() != DrbItem.VALUE_ITEM)
      {
         throw new DynamicException(this, this.functionName + 
            "() : first parameter is not a single element node "
                  + "or a single document node");
      }
      String iso_date = iso_date_item.toString ();

      // Second parameter: format string
      final Expression input_format_exp = (Expression) this.parameters.get(1);

      if (input_format_exp == null)
      {
         throw new DynamicException(this, this.functionName + 
            "() operation requires a string as second parameter.");
      }
      

      final DrbSequence input_format_sequence = input_format_exp.evaluate(context);

      if (input_format_sequence == null)
      {
         throw new DynamicException(this, this.functionName + 
            "() : error while evaluating the second parameter");
      }

      if (input_format_sequence.getLength() != 1)
      {
         throw new DynamicException(this, this.functionName + 
            "() : second parameter must be a single element string "
                  + "Found a sequence of "
                  + input_format_sequence.getLength() + " item(s)");
      }

      final DrbItem input_format_item = input_format_sequence.getItem(0);

      if (input_format_item.getItemType() != DrbItem.VALUE_ITEM)
      {
         throw new DynamicException(this, this.functionName + 
            "() : second parameter is not a single element node "
                  + "or a single document node");
      }
      String input_format = input_format_item.toString ();
      
      // Third parameter: output format string
      
      String output_format = null;
      if (this.parameters.size ()>2)
      {
         final Expression output_format_exp = (Expression) this.parameters.get(2);
         final DrbSequence output_format_sequence = output_format_exp.evaluate(context);

         if (output_format_sequence == null)
         {
            throw new DynamicException(this, this.functionName + 
               "() : error while evaluating the third parameter");
         }

         if (output_format_sequence.getLength() != 1)
         {
            throw new DynamicException(this, this.functionName + 
               "() : third parameter must be a single element string "
                     + "Found a sequence of "
                     + output_format_sequence.getLength() + " item(s)");
         }

         final DrbItem output_format_item = output_format_sequence.getItem(0);

         if (output_format_item.getItemType() != DrbItem.VALUE_ITEM)
         {
            throw new DynamicException(this, this.functionName + 
               "() : second parameter is not a single element node "
                     + "or a single document node");
         }
         output_format = output_format_item.toString ();
      }
      else
         output_format="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
         
      // Computes the passed date
      SimpleDateFormat odf = new SimpleDateFormat (output_format);
         
      String date;
      try
      {
         long time = toMilliseconds (checkMonth(iso_date), input_format);
         date = odf.format (new Date (time));
      }
      catch (ParseException e)
      {
         throw new DynamicException(this, this.functionName + 
            "() : " + e.getMessage ());
      }
      
      // Computes return value
      final DrbDefaultSequence output_sequence = new DrbDefaultSequence();
      output_sequence.addItem (new fr.gael.drb.value.String(date));
      return output_sequence;
   }
   
   private String checkMonth (String date)
   {
      // Look at the months
      String[]months={"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};
      String[]iso_months={"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
      
      String modified_date = date;
      for (int index=0; index<months.length; index++)
      {
         int pos = date.indexOf (months[index]); 
         if (pos == -1) continue;
         
         modified_date = date.substring (0, pos) + iso_months[index] +
            date.substring (pos + months[index].length ()); 
         break;
      }
      return modified_date;
   }
   private long toMilliseconds (String date, String format) throws ParseException
   {
      // Case of pattern not XXXss.SSS(S)*'Z'
      if (!format.matches (".*\\.S{4,}('Z')?"))
      {
         SimpleDateFormat df = new SimpleDateFormat (format, Locale.US);
         long time = df.parse (date).getTime (); 
         return time;
      }
      
      // Case of no micro value
      String micro="0000";
      if (date.contains ("."))
      {
         micro = date.replaceAll (".*\\.(\\d*)Z?", "$1");   
      }
      String modified_date = date.replaceAll ("(.*)(\\.\\d*)?Z?", "$1");
      String modified_format = format.replaceAll ("(.*)\\.S+('Z')?", "$1");
      
      // Checks substitutions
      if ((modified_date==null) || (modified_format==null) ||
          "".equals (modified_date) || "".equals (modified_format))
      {
         throw new ParseException (this.functionName + 
            "() : Cannot parse date \"" + date + 
            "\" with format \"" + format + "\"", 0);
      }
          

      long milli = 0;
      if (!"".equals (micro))
      {
         if (micro.length () > 6) micro = micro.substring (0, 5);
         milli = (long)(java.lang.Float.parseFloat ("0." + micro) * 1000f);
      }
      
      SimpleDateFormat df = new SimpleDateFormat (modified_format, Locale.US);
      long time;
      try
      {
         time = df.parse (modified_date).getTime () + milli;
      }
      catch (ParseException e)
      {
         throw new ParseException (this.functionName + 
            "() : Cannot parse date \"" + modified_date + 
            "\" with format \"" + modified_format + "\" at " + 
            e.getErrorOffset (), e.getErrorOffset ());
      }
      return time;
   }
   
   
   /**
    * Returns a description of the function call.
    * 
    * @return the description of the function call.
    */
   public String toString()
   {
      String output = this.functionName + "(";

      for (int i = 0; i < this.parameters.size(); i++)
      {
         if (i != 0)
         {
            output = output + ", ";
         }

         output = output + this.parameters.get(i);
      }

      output = output + ")";

      return output;
   }
}
