/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

/**
 * Declaration of an XML-Schema particle.
 */
public abstract class XsdParticle extends XsdComponent implements
      NodeListValidator
{

   // ====================================================
   // Static part.
   // ====================================================
   /**
    * minOccurs tag.
    */
   final static String MIN_OCCURS_TAG = "minOccurs";

   /**
    * maxOccurs tag.
    */
   final static String MAX_OCCURS_TAG = "maxOccurs";

   /**
    * unbounded tag.
    */
   final static String UNBOUNDED_OCCURS_TAG = "unbounded";

   /**
    * Model Group term.
    */
   public final static int MODEL_GROUP_TERM = 1;

   /**
    * Element term.
    */
   public final static int ELEMENT_TERM = 2;

   /**
    * Wildcard term.
    */
   public final static int WILDCARD_TERM = 3;

   /**
    * Unbounded occurrence.
    */
   public final static Integer UNBOUNDED_OCCURS = java.lang.Integer.MAX_VALUE;

   // ============================================
   // Attributes part.
   // ============================================
   /**
    * minimum occurrence.
    */
   private int minOccurs = 1;

   /**
    * maximum occurrence.
    */
   private int maxOccurs = 1;

   // =============================================
   // Methods part.
   // =============================================
   /**
    * Build a particle.
    */
   protected XsdParticle()
   {
      this(1, 1);
   }

   /**
    * Build a particle.
    * 
    * @param minoccurs the min of the occurence
    * @param maxoccurs the max of the occurence
    */
   protected XsdParticle(final int minoccurs, final int maxoccurs)
   {
      this.minOccurs = minoccurs;
      this.maxOccurs = maxoccurs;
   }

   /**
    * Returns the minimum occurrence.
    * 
    * @return int minimum occurence
    */
   public final int getMinOccurs()
   {
      return this.minOccurs;
   }

   /**
    * Returns the maximum occurrence.
    * 
    * @return int maximum occurence
    */
   public final int getMaxOccurs()
   {
      return this.maxOccurs;
   }

   /**
    * Set the min and max occurs parameters.
    * 
    * @param minoccurs the min of the occurence
    * @param maxoccurs the max of the occurence
    */
   public void setOccurs(final int minoccurs, final int maxoccurs)
   {
      this.minOccurs = minoccurs;
      this.maxOccurs = maxoccurs;
   }

   /**
    * Returns true if this particle is nillable or false otherwise.
    * 
    * @return true or false
    */
   boolean isNillable()
   {
      return (this.getMinOccurs() == 0);
   } // isNillable

   /**
    * Returns the term attribute.
    * 
    * @return int
    */
   public abstract int getTerm();

} // XsdParticle
