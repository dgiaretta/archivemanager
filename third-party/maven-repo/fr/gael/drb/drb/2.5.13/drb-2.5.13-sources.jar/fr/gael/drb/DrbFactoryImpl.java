/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import java.net.URL;

/**
 * Common interface for Node factory implementations. All the classes
 * implementing this interface can be used by the DrbFactory class. As a
 * summary, the "Data Request Broker" (DRB) implementations are packages that
 * break down a specific data resource (e.g. an XML document, an HTML file, a
 * Zip archive, a database, etc.) into a tree of DrbNode instances.
 * <p>
 * As an example, an implementation may handle file systems, breaking down the
 * hard disk devices into directories and regular files. Another one may provide
 * nodes corresponding to the tables and records of a database.
 * </p>
 * <b>The factory implementations are supposed to be used by the DrbFactory
 * class and not outside.</b> It may however be useful to create DrbNodes
 * directly from a specific implementation disregarding the DrbFactory abstract
 * level. It is therefore recommended to be careful in such situation.
 * </p>
 * <p>
 * Here are some examples of direct use of this interface to open DrbNodes from
 * a path, maybe with an existing context. The following examples are not
 * supposed to work with existing implementations but intends to provides an
 * overview of the DrbFactoryImpl interface. Report to the implementations
 * specific documentations for an accurate description of their use:
 * </p>
 */
public interface DrbFactoryImpl
{

   /**
    * The scheme identifier of the implementation. This string is short name
    * identifying univocally the implementation regarding the others. Basically
    * the identifier shall be composed of lowercase characters and shall nearly
    * be composed of alpabetical characters. The returned identifier shall never
    * be null.
    * 
    * @return The identifier of the implementation.
    */
   public String getIdentifier();

   /**
    * The name of the implementation. This name is the full explicit name of the
    * implementation. Because other operations are supposed to provide
    * configuration management information, it is not necessary to embed any
    * version or release numbers in the name string. The returned name shall
    * never be null.
    * 
    * @return The name of the implementation.
    */
   public String getName();

   /**
    * Opens the node matching a given path. This operation creates and returns a
    * DrbNode corresponding to the given "Uniform Resource Identifier" (URI).
    * Because URL class provided by java.net package supports the URI
    * specifications, it has been used has URI parameter. The implementation is
    * supposed to be able to handle the URI with a default or absolute context.
    */
   public DrbNode open(URL uri);

   /**
    * Opens the node from an existing node. This operation creates and returns a
    * DrbNode using an existing node as base or context. The input DrbNode has
    * to be used as base of the creation. If the implementation is not able to
    * handle any input node, it shall always return null. The reference to the
    * input shall not be null.
    * 
    * @param base_node The input node to be used as context or base. This
    *           parameter shall not be null.
    * @return A root node or null if an error occured or if the implementation
    *         does not supports the input node.
    */
   public DrbNode open(DrbNode base_node);

   /**
    * Opens the node matching a given URI from an existing node. This operation
    * creates and returns a DrbNode corresponding to the given "Uniform Resource
    * Identifier" (URI) using an existing node as base or context. Because URL
    * class provided by java.net package supports the URI specifications, it has
    * been used has URI parameter. The input DrbNode has to be used as base of
    * the creation. If the implementation is not able to handle any input node,
    * it shall always return null even if it is able to use the passed URI
    * standalone. If the reference to the URI is null the operation works as the
    * open(DrbNode baseNode). Similary, if the URI reference is null, the
    * operation works as the open(URL uri).
    */
   public DrbNode open(URL uri, DrbNode base_node);

}// DrbFactoryImpl
