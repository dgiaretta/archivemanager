/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import fr.gael.drb.value.Value;

/**
 * Generic node interface. This interface represents a single node of a tree of
 * data. Any node can have no, one or several children.This interface provides
 * the primarily operations to browse an entire data structure. All
 * implementations of the "Data Request Broker" shall be able to produce such
 * nodes.
 */
interface DrbSimpleNode extends DrbItem
{
   /**
    * Name of the node. Returns the name of the node. This name is the canonical
    * name of the node It does not contains any prefix, path and location
    * part.This name clearly identifies the node in its parent depending only
    * from its occurrence number and its index. All nodes provided by an
    * implementation is named. Therefore this operation never returns null
    * value. An empty string is however allowed if the node is unique (e.g. non
    * named root node).
    * 
    * @return The name of the node.
    */
   public String getName();

   /**
    * Index of the node. Returns the index of the node in its parent children
    * list. This index starts from 0 and takes into account all occurrences of
    * nodes disregarding the type of nodes. If the node has not parent the index
    * may not be available: the operation returns therefore a negative value.
    * 
    * @return The index of the node or negative value.
    */
   public int getIndex();

   /**
    * Root node. Returns the root node of the holding the current one. If the
    * current node is already the root, the operation returns a reference to
    * itself. The root corresponds to the top level node. If the node is not
    * attached to a specific parent it has no root and therefore the current
    * operation returns null.
    * 
    * @return A reference to the root node or null.
    */
   public DrbNode getRoot();

   /**
    * The full path of the node. The full path of a node goes through the
    * implementations. Each implementation is supposed to keep the URI (or an
    * equivalent means)of its parent to fulfill this operation. The returned
    * path is canonical so it does not necessarily correspond to the path that
    * allowed the creation of the node. For instance the canonical path of a
    * node created with the URI "/step1/../step2/node" is "/step2/node".The full
    * path is an absolute path that begins with a "/". All steps are composed of
    * the name of the node (i.e. returned by getName()) and a possible qualifier
    * as defined in the XPath 2.0. For instance, if the implementation supports
    * multi-occurrences of a node, the canonical step shall contain the
    * occurrence number in a step qualifier (e.g "/step/node[2]/" ).
    * 
    * @return The absolute path of the current node.
    */
   public String getPath();

   /**
    * Get namespace URI. The namespace URI of this node, or null if it is
    * unspecified. This is not a computed value that is the result of a
    * namespace lookup based on an examination of the namespace declarations in
    * scope. It is merely the namespace URI given at creation time.
    * 
    * @return The namspace URI or null if unspecified.
    */
   public String getNamespaceURI();

   /**
    * The value type of the node. The node can embedded a particular value
    * according to the fr.gael.drb.value package. This operation returns the
    * type identifier of the content of the current node. The value of the node
    * depends on the implementation as well as on the node itself. If the node
    * does not contain any value, it shall return
    * fr.gael.drb.value.Value.NULL_ID identifier.
    * 
    * @return NULL_ID if the node does not provide value or any other valid type
    *         identifier otherwise.
    */
   public int getValueType();

   /**
    * The value of the node. The value of the node means its content. The value
    * is expressed according to one of the types supported by the
    * fr.gael.drb.value package. Generally these types correspond to primitive
    * types (e.g. integer, floating points etc.) or very low level types (e.g.
    * string, date, etc.).
    * 
    * @return A reference to the value of the node or null if the node does not
    *         contains any value.
    */
   public Value getValue();

   /**
    * The attributes of the nodes. This operation returns a list of attribute
    * owned by the current node is any.
    * 
    * @return The list attributes of the current node.
    */
   public DrbAttributeList getAttributes();

   /**
    * Returns an attribute matching a specific name.
    * 
    * @param name The name to match.
    * @return A reference to the attribute or null is not found.
    */
   public DrbAttribute getAttribute(String name);

   /**
    * Checks if any attribute exists. Returns whether the current node has at
    * least an attribute.
    * 
    * @return true if this node has any attribute, false otherwise.
    */
   // public boolean hasAttributes();
   /**
    * The parent of this node. Returns a reference to the parent node of the
    * current node according to the current implementation. Most of the nodes
    * have a parent except root nodes or if they have just been removed, etc. If
    * the node has no parent the operation returns null.
    * 
    * @return The parent of this node or null.
    */
   public DrbNode getParent();

   /**
    * The list of children of the current node. Returns a list of references to
    * the children of the current node. The current node may have no child and
    * the operation returns therefore a null reference.
    * 
    * @return The list of children if any null otherwise.
    */
   public DrbNodeList getChildren();

   /**
    * Checks if current node is parent of at least one child.
    * 
    * @return <code>true</code> if current node has at least one child,
    * <code>false</code> otherwise.
    */
   public boolean hasChild();

   /**
    * Returns an occurrence of child matching a specific name. The occurrence
    * number starts from 1. The name is a local name without any prefix.
    * 
    * @param name The name to match.
    * @param occurence The occurrence number of the desired child.
    * @return A reference to the child or <code>null</code> if not found.
    */
   public DrbNode getNamedChild(String name, int occurence);

   /**
    * Reference to the first child of the current node. If the current node has
    * no child a null reference if returned. The children order depends on the
    * implementation. This operation time performance depends therefore from the
    * implementation. However, the implementations shall try to prefer the
    * firstChild() performances against the lastChild() as far as possible.
    * 
    * @return A reference to the first child or null if no such node.
    */
   public DrbNode getFirstChild();

   /**
    * Reference to the last child of the current node. If the current node has
    * no child a null reference if returned. The children order depends on the
    * implementation. This operation time performance depends therefore from the
    * implementation. However, the implementations shall try to prefer the
    * firstChild() performances against the lastChild() as far as possible.
    * 
    * @return A reference to the last child or null if no such node.
    */
   public DrbNode getLastChild();

   /**
    * Reference to a specific child. The child is identified by its position
    * (i.e. index or sequence number) in the children list of this node. The
    * children order depends on the implementation. This operation time
    * performance depends therefore of this implementation.The provided index
    * start from 0 and shall not be greater or equal to the number of children.
    * If the current node has no child a null reference is returned.
    * 
    * @param index The position of the node to retrieve starting from 0 and not
    *           greater or equal to the number of children.
    * @return A reference to specified child or null if no such node.
    */
   public DrbNode getChildAt(int index);

   /**
    * Number of children. Returns the number of children belonging to the
    * current node. According to the implementation the computation of children
    * number may require more or less time. The number of children may actually
    * require to parse a big file if it is not constant among document
    * instances. It is therefore recommended to use this operation only if
    * required. It is preferable to browse the tree from first children to last
    * using getFirstChild() and getNextSibling() operations. If the current node
    * has no child, 0 is returned.
    * 
    * @return The number of children of the current node.
    */
   public int getChildrenCount();

   /**
    * Previous sibling of the current node. Returns a reference to the previous
    * node in the children list of current node parent. This reference may be
    * null if the current node has no parent or if it is the first child of its
    * parent. The reference may be null if the current node has no previous
    * sibling.
    * 
    * @return A reference to the previous sibling or null if no such node.
    */
   public DrbNode getPreviousSibling();

   /**
    * Next sibling of the current node. Returns a reference to the next node in
    * the children list of current node parent. This reference may be null if
    * the current node has no parent or if it is the last child of its parent.
    * The reference may be null if the current node has no next sibling.
    * 
    * @return A reference to the next sibling or null if no such node.
    */
   public DrbNode getNextSibling();
}// DrbSimpleNode
