/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.value.Numeric;
import fr.gael.drb.value.Value;

/**
 * Provides convenient/common implementation for predicates.
 */
class PredicatsListExpression extends AbstractExpression
{
   /**
    * Logger
    */
   static private Logger logger =
      Logger.getLogger(PredicatsListExpression.class);

   /**
    * Qualifiers of the variable.
    */
   List<Expression> predicates = new ArrayList<Expression>();

   /**
    * Build a PredicatListExpression
    * 
    * @param name Name of the expression
    * @param token Token related to the current expression.
    */
   public PredicatsListExpression(final String name, final Token token)
   {
      super(name, token);

   }

   /**
    * Appends a predicate.
    * 
    * @param expression the expression to append as predicate.
    */
   public void addPredicate(final Expression expression)
   {
      if (expression != null)
      {
         this.predicates.add(expression);
      }
      else
      {
         throw new DynamicException(this, "Cannot add null step predicate");
      }

   }

   /**
    * Test if the list of predicates has no elements
    * 
    * @return True is the list of predicates if empty, else false.
    */
   public boolean isEmpty()
   {
      return this.predicates.isEmpty();
   }

   /**
    * Evaluate all the predicates on the current item
    * 
    * @param context dynamic evaluation context.
    * @return true if all the predicate evaluations are true. false if one of
    *         the predicate evaluation is false.
    */
   public boolean accepts(final DynamicContext context)
   {
      for (int iqual = 0; iqual < this.predicates.size(); iqual++)
      {

         final Expression predicate = this.predicates.get(iqual);

         /**********************************************************************
          * Case where the predicate is a range expression, its not useful to
          * evaluate it
          *********************************************************************/
         if (predicate instanceof RangeExpression)
         {

            final RangeExpression range_predicate = (RangeExpression) predicate;
            if (!this.checkRangeExpression(context, range_predicate))
            {
               return false;
            }
            else
            {
               continue;
            }

         }

         /**********************************************************************
          * Case of a sequence expression: Browsing the sequence to check if
          * there are range expression
          *********************************************************************/
         if (predicate instanceof SequenceExpression)
         {

            boolean this_predicat_ok = false;
            final SequenceExpression sequence_predicate =
               (SequenceExpression) predicate;
            int i = -1;
            // getting each expression of the sequence
            for (final Iterator it = sequence_predicate.iterator(); it
                  .hasNext();)
            {
               i++;
               final Expression expr = (Expression) it.next();

               // its a range expression, no evaluation
               if (expr instanceof RangeExpression)
               {

                  // not in the range, continue to the next expression
                  if (!this.checkRangeExpression(context,
                        (RangeExpression) expr))
                  {
                     continue;
                  }
                  else
                  {
                     this_predicat_ok = true;
                     break;
                  }

               }
               // not a range, evaluation of the sequence
               else
               {
                  final DrbSequence result = expr.evaluate(context);

                  if (result.getLength() == 0)
                  {
                     continue;
                  }

                  if (result.getLength() > 1)
                  {
                     throw new DynamicException(this,
                           "Sequence inside predicats should contain only numeric value");
                  }

                  final DrbItem item = result.getItem(0);

                  // if its a NODE at the FIRST place , this predicat is true
                  if ((i == 0) && (item.getItemType() == DrbItem.NODE_ITEM))
                  {
                     this_predicat_ok = true;
                     break;
                  }

                  // here the result must be a numeric literal
                  if (!(item.getItemType() == DrbItem.VALUE_ITEM))
                  {
                     throw new DynamicException(this,
                           "Sequence inside predicats should contain only numeric value");
                  }

                  final Value value = (Value) item;

                  // its a numeric, we check the current position
                  if (value instanceof Numeric)
                  {
                     if (!value.equals(new fr.gael.drb.value.Int(context.focus
                           .getContextPosition())))
                     {
                        continue;
                     }
                     else
                     {
                        this_predicat_ok = true;
                        break;
                     }
                  }
                  // we don't accept something other than numerics inside
                  // sequence
                  else
                  {
                     throw new DynamicException(this,
                           "Sequence inside predicats should contain only numeric value");
                  }
               }
            }
            if (!this_predicat_ok)
            {
               return false;
            }
            else
            {
               continue;
            }

         }

         /**********************************************************************
          * Evaluation of the predicate
          *********************************************************************/
         final DrbSequence predicate_result = predicate.evaluate(context);

         if (predicate_result == null)
         {
            throw new DynamicException(this,
                  "Error while applying predicate (context: " + context + ")");
         }

         /**
          * Cases where we must calculate the EBV
          */

         /**
          * Empty sequence
          */
         if ((predicate_result.getLength() == 0))
         {
            if (!Query.getEffectiveBooleanValue(predicate_result))
            {
               return false;
            }
            else
            {
               continue;
            }
         }

         /**
          * A sequence where the first item is a node
          */
         DrbItem predicate_item = predicate_result.getItem(0);

         if (predicate_item != null)
         {
            if (predicate_item.getItemType() == DrbItem.NODE_ITEM)
            {
               if (!Query.getEffectiveBooleanValue(predicate_result))
               {
                  return false;
               }
               else
               {
                  continue;
               }
            }
         }

         /**
          * Case of only one item
          */
         if (predicate_result.getLength() == 1)
         {

            predicate_item = predicate_result.getItem(0);

            if (predicate_item != null)
            {
               if (predicate_item.getItemType() == DrbItem.VALUE_ITEM)
               {
                  final Value value = (Value) predicate_item;

                  // its a numeric, we check the current position
                  if (value instanceof Numeric)
                  {
                     // if (((Numeric)value).intValue() !=
                     // (context.focus.getContextPosition()))
                     if (((Numeric) value).intValue() != context.focus
                           .getContextPosition())
                     {
                        return false;
                     }
                  }
                  // else we calculate the EBV
                  else
                  {
                     if (!Query.getEffectiveBooleanValue(predicate_result))
                     {
                        return false;
                     }
                  }
               }
               // else we calculate the EBV
               else
               {
                  if (!Query.getEffectiveBooleanValue(predicate_result))
                  {
                     return false;
                  }
               }
            }
         }
         /**
          * Browsing the sequence to compare position with items of the sequence
          */
         else
         {
            boolean this_predicat_ok = false;
            for (int i = 0; i < predicate_result.getLength(); i++)
            {

               final DrbItem item = predicate_result.getItem(i);

               // If its not a value, return false
               if (!(item.getItemType() == DrbItem.VALUE_ITEM))
               {
                  throw new DynamicException(this,
                        "Sequence inside predicats should contain only numeric value");
               }

               final Value value = (Value) item;

               // its a numeric, we check the current position
               if (value instanceof Numeric)
               {
                  if (!value.equals(new fr.gael.drb.value.Int(context.focus
                        .getContextPosition())))
                  {
                     continue;
                  }
                  else
                  {
                     this_predicat_ok = true;
                     break;
                  }
               }
               // we dont accept something other than numerics inside sequence
               else
               {
                  throw new DynamicException(this,
                        "Sequence inside predicats should contain only numeric value");
               }
            }
            if (!this_predicat_ok)
            {
               return false;
            }
         }

      }
      return true;
   } // accepts

   /**
    * Evaluate all the predicates on the current item
    * 
    * @param context dynamic evaluation context.
    * @return A singleton containing the effectiveBooleanValue True if all the
    *         predicate evaluations are true. False if one of the predicate
    *         evaluation is false.
    */
   public final DrbSequence evaluate(final DynamicContext context)
   {
      if (this.accepts(context))
      {
         return LiteralResult.TRUE;
      }
      else
      {
         return LiteralResult.FALSE;
      }
   } // evaluate

   /**
    * When there are predicates with literals or range expressions inside the
    * list, we can limit the predicates evaluation on items of the sequence,
    * instead of browsing the whole sequence. This method browse the predicats
    * list and calculate these limits.
    * 
    * @param positions An array containing 2 int, the first one (int[0])
    *           containing the min limit and the second one (int[1]) containing
    *           the max limit
    * @param context Dynamic context of the evaluation
    * @return true if its worth to continue evaluation, or false if limits are
    *         such as we can stop evaluation of items, for none of those will be
    *         convenient regarding its position.
    */
   public boolean getEvaluationLimit(final DynamicContext context,
         final int[] positions)
   {

      Integer min_position = 1;
      Integer max_position = java.lang.Integer.MAX_VALUE;

      Integer current_min = 1;
      Integer current_max = java.lang.Integer.MAX_VALUE;

      for (int iqual = 0; iqual < this.predicates.size(); iqual++)
      {

         final Expression predicate = this.predicates.get(iqual);

         /**
          * getting the limit of the range expression
          */
         if (predicate instanceof RangeExpression)
         {
            final RangeExpression range_predicate = (RangeExpression) predicate;

            current_min = range_predicate.getMinimumValue(context).intValue();
            current_max = range_predicate.getMaximumValue(context).intValue();
         }
         /**
          * getting the value of the literal numeric
          */
         else if (predicate instanceof LiteralExpression)
         {

            final DrbSequence sequence = predicate.evaluate(context);

            /**
             * Only one item in the sequence
             */
            if (sequence.getLength() == 1)
            {

               final DrbItem item = sequence.getItem(0);

               // its a numeric, we get its value
               if (item.getItemType() == DrbItem.VALUE_ITEM)
               {
                  final Value value = (Value) item;

                  if (value instanceof Numeric)
                  {
                     current_min = ((Numeric) value).intValue();
                     current_max = current_min;

                  }
                  else
                  {
                     continue;
                  }

               }
               else
               {
                  continue;
               }

            }
            // the size of the sequence > 1, goto the next predicates
            else
            {
               continue;
            }

         }// end else not a range nor a literal
         else
         {
            continue;
         }

         // tests the different cases of intersection btw the two sets
         /**
          * Cases of no intersection
          */
         if ((current_min > max_position) || (min_position > current_max))
         {
            return false;
         }

         /**
          * Cases of total inclusion of one set into another
          */
         if ((min_position >= current_min) && (max_position <= current_max))
         {
            ;
         }
         else if ((current_min >= min_position)
               && (current_max <= max_position))
         {
            min_position = current_min;
            max_position = current_max;
         }
         /**
          * Cases of intersection not null
          */
         else if ((current_min >= min_position)
               && (current_max >= max_position))
         {
            min_position = current_min;
         }
         else if ((current_min <= min_position)
               && (current_max <= max_position))
         {
            max_position = current_max;
         }
      }// end for

      positions[0] = min_position;
      positions[1] = max_position;

      return true;
   }

   /**
    * Check is the context position of the context item is inside the range
    * 
    * @param context The dynamic context of evaluation
    * @param expr The range expression
    * @return True if the context position of the context item is inside the
    *         range
    */
   private boolean checkRangeExpression(final DynamicContext context,
         final RangeExpression expr)
   {

      if ((context == null) || (expr == null))
      {
         return false;
      }

      int min_position;
      int max_position;

      // getting the minimum of the range
      if (expr.isMinimumConstant())
      {
         min_position = (int) expr.getMinimumValue();
      }
      else
      {
         min_position = expr.getMinimumValue(context).intValue();
      }

      // getting the maximum of the range
      if (expr.isMaximumConstant())
      {
         max_position = (int) expr.getMaximumValue();
      }
      else
      {
         max_position = expr.getMaximumValue(context).intValue();
      }

      // checking the position is inside the range
      if (!((context.focus.getContextPosition() >= min_position) && (context.focus
            .getContextPosition() <= max_position)))
      {
         return false;
      }
      else
      {
         return true;
      }

   }

   /**
    * A expression which is constant means that it need no context item to be
    * evaluate. The returned sequence from its evaluation will always be the
    * same along the query script
    * 
    * @return true if this expression is constant
    */
   public boolean isConstant()
   {

      boolean bool = true;

      for (final Iterator it = this.predicates.iterator(); it.hasNext();)
      {
         bool = bool && (((Expression) it.next()).isConstant());
      }
      return bool;
   }

   /**
    * Returns a detailed description of the predicats list.
    * 
    * @return the description of the predicats list.
    */
   public String toString()
   {

      String s = "";

      for (final Iterator i = this.predicates.iterator(); i.hasNext();)
      {
         s += "[" + i.next() + "]";
      }

      return s;
   }
}
