/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.awt.Color;
import java.awt.Font;
import java.io.Serializable;

import javax.swing.text.Style;

/**
 * Simple class to represent a lexical token. This wraps the
 * QueryParserConstants used by the scanner to provide a convenient class that
 * can be stored as a attribute value.
 */
public class TokenElement implements Serializable
{
   /**
    * Key to be used in AttributeSet's holding a value of TokenElement.
    */
   public static final Object TOKEN_ATTRIBUTE = new AttributeKey();

   /**
    * String representation of the token.
    */
   String representation;

   /**
    * TokenElement scan value.
    */
   int scanValue;

   /**
    * TokenElement color value.
    */
   Color color = Color.black;

   /**
    * TokenElement font.
    */
   Font font = new Font("Monospaced", 0, 14);

   /**
    * TokenElement style.
    */
   Style style = null;

   /**
    * Creates a new token.
    * 
    * @param representation token human presentation.
    * @param scan_value token scan value.
    */
   TokenElement(final String representation, final int scan_value)
   {
      this.representation = representation;
      this.scanValue = scan_value;
   }

   /**
    * Creates a new token.
    * 
    * @param representation token human presentation.
    * @param color token color.
    */
   TokenElement(final String representation, final Color color)
   {
      this.representation = representation;
      if (color != null)
      {
         this.color = color;
      }
      this.scanValue = getScanValueForRepresentation(representation);
   }

   /**
    * Creates a new token.
    * 
    * @param representation token human presentation.
    * @param font token font.
    * @param color token color.
    */
   TokenElement(final String representation, final Font font, final Color color)
   {
      this.representation = representation;
      if (font != null)
      {
         this.font = font;
      }
      if (color != null)
      {
         this.color = color;
      }
      this.scanValue = getScanValueForRepresentation(representation);
   }

   /**
    * Creates a new token.
    * 
    * @param representation token human presentation.
    * @param scan_value token scan value.
    * @param font token font.
    * @param color token color.
    */
   TokenElement(final String representation, final int scan_value,
         final Font font, final Color color)
   {
      this.representation = representation;
      this.scanValue = scan_value;
      if (font != null)
      {
         this.font = font;
      }
      if (color != null)
      {
         this.color = color;
      }
   }

   /**
    * Loop on the token image list and retrieve the scan value.
    * 
    * @param name token human presentation.
    * @return the scan value of the representation. returns -1 if not found.
    */
   private static int getScanValueForRepresentation(final String name)
   {
      if (name == null)
      {
         return -1;
      }

      final String[] images = QueryParserConstants.tokenImage;

      if (images == null)
      {
         return -1;
      }

      for (int i_image = 0; i_image < images.length; i_image++)
      {
         final String current = images[i_image];

         if ((current != null) && (current.equals(name)))
         {
            return i_image;
         }
      }

      return -1;
   }

   /**
    * A human presentable form of the token, useful for things like lists,
    * debugging, etc.
    * 
    * @return the representation.
    */
   public String toString()
   {
      return this.representation;
   }

   /**
    * Numeric value of this token. This is the value returned by the scanner and
    * is the tie between the lexical scanner and the tokens.
    * 
    * @return the scan value.
    */
   public int getScanValue()
   {
      return this.scanValue;
   }

   /**
    * TokenElement color accessor.
    * 
    * @return the color.
    */
   public Color getColor()
   {
      return this.color;
   }

   /**
    * TokenElement font accessor.
    * 
    * @return the font.
    */
   public Font getFont()
   {
      return this.font;
   }

   /**
    * Sets the new font of this token.
    * 
    * @param new_font the font to be set.
    */
   public void setFont(final Font new_font)
   {
      this.font = new_font;
   }

   /**
    * Sets this token style.
    * 
    * @param style the style to be associated with this token.
    */
   public void setStyle(final Style style)
   {
      this.style = style;
   }

   /**
    * TokenElement style accessor.
    * 
    * @return the style associated with this token.
    */
   public Style getStyle()
   {
      return this.style;
   }

   /**
    * Specifies the category of the token as a string that can be used as a
    * label.
    * 
    * @return the string name of the category.
    */
   public String getCategory()
   {
      final String nm = this.getClass().getName();
      final int nmStart = nm.lastIndexOf('.') + 1; // not found results in 0
      return nm.substring(nmStart, nm.length());
   }

   /**
    * Returns a hashcode for this set of attributes.
    * 
    * @return a hashcode value for this set of attributes.
    */
   public final int hashCode()
   {
      return this.scanValue;
   }

   /**
    * Compares this object to the specifed object. The result is
    * <code>true</code> if and only if the argument is not <code>null</code>
    * and is a <code>Font</code> object with the same name, style, and point
    * size as this font.
    * 
    * @param obj the object to compare this font with.
    * @return <code>true</code> if the objects are equal; <code>false</code>
    *         otherwise.
    */
   public final boolean equals(final Object obj)
   {
      if (obj instanceof TokenElement)
      {
         final TokenElement t = (TokenElement) obj;
         return (this.scanValue == t.scanValue);
      }
      return false;
   }

   /**
    * Attributes key object.
    */
   static class AttributeKey
   {
      /**
       * Builds a new instance.
       */
      private AttributeKey()
      {
      }

      /**
       * String representation accessor.
       * 
       * @return "token".
       */
      public String toString()
      {
         return "token_element";
      }
   }
}
