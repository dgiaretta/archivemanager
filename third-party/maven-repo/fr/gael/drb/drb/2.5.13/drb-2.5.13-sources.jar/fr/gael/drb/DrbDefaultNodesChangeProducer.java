/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import javax.swing.event.EventListenerList;

/**
 * A basic implementation of the DrbNodesChangeProducer. This implementation is
 * useful to avoid the manageent of listener lists. If the target class does not
 * extends any other, the DrbDefaultNodesChangeProducer may be directly extened
 * providing both the DrbNodesChangeProducer implementation and the code
 * managing the listener. If the target class already extends another one, the
 * DrbDefaultNodesChangeProducer may be aggregated and the oprtations of the
 * DrbNodesChangeProducer wrapped to the aggregat. These two options minimize
 * the duplication of code dedicated to the management of node change events.
 */
public class DrbDefaultNodesChangeProducer implements DrbNodesChangeProducer,
      DrbNodesChangeListener
{

   /**
    * The list of listeners.
    */
   private EventListenerList listenerList;

   /**
    * Getter of the EventListenerList
    * 
    * @return EventListenerList
    */
   public EventListenerList getListenerList()
   {
      return this.listenerList;
   }

   /**
    * Setter of the EventListenerList
    * 
    * @param list The EventListenerList
    */
   public void setListenerList(final EventListenerList list)
   {
      this.listenerList = list;
   }

   /**
    * Builds a default node change producer. This operation only initializes the
    * listener list.
    */
   public DrbDefaultNodesChangeProducer()
   {
      this.listenerList = new EventListenerList();
   }

   /**
    * Adds a listener to the list. This operations delegates to the add() of the
    * EventListenerList attribute The passed listener shall never be null;
    * 
    * @param listener The listener to be added in the list.
    */
   public void addNodesChangeListener(final DrbNodesChangeListener listener)
   {
      if (listener != null)
      {
         this.listenerList.add(DrbNodesChangeListener.class, listener);
      }
   }

   /**
    * Removes a listener from the list. This operation delegates to the remove()
    * of the EventListenerList attribute. The passed listener shall never be
    * null.
    * 
    * @param listener The listener to be removed in the list.
    */
   public void removeNodesChangeListener(final DrbNodesChangeListener listener)
   {
      if (listener != null)
      {
         this.listenerList.remove(DrbNodesChangeListener.class, listener);
      }
   }

   /**
    * Dispatches the received node change event to all the listener. The event
    * is not dispatched if the passed reference is null. If null the operation
    * does nothing.
    * 
    * @param event A reference to the event to dispatch.
    */
   public void nodesChanged(final DrbNodesChangeEvent event)
   {
      if (event != null)
      {
         final Object[] listeners = this.listenerList.getListenerList();

         final int count = listeners.length - 1;

         for (int i = 0; i < count; i += 2)
         {
            if (listeners[i] == DrbNodesChangeListener.class)
            {
               ((DrbNodesChangeListener) listeners[i + 1]).nodesChanged(event);
            }
         }
      }
   }

   /**
    * Dispatches the received node insertion event to all the listener. The
    * event is not dispatched if the passed reference is null. If null the
    * operation does nothing.
    * 
    * @param event A reference to the event to dispatch.
    */
   public void nodesInserted(final DrbNodesChangeEvent event)
   {
      if (event != null)
      {
         final Object[] listeners = this.listenerList.getListenerList();

         final int count = listeners.length - 1;

         for (int i = 0; i < count; i += 2)
         {
            if (listeners[i] == DrbNodesChangeListener.class)
            {
               ((DrbNodesChangeListener) listeners[i + 1]).nodesInserted(event);
            }
         }
      }
   }

   /**
    * Dispatches the received node removal event to all the listener. The event
    * is not dispatched if the passed reference is null. If null the operation
    * does nothing.
    * 
    * @param event A reference to the event to dispatch.
    */
   public void nodesRemoved(final DrbNodesChangeEvent event)
   {
      if (event != null)
      {
         final Object[] listeners = this.listenerList.getListenerList();

         final int count = listeners.length - 1;

         for (int i = 0; i < count; i += 2)
         {
            if (listeners[i] == DrbNodesChangeListener.class)
            {
               ((DrbNodesChangeListener) listeners[i + 1]).nodesRemoved(event);
            }
         }
      }
   }

   /**
    * Dispatches the received structure change event to all the listener. The
    * event is not dispatched if the passed reference is null. If null the
    * operation does nothing.
    * 
    * @param event A reference to the event to dispatch.
    */
   public void structureChanged(final DrbNodesChangeEvent event)
   {
      if (event != null)
      {
         final Object[] listeners = this.listenerList.getListenerList();

         final int count = listeners.length - 1;

         for (int i = 0; i < count; i += 2)
         {
            if (listeners[i] == DrbNodesChangeListener.class)
            {
               ((DrbNodesChangeListener) listeners[i + 1])
                     .structureChanged(event);
            }
         }
      }
   }
} // DrbDefaultNodesChangeProducer
