/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultMutableNode;
import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.value.Value;

/**
 * Declaration of an XML-Schema model group.
 */
public class XsdModelGroup extends XsdParticle
{

   // =============================================
   // Static part.
   // =============================================
   /**
    * Sequence model tag.
    */
   final static String SEQUENCE_TAG = "sequence";

   /**
    * Choice model tag.
    */
   final static String CHOICE_TAG = "choice";

   /**
    * All model tag.
    */
   final static String ALL_TAG = "all";

   /**
    * Sequence model.
    */
   public final static int SEQUENCE_MODEL = 1;

   /**
    * Choice model.
    */
   public final static int CHOICE_MODEL = 2;

   /**
    * All model.
    */
   public final static int ALL_MODEL = 3;

   // ======================================
   // Attributes part.
   // ======================================
   /**
    * Content of this model group.
    */
   private XsdParticle[] content;

   /**
    * Compositor of this model group.
    */
   private int compositor = SEQUENCE_MODEL;

   // ========================================
   // Methods part.
   // ========================================
   /**
    * Build a model group.
    * 
    * @param minoccurs the minimum occurence
    * @param maxoccurs the maximum occurence
    * @param content the particle
    * @param compositor int
    */
   public XsdModelGroup(final int minoccurs, final int maxoccurs,
         XsdParticle[] content, final int compositor)
   {
      super(minoccurs, maxoccurs);
      if (content == null)
      {
         content = new XsdParticle[] {};
      }
      this.content = content;
      this.compositor = compositor;
   } // XsdModelGroup

   /**
    * Returns true if this particle is nillable or false otherwise.
    * 
    * @return boolean true or false
    */
   public final boolean isNillable()
   {
      if (this.getMinOccurs() == 0)
      {
         return true;
      }
      for (int i = 0; i < this.content.length; i++)
      {
         if (!this.content[i].isNillable())
         {
            return false;
         }
      }
      return true;
   } // isNillable

   /**
    * Returns the term attribute.
    * 
    * @return int
    */
   public final int getTerm()
   {
      return XsdParticle.MODEL_GROUP_TERM;
   } // getTerm

   /**
    * Returns the compositor of this model group.
    * 
    * @return int
    */
   public final int getCompositor()
   {
      return this.compositor;
   } // getCompositor

   /**
    * Returns the content of this model group.
    * 
    * @return XsdParticle[]
    */
   final XsdParticle[] getContent()
   {
      return this.content;
   } // getContent

   /**
    * Returns a particle of this model group.
    * 
    * @param index index
    * @return XsdParticle
    */
   public final XsdParticle getParticle(final int index)
   {
      if ((index < 0) || (index >= this.content.length))
      {
         return null;
      }
      else
      {
         return this.content[index];
      }
   } // getParticle

   /**
    * Returns the length of this model group.
    * 
    * @return int
    */
   public final int getLength()
   {
      return this.content.length;
   } // getLength

   /**
    * Performs an extension.
    * 
    * @param extension the extension
    * @return XsdModelGroup
    */
   XsdModelGroup deriveByExtension(final XsdModelGroup extension)
   {
      XsdParticle[] extcontent = null;
      int ext_compositor = this.getCompositor();
      int ext_min_occurs = this.getMinOccurs();
      int ext_max_occurs = this.getMaxOccurs();
      if (extension != null)
      {
         // The base shall be a sequence with occurrence equals to 1
         if ((extension.getCompositor() != this.getCompositor())
               || (this.getCompositor() != SEQUENCE_MODEL)
               || (this.getMinOccurs() != 1) || (this.getMaxOccurs() != 1))
         {
            // encapsulate base and extension into a sequence
            if (this.content.length > 0)
            {
               ext_compositor = SEQUENCE_MODEL;
               ext_min_occurs = 1;
               ext_max_occurs = 1;
               extcontent = new XsdParticle[2];
               extcontent[0] = this;
               extcontent[1] = extension;
            }
            else
            {
               ext_compositor = extension.getCompositor();
               ext_min_occurs = extension.getMinOccurs();
               ext_max_occurs = extension.getMaxOccurs();
               extcontent = extension.content;
            }
         }
         else
         {
            extcontent =
               new XsdParticle[this.content.length + extension.content.length];
            System.arraycopy(extension.content, 0, extcontent,
                  this.content.length, extension.content.length);
            System.arraycopy(this.content, 0, extcontent, 0,
                  this.content.length);
         }
      }
      else
      {
         extcontent = new XsdParticle[this.content.length];
         System.arraycopy(this.content, 0, extcontent, 0, this.content.length);
      }
      return new XsdModelGroup(ext_min_occurs, ext_max_occurs, extcontent,
            ext_compositor);
   } // deriveByExtension

   /**
    * Performs a restriction.
    * 
    * @param restriction the restriction
    * @return XsdModelGroup
    */
   XsdModelGroup deriveByRestriction(final XsdModelGroup restriction)
   {
      final XsdParticle[] rescontent = new XsdParticle[this.content.length];
      System.arraycopy(this.content, 0, rescontent, 0, this.content.length);
      int minoccurs = this.getMinOccurs();
      int maxoccurs = this.getMaxOccurs();

      if (restriction != null)
      {
         if (restriction.getCompositor() == this.getCompositor())
         {
            for (int i = 0; i < this.content.length; i++)
            {
               if (this.content[i] instanceof XsdElement)
               {
                  final XsdElement elti = (XsdElement) this.content[i];
                  if (elti.getName() == null)
                  {
                     continue;
                  }
                  for (int j = 0; j < restriction.content.length; j++)
                  {
                     if (restriction.content[j] instanceof XsdElement)
                     {
                        final XsdElement eltj =
                           (XsdElement) restriction.content[j];
                        if (elti.getName().equals(eltj.getName()))
                        {
                           final XsdElement newelt =
                              new XsdElement(eltj.getMinOccurs(), eltj
                                    .getMaxOccurs(), eltj.getName(), eltj
                                    .getType());
                           final DrbDefaultNodeList nodelist =
                              new DrbDefaultNodeList();
                           if (elti.getExternalNodes() != null)
                           {
                              for (int k = 0; k < elti.getExternalNodes()
                                    .getLength(); k++)
                              {
                                 nodelist.add(elti.getExternalNodes().item(k));
                              }
                           }
                           if (eltj.getExternalNodes() != null)
                           {
                              for (int k = 0; k < eltj.getExternalNodes()
                                    .getLength(); k++)
                              {
                                 nodelist.add(eltj.getExternalNodes().item(k));
                              }
                           }
                           newelt.setExternalNodes(nodelist);
                           rescontent[i] = newelt;
                        }
                     }
                  }
               }
            }
            if (restriction.getMinOccurs() > minoccurs)
            {
               minoccurs = restriction.getMinOccurs();
            }
            if (restriction.getMaxOccurs() < maxoccurs)
            {
               maxoccurs = restriction.getMaxOccurs();
            }
         }
      }
      return new XsdModelGroup(minoccurs, maxoccurs, rescontent, this
            .getCompositor());
   } // deriveByExtension

   // -----------------------------------------------------
   // XsdComponent class overloading
   // ------------------------------------------------------
   /**
    * Format this component into a string.
    * 
    * @return DrbNode
    */
   DrbNode toNode()
   {
      String tag = "sequence";
      switch (this.compositor)
      {
         case SEQUENCE_MODEL:
            tag = SEQUENCE_TAG;
            break;
         case CHOICE_MODEL:
            tag = CHOICE_TAG;
            break;
      }
      final DrbNode groupnode = new DrbDefaultMutableNode(tag);
      groupnode.setNamespaceURI(Namespace.XML_SCHEMA_NAMESPACE);

      final DrbDefaultAttributeList attributes = new DrbDefaultAttributeList();
      if ((this.getMinOccurs() != 1) && (this.getMaxOccurs() != 0))
      {
         attributes.add(new DrbDefaultAttribute(MIN_OCCURS_TAG,
               new fr.gael.drb.value.Int(this.getMinOccurs()), groupnode));
      }
      if (this.getMaxOccurs() != 1)
      {
         attributes.add(new DrbDefaultAttribute(MAX_OCCURS_TAG,
               new fr.gael.drb.value.Int(this.getMaxOccurs()), groupnode));
      }
      groupnode.setAttributes(attributes);
      if (this.content != null)
      {
         for (int i = 0; i < this.content.length; i++)
         {
            final DrbNode particlenode = this.content[i].toNode();
            if (particlenode != null)
            {
               groupnode.appendChild(particlenode);
            }
         }
      }

      return groupnode;
   } // toNode

   // -------------------------------------------------------------
   // NodeListValidator interface implementation
   // -------------------------------------------------------------
   /**
    * Validates this node list.
    * 
    * @param nodelist nodeList
    * @return XsdInvalid
    */
   public XsdInvalid isValid(DrbNodeList nodelist)
   {
      // Node list must not be null
      if (nodelist == null)
      {
         nodelist = new DrbDefaultNodeList();
      }
      final XsdInvalidModelGroup invalid =
         new XsdInvalidModelGroup(nodelist, this, 0, 0, 0);
      // Check children
      if (this.search(nodelist, 0, invalid) == nodelist.getLength())
      {
         return null;
      }
      return invalid;
   }

   /**
    * Search a pattern in the list.
    * 
    * @param nodelist DrbNodeList
    * @param start int
    * @return int
    */
   public int search(final DrbNodeList nodelist, final int start)
   {
      return this.search(nodelist, start, new XsdInvalidModelGroup(nodelist,
            this, start, start, 0));
   } // search

   /**
    * Search a pattern in the list.
    * 
    * @param nodelist DrbNodeList
    * @param start int
    * @param invalid XsdInvalidModelGroup
    * @return int
    */
   int search(DrbNodeList nodelist, final int start,
         final XsdInvalidModelGroup invalid)
   {
      // Node list must not be null
      if (nodelist == null)
      {
         nodelist = new DrbDefaultNodeList();
      }
      if (start < 0)
      {
         return -1;
      }

      // Check children
      int occurs = 0;
      int startindex = start, endindex = start;
      while ((startindex < nodelist.getLength())
            && (occurs < this.getMaxOccurs()))
      {
         /*
          * DEBUG System.err.println("Model Group: occurs=" + occurs + " index=" +
          * endindex + " compositor=" + getCompositor()); DEBUG
          */
         switch (this.getCompositor())
         {
            case SEQUENCE_MODEL:
               for (int i = 0; i < this.content.length; i++)
               {
                  invalid.setStopParticle(i);
                  /*
                   * DEBUG System.err.println("Sequence Model: particle=" + i + "
                   * index=" + endindex + " -> " + nodelist.item(endindex));
                   * DEBUG
                   */
                  final int newendindex =
                     this.content[i].search(nodelist, endindex);
                  if (newendindex < endindex)
                  {
                     invalid.setStopIndex(endindex);
                     return -1;
                  }
                  invalid.setStopIndex(newendindex);
                  if ((newendindex == endindex)
                        && (!this.content[i].isNillable()))
                  {
                     endindex = startindex; // cancel matching
                     break;
                  }
                  endindex = newendindex;
               }
               break;

            case CHOICE_MODEL:
               invalid.setStopIndex(startindex);
               invalid.setStopParticle(-1);
               for (int i = 0; i < this.content.length; i++)
               {
                  final int curendindex =
                     this.content[i].search(nodelist, startindex);
                  if (curendindex < startindex)
                  {
                     continue;
                  }
                  if (curendindex > endindex)
                  {
                     invalid.setStopParticle(i);
                     endindex = curendindex;
                     /*
                      * DEBUG System.err.println("Choice Model: found particle=" +
                      * i + " index=[" + startindex + " to " + (curendindex - 1) + "] -> " +
                      * nodelist.item(curendindex - 1)); DEBUG
                      */
                  }
               }
               /*
                * DEBUG if (invalid.stopParticle < 0) {
                * System.err.println("Choice Model: index=" + startindex + " not
                * found -> " + nodelist.item(startindex)); } DEBUG
                */
               break;
         }
         if (endindex < startindex)
         {
            return -1;
         }
         // Check occurrence
         if (startindex == endindex)
         {
            break;
         }
         occurs++;
         startindex = endindex;
      }
      if ((occurs < this.getMinOccurs())
            && !((occurs == 0) && this.isNillable()))
      {
         /*
          * DEBUG System.err.println("Model Group: occurs=" + occurs + "
          * Unexpected end of group." + " compositor=" + getCompositor()); DEBUG
          */
         occurs = 0;
         endindex = start;
         return -1;
      }

      return endindex;
   } // search

   // =======================================
   // Unitary test part.
   // =======================================
   /**
    * Makes this class runnable for testing.
    * 
    * @param args String[]
    */
   public static void main(final String[] args)
   {
      System.out.println("Loading ...");
      System.out.println("   <xsd:element name='toto' type='point'/>\n");
      System.out.println("   <xsd:complexType name='point'>");
      System.out.println("     <xsd:sequence>");
      System.out.println("       <xsd:element name='x' type='xsd:float'");
      System.out.println("                    minOccurs='1' maxOccurs='1'/>");
      System.out.println("       <xsd:element name='y' type='xsd:int'");
      System.out.println("                    minOccurs='0' maxOccurs='1'/>");
      System.out.println("       <xsd:element name='z' type='xsd:int'");
      System.out.println("                    minOccurs='0' maxOccurs='1'/>");
      System.out.println("     </xsd:sequence>");
      System.out.println("   </xsd:complexType>");

      final XsdAtomicType floattype = new XsdAtomicType(Value.FLOAT_ID, null);
      final XsdAtomicType inttype = new XsdAtomicType(Value.INTEGER_ID, null);
      final XsdElement xelt = new XsdElement(1, 1, "x", floattype);
      final XsdElement yelt = new XsdElement(0, 1, "y", inttype);
      final XsdElement zelt = new XsdElement(0, 1, "z", inttype);
      final XsdModelGroup group =
         new XsdModelGroup(1, 1, new XsdParticle[] { xelt, yelt, zelt },
               XsdModelGroup.SEQUENCE_MODEL);
      final XsdComplexType pointtype = new XsdComplexType("point", group, null);
      final XsdElement pointelt = new XsdElement(1, 1, "toto", pointtype);

      // 1: valid instance
      final DrbNode node1 = new DrbDefaultMutableNode("toto");
      final DrbNode node1x = new DrbDefaultMutableNode("x");
      node1x.setValue(new fr.gael.drb.value.Float(1.0f));
      node1.appendChild(node1x);
      final DrbNode node1y = new DrbDefaultMutableNode("y");
      node1y.setValue(new fr.gael.drb.value.Integer(2));
      node1.appendChild(node1y);
      System.out.println("\n\nChecking \n" + node1 + " -> "
            + pointelt.isValid(node1));
      // 2: invalid instance -> bad sequence
      final DrbNode node2 = new DrbDefaultMutableNode("toto");
      final DrbNode node2y = new DrbDefaultMutableNode("y");
      node2y.setValue(new fr.gael.drb.value.Integer(1));
      node2.appendChild(node2y);
      final DrbNode node2x = new DrbDefaultMutableNode("x");
      node2x.setValue(new fr.gael.drb.value.Float(2.0f));
      node2.appendChild(node1x);
      System.out.println("\n\nChecking \n" + node2 + " -> "
            + pointelt.isValid(node2));
      // 3: valid instance
      final DrbNode node3 = new DrbDefaultMutableNode("toto");
      final DrbNode node3x = new DrbDefaultMutableNode("x");
      node3x.setValue(new fr.gael.drb.value.Float(1.0f));
      node3.appendChild(node3x);
      System.out.println("\n\nChecking \n" + node3 + " -> "
            + pointelt.isValid(node3));
      // 4: invalid instance -> bad occurrence for x
      final DrbNode node4 = new DrbDefaultMutableNode("toto");
      final DrbNode node4x = new DrbDefaultMutableNode("x");
      node4x.setValue(new fr.gael.drb.value.Float(1.0f));
      node4.appendChild(node4x);
      node4.appendChild(node4x);
      System.out.println("\n\nChecking \n" + node4 + " -> "
            + pointelt.isValid(node4));
      // 5: valid instance
      final DrbNode node5 = new DrbDefaultMutableNode("toto");
      final DrbNode node5x = new DrbDefaultMutableNode("x");
      node5x.setValue(new fr.gael.drb.value.Float(1.0f));
      node5.appendChild(node5x);
      final DrbNode node5z = new DrbDefaultMutableNode("z");
      node5z.setValue(new fr.gael.drb.value.Integer(1));
      node5.appendChild(node5z);
      System.out.println("\n\nChecking \n" + node5 + " -> "
            + pointelt.isValid(node5));

   } // main

} // XsdModelGroup
