/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbNode;

/**
 * Writer block. This class provides the an implementation for writing block.<br>
 */
class WriterBlock extends DefaultBlock
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(WriterBlock.class);

   /**
    * The effective occurrence count for each child descriptor.
    */
   private int[] descOccurrenceCount;

   /**
    * Creates a new instance of DefaultBlock with descriptor and key. The
    * descriptor ans the key must not be null. The descriptor is used to get
    * information about the block such as name, offset, number of occurrences,
    * etc. The key is the path of the block in the descriptors tree.
    * 
    * @param descriptor The descriptor of the block.
    * @param key The key of the block.
    */
   protected WriterBlock(final Descriptor descriptor, final int[] key)
   {
      // Call superclass operation
      super(descriptor, key);

      this.descOccurrenceCount = new int[descriptor.getChildrenCount()];
      for (int i = 0; i < this.descOccurrenceCount.length; i++)
      {
         this.descOccurrenceCount[i] = 0;
         if (descriptor.getChildAt(i).getOccurrenceCountType() != PhysicalAttribute.FIXED)
         {
         }
      }
   }

   /**
    * Appends a child at the end of the children list. This implementation wraps
    * the appendChild() operation from the descriptor All values are recursively
    * written using the offsets and lengths corresponding to each block
    * descriptor and block occurrence. The order depends on the underlying
    * descriptor.
    * <p>
    * <b>Events:</b> No particular event is fired yet in this implementation.
    * </p>
    * 
    * @param node A reference to the node to be appended.
    * @return A reference to the node passed in parameter.
    * @throws NullPointerException This exception is raised when the passed node
    *            is a null reference.
    * @throws UnsupportedOperationException This exception is raised when the
    *            current block cannot accept any child or if the child name does
    *            not match any valid children name from the descriptor.
    */
   public DrbNode appendChild(final DrbNode node) throws NullPointerException,
         UnsupportedOperationException
   {
      // Checks the passed node
      if (node == null)
      {
         throw new NullPointerException("WriterBlock.appendChild(): "
               + "The reference to the node to append is null.");
      }
      // Loop on child descriptors until one occurrence is found.
      for (int i = 0; i < this.descriptor.getChildrenCount(); i++)
      {
         final Descriptor child_desc = this.descriptor.getChildAt(i);
         if (child_desc.isSame(node.getName()))
         {
            logger.debug("appendChild: occurs(" + node.getName() + ") = "
                  + this.descOccurrenceCount[i]);
         }
         if (child_desc.isSame(node.getName())
               && (this.descOccurrenceCount[i] < child_desc.getMaxOccurs()))
         {
            // If the child element has a fixed occurrence, we shall replace it
            // by the provided node.
            this.descOccurrenceCount[i]++;
            if (logger.isDebugEnabled())
            {
               logger.debug("WriterBlock.appendChild: occurs(" + node.getName()
                     + ") = " + this.descOccurrenceCount[i]);
            }
            try
            {
               if (logger.isDebugEnabled())
               {
                  logger
                        .debug("appendChild: replaced occurs "
                              + this.descOccurrenceCount[i] + " by "
                              + node.getName());
               }
               final int[] child_key =
                  IntMap.getChildKey(this.key, this.descOccurrenceCount[i] - 1);
               child_desc.create(node, child_key, false, 0);
               return new WriterBlock(child_desc, child_key);
            }
            catch (final java.io.IOException e)
            {
               throw new UnsupportedOperationException(this.descriptor
                     .getPath()
                     + ": replaceChild failed due to an I/O error ("
                     + e.getMessage() + ")");
            }
         }
      }
      throw new UnsupportedOperationException(this.descriptor.getPath()
            + ": appendChild failed.");
   }

   /*------------------------------------------------------------------------*/
   /* End of DrbMutableNode Interface */
   /*------------------------------------------------------------------------*/
}
