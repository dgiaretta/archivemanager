/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * The Boolean class is a generic wrapper for boolean values.
 */
public class Boolean extends AbstractValue implements Logic
{
   // ===========================================================================
   // Attributes part.
   // ===========================================================================
   /**
    * The Boolean priority.
    */
   final static int PRIORITY = 0;

   /**
    * The Boolean value.
    */
   private boolean value;

   // ===========================================================================
   // Methods part.
   // ===========================================================================
   /**
    * Allocates a Boolean object representing the value argument.
    * 
    * @param v the value of the Boolean.
    */
   public Boolean(final boolean v)
   {
      this.value = v;
   }

   /**
    * Allocates a Boolean object representing the value argument.
    * 
    * @param v the value of the Boolean.
    */
   public Boolean(final java.lang.String v)
   {
      if ((v.compareToIgnoreCase("true") == 0) || (v.equals("1")))
      {
         this.value = true;
      }
      if ((v.compareToIgnoreCase("false") == 0) || (v.equals("0")))
      {
         this.value = false;
      }
   }

   /**
    * Allocates a Boolean object representing the value argument.
    * 
    * @param v the value of the Boolean.
    */
   public Boolean(final int v)
   {
      this.value = (v != 0);
   }

   /**
    * Returns a String object representing this Boolean's value. If this object
    * represents the value true, a string equal to "true" is returned.
    * Otherwise, a string equal to "false" is returned.
    * 
    * @return a string representation of this object.
    */
   public java.lang.String toString()
   {
      return (this.value ? "true" : "false");
   }

   // --------------------------------------------------------------------------
   // Value interface implementation
   // ---------------------------------------------------------------------------
   /**
    * The type identifier of the value.
    * 
    * @return an identifier of the value type.
    */
   public final int getType()
   {
      return Value.BOOLEAN_ID;
   }

   /**
    * Return the Boolean priority.
    * 
    * @return the boolean priority.
    */
   public final int getPriority()
   {
      return PRIORITY;
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself should be returned. If the conversion is not allowed a
    * ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException if the conversion is impossible.
    */
   public final Value convertTo(final int type) throws ClassCastException
   {
      switch (type)
      {
         // Boolean -> Boolean conversion
         case BOOLEAN_ID:
            return this;

            // Boolean -> String conversion
         case Value.STRING_ID:
            return new String(this.toString());

         default:
            return new Int(this.value ? 1 : 0).convertTo(type);
      }
   }

   /**
    * Assign a new Value. An implicit conversion may be performed to make the
    * assignment. This assignment may result in a loss of precision (ex : float
    * to int).
    * 
    * @param v the new Value.
    */
   public void assign(final Value v)
   {
      final Boolean vb = (Boolean) v.convertTo(Value.BOOLEAN_ID);
      this.value = vb.booleanValue();
   }

   // --------------------------------------------------------------------------
   // Comparison interface implementation
   // --------------------------------------------------------------------------
   /**
    * Compare this value with another value. A ClassCastException is thrown if
    * the value is not a Boolean one.
    * 
    * @param x another value.
    * @return The returned value is :
    *         <ul>
    *         <li> negative if this value is lower than another value
    *         <li> zero if the two values are equal
    *         <li> positive if this value is greater than another value
    *         </ul>
    */
   public int compareTo(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Comparison) this.convertTo(x.getType())).compareTo(x);
      }
      final boolean b = ((Logic) x.convertTo(BOOLEAN_ID)).booleanValue();
      if (this.booleanValue() == b)
      {
         return 0;
      }
      return b ? -1 : +1;
   }

   // --------------------------------------------------------------------------
   // Logic interface implementation
   // --------------------------------------------------------------------------
   /**
    * Compute a Logical-AND.
    * 
    * @param x another value.
    * @return logical AND of the two values.
    */
   public final boolean and(final Value x)
   {
      return this.booleanValue() && ((Logic) x).booleanValue();
   }

   /**
    * Compute a logical OR.
    * 
    * @param x another value.
    * @return logical OR of the two values.
    */
   public final boolean or(final Value x)
   {
      return this.booleanValue() || ((Logic) x).booleanValue();
   }

   /**
    * Convert into a boolean value.
    * 
    * @return the equivalent boolean value.
    */
   public final boolean booleanValue()
   {
      return (this.value);
   }

   /**
    * Main
    * 
    * @param args the args
    */
   /*
    * public static void main(java.lang.String[] args) { Boolean b1 = new
    * Boolean(args[0]); Boolean b2 = new Boolean(args[1]);
    * System.err.println(b1.compareTo(b2)); }
    */
}
