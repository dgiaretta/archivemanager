/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * The UnsignedShort class is a generic wrapper for unsigned short values.
 */
public class UnsignedShort extends AbstractNumeric implements ValueFormat
{
   // TODO: the complete description of the short (e.g. value domain)
   // shall be provided in the header of this file.
   /**
    * The UnsignedShort priority.
    */
   final static int PRIORITY = 2;

   /**
    * The UnsignedShort value.
    */
   short value;

   /**
    * Builds an UnsignedShort object initialized to the specified short value.
    * 
    * @param value the value of the UnsignedShort.
    */
   public UnsignedShort(final short value)
   {
      this.value = value;
   }

   /**
    * Builds an UnsignedShort object initialized to the specified int value. A
    * cast is perform to fit the specified integer to the short representation.
    * The cast mechanism is the one of Java.
    * 
    * @param value the value of the Short.
    */
   public UnsignedShort(final int value)
   {
      this.value = (short) value;
   }

   /**
    * Prints the value of the Short in a character string.
    * 
    * @return a string representation of the short. The returned value cannot be
    *         null.
    */
   public java.lang.String toString()
   {
      return java.lang.Integer.toString((this.value & 0xffff));
   }

   /**
    * Returns a string containing the value with a fixed format.
    * 
    * @param length The expected length of the output string
    * @return The formatted string.
    */
   public java.lang.String getFormattedString(final int length)
   {
      return Short.getFormattedString(length, this.value, false);
   }

   /**
    * Returns a byte buffer containing the value in a fixed format.
    * 
    * @return The formatted buffer.
    */
   public byte[] getFormattedBuffer()
   {
      return Short.getFormattedBuffer(this.value);
   }

   /**
    * Returns the current Value type
    * 
    * @return the current Value type
    */
   public final int getType()
   {
      return Value.UNSIGNED_SHORT_ID;
   }

   /**
    * Returns the current Value priority.
    * 
    * @return the current Value priority
    */
   public final int getPriority()
   {
      return PRIORITY;
   }

   /**
    * In particular this operation that performs non obvious conversions. The
    * comment is an important spec for the DRB user.
    * 
    * @param type the type in which convert
    * @return the converted Value
    * @throws java.lang.ClassCastException if the conversion is impossible
    */
   public final Value convertTo(final int type)
         throws java.lang.ClassCastException
   {
      switch (type)
      {
         // UnsignedShort -> Short conversion
         case Value.UNSIGNED_SHORT_ID:
         case Value.NUMERIC_ID:
            return this;

            // UnsignedShort -> Unknown conversion
         default:
            return super.convertTo(type);
      }
   }

   /**
    * assign a new Value
    * 
    * @param v the new Value
    */
   public void assign(final Value v)
   {
      final Numeric vs = (Numeric) v.convertTo(Value.NUMERIC_ID);
      this.value = vs.shortValue();
   }

   /**
    * Returns a Value containing the opposite of the current Value.
    * 
    * @return a Value containing the opposite of the current Value.
    */
   public Value unaryMinus()
   {
      return new Short(-this.value);
   }

   /**
    * Adds the specified value to the current short value.
    * 
    * @param x another value.
    * @return the sum of the two values.
    */
   public final Value add(final Value x)
   {
      // TODO: incomplete operation comment. The algorithm shall be detailed.
      // TODO: bad name x.
      // TODO: x is not checked before use.
      // TODO: all internal comments shall be reviewed and aligned.
      // The comment type is wrong.
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).add(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final int sum = num.intValue() + this.intValue();
      // Check the integrity of the result
      if ((sum < -0x8000) || (sum > 0xffff))
      {
         return new Int(sum);
      }
      else if (sum < 0x8000)
      {
         return new Short((short) sum);
      }
      else
      {
         // unsigned short range
         return new UnsignedShort((short) sum);
      }
   }

   /**
    * Substracts the specified value to the current short value.
    * 
    * @param x another value.
    * @return the difference between the two values.
    */
   public Value sub(final Value x)
   {
      // TODO: incomplete operation comment. The algorithm shall be detailed
      // (e.g. when the result is negative).
      // TODO: bad name x.
      // TODO: x is not checked before use.
      // TODO: all internal comments shall be reviewed and aligned.
      // The comment type is wrong.
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).sub(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final int dif = this.intValue() - num.intValue();
      // Check the integrity of the result
      if ((dif < -0x8000) || (dif > 0xffff))
      {
         return new Int(dif);
      }
      else if (dif < 0x8000L)
      {
         return new Short((short) dif);
      }
      else
      {
         // unsigned int range
         return new UnsignedShort((short) dif);
      }
   }

   /**
    * Multiply the specified value by the current short value.
    * 
    * @param x another value.
    * @return the product of the two values.
    */
   public Value multiply(final Value x)
   {
      // TODO: incomplete operation comment. The algorithm shall be detailed
      // (e.g. when the result is negative).
      // TODO: bad name x.
      // TODO: x is not checked before use.
      // TODO: all internal comments shall be reviewed and aligned.
      // The comment type is wrong.
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).multiply(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final int prod = (this.intValue() * num.intValue());
      // Check the integrety of the result
      if ((prod < -0x8000) || (prod > 0xffff))
      {
         return new Int(prod);
      }
      else if (prod < 0x8000L)
      {
         return new Short((short) prod);
      }
      else
      {
         return new UnsignedShort((short) prod);
      }
   }

   /**
    * Divides the specified value by the current short value.
    * 
    * @param x another value.
    * @return the ratio of the two values.
    */
   public final Value divide(final Value x)
   {
      // TODO: incomplete operation comment. The algorithm shall be detailed
      // (e.g. when the result is negative or division by 0).
      // TODO: bad name x.
      // TODO: x is not checked before use.
      // TODO: all internal comments shall be reviewed and aligned.
      // The comment type is wrong.
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).divide(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final int div = (this.intValue() / num.intValue());
      // Check the integrety of the result
      if ((div < -0x8000) || (div > 0xffff))
      {
         return new Int(div);
      }
      else if (div < 0x8000)
      {
         return new Short((short) div);
      }
      else
      {
         return new UnsignedShort((short) div);
      }
   }

   /**
    * Compute the modulus of the current short value by the specified value.
    * 
    * @param x another value.
    * @return the modulus of the values.
    */
   public Value modulus(final Value x)
   {
      // TODO: incomplete operation comment. The algorithm shall be detailed.
      // TODO: bad name x.
      // TODO: x is not checked before use.
      // TODO: all internal comments shall be reviewed and aligned.
      // The comment type is wrong.
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).modulus(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final int mod = (this.intValue() % num.intValue());
      // Check the integrety of the result
      if ((mod < -0x8000) || (mod > 0xffff))
      {
         return new Int(mod);
      }
      else if (mod < 0x8000)
      {
         return new Short((short) mod);
      }
      else
      {
         return new UnsignedShort((short) mod);
      }
   }

   /**
    * compare the current value to the given one.
    * 
    * @param x the Value to compare
    * @return a negative number if the current value is greater, a positive
    *         number if the given value is greater, 0 if there are equal
    */
   public int compareTo(final Value x)
   {
      if (this.getPriority() >= x.getPriority())
      {
         return (this.intValue() - ((Numeric) x).intValue());
      }
      return -((Comparison) x).compareTo(this);
   }

   /**
    * indicates if the value is not 0
    * 
    * @return true if the value is not 0
    */
   public final boolean booleanValue()
   {
      return (this.value != 0);
   }

   // ------------------------------------------------------------------------
   // Numeric interface implementation
   // ------------------------------------------------------------------------
   // see interface Numeric for more informations

   /**
    * return the byte value.
    * 
    * @return the byte value
    */
   public final byte byteValue()
   {
      return (byte) this.value;
   }

   /**
    * return the int value.
    * 
    * @return the int value
    */
   public final int intValue()
   {
      return (this.value & 0xffff);
   }

   /**
    * return the long value.
    * 
    * @return the long value
    */
   public final long longValue()
   {
      return (this.value & 0xffffL);
   }

   /**
    * return the short value.
    * 
    * @return the short value
    */
   public final short shortValue()
   {
      return this.value;
   }

   /**
    * return the float value.
    * 
    * @return the float value
    */
   public final float floatValue()
   {
      return (this.value & 0xffff);
   }

   /**
    * return the double value.
    * 
    * @return the double value
    */
   public final double doubleValue()
   {
      return (this.value & 0xffff);
   }

   /**
    * assign a new boolean value
    * 
    * @param value the new value to assign
    */
   public final void assign(final boolean value)
   {
      this.value = (value ? (short) 1 : (short) 0);
   }

   /**
    * assign a new byte value
    * 
    * @param value the new value to assign
    */
   public final void assign(final byte value)
   {
      this.value = value;
   }

   /**
    * assign a new int value
    * 
    * @param value the new value to assign
    */
   public final void assign(final int value)
   {
      this.value = (short) value;
   }

   /**
    * assign a new short value
    * 
    * @param value the new value to assign
    */
   public final void assign(final short value)
   {
      this.value = value;
   }

   /**
    * assign a new long value
    * 
    * @param value the new value to assign
    */
   public final void assign(final long value)
   {
      this.value = (short) value;
   }

   /**
    * assign a new float value
    * 
    * @param value the new value to assign
    */
   public final void assign(final float value)
   {
      this.value = (short) value;
   }

   /**
    * assign a new double value
    * 
    * @param value the new value to assign
    */
   public final void assign(final double value)
   {
      this.value = (short) value;
   }

   // TODO: To be moved in a test class
   /*
    * public static void main(java.lang.String[] args) { UnsignedShort us = new
    * UnsignedShort(60000); UnsignedShort us2 = new UnsignedShort(5001);
    * System.out.println("us=" + us); System.out.println(us + " + " + us2 + " = " + (
    * us.add(us2))); System.out.println(us + " - " + us2 + " = " + (
    * us.sub(us2))); System.out.println(us + " * " + us2 + " = " + (
    * us.multiply(us2))); System.out.println(us + " / " + us2 + " = " + (
    * us.divide(us2))); System.out.println(us + " % " + us2 + " = " + (
    * us.modulus(us2))); }
    */
}
