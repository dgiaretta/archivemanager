/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAbstractNode;
import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbFactory;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.impl.xml.XmlFactory;
import fr.gael.drb.query.Query;
import fr.gael.drb.value.Value;

/**
 * The XML-Schema factory. The tags and attributes supported are listed below : -
 * complexType name type Content: (annotation?, (simpleContent | complexContent |
 * ((sequence | choice)?, attribute*))) - simpleType name Content: (annotation?,
 * (restriction | list | union)) - element name ref minOccurs maxOccurs type
 * Content: (annotation?, (complexType | simpleType)?) - attribute name type
 * default fixed value use Content: (annotation?, (simpleType?) - sequence
 * minOccurs maxOccurs Content: (annotation?, (element | sequence | choice))* -
 * choice minOccurs maxOccurs Content: (annotation?, (element | sequence |
 * choice))* - include schemaLocation - list itemType
 */
public class XsdFactory
{

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(XsdFactory.class);

   // =============================================
   // Attributes part.
   // =============================================
   /**
    * Context.
    */
   Context context;

   /**
    * Context class
    * 
    * @author Didier FRANCOIS
    */
   private static class Context
   {
      /**
       * Global element map.
       */
      HashMap globalTypeMap = new HashMap();

      /**
       * Global attribute map.
       */
      HashMap globalAttributeMap = new HashMap();

      /**
       * Global element map.
       */
      HashMap globalElementMap = new HashMap();

      /**
       * Namespace.
       */
      Namespace namespaces = new Namespace();

      /**
       * Type definition.
       */
      HashMap unresolvedTypeMap = new HashMap();

      /**
       * Attribute definition.
       */
      HashMap unresolvedAttributeMap = new HashMap();

      /**
       * Element definition.
       */
      HashMap unresolvedElementMap = new HashMap();

      /**
       * Included schema.
       */
      HashSet includeSet = new HashSet();

      /**
       * target namespace.
       */
      String targetNamespace = null;

      /**
       * Build a context with a specific schema.
       * 
       * @param xsd_schema the schema for schema.
       */
      Context(final XmlSchema xsd_schema)
      {
         if (xsd_schema != null)
         {
            final XsdType[] xsd_type = xsd_schema.getGlobalTypes();
            for (int i = 0; i < xsd_type.length; i++)
            {
               final XsdType type = xsd_type[i];
               this.globalTypeMap.put(type.getName(), type);
            }
         }
      } // Context

   } // Context

   // =================================================
   // Methods part.
   // =================================================
   /**
    * Initialize this factory.
    * 
    * @param xsd_schema the base schema definition
    */
   private void init(final XmlSchema base_schema)
   {
      this.context = new Context(base_schema);
   } // init

   /**
    * Resolve a type.
    * 
    * @param qname the name
    * @return The type
    */
   private XsdType resolveType(final String qname)
   {
      if (qname == null)
      {
         return null;
      }
      final String local_name = Namespace.toLocal(qname);
      XsdType type = (XsdType) this.context.globalTypeMap.get(local_name);
      if (type == null)
      {
         final DrbNode type_node =
            (DrbNode) this.context.unresolvedTypeMap.get(local_name);
         if (type_node == null)
         {
            logger.error("XsdFactory.resolveType : Type '" + local_name
                  + " unknown !");
            return null;
         }
         else if (XsdComplexType.TAG.equals(type_node.getName()))
         {
            type = new XsdComplexType(local_name, (XsdModelGroup) null, null);
            this.context.globalTypeMap.put(local_name, type);
            type = this.loadComplexType((XsdComplexType) type, type_node);
            // type = loadComplexType (null, type_node);
         }
         else if (XsdSimpleType.TAG.equals(type_node.getName()))
         {
            type = this.loadSimpleType(type_node);
         }
         else
         {
            logger.error("XsdFactory.resolveType : Type '" + local_name
                  + " unresolved !");
            return null;
         }
         this.context.unresolvedTypeMap.remove(local_name);
         if (type == null)
         {
            logger.error("XsdFactory.resolveType ->  '" + qname + "' null type");
         }
         else
         {
            this.context.globalTypeMap.put(type.getName(), type);
            type.setTargetNamespace(this.context.targetNamespace);
         }
      }
      return type;
   } // resolveType

   /**
    * Resolve an attribute.
    * 
    * @param qname the name
    * @return the attribute
    */
   private XsdAttribute resolveAttribute(final String qname)
   {
      final String local_name = Namespace.toLocal(qname);
      final String prefix_name = Namespace.toPrefix(qname);
      final String uri = this.context.namespaces.resolveNamespace(prefix_name);
      final XsdName xs_name = new XsdName(local_name, uri);
      XsdAttribute attribute_decl =
         (XsdAttribute) this.context.globalAttributeMap.get(local_name);
      if (attribute_decl == null)
      {
         final DrbNode attrib_node =
            (DrbNode) this.context.unresolvedAttributeMap.get(local_name);
         if (attrib_node == null)
         {
            logger.error("XsdFactory.resolveAttribute : Attribute '"
                  + local_name + " unknown !");
            return null;
         }
         else if (XsdAttribute.TAG.equals(attrib_node.getName()))
         {
            attribute_decl = this.loadAttribute(attrib_node);
         }
         else
         {
            logger.error("XsdFactory.resolveAttribute : Attribute '"
                  + local_name + " unresolved !");
            return null;
         }
         this.context.unresolvedAttributeMap.remove(local_name);
         if (attribute_decl == null)
         {
            logger.error("XsdFactory.resolveAttribute ->  '" + qname
                  + "' null attribute");
         }
         else
         {
            this.context.globalAttributeMap.put(attribute_decl.getName(),
                  attribute_decl);
            attribute_decl.setTargetNamespace(this.context.targetNamespace);
         }
      }
      return attribute_decl;
   } // resolveAttribute

   /**
    * Resolve a global element definition. The referenced element may declared
    * in the input schema or imported from an external schema file (see
    * xs:include and xs:import). As defined in the W3C recommendation, global
    * elements are located at the following XPath: /xs:schema/xs:element
    * 
    * @param qname the qualified name of the element definition.
    * @return the element definition or null if not found.
    */
   private XsdElement resolveElement(final String qname)
   {
      final String local_name = Namespace.toLocal(qname);
      final String prefix_name = Namespace.toPrefix(qname);
      final String uri = this.context.namespaces.resolveNamespace(prefix_name);
      final XsdName xs_name = new XsdName(local_name, uri);

      // This method solve an element definition in the following order:
      // 1. Try to find in the element cache
      // 2. Load the element from the pre-parsed schema (xsd file)
      XsdElement element_decl =
         (XsdElement) this.context.globalElementMap.get(xs_name);
      if (element_decl == null)
      {
         // Case of element that is used for the first time.
         // We must retrieve the xs:element node from the pre-parsed schema
         // Then, we create an instance of XsdElement class from the XML file.
         final DrbNode element_node =
            (DrbNode) this.context.unresolvedElementMap.get(xs_name);
         if (element_node == null)
         {
            // It is an error to reference an element that have not a global
            // visibility. The schema is corrupted or have missing components.
            if (!"http://www.w3.org/2001/XMLSchema".equals(uri))
            {
               logger.error("XsdFactory.resolveElement : Element '" + qname
                     + " unknown !");
            }
            return null;
         }
         else if (XsdElement.TAG.equals(element_node.getName()))
         {
            element_decl = this.loadElement(element_node);
         }
         else
         {
            logger.error("XsdFactory.resolveElement : Element '" + local_name
                  + " unresolved !");
            return null;
         }
         this.context.unresolvedElementMap.remove(local_name);
         if (element_decl == null)
         {
            logger.error("XsdFactory.resolveElement ->  '" + qname
                  + "' null element");
         }
         else
         {
            this.context.globalElementMap.put(element_decl.getName(),
                  element_decl);
            element_decl.setTargetNamespace(this.context.targetNamespace);
         }
      }
      return element_decl;
   } // resolveElement

   /**
    * Preload a schema
    * 
    * @param context the context
    * @param base the base node
    * @param schema the schema node
    */
   private void preloadSchema(final Context context, final DrbNode base,
         final DrbNode schema_file)
   {
      if (schema_file == null)
      {
         logger.error("Cannot preload XML Schema from a null node.",
               new NullPointerException());
         return;
      }
      
      DrbNode schema = schema_file.getFirstChild();

      /** Assert the baseNode is a schema */
      if (!XmlSchema.TAG.equals(schema.getName()))
      {
         // We are maybe already in the schema node
         schema = schema_file;
         if (!XmlSchema.TAG.equals(schema.getName()))
         {
            logger.error("XsdFactory.preloadSchema : '" + schema.getName()
                  + "' is not a valid schema.");
            return;
         }
      }

      // Load complexType
      for (int ioccurs = 1;; ioccurs++)
      {
         final DrbNode type_node =
            schema.getNamedChild(XsdComplexType.TAG, ioccurs);
         String type_name = null;
         if (type_node == null)
         {
            break;
         }
         final DrbAttributeList attribs = type_node.getAttributes();
         for (int i = 0; i < attribs.getLength(); i++)
         {
            final DrbAttribute attribute = attribs.item(i);
            final String attributeName = attribute.getName();
            if (XsdComplexType.NAME_TAG.equals(attributeName))
            {
               type_name = attribute.getValue().toString();
               break;
            }
         }
         if (type_name != null)
         {
            context.unresolvedTypeMap.put(Namespace.toLocal(type_name),
                  type_node);
         }
      }

      // Load simpleType
      for (int ioccurs = 1;; ioccurs++)
      {
         final DrbNode type_node =
            schema.getNamedChild(XsdSimpleType.TAG, ioccurs);
         String type_name = null;
         if (type_node == null)
         {
            break;
         }
         final DrbAttributeList attribs = type_node.getAttributes();
         for (int i = 0; i < attribs.getLength(); i++)
         {
            final DrbAttribute attribute = attribs.item(i);
            final String attributeName = attribute.getName();
            if (XsdSimpleType.NAME_TAG.equals(attributeName))
            {
               type_name = attribute.getValue().toString();
               break;
            }
         }
         if (type_name != null)
         {
            context.unresolvedTypeMap.put(Namespace.toLocal(type_name),
                  type_node);
         }
      }

      // Load attribute
      for (int ioccurs = 1;; ioccurs++)
      {
         final DrbNode attrib_node =
            schema.getNamedChild(XsdAttribute.TAG, ioccurs);
         String attrib_ref = null;
         if (attrib_node == null)
         {
            break;
         }
         final DrbAttributeList attribs = attrib_node.getAttributes();
         for (int i = 0; i < attribs.getLength(); i++)
         {
            final DrbAttribute attribute = attribs.item(i);
            final String attributeName = attribute.getName();
            if (XsdAttribute.NAME_TAG.equals(attributeName))
            {
               attrib_ref = attribute.getValue().toString();
               break;
            }
         }
         if (attrib_ref != null)
         {
            final String ref_prefix = Namespace.toPrefix(attrib_ref);
            final String ref_uri =
               context.namespaces.resolveNamespace(ref_prefix);
            context.unresolvedAttributeMap.put(new XsdName(ref_prefix, ref_uri),
                  attrib_node);
         }
      }

      // Load element
      for (int ioccurs = 1;; ioccurs++)
      {
         final DrbNode element_node =
            schema.getNamedChild(XsdElement.TAG, ioccurs);
         String element_name = null;
         if (element_node == null)
         {
            break;
         }
         final DrbAttributeList attribs = element_node.getAttributes();
         for (int i = 0; i < attribs.getLength(); i++)
         {
            final DrbAttribute attribute = attribs.item(i);
            final String attributeName = attribute.getName();
            if (XsdElement.NAME_TAG.equals(attributeName))
            {
               element_name = attribute.getValue().toString();
               break;
            }
         }
         if (element_name != null)
         {
            context.unresolvedElementMap.put(new XsdName(element_name,
                  context.targetNamespace), element_node);
         }
      }

      // Load include
      for (int ioccurs = 1;; ioccurs++)
      {
         final DrbNode include_node =
            schema.getNamedChild(XmlSchema.INCLUDE_TAG, ioccurs);
         if (include_node == null)
         {
            break;
         }
         this.preloadInclude(context, base, include_node);
      }

      // Load import
      for (int ioccurs = 1;; ioccurs++)
      {
         final DrbNode include_node =
            schema.getNamedChild(XmlSchema.IMPORT_TAG, ioccurs);
         if (include_node == null)
         {
            break;
         }
         this.preloadInclude(context, base, include_node);
      }

   } // preloadSchema

   /**
    * Parse an include directive.
    * 
    * @param context the context
    * @param base the base node
    * @param include_node the include node
    */
   private void preloadInclude(final Context context, final DrbNode base,
         final DrbNode include_node)
   {
      String schema_location = null;
      final DrbAttributeList attribs = include_node.getAttributes();
      for (int i = 0; i < attribs.getLength(); i++)
      {
         final DrbAttribute attribute = attribs.item(i);
         final String attributeName = attribute.getName();

         if (XmlSchema.SCHEMA_LOCATION_TAG.equals(attributeName))
         {
            schema_location = attribute.getValue().toString();
         }
      }
      /**
       * Attempt to include the specified document.
       */
      if (schema_location != null)
      {
         /*
          * if (!schema_location.startsWith("/") && (base != null)) { String
          * base_path = base.getPath(); if (base != null) schema_location =
          * base_path + "/" + schema_location }
          */
         DrbNode include_schema_base = null;

         final Query schema_query = new Query(schema_location);
         final DrbSequence schema_result = schema_query.evaluate(base);
         if ((schema_result != null) && (schema_result.getLength() > 0))
         {
            include_schema_base = (DrbNode) schema_result.getItem(0);
         }

         if (include_schema_base != null)
         {
            final String include_path = include_schema_base.getPath();

            if (!context.includeSet.contains(include_path))
            {
               final DrbNode include_schema =
                  include_schema_base.getFirstChild();

               if (logger.isDebugEnabled())
               {
                  logger.debug("Preloading XML Schema from \"" + include_path
                        + "\", included from \"" + base.getPath() + "\"...");
               }

               this.preloadSchema(context, include_schema_base.getParent(),
                     include_schema);

               context.includeSet.add(include_path);
            }
         }
         else
         {
            logger.error("XsdFactory.preloadInclude:  cannot include '"
                  + schema_location + "'.");
         }
      }
   }

   /**
    * Load a schema from the specified node
    * 
    * @param schema the schema node
    * @return the xml schema
    */
   private XmlSchema loadSchema(final DrbNode schema_file)
   {
      String targetNamespace = null;
      XmlSchema xmlschema = null;
      XsdElement[] root_elt = null;
      XsdType[] global_type = null;
      XsdAnnotation annotation = null;
      final DrbDefaultNodeList extNodes = new DrbDefaultNodeList();
      final DrbDefaultAttributeList extAttributes =
         new DrbDefaultAttributeList();
      final ArrayList type_list = new ArrayList();
      final ArrayList elt_list = new ArrayList();
      final HashMap namespaceMap = new HashMap();
      try
      {
         DrbNode schema = schema_file.getFirstChild();
         /** Assert the baseNode is a schema */
         if (!XmlSchema.TAG.equals(schema.getName()))
         {
            logger.error("'" + schema.getName() + "' is not a valid schema.");
            return null;
         }

         /** Parse namespace bindings */
         if (schema instanceof DrbAbstractNode)
         {
            this.context.namespaces.addNamespaces(((DrbAbstractNode) schema)
                  .getNamespaceBindings());
         }

         /** Parse attributes */
         final DrbAttributeList schema_attributes = schema.getAttributes();
         if (schema_attributes != null)
         {
            for (int i = 0; i < schema_attributes.getLength(); i++)
            {
               final DrbAttribute attrib = schema_attributes.item(i);
               if (attrib == null)
               {
                  continue;
               }
               final String name = attrib.getName();
               final String namespace = attrib.getName();
               if (name == null)
               {
                  continue;
               }
               // targetNamespace
               if (XmlSchema.TARGET_NAMESPACE_TAG.equals(name))
               {
                  final Value value = attrib.getValue();
                  if (value != null)
                  {
                     this.context.targetNamespace = value.toString();
                  }
               }
               else
               // xmlns
               {
                  final Value value = attrib.getValue();
                  if (value != null)
                  {
                     namespaceMap.put(name, value.toString());
                  }
               }
            }
         }
         targetNamespace = this.context.targetNamespace;
         /** Parse children */
         final DrbNodeList children = schema.getChildren();
         if (children != null)
         {
            for (int i = 0; i < children.getLength(); i++)
            {
               final DrbNode node = children.item(i);
               final String nodeName = Namespace.toLocal(node.getName());
               // annotation
               if (XsdAnnotation.TAG.equals(nodeName))
               {
                  annotation = this.loadAnnotation(node, extNodes);
               }
               else
               // element
               if (XsdElement.TAG.equals(nodeName))
               {
                  final XsdElement elt = this.loadElement(node);
                  if (elt != null)
                  {
                     elt_list.add(elt);
                     elt.setTargetNamespace(targetNamespace);
                  }
               }
               else
               // complexType
               if (XsdComplexType.TAG.equals(nodeName)
                     && this.context.unresolvedTypeMap.containsValue(node))
               {
                  final XsdType type = this.loadComplexType(null, node);
                  if (type != null)
                  {
                     type_list.add(type);
                     this.context.globalTypeMap.put(type.getName(), type);
                     type.setTargetNamespace(targetNamespace);
                  }
               }
               else
               // simpleType
               if (XsdSimpleType.TAG.equals(nodeName))
               {
                  final XsdType type = this.loadSimpleType(node);
                  if (type != null)
                  {
                     type_list.add(type);
                     this.context.globalTypeMap.put(type.getName(), type);
                     type.setTargetNamespace(targetNamespace);
                  }
               }
               // others
               else
               {
                  extNodes.add(node);
               }
            } // for children
         } // if children

         // Load unresolved types
         final Object[] unresolved_types =
            this.context.unresolvedTypeMap.keySet().toArray();
         for (int i = 0; i < unresolved_types.length; i++)
         {
            final String type_name = unresolved_types[i].toString();
            if (this.context.unresolvedTypeMap.get(type_name) != null)
            {
               final XsdType type = this.resolveType(type_name);
               if (type != null)
               {
                  type_list.add(type);
               }
            }
         }

         root_elt = new XsdElement[elt_list.size()];
         elt_list.toArray(root_elt);
         global_type = new XsdType[this.context.globalTypeMap.values().size()];
         this.context.globalTypeMap.values().toArray(global_type);

         xmlschema =
            new XmlSchema(root_elt, global_type, this.context.namespaces);
         xmlschema.setAnnotation(annotation);
         xmlschema.setExternalNodes(extNodes);
         xmlschema.setTargetNamespace(targetNamespace);
      }
      catch (final NullPointerException e)
      {
         e.printStackTrace();
         return null;
      }
      return xmlschema;

   } // loadSchema

   /**
    * Load an annotation from the specified node
    * 
    * @param base_node the base node
    * @return an annotation from the specified node
    */
   private XsdAnnotation loadAnnotation(final DrbNode base_node)
   {
      final ArrayList appinfo_list = new ArrayList();
      final ArrayList doc_list = new ArrayList();

      final DrbNodeList children = base_node.getChildren();
      if (children != null)
      {
         for (int i = 0; i < children.getLength(); i++)
         {
            final DrbAbstractNode node = (DrbAbstractNode) children.item(i);
            if (node == null)
            {
               continue;
            }
            final String node_name = node.getName();
            if (XsdDocumentation.TAG.equals(node_name))
            {
               doc_list.add(new XsdDocumentation(node.getContent()));
            }
            else if (XsdAppinfo.TAG.equals(node_name))
            {
               appinfo_list.add(new XsdAppinfo(node.getContent()));
            }
         }
      }
      final XsdAppinfo[] appinfo = new XsdAppinfo[appinfo_list.size()];
      appinfo_list.toArray(appinfo);
      final XsdDocumentation[] doc = new XsdDocumentation[doc_list.size()];
      doc_list.toArray(doc);

      return new XsdAnnotation(appinfo, doc);
   } // loadAnnotation

   /**
    * Load an annotation from the specified node
    * 
    * @param base_node the base node
    * @param external_children the external children
    * @return the annotation from the specified node
    */
   private XsdAnnotation loadAnnotation(final DrbNode base_node,
         final ArrayList external_children)
   {
      final XsdAnnotation annotation = this.loadAnnotation(base_node);
      // SDF compatibility
      // annotation -> external
      // appinfo/* -> external
      if (!Namespace.XML_SCHEMA_NAMESPACE.equals(this.context.targetNamespace))
      {
         external_children.add(base_node);
      }
      final XsdAppinfo[] appinfos = annotation.getAppinfos();
      for (int iapp = 0; iapp < appinfos.length; iapp++)
      {
         if (appinfos[iapp].getContent() != null)
         {
            final DrbSequence appinfo_content = appinfos[iapp].getContent();
            for (int i = 0; i < appinfo_content.getLength(); i++)
            {
               if (appinfo_content.getItem(i) instanceof DrbNode)
               {
                  external_children.add(appinfo_content.getItem(i));
               }
            }
         }
      }
      return annotation;
   } // loadAnnotation

   /**
    * Load an element from the specified node
    * 
    * @param element_node the element node
    * @return the element from the specified node
    */
   private XsdElement loadElement(final DrbNode element_node)
   {
      XsdElement ref = null;
      XsdElement element = null;
      XsdType type = null;
      XsdAnnotation annotation = null;

      int min_occurs = 1; // 0;
      int max_occurs = 1; // XsdParticle.UNBOUNDED_OCCURS;
      String name = null;
      String namespaceURI = this.context.targetNamespace;
      Value value = null;
      int constraint = 0;

      /** external children and attributes */
      final DrbDefaultNodeList externalChildren = new DrbDefaultNodeList();
      final DrbDefaultAttributeList externalAttributes =
         new DrbDefaultAttributeList();

      /**
       * Analyse attributes of element tag.
       */
      final DrbAttributeList attributes = element_node.getAttributes();

      if (attributes != null)
      {
         for (int i = 0; i < attributes.getLength(); i++)
         {
            final DrbAttribute attribute = attributes.item(i);
            final String attributeName = Namespace.toLocal(attribute.getName());

            // Name of the element
            if (attributeName.equals(XsdElement.NAME_TAG))
            {
               name = attribute.getValue().toString();
            }
            else
            // type of the element
            if (attributeName.equals(XsdElement.TYPE_TAG))
            {
               final String typename = attribute.getValue().toString();
               type = this.resolveType(typename);
            }
            else
            // minOccurs of the element in its parent
            if (attributeName.equals(XsdElement.MIN_OCCURS_TAG))
            {
               min_occurs = Integer.parseInt(attribute.getValue().toString());
            }
            else
            // maxOccurs of the element in its parent
            if (attributeName.equals(XsdElement.MAX_OCCURS_TAG))
            {
               final String attributeValue = attribute.getValue().toString();
               if (attributeValue.equals(XsdElement.UNBOUNDED_OCCURS_TAG))
               {
                  max_occurs = XsdElement.UNBOUNDED_OCCURS;
               }
               else
               {
                  max_occurs = Integer.parseInt(attributeValue);
               }
            }
            else if (attributeName.equals(XsdElement.DEFAULT_TAG))
            {
               value = attribute.getValue();
               constraint = 0;
            }
            else if (attributeName.equals(XsdElement.FIXED_TAG))
            {
               value = attribute.getValue();
               constraint = 1;
            }
            else if (attributeName.equals(XsdElement.REF_TAG))
            {
               final String ref_qname = attribute.getValue().toString();
               ref = this.resolveElement(ref_qname);
            }
            else
            {
               externalAttributes.add(attribute);
            }
         }
      }

      /**
       * Analyse children of element tag.
       */
      final DrbNodeList children = element_node.getChildren();
      if (children != null)
      {
         for (int i = 0; i < children.getLength(); i++)
         {
            final DrbNode node = children.item(i);
            final String nodeName = Namespace.toLocal(node.getName());
            // annotation
            if (nodeName.equals(XsdAnnotation.TAG))
            {
               annotation = this.loadAnnotation(node, externalChildren);
            }
            else
            // complexType
            if (nodeName.equals(XsdComplexType.TAG))
            {
               type = this.loadComplexType(null, node);
            }
            else
            // simpleType
            if (nodeName.equals(XsdSimpleType.TAG))
            {
               type = this.loadSimpleType(node);
            }
            // others
            else
            {
               externalChildren.add(node);
            }
         }
      }
      if (max_occurs < min_occurs)
      {
         max_occurs = min_occurs;
      }

      if (ref != null)
      {
         name = ref.getName();
         namespaceURI = ref.getTargetNamespace();
         type = ref.getType();
         if (value == null)
         {
            value = ref.getValue();
            constraint = ref.getConstraint();
         }
         if (annotation == null)
         {
            annotation = ref.getAnnotation();
         }
         for (int i = 0; i < ref.getExternalNodes().getLength(); i++)
         {
            externalChildren.add(ref.getExternalNodes().item(i));
         }
      }

      element = new XsdElement(min_occurs, max_occurs, name, type);
      element.setValueConstraint(value, constraint);
      element.setAnnotation(annotation);
      element.setExternalNodes(externalChildren);
      element.setExternalAttributes(externalAttributes);
      element.setTargetNamespace(namespaceURI);
      return element;
   } // loadElement

   /**
    * Load an attribute.
    * 
    * @param attribute_node the attribute node
    * @return the attribute
    */
   private XsdAttribute loadAttribute(final DrbNode attribute_node)
   {
      XsdSimpleType type = null;
      XsdAnnotation annotation = null;
      Value value = null;
      String name = null;
      int use = -1;
      XsdAttribute ref = null;

      /** external children */
      final DrbDefaultNodeList externalChildren = new DrbDefaultNodeList();

      /**
       * Analyse attributes of this node.
       */
      final DrbAttributeList attributes = attribute_node.getAttributes();
      if (attributes != null)
      {
         for (int i = 0; i < attributes.getLength(); i++)
         {
            final DrbAttribute attribute = attributes.item(i);
            final String attributeName = Namespace.toLocal(attribute.getName());

            // Name of the attribute
            if (attributeName.equals(XsdAttribute.NAME_TAG))
            {
               name = attribute.getValue().toString();
               // WARNING : check that the attribute has not already
               // been declared
            }
            else
            {
               // ref of the attribute
               if (attributeName.equals(XsdAttribute.REF_TAG))
               {
                  final String refname = attribute.getValue().toString();
                  ref = this.resolveAttribute(refname);
               }
               else
               {
                  // type of the attribute
                  if (attributeName.equals(XsdAttribute.TYPE_TAG))
                  {
                     final String typename = attribute.getValue().toString();
                     type = (XsdSimpleType) this.resolveType(typename);
                     // WARNING : check that the attribute is a simple type
                  }
                  else
                  {
                     // use of the attribute
                     if (attributeName.equals(XsdAttribute.USE_TAG))
                     {
                        final String useName = attribute.getValue().toString();
                        if (useName.equals(XsdAttribute.OPTIONAL_USE_TAG))
                        {
                           use = XsdAttribute.OPTIONAL_USE;
                        }
                        else if (useName.equals(XsdAttribute.PROHIBITED_USE_TAG))
                        {
                           use = XsdAttribute.PROHIBITED_USE;
                        }
                        else if (useName.equals(XsdAttribute.REQUIRED_USE_TAG))
                        {
                           use = XsdAttribute.REQUIRED_USE;
                        }
                        else
                        {
                           logger.warn("XsdFactory:loadAttribute :"
                                 + " unknown use :" + useName);
                        }
                        // WARNING : check that the attribute has
                        // not already been declared
                     }
                     else
                     {
                        // Fixed value of attribute
                        if (attributeName.equals(XsdAttribute.FIXED_TAG))
                        {
                           value = attribute.getValue();
                        }
                        else
                        {
                           // Default value of attribute
                           if (attributeName.equals(XsdAttribute.DEFAULT_TAG))
                           {
                              value = attribute.getValue();
                              use = XsdAttribute.OPTIONAL_USE;
                           }
                           else
                           {
                              logger.warn("XsdFactory:loadAttribute : "
                                    + "unknown attribute : " + attributeName);
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      /**
       * Analyse children of attribute tag.
       */
      final DrbNodeList children = attribute_node.getChildren();
      if (children != null)
      {
         for (int i = 0; i < children.getLength(); i++)
         {
            final DrbNode node = children.item(i);
            final String nodeName = Namespace.toLocal(node.getName());
            // annotation
            if (nodeName.equals(XsdAnnotation.TAG))
            {
               annotation = this.loadAnnotation(node, externalChildren);
            }
            else
            // simpleType
            if (nodeName.equals(XsdSimpleType.TAG))
            {
               type = this.loadSimpleType(node);
            }
            // others
            else
            {
               externalChildren.add(node);
            }
         }
      }
      /**
       * Build attribute from definition.
       */
      if ((value != null) && (type != null))
      {
         value = value.convertTo(type.getTypeId());
      }
      if (ref != null)
      {
         name = ref.getName();
         type = ref.getType();
         if (value == null)
         {
            value = ref.getValueConstraint();
         }
         if (use == -1)
         {
            use = ref.getUse();
         }
         if (annotation == null)
         {
            annotation = ref.getAnnotation();
         }
         for (int i = 0; i < ref.getExternalNodes().getLength(); i++)
         {
            externalChildren.add(ref.getExternalNodes().item(i));
         }
      }
      if (use == -1)
      {
         use = XsdAttribute.OPTIONAL_USE;
      }
      XsdAttribute attribute_decl = null;
      attribute_decl = new XsdAttribute(name, type, value, use);
      attribute_decl.setAnnotation(annotation);
      attribute_decl.setExternalNodes(externalChildren);
      attribute_decl.setTargetNamespace(this.context.targetNamespace);

      return attribute_decl;
   }

   /**
    * Load a complex type from the specified node
    * 
    * @param ref_type the complex type
    * @param base_node the base node
    * @return the complex type to be loaded
    */
   private XsdComplexType loadComplexType(XsdComplexType ref_type,
         final DrbNode base_node)
   {
      XsdComplexType complex_type = null;
      String name = null;
      final XsdType base = null;
      XsdModelGroup complex_content = null;
      final ArrayList attrib_list = new ArrayList();
      XsdAnnotation annotation = null;
      final DrbDefaultNodeList externalNodes = new DrbDefaultNodeList();
      final DrbDefaultAttributeList externalAttributes =
         new DrbDefaultAttributeList();

      /**
       * Analyse attributes of complexType tag : name and external attributes
       */
      final DrbAttributeList attributes = base_node.getAttributes();
      if (attributes != null)
      {
         for (int i = 0; i < attributes.getLength(); i++)
         {
            final DrbAttribute attribute = attributes.item(i);
            final String attributeName = attribute.getName();

            // Set the name of the node
            if (attributeName.equals(XsdComplexType.NAME_TAG))
            {
               name = attribute.getValue().toString();
            }
            // Set its external attributes
            else
            {
               externalAttributes.add(attribute);
            }
         }
      }

      /**
       * Analyse children of complexType tag.
       */
      final DrbNodeList children = base_node.getChildren();
      if (children != null)
      {
         for (int i = 0; i < children.getLength(); i++)
         {
            final DrbNode node = children.item(i);
            final String nodeName = node.getName();
            // annotation
            if (XsdAnnotation.TAG.equals(nodeName))
            {
               annotation = this.loadAnnotation(node, externalNodes);
            }
            else
            // model group
            if (XsdModelGroup.SEQUENCE_TAG.equals(nodeName)
                  || XsdModelGroup.CHOICE_TAG.equals(nodeName)
                  || XsdModelGroup.ALL_TAG.equals(nodeName))
            {
               complex_content = this.loadModelGroup(node);
            }
            else
            // complexContent | simpleContent
            if (XsdComplexType.COMPLEX_CONTENT_TAG.equals(nodeName)
                  || XsdComplexType.SIMPLE_CONTENT_TAG.equals(nodeName))
            {
               complex_type = this.loadComplexTypeContent(name, node);
            }
            else
            // attribute
            if (XsdAttribute.TAG.equals(nodeName))
            {
               final XsdAttribute attrib = this.loadAttribute(node);
               if (attrib != null)
               {
                  attrib_list.add(attrib);
               }
            }
            // other
            else
            {
               externalNodes.add(node);
            }
         }
      }

      // Add xsi attributes.

      XsdAttributeGroup attrib_group = null;
      if (attrib_list.size() > 0)
      {
         XsdAttribute[] attribs = null;
         attribs = new XsdAttribute[attrib_list.size()];
         attrib_list.toArray(attribs);
         attrib_group = new XsdAttributeGroup(null, attribs);
      }

      /**
       * Create the complexType
       */
      if (complex_type == null)
      {
         complex_type =
            new XsdComplexType(name, attrib_group, complex_content, base,
                  XsdComplexType.EXTENSION_METHOD);
      }
      if (complex_type.getExternalNodes() != null)
      {
         final DrbNodeList ref_ext_nodes = complex_type.getExternalNodes();
         externalNodes.addAll(0, (java.util.Collection) ref_ext_nodes);
      }
      complex_type.setAnnotation(annotation);
      complex_type.setExternalNodes(externalNodes);
      complex_type.setExternalAttributes(externalAttributes);
      complex_type.setTargetNamespace(this.context.targetNamespace);

      if (ref_type == null)
      {
         ref_type = (XsdComplexType) this.resolveType(complex_type.getName());
      }
      if (ref_type != null)
      {
         ref_type.setName(complex_type.getName());
         ref_type.setBase(complex_type.getBase());
         ref_type.setSimpleContent(complex_type.getDatatype());
         ref_type.setComplexContent(complex_type.getComplexContent());
         ref_type.setAttributeGroup(complex_type.getAttributeGroup());
         ref_type.setAnnotation(annotation);
         ref_type.setExternalNodes(externalNodes);
         ref_type.setExternalAttributes(externalAttributes);
         ref_type.setTargetNamespace(complex_type.getTargetNamespace());

         complex_type.setBase(null);
         return ref_type;
      }
      return complex_type;
   } // loadComplexType

   /**
    * Load a model group from the specified node
    * 
    * @param base_node the base node
    * @return the model group
    */
   private XsdModelGroup loadModelGroup(final DrbNode base_node)
   {
      XsdAnnotation annotation = null;
      XsdModelGroup model_group = null;
      XsdParticle[] content = null;
      final ArrayList particle_list = new ArrayList();
      int min_occurs = 1;
      int max_occurs = 1;

      /**
       * Read compositor.
       */
      int compositor = -1;
      if (XsdModelGroup.SEQUENCE_TAG.equals(base_node.getName()))
      {
         compositor = XsdModelGroup.SEQUENCE_MODEL;
      }
      else if (XsdModelGroup.CHOICE_TAG.equals(base_node.getName()))
      {
         compositor = XsdModelGroup.CHOICE_MODEL;
      }
      else if (XsdModelGroup.ALL_TAG.equals(base_node.getName()))
      {
         compositor = XsdModelGroup.ALL_MODEL;
      }

      /**
       * Analyse attributes of this model group node.
       */
      final DrbAttributeList attributes = base_node.getAttributes();
      final DrbDefaultAttributeList externalAttributes =
         new DrbDefaultAttributeList();
      if (attributes != null)
      {
         for (int i = 0; i < attributes.getLength(); i++)
         {
            final DrbAttribute attribute = attributes.item(i);
            final String attributeName = Namespace.toLocal(attribute.getName());

            // minOccurs of the element in its parent
            if (attributeName.equals(XsdElement.MIN_OCCURS_TAG))
            {
               min_occurs = Integer.parseInt(attribute.getValue().toString());
            }
            else
            // maxOccurs of the element in its parent
            if (attributeName.equals(XsdElement.MAX_OCCURS_TAG))
            {
               final String attributeValue = attribute.getValue().toString();
               if (attributeValue.equals(XsdElement.UNBOUNDED_OCCURS_TAG))
               {
                  max_occurs = XsdElement.UNBOUNDED_OCCURS;
               }
               else
               {
                  max_occurs = Integer.parseInt(attributeValue);
               }
            }
            else
            {
            }
         }
      }

      /**
       * Analyse children of this model group node.
       */
      final DrbNodeList children = base_node.getChildren();
      final DrbDefaultNodeList externalNodes = new DrbDefaultNodeList();

      if (children != null)
      {
         for (int i = 0; i < children.getLength(); i++)
         {
            final DrbNode node = children.item(i);
            final String nodeName = Namespace.toLocal(node.getName());

            if (nodeName.equals(XsdAnnotation.TAG))
            {
               annotation = this.loadAnnotation(node, externalNodes);
            }
            else if (nodeName.equals(XsdElement.TAG))
            {
               particle_list.add(this.loadElement(node));
            }
            else if (XsdModelGroup.SEQUENCE_TAG.equals(nodeName)
                  || XsdModelGroup.CHOICE_TAG.equals(nodeName)
                  || XsdModelGroup.ALL_TAG.equals(nodeName))
            {
               particle_list.add(this.loadModelGroup(node));
            }
            else
            {
               externalNodes.add(node);
            }
         }
      }
      /**
       * Build a model group.
       */
      content = new XsdParticle[particle_list.size()];
      particle_list.toArray(content);
      /*
       * if (max_occurs < min_occurs) max_occurs = min_occurs;
       */
      model_group =
         new XsdModelGroup(min_occurs, max_occurs, content, compositor);
      model_group.setAnnotation(annotation);
      model_group.setExternalNodes(externalNodes);

      return model_group;
   } // loadModelGroup

   /**
    * Load a the content of a complexType from the specified node
    * 
    * @param name the name node
    * @param base_node the base node
    * @return the complex type
    */
   private XsdComplexType loadComplexTypeContent(final String name,
         final DrbNode base_node)
   {
      final int simpleContent = 1;
      final int complexContent = 2;
      int content_type = -1;
      // final int RESTRICTION_METHOD = 1;
      // final int EXTENSION_METHOD = 2;
      int derivation_method = -1;
      DrbNode content_node = null;
      XsdType base_type = null;
      /**
       * Retrieve the content type
       */
      if (XsdComplexType.COMPLEX_CONTENT_TAG.equals(base_node.getName()))
      {
         content_type = complexContent;
      }
      else if (XsdComplexType.SIMPLE_CONTENT_TAG.equals(base_node.getName()))
      {
         content_type = simpleContent;
      }
      /**
       * Analyse children of this content node.
       */
      DrbNodeList children = base_node.getChildren();
      if (children != null)
      {
         for (int i = 0; i < children.getLength(); i++)
         {
            final DrbNode node = children.item(i);
            final String nodeName = Namespace.toLocal(node.getName());

            if (XsdComplexType.EXTENSION_TAG.equals(nodeName))
            {
               content_node = node;
               derivation_method = XsdComplexType.EXTENSION_METHOD;
            }
            else if (XsdComplexType.RESTRICTION_TAG.equals(nodeName))
            {
               content_node = node;
               derivation_method = XsdComplexType.RESTRICTION_METHOD;
            }
         }
      }
      if (content_node == null)
      {
         return null;
      }
      /**
       * Analyse attributes of the derivation node.
       */
      final DrbAttributeList attributes = content_node.getAttributes();
      if (attributes != null)
      {
         for (int i = 0; i < attributes.getLength(); i++)
         {
            final DrbAttribute attribute = attributes.item(i);
            final String attributeName = Namespace.toLocal(attribute.getName());

            // minOccurs of the element in its parent
            if (XsdComplexType.DERIVATION_BASE_TAG.equals(attributeName))
            {
               final String base_typename = attribute.getValue().toString();
               base_type = this.resolveType(base_typename);
            }
         }
      }
      if (base_type == null)
      {
         return null;
      }
      /**
       * Performs the derivation.
       */
      final ArrayList attrib_list = new ArrayList();
      // complex content
      XsdModelGroup complex_content = null;
      children = content_node.getChildren();
      if (children != null)
      {
         for (int i = 0; i < children.getLength(); i++)
         {
            final DrbNode node = children.item(i);
            final String nodeName = Namespace.toLocal(node.getName());

            // model group
            if (XsdModelGroup.SEQUENCE_TAG.equals(nodeName)
                  || XsdModelGroup.CHOICE_TAG.equals(nodeName)
                  || XsdModelGroup.ALL_TAG.equals(nodeName))
            {
               complex_content = this.loadModelGroup(node);
            }
            else
            // attribute
            if (XsdAttribute.TAG.equals(nodeName))
            {
               final XsdAttribute attrib = this.loadAttribute(node);
               if (attrib != null)
               {
                  attrib_list.add(attrib);
               }
            }
         }
      }
      // Build attribute group
      XsdAttributeGroup attrib_group = null;
      if (attrib_list.size() > 0)
      {
         XsdAttribute[] attribs = null;
         attribs = new XsdAttribute[attrib_list.size()];
         attrib_list.toArray(attribs);
         attrib_group = new XsdAttributeGroup(null, attribs);
      }

      // simple content
      final XsdSimpleType simple_content = base_type.getDatatype();
      XsdComplexType complex_type = null;
      if ((derivation_method == XsdComplexType.RESTRICTION_METHOD)
            && (content_type == simpleContent))
      {
         final XsdFacet[] facets =
            this.loadFacets(simple_content.getTypeId(), content_node);
         complex_type =
            new XsdComplexType(name, attrib_group, facets, base_type,
                  derivation_method);
      }
      else
      {
         complex_type =
            new XsdComplexType(name, attrib_group, complex_content, base_type,
                  derivation_method);
      }
      return complex_type;
   } // loadComplexTypeContent

   /**
    * Load a simple type from the specified node
    * 
    * @param base_node the base node
    * @return The simple type
    */
   private XsdSimpleType loadSimpleType(final DrbNode base_node)
   {
      XsdAnnotation annotation = null;
      String name = null;
      XsdSimpleType type = null;

      /**
       * Analyse attributes of this simpleType node.
       */
      final DrbAttributeList attributes = base_node.getAttributes();
      final DrbDefaultAttributeList externalAttributes =
         new DrbDefaultAttributeList();
      if (attributes != null)
      {
         for (int i = 0; i < attributes.getLength(); i++)
         {
            final DrbAttribute attribute = attributes.item(i);
            final String attributeName = Namespace.toLocal(attribute.getName());

            // name of the simpleType
            if (XsdSimpleType.NAME_TAG.equals(attributeName))
            {
               name = attribute.getValue().toString();
            }
            // Set its external attributes
            else
            {
               externalAttributes.add(attribute);
            }
         }
      }

      /**
       * Analyse children of this simpleType node.
       */
      final DrbNodeList children = base_node.getChildren();
      final DrbDefaultNodeList externalNodes = new DrbDefaultNodeList();

      if (children != null)
      {
         for (int i = 0; i < children.getLength(); i++)
         {
            final DrbNode node = children.item(i);
            final String nodeName = Namespace.toLocal(node.getName());

            if (nodeName.equals(XsdAnnotation.TAG))
            {
               annotation = this.loadAnnotation(node, externalNodes);
            }
            else if (XsdSimpleType.RESTRICTION_TAG.equals(nodeName)
                  || XsdListType.TAG.equals(nodeName))
            {
               type = this.loadSimpleTypeContent(name, node);
            }
            else
            {
               externalNodes.add(node);
            }
         }
      }
      if (type != null)
      {
         if (type.getExternalNodes() != null)
         {
            final DrbNodeList ref_ext_nodes = type.getExternalNodes();
            externalNodes.addAll(0, (java.util.Collection) ref_ext_nodes);
         }
         if (annotation == null)
         {
            annotation = type.getAnnotation();
         }
         type.setAnnotation(annotation);
         type.setExternalNodes(externalNodes);
         type.setTargetNamespace(this.context.targetNamespace);
      }
      return type;
   } // loadSimpleType

   /**
    * Load a simpleType content from the specified node
    * 
    * @param name the name of the node
    * @param base_node the base node
    * @return the simple type
    */
   private XsdSimpleType loadSimpleTypeContent(final String name,
         final DrbNode base_node)
   {
      final int restrictionMethod = 1;
      final int listMethod = 2;
      int derivation_method = -1;
      int type_id = Value.UNKNOWN_ID;
      XsdSimpleType type = null;
      XsdSimpleType base_type = null;
      XsdSimpleType item_type = null;
      XsdFacet[] facets = null;
      /**
       * Retrieve the derivation method
       */
      if (XsdSimpleType.RESTRICTION_TAG.equals(base_node.getName()))
      {
         derivation_method = restrictionMethod;
      }
      else if (XsdListType.TAG.equals(base_node.getName()))
      {
         derivation_method = listMethod;
      }
      else
      {
         return null;
      }
      /**
       * Analyse children of this simpleContent node.
       */
      final DrbNodeList children = base_node.getChildren();
      if (children != null)
      {
         for (int i = 0; i < children.getLength(); i++)
         {
            final DrbNode node = children.item(i);
            final String nodeName = Namespace.toLocal(node.getName());

            if (XsdSimpleType.TAG.equals(nodeName))
            {
               if (derivation_method == restrictionMethod)
               {
                  base_type = this.loadSimpleType(node);
                  type_id = base_type.getTypeId();
               }
               if (derivation_method == listMethod)
               {
                  item_type = this.loadSimpleType(node);
                  type_id = Value.ARRAY_ID;
               }
            } // simpleType loading
         }
      }
      /**
       * Analyse attributes of this simpleType node.
       */
      final DrbAttributeList attributes = base_node.getAttributes();
      if (attributes != null)
      {
         for (int i = 0; i < attributes.getLength(); i++)
         {
            final DrbAttribute attribute = attributes.item(i);
            final String attributeName = Namespace.toLocal(attribute.getName());
            // derivation by restriction
            if ((derivation_method == restrictionMethod)
                  && XsdSimpleType.DERIVATION_BASE_TAG.equals(attributeName))
            {
               final String base_typename = attribute.getValue().toString();
               base_type = (XsdSimpleType) this.resolveType(base_typename);
               if (base_type != null)
               {
                  type_id = base_type.getTypeId();
               }

            }
            // derivation by list
            if ((derivation_method == listMethod)
                  && XsdListType.ITEM_TYPE_TAG.equals(attributeName))
            {
               final String item_typename = attribute.getValue().toString();
               item_type = (XsdSimpleType) this.resolveType(item_typename);
            }
         }
      }
      // In case of unknown type, try to guess from name
      boolean primitive_flag = false;
      if (type_id == Value.UNKNOWN_ID)
      {
         type_id = Value.STRING_ID;
      }
      if (Namespace.XML_SCHEMA_NAMESPACE.equals(this.context.targetNamespace))
      {
         primitive_flag = true;
         if ("boolean".equals(name))
         {
            type_id = Value.BOOLEAN_ID;
         }
         else if ("float".equals(name))
         {
            type_id = Value.FLOAT_ID;
         }
         else if ("double".equals(name))
         {
            type_id = Value.DOUBLE_ID;
         }
         else if ("decimal".equals(name))
         {
            type_id = Value.DECIMAL_ID;
         }
         else if ("integer".equals(name))
         {
            type_id = Value.INTEGER_ID;
         }
         else if ("long".equals(name))
         {
            type_id = Value.LONG_ID;
         }
         else if ("unsignedLong".equals(name))
         {
            type_id = Value.UNSIGNED_LONG_ID;
         }
         else if ("int".equals(name))
         {
            type_id = Value.INT_ID;
         }
         else if ("unsignedInt".equals(name))
         {
            type_id = Value.UNSIGNED_INT_ID;
         }
         else if ("short".equals(name))
         {
            type_id = Value.SHORT_ID;
         }
         else if ("unsignedShort".equals(name))
         {
            type_id = Value.UNSIGNED_SHORT_ID;
         }
         else if ("byte".equals(name))
         {
            type_id = Value.BYTE_ID;
         }
         else if ("unsignedByte".equals(name))
         {
            type_id = Value.UNSIGNED_BYTE_ID;
         }
         else if ("string".equals(name))
         {
            type_id = Value.STRING_ID;
         }
         else if ("anyURI".equals(name))
         {
            type_id = Value.STRING_ID;
         }
         else if ("NOTATION".equals(name))
         {
            type_id = Value.STRING_ID;
         }
         else if ("QName".equals(name))
         {
            type_id = Value.STRING_ID;
         }
         else if ("dateTime".equals(name))
         {
            type_id = Value.DATE_ID;
         }
         else if ("duration".equals(name))
         {
            type_id = Value.DURATION_ID;
         }
         else
         {
            primitive_flag = false;
         }
      }
      facets = this.loadFacets(type_id, base_node);
      /**
       * Derivation by restricion
       */
      if (base_type != null)
      {
         switch (base_type.getVariety())
         {
            case XsdSimpleType.ATOMIC_VARIETY:
               type = new XsdAtomicType(name, (XsdAtomicType) base_type, facets);
               break;
            case XsdSimpleType.LIST_VARIETY:
               item_type = ((XsdListType) base_type).getItemType();
               break;
         }
      }
      if (primitive_flag)
      {
         ((XsdAtomicType) type).init(type_id);
         type.name = name;
      }

      /**
       * Derivation by list
       */
      if (item_type != null)
      {
         type = new XsdListType(name, item_type, facets);
      }
      if ((type != null) && (base_type != null))
      {
         type.setExternalNodes(base_type.getExternalNodes());
         type.setAnnotation(base_type.getAnnotation());
         type.setTargetNamespace(this.context.targetNamespace);
      }
      return type;
   } // loadSimpleTypeContent

   /**
    * Load facets from the specified node.
    * 
    * @param base_node the base node
    * @param type_id the identifier type
    * @return the faces
    */
   XsdFacet[] loadFacets(final int type_id, final DrbNode base_node)
   {
      final ArrayList facet_list = new ArrayList();
      final ArrayList enum_list = new ArrayList();
      XsdFacet[] facets = null;

      int primitive_id = type_id;
      switch (type_id)
      {
         case Value.BYTE_ID:
         case Value.UNSIGNED_BYTE_ID:
         case Value.SHORT_ID:
         case Value.UNSIGNED_SHORT_ID:
         case Value.INT_ID:
         case Value.UNSIGNED_INT_ID:
         case Value.LONG_ID:
         case Value.UNSIGNED_LONG_ID:
         case Value.INTEGER_ID:
         case Value.DECIMAL_ID:
            primitive_id = Value.DECIMAL_ID;
      }

      /**
       * Analyse children of this simpleContent node.
       */
      final DrbNodeList children = base_node.getChildren();
      final DrbDefaultNodeList externalNodes = new DrbDefaultNodeList();

      if (children != null)
      {
         for (int i = 0; i < children.getLength(); i++)
         {
            final DrbNode node = children.item(i);
            final String nodeName = Namespace.toLocal(node.getName());
            Value facet_value = null;
            /**
             * Analyse attributes of this facet node.
             */
            final DrbAttributeList attributes = node.getAttributes();
            if (attributes != null)
            {
               for (int j = 0; j < attributes.getLength(); j++)
               {
                  final DrbAttribute attribute = attributes.item(j);
                  final String attributeName =
                     Namespace.toLocal(attribute.getName());

                  // value of the facet
                  if (XsdFacet.VALUE_TAG.equals(attributeName))
                  {
                     facet_value = attribute.getValue();
                  }
               } // for attribute
            }
            if (facet_value == null)
            {
               // fr.gael.drb.impl.xml.XmlWriter.writeXML(node, System.err);
               // logger.error("No value found in facet " + node.getPath());
               continue;
            }
            /**
             * Read the current facet
             */
            if (XsdMinInclusiveFacet.TAG.equals(nodeName))
            {
               facet_list.add(new XsdMinInclusiveFacet(facet_value
                     .convertTo(primitive_id)));
            }
            else if (XsdMaxInclusiveFacet.TAG.equals(nodeName))
            {
               facet_list.add(new XsdMaxInclusiveFacet(facet_value
                     .convertTo(primitive_id)));
            }
            else if (XsdMinExclusiveFacet.TAG.equals(nodeName))
            {
               facet_list.add(new XsdMinExclusiveFacet(facet_value
                     .convertTo(primitive_id)));
            }
            else if (XsdMaxExclusiveFacet.TAG.equals(nodeName))
            {
               facet_list.add(new XsdMaxExclusiveFacet(facet_value
                     .convertTo(primitive_id)));
            }
            else if (XsdLengthFacet.TAG.equals(nodeName))
            {
               facet_list.add(new XsdLengthFacet(facet_value
                     .convertTo(Value.INTEGER_ID)));
            }
            else if (XsdMinLengthFacet.TAG.equals(nodeName))
            {
               facet_list.add(new XsdMinLengthFacet(facet_value
                     .convertTo(Value.INTEGER_ID)));
            }
            else if (XsdMaxLengthFacet.TAG.equals(nodeName))
            {
               facet_list.add(new XsdMaxLengthFacet(facet_value
                     .convertTo(Value.INTEGER_ID)));
            }
            else if (XsdPatternFacet.TAG.equals(nodeName))
            {
               facet_list.add(new XsdPatternFacet(facet_value.toString()));
            }
            else if (XsdEnumerationFacet.TAG.equals(nodeName))
            {
               enum_list.add(facet_value.convertTo(primitive_id));
            }
            else if (XsdFractionDigitsFacet.TAG.equals(nodeName))
            {
               facet_list.add(new XsdFractionDigitsFacet(facet_value
                     .convertTo(Value.INTEGER_ID)));
            }
            else if (XsdTotalDigitsFacet.TAG.equals(nodeName))
            {
               facet_list.add(new XsdTotalDigitsFacet(facet_value
                     .convertTo(Value.INTEGER_ID)));
            }
            else
            {
               externalNodes.add(node);
            }
         }
      }
      if (enum_list.size() > 0)
      {
         final Value[] enum_values = new Value[enum_list.size()];
         enum_list.toArray(enum_values);
         facet_list.add(new XsdEnumerationFacet(enum_values));
      }
      if (facet_list.size() > 0)
      {
         facets = new XsdFacet[facet_list.size()];
         facet_list.toArray(facets);
      }
      return facets;

   } // loadFacets

   /**
    * Load a schema from the specified node
    * 
    * @param schema the specified node
    * @return The schema from the specified node
    */
   public XmlSchema open(final DrbNode schema)
   {
      DrbNode base = null;
      if (schema != null) // get the directory of the file
      {
         base = schema.getParent();
      }
      return this.open(base, schema);
   } // open

   /**
    * Load a schema from the specified node
    * 
    * @param base the context node used for the xs:include instruction.
    * @param schema the schema node
    * @return the schema from the specified node
    */
   public XmlSchema open(final DrbNode base, final DrbNode schema)
   {
      // Check that the input schema is not null
      this.init(XmlSchema.getDefaultSchema());
      if (schema != null)
      {
         this.preloadSchema(this.context, base, schema);
         return this.loadSchema(schema);
      }
      return null;
   } // open

   /**
    * Load a schema from the specified node
    * 
    * @param base the node
    * @param schema_node the schema node
    * @param schema_def the schema definition
    * @return the schema from the specified node
    */
   protected XmlSchema open(final DrbNode base, final DrbNode schema_node,
         final XmlSchema schema_def)
   {
      // Check that the input schema is not null
      this.init(schema_def);
      if (schema_node != null)
      {
         this.preloadSchema(this.context, base, schema_node);
         return this.loadSchema(schema_node);
      }
      return null;
   } // open

   // ==============================================
   // Unitary test part.
   // ==============================================
   /**
    * Makes this class runnable for testing.
    * 
    * @param args string[]
    */
   public static void main(final String[] args)
   {
      final DrbNode file_node = DrbFactory.open(args[0]);
      logger.error("Opened file '" + file_node.getPath() + ".");
      final DrbNode schema_node = file_node.getFirstChild();
      logger.error("Opened schema '" + schema_node.getPath() + ".");
      final XsdFactory xsdfactory = new XsdFactory();
      final XmlSchema xmlschema =
         xsdfactory.open(file_node.getParent(), schema_node);
      if (xmlschema == null)
      {
         logger.error("Problem while loading schema !");
         return;
      }
      for (int i = 0; i < schema_node.getAttributes().getLength(); i++)
      {
         System.err.println("local name="
               + schema_node.getAttributes().item(i).getName());
         System.err.println("namespace URI="
               + schema_node.getAttributes().item(i).getNamespaceURI());
      }
      XmlFactory.writeXML(xmlschema.toNode(), System.err);

      final XsdElement root_elt = xmlschema.getDefaultRootElement();
      if (root_elt == null)
      {
         logger.error("No elements !");
         return;
      }
   } // main

} // XsdFactory
