/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * Standard numeric values : from boolean to double. All operators are supported :
 * arithmetic, comparison and logic.
 */
public interface Numeric extends Value, Arithmetic, Comparison, Logic
{

   /**
    * Returns this value as a byte (signed 8 bits). The conversion may result in
    * a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type byte.
    */
   byte byteValue();

   /**
    * Returns this value as a short integer (signed 16 bits). The conversion may
    * result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type short.
    */
   short shortValue();

   /**
    * Returns this value as an integer (signed 32 bits). The conversion may
    * result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type int.
    */
   int intValue();

   /**
    * Returns this value as a long integer (signed 64 bits). The conversion may
    * result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type long.
    */
   long longValue();

   /**
    * Returns this value as a float (signed 32 bits IEEE 754). The conversion
    * may result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type float.
    */
   float floatValue();

   /**
    * Returns this value as a double (signed 64 bits IEEE 754). The conversion
    * may result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type double.
    */
   double doubleValue();

   /**
    * Assign a boolean value.
    * 
    * @param v another value.
    */
   void assign(boolean v);

   /**
    * Assign a byte value.
    * 
    * @param v another value. The conversion may result in a loss of precision.
    */
   void assign(byte v);

   /**
    * Assign an int value.
    * 
    * @param v another value. The conversion may result in a loss of precision.
    */
   void assign(int v);

   /**
    * Assign a long value.
    * 
    * @param v another value. The conversion may result in a loss of precision.
    */
   void assign(long v);

   /**
    * Assign short value.
    * 
    * @param v another value. The conversion may result in a loss of precision.
    */
   void assign(short v);

   /**
    * Assign a float value.
    * 
    * @param v another value. The conversion may result in a loss of precision.
    */
   void assign(float v);

   /**
    * Assign a double value.
    * 
    * @param v another value. The conversion may result in a loss of precision.
    */
   void assign(double v);

   /**
    * Check if this value is signed.
    * 
    * @return true if this value is signed and false otherwise.
    */
   // boolean isSigned();
}
