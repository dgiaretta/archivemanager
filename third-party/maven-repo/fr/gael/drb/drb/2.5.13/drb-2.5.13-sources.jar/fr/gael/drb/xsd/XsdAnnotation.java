/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbDefaultMutableNode;
import fr.gael.drb.DrbNode;

/**
 * Declaration of an XML-Schema annotation.
 */
public class XsdAnnotation
{

   // =======================================================================
   // Static part.
   // =======================================================================
   /**
    * annotation tag name.
    */
   final static String TAG = "annotation";

   // =======================================================================
   // Attributes part.
   // =======================================================================
   /**
    * appinfo list.
    */
   private XsdAppinfo[] appinfo;

   /**
    * documentation list.
    */
   private XsdDocumentation[] documentation;

   /**
    * Build an annotation.
    * 
    * @param appinfo XsdAppinfo[]
    * @param documentation The documentation
    */
   public XsdAnnotation(XsdAppinfo[] appinfo, XsdDocumentation[] documentation)
   {
      if (appinfo == null)
      {
         appinfo = new XsdAppinfo[] {};
      }
      this.appinfo = appinfo;
      if (documentation == null)
      {
         documentation = new XsdDocumentation[] {};
      }
      this.documentation = documentation;
   }

   /**
    * Returns a list of documentations.
    * 
    * @return The documentation
    */
   public XsdDocumentation[] getDocumentations()
   {
      return this.documentation;
   }

   /**
    * Return a list of appinfos.
    * 
    * @return XsdAppinfo[]
    */
   public XsdAppinfo[] getAppinfos()
   {
      return this.appinfo;
   }

   /**
    * Format this component into a node.
    * 
    * @return the node
    */
   DrbNode toNode()
   {
      if ((this.appinfo.length == 0) && (this.documentation.length == 0))
      {
         return null;
      }
      final DrbNode annotNode = new DrbDefaultMutableNode(this.TAG);
      annotNode.setNamespaceURI(Namespace.XML_SCHEMA_NAMESPACE);
      for (int i = 0; i < this.documentation.length; i++)
      {
         final DrbNode docNode = this.documentation[i].toNode();
         if (docNode != null)
         {
            annotNode.appendChild(docNode);
         }
      }
      for (int i = 0; i < this.appinfo.length; i++)
      {
         final DrbNode appNode = this.appinfo[i].toNode();
         if (appNode != null)
         {
            annotNode.appendChild(appNode);
         }
      }
      return annotNode;
   }
} // XsdAnnotation
