/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sdf;

import java.util.ArrayList;
import java.util.Arrays;

import org.apache.log4j.Logger;

/**
 * A map of (int[], int) key-value pairs. This class is designed to store values
 * associated to keys. Instead of a HashMap it uses an ArrayList of IntMapEntry
 * items. Using a int[] key, it is possible to retreive the associated int
 * value. For instance, this map can store the offset values corresponding to
 * several occurrences in a tree.
 */
final class IntMap
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(IntMap.class);

   /**
    * The list of items.
    */
   private ArrayList item;

   /**
    * Create a IntMap instance.
    */
   protected IntMap()
   {
      // Create the ArrayList
      this.item = new ArrayList();
   }

   /**
    * Returns the value associated to the key. If the given key is null returns
    * -1. If no entry matches the key returns -1. Else returns the value
    * associated to the key. Note: The search is in O(n*d) where n is the number
    * of elements in the map and d the depth of the structured data file tree.
    * The search is done in reverse order of the ArrayList items.
    * 
    * @param key The key from which to get the value.
    * @return The value associated to the key.
    */
   protected final int get(final int[] key)
   {
      // Local declarations
      IntMapEntry entry;

      // Check parameter
      if (key == null)
      {
         logger.error("IntMap.get() ERROR: " + "Invalid parameter.");
         logger.error("   key is null.");
         return -1;
      }

      // Parse the items
      final int size = this.item.size();
      for (int i = size - 1; i >= 0; i--)
      {
         // Get the map entry
         entry = (IntMapEntry) this.item.get(i);

         // Test key equality
         if (Arrays.equals(entry.getKey(), key))
         {
            // Return the value
            return entry.getValue();
         }
      }
      // At this step no entry matched the key
      return -1;
   }

   /**
    * Adds the key-value pair map entry to the map. If the given key is null
    * nothing is added to the map. The value can be retreive later by the
    * get(key) operation.
    * 
    * @param key The key to identify the value.
    * @param value The value to add in the map.
    */
   protected final void add(final int[] key, final int value)
   {
      // Local declarations
      IntMapEntry entry;

      // Check parameter
      if (key == null)
      {
         logger.warn("IntMap.add() WARNING: " + "Invalid parameter.");
         logger.warn("   key is null, nothing added to the map.");
         return;
      }

      // Create a map entry
      entry = new IntMapEntry(key, value);

      // Add the map entry to the map
      this.item.add(entry);
   }

   /**
    * Creates the parent key corresponding to the given one. Creates a copy of
    * the key elements except for the last one. If the key is null or empty
    * array ({} for root key) then returns null else the length follows the rule :
    */
   protected static final int[] getParentKey(final int[] key)
   {
      // Test key
      if ((key == null) || (key.length == 0))
      {
         return null;
      }

      // Create the parent key : copy elements except the last one
      final int[] parentKey = new int[key.length - 1];
      System.arraycopy(key, 0, parentKey, 0, key.length - 1);

      // Return the parent key
      return parentKey;
   }

   /**
    * Creates a child key correponding to the given one and append the child id.
    * Creates a copy of the key and adds the passed childId as last element of
    * the child key. If the key is null returns null. The length follows the
    * rule :
    */
   protected static final int[] getChildKey(final int[] key, final int child_id)
   {
      // Test key
      if (key == null)
      {
         return null;
      }

      // Create the child key : copy all elements
      final int[] childKey = new int[key.length + 1];
      System.arraycopy(key, 0, childKey, 0, key.length);

      // Add the child id as last element
      childKey[childKey.length - 1] = child_id;

      // Return the child key
      return childKey;
   }

   /**
    * Creates a sibling key correponding to the given one and change the last id
    * Creates a copy of the key and changes the last element of the key with the
    * passed SiblingId. If the key is null returns null. The length follows the
    * rule :
    * <dl>
    * <dd>siblingKey.length = key.length</dd>
    * </dl>
    * 
    * @param key The key used to create the sibling key
    * @param sibling_id The sibling id to use as last element.
    * @return The created child key.
    */
   protected static final int[] getSiblingKey(final int[] key,
         final int sibling_id)
   {
      // Test key
      if (key == null)
      {
         return null;
      }

      // Create the sibling key : copy all elements except the last one
      final int[] siblingKey = new int[key.length];
      System.arraycopy(key, 0, siblingKey, 0, key.length - 1);

      // Add the sibling id as last element
      siblingKey[siblingKey.length - 1] = sibling_id;

      // Return the sibling key
      return siblingKey;
   }

   /**
    * Print a key into a string. For instance it can returns "{3 41 6}" if
    * key={3,41,6}.
    * 
    * @param key The key to print.
    * @return The string containing key info.
    */
   public static final String keyToString(final int[] key)
   {
      // Test parameter
      if (key == null)
      {
         return null;
      }

      // Print the key content
      String info = "{";
      for (int i = 0; i < key.length; i++)
      {
         info = info + key[i];
         if (i < key.length - 1)
         {
            info = info + " ";
         }
      }
      info = info + "}";

      // Return info string
      return info;
   }

   /**
    * Print the map into a string. For instance it can returns "{2 [{3 41 6}
    * 50], [{1} 23]}" in case of to map entries [{3 41 6} 50] and [{1} 23].
    * 
    * @return The string containing map info.
    */
   public final String toString()
   {
      // Print the key content
      String info = "{" + this.item.size() + " ";
      for (int i = 0; i < this.item.size(); i++)
      {
         info = info + (this.item.get(i));
         if (i < this.item.size() - 1)
         {
            info = info + ", ";
         }
      }
      info = info + "}";

      // Return info string
      return info;
   }

   /**
    * Main operation used for unitary tests.
    * 
    * @param args line argument
    */
   public static void main(final String[] args)
   {
      final IntMap map = new IntMap();
      map.get(null);
      map.get(new int[] {});
      System.out.println("map = " + map);
      map.add(new int[] {}, 10);
      map.add(new int[] { 1 }, 11);
      map.add(new int[] { 2 }, 20);
      map.add(new int[] { 1, 0 }, 40);
      map.add(new int[] { 1, 0, 1 }, 90);
      map.add(new int[] { 1, 0, 5 }, 340);

      System.out.println("map = " + map);
      System.out.println("getKey() = "
            + IntMap.keyToString(((IntMapEntry) (map.item.get(5))).getKey()));

      System.out.println("\nparentKey({5,4,3,2}) = "
            + keyToString(getParentKey(new int[] { 5, 4, 3, 2 })));
      System.out.println("\nchildKey({5,4,3,2},7) = "
            + keyToString(getChildKey(new int[] { 5, 4, 3, 2 }, 7)));
      System.out.println("\nsiblingKey({5,4,3,2},7) = "
            + keyToString(getSiblingKey(new int[] { 5, 4, 3, 2 }, 7)));
   }
}// IntMap
