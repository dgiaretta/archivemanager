/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * The BinaryInteger class is a generic wrapper for binary integer values. For
 * all arithmetics operations it is handled as a simple Integer.
 */
public class BinaryInteger extends Int
{

   /**
    * This flag indicates that the number of significants digit is not fixed.
    */
   public static short DIGIT_AS_NEEDED = -1;

   /**
    * Number of significant digit to be used. A value lower than 0 means that
    * this number is variable.
    */
   private int numDigit;

   /**
    * Constructs a BinaryInteger object initialized to the specified int value.
    * 
    * @param v the value of the BinaryInteger.
    */
   public BinaryInteger(final int v)
   {
      super(v);
      this.numDigit = DIGIT_AS_NEEDED;
   }

   /**
    * Constructs a BinaryInteger object initialized to the specified int value.
    * 
    * @param v the value of the BinaryInteger.
    * @param num_digit The number of significant digit to be used. A negative
    *           value denotes a binary with unfixed number of digit.
    * @see DIGIT_AS_NEEDED
    */
   public BinaryInteger(final int v, final int num_digit)
   {
      super(v);
      this.numDigit = num_digit;
   }

   /**
    * Returns a new String object representing this BinaryInteger. The String is
    * a sequence of bits value.
    * 
    * @return a string representation of the object.
    */
   public java.lang.String toString()
   {
      if (this.numDigit < 0)
      {
         return java.lang.Integer.toBinaryString(this.value);
      }
      final char[] binStr = new char[this.numDigit];
      int bitmask = (1 << (this.numDigit - 1));
      for (int i = 0; i < this.numDigit; i++)
      {
         binStr[i] = (bitmask & this.value) == 0 ? '0' : '1';
         bitmask = bitmask >> 1;
      }
      return new java.lang.String(binStr);
   }

   // --------------------------------------------------
   // Value interface implementation
   // -------------------------------------------------
   /**
    * The type identifier of this Integer value.
    * 
    * @return an identifier of the Integer type.
    */
   public int getType()
   {
      return BINARY_INTEGER_ID;
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself is returned. If the conversion is not allowed a
    * ClassCastException is thrown. The type must be a number (BOOLEAN_ID to
    * DOUBLE_ID) or an array.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException is the convertion is impossible
    */
   public Value convertTo(final int type) throws ClassCastException
   {
      if (type == BINARY_INTEGER_ID)
      {
         return this;
      }
      return super.convertTo(type);
   }

   /*
    * public static void main(java.lang.String[] args) { BinaryInteger b0 = new //
    * BinaryInteger(0x23, BinaryInteger.DIGIT_AS_NEEDED); System.out.println(" *
    * digits = " + b0); BinaryInteger b1 = new BinaryInteger(0x23, 8);
    * System.out.println(" 8 digits = " + b1); BinaryInteger b2 = new
    * BinaryInteger(0x23, 10); System.out.println("10 digits = " + b2); }
    */
}
