/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.value.Value;
import fr.gael.drb.value.ValueArray;

/**
 * Wraps a computed element constructor expression of XQuery language.
 */
class ComputedElementConstructorExpression extends ConstructorExpression
{

   /**
    * Logger.
    */
   static private Logger logger =
      Logger.getLogger(ComputedElementConstructorExpression.class);

   /**
    * Name expression
    */
   private Expression name_expression;

   /**
    * Builds an Computed element constructor expression.
    * 
    * @param token the token related to the current expression.
    * @param name string form of the element qualified name.
    */
   public ComputedElementConstructorExpression(final Token token,
         final String name)
   {
      super("Computed Element constructor", token);
      this.name = new QName(name);
      this.name_expression = null;
   }

   /**
    * Builds an Computed element constructor expression.
    * 
    * @param token the token related to the current expression.
    * @param name_expression expression whose evaluation gives the element
    *           qualified name.
    */
   public ComputedElementConstructorExpression(final Token token,
         final Expression name_expression)
   {
      super("Computed Element constructor", token);
      this.name_expression = name_expression;
      this.name = null;
   }

   /**
    * Evaluates the computed element contructor expression.
    * 
    * @param outer_context the dynamic evaluation context to consider.
    * @return the evaluated sequence.
    */
   public DrbSequence evaluate(final DynamicContext outer_context)
   {
      /**
       * Create an inner context.
       */
      final DynamicContext context = new DynamicContext(outer_context);

      ConstructorNode node = null;

      /**
       * Evaluation if required of the qname.
       */
      final QName name = this.processNodeName(context);

      /**
       * Creating the output node
       */
      node = new ConstructorNode(name.getLocalName());

      /**
       * Check the prefix has been bound to an URI, if any.
       */
      this.setNodeURI(context, node, name);

      /**
       * If the main expression is not null, evaluation of it
       */
      this.processContent(context, node);

      node.setNamespaceBindings(this.declaredNamespaces);

      return new DrbDefaultSequence(node);
   }

   /**
    * If the name has been provided as an expression, this method evaluate it
    * and set the result value as the name of the node
    * 
    * @param context The dynamic context of evaluation
    * @return The QName being evaluated
    */
   private QName processNodeName(final DynamicContext context)
   {

      if (this.name != null)
      {
         return this.name;
      }

      if (this.name_expression == null)
      {
         throw new DynamicException(this,
               "The name or the name expression of the element constructor "
                     + "cannot be null");
      }

      final DrbSequence sequence = this.name_expression.evaluate(context);

      if (sequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the name expression");
      }

      final ValueArray array = sequence.atomize();

      if (array.length() != 1)
      {
         throw new TypeException(this,
               "XPTY0004 - The sequence length of the name expression must be one");
      }

      final Value value = array.getElement(0);

      if (!(value instanceof fr.gael.drb.value.String))
      {
         throw new TypeException(
               this,
               "XPTY0004 - Result of the evaluation of the name expression"
                     + " must be a singleton containing either a String or a QName");
      }

      return new QName(value.toString());

   }

   /**
    * Return the separator used when encounter adjacent text nodes among items
    * of a sequence
    * 
    * @return The separator (often a blank space or the empty string)
    */
   protected String getAdjacentTextNodeSeparator()
   {

      return "";
   }
}
