/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * The Short class is a generic wrapper for short values.
 */
public class Short extends AbstractNumeric implements ValueFormat
{
   // =========================================================================
   // Attributes part.
   // =========================================================================
   /**
    * The Short priority.
    */
   final static int PRIORITY = 2;

   /**
    * The Short value.
    */
   short value;

   // =========================================================================
   // Methods part.
   // =========================================================================
   /**
    * Constructs a Short object initialized to the specified short value.
    * 
    * @param v the value of the Short.
    */
   public Short(final short v)
   {
      this.value = v;
   }

   /**
    * Allocates a Short object representing the value argument.
    * 
    * @param v the value of the Short.
    */
   public Short(final int v)
   {
      this.value = (short) v;
   }

   /**
    * Returns a new String object representing this Short.
    * 
    * @return a string representation of the object.
    */
   public java.lang.String toString()
   {
      return java.lang.Short.toString(this.value);
   }

   // -------------------------------------------------------------------------
   // ValueFormat interface implementation
   // -------------------------------------------------------------------------
   // see interface ValueFormat for more information.

   /**
    * Return a string containing the value with a fixed format.
    * 
    * @param length The expected length of the output string
    * @return The formatted string.
    */
   public java.lang.String getFormattedString(final int length)
   {
      return getFormattedString(length, this.value, true);
   }

   /**
    * Return a byte buffer containing the value in a fixed format.
    * 
    * @return The formatted buffer.
    */
   public byte[] getFormattedBuffer()
   {
      return getFormattedBuffer(this.value);
   }

   /**
    * Return a string containing the passed value with a fixed format.
    * 
    * @param length The expected length of the output string
    * @param value The value to use for output string.
    * @param is_signed True if the value is signed, false if unsigned.
    * @return The formatted string.
    */
   public static java.lang.String getFormattedString(final int length,
         final short value, final boolean is_signed)
   {
      if (is_signed)
      {
         return new java.lang.String(new java.text.DecimalFormat(
               "+00000;-00000").format(value));
      }
      else
      {
         return new java.lang.String(new java.text.DecimalFormat(
               "+00000;-00000").format((value & 0xffff)));
      }
   }

   /**
    * Return a byte buffer containing the passed value in a fixed format.
    * 
    * @param value The value to use for output buffer.
    * @return The formatted buffer.
    */
   public static byte[] getFormattedBuffer(final short value)
   {
      final byte[] buffer = new byte[2];
      buffer[0] = (byte) (value >> 8);
      buffer[1] = (byte) (value);
      return buffer;
   }

   // -------------------------------------------------------------------------
   // Value interface implementation
   // -------------------------------------------------------------------------
   // see interface Value for more information.

   /**
    * Returns the current type.
    * 
    * @return the current type.
    */
   public final int getType()
   {
      return Value.SHORT_ID;
   }

   /**
    * Returns the current priority.
    * 
    * @return the current priority.
    */
   public final int getPriority()
   {
      return PRIORITY;
   }

   /**
    * Convert this Short value into the specified type. In case of identity
    * conversion the value itself should be returned. If the conversion is not
    * allowed a ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException if the conversion is impossible
    */
   public final Value convertTo(final int type) throws ClassCastException
   {
      switch (type)
      {
         // Short -> Short conversion
         case Value.SHORT_ID:
         case Value.NUMERIC_ID:
            return this;

            // Short -> Unknown conversion
         default:
            return super.convertTo(type);
      }
   }

   /**
    * assign a new Value to the current one.
    * 
    * @param v the new Value
    */
   public void assign(final Value v)
   {
      final Short vs = (Short) v.convertTo(Value.SHORT_ID);
      this.value = vs.shortValue();
   }

   // --------------------------------------------------------------------------
   // Arithmetic interface implementation
   // --------------------------------------------------------------------------
   // see interface Arithmetic for more information about these operators.
   /**
    * unary Minus
    * 
    * @return the value
    */
   public Value unaryMinus()
   {
      return new Short(-this.value);
   }

   /**
    * Adds the current Value to the current one
    * 
    * @param x the Value to add to
    * @return the current Value added by the current one
    */
   public Value add(Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).add(x);
      }
      x = x.convertTo(Value.NUMERIC_ID);
      return new Short(this.shortValue() + ((Numeric) x).shortValue());
   }

   /**
    * Substracts the current Value by the current one
    * 
    * @param x the Value to substract to
    * @return the current Value substracted by the current one
    */
   public Value sub(Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).sub(x);
      }
      x = x.convertTo(Value.NUMERIC_ID);
      return new Short(this.shortValue() - ((Numeric) x).shortValue());
   }

   /**
    * Multiplies the current Value by the current one
    * 
    * @param x the Value to multiply by
    * @return the current Value multiplied by the current one
    */
   public Value multiply(Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).multiply(x);
      }
      x = x.convertTo(Value.NUMERIC_ID);
      return new Short(this.shortValue() * ((Numeric) x).shortValue());
   }

   /**
    * Divides the current Value by the current one
    * 
    * @param x the Value to divide by
    * @return the current Value divided by the current one
    */
   public final Value divide(Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).divide(x);
      }
      x = x.convertTo(Value.NUMERIC_ID);
      return new Short(this.shortValue() / ((Numeric) x).shortValue());
   }

   /**
    * Calculates the current value modulus the given one.
    * 
    * @param x the Value to modulate by
    * @return the current value modulus the given one
    */
   public Value modulus(Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).modulus(x);
      }
      x = x.convertTo(Value.NUMERIC_ID);
      return new Short(this.shortValue() % ((Numeric) x).shortValue());
   }

   // -------------------------------------------------------------------------
   // Comparison interface implementation
   // -------------------------------------------------------------------------
   // see interface Comparison for more information.
   /**
    * Compares the current Value to the given one
    * 
    * @param x the Value to be compared
    * @return a negative integer, zero, or a positive integer as the argument is
    *         less than, equal to, or greater than the current Value.
    */
   public int compareTo(final Value x)
   {
      if (this.getPriority() >= x.getPriority())
      {
         return (this.shortValue() - ((Numeric) x).shortValue());
      }
      return -((Comparison) x).compareTo(this);
   }

   // -------------------------------------------------------------------------
   // Logic interface implementation
   // -------------------------------------------------------------------------
   // see interface Logic for more information about these operators.
   /**
    * Returns the logical representation of the current Value
    * 
    * @return the logical representation of the current Value
    */
   public final boolean booleanValue()
   {
      return (this.value != 0);
   }

   // -------------------------------------------------------------------------
   // Numeric interface implementation
   // -------------------------------------------------------------------------
   // see interface Numeric for more informations
   /**
    * Returns the byte representation of the Value.
    * 
    * @return the byte representation of the Value.
    */
   public final byte byteValue()
   {
      return (byte) this.value;
   }

   /**
    * Returns the int representation of the Value.
    * 
    * @return the int representation of the Value.
    */
   public final int intValue()
   {
      return this.value;
   }

   /**
    * Returns the long representation of the Value.
    * 
    * @return the long representation of the Value.
    */
   public final long longValue()
   {
      return this.value;
   }

   /**
    * Returns the short representation of the Value.
    * 
    * @return the short representation of the Value.
    */
   public final short shortValue()
   {
      return this.value;
   }

   /**
    * Returns the float representation of the Value.
    * 
    * @return the float representation of the Value.
    */
   public final float floatValue()
   {
      return this.value;
   }

   /**
    * Returns the double representation of the Value.
    * 
    * @return the double representation of the Value.
    */
   public final double doubleValue()
   {
      return this.value;
   }

   /**
    * Assign a boolean Value to the current one.
    * 
    * @param value the Value to set.
    */
   public final void assign(final boolean value)
   {
      this.value = (value ? (short) 1 : (short) 0);
   }

   /**
    * Assign a byte Value to the current one.
    * 
    * @param value the Value to set.
    */
   public final void assign(final byte value)
   {
      this.value = value;
   }

   /**
    * Assign an int Value to the current one.
    * 
    * @param value the Value to set.
    */
   public final void assign(final int value)
   {
      this.value = (short) value;
   }

   /**
    * Assign a short Value to the current one.
    * 
    * @param value the Value to set.
    */
   public final void assign(final short value)
   {
      this.value = value;
   }

   /**
    * Assign a long Value to the current one.
    * 
    * @param value the Value to set.
    */
   public final void assign(final long value)
   {
      this.value = (short) value;
   }

   /**
    * Assign a float Value to the current one.
    * 
    * @param value the Value to set.
    */
   public final void assign(final float value)
   {
      this.value = (short) value;
   }

   /**
    * Assign a double Value to the current one.
    * 
    * @param value the Value to set.
    */
   public final void assign(final double value)
   {
      this.value = (short) value;
   }
}
