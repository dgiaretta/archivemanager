/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * The UnsignedLong class is a generic wrapper for unsigned long values.
 */
public class UnsignedLong extends AbstractNumeric implements ValueFormat
{
   // =========================================================================
   // Attributes part.
   // =========================================================================
   /**
    * The Long priority.
    */
   public final static int PRIORITY = 4;

   /**
    * The Long value.
    */
   protected long value;

   // =========================================================================
   // Methods part.
   // =========================================================================
   /**
    * Constructs an UnsignedLong object initialized to the specified long value.
    * 
    * @param v the value of the UnsignedLong. v is interpreted as a binary
    *           stream.
    */
   public UnsignedLong(final long v)
   {
      this.value = v;
   }

   /**
    * Returns a new String object representing this Integer.
    * 
    * @param value the objcet to represent
    * @return a string representation of the object.
    */
   public static java.lang.String toString(final long value)
   {
      // It is possible to print directly an unsigned long provided it takes at
      // most 63 bits because the bit 64 is reserved for sign coding. So if the
      // long value is positive we can use native JAVA formatter.
      if (value >= 0)
      {
         return java.lang.Long.toString(value);
      }
      else
      {
         // When the value has 64 significant bits, we remove the last digit and
         // print it apart. It is not straightforward to do arithmetic
         // operation with unsigned values. We use binary operator such as
         // << and >> to compute products and divisions which are multiple of 2.
         // The last digit is obtained by using a modulo 10.
         final long v1 = (value >>> 1) / 5; // divide by 10 (= 2 * 5)
         final long v0 = value - (v1 * 10);
         return java.lang.Long.toString(v1) + java.lang.Long.toString(v0);
      }
   }

   // -------------------------------------------------------------------------
   // ValueFormat interface implementation
   // -------------------------------------------------------------------------
   // see interface ValueFormat for more information.

   /**
    * Return a string containing the value with a fixed format.
    * 
    * @param length The expected length of the output string
    * @return The formatted string.
    */
   public java.lang.String getFormattedString(final int length)
   {
      /**
       * Compute the number of zero to put in the string.
       */
      java.lang.String zero_string = "";
      for (int i_zero = 0; i_zero < length - 1; i_zero++)
      {
         zero_string = zero_string + "0";
      }

      return new java.lang.String(new java.text.DecimalFormat("+" + zero_string
            + ";-" + zero_string).format(this.value));

      // return new java.lang.String(new java.text.DecimalFormat(
      // "+00000000000000000000;-00000000000000000000").format(value));

   }

   /**
    * Return a byte buffer containing the value in a fixed format.
    * 
    * @return The formatted buffer.
    */
   public byte[] getFormattedBuffer()
   {
      final byte[] buffer = new byte[8];

      buffer[0] = (byte) (this.value >>> 56);
      buffer[1] = (byte) (this.value >>> 48);
      buffer[2] = (byte) (this.value >>> 40);
      buffer[3] = (byte) (this.value >>> 32);
      buffer[4] = (byte) (this.value >>> 24);
      buffer[5] = (byte) (this.value >>> 16);
      buffer[6] = (byte) (this.value >>> 8);
      buffer[7] = (byte) (this.value);

      return buffer;
   }

   /**
    * Returns a new String object representing this Unsigned Long.
    * 
    * @return a string representation of the object.
    */
   public java.lang.String toString()
   {
      return toString(this.value);
   }

   // ------------------------------------------------------------------------
   // Value interface implementation
   // ------------------------------------------------------------------------
   /**
    * The type identifier of this Long value.
    * 
    * @return an identifier of the Long type.
    */
   public final int getType()
   {
      return Value.UNSIGNED_LONG_ID;
   }

   /**
    * Returns the Long priority
    * 
    * @return the Long priority
    */
   public final int getPriority()
   {
      return PRIORITY;
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself is returned. If the conversion is not allowed a
    * ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException if the conversion is impossible
    */
   public Value convertTo(final int type) throws ClassCastException
   {
      switch (type)
      {
         // UnsignedLong -> UnsignedLong conversion
         case Value.UNSIGNED_LONG_ID:
         case Value.NUMERIC_ID:
            return this;

            // UnsignedLong -> Unknown conversion
         default:
            return super.convertTo(type);
      }
   }

   /**
    * Assign a new Value. An implicit conversion may be performed to make the
    * assignment. This assignment may result in a loss of precision (ex : float
    * to long).
    * 
    * @param v the value to be assigned.
    */
   public void assign(final Value v)
   {
      final Numeric vl = (Numeric) v.convertTo(Value.NUMERIC_ID);
      this.value = vl.longValue();
   }

   // --------------------------------------------------------------------------
   // Arithmetic interface implementation
   // --------------------------------------------------------------------------
   /**
    * Compute the unary minus of this value.
    * 
    * @return The unary minus of this value as signed Long.
    */
   public Value unaryMinus()
   {
      return new Long(-this.value);
   }

   /**
    * Compute an addition.
    * 
    * @param x another value.
    * @return the sum of the two values.
    */
   public Value add(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).add(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      // Check the integrity of the result
      if (this.doubleValue() + num.doubleValue() < 0.0)
      {
         return new Long(this.longValue() + num.longValue());
      }
      else
      {
         return new UnsignedLong(this.longValue() + num.longValue());
      }
   }

   /**
    * Compute a substraction.
    * 
    * @param x another value.
    * @return the difference between the two values.
    */
   public Value sub(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).sub(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      // Check the integrity of the result
      if (this.doubleValue() < num.doubleValue())
      {
         return new Long(this.longValue() - num.longValue());
      }
      else
      {
         return new UnsignedLong(this.longValue() - num.longValue());
      }
   }

   /**
    * Compute a multiplication.
    * 
    * @param x another value.
    * @return the product of the two values.
    */
   public final Value multiply(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).multiply(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      // Check the integrity of the result
      if (num.doubleValue() < 0.0)
      {
         return new Long(this.longValue() * num.longValue());
      }
      else
      {
         return new UnsignedLong(this.longValue() * num.longValue());
      }
   }

   /**
    * Compute a division.
    * 
    * @param x another value.
    * @return the ratio of the two values.
    */
   public final Value divide(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).divide(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      // Check the integrity of the result
      if (num.doubleValue() < 0.0)
      {
         return new Long(this.longValue() / num.longValue());
      }
      else
      {
         final BigInteger bi1 = new BigInteger(this.toString());
         final BigInteger bi2 = new BigInteger(x.toString());
         final BigInteger div = bi1.divide(bi2);
         return new UnsignedLong(div.longValue());
      }
   }

   /**
    * Compute a modulus.
    * 
    * @param x another value.
    * @return the modulus of the values.
    */
   public Value modulus(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).modulus(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      // Check the integrity of the result
      if (this.doubleValue() % num.doubleValue() < 0.0)
      {
         return new Long(this.longValue() % num.longValue());
      }
      else
      {
         final BigInteger bi1 = new BigInteger(this.toString());
         final BigInteger bi2 = new BigInteger(x.toString());
         final BigInteger mod = bi1.mod(bi2);
         return new UnsignedLong(mod.longValue());
      }
   }

   // --------------------------------------------------------------------------
   // Comparison interface implementation
   // --------------------------------------------------------------------------
   // see interface Comparison for more information
   /**
    * Compare the current Value to the given one
    * 
    * @param x the Value to compare with
    * @return a negative integer, zero, or a positive integer as the argument is
    *         less than, equal to, or greater than the current Value.
    */
   public int compareTo(final Value x)
   {
      if (this.getPriority() >= x.getPriority())
      {
         final BigInteger bi1 = new BigInteger(this.toString());
         final BigInteger bi2 = new BigInteger(x.toString());
         return bi1.compareTo(bi2);
      }
      return -((Comparison) x).compareTo(this);
   }

   // --------------------------------------------------------------------------
   // Logic interface implementation
   // --------------------------------------------------------------------------
   // see interface Logic for more information

   /**
    * Returns this value as a boolean
    * 
    * @return the numeric value represented by this object after conversion to
    *         type boolean.
    */
   public final boolean booleanValue()
   {
      return (this.value != 0);
   }

   // --------------------------------------------------------------------------
   // Numeric interface implementation
   // --------------------------------------------------------------------------
   // see interface Numeric for more information
   /**
    * Returns this value as a byte (signed 8 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type byte.
    */
   public final byte byteValue()
   {
      return (byte) (this.value & 0xffL);
   }

   /**
    * Returns this value as an integer (signed 32 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type int.
    */
   public final int intValue()
   {
      return (int) (this.value & 0xffffffffL);
   }

   /**
    * Returns this value as a long integer (signed 64 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type long.
    */
   public final long longValue()
   {
      return (this.value);
   }

   /**
    * Returns this value as a short integer (signed 16 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type short.
    */
   public final short shortValue()
   {
      return (short) (this.value & 0xffffL);
   }

   /**
    * Returns this value as a float (signed 32 bits IEEE 754). The conversion
    * may result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type float.
    */
   public final float floatValue()
   {
      return (this.value >>> 1) * 2.0f;
   }

   /**
    * Returns this value as a BigInteger. The conversion may result in a loss of
    * precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type BigInteger.
    */
   protected BigInteger integerValue()
   {
      return new BigDecimal(this.toString()).toBigInteger();
   }

   /**
    * Returns this value as a BigDecimal. The conversion may result in a loss of
    * precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type BigDecimal.
    */
   protected BigDecimal decimalValue()
   {
      return new BigDecimal(this.toString());
   }

   /**
    * Returns this value as a double (signed 64 bits IEEE 754). The conversion
    * may result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type double.
    */
   public final double doubleValue()
   {
      return (this.value >>> 1) * 2.0;
   }

   /**
    * Assign a boolean value.
    * 
    * @param value another value.
    */
   public final void assign(final boolean value)
   {
      this.value = (value ? 1 : 0);
   }

   /**
    * Assign a byte value.
    * 
    * @param value another value.
    */
   public final void assign(final byte value)
   {
      this.value = (value & 0xffL);
   }

   /**
    * Assign an int value.
    * 
    * @param value another value.
    */
   public final void assign(final int value)
   {
      this.value = (value & 0xffffffffL);
   }

   /**
    * Assign short value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final short value)
   {
      this.value = (value & 0xffffL);
   }

   /**
    * Assign a long value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final long value)
   {
      this.value = value;
   }

   /**
    * Assign a float value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final float value)
   {
      this.value = (long) value;
   }

   /**
    * Assign a double value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final double value)
   {
      this.value = (long) value;
   }

   /*
    * public static void main(java.lang.String[] args) { UnsignedLong ul = new
    * UnsignedLong(-1L); System.out.println(java.lang.Long.MIN_VALUE);
    * System.out.println(java.lang.Long.MAX_VALUE);
    * System.out.println(ul.toString()); ul.assign((byte)-1);
    * System.out.println("in Byte = " + ul.toString()); ul.assign((short)-1);
    * System.out.println("in Short = " + ul.toString()); ul.assign((int)-1);
    * System.out.println("in Int = " + ul.toString()); ul.assign((long)-1);
    * System.out.println("in Long = " + ul.toString()); ul.assign((float)-1);
    * System.out.println("in Float = " + ul.toString()); ul.assign((double)-1);
    * System.out.println("in Double = " + ul.toString());
    * System.out.println("out Byte = " + ul.byteValue());
    * System.out.println("out Short = " + ul.shortValue());
    * System.out.println("out Int = " + ul.intValue()); System.out.println("out
    * Long = " + ul.longValue()); System.out.println("out Float = " +
    * ul.floatValue()); System.out.println("out Double = " + ul.floatValue());
    * ul.assign(-24L); System.out.println("Val = " + ul); UnsignedLong vl = new
    * UnsignedLong(13L); Value diff = ul.sub(vl); System.out.println("Sub = " +
    * diff + " type = " + diff.getType()); Value sum = vl.add(ul);
    * System.out.println("Add = " + sum + " type = " + sum.getType());
    * vl.assign(78L); Numeric div = (Numeric)ul.divide(vl);
    * System.out.println("Div = " + div + " type = " + div.getType()); Value
    * prod = div.multiply(vl); System.out.println("Mul = " + div + " type = " +
    * prod.getType()); Value mod = ul.modulus(vl); System.out.println("Mod = " +
    * mod + " type = " + mod.getType()); int cmp = ul.compareTo(vl);
    * System.out.println("Cmp = " + cmp); BigInteger bi1 = new
    * BigInteger(ul.toString()); BigInteger bi2 = new BigInteger(vl.toString()); }
    */
} // UnsignedLong
