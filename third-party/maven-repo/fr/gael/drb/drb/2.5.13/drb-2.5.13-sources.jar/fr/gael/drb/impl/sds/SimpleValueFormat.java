/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import fr.gael.drb.value.Value;

/**
 * Class to format the value. Used to create an output string or buffer to write
 * the value in a file.
 */
class SimpleValueFormat implements ValueFormat
{
   /**
    * Return a string containing the value with a fixed format.
    * 
    * @param value The input value.
    * @return The formatted string.
    */
   public java.lang.String formatString(final Value value)
   {
      return value.toString();
   }

   /**
    * Return a byte buffer containing the value in a fixed format.
    * 
    * @param value The input value.
    * @return The formatted buffer.
    */
   public byte[] formatBytes(final Value value)
   {
      return ((fr.gael.drb.value.ValueFormat) value).getFormattedBuffer();
   }
}
