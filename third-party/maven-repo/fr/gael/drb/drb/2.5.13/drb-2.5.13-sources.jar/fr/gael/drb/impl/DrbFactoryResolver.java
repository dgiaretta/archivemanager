/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl;

import java.util.Hashtable;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbFactoryImpl;
import fr.gael.drb.DrbNode;
import fr.gael.drb.meta.DrbMetadata;
import fr.gael.drb.meta.DrbMetadataResolver;
import fr.gael.drb.meta.MetadataResolver;
import fr.gael.drb.value.Value;

/**
 * Abstract factory resolver. Registered metadata resolvers must identifies the
 * target factory with the format property.
 */
public abstract class DrbFactoryResolver
{
   /**
    * A logger for this class.
    */
   private static Logger logger = Logger.getLogger(DrbFactoryResolver.class);

   /**
    * The available metadata resolvers. They must provide a property named
    * "format" corresponding to the resource format. e.g XML 
    */
   static private DrbMetadataResolver metadataResolver = null;

   static
   {
      // Get the metadata resolver property if defined
      final String metadata_resolver_property =
         System.getProperty("fr.gael.drb.meta.DrbMetadataResolver");

      // If defined instanciate the defined metadata resolver and assign it.
      // Return to default resolver in any case of error
      if (metadata_resolver_property != null)
      {
         try
         {
            // Get the resolver class referenced as property
            final Class<?> metadata_resolver_class =
               ClassLoader.getSystemClassLoader().loadClass(
                     metadata_resolver_property);

            // Create new instance and assign the resolver
            metadataResolver =
               (DrbMetadataResolver) metadata_resolver_class.newInstance();
         }
         catch (final ClassNotFoundException exception)
         {
            logger.warn("Cannot find metadata resolver class ("
                  + exception.getMessage() + ")");
         }
         catch (final IllegalAccessException exception)
         {
            logger.warn("Cannot access metadata resolver class ("
                  + exception.getMessage() + ")");
         }
         catch (final InstantiationException exception)
         {
            logger.warn("Cannot instanciate metadata resolver class ("
                  + exception.getMessage() + ")");
         }
         catch (final Exception exception)
         {
            logger.warn("Cannot get metadata resolver class ("
                  + exception.getMessage() + ")");
         }
         finally
         {
            if (metadataResolver != null)
            {
               logger.info("User defined metatadata resolver: \""
                     + metadata_resolver_property + "\"");
            }
            else
            {
               logger.warn("Using default metadata resolver.");
               metadataResolver = new DrbDefaultMetadataResolver();
            }
         }
      }
      else
      {
         metadataResolver = new DrbDefaultMetadataResolver();
      }
   }

   /**
    * The available factory.
    */
   static private Hashtable<String, String> factoryHash =
      new Hashtable<String, String>();

   static
   {
      // Statically Known Factories
      factoryHash.put("file", "fr.gael.drb.impl.file.FileFactory");
      //factoryHash.put("ftp", "fr.gael.drb.impl.ftp.FtpFactory");
      factoryHash.put("sdf", "fr.gael.drb.impl.sds.SdfFactory");
      factoryHash.put("xml", "fr.gael.drb.impl.xml.XmlFactory");
   }

   /**
    * Cache of already loaded factories
    */
   static private Hashtable<String, DrbFactoryImpl> factoryCacheHash =
      new Hashtable<String, DrbFactoryImpl>();

   /**
    * Retrieves an implementation factory denoted by a given implementation
    * identifier.
    * <p>
    * Algorithm: the method looks first in this class internal register of
    * implementation factories for creating an instance of the requested
    * {@link fr.gael.drb.DrbFactoryImpl} object. If the factory identifier was
    * no found in the register, the method attempts to load an implementation
    * factory class that would follow the pattern
    * <code>fr.gael.drb.impl.&lt;identifier>.&lt;Identifier>Factory</code>,
    * where <code>&lt;identifier></code> is the lower cased implementation
    * identifier annd <code>&lt;Identifier></code> is the <a
    * href="http://en.wikipedia.org/wiki/CamelCase">lowerCamlCase</a> form of
    * the same factory identifier. As an example, for the given "Xml"
    * identifier, the searched class path would be
    * <code>fr.gael.drb.impl.xml.XmlFactory</code>.
    * </p>
    * <p>
    * Note: the implementation identification is not case sensitive so, for
    * example "file", "File" or "fIlE" would match the same implementation.
    * </p>
    * 
    * @param implementation_identifier the implementation identifier
    * @return an implementation factory or null if not found.
    * @throws NullPointerException if the provided identifier is null.
    */
   public static DrbFactoryImpl resolveImpl(
         final String implementation_identifier) throws NullPointerException
   {
      // Check that provided identifier is not null.
      if (implementation_identifier == null)
      {
         throw new NullPointerException(
               "Cannot resolve implementation factory from a null identifier.");
      }

      // Lower case input identifier.
      final String lower_case_identifier =
         implementation_identifier.toLowerCase();

      // Get the implementation factory from the cache is already available
      DrbFactoryImpl impl = factoryCacheHash.get(lower_case_identifier);

      if (impl != null)
      {
         return impl;
      }

      // Get the implementation factory class path from the register
      String impl_name = factoryHash.get(lower_case_identifier);

      // If the factory class pass has not been found in the register, try to
      // discover it from the standard factory implementation pattern
      if (impl_name == null)
      {
         // Construction the factory name from the implementation identifier
         // The pattern has the general from :
         // fr.gael.drb.impl.<identifier>.<IdentifierFactory>
         // ex: fr.gael.drb.impl.xml.XmlFactory is the XML implementation
         final String factory_name =
            lower_case_identifier.substring(0, 1).toUpperCase()
                  + lower_case_identifier.substring(1) + "Factory";

         impl_name =
            "fr.gael.drb.impl." + lower_case_identifier + "." + factory_name;
      }

      // Get an instance of the implementation factory
      try
      {
         impl = (DrbFactoryImpl) Class.forName(impl_name).newInstance();

         logger.debug("Implementation Factory \"" + impl_name + "\" loaded.");

         // Cache the loaded factory if found
         if (impl != null)
         {
            factoryCacheHash.put(lower_case_identifier, impl);
            logger.debug("Implementation Factory \"" + impl_name + "\" cached.");
         }

         // Return the loaded factory
         return (DrbFactoryImpl) impl;
      }
      catch (final Exception exception)
      {
         logger.warn("Cannot get new instance of \"" + impl_name
               + "\" implementation factory (" + exception.getMessage() + ").");
      }

      // Return nothing if the factory has not been found
      return null;
   } // End resolveImpl(String)

   /**
    * Resolve a specific implementation that handle the specified base node.
    * 
    * @param base_node the specified base node.
    * @return an implementation.
    */
   public static DrbFactoryImpl resolveImpl(final DrbNode base_node)
   {
      if (getMetadataResolver() == null)
      {
         return null;
      }

      final DrbMetadata metadata =
         getMetadataResolver().resolveMetadata(base_node);

      if (metadata != null)
      {

         // Identifies node format
         final Value factory_id =
            metadata.getProperty("implementationIdentifier");

         if (factory_id != null)
         {

            // Locate factory (if available)
            final DrbFactoryImpl factory = resolveImpl(factory_id.toString());

            return factory;
         }
      }

      return null;
   } // End resolveImpl(DrbNode)

   public static DrbMetadataResolver getMetadataResolver()
   {
      return metadataResolver;
   }

   public static void setMetadataResolver(
         final DrbMetadataResolver metadata_resolver)
   {
      metadataResolver = metadata_resolver;
   }

   /**
    * Registers an implementation that handle the specified format.
    * 
    * @param format unique identifier of the factory
    * @param classpath the classpath of the registered factory
    */
   public static void registerFactory(final String format, final String classpath)
   {
      factoryHash.put(format, classpath);
   }

   /**
    * Registers a schema location.
    * 
    * @param extension unique identifier of the schema
    * @param schema_location the location path of the registered schema
    * @deprecated the schema location should now be deduced from the DrbMetadata
    *             associated to the items. Calls to this operations now are
    *             equivalent to
    *             <code>{@link DrbFactoryResolver#getMetadataResolver()}.
    *             registerSchemaLocation(extension, schema_location)</code>.
    *             This only if the current resolver is the
    *             {@link fr.gael.drb.impl.DrbDefaultMetadataResolver}.
    * @see fr.gael.drb.impl.DrbDefaultMetadataResolver#registerSchemaLocation(
    *      String, String)
    */
   public static void registerSchema(final String extension,
         final String schema_location)
   {
      final DrbMetadataResolver resolver = getMetadataResolver();

      if ((resolver != null) && (resolver instanceof DrbDefaultMetadataResolver))
      {
         DrbDefaultMetadataResolver.registerSchemaLocation(extension,
               schema_location);
      }
   } // End registerSchema()

   /**
    * Registers a metadata resolver
    * 
    * @param metadata a metadata resolver
    * @deprecated {@link fr.gael.drb.impl.DrbFactoryResolver} no longer support
    *             multiple {@link fr.gael.drb.meta.DrbMetadataResolver}'s. For
    *             compatibility purpose, this method now is equivalent to
    *             {@link #setMetadataResolver(DrbMetadataResolver)} that
    *             replaces the current value. This method may be removed in a
    *             successive version.
    */
   public static void registerMetadata(final MetadataResolver metadata)
   {
      setMetadataResolver(metadata);
   }
} // End DrbFactoryResolver
