/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

/**
 * Abstract implementation of the Variable interface.
 * <p>
 * This class provides a default implementation of the Variable interface and in
 * particular the management of the name and the sequence type of the variable.
 * A variable cannot be declared without name. Unless specified, the sequence
 * type is
 * 
 * <pre>
 * &quot;xs:anyType&quot;
 * </pre>.
 * </p>
 * <p>
 * This abstract implementation does not provide mechanism to hold the value of
 * the variable.
 * </p>
 */
abstract class AbstractVariable implements Variable
{
   /**
    * The name of the variable.
    */
   private QName name = null;

   /**
    * The sequence type of the variable.
    */
   private SequenceType sequenceType = new SequenceType();

   /**
    * Copy constructor. Build a variable from an existing variable.
    * 
    * @param variable an input variable.
    */
   AbstractVariable(final AbstractVariable variable)
   {
      this.name = variable.name;
      this.sequenceType = variable.sequenceType;
   }

   /**
    * Builds a variable base on the string form of its qualified name.
    * 
    * @param name string form of the variable qualified name.
    */
   AbstractVariable(final QName name)
   {
      if (name == null)
      {
         throw new NullPointerException(
               "A variable cannot be instanciated without name.");
      }

      this.name = new QName(name);
   }

   /**
    * Builds a variable base on the string form of its qualified name and its
    * assigned sequence type.
    * 
    * @param name string form of the variable qualified name.
    * @param sequence_type the type of the variable.
    */
   AbstractVariable(final QName name, final SequenceType sequence_type)
   {
      if (name == null)
      {
         throw new NullPointerException(
               "A variable cannot be instanciated without name.");
      }

      this.name = new QName(name);

      this.sequenceType = sequence_type;
   }

   /**
    * Returns the qualified name of the variable. Any variable shall return a
    * qualified name, even if it is not prefixed.
    * 
    * @return the qualified name of the variable.
    */
   public QName getQName()
   {
      return this.name;
   }

   /**
    * Returns the string form of the qualified name of the variable.
    * 
    * @return the string form of the qualified name.
    */
   public String getName()
   {
      return this.name.getName();
   }

   /**
    * Assigns a new name to the variable. The provided name shall be the
    * qualified name of the variable such as the one provided at construction.
    * The operation replaces the old name with the new one although the prefix
    * part has changed or not. The operation raises a NullPointerException if
    * the provided name is null.
    * 
    * @param name the new qualified name of the variable.
    */
   protected void setName(final String name)
   {
      if (name == null)
      {
         throw new NullPointerException(
               "Cannot replace name with a null reference.");
      }

      this.name = new QName(name);
   }

   /**
    * Returns the sequence type of the variable. The variable may not have an
    * asigned sequence type. A null reference is therefore returned.
    * 
    * @return the sequence type of the variable.
    */
   protected SequenceType getSequenceType()
   {
      return this.sequenceType;
   }

   /**
    * Returns the string form of the qualified name of the sequence type of the
    * variable. The name of the sequence type does not include the occurence
    * indicator.
    * 
    * @return the string form of the qualified name of the sequence type.
    */
   public String getSequenceTypeName()
   {
      if (this.sequenceType != null)
      {
         return this.sequenceType.getName();
      }
      else
      {
         return null;
      }
   }

   /**
    * Checks if this variable is declared as external. External variables are
    * declared in the prolog and are initialized through the query environment.
    * 
    * @return true if this variable is external and false otherwise.
    */
   public boolean isExternal()
   {
      return false;
   } // isExternal

   /**
    * Returns a detailed description of the variable.
    * 
    * @return the description of the variable.
    */
   public String toString()
   {
      if (this.sequenceType != null)
      {
         return this.name.getName() + this.sequenceType;
      }
      else
      {
         return this.name.getName();
      }
   }

   /**
    * Reports the duplicating operation as abstract.
    * 
    * @return the duplicated instance of the variable.
    */
   public abstract Object clone();
}
