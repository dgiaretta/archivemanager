/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import org.apache.log4j.Logger;

/**
 * A key that represents the abstract path of a block in the SDF tree.
 */
class BlockKey
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(BlockKey.class);

   /**
    * Key of the block. It is an array containing the occurrence indexes of the
    * block and all its ancestors up to the root block of the structured file.
    * Root index is omitted because it's always 0. Values start from 0 for the
    * first index. The number of indexes corresponds to the depth in the tree,
    * having depth=0 for the root block.
    */
   private int[] key;

   /**
    * Create a BlockKey instance with a key. The key must be not null.
    * 
    * @param key The key of the map entry.
    */
   protected BlockKey(final int[] key)
   {
      // Check parameters
      if (key == null)
      {
         logger.error("BlockKey.BlockKey() ERROR: " + "Invalid parameter.");
         logger.error("   key = null");
      }

      // Set the values
      this.key = key;
   }

   /**
    * Returns the key of the map entry.
    * 
    * @return The key of the map entry.
    */
   protected final int[] getKey()
   {
      return this.key;
   }

   /**
    * Returns the index at the specified depth in the key.
    * 
    * @param depth the depth in the key starting at 0.
    * @return The index at the specified depth.
    */
   protected int getIndex(final int depth)
   {
      if ((this.key == null) || (depth >= this.key.length))
      {
         return 0;
      }
      else
      {
         return this.key[depth];
      }
   }

   /**
    * Set the index at the specified depth in the key.
    * 
    * @param depth the depth in the key stating at 0.
    * @param index the index.
    */
   protected void setIndex(final int depth, final int index)
   {
      if ((this.key != null) && (depth < this.key.length))
      {
         this.key[depth] = index;
      }
   }

   /**
    * Print the key-value pair info into a string. For instance it can returns
    * "[{3 41 6} 50]" if key={3,41,6} and value=50.
    * 
    * @return The string containing key-value pair info.
    */
   public final String toString()
   {
      // Test parameter
      if (this.key == null)
      {
         return null;
      }

      return IntMap.keyToString(this.key);
   }

   /**
    * Main operation used for unitary tests.
    * 
    * @param args String[]
    */
   public static void main(final String[] args)
   {
      final BlockKey k1 = new BlockKey(new int[] {});
      final BlockKey k2 = new BlockKey(new int[] { 1, 4 });
      final BlockKey k3 = new BlockKey(new int[] { 1, 4, 2 });

      System.out.println("k1 = " + k1);
      System.out.println("k2 = " + k2);
      System.out.println("k3 = " + k3);
      System.out.println("k3.getKey().length = " + k3.getKey().length);
   }
}
