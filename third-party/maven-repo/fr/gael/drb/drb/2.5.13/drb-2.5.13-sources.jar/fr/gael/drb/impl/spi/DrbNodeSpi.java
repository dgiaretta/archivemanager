/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.spi;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAbstractNode;
import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultMutableNode;
import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbFactory;
import fr.gael.drb.DrbFactoryImpl;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.DrbNodesChangeEvent;
import fr.gael.drb.DrbNodesChangeListener;
import fr.gael.drb.DrbNodesChangeProducer;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.DrbUpdateImpl;
import fr.gael.drb.impl.DrbFactoryResolver;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.value.Value;
import fr.gael.drb.xsd.Namespace;

/**
 * Service Provider Interface. This interface allows to plug services on a node.
 * For instance, DrbNodeSpi is able to open standard archives (Tar, Jar, Zip)
 * and documents (XML).
 */
public class DrbNodeSpi extends DrbNodeImpl
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(DrbNodeSpi.class);

   /**
    * The base node.
    */
   protected DrbNode baseNode;

   /**
    * The parent.
    */
   private DrbNode parent;

   /**
    * A sub-implementation factory that can (and may already have) create
    * sub-implementation children for the base node.
    */
   private DrbFactoryImpl subImplFactory = null;

   /**
    * Denotes whether a resolution of sub-implementation factory has already
    * been probed.
    */
   private boolean isSubImplFactoryResolved = false;

   /**
    * Sub impl must be preferred to subImplChildren, to let the sub 
    * implementation manage informations.
    */
   private DrbNode subImpl = null;

   /**
    * To be removed after optimization of the resolvers cf. constructor below.
    */
   static private boolean isWarningPrinted = false;

   /**
    * Shall the sub-implementation be resolved?
    */
   boolean isSubImplChildrenResolved = false;
   /**
    * Builds a DrbNodeSpi from a base node.
    * 
    * @param base_node The node to be wrapped. This parameter shall never be
    *           null.
    */
   public DrbNodeSpi(final DrbNode base_node)
   {
      this (base_node, null);
   }

   /**
    * Builds a DrbNodeSpi from a base node and control if this given base should
    * be wrapped or cloned i.e. wrap around the same node as the provided node
    * and inheriting from the potentially resolved sub-implementations.
    * 
    * @param base_node The node to be wrapped. This parameter shall never be
    *           null.
    * @param clone_if_node_spi denotes whether this constructor should attempt
    *           to clone the <code>base_node</code> if this latter is also a
    *           {@link DrbNodeSpi}.
    */
   public DrbNodeSpi(final DrbNode base_node, final boolean clone_if_node_spi)
   {
      this(base_node);

      if ((clone_if_node_spi) && (base_node instanceof DrbNodeSpi))
      {
         final DrbNodeSpi node_to_clone = (DrbNodeSpi) base_node;

         this.baseNode = node_to_clone.baseNode;
         this.parent = node_to_clone.parent;
         this.subImplFactory = node_to_clone.subImplFactory;
         this.isSubImplFactoryResolved = node_to_clone.isSubImplFactoryResolved;
      }
   }

   /**
    * Builds a DrbNodeSpi from a base node and a parent
    * 
    * @param base_node The node to be wrapped. This parameter shall never be
    *           null.
    * @param parent node to be considered as the parent of the
    *           <code>base_node</code>.
    */
   public DrbNodeSpi(final DrbNode base_node, final DrbNode parent)
   {
      // Prevent initialization with a null base node
      if (base_node == null)
      {
         final NullPointerException exception =
            new NullPointerException(
               "Cannot initialize a DrbNodeSpi class with a null base_node");

         if (logger.isDebugEnabled())
         {
            logger.debug("DrbNodeSpi contruction error", exception);
         }

         throw exception;
      }

      // Assigns base node
      this.baseNode = base_node;

      // TODO: optimize resolvers to relax this constraint
      // Until optimization of the resolvers, only node from the File
      // implementations are subject of the DrbNodeSpi switch
      
      DrbAttribute dir_attr = base_node.getAttribute("directory");

      if ((dir_attr == null) || (dir_attr.getValue() == null) ||
           "true".equals(dir_attr.getValue().toString()))
      {
         this.isSubImplChildrenResolved = true;
         if ((!isWarningPrinted)
               && (logger.isEnabledFor(org.apache.log4j.Level.WARN)))
         {
            final String base_package = base_node.getClass().getPackage().getName();
            logger.debug("Sub-implemenation resolver is disabled from "
                  + base_package + " nodes until future optimization "
                  + "(this message will not be repeated).");

            isWarningPrinted = true;
         }
      }

      if (logger.isDebugEnabled())
      {
         logger.debug("[DRB SPI] Current implementation = "
               + this.getClass().getName());
      }
      this.parent = parent;
   }
   
   private DrbNode getDelegateNode ()
   {
      DrbNode impl = this.getSubImpl();
      if (impl==null)
      {
         impl=this.baseNode;
      }
      
      if (impl==null)
         throw new NullPointerException("No node to wrap.");
      
      return impl;
   }

   /**
    * Indicates whether this node is "equal to" to another node. See
    * Object.equals() for the general contract of this method.
    * 
    * @param obj another value.
    * @return true if this object is the same as the obj argument
    */
   public boolean equals(final Object obj)
   {
      // Check reference equality
      if (this == obj)
      {
         return true;
      }

      // Check I/O
      if (obj instanceof DrbNodeSpi)
      {
         final DrbNodeSpi spi_node = (DrbNodeSpi) obj;
         if (this.baseNode == null)
         {
            return false;
         }
         return this.baseNode.equals(spi_node.baseNode);
      }

      // Otherwise the object is different
      return false;
   } // equals

   /**
    * Adds a listener to the producer. This operation enables to add a nodes 
    * change listener to the implementing class. Any change performed by the
    * implementing class will be notified by a DrbNodesChangeEvent fired through
    * the specific triggers (i.e. operations) of the listeners. In case of
    * problem, no error as well as exception is raised.
    * 
    * @param listener The listener to be added in the list of the implementing
    *           class.
    */
   public void addNodesChangeListener(final DrbNodesChangeListener listener)
   {
      if (this.baseNode instanceof DrbNodesChangeProducer)
      {
         ((DrbNodesChangeProducer) this.baseNode)
            .addNodesChangeListener(listener);
      }
      else
      {
         super.addNodesChangeListener(listener);
      }
   }

   /**
    * Removes a listener to the producer. This operation enables to remove a
    * nodes change listener to the implementing class. This listener is supposer
    * to have been previously inserted with the addNodesChangeListener()
    * operation. In case of null parameter or unsuccessful retrieval, no error
    * as well as exception is raised.
    * 
    * @param listener The listener to be removed in the list of the implementing
    *           class.
    */
   public void removeNodesChangeListener(final DrbNodesChangeListener listener)
   {
      if (this.baseNode instanceof DrbNodesChangeProducer)
      {
         ((DrbNodesChangeProducer) this.baseNode)
            .removeNodesChangeListener(listener);
      }
      else
      {
         super.removeNodesChangeListener(listener);
      }
   }

   /**
    * Closes this node and releases any system resources associated with the
    * pointed file. A closed node cannot perform input or output operations and
    * cannot be reopened.
    * 
    * @param deep if this flag is disabled,the implementation shall not release
    *           the resources shared with the descendants.
    */
   public void close(final boolean deep)
   {
      // Only the root can be closed.
      // If the deep flag is not activated, we do not close the children
      if (this.baseNode instanceof DrbNodeImpl)
      {
         ((DrbNodeImpl) this.baseNode).close(deep);
      }
      // Also cleanup inner sub-implementation if any
      if (deep && (getSubImpl()!=null) && (getSubImpl() instanceof DrbNodeImpl))
      {
         ((DrbNodeImpl)getSubImpl()).close(deep);
      }
   }

   /**
    * Returns the sub-implementation factory if any.
    * 
    * @return DrbFactoryImpl
    */
   protected DrbFactoryImpl getSubImplFactory()
   {
      if (!this.isSubImplFactoryResolved)
      {
         this.subImplFactory = DrbFactoryResolver.resolveImpl(this);
         this.isSubImplFactoryResolved = true;
      }
      return this.subImplFactory;
   }
   
   /**
    * SubImpl it the sub-implementation designated by this SPI.
    * @return the sub implementation hidden behind this node.
    */
   private DrbNode getSubImpl ()
   {
      if (logger.isDebugEnabled())
      {
         logger.debug("[DRB SPI] Retrieving sub-implementation of node \""
               + this.getName() + "\"...");
      }
      
      if (!this.isSubImplChildrenResolved && (this.subImpl == null))
      {
         // Get sub-implementation factory matching the this node, if any
         final DrbFactoryImpl impl = this.getSubImplFactory();
         if (impl == null)
            return null;
         // Open the sub-implementation child node
         this.subImpl = impl.open(this);
      }
      return this.subImpl;
   }

   /**
    * Sets a sub-implementation In case of success a structure change event is
    * fired on the current node.
    * 
    * @param path the schema path to be set.
    * @throws UnsupportedOperationException This exception is raised when the
    *            schema cannot be applied to this node.
    */
   public final void setSchema(final String path)
      throws UnsupportedOperationException
   {
      /**
       * Check parameter.
       */
      if (path == null)
      {
         logger.error("DrbNodeSpi.setSchema(): Invalid path.");
         throw new UnsupportedOperationException(
            "DrbNodeSpi.setSchema() : Invalid path.");
      }

      /**
       * Opens the schema
       */
      DrbNode schema = DrbFactory.openURI(path);

      if (schema == null)
      {
         logger.error("DrbNodeSpi.setSchema(): Cannot open schema " + path);
         throw new UnsupportedOperationException(
            "DrbNodeSpi.setSchema() : Cannot open schema " + path);
      }
      
      this.setSchema(schema);

   } // End setSchema(String)

   public final void setSchema(final DrbNode schema)
   {
      /**
       * Opens the sub-implementation.
       */
      try
      {
         final DrbNode node = new fr.gael.drb.impl.sds.SdfFactory().open(
            this.baseNode, schema, schema.getPath());
         DrbDefaultMutableNode file_node = new DrbDefaultMutableNode(
            this.baseNode.getName(), this.baseNode.getParent(), 
            this.baseNode.getIndex(), this.baseNode.getPreviousSibling(),
            this.baseNode.getNextSibling());

         // prepare the children list.
         DrbDefaultNodeList list = new DrbDefaultNodeList();
         list.add(node);
         file_node.setChildren(list);
      
         this.subImpl = file_node;
         this.structureChanged(new DrbNodesChangeEvent(this));
      }
      catch (Exception e)
      {
         logger.error(
            "DrbNodeSpi.setSchema(): Cannot retreive a sub implementation.");
         throw new UnsupportedOperationException(
            "DrbNodeSpi.setSchema(): Cannot retreive a sub implementation.", e);
      }

   }
   /**
    * Name of the node. Returns the name of the node.This name is the canonical
    * name of the node. It does not contains any prefix, path and location
    * part.This name clearly identifies the node in its parent depending only
    * from its occurence number and its index. All nodes provided by an
    * implementation is named. Therefore this operation never returns null
    * value. An empty string is however allowed if the node is unique (e.g. non
    * named root node).
    * 
    * @return The name of the node.
    */
   public String getName()
   {
      return this.baseNode.getName();
   }

   /**
    * Name of the node. Returns the name of the node.This name is the canonical
    * name of the node. It does not contains any prefix, path and location
    * part.This name clearly identifies the node in its parent depending only
    * from its occurence number and its index. All nodes provided by an
    * implementation is named. Therefore this operation never returns null
    * value. An empty string is however allowed if the node is unique (e.g. non
    * named root node).
    * 
    * @return The name of the node.
    */
   protected String getXPathName()
   {
      if (this.baseNode instanceof DrbAbstractNode)
      {
         return this.getXPathName((DrbAbstractNode) this.baseNode);
      }
      else
      {
         return super.getXPathName();
      }
   }

   /**
    * Check if this node may have multiple occurrence. If the base node is an
    * instance of DrbAbstractNode, this method will simply call its
    * allowsMultiOccurrence() method. Otherwise, it will use the default
    * implementation.
    * 
    * @return true if the children may have a multiple occurrence and false
    *         otherwise.
    * @see fr.gael.drb.DrbAbstractNode#allowsMultiOccurrence()
    */
   public boolean allowsMultiOccurrence()
   {
      if (this.baseNode instanceof DrbAbstractNode)
      {
         return ((DrbAbstractNode) this.baseNode).allowsMultiOccurrence();
      }
      else
      {
         return super.allowsMultiOccurrence();
      }
   } // allowsMultiOccurrence

   /**
    * The path of the base node. This implementation simply call the getPath()
    * method of the base node.
    * 
    * @return The path of the base node.
    * @see fr.gael.drb.DrbNode See the DrbNode interface for the general
    *      contract
    */
   public String getPath()
   {
      try
      {
         return this.baseNode.getPath();
      }
      catch (final Exception e)
      {
         e.printStackTrace();
         return null;
      }
   }

   /**
    * Index of the node. Returns the index of the node in its parent children
    * list. This index starts from 0 and takes into account all occurences of
    * nodes disregrading the type of nodes. If the node has not parent the index
    * may not be available: the operation returns therefore a negative value.
    * 
    * @return The index of the node or negative value.
    */
   public int getIndex()
   {
      try
      {
         return this.baseNode.getIndex();
      }
      catch (final Throwable e)
      {
         logger.debug("DrbNodeSpi.getIndex(): " + e);
         e.printStackTrace();
         return -1;
      }
   } // getIndex

   /**
    * Get namespace URI. The namespace URI of this node, or null if it is
    * unspecified. This is not a computed value that is the result of a
    * namespace lookup based on an examination of the namespace declarations in
    * scope. It is merely the namespace URI given at creation time. The
    * Namespaces on an attribute does not inherit its namespace from the element
    * it is attached to. If an attribute is not explicitly given a namespace, it
    * simply has no namespace.
    * 
    * @return The namspace URI or null if unspecified.
    */
   public String getNamespaceURI()
   {
      return this.baseNode.getNamespaceURI();
   }

   /**
    * Get the namespace bindings.
    * 
    * @return The namespace bindings.
    */
   public Namespace getNamespaceBindings()
   {
      if (this.baseNode instanceof DrbAbstractNode)
      {
         return ((DrbAbstractNode) this.baseNode).getNamespaceBindings();
      }
      else
      {
         return null;
      }
   }

   /**
    * The value type of the node. The value type is determined from the value
    * previously assigned to the node. If no speficic value has been previsouly
    * set, fr.gael.drb.value.Value.NULL_ID type is returned.
    * 
    * @return NULL_ID if the node does not provide value or any other valid type
    *         identifier otherwise.
    */
   public int getValueType()
   {
      try
      {
         return this.baseNode.getValueType();
      }
      catch (final Throwable e)
      {
         logger.debug("DrbNodeSpi.getValueType(): " + e);
         return -1;
      }
   }

   /**
    * The value of the node. The value is the one previously set.
    * 
    * @return A reference to the value of the node or null if no value has
    *         already been set.
    */
   public Value getValue()
   {
      return this.baseNode.getValue();
   }

   /**
    * Returns an attribute matching a specific name.
    * 
    * @param name The name to match.
    * @return A reference to the attribute or null is not found.
    */
   public DrbAttribute getAttribute(final String name)
   {
      final DrbAttribute attr = this.baseNode.getAttribute(name);
      if (attr == null)
      {
         return null;
      }
      else
      {
         return new DrbAttributeSpi(attr, this);
      }
   }

   /**
    * The attributes of the nodes. This operation returns a list of attribute
    * previously set (if any).
    * 
    * @return The list attributes of the current node or null if none.
    */
   public DrbAttributeList getAttributes()
   {
      final DrbAttributeList attributes = this.baseNode.getAttributes();
      if ((attributes == null) || (attributes.getLength() == 0))
      {
         return null;
      }
      final DrbDefaultAttributeList list = new DrbDefaultAttributeList();
      /**
       * Initialize the output attribute list.
       */
      for (int i = 0; i < attributes.getLength(); i++)
      {
         final DrbAttribute attrib = attributes.item(i);
         if (attrib != null)
         {
            list.add(new DrbAttributeSpi(attrib, this));
         }
      }
      return list;
   }

   /**
    * The parent of this node. Returns a reference to the parent node of the
    * current node according to the current implementation. Most of the nodes
    * have a parent except root nodes or if they have just been removed, etc. If
    * the node has no parent the operation returns null.
    * 
    * @return The parent of this node or null.
    */
   public DrbNode getParent()
   {
      final DrbNode parent_node = this.baseNode.getParent();
      if (parent_node != null)
         return new DrbNodeSpi(parent_node);
      else
         return null;
   } // End getParent()

   /**
    * Checks if any child exists. Returns whether the current node has at least
    * a child.
    * 
    * @return true if this node has any children, false otherwise.
    */
   public final boolean hasChild()
   {
      final DrbNode impl = getDelegateNode();
      try
      {
         return impl.hasChild();
      }
      catch (UnsupportedOperationException e)
      {
         logger.debug(
            "hasChild not supported by the sub-implementation.", e);
         return false;
      }
   } // End hasChild()

   /**
    * Returns an occurrence of child matching a specific name. The occurrence
    * number starts from 1.
    * 
    * @param name The name to match.
    * @param occurence The occurrence number of the desired child.
    * @return A reference to the child or null is not found.
    */
   public DrbNode getNamedChild(final String name, final int occurence)
   {
      // Checks parameters.
      if ((name == null) || (occurence <= 0))
      {
         logger.error("DrbNodeSpi.getNamedChild(): Invalid parameters.");
         return null;
      }

      // Output child declaration
      DrbNode output_child = null;
      DrbNode impl = getDelegateNode();
      output_child = impl.getNamedChild(name, occurence);

      // Returns enveloped child
      if (output_child!=null)
         return new DrbNodeSpi(output_child);
      return null;
   }

   /**
    * Reference to the first child of the current node (directory). If the
    * current node has no child a null reference is returned.
    * 
    * @return A reference to the first child or null if no such node.
    */
   public final DrbNode getFirstChild()
   {
      DrbNode output_child = null;
      
      DrbNode impl = getDelegateNode();
      // Retrieve first child from sub-implementation delegation.
      output_child = impl.getFirstChild();
      
      // Returns enveloped child
      if (output_child!=null)
         return new DrbNodeSpi(output_child);
      return null;
   } // End getFirstChild()

   /**
    * Reference to the last child of the current node (directory). If the
    * current node has no child a null reference if returned.
    * 
    * @return A reference to the last child or null if no such node.
    */
   public final DrbNode getLastChild()
   {
      DrbNode output_child = null;
      
      DrbNode impl = getDelegateNode();
      output_child = impl.getLastChild();

      // Returns enveloped child
      if (output_child!=null)
         return new DrbNodeSpi(output_child);
      return null;
   }

   /**
    * Reference to a specific child of the current node (directory). The child
    * is identified by its position (i.e. index or sequence number) in the
    * children list of this node.
    * 
    * @param index The position of the node to retrieve starting from 0 and not
    *           greater or equal to the number of children.
    * @return A reference to specified child or null if no such node.
    */
   public final DrbNode getChildAt(final int index)
   {
      DrbNode output_child = null;

      // Retrieve child at index from sub-implementation delegation.
      try
      {
         output_child = getDelegateNode ().getChildAt(index);
      }
      catch (Exception e)
      {
         logger.error("No child at index #" + index + "("+ e.getMessage() + ")");
         return null;
      }

      // Returns enveloped child
      if (output_child!=null)
         return new DrbNodeSpi(output_child);
      return null;
   } // End getChildAt(int)

   /**
    * The list of children of the current node. Returns a list of references to
    * the children of the current node. The current node may have no child and
    * the operation returns therefore a null reference.
    * 
    * @return The list of children if any null otherwise.
    */
   public DrbNodeList getChildren()
   {
      DrbNodeList children = getDelegateNode().getChildren();
      if (children==null) return null;

      DrbDefaultNodeList list = new DrbDefaultNodeList();
      for (int inode = 0; inode < children.getLength(); inode++)
      {
         final DrbNodeSpi child=new DrbNodeSpi(children.item(inode));
         list.add(child);
      }
      return list;
   }

   /**
    * The content of the current node. Returns a sequence of nodes and atomic
    * values.
    * 
    * TODO: Fred: TBC the use of this method
    * 
    * @return The content of this node.
    */
   public DrbSequence getContent()
   {
      /**
       * Prepare the content sequence.
       */
      DrbSequence content = new DrbDefaultSequence();
      /**
       * Implementation not present: use base node if possible.
       */
      if (getSubImpl() == null)
      {
         if (this.baseNode instanceof DrbAbstractNode)
         {
            content = ((DrbAbstractNode) this.baseNode).getContent();
         }
         else
         {
            content = this.baseNode.getChildren();
         }
      }
      else
      {
         /**
          * Initialize the output node list. The nodes are created benefiting from
          * the children list as parent children list of the created nodes.
          */
         for (int inode = 0; inode < content.getLength(); inode++)
         {
            final DrbItem item = getSubImpl();
            if (item.getItemType() == DrbItem.NODE_ITEM)
            {
               final DrbNodeSpi child = new DrbNodeSpi((DrbNode) item);
               child.parent = this;
               content.addItem(inode, child);
            }
            else
            {
               content.addItem(inode, item);
            }
         }
      }
      return content;
   }

   /**
    * Number of files or directory hold by the current node (directory). Returns
    * the number of children belonging to the current node.
    * 
    * @return The number of children of the current node (directory).
    */
   public final int getChildrenCount()
   {
      // Retrieve child at index from sub-implementation delegation.
      return getDelegateNode().getChildrenCount();
   }

   /**
    * Previous sibling of the current file or directory. The sibling is
    * retrieved from the parent children list. The previous sibling may not
    * exist if the current node is the root or if it is the first file or
    * directory.
    * 
    * @return A reference to the previous sibling or null if no such node.
    */
   public final DrbNode getPreviousSibling()
   {
      final DrbNode sibling = this.baseNode.getPreviousSibling();

      if (sibling != null)
      {
         return new DrbNodeSpi(sibling, this.parent);
      }
      else
      {
         return null;
      }
   } // End getPreviousSibling

   /**
    * Next sibling of the current file or directory. The sibling is retrieved
    * from the parent children list. The next sibling may not exist if the
    * current node is the root or if it is the last file or directory.
    * 
    * @return A reference to the next sibling or null if no such node.
    */
   public final DrbNode getNextSibling()
   {
      final DrbNode sibling = this.baseNode.getNextSibling();

      if (sibling != null)
      {
         return new DrbNodeSpi(sibling, this.parent);
      }
      else
      {
         return null;
      }
   }

   // -------------------------------------------------------------------------
   // Mutable methods
   // -------------------------------------------------------------------------
   /**
    * Changes the name of the node. The passed name may be an empty string but
    * never a null reference. The change is persistent such as further instance
    * of a same node (even in different sessions) will have this new name. If
    * the implementation does not support the rename operation it is supposed to
    * throw a UnsupportedOperationException.
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current standing also as the source of the event. The called
    * operation is the nodesChanged() of the listeners.
    * </p>
    * 
    * @param name Reference to the new name.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested rename for any
    *            reason (e.g. specific case or general inability).
    * @throws NullPointerException This exception is raised when the passed name
    *            is a null reference. This exception may be overridden by an
    *            UnsupportedOperationException.
    */
   public void rename(final String name) throws NullPointerException,
      UnsupportedOperationException
   {
      this.baseNode.rename(name);
      // subImplChildren = null;
      // TODO: shall return the new instance of node (if any) and throw an event
   }

   /**
    * Changes the value of the node. This operation sets a new value of the
    * current node.The value type of the node shall be compatible with the node
    * implementation. If the type does not match exactly it is casted to a
    * compatible one based on the the fr.gael.drb.value capabilities. A
    * reference to the effectivelly assigned value is returned by the operation
    * so it is possible to check if a cast has been performed and therefore
    * assess the accuracy of the assignement. If the cast is not possible the
    * operation raises an UnsupportedOperationException. If the assignment is
    * possible and the node implementation has a physical representation the
    * value is updated in the physical source in order to persist among
    * sessions. It therefore possible that this operation consumses an variable
    * time.
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept value changes. For instance it may not be possible to change the
    * value of a file directory that has no immediate signification.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node changed event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node. The called operation is
    * the nodesChanged() of the listeners.
    * </p>
    * 
    * @param value The new value of the node. This value shall not be null.
    * @return The effectivelly assigned value. The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested assignment for
    *            any reason.
    */
   public Value setValue(final Value value) throws NullPointerException,
      ClassCastException, UnsupportedOperationException
   {
      return this.baseNode.setValue(value);
   }

   /**
    * Set the attribute list of a node. If some attributes are already attached
    * to the current node they are first removed and then replaced by the new
    * ones. However the operation checks the compatibility of the passed
    * attribute according to the current implementation. The operation does
    * nothing if the compatibility check fails.
    * <p>
    * <b>Warning:</b> The input attributes may be duplicated or re-instanciated
    * according to the targetted implementation. References to the effectively
    * inserted attributes can be reteived from the getAttributes() operation of
    * the DrbNode. It is highly recommended to discard the references to the
    * input attribuets if not mandatory.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept attribute changes. For instance it may not be possible to change
    * the size attribute of a file through this operation with would meant a
    * effective file resize that is not really relevant without additional data.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node. The called operation is
    * the nodesChanged() of the listeners.
    * </p>
    * 
    * @param attributes A reference to the new attribute list.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the attribute list is null. This exception may be
    *            overriden by an UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested attribute changes
    *            for any reason.
    */
   public void setAttributes(final DrbAttributeList attributes)
      throws NullPointerException, UnsupportedOperationException
   {
      this.baseNode.setAttributes(attributes);
   }

   /**
    * Sets a namespace resource identifier. The new namespace identifier shall
    * not be null.
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept namespace changes. For instance it may not be possible to change
    * the namespace of a file that is basically fixed.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node.The called operation is the
    * nodesChanged() of the listeners.
    * </p>
    * 
    * @param namespace_uri A reference to the new namespace identifier.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the new namespace identifier is null.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested namespace change
    *            for any reason (e.g. by definition or in the specific case).
    */
   public void setNamespaceURI(final String namespace_uri)
      throws NullPointerException, UnsupportedOperationException
   {
      this.baseNode.setNamespaceURI(namespace_uri);
   }

   /**
    * Inserts a child at a given position. The passed node is inserted in the
    * list of children at the given position The position is the expected index
    * of the node after insertion. All the previous children from the aimed
    * position to the end of the list are shift to the end of the new children
    * list (i.e. their indices are shifted up of 1). If the given index is out
    * of the children bounds and therefore less than zero and greater or equal
    * to the current number of children,the operation raises an exception. An
    * index equal to the current number of children is allowed and the operation
    * is therefore equivalent to appendChild().
    * <p>
    * If the node has been inserted within the children list, the next sibling
    * indicies are increased of one. In addition the assiociations between the
    * inserted node and it previous and next siblings are updated (if any).
    * </p>
    * <p>
    * <b>Warning:</b> The inserted node may be duplicated or re-instanciated
    * according to the targetted implementation. A reference to the effectively
    * inserted node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned node.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to insert a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Case of unordered or specifically ordered implementations:</b> If the
    * implementation does not support ordered children or has specific ordering
    * rules, the node is inserted without taking into account the requested
    * index passed in parameter. For instance it may not be possible to impose
    * the file order in a directory: it generally depends on the lexicographical
    * order of the node names or their creation date.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the inserted node and the source is the current node. The called
    * operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param node A reference to the node to be inserted.
    * @param index The expected index of the node after the insertion.
    * @return A reference to the effectively inserted node. This reference may
    *         differ from the input one.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference. This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or if it is greater or equal to the
    *            number of children in the number of children prior the call.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested insertion for any
    *            reason(e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbNode insertChild(final DrbNode node, final int index)
      throws NullPointerException, UnsupportedOperationException,
      IndexOutOfBoundsException
   {
      if (this.getSubImpl() != null)
      {
         throw new UnsupportedOperationException(
            "DrbNodeSpi.insertChild(): This operation is not allowed "
                  + "for sub-implementation.");
      }

      final DrbNode inserted_node = this.baseNode.insertChild(node, index);

      if (inserted_node != null)
      {
         return new DrbNodeSpi(inserted_node);
      }
      else
      {
         return null;
      }
   } // insertChild

   /**
    * Appends a child at the end of the children list. The passed node is
    * inserted in the list of children at the end of the current list.
    * <p>
    * <b>Warning:</b> The appended node may be duplicated or re-instanciated
    * according to the targeted implementation. A reference to the effectively
    * appended node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned node.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to append a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Case of unordered or specifically ordered implementations:</b> If the
    * implementation does not support ordered children or has specific ordering
    * rules, the node may not be appended but only inserted according to these
    * rules. For instance it may not be possible to impose the file order in a
    * directory:it generally depends on the lexicographical order of the node
    * names or their creation date.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the appended node and the source is the current node. The called
    * operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param node A reference to the node to be appended.
    * @return A reference to the effectivelly appended node. This reference may
    *         differ from the input one.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference.This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested append for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbNode appendChild(final DrbNode node) throws NullPointerException,
      UnsupportedOperationException
   {
      final DrbFactoryImpl sub_impl_factory = this.getSubImplFactory();
      if (sub_impl_factory != null)
      {
         if (!(sub_impl_factory instanceof DrbUpdateImpl))
         {
            throw new UnsupportedOperationException(
               "DrbNodeSpi.appendChild(): This operation is not allowed "
                     + "for sub-implementation without updating ability.");
         }
         final DrbUpdateImpl sub_impl_update = (DrbUpdateImpl) sub_impl_factory;
         sub_impl_update.put(node, this.baseNode);
      }

      final DrbNode appended_node = this.baseNode.appendChild(node);

      if (appended_node != null)
      {
         return new DrbNodeSpi(appended_node);
      }
      else
      {
         return null;
      }
   } // appendChild

   /**
    * Replaces a child of the current node. This operation replaces a child in
    * the current children list by a new one The operation aborts when the index
    * is out of bound (index < 0 || index > size). In case of error, the
    * implementation has to restore the initial situation. It is therefore
    * recommended for any implementation to check the consistency prior to
    * perform the replacement.
    * <p>
    * <b>Warning:</b> The replacing node may be duplicated or re-instanciated
    * according to the targetted implementation.A reference to the effectively
    * replacing node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned one.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to insert a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the new node and the source is the current node.The called operation is
    * the structureChanged() of the listeners.
    * </p>
    * 
    * @param index Index of the node to be replaced. This index starts at 0 and
    *           shall be less than the number of children.
    * @param new_node A reference to the node that replaces the old one.
    * @return A reference to the effectivelly replacing node.This reference may
    *         differ from the new_node parameter.
    * @throws NullPointerException This exception is raised when the reference
    *            to the new node is null. This exception may be overriden by a
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested replace for any
    *            reason. In addition if the old_node is not retreived in the
    *            current children list, this exception is also raised.
    */
   public DrbNode replaceChild(final int index, final DrbNode new_node)
      throws NullPointerException, IndexOutOfBoundsException,
      UnsupportedOperationException
   {
      if (this.getSubImpl() != null)
      {
         throw new UnsupportedOperationException(
            "DrbNodeSpi.replaceChild(): This operation is not allowed "
                  + "for sub-implementation.");
      }

      final DrbNode replaced_node = this.baseNode.replaceChild(index, new_node);

      if (replaced_node != null)
      {
         return new DrbNodeSpi(replaced_node);
      }
      else
      {
         return null;
      }
   }

   /**
    * Removes an existing child. The child at the given index is removed from
    * the children list of the current node. The child is not modified by this
    * operation. At the child point of view it keeps the same parent or any
    * common association depending on the implementation. However at the parent
    * (i.e. the current node) point of view the removed node is completely
    * dismissed and will never be re-instaciated from constructor operations
    * (e.g. getFirstChild(), etc. ). The index of the child to be removed has to
    * correspond to an existing children index. If the index is less than zero
    * or greater or equal to the current number of children, an exception is
    * thrown.
    * <p>
    * This operation takes into account the removal by updating the sibling
    * associations of the children nodes prior and next to the removed one. The
    * indicies of the nodes next to the removed one are decresed of one. Their
    * parents as well as their contents are left unchanged.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the removed node and the source is the current node.The called
    * operation is the nodesRemoved() of the listeners.
    * </p>
    * 
    * @param index Index of the child to be removed.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested removal for any
    *            reason.
    */
   public void removeChild(final int index) throws IndexOutOfBoundsException,
      UnsupportedOperationException
   {
      if (this.getSubImpl() != null)
      {
         throw new UnsupportedOperationException(
            "DrbNodeSpi.removeChild(): This operation is not allowed "
                  + "for sub-implementation.");
      }
      this.baseNode.removeChild(index);
   }

   /**
    * Tests if a specific interface can be provided. This operations tests with
    * a minimum of time and memory consumption if the current implementation can
    * provide a specific interface. It important to consider that hasImpl()
    * provides information about the ability to provide such interface in
    * general cases but not focused on the current instance. It may therefore be
    * impossible to get a specific implementation from a node whereas hasImpl()
    * operation returns true.
    * 
    * @param api The class type to test.
    * @return true if an implementation of the interface can be provided and
    *         false otherwise.
    */
   @SuppressWarnings ("rawtypes")
   public boolean hasImpl(final Class api)
   {
      if ((this.baseNode != null) && (this.baseNode instanceof DrbNodeImpl))
      {
         return ((DrbNodeImpl) this.baseNode).hasImpl(api);
      }
      else
      {
         return super.hasImpl(api);
      }
   }

   /**
    * Returns a specific implementation. This operation returns a reference to
    * an object implementing a specific interface. This mean is useful to
    * benefit by a specific and direct API instead of using the DrbNode
    * interface. The provided object shall represent the current node such as it
    * is possible after a call to this operation, to dismiss the reference to
    * the node. For instance, a file is usually wrapped as a drb.imple.file.File
    * class and thanks to this operation can be seen as a InputStream anabling
    * direct access to the handled file.
    * 
    * @param api The interface (or class) to be provided.
    * @return A reference to the object implementing the interface or a null
    *         reference otherwise.
    */
   @SuppressWarnings ({ "rawtypes"})
   public Object getImpl(final Class api)
   {
      if ((this.baseNode != null) && (this.baseNode instanceof DrbNodeImpl))
      {
         return ((DrbNodeImpl) this.baseNode).getImpl(api);
      }
      else
      {
         return super.getImpl(api);
      }
   }

   /**
    * Drb 2.5.0 updated DrbNodeSpi to wrap only base node sub-implementations
    * instead of its base node sub-implementation children.
    * This implies each implementation must manage base node as the root node
    * of the given input, not as the children of the given input...
    * This facility method helps to manage the transition for all the existing
    * implementations. New implementations must return the expected wrapped 
    * node.
    * @param impl_node the newest implemented first child node.
    * @param base_node the wrapped node. Can be null if unknown.
    * @return
    */
   public static DrbNode getDrb250FileNodeFromImplNode (final DrbNode impl_node, 
      final DrbNode base_node)
   {
      DrbDefaultMutableNode node = null;
      if (base_node!=null)
      {
         node = new DrbDefaultMutableNode(base_node.getName(), 
            base_node.getParent(), base_node.getIndex(), 
            base_node.getPreviousSibling(), base_node.getNextSibling()) 
         {
            @Override
            public void close(boolean deep)
            {
               super.close(deep);
               if (impl_node instanceof DrbNodeImpl)
                  ((DrbNodeImpl)impl_node).close(deep);
            }
            
            @Override
            public Value setValue(Value value)
            {
               return impl_node.setValue(value);
            }
            
            @Override
            public Value getValue()
            {
               return impl_node.getValue();
            }

         };
      }
      else
      {
         node = new DrbDefaultMutableNode("SpiWrappedFile") 
         {
            @Override
            public void close(boolean deep)
            {
               super.close(deep);
               if (impl_node instanceof DrbNodeImpl)
                  ((DrbNodeImpl)impl_node).close(deep);
            }
            
            @Override
            public Value setValue(Value value)
            {
               return impl_node.setValue(value);
            }
            
            @Override
            public Value getValue()
            {
               return impl_node.getValue();
            }
         };
      }

      DrbDefaultNodeList list = new DrbDefaultNodeList();
      list.add (impl_node);
      node.setChildren(list);
      return node;
   }
   
   public DrbNode getBaseNode() {
      return baseNode;
   }
} // DrbNodeSpi
