/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * The FloatArray class is a generic wrapper for float array values.
 */
public class FloatArray extends AbstractNumericArray implements ValueFormat
{
   // =========================================================================
   // Attributes part.
   // =========================================================================
   /**
    * The FloatArray priority.
    */
   final static int PRIORITY = 5;

   /**
    * the flaot array value
    */
   private float[] value;

   // =======================================================================
   // Methods part.
   // =======================================================================
   /**
    * Constructs a FloatArray initialized to the specified float[] value.
    * 
    * @param v the value of the FloatArray.
    */
   public FloatArray(final float[] v)
   {
      this.value = new float[v.length];
      System.arraycopy(v, 0, this.value, 0, v.length);
   }

   /**
    * Constructs an FloatArray object with the specified length.
    * 
    * @param size the length of the FloatArray.
    */
   public FloatArray(final int size)
   {
      this.value = new float[size];
   }

   /**
    * Returns the underlying object for optimization.    
    * @return a backing array.
    */
   public final float[] getData()
   {
      return this.value;
   }

   // --------------------------------------------------------------------------
   // ValueFormat interface implementation
   // --------------------------------------------------------------------------
   // see interface ValueFormat for more information.

   /**
    * Return a string containing the value with a fixed format.
    * 
    * @param length The expected length of the output string
    * @return The formatted string.
    */
   public java.lang.String getFormattedString(final int length)
   {
      java.lang.String str = "";
      for (int i = 0; i < this.length(); i++)
      {
         str = str + Float.getFormattedString(4, this.value[i]);
      }
      return str;
   }

   /**
    * Return a byte buffer containing the value in a fixed format.
    * 
    * @return The formatted buffer.
    */
   public final byte[] getFormattedBuffer()
   {
      final byte[] buffer = new byte[4 * this.length()];
      for (int i = 0; i < this.length(); i++)
      {
         final int int_value = java.lang.Float.floatToRawIntBits(this.value[i]);
         buffer[4 * i + 0] = (byte) (int_value >>> 24);
         buffer[4 * i + 1] = (byte) (int_value >>> 16);
         buffer[4 * i + 2] = (byte) (int_value >>> 8);
         buffer[4 * i + 3] = (byte) (int_value);
      }
      return buffer;
   }

   // -------------------------------------------------------------------------
   // Value interface implementation
   // -------------------------------------------------------------------------
   /**
    * The type identifier of this FloatArray value.
    * 
    * @return an identifier of the array type, namely ARRAY_ID
    */
   public final int getType()
   {
      return Value.ARRAY_ID;
   }

   /**
    * Returns the FloatArray priority
    * 
    * @return the FloatArray priority
    */
   public final int getPriority()
   {
      return PRIORITY;
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself is returned. If the conversion is not allowed a
    * ClassCastException is thrown. The types supported are ARRAY_ID and
    * STRING_ID.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException is the convertion is impossible
    */
   public final Value convertTo(final int type) throws ClassCastException
   {
      if (type == ARRAY_ID)
      {
         return this;
      }

      if (type == STRING_ID)
      {
         return new String(this.toString());
      }

      throw new ClassCastException();
   }

   /**
    * Assign a new ValueArray to the current one.
    * 
    * @param v the new Value.
    * @throws ClassCastException if the given Value is not a ValueArray.
    */
   public final void assign(final Value v) throws ClassCastException
   {
      final NumericArray b = (NumericArray) v;
      this.value = new float[b.length()];
      for (int i = 0; i < this.length(); i++)
      {
         this.value[i] = b.floatValue(i);
      }
   }

   // ------------------------------------------------------------------------
   // ValueArray interface implementation
   // ------------------------------------------------------------------------
   // ValueArray convertToArray(int type)
   // {
   // throw new ClassCastException();
   // }

   /**
    * Returns the Array type of the current Value.
    * 
    * @return the Array type of the current Value.
    */
   public final int getArrayType()
   {
      return Value.FLOAT_ID;
   }

   /**
    * Returns the Value at the given index.
    * 
    * @param index the index to be queried
    * @return the Value at the given index.
    */
   public final Value getElement(final int index)
   {
      return new Float(this.value[index]);
   }

   /**
    * Assign a new Value at the given index.
    * 
    * @param index the index to be changed.
    * @param element the new Value.
    */
   public final void assign(final int index, Value element)
   {
      element = element.convertTo(Value.NUMERIC_ID);
      this.value[index] = ((Numeric) element).floatValue();
   }

   /**
    * Returns the current array length.
    * 
    * @return the current array length.
    */
   public final int length()
   {
      return this.value.length;
   }

   // -------------------------------------------------------------------------
   // NumericArray interface implementation
   // -------------------------------------------------------------------------

   /**
    * Returns the boolean (logic) Value at the given index.
    * 
    * @param index the index to be queried.
    * @return the Value at the given index.
    */
   public final boolean booleanValue(final int index)
   {
      return this.value[index] != 0;
   }

   /**
    * Returns the byte Value at the given index.
    * 
    * @param index the index to be queried.
    * @return the Value at the given index.
    */
   public final byte byteValue(final int index)
   {
      return (byte) (this.value[index]);
   }

   /**
    * Returns the int Value at the given index.
    * 
    * @param index the index to be queried.
    * @return the Value at the given index.
    */
   public final int intValue(final int index)
   {
      return (int) (this.value[index]);
   }

   /**
    * Returns the long Value at the given index.
    * 
    * @param index the index to be queried.
    * @return the Value at the given index.
    */
   public final long longValue(final int index)
   {
      return (long) (this.value[index]);
   }

   /**
    * Returns the short Value at the given index.
    * 
    * @param index the index to be queried.
    * @return the Value at the given index.
    */
   public final short shortValue(final int index)
   {
      return (short) (this.value[index]);
   }

   /**
    * Returns the float Value at the given index.
    * 
    * @param index the index to be queried.
    * @return the Value at the given index.
    */
   public final float floatValue(final int index)
   {
      return (this.value[index]);
   }

   /**
    * Returns the double Value at the given index.
    * 
    * @param index the index to be queried.
    * @return the Value at the given index.
    */
   public final double doubleValue(final int index)
   {
      return (this.value[index]);
   }

   /**
    * Assign a new float value to the current Value, at the given index
    * 
    * @param index the index where to set the new Value
    * @param value the new Value
    */
   public final void assign(final int index, final boolean value)
   {
      this.value[index] = (value ? 1 : 0);
   }

   /**
    * Assign a new byte value to the current Value, at the given index
    * 
    * @param index the index where to set the new Value
    * @param value the new Value
    */
   public final void assign(final int index, final byte value)
   {
      this.value[index] = value;
   }

   /**
    * Assign a new int value to the current Value, at the given index
    * 
    * @param index the index where to set the new Value
    * @param value the new Value
    */
   public final void assign(final int index, final int value)
   {
      this.value[index] = value;
   }

   /**
    * Assign a new short value to the current Value, at the given index
    * 
    * @param index the index where to set the new Value
    * @param value the new Value
    */
   public final void assign(final int index, final short value)
   {
      this.value[index] = value;
   }

   /**
    * Assign a new long value to the current Value, at the given index
    * 
    * @param index the index where to set the new Value
    * @param value the new Value
    */
   public final void assign(final int index, final long value)
   {
      this.value[index] = value;
   }

   /**
    * Assign a new float value to the current Value, at the given index
    * 
    * @param index the index where to set the new Value
    * @param value the new Value
    */
   public final void assign(final int index, final float value)
   {
      this.value[index] = value;
   }

   /**
    * Assign a new double value to the current Value, at the given index
    * 
    * @param index the index where to set the new Value
    * @param value the new Value
    */
   public final void assign(final int index, final double value)
   {
      this.value[index] = (float) value;
   }

   /**
    * Returns the String representation of the Value.
    * 
    * @return the String representation of the Value.
    */
   public java.lang.String toString()
   {
      final StringBuffer strbuf = new StringBuffer(this.value.length * 10);
      for (int i = 0; i < this.value.length; i++)
      {
         if (i != 0)
         {
            strbuf.append(" ");
         }
         strbuf.append(this.value[i]);
      }
      return strbuf.toString();
   }
}
