/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.spi;

import fr.gael.drb.DrbAbstractAttribute;
import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbNode;
import fr.gael.drb.value.Value;

/**
 * Servide Provider Interface. This interface allows to plug services on a
 * attribute.
 */
class DrbAttributeSpi extends DrbAbstractAttribute
{
   /**
    * The base attribute.
    */
   protected DrbAttribute baseAttribute;

   /**
    * The owner node.
    */
   protected DrbNode owner;

   /**
    * Builds a getInstance from a base attribute. TODO : this operation shall
    * raise an exception in case of null parameter.
    * 
    * @param base_owner The owner node or null.
    * @param base_attrib The attribute to be wrapped. This parameter shall never
    *           be null.
    */
   DrbAttributeSpi(final DrbAttribute base_attrib, final DrbNode base_owner)
   {
      this.baseAttribute = base_attrib;
      this.owner = base_owner;
   }

   /**
    * Name of the attribute. Returns the name of the attribute. This name does
    * not contain any prefix, path nor any other location or identification
    * part. This name clearly identfies the attibute in the set of attribute of
    * the same node. This name is unique is this set. The attribute name is
    * never an empty string and always exists.
    * 
    * @return The name of the attribute.
    */
   public String getName()
   {
      return this.baseAttribute.getName();
   }

   /**
    * Changes the name of the attribute.
    * 
    * @param name Reference to the new name.
    * @throws UnsupportedOperationException This exception always raised because
    *            the name property is not defined for values.
    * @throws NullPointerException This exception is overriden by an
    *            UnsupportedOperationException.
    */
   public void rename(final java.lang.String name) throws NullPointerException,
         UnsupportedOperationException
   {
      this.baseAttribute.rename(name);
   }

   /**
    * The node the owning the current attribute. Returns a reference to the node
    * to which belongs this attribute. Because the attribute may have just been
    * created it may have no owner. This operation is similar to a getParent().
    * 
    * @return The owner of the attribute.
    */
   public DrbNode getOwner()
   {
      if (this.owner == null)
      {
         return new DrbNodeSpi(this.baseAttribute.getOwner());
      }
      return this.owner;
   }

   /**
    * The value type of the attribute. All node have a value according to the
    * fr.gael.drb.value package. This operation returns the type identifier of
    * the content of the current attribute. The value of the attribute depends
    * on the implementation as well as on the attribute itself. This operation
    * never returns a fr.gael.drb.value.Value.NULL_ID identifier.
    * 
    * @return The type of the attribute.
    */
   public int getValueType()
   {
      return this.baseAttribute.getValueType();
   }

   /**
    * Get namespace URI. The namespace URI of this attribute, or null if it is
    * unspecified. This is not a computed value that is the result of a
    * namespace lookup based on an examination of the namespace declarations in
    * scope. It is merely the namespace URI given at creation time. The
    * Namespaces on an attribute does not inherit its namespace from the element
    * it is attached to. If an attribute is not explicitly given a namespace, it
    * simply has no namespace
    * 
    * @return The namspace URI or null if unspecified.
    */
   public String getNamespaceURI()
   {
      return this.baseAttribute.getNamespaceURI();
   }

   /**
    * Sets a namespace resource identifier.
    * 
    * @param namespace_uri A reference to the new namespace identifier.
    * @throws UnsupportedOperationException This exception always raised because
    *            the name property is not defined for values.
    * @throws NullPointerException This exception is overriden by an
    *            UnsupportedOperationException.
    */
   public void setNamespaceURI(final java.lang.String namespace_uri)
         throws NullPointerException, UnsupportedOperationException
   {
      this.baseAttribute.setNamespaceURI(namespace_uri);
   }

   /**
    * The value of the attribute. The value is expressed accoring to one of the
    * types supported by the fr.gael.drb.value package. Generally these types
    * correspond to primitive types (e.g. integer, floatting points, etc.) or
    * very low level types (e.g. string, date, etc.). On the contrary to DOM
    * implementation all the types are allowed even the arrays, date etc. Only
    * the Value.NULL_ID type is forbidden.
    * 
    * @return The value of the attribute.
    */
   public Value getValue()
   {
      return this.baseAttribute.getValue();
   }

   /**
    * The attribute was explicitly given a value. This operation returns true if
    * the attribute was explicitly given an value in the data source handled by
    * the current implementation (e.g. a node of an XML document). Otherwise the
    * value is inherited from a default value.
    * 
    * @return false is a defaulted value or true otherwise.
    */
   public boolean isSpecified()
   {
      return this.baseAttribute.isSpecified();
   }

   /**
    * Changes the value of the item. This operation sets a new value of the
    * current item.The value type of the item shall be compatible with the item
    * implementation. If the type does not match exactly it is casted to a
    * compatible one based on the the fr.gael.drb.value capabilities. A
    * reference to the effectivelly assigned value is returned by the operation
    * so it is possible to check if a cast has been performed and therefore
    * assess the accuracy of the assignement. If the cast is not possible the
    * operation raises an UnsupportedOperationException. If the assignment is
    * possible and the item implementation has a physical representation the
    * value is updated in the physical source in order to persist among
    * sessions. It therefore possible that this operation consumses an variable
    * time.
    * 
    * @param value The new value of the node. This value shall not be null.
    * @return The effectivelly assigned value. The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested assignment for
    *            any reason.
    */
   public Value setValue(final Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      return this.baseAttribute.setValue(value);
   }

   /**
    * Returns a description of the current attribute. The output format is : "@"
    * <name> "=" <value> .
    * 
    * @return the description of the attribute.
    */
   public String toString()
   {
      return "@" + this.getName() + "=" + this.getValue();
   }

}
