/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.value.Boolean;

/**
 * URL node implementation
 */
public class URLNode extends DrbNodeImpl
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(URLNode.class);

   /**
    * The URL
    */
   protected URL url;

   /**
    * The inputStream used to read ftp node
    */
   protected InputStream inputstream;

   /**
    * Creates a URLNode with an url
    * 
    * @param url the url
    */
   public URLNode(final URL url)
   {
      this.url = url;
   }

   /**
    * Check if this node may have multiple occurrence
    * 
    * @return true if the children may have a multiple occurrence and false
    *         otherwise.
    */
   public boolean allowsMultiOccurrence()
   {
      return false;
   } // allowsMultiOccurrence

   // ----------------------------------------------
   // Object class overload
   // ----------------------------------------------
   /**
    * Indicates whether this node is "equal to" to another node. See
    * Object.equals() for the general contract of this method.
    * 
    * @param obj another value.
    * @return true if this object is the same as the obj argument
    */
   public boolean equals(final Object obj)
   {
      // Check reference equality
      if (this == obj)
      {
         return true;
      }
      // Check node equality if possible
      if (obj instanceof URLNode)
      {
         final URLNode urlNode = (URLNode) obj;
         return this.url.equals(urlNode.url);
      }
      // Otherwise the object is different
      return false;
   } // equals

   /**
    * This methods returns the name of the URL node
    * 
    * @return String The name of the url
    */
   public String getName()
   {
      final String name = this.url.getPath();
      final String urlName = this.url.toString();

      if (name.equals(""))
      {
         return urlName;
      }

      if (name.equals("/"))
      {
         return urlName.substring(0, urlName.lastIndexOf("/"));
      }

      final String[] str = name.split("/");

      return str[str.length - 1];
   }

   /**
    * The list of child nodes. This method is not implemented at this level.
    * 
    * @return Always return null.
    */
   public DrbNodeList getChildren()
   {
      return null;
   }
   
   @Override
   public boolean hasChild()
   {
      return false;
   }
   
   @Override
   public int getChildrenCount()
   {
      return 0;
   }
   
   @Override
   public DrbNode getChildAt(int index)
   {
      return null;
   }

   /**
    * This method returns the parent node
    * 
    * @return DrbNode the parent node
    */
   public DrbNode getParent()
   {
      java.net.URI uri;

      try
      {
         String u = this.url.toString();
         String path = u;
         if (path.contains("?")) path=u.substring(0, u.indexOf("?"));
         
         uri = new URI (path);

         uri = path.endsWith("/") ?
            resolve(uri, "..") : resolve(uri, "");

         try
         {
            final String file = uri.toURL().getFile();
            if (file.equals("/"))
            {
               return null;
            }

            return this.createNode(uri.toURL());
         }
         catch (final MalformedURLException e1)
         {
            logger.warn("fr.gael.drb.impl.URLNode.getParent:  "
                  + e1.getMessage());
         }
      }
      catch (final URISyntaxException e)
      {
         logger.warn("fr.gael.drb.impl.URLNode.getParent:  "
               + e.getMessage());
      }
      return null;
   }
   
   public static URI resolve(URI base, String child)
            throws URISyntaxException
          {
            URI childUri = new URI(child);
            URI ruri = base.resolve(childUri);
            // if the child fragment is relative (which we'll assume is the case
            // if URI.resolve doesn't do anything useful with it) and the base
            // URI is pointing at something nested inside a jar, we seem to have
            // to this ourselves to make sure that the nested jar url gets
            // resolved correctly
            if (childUri.equals(ruri) && !childUri.isAbsolute() &&
             (base.getScheme().equals("jar") || base.getScheme().equals("zip"))) {
              String r = base.toString();
              int lastslash = r.lastIndexOf('/');
              r = r.substring(0,lastslash) + "/" + childUri;
              // Sun's implementation of URI doesn't support references to the
              // parent directory ("/..") in the part after "!/" so we have to
              // remove these ourselves
              int exclPointSlashIndex = r.lastIndexOf("!/");
              if (exclPointSlashIndex > 0)
              {
                int slashDotDotIndex = r.indexOf("/..", exclPointSlashIndex);
                while (slashDotDotIndex > 0)
                {
                  int prevSlashIndex = r.lastIndexOf("/", slashDotDotIndex - 1);
                  if (prevSlashIndex >= exclPointSlashIndex)
                  {
                    String temp = r.substring(slashDotDotIndex + 3);
                    r = r.substring(0, prevSlashIndex).concat(temp);
                  }
                  slashDotDotIndex = r.indexOf("/..", exclPointSlashIndex);
                }
              }
              return URI.create(r);
            }
            //fix up normalization bug
            if ("file".equals(ruri.getScheme()) && ! child.equals(ruri))
            {
              if (base.getPath().startsWith("//") && !ruri.getPath().startsWith("//"))
              {
                String path = "///".concat(ruri.getPath());
                try
                {
                  ruri = new URI("file", null, path, ruri.getQuery(), ruri.getFragment());
                }
                catch(URISyntaxException uris)
                {}
              }
            }
            return ruri;
          }

   /**
    * Returns the URL path
    * 
    * @return URL path
    */
   public String getPath()
   {
      return this.url.toString();
   }

   /**
    * Returns an occurence of the node matching the specified name.
    * 
    * @param name the name of the name
    * @param occurence the occurence number of the node
    * @return the child node having the specified name or null.
    */
   public DrbNode getNamedChild(final String name, final int occurence)
   {
      if (occurence != 1)
      {
         return null;
      }

      java.net.URI uri;

      try
      {
         uri = resolve(url.toURI(), name);
         uri = uri.normalize();

         try
         {
            return this.createNode(uri.toURL());
         }
         catch (final MalformedURLException e1)
         {
            logger.error("fr.gael.drb.impl." + "URLNode.getNamedChild:  "
                  + e1.getMessage());
         }
      }
      catch (final URISyntaxException e)
      {
         logger.error("fr.gael.drb.impl.URLNode.getNamedChild:  "
               + e.getMessage());
      }
      return null;
   }

   /**
    * This method create a url node with aa url
    * 
    * @param url the URL
    * @return URLNode The new node created
    */
   protected URLNode createNode(final URL url)
   {
      return new URLNode(url);
   }

   /**
    * Tests if a specific interface can be provided. This operations tests with
    * a minimum of time and memory consumption if the current implementation can
    * provide a specific interface. It important to consider that hasImpl()
    * provides information about the ability to provide such interface in
    * general cases but not focused on the current instance. It may therefore be
    * impossible to get a specific implementation from a node whereas hasImpl()
    * operation returns true.
    * 
    * @param api The class type to test.
    * @return true if an implementation of the interface can be provided and
    *         false otherwise.
    */
   @SuppressWarnings ({ "rawtypes", "unchecked"})
   public boolean hasImpl(final Class api)
   {
      if (api.isAssignableFrom(java.io.InputStream.class))
      {
         return true;
      }

      if (api.isAssignableFrom(java.io.OutputStream.class))
      {
         return true;
      }

      if (api == URL.class)
      {
         return true;
      }

      return super.hasImpl(api);
   }

   /**
    * Returns a specific implementation. This operation returns a reference to
    * an object implementing a specific interface. This mean is useful to
    * benefit by a specific and direct API instead of using the DrbNode
    * interface. The provided object shall represent the current node such as it
    * is possible after a call to this operation, to dismiss the reference to
    * the node. For instance, a file is usually wrapped as a drb.imple.file.File
    * class and thanks to this operation can be seen as a InputStream anabling
    * direct access to the handled file.
    * 
    * @param api The interface (or class) to be provided.
    * @return A reference to the object implementing the interface or a null
    *         reference otherwise.
    */
   @SuppressWarnings ({ "rawtypes", "unchecked"})
   public Object getImpl(final Class api)
   {

      if (api.isAssignableFrom(java.io.InputStream.class))
      {
         try
         {
            if (this.url != null)
            {
               // Connect to the URL in input mode
               final URLConnection urlConnect = this.url.openConnection();
               urlConnect.setDoInput(true);
               urlConnect.setUseCaches(false);
               final InputStream stream = urlConnect.getInputStream();
               // Read all the data in this InputStream
               /*
                * ByteArrayOutputStream byte_output = new
                * ByteArrayOutputStream(); byte[] buffer = new byte[1024]; int
                * len = 0; do { len = stream.read(buffer); if (len > 0)
                * byte_output.write(buffer, 0, len); } while(len > 0);
                * byte_output.flush(); //Create a new stream that support the
                * mark and reset methods stream = new
                * ByteArrayInputStream(byte_output.toByteArray());
                */
               return stream;
            }

         }
         catch (final Exception e)
         {
            return null;
         }
      }

      else if (api.isAssignableFrom(java.io.OutputStream.class))
      {
         try
         {
            final URLConnection urlConnect = this.url.openConnection();
            return urlConnect.getOutputStream();
         }
         catch (final Exception e)
         {
            return null;
         }
      }

      else if (api == URL.class)
      {
         if (this.url != null)
         {
            return this.url;
         }
      }

      return super.getImpl(api);
   }
   
   /**
    * Returns an attribute list including the only "directory" attribute always
    * set to "false".
    * 
    * @return the attribute list.
    */
   @Override
   public DrbAttributeList getAttributes()
   {
      DrbDefaultAttributeList attribute_list = new DrbDefaultAttributeList();

      attribute_list
            .add(new DrbDefaultAttribute("directory", new Boolean(false)));

      return attribute_list;
   }

} // URLNode
