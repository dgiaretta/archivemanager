/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.xml;

import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAbstractNode;
import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbFactory;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.value.Value;
import fr.gael.drb.xsd.Namespace;

/**
 * Writer of XML nodes. This writer save DrbNodes into an XML document.
 */
public class XmlWriter
{

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(XmlFactory.class);

   /**
    * Show all items.
    */
   public static final int SHOW_ALL = 0xffffff;

   /**
    * Show attribute items.
    */
   public static final int SHOW_ATTRIBUTE = 1;

   /**
    * Show comment items.
    */
   public static final int SHOW_COMMENT = 2;

   /**
    * Show PI items.
    */
   public static final int SHOW_PROCESSING_INSTRUCTION = 4;

   /**
    * Show NOTATION items.
    */
   public static final int SHOW_NOTATION = 8;

   /**
    * the output stream writer to be used for printing XML document.
    */
   private XmlStream stream;

   /**
    * The XML stream.
    */
   class XmlStream extends PrintWriter
   {
      /**
       * The encoding being used.
       */
      String encoding;

      /**
       * Create a new print stream.
       */
      XmlStream(final Writer out, final String encoding)
            throws java.io.UnsupportedEncodingException
      {
         super(new BufferedWriter(out, 64 * 1024), true);
         this.encoding = encoding;
      }

      /**
       * Create a new print stream.
       */
      XmlStream(final OutputStream out)
            throws java.io.UnsupportedEncodingException
      {
         this(out, "UTF-8");
      }

      /**
       * Create a new print stream.
       */
      XmlStream(final OutputStream out, final String charset_name)
            throws java.io.UnsupportedEncodingException
      {
         this(new OutputStreamWriter(out, charset_name), charset_name);
      }

      /**
       * Terminate the current line by writing the line separator string.
       */
      public void println()
      {
         this.write((int) '\n');
      }

      /**
       * Terminate the current line by writing the line separator string.
       */
      public void println(final String s)
      {
         this.print(s);
         this.write((int) '\n');
      }
   }

   /**
    * The dynamic context.
    */
   public static class Context implements Cloneable
   {
      /**
       * indentation.
       */
      private int indent = 0;

      /**
       * The filtering flags.
       */
      private int filter = SHOW_ALL;

      /**
       * Preserve space flag.
       */
      protected boolean preserveSpace = true;

      /**
       * Namespaces. This attribute gathers all (prefix, URI) pairs defining the
       * namespaces to be considered. At creation, the namespace is augmented
       * with the default namespaces defined by the XQuery specifications (c.f.
       * Environment constructor commentary.
       */
      private Namespace namespace = new Namespace();

      /**
       * Default element/type namespace. This is a namespace URI. It is used for
       * any unprefixed QName appearing in a position where an element or type
       * name is expected. At creation the default namespace is null.
       */
      private String defaultElementNamespaceURI = null;

      /**
       * Environment constructor. This operations initialises the environment
       * with default values.
       * <p>
       * The following default namespaces are inserted: <table>
       * <tr>
       * <td>xml</td>
       * <td>http://www.w3.org/XML/1998/namespace</td>
       * </tr>
       * <tr>
       * <td>xs</td>
       * <td>http://www.w3.org/2001/XMLSchema</td>
       * </tr>
       * <tr>
       * <td>xsi</td>
       * <td>http://www.w3.org/2001/XMLSchema-instance</td>
       * </tr>
       * </table>
       */
      public Context()
      {
         /**
          * Initialise namespace according to the XQuery specifications.
          */
         this.namespace.bind(XmlNode.XML_PREFIX, XmlNode.XML_NAMESPACE);
         this.namespace.bind(XmlNode.XMLNS_PREFIX, XmlNode.XMLNS_NAMESPACE);
         this.namespace.bind("xs", "http://www.w3.org/2001/XMLSchema");
         this.namespace
               .bind("xsi", "http://www.w3.org/2001/XMLSchema-instance");
      } // Context constructor

      /**
       * Environment constructor. This operations initialises the environment
       * with specified values.
       * 
       * @param namespace the namespace bindings.
       * @param default_namespace_uri the default namespace URI.
       */
      public Context(Namespace namespace, final String default_namespace_uri)
      {
         /**
          * Initialise namespace according to the XQuery specifications.
          */
         namespace = namespace.cloneNamespace();
         namespace.bind(XmlNode.XML_PREFIX, XmlNode.XML_NAMESPACE);
         namespace.bind(XmlNode.XMLNS_PREFIX, XmlNode.XMLNS_NAMESPACE);
         namespace.bind("xs", "http://www.w3.org/2001/XMLSchema");
         namespace.bind("xsi", "http://www.w3.org/2001/XMLSchema-instance");
         this.namespace = namespace;
         this.defaultElementNamespaceURI = default_namespace_uri;
      } // Context constructor

      /**
       * Clones the current class.
       * 
       * @return the cloned context.
       */
      public Context cloneContext()
      {
         try
         {
            final Context clone_context = (Context) super.clone();
            clone_context.setNamespace(this.namespace.cloneNamespace());
            return clone_context;
         }
         catch (final CloneNotSupportedException clone_exception)
         {
            logger.error("XmlWriter.Context.clone() : not supported.");
            return null;
         }
      }

      /**
       * Returns the indentation.
       * 
       * @return the indentation.
       */
      public final int getIndent()
      {
         return this.indent;
      }

      /**
       * Set the indent provided in parameter. Any previous indent will be
       * discarded.
       * 
       * @param indent the indent to be considered.
       */
      public final void setIndent(final int indent)
      {
         this.indent = indent;
      }

      /**
       * Change the preserve space flag.
       * 
       * @param preserve_space the preserve space flag
       */
      public final void setPreserveSpace(final boolean preserve_space)
      {
         this.preserveSpace = preserve_space;
      }

      /**
       * Returns the filtering flags.
       * 
       * @return the filtering flags.
       */
      public final int getFilter()
      {
         return this.filter;
      }

      /**
       * Set the filter provided in parameter. Any previous filter will be
       * discarded.
       * 
       * @param filter the filter to be considered.
       */
      public final void setFilter(final int filter)
      {
         this.filter = filter;
      }

      /**
       * Returns the namespace of the environment.
       * 
       * @return the namespace of the current environment.
       */
      public final Namespace getNamespace()
      {
         return this.namespace;
      }

      /**
       * Set the namespace provided in parameter. Any previous namespace will be
       * discarded.
       * 
       * @param namespace the namespace to be considered.
       */
      public final void setNamespace(Namespace namespace)
      {
         if (namespace == null)
         {
            namespace = new Namespace();
         }
         this.namespace = namespace;
      }

      /**
       * Returns the default namespace URI of elements and types.
       * 
       * @return the default namspace URI if exist or null otherwise.
       */
      public final String getDefaultElementNamespaceURI()
      {
         return this.defaultElementNamespaceURI;
      }

      /**
       * Set the default namespace URI for elements and types. Any previous
       * default namespace URI will be overriden.
       * 
       * @param namespace_uri the new default namespace URI to consider.
       */
      public final void setDefaultElementNamespaceURI(final String namespace_uri)
      {
         this.defaultElementNamespaceURI = namespace_uri;
      }
   }

   /**
    * Builds a XML Writer from an output stream.
    * 
    * @param file the output stream to be used for printing XML document
    */
   public XmlWriter(final OutputStream file)
   {
      try
      {
         this.stream = new XmlStream(file);
      }
      catch (final java.io.UnsupportedEncodingException e)
      {
         throw new UnsupportedOperationException(e.getMessage());
      }
   }

   /**
    * Builds a XML Writer from a writer.
    * 
    * @param file the writer to be used for printing XML document
    * @param encoding the encoding used by the writer.
    */
   public XmlWriter(final Writer file, final String encoding)
   {
      try
      {
         this.stream = new XmlStream(file, encoding);
      }
      catch (final java.io.UnsupportedEncodingException e)
      {
         throw new UnsupportedOperationException(e.getMessage());
      }
   }

   /**
    * Builds a XML Writer from an output node.
    * 
    * @param node the output node to be used for printing XML document
    */
   public XmlWriter(final DrbNode node)
   {
      /**
       * Checks the provided base node. The base node shall be a non null and
       * have an impl.
       */
      if ((node == null) || (!(node instanceof DrbNodeImpl)))
      {
         return;
      }

      final DrbNodeImpl baseImpl = (DrbNodeImpl) node;

      /**
       * Try to get OutputStream implementation from the provided node.
       */
      OutputStream file;

      file = (OutputStream) baseImpl.getImpl(OutputStream.class);
      if (file == null)
      {
         throw new NullPointerException(
               "Cannot retrieve an output stream for writing XML.");
      }

      try
      {
         this.stream = new XmlStream(file);
      }
      catch (final java.io.UnsupportedEncodingException e)
      {
         throw new UnsupportedOperationException(e.getMessage());
      }
   }

   /**
    * Writes the input tree nodes into a file.
    * 
    * @param node the input node to be printed.
    * @param file the output stream to be used for printing XML document
    */
   public static void writeXML(final DrbNode node, final OutputStream file)
   {
      new XmlWriter(file).save(node);
   }

   /**
    * Writes the input tree nodes into a file.
    * 
    * @param node the input node to be printed.
    * @param file the output stream to be used for printing XML document
    * @param context the writer context.
    * @param prolog true to print the prolog and false otherwise
    */
   public static void writeXML(final DrbNode node, final OutputStream file,
         final Context context, final boolean prolog)
   {
      new XmlWriter(file).save(node, context, prolog);
   }

   /**
    * Writes the input tree nodes into an output stream.
    * 
    * @param node the input node to be printed.
    */
   public void save(final DrbNode node)
   {
      /**
       * Prints the tree root node
       */
      this.save(node, new Context(), false);
   }

   /**
    * Writes the input tree nodes.
    * 
    * @param node the input node to be printed.
    * @param context the writer context.
    * @param prolog true to print the prolog and false otherwise
    */
   public void save(final DrbNode node, Context context, final boolean prolog)
   {
      /**
       * Prints the XML prolog.
       */
      if (prolog)
      {
         this.stream.println("<?xml version=\"1.0\" encoding=\""
               + this.stream.encoding + "\"?>");
         this.stream.println();
      }

      /**
       * Prints the tree root node
       */
      if (context == null)
      {
         context = new Context();
      }
      this.writeNode(node, context);
      this.stream.flush();
   }

   /**
    * Writes a node into an output file with the specified indent. depth.
    * Recursive calls.
    * 
    * @param node the input node to be printed.
    */
   private void writeNode(final DrbNode node, final Context context)
   {
      /**
       * Cheks parameters.
       */
      if ((node == null) || (context == null))
      {
         logger.error("XmlWriter.writeNode() : Invalid parameter.");
         return;
      }

      /**
       * Check namespace declarations.
       */
      final DrbAttributeList attributes = node.getAttributes();

      Namespace declared_namespace = null;
      final Namespace namespace = context.getNamespace();
      final int indent = context.getIndent();
      final int filter = context.getFilter();

      if (node instanceof DrbAbstractNode)
      {
         declared_namespace = ((DrbAbstractNode) node).getNamespaceBindings();
         namespace.addNamespaces(declared_namespace);
      }
      if (declared_namespace == null)
      {
         declared_namespace = new Namespace();
      }
      if (attributes != null)
      {
         for (int iattr = 0; iattr < attributes.getLength(); iattr++)
         {
            final String attr_name = attributes.item(iattr).getName();
            final String attr_uri = attributes.item(iattr).getNamespaceURI();
            final String attr_value =
               attributes.item(iattr).getValue().toString();
            if (XmlNode.XMLNS_NAMESPACE.equals(attr_uri))
            {
               namespace.bind(attr_name, attr_value);
               declared_namespace.unbind(attr_name);// WARNING
            }
         }
      }

      for (int i = 0; i < context.getIndent(); i++)
      {
         this.stream.print(" ");
      }

      this.stream.print("<");

      String node_fullname = node.getName();
      String node_uri = node.getNamespaceURI();
      String node_prefix = namespace.resolvePrefix(node_uri);
      if ("".equals(node_prefix))
      {
         node_prefix = null;
      }
      if ("".equals(node_uri))
      {
         node_uri = null;
      }
      if (node_prefix != null)
      {
         node_fullname = node_prefix + ":" + node_fullname;
      }
      if (node.getName() != null)
      {
         this.stream.print(node_fullname);
      }
      else
      {
         this.stream.print("unnamed");
      }

      if ((attributes != null) && ((filter & SHOW_ATTRIBUTE) != 0))
      {
         for (int iattr = 0; iattr < attributes.getLength(); iattr++)
         {
            final String attribute_name = attributes.item(iattr).getName();
            if ((attribute_name != null) && (!attribute_name.equals("xmlns")))
            {
               String attr_name = attributes.item(iattr).getName();
               final String attr_uri = attributes.item(iattr).getNamespaceURI();
               final String attr_prefix = namespace.resolvePrefix(attr_uri);
               final Value attr_value = attributes.item(iattr).getValue();
               String attr_string = "";
               if (attr_value != null)
               {
                  attr_string = XmlNode.toXML(attr_value.toString());
               }
               if (attr_prefix != null)
               {
                  attr_name = attr_prefix + ":" + attr_name;
               }
               this.stream.print(" " + attr_name + "=\"" + attr_string + "\"");
            }
         }
      }
      // Generate namespace prefixes
      boolean default_namespace_written = false;
      String default_namespace = context.getDefaultElementNamespaceURI();
      final String[] prefixes = declared_namespace.getDeclaredPrefixes();
      for (int i = 0; i < prefixes.length; i++)
      {
         final String attr_string = namespace.resolveNamespace(prefixes[i]);
         if ((attr_string == null) || prefixes[i].equals("")
               || prefixes[i].equals("xml") || prefixes[i].equals("xmlns"))
         {
            continue;
         }

         // Write namespace declaration
         this.stream.print(" " + "xmlns:" + prefixes[i] + "=\"" + attr_string
               + "\"");
      }

      // Write node namespace as default
      if ((node_prefix == null) && (node_uri != default_namespace))
      {
         if ((node_uri == null) || !node_uri.equals(default_namespace))
         {
            if (node_uri == null)
            {
               this.stream.print(" xmlns=\"\"");
            }
            else
            {
               this.stream.print(" xmlns=\"" + node_uri + "\"");
            }
            default_namespace_written = true;
            default_namespace = node_uri;
         }
      }

      // Write default namespace (if any).
      if (!default_namespace_written)
      {
         final String attr_string = declared_namespace.getDefaultNamespaceURI();
         if ((attr_string != null)
               && !attr_string.equals(context.getDefaultElementNamespaceURI()))
         {
            default_namespace_written = true;
            this.stream.print(" " + "xmlns" + "=\"" + attr_string + "\"");
            default_namespace = attr_string;
         }
      }

      DrbSequence content = null;
      if (node instanceof DrbAbstractNode)
      {
         content = ((DrbAbstractNode) node).getContent();
      }
      else
      {
         content = new DrbDefaultSequence(node.getChildren());
         final Value value = node.getValue();
         if (value != null)
         {
            content.addItem(content.getLength(), value);
         }
      }

      if ((content != null) && (content.getLength() > 0))
      {
         this.stream.print(">");
      }

      boolean single_line = false;
      if (content != null)
      {
         for (int ichild = 0; ichild < content.getLength(); ichild++)
         {
            final DrbItem item = content.getItem(ichild);
            if (item.getItemType() == DrbItem.NODE_ITEM)
            {
               final Context child_context = context.cloneContext();
               child_context.setIndent(indent + 3);
               child_context.setDefaultElementNamespaceURI(default_namespace);
               if (ichild == 0)
               {
                  this.stream.println("");
               }
               this.writeNode((DrbNode) item, child_context);
               this.stream.println("");
            }
            else if ((item.getItemType() == DrbItem.VALUE_ITEM)
                  || ("#cdata-section".equals(item.getName())))
            {
               final Value value = item.getValue();
               String value_string = (value == null) ? "" : value.toString();
               boolean use_cdata = "#cdata-section".equals(item.getName());

               if (use_cdata || (value_string.indexOf('<') >= 0)
                     || (value_string.indexOf('&') >= 0))
               {
                  value_string = "<![CDATA[" + value_string + "]]>";
                  use_cdata = true;
               }
               if (!use_cdata && !context.preserveSpace)
               {
                  value_string = value_string.trim();
               }
               if (!use_cdata && context.preserveSpace)
               {
                  value_string = value_string.replaceAll("\n", "&#10;");
               }

               if (!value_string.equals(""))
               {
                  if (((content.getLength() != 1) || (value_string
                        .indexOf('\n') >= 0)))
                  {
                     this.stream.println("");
                     String indent_string = "";
                     for (int i = 0; i < indent + 3; i++)
                     {
                        indent_string = indent_string + " ";
                     }
                     this.stream.print(indent_string);
                     if (!use_cdata)
                     {
                        value_string =
                           value_string.replaceAll("\n", "\n" + indent_string);
                     }
                  }
                  else
                  {
                     single_line = true;
                  }
                  this.stream.print(value_string);
                  if (!single_line)
                  {
                     this.stream.println("");
                  }
               }
            }
            else if ((item.getItemType() == XmlItem.COMMENT_ITEM)
                  && ((filter & SHOW_COMMENT) != 0))
            {
               this.stream.println("");
               for (int i = 0; i < indent + 3; i++)
               {
                  this.stream.print(" ");
               }
               final Value value = item.getValue();
               final String value_string =
                  (value == null) ? "" : value.toString();
               this.stream.println("<!--" + value_string + "-->");
            }
            else if ((item.getItemType() == XmlItem.PROCESSING_INSTRUCTION_ITEM)
                  && ((filter & SHOW_PROCESSING_INSTRUCTION) != 0))
            {
               this.stream.println("");
               for (int i = 0; i < indent + 3; i++)
               {
                  this.stream.print(" ");
               }
               final String pi_target = item.getName();
               final Value value = item.getValue();
               final String value_string =
                  (value == null) ? "" : value.toString();
               this.stream
                     .println("<?" + pi_target + " " + value_string + "?>");
            }
         }
      }

      if ((content != null) && (content.getLength() > 0))
      {
         if (!single_line)
         {
            for (int i = 0; i < indent; i++)
            {
               this.stream.print(" ");
            }
         }

         this.stream.print("</");

         if (node.getName() != null)
         {
            this.stream.print(node_fullname);
         }
         else
         {
            this.stream.print("unnamed");
         }

         this.stream.print(">");
      }
      else
      {
         this.stream.print("/>");
      }
   }

   /**
    * Dump the infoset structure of a node.
    */
   public static void dump(final DrbItem item, final OutputStream stream,
         final String indent)
   {
      final PrintWriter printer = new PrintWriter(stream, true);

      if (item instanceof DrbAbstractNode)
      {
         final DrbAbstractNode node = (DrbAbstractNode) item;
         printer.println(indent + "element=[");
         printer.println(indent + "  namespace name=[" + node.getNamespaceURI()
               + "]");
         printer.println(indent + "  local name=[" + node.getName() + "]");
         printer.println(indent + "  index=[" + node.getIndex() + "]");
         printer.println(indent + "  base URI=[" + node.getPath() + "]");

         printer.print(indent + "  attributes=[");
         final DrbSequence attribs = node.getAttributes();
         if (attribs != null)
         {
            if (attribs.getLength() > 0)
            {
               printer.println("");
               for (int i = 0; i < attribs.getLength(); i++)
               {
                  dump(attribs.getItem(i), stream, indent + "    ");
               }
               printer.println(indent + "  ");
            }
         }
         printer.println("]");

         printer.print(indent + "  namespace declaration=[");
         final Namespace namespace = node.getNamespaceBindings();
         if (namespace != null)
         {
            printer.print(namespace.getDefaultNamespaceURI());
            final String[] prefixes = namespace.getDeclaredPrefixes();
            for (int i = 0; i < prefixes.length; i++)
            {
               printer.print(" " + prefixes[i] + "=\""
                     + namespace.resolveNamespace(prefixes[i]) + "\"");
            }
         }
         printer.println("]");

         printer.print(indent + "  children=[");
         final DrbSequence content = node.getContent();
         if (content != null)
         {
            if (content.getLength() > 0)
            {
               printer.println("");
               for (int i = 0; i < content.getLength(); i++)
               {
                  dump(content.getItem(i), stream, indent + "    ");
               }
               printer.print(indent + "  ");
            }
         }
         printer.println("]");
         printer.println(indent + "]");
      }
      else if (item instanceof DrbAttribute)
      {
         final DrbAttribute attr = (DrbAttribute) item;
         printer.println(indent + "attribute=[");
         printer.println(indent + "  namespace name=[" + attr.getNamespaceURI()
               + "]");
         printer.println(indent + "  local name=[" + attr.getName() + "]");
         printer.println(indent + "  prefix=[]");

         printer.print(indent + "  normalized value=[");
         if (attr.getValue() != null)
         {
            printer.print(attr.getValue().toString());
         }
         printer.println("]");
         printer.println(indent + "  specified=[" + attr.isSpecified() + "]");
         printer.println(indent + "  attribute type=[CDATA]");
         printer.println(indent + "  references=[]");
         printer.println(indent + "]");
      }
      else if (item instanceof Value)
      {
         final Value value = (Value) item;
         printer.println(indent + "value=[");
         printer.println(indent + "  text=[" + value.toString() + "]");
         printer.print(indent + "  type=[");
         if (value.getType() != Value.ARRAY_ID)
         {
            printer.print(new fr.gael.drb.xsd.XsdAtomicType(value.getType())
                  .getName());
         }
         else
         {
            printer.print("array");
         }
         printer.println("]");
         printer.println(indent + "]");
      }
      printer.flush();
   }

   /**
    * Make this class runnable for testing.
    * 
    * @param args the arguments.
    */
   public static void main(final String[] args)
   {
      String xpath = ".";
      final XmlWriter writer = new XmlWriter(System.out);
      boolean prolog = false;
      boolean force_sax = false;
      boolean force_xml = false;
      boolean force_dump = false;
      int filter = SHOW_ALL;
      for (int i = 0; i < args.length; i++)
      {
         if (args[i].equals("--prolog"))
         {
            prolog = true;
         }
         else if (args[i].equals("--no-attribute"))
         {
            filter = filter ^ SHOW_ATTRIBUTE;
         }
         else if (args[i].equals("--no-comment"))
         {
            filter = filter ^ SHOW_COMMENT;
         }
         else if (args[i].equals("--xml"))
         {
            force_xml = true;
         }
         else if (args[i].equals("--sax"))
         {
            force_sax = true;
         }
         else if (args[i].equals("--dump"))
         {
            force_dump = true;
         }
         else if (!args[i].startsWith("--") && (args[i].length() > 0))
         {
            xpath = args[i];
         }
      }
      DrbNode input_node = DrbFactory.open(xpath);
      if (force_xml)
      {
         input_node = new XmlFactory().open(input_node);
      }
      if (force_sax)
      {
         input_node = new SaxDocument(input_node).getFirstChild();
      }

      if (force_dump)
      {
         XmlWriter.dump(input_node, System.out, "");
      }
      else
      {
         final Context context = new Context();
         context.setFilter(filter);
         writer.save(input_node, context, prolog);
      }
   } // main
}
