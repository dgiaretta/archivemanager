/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.value.Numeric;
import fr.gael.drb.value.Value;

/**
 * Declaration of an XML-Schema length Facet.
 */
public class XsdLengthFacet extends XsdFacet
{

   /**
    * length facet name.
    */
   final static String TAG = "length";

   /**
    * The length value.
    */
   private Numeric value;

   /**
    * Build a minLength facet.
    * 
    * @param value the value
    */
   XsdLengthFacet(final Value value)
   {
      this.value =
         (fr.gael.drb.value.Numeric) value.convertTo(Value.NUMERIC_ID);
   } // XsdLengthFacet

   /**
    * Identifier of this facet.
    * 
    * @return Identifier of this facet.
    */
   public final int getId()
   {
      return LENGTH_ID;
   } // getId

   /**
    * The length value
    * 
    * @return The length value
    */
   public final Value getValue()
   {
      return this.value;
   } // getValue

   /**
    * The name of this facet.
    * 
    * @return The name of this facet.
    */
   public final String getName()
   {
      return TAG;
   } // getName

   // --------------------------------------------------------
   // ValueValidator interface implementation
   // --------------------------------------------------------
   /**
    * Validates the present value.
    * 
    * @param v the value
    * @return true if this value satifies the type definition, else false
    */
   public boolean isValid(final Value v)
   {
      if (v == null)
      {
         return this.value.intValue() == 0;
      }
      else if (v.getType() == Value.ARRAY_ID)
      {
         return ((fr.gael.drb.value.ValueArray) v).length() == this.value
               .intValue();
      }
      else if (v.getType() == Value.STRING_ID)
      {
         return v.toString().length() == this.value.intValue();
      }
      return false;
   }

} // XsdLengthFacet class
