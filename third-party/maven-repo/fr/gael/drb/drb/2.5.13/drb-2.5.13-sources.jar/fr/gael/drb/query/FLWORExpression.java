/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.util.HashMap;
import java.util.Vector;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.value.Int;

/**
 * Wraps a FLOWR expression of XQuery language. XQuery provides a feature called
 * a FLWOR expression that supports iteration and binding of variables to
 * intermediate results. This kind of expression is often useful for computing
 * joins between two or more documents and for restructuring data. The name
 * FLWOR, pronounced "flower", is suggested by the keywords for, let, where,
 * order by, and return.
 */
class FLWORExpression extends AbstractExpression
{
   /**
    * Logger.
    */
   Logger logger = Logger.getLogger(FLWORExpression.class);

   /**
    * Collection of let bindings.
    */
   private HashMap<QName, DynamicVariable> letBindings =
      new HashMap<QName, DynamicVariable>();

   /**
    * Ordered keys of the let bindings.
    */
   private Vector<QName> letKeys = new Vector<QName>();

   /**
    * Collection of for clause bindings.
    */
   private HashMap<QName, DynamicVariable> forBindings =
      new HashMap<QName, DynamicVariable>();

   /**
    * Collection of for clause bindings.
    */
   private HashMap<QName, DefaultVariable> forPositionalVariable =
      new HashMap<QName, DefaultVariable>();

   /**
    * Ordered keys of the for bindings.
    */
   private Vector<QName> forKeys = new Vector<QName>();

   /**
    * The optional expression binding the "where" clause.
    */
   private Expression whereExpression = null;

   /**
    * The expression binding the "return" clause.
    */
   private Expression returnExpression = null;

   /**
    * Potentially nested expression. The current implementation supports only
    * one sequence of let bindings followed by one sequence of for clauses. The
    * subsequent let and for clauses are considered as a nested FLWOR
    * sub-expression. In case of nested expressions (i.e. non null attribute),
    * the where and return clauses are delegated to the lowest level.
    */
   private FLWORExpression nestedFLWORExpression = null;

   /**
    * Builds a FLWOR expression free of clause. The clauses and bindings are to
    * be added before any use of the class.
    * 
    * @param token the token related to the expression in the XQuery script.
    */
   FLWORExpression(final Token token)
   {
      /**
       * Call the default constructor of the super abstract class.
       */
      super("FLWOR", token);
   }

   /**
    * Adds a "for" clause binding.
    * 
    * @param variable the dynamic variable to bind.
    * @param positional_variable potentially request positional variable.
    */
   public void addForBinding(final DynamicVariable variable,
         final DefaultVariable positional_variable)
   {
      if (variable == null)
      {
         throw new NullPointerException(
               "Cannot assign null variable to \"for\" clause");
      }

      if (this.nestedFLWORExpression == null)
      {
         if (variable.getExpression().isUpdating())
         {
            throw new StaticException("XUST0001 - The for binding of a FLWOR "
                  + "expression must not contain an updating expression.", this
                  .getToken());
         }

         this.forBindings.put(variable.getQName(), variable);

         if (positional_variable != null)
         {
            this.forPositionalVariable.put(variable.getQName(),
                  positional_variable);
         }

         this.forKeys.add(variable.getQName());
      }
      else
      {
         this.nestedFLWORExpression
               .addForBinding(variable, positional_variable);
      }
   }

   /**
    * Adds a "let" clause binding.
    * 
    * @param variable the dynamic variable to bind. The reference shall not be
    *           null.
    */
   public void addLetBinding(final DynamicVariable variable)
   {
      /**
       * Check parameter.
       */
      if (variable == null)
      {
         throw new NullPointerException(
               "Cannot assign null variable to \"let\" clause");
      }

      if (variable.getExpression() == null)
      {
         throw new NullPointerException(
               "Cannot assign variable with null expression to \"let\" clause");
      }

      if (variable.getExpression().isUpdating())
      {
         throw new StaticException("XUST0001 - The let binding of a FLWOR "
               + "expression must not contain an updating expression.", this
               .getToken());
      }
      /**
       * Nest FLWOR sub-expression if necessary.
       */
      if ((this.nestedFLWORExpression == null) && (this.forBindings.size() > 0))
      {
         this.nestedFLWORExpression = new FLWORExpression(this.getToken());

         this.nestedFLWORExpression.setReturnExpression(this.returnExpression);
         this.returnExpression = null;

         this.nestedFLWORExpression.setWhereExpression(this.whereExpression);
         this.whereExpression = null;
      }

      /**
       * Bind variable.
       */
      if (this.nestedFLWORExpression == null)
      {
         this.letBindings.put(variable.getQName(), variable);
         this.letKeys.add(variable.getQName());
      }
      else
      {
         this.nestedFLWORExpression.addLetBinding(variable);
      }
   }

   /**
    * Set the return expression. Any previous declaration will be overridden.
    * 
    * @param return_expression the return expression of the FLWOR expression.
    */
   public void setReturnExpression(final Expression return_expression)
   {
      if (this.nestedFLWORExpression == null)
      {
         this.returnExpression = return_expression;
      }
      else
      {
         this.nestedFLWORExpression.setReturnExpression(return_expression);
      }
   }

   /**
    * Sets the where expression. Any previous declaration will be overridden.
    * 
    * @param where_expression the where expression of the FLWOR expression.
    */
   public void setWhereExpression(final Expression where_expression)
   {
      if (this.nestedFLWORExpression == null)
      {
         this.whereExpression = where_expression;
      }
      else
      {
         this.nestedFLWORExpression.setWhereExpression(where_expression);
      }
   }

   /**
    * Evaluates the FLWOR expression.
    * 
    * @param outer_context the dynamic context to be considered.
    * @return the output sequence of the FLWOR expression.
    */
   public DrbSequence evaluate(final DynamicContext outer_context)
   {
      /**
       * Creates the in-scope context to avoid alteration of the outer context.
       */
      final DynamicContext context = new DynamicContext(outer_context);

      /**
       * Evaluates the let items. The let items are evaluated with the inner
       * context that is augmented at each loop by the new bindings.
       */
      for (int ibind = 0; ibind < this.letKeys.size(); ibind++)
      {

         /**
          * Check and process, should the occasion arise, the cancellation
          * request.
          */
         if (this.isCancellationRequested() == true)
         {
            this.throwCancelException();
         }

         /**
          * Evaluates the current let clause expression.
          */
         final DynamicVariable variable =
            this.letBindings.get(this.letKeys.get(ibind));
         variable.initialize(context);

         /**
          * Augment the inner context with the new binding.
          */
         context.addInScopeVariable(variable);
      }

      /**
       * Evaluates the for items.
       */
      final Vector<DrbSequence> forSequenceList = new Vector<DrbSequence>();

      for (int ibind = 0; ibind < this.forKeys.size(); ibind++)
      {
         /**
          * Check and process, should the occasion arise, the cancellation
          * request.
          */
         if (this.isCancellationRequested() == true)
         {
            this.throwCancelException();
         }

         /**
          * Evaluate the current "for" clause expression.
          */
         final DynamicVariable variable =
            this.forBindings.get(this.forKeys.get(ibind));
         variable.initialize(context);

         final DrbSequence forSequence = variable.getValue();

         if (forSequence == null)
         {
            throw new DynamicException(this,
                  "Error while evaluating the \"for\" clause binding "
                        + variable);
         }

         /**
          * Detect empty sequence. If the current variable is bound to an empty
          * sequence, it is not necessary to continue the processing because no
          * tuple will result for the FLWOR expression.
          */
         if (forSequence.getLength() <= 0)
         {
            return new DrbDefaultSequence();
         }

         /**
          * Add the evaluated sequence in a common list that will form the tuple
          * of the "for" loop.
          */
         forSequenceList.add(forSequence);
      }

      /**
       * Prepare arrays of binding indices and sizes for increasing the
       * construction speed of the tuples. Warning : this implementation does
       * not perform a real cartesian product but considers the data sorted !
       */
      final int forSequenceSize = forSequenceList.size();

      final int[] indices = new int[forSequenceSize];
      final int[] lengths = new int[forSequenceSize];
      int context_size = 0;

      for (int index = 0; index < forSequenceSize; index++)
      {
         indices[index] = 0;
         lengths[index] = (forSequenceList.get(index)).getLength();

         if (lengths[index] != 0)
         {
            if (context_size == 0)
            {
               context_size = lengths[index];
            }
            else
            {
               context_size *= lengths[index];
            }
         }
      }

      /**
       * Prepare for looping.
       */
      DrbSequence output_sequence = null;
      context.focus.setContextSize(context_size);

      /**
       * Loop on for tuples.
       */
      for (int position = 0; position < context_size; position++)
      {

         /**
          * Set context position in the focus.
          */
         context.focus.setContextPosition(position + 1);

         /**
          * Check and process, should the occasion arise, the cancellation
          * request.
          */
         if (this.isCancellationRequested() == true)
         {
            this.throwCancelException();
         }

         /**
          * Compute the next tuple indices for each binding apart during the
          * first iteration.
          */
         if (position != 0)
         {
            int isequence;

            for (isequence = forSequenceSize - 1; isequence >= 0; isequence--)
            {
               indices[isequence] += 1;

               if (indices[isequence] >= lengths[isequence])
               {
                  indices[isequence] = 0;
               }
               else
               {
                  break;
               }
            }

            if ((isequence == 0) && (indices[0] == 0))
            {
               break;
            }
         }

         /**
          * Bound the "for" clause variable to their value of the current loop
          * and put/override them in the inner context.
          */
         for (int ibind = 0; ibind < this.forKeys.size(); ibind++)
         {
            final DrbSequence sequence = forSequenceList.get(ibind);

            final DynamicVariable variable =
               this.forBindings.get(this.forKeys.get(ibind));

            if (sequence.getLength() >= 1)
            {
               variable.setValue(sequence.getItem(indices[ibind]));
            }
            else
            {
               // TODO: Should the empty sequences bounded to the variables ?
               // See XQuery request (08/07/2004)
               variable.setValue(sequence);
            }

            context.addInScopeVariable(variable);

            final DefaultVariable positionalVariable =
               this.forPositionalVariable.get(this.forKeys.get(ibind));

            if (positionalVariable != null)
            {
               positionalVariable.setValue(new Int(indices[ibind] + 1));

               context.addInScopeVariable(positionalVariable);
            }
         }

         /**
          * Process the return clause.
          */
         final DrbSequence returnSequence = this.processReturnClause(context);

         /**
          * Check if something has been processed.
          */
         if (returnSequence == null)
         {
            continue;
         }

         /**
          * Concatenate the result in the output sequence. In the specific case
          * of first result, only set the resulting sequence as output sequence.
          * Else, if the resulting sequence is a not default sequence, transform
          * it to this type before inserting th new items.
          */
         if (output_sequence == null)
         {
            // output_sequence = returnSequence;
            output_sequence = new DrbDefaultSequence(returnSequence);
         }
         else
         {
            // TODO: Should be a natural feature of the default sequence.
            if (!(output_sequence instanceof DrbDefaultSequence))
            {
               output_sequence = new DrbDefaultSequence(output_sequence);
            }

            for (int item = 0; item < returnSequence.getLength(); item++)
            {
               ((DrbDefaultSequence) output_sequence).add(returnSequence
                     .getItem(item));
            }
         }
      }

      /**
       * Process "let" clause if no "for" binding was to be processed.
       */
      if ((this.letBindings.size() > 0) && (context_size <= 0))
      {
         output_sequence = this.processReturnClause(context);
      }

      /**
       * Return the evaluated sequence. If null, an empty sequence is returned.
       */
      if (output_sequence == null)
      {
         return new DrbDefaultSequence();
      }
      else
      {
         return output_sequence;
      }

   }

   /**
    * Evaluate the return expression. The return expression is evaluated only if
    * the where clause is true.
    * 
    * @param context the dynamic context to be considered.
    * @return the evaluated expression or null if the "where" clause is false.
    */
   private DrbSequence processReturnClause(final DynamicContext context)
   {
      DrbSequence returnSequence = null;

      if (this.nestedFLWORExpression == null)
      {
         /**
          * Filter tuples according to the where expression.
          */
         if (this.whereExpression != null)
         {
            /**
             * Evaluate the "where" clause with the current inner context.
             */
            final DrbSequence whereSequence =
               this.whereExpression.evaluate(context);

            /**
             * Check the evaluation result.
             */
            if (whereSequence == null)
            {
               throw new DynamicException(this,
                     "Error while evaluating the \"where\" clause at position "
                           + context.focus.getContextPosition());
            }

            /**
             * Do not process the result if the "where" test is false.
             */
            if (Query.getEffectiveBooleanValue(whereSequence) == false)
            {
               return null;
            }
         }

         /**
          * Evaluates the "return" clause.
          */
         returnSequence = this.returnExpression.evaluate(context);
      }
      else
      {
         returnSequence = this.nestedFLWORExpression.evaluate(context);
      }

      /**
       * Checks the "return" resulting sequence.
       */
      if (returnSequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the \"return\" clause at position "
                     + context.focus.getContextPosition());
      }

      return returnSequence;
   }

   /**
    * Propagate cancellation request to the sub-expressions. Here only the where
    * and return clauses are regarded.
    * 
    * @param reason a explicit message describing the origin or reason of the
    *           cancellation request. This reason will be reported in the
    *           message of the cancel exception.
    */
   public void cancel(final String reason)
   {
      /**
       * Call the super class implementation.
       */
      super.cancel(reason);

      /**
       * Propagate the cancellation request to the the where and return clauses.
       */
      this.whereExpression.cancel(reason);
      this.returnExpression.cancel(reason);
   }

   /**
    * Overrides the standard toString() operation for a convenient reporting.
    * The output is similar to the original XQuery script does not contain the
    * bound expressions.
    * 
    * @return the expression as a string.
    */
   public String toString()
   {
      String output = "";

      if (this.letBindings.size() > 0)
      {
         output = output + "let (bindings...)\n";
      }

      if (this.forBindings.size() > 0)
      {
         output = output + "for (bidings)\n";
      }

      if (this.whereExpression != null)
      {
         output = output + "where " + this.whereExpression + "\n";
      }

      output = output + "return " + this.returnExpression + "\n";

      return output;
   }

   /**
    * Checks if this FLWOR expression can modify the state of an existing node.
    * A FLWOR expression is updating if the return clause is updating.
    * 
    * @return true if this expression performs updating operations and false
    *         otherwise
    */
   public boolean isUpdating()
   {
      final double key = Math.random();
      this.logger.debug("FLOWR.isUpdating() : Start " + key);
      final boolean bool =
         (((this.returnExpression != null) && this.returnExpression
               .isUpdating()) || ((this.nestedFLWORExpression != null) && this.nestedFLWORExpression
               .isUpdating()));
      this.logger.debug("FLOWR.isUpdating() : Stop " + key);
      return bool;
   }
}
