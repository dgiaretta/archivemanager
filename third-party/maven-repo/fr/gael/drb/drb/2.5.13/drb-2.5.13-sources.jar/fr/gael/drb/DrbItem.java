/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import fr.gael.drb.value.Value;

/**
 * Item interface. This interface represents commons properties of structured
 * data. Supported item kinds are nodes, attributes and values.
 */
public interface DrbItem
{
   /**
    * The item type is undefined.
    */
   public static final int UNDEFINED_ITEM = 0;

   /**
    * The item is a node.
    */
   public static final int NODE_ITEM = 1;

   /**
    * The item is an attribute.
    */
   public static final int ATTRIBUTE_ITEM = 2;

   /**
    * The item is a value.
    */
   public static final int VALUE_ITEM = 3;

   /**
    * A code representing the type of the underlying object, as defined above.
    * 
    * @return The code of this item.
    */
   public int getItemType();

   /**
    * Name of the item. Returns the name of the item. This name does not contain
    * any prefix, path nor any other location or identification part.
    * 
    * @return The name of the item.
    */
   public String getName();

   /**
    * Changes the name of the item. The passed name may be an empty string but
    * never a null reference. The change is persistant such as further instance
    * of a same node (even in different sessions) will have this new name. If
    * the implementation does not suppot the rename operation it is supposed to
    * throw a UnsupportedOperationException.
    * 
    * @param name Reference to the new name.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested rename for any
    *            reason (e.g. specific case or general incapability).
    * @throws NullPointerException This exception is raised when the passed name
    *            is a null reference.This exception may be overriden by an
    *            UnsupportedOperationException.
    */
   public void rename(String name) throws NullPointerException,
         UnsupportedOperationException;

   /**
    * Get namespace URI. The namespace URI of this item, or null if it is
    * unspecified. This is not a computed value that is the result of a
    * namespace lookup based on an examination of the namespace declarations in
    * scope. It is merely the namespace URI given at creation time.
    * 
    * @return The namspace URI or null if unspecified.
    */
   public String getNamespaceURI();

   /**
    * Sets a namespace resource identifier. The new namespace identifier shall
    * not be null.
    * <p>
    * <b>Important note:</b> The implementation of the item is not supposed to
    * accept namespace changes. For instance it may not be possible to change
    * the namespace of a file that is basically fixed.
    * </p>
    * 
    * @param namespace_uri A reference to the new namespace identifier.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the new namespace identifier is null.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested namespace change
    *            for any reason (e.g. by definition or in the specific case).
    */
   public void setNamespaceURI(String namespace_uri)
         throws NullPointerException, UnsupportedOperationException;

   /**
    * The value of the item. The value is expressed accoring to one of the types
    * supported by the fr.gael.drb.value package. Generally these types
    * correspond to primitive types (e.g. integer, floating points, etc.) or
    * very low level types (e.g. string, date, etc.). On the contrary to DOM
    * implementation all the types are allowed even the arrays, date etc. Only
    * the Value.NULL_ID type is forbidden.
    * 
    * @return The value of the item.
    */
   public Value getValue();

   /**
    * Changes the value of the item. This operation sets a new value of the
    * current item.The value type of the item shall be compatible with the item
    * implementation. If the type does not match exactly it is casted to a
    * compatible one based on the the fr.gael.drb.value capabilities. A
    * reference to the effectivelly assigned value is returned by the operation
    * so it is possible to check if a cast has been performed and therefore
    * assess the accuracy of the assignement. If the cast is not possible the
    * operation raises an UnsupportedOperationException. If the assignment is
    * possible and the item implementation has a physical representation the
    * value is updated in the physical source in order to persist among
    * sessions. It therefore possible that this operation consumses an variable
    * time.
    * 
    * @param value The new value of the node. This value shall not be null.
    * @return The effectivelly assigned value. The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested assignment for
    *            any reason.
    */
   public Value setValue(Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException;
}
