/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import fr.gael.drb.value.DefaultValueArray;
import fr.gael.drb.value.Value;
import fr.gael.drb.value.ValueArray;

/**
 * This class provides a skeletal implementation of the DrbSequence interface,
 * to minimize the effort required to implement this interface.
 */
public abstract class DrbAbstractSequence implements DrbSequence
{
   /**
    * The atomic values of this sequence. The value of the node means its
    * content. The value is expressed accoring to one of the types supported by
    * the fr.gael.drb.value package. Generally these types correspond to
    * primitive types (e.g. integer, floatting points etc.) or very low level
    * types (e.g. string, date, etc.).
    * 
    * @return A reference to the values of the sequence.
    */
   public ValueArray atomize()
   {
      return atomize(this);
   }

   /**
    * The atomic values of this sequence. The value of the node means its
    * content. The value is expressed accoring to one of the types supported by
    * the fr.gael.drb.value package. Generally these types correspond to
    * primitive types (e.g. integer, floatting points etc.) or very low level
    * types (e.g. string, date, etc.).
    * 
    * @return A reference to the values of the sequence.
    */
   static ValueArray atomize(final DrbSequence seq)
   {
      final int count = seq.getLength();

      /**
       * Case where the sequence contains only one value which is an array
       */
      if ((count == 1) && (seq.getItem(0).getValue() != null)
            && (seq.getItem(0).getValue().getType() == Value.ARRAY_ID))
      {
         return (ValueArray) seq.getItem(0).getValue();
      }

      final DefaultValueArray values = new DefaultValueArray(count);
      int k = 0;
      for (int i = 0; i < count; i++)
      {
         final Value v = seq.getItem(i).getValue();

         if ((v != null) && (v.getType() == Value.ARRAY_ID))
         {
            final ValueArray array = (ValueArray) v;
            for (int j = 0; j < array.getLength(); j++)
            {
               values.assign(k, array.getItem(j).getValue());
               k++;
            }
         }
         // Assign value only if not null
         else if (v != null)
         {
            values.assign(k, v);
            k++;
         }

      }

      return values;
   }

   /**
    * Inserts a item at a given position. The passed item is inserted in the
    * list of children at the given position The position is the expected index
    * of the item after insertion. All the previous item from the aimed position
    * to the end of the list are shift to the end of the new sequence (i.e.
    * their indices are shifted up of 1). If the given index is out of the
    * sequence bounds and therefore less than zero and greater or equal to the
    * current number of items,the operation raises an exception. An index equal
    * to the current number of item is allowed and the operation is therefore
    * equivalent to an append.
    * 
    * @param index The expected index of the item after the insertion.
    * @param item A reference to the item to be inserted.
    * @return A reference to the a sequence containing the inserted node.
    * @throws NullPointerException This exception is raised when the passed item
    *            a null reference. This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passe
    *            index is less than zero or if it is greater or equal to the
    *            number of item in the sequence prior the call
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested insertion for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbSequence addItem(final int index, final DrbItem item)
         throws NullPointerException, UnsupportedOperationException,
         IndexOutOfBoundsException
   {
      throw new UnsupportedOperationException(
            "DrbAbstractSequence.addItem(): This operation is not supported.");
   } // addItem

   /**
    * Appends an item at the end of the item list.
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to append a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Case of unordered or specifically ordered implementations:</b> If the
    * implementation does not support ordered children or has specific ordering
    * rules, the node may not be appended but only inserted according to these
    * rules. For instance it may not be possible to impose the file order in a
    * directory:it generally depends on the lexicographical order of the node
    * names or their creation date.
    * </p>
    * 
    * @param item A reference to the item to be appended.
    * @return A reference to the a sequence containing the appended node.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference.This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested append for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbSequence addItem(final DrbItem item) throws NullPointerException,
         UnsupportedOperationException
   {
      return this.addItem(this.getLength(), item);
   } // addItem

   /**
    * Removes an existing item. The item at the given index is removed from the
    * sequence of the current item. The item is not modified by this operation.
    * The index of the item to be removed has to correspond to an existing item
    * index. If the index is less than zero or greater or equal to the current
    * number of items, an exception is thrown.
    * 
    * @param index Index of the item to be removed.
    * @return A reference to the a sequence after the removal of the item.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested removal for any
    *            reason.
    */
   public DrbSequence removeItem(final int index)
         throws IndexOutOfBoundsException, UnsupportedOperationException
   {
      throw new UnsupportedOperationException(
            "DrbAbstractSequence.removeItem(): This operation is not supported.");
   }
} // DrbAbstractSequence
