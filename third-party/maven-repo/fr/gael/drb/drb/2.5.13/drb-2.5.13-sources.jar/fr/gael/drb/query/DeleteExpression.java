/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbSequence;

/**
 * Wraps a Delete expression of XQuery Update Facility. The 'Delete' expression
 * implements the DO/DELETE updating expression of the XQuery Update Facility.
 * This expression matches :
 * <p>
 * <code>
 * <Do> <Delete> <Expr>
 * </code>
 * </p>
 * <p>
 * The expression following the 'delete' keyword is called the target
 * expression.
 * </p>
 */
class DeleteExpression extends AbstractExpression
{
   /**
    * The target expression. This expression cannot be null. The evaluation of
    * this expression provides the target node.
    */
   private Expression targetExpression = null;

   /**
    * Builds an instance of the DeleteExpression. The underlying expression
    * (i.e. target) is reset to null.
    * 
    * @param token the token related to the current expression.
    */
   public DeleteExpression(final Token token)
   {
      super("Delete", token);
   }

   /**
    * Accessor to the target expression. The parameter is not tested and the
    * reference is immeiately assigned to the target expression.
    * 
    * @param test_expression the expression to be assigned.
    */
   public void setTargetExpression(final Expression target_expression)
   {
      this.targetExpression = target_expression;
   }

   /**
    * Evaluates the delete expression. The evaluation context is used as outer
    * focus of the two underlying expressions. This means that the delete
    * expression context is used for the evaluation of the target expression.
    * The evaluation is performed as follow :
    * <p>
    * <b>Check target expression consitency:</b> before evaluating the
    * expression, the target expression shall not be null.
    * </p>
    * <p>
    * 
    * @param context the context to be considered during the evaluation. This
    *           parameter is mandatory so it is not controlled during the
    *           evaluation of the conditional expression. However, because it is
    *           directly used by the underlying expression a null context may
    *           raise an error if the expression requires a non null context.
    * @return the result of the evaluation of the delete expression is an empty
    *         sequence and a pending update list.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {

      DrbSequence output_sequence;
      /**
       * Checks the delete expression consitency.
       */
      if (this.targetExpression == null)
      {
         throw new DynamicException(this, "Incomplete \"delete\" declaration");
      }

      /**
       * Evaluates the target-expression
       */
      final DrbSequence target_sequence =
         this.targetExpression.evaluate(context);

      if (target_sequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the target expression");
      }

      /**
       * Check and process, should the occasion arise, the cancellation request.
       */
      if (this.isCancellationRequested() == true)
      {
         this.throwCancelException();
      }

      for (int i = 0; i < target_sequence.getLength(); i++)
      {
         final DrbItem target_item = target_sequence.getItem(i);
         // Case 1 : Deleting an element node
         if (target_item.getItemType() == DrbItem.NODE_ITEM)
         {
            final DrbNode target_node = (DrbNode) target_item;
            final DrbNode target_parent = target_node.getParent();
            final int target_index = target_node.getIndex();

            if (target_parent == null)
            {
               throw new DynamicException(this,
                     "[XUST0001] - While deleting an element, the target node must have a parent");
            }
            target_parent.removeChild(target_index);
         }
         else
         // Case 2 : Deleting an attribute node
         if (target_item.getItemType() == DrbItem.ATTRIBUTE_ITEM)
         {
            throw new DynamicException(this,
                  "[XUST0001] - 'Delete' expression is not implemented for attributes");
         }
         else
         {
            throw new DynamicException(this,
                  "[XUST0001] - Cannot delete an atomic value");
         }
      }
      /**
       * Evaluates the result (always an empty sequence).
       */
      output_sequence = new DrbDefaultSequence();

      return output_sequence;
   }

   /**
    * A expression which is constant means that it need no context item to be
    * evaluate. The returned sequence from its evaluation will always be the
    * same along the query script
    * 
    * @return true if this expression is constant
    */
   public boolean isConstant()
   {
      return false;
   }

   /**
    * Identifies expression that can modify the state of an existing node. This
    * function returns always true since 'delete' is a basic updating expression
    * 
    * @return true
    */
   public boolean isUpdating()
   {
      return true;
   }
}
