/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sdf;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.value.Value;
import fr.gael.drb.xsd.XsdInvalid;
import fr.gael.drb.xsd.XsdNode;

/**
 * Abstract block. This class provides the abstract implementation of DrbNode
 * for the Structured Data File block. Most of the operations are implemented
 * here but as a block always getting information from its descriptor. Therefore
 * a set of subclasses should store such information into cache to improve
 * performance.
 */
public abstract class AbstractBlock extends DrbNodeImpl implements XsdNode
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(AbstractBlock.class);

   /**
    * Descriptor of the block. Reference to the block descriptor. The descriptor
    * is used to access the file and information about the block
    */
   protected Descriptor descriptor;

   /**
    * Key of the block in the Structured Data File tree. This is an array
    * containing the occurrence indexes of the block and all its ancestors up to
    * the root block of the structured file. Root index is omitted because is
    * always 0. Values start from 0 for the first index. The number of indexes
    * corresponds to the depth in the tree, having depth=0 for the root block.
    */
   protected int[] key;

   /**
    * Initializes the class attributes. As the class is abstract, this
    * operations can only be called by subclasses as super(descriptor,key).<br>
    * The descriptor and the key must not be null.
    * 
    * @param descriptor The descriptor of the block.
    * @param key The key of the block.
    */
   protected AbstractBlock(final Descriptor descriptor, final int[] key)
   {
      // Check parameters
      if ((descriptor == null) || (key == null))
      {
         this.logger.error("AbstractBlock.AbstractBlock() ERROR: "
               + "Invalid parameter(s).");
         if (descriptor == null)
         {
            this.logger.error("   descriptor       = null");
         }
         else
         {
            this.logger.error("   descriptor.name  = " + descriptor.getName());
         }
         this.logger.error("   key              = " + IntMap.keyToString(key));
      }

      // Set the values
      this.descriptor = descriptor;
      this.key = key;
   }

   /**
    * Name of the block. This name is the canonical name of the block and is
    * directly extracted from the descriptor.
    * 
    * @return The name of the block.
    */
   public final String getName()
   {
      return this.descriptor.getName();
   }

   /**
    * The sdf namespace. The namespace URI of any node produced by this class is :
    * "http://www.gael.fr/drb/impl/sdf-20020222".
    * 
    * @return "http://www.gael.fr/drb/impl/sdf-20020222"
    */
   public final String getNamespaceURI()
   {
      if (this.descriptor.getSchema() == null)
      {
         return "http://www.gael.fr/drb/impl/sdf-20020222";
      }
      else
      {
         return this.descriptor.getSchema().getTargetNamespace();
      }
   }

   /**
    * Offset of the block. Returns the offset of the block in the underlying
    * RandomAccessFile.
    * 
    * @return The offset in bytes.
    */
   protected long getOffset()
   {
      return this.descriptor.getOffset(this.key);
   }

   /**
    * Length of the block. Returns the length of the block (children included).
    * 
    * @return The length in bytes.
    */
   protected long getLength()
   {
      return this.descriptor.getLength(this.key);
   }

   /**
    * Name of the node. Returns the name of the node. This name is the canonical
    * name of the node It does not contains any prefix, path and location
    * part.This name clearly identifies the node in its parent depending only
    * from its occurence number and its index. All nodes provided by an
    * implementation is named. Therefore this operation never returns null
    * value. An empty string is however allowed if the node is unique (e.g. non
    * named root node).
    * 
    * @return The name of the node.
    */
   public String getXPathName()
   {
      int occurrence; // Current occurrence
      // Get occurrence at the current sdf tree depth
      if (this.key.length == 0)
      {
         return "(" + this.descriptor.getSchemaNodePath() + ")"
               + this.descriptor.getRoot().getName();
      }

      occurrence = this.key[this.key.length - 1];

      // Case of single occurrence, do not print the occurrence
      final String desc_name = this.descriptor.getName();

      if ((occurrence == 0)
            && (this.descriptor.getOccurrenceCount(this.key) <= 1))
      {
         return desc_name;
      }
      // Else print the occurrence (e.g. "/mds[1]")
      else
      {
         return desc_name + "[" + (occurrence + 1) + "]";
      }
   }

   /**
    * Returns the path of the SDF node. This operation loops on the ancestors of
    * the current node to build the path within the SDF. At each step the
    * occurrence number of the node is computed. The general form of the path
    * within the SDF is : step[occ]/step[occ] [...]. The occurence number is
    * ommited if equal to 1. The base path (the one of the underlying
    * implementation) is added before the computed path, together with schema
    * path. For instance :<br>
    * "./MyMeris/(/schemas/MER_RR__1P.xml)MER_RR__1P/mds[2]/mdsr[10]/toa_rad"
    * 
    * @return The path of the current node.
    */
   /*
    * public String getPath() { Descriptor currentDescriptor; // Current
    * descriptor DrbNode baseNode; // Base node of the current SDF String path =
    * ""; // The path to return int occurrence; // Current occurrence int[]
    * currentKey; // Current key // Loop on key items (occurrences in reverse
    * order) currentKey = key; currentDescriptor = this.descriptor; for (int i =
    * key.length - 1; i >= 0; i--) { // Get occurrence at the current sdf tree
    * depth occurrence = key[i]; // Case of single occurrence, do not print the
    * occurrence if ((occurrence == 0) &&
    * (currentDescriptor.getOccurrenceCount(currentKey) <= 1)) { path = "/" +
    * currentDescriptor.getName() + path; } // Else print the occurrence (e.g.
    * "/mds[1]") else { path = "/" + currentDescriptor.getName() + "[" +
    * (occurrence + 1) + "]" + path; } // Get parent descriptor
    * currentDescriptor = currentDescriptor.getParent(); currentKey =
    * IntMap.getParentKey(currentKey); } // At this step the root descriptor
    * must be added (key ={}) path = this.descriptor.getRoot().getName() + path; //
    * Return path with base node and schema path as follow : //
    * base_node_path/(schema_path)descriptors_path return
    * this.descriptor.getBaseNodePath() + "/(" +
    * this.descriptor.getSchemaNodePath() + ")" + path; }
    */

   /**
    * Returns the attributes. Attributes can be "encoding", "occurrence",
    * "offset", "length", "bitLength" and "documentation".
    * 
    * @return The list of block attributes.
    */
   public DrbAttributeList getAttributes()
   {
      // Local declarations
      DrbDefaultAttributeList attr_list; // Output attribute list
      DrbDefaultAttribute attr; // Attribute to add in attribute list
      String strTmp; // Temporary string
      fr.gael.drb.value.String str_value; // Attribute string
      fr.gael.drb.value.Long long_value; // Attribute long

      // Creates attribute list
      attr_list = new DrbDefaultAttributeList();

      // Creates encoding attribute
      switch (this.descriptor.getEncoding())
      {
         case Descriptor.ENCODING_BINARY:
            strTmp = "Binary";
            break;
         case Descriptor.ENCODING_ASCII:
            strTmp = "Ascii";
            break;
         case Descriptor.ENCODING_EBCDIC:
            strTmp = "Ebcdic";
            break;
         default:
            strTmp = "Unknown (" + this.descriptor.getEncoding() + ")";
            break;
      }
      str_value = new fr.gael.drb.value.String(strTmp);
      attr = new DrbDefaultAttribute("encoding", str_value, false, this);
      attr_list.add(attr);

      // Creates occurrence attribute if occurrence > 1
      final int occurrence =
         (this.key.length > 0) ? this.key[this.key.length - 1] : -1;
      if (occurrence > 0)
      {
         long_value = new fr.gael.drb.value.Long(occurrence + 1);
         attr = new DrbDefaultAttribute("occurrence", long_value, false, this);
         attr_list.add(attr);
      }

      // If node has no child adds offset and length
      // CD : Sinon le calcul est fait et ca peut prendre beaucoup de temps des
      // le debut.
      if (!this.hasChild())
      {
         // Creates offset attribute
         long_value =
            new fr.gael.drb.value.Long(this.descriptor.getOffset(this.key));
         attr = new DrbDefaultAttribute("offset", long_value, false, this);
         attr_list.add(attr);

         // Creates length attribute if node has no child
         final int bitLength = this.descriptor.getBitLength();
         if (bitLength == 0)
         {
            long_value =
               new fr.gael.drb.value.Long(this.descriptor.getLength(this.key));
            attr = new DrbDefaultAttribute("length", long_value, false, this);
         }
         else
         {
            long_value =
               new fr.gael.drb.value.Long(8
                     * this.descriptor.getLength(this.key) + bitLength);
            attr =
               new DrbDefaultAttribute("bitLength", long_value, false, this);
         }
         attr_list.add(attr);
      }

      // Creates documentation attribute
      strTmp = this.descriptor.getDocumentation();
      if (strTmp != null)
      {
         str_value = new fr.gael.drb.value.String(strTmp);
         attr =
            new DrbDefaultAttribute("documentation", str_value, false, this);
         attr_list.add(attr);
      }

      // Creates type attribute
      if ((this.descriptor.getType() != null)
            && (this.descriptor.getType().getName() != null))
      {
         str_value =
            new fr.gael.drb.value.String(this.descriptor.getType().getName());
         attr = new DrbDefaultAttribute("type", str_value, false, this);
         attr_list.add(attr);
      }

      // Returns the attribute list if not empty
      if (attr_list.getLength() > 0)
      {
         return attr_list;
      }
      else
      {
         return null;
      }
   }

   /**
    * Returns the value of the block. This operation is left as abstract here.
    * According to the block type, several optimisation levels can be provided.
    * Therefore implementation must be decided by sub-classes.
    * 
    * @return The block value.
    */
   public abstract Value getValue();

   /**
    * Returns the value type of the block. This operation is left as abstract
    * here. According to the block type, several optimisation levels can be
    * provided. Therefore implementation must be decided by sub-classes.
    * 
    * @return The block value type.
    */
   public abstract int getValueType();

   /**
    * Index of the block. Returns the index of the block in its parent block.
    * This implementation uses the parent descriptor to parse all children and
    * count blocks until the current one.<br>
    * No cache is performed, descriptors are used on each call.
    * 
    * @return The index of the block or a negative value.
    */
   public int getIndex()
   {
      // Local declarations
      Descriptor childDesc; // reference to a child descriptor
      int curIndex; // Current index
      // Case of root block
      if (this.key.length == 0)
      {
         return 0;
      }

      // Loop on children descriptors of the parent until to find the same as
      // the current descriptor.
      curIndex = 0;
      childDesc = this.descriptor.getParent().getFirstChild();
      while (childDesc != null)
      {
         // If block descriptor is the same as the current child
         // descriptor, returns the count of previous blocks plus the
         // corresponding block occurrence (the last element of the key).
         if (this.descriptor == childDesc)
         {
            return (curIndex + this.key[this.key.length - 1]);
         }

         // Add occurrence number of this child descriptor to the count.
         // As block occurrence number can only be fixed or constant in the
         // parent, the value can be retreived with a key having the same
         // "parent key" prefix. Then the current block key can be used.
         curIndex += childDesc.getOccurrenceCount(this.key);

         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
      }

      // At this step all children descriptors have been browsed then this
      // case cannot exists
      this.logger.error("AbstractBlock.getIndex() ERROR: "
            + "This message should never appear !");
      this.logger.error("   No descriptor in the parent matches the "
            + "current one = " + this.descriptor);
      return -1;
   }

   /**
    * Returns a new instance of the root block. If the current block is the root
    * block then return the block itself.<br>
    * Uses the current descriptor and the root descriptor to create a new
    * instance of the root block.
    * 
    * @return A new instance of the root block.
    */
   public DrbNode getRoot()
   {
      // Check if current block is already the root.
      if (this.key.length == 0)
      {
         return this;
      }

      // The root block has an empty array key.
      return new DefaultBlock(this.descriptor.getRoot(), new int[] {});

   }

   /**
    * Returns a new instance of the parent block. If the current block is the
    * root block returns null.<br>
    * Uses the current descriptor and its parent to create the parent block.
    * 
    * @return A new instance of the parent block or null.
    */
   public DrbNode getParent()
   {
      // Local declarations
      Descriptor parentDesc; // Parent descriptor
      int[] parentKey; // Parent key

      // Case of "root" block : it has no parent then returns null
      if (this.key.length == 0)
      {
         return this.descriptor.getBaseNode();
      }

      // Get parent related information
      parentDesc = this.descriptor.getParent();
      parentKey = IntMap.getParentKey(this.key);

      return this.createOptimalBlock(parentDesc, parentKey, parentDesc
            .getOccurrenceCount(parentKey));
   }

   /**
    * Returns a new instance of the list of children blocks. If the block has no
    * child returns null.<br>
    * This implementation uses the descriptor to parse all its children and
    * create a new instance of each corresponding block. These blocks are then
    * added to the list.<br>
    * 
    * @return A new list of children if any, null otherwise.
    */
   public DrbNodeList getChildren()
   {
      // Local declarations
      DrbDefaultNodeList children; // List of children
      Descriptor childDesc; // reference to a child descriptor
      int childDescOccurrenceCount; // occurrence count of child desc

      // Create the children list
      children = new DrbDefaultNodeList();

      // Loop on child descriptors
      childDesc = this.descriptor.getFirstChild();
      while (childDesc != null)
      {
         // Loops on block occurrences of the current child descriptor.
         childDescOccurrenceCount =
            childDesc.getOccurrenceCount(IntMap.getChildKey(this.key, 0));
         for (int i = 0; i < childDescOccurrenceCount; i++)
         {
            children.add(this.createOptimalBlock(childDesc, IntMap.getChildKey(
                  this.key, i), childDescOccurrenceCount));
         }

         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
      }

      // If no child returns null
      if (children.size() == 0)
      {
         return null;
      }

      // Returns the children list
      return children;
   }

   /**
    * Returns true if at least one child exists for the current block. Browses
    * the children descriptors until one block occurrence exists.<br>
    * If the current descriptor has no child then returns false.<br>
    * If all the children descriptors have no block occurrence then returns
    * false.<br>
    * No cache is performed, descriptors are used on each call.
    * 
    * @return true if this block has at least one child, false otherwise.
    */
   public boolean hasChild()
   {
      // Local declarations
      Descriptor childDesc; // reference to a child descriptor

      // Loop on child descriptors until one occurrence is found.
      childDesc = this.descriptor.getFirstChild();
      while (childDesc != null)
      {
         // If an occurrence is found, return true
         if (childDesc.getOccurrenceCount(IntMap.getChildKey(this.key, 0)) > 0)
         {
            return true;
         }

         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
      }

      // At this step all children descriptors have been browsed but no
      // block occurrence found.
      return false;
   }

   /**
    * Returns a new instance of the first child of the current block. Browses
    * the children descriptors until one block occurrence exists and returns it.<br>
    * If the current descriptor has no child then returns null.<br>
    * If all the children descriptors have no block occurrence then returns
    * null.
    * 
    * @return A new instance of the first child block or null.
    */
   public DrbNode getFirstChild()
   {
      // Local declarations
      Descriptor childDesc; // reference to a child descriptor
      int[] childKey; // Key of the child
      int childDescOccurrenceCount; // occurrence count of child desc

      // Loop on child descriptors until one occurrence is found.
      childDesc = this.descriptor.getFirstChild();
      while (childDesc != null)
      {
         // Create child key
         childKey = IntMap.getChildKey(this.key, 0);

         // If an occurrence is found, returns the corresponding block.
         if ((childDescOccurrenceCount = childDesc.getOccurrenceCount(childKey)) > 0)
         {
            return this.createOptimalBlock(childDesc, childKey,
                  childDescOccurrenceCount);
         }

         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
      }

      // At this step all children descriptors have been browsed but no
      // block occurrence found.
      return null;
   }

   /**
    * Returns a new instance of the last child of the current block. This
    * implementation calls getChildAt(getChildrenCount()-1).<br>
    * Therefore performance is low because descriptors are used 2 times at each
    * call.
    * 
    * @return A new instance of the last child block or null.
    */
   public DrbNode getLastChild()
   {
      return this.getChildAt(this.getChildrenCount() - 1);
   }

   /**
    * Returns a new instance of the "index"th child of the current block.
    * Browses the children descriptors, counts block occurrences until the
    * "index"th and returns it.<br>
    * If the current descriptor has no child then returns null.<br>
    * If index is outside the range of children count then returns null.
    * 
    * @param index The position of the child block to retreive starting from 0
    *           and not greater or equal to the number of children.
    * @return A new instance of the "index"th child block or null.
    */
   public DrbNode getChildAt(final int index)
   {
      // Local declarations
      Descriptor childDesc; // reference to a child descriptor
      int[] childKey; // Key of the child
      int childrenCount; // total number of children
      int descOccurrenceCount; // occurrence number in current desc

      // Check parameter
      if (index < 0)
      {
         // this.logger.warn("getChildAt("+index+"): Out of bounds !");
         return null;
      }

      // Loop on child descriptors until one occurrence is found.
      childrenCount = 0;
      childDesc = this.descriptor.getFirstChild();
      while (childDesc != null)
      {
         // Create child key
         childKey = IntMap.getChildKey(this.key, index - childrenCount);

         // If index corresponds to the occurrences of the current child
         // descriptor, returns the corresponding block.
         if ((descOccurrenceCount = childDesc.getOccurrenceCount(childKey)) > index
               - childrenCount)
         {
            return this.createOptimalBlock(childDesc, childKey,
                  descOccurrenceCount);
         }

         // Add occurrence number of this child descriptor to the count
         childrenCount += descOccurrenceCount;

         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
      }

      // At this step all children descriptors have been browsed but no
      // block occurrence found.
      return null;
   }

   /**
    * Returns a new instance of the child block having the given name and the
    * given occurrence. This implementation browses the children descriptors
    * until to match the given name, then get the associated block occurrence if
    * exists.<br>
    * If the current descriptor has no child then returns null.<br>
    * If no block having this occurrence exists then returns null.
    * 
    * @param name The name of the child block to retreive.
    * @param occurrence The occurrence of the child block to retreive, value
    *           starting from 1.
    * @return A new instance of the child block having the given name and
    *         occurrence.
    */
   public DrbNode getNamedChild(final String name, int occurrence)
   {
      // Local declarations
      Descriptor childDesc; // reference to a child descriptor
      int[] childKey; // Key of the child
      int descOccurrenceCount; // occurrence number in current desc

      // Check parameter
      if (occurrence < 1)
      {
         this.logger.error("getNamedChild() Error : " + "Invalid occurrence ("
               + occurrence + ").");
         return null;
      }

      // Loop on child descriptors until name is found.
      childDesc = this.descriptor.getFirstChild();
      while (childDesc != null)
      {
         // If the descriptor name matches the given name
         if (childDesc.getName().equals(name))
         {
            // Create first named child key
            childKey = IntMap.getChildKey(this.key, 0);

            // If occurrence is in range of the current occurrence count then
            // returns the corresponding block.
            if ((descOccurrenceCount = childDesc.getOccurrenceCount(childKey)) >= occurrence)
            {
               // Create child key for this occurrence, only the last key
               // item has to be changed (value starts from 0).
               childKey[childKey.length - 1] = occurrence - 1;

               // Return the created block
               return createOptimalBlock(childDesc, childKey,
                     descOccurrenceCount);
            }

            // At this step the name was matched but occurrence was bigger than
            // occurrence count then the current occurrence count is
            // substracted in case another node has the same name
            occurrence = occurrence - descOccurrenceCount;
         }

         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
      }

      // At this step all children descriptors have been browsed but none
      // with the given name then returns null.
      return null;
   }

   /**
    * Returns the number of children of the current block. Browses the children
    * descriptors to count all children occurrences for the current block.<br>
    * If the current descriptor has no child then returns 0.<br>
    * If all children descriptors have no block occurrence then returns 0.<br>
    * No cache is performed, descriptors are used on each call.
    * 
    * @return The number of children for the current block.
    */
   public int getChildrenCount()
   {
      // Local declarations
      Descriptor childDesc; // reference to a child descriptor
      int childrenCount; // number of children

      // Loop on child descriptors.
      childrenCount = 0;
      childDesc = this.descriptor.getFirstChild();
      while (childDesc != null)
      {
         // Add occurrence number of this child descriptor to the count
         childrenCount +=
            childDesc.getOccurrenceCount(IntMap.getChildKey(this.key, 0));

         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
      }

      // All children descriptors have been browsed then returns the
      // children block count.
      return childrenCount;
   }

   /**
    * Returns a new instance of the previous sibling block. This implementation
    * uses getParent().getChildAt(getIndex()-1).<br>
    * Therefore performance is low because descriptors are parsed 2 times at
    * each call.
    * 
    * @return A new instance of the previous sibling block or null.
    */
   public DrbNode getPreviousSibling()
   {
      return ((AbstractBlock) this.getParent()).getChildAt(this.getIndex() - 1);
   }

   /**
    * Returns a new instance of the next sibling block. Uses the current
    * descriptors and its next sibling if needed, because the next sibling block
    * can have the same descriptor (in case of multiple occurrences) or another
    * next sibling descriptor (having at least one block occurrence).
    * 
    * @return A new instance of the next sibling block or null.
    */
   public DrbNode getNextSibling()
   {
      // Local declarations
      Descriptor nextDesc; // reference to a next descriptor
      int[] nextKey; // Key of the next sibling
      int curOccurrence; // Occurrence of the block in its desc
      int descOccurrenceCount; // Occurrence count in the current desc

      // Case of root block
      if (this.key.length == 0)
      {
         return null;
      }

      // If the descriptor has multiple occurrences and the current occurrence
      // is lower, then returns the next sibling with the same descriptor
      curOccurrence = this.key[this.key.length - 1];
      descOccurrenceCount = this.descriptor.getOccurrenceCount(this.key);
      if (curOccurrence < descOccurrenceCount - 1)
      {
         return createOptimalBlock(this.descriptor, IntMap.getSiblingKey(
               this.key, curOccurrence + 1), descOccurrenceCount);
      }

      // Loop on next descriptors until a block occurrence is found.
      nextDesc = this.descriptor;
      while ((nextDesc = nextDesc.getNextSibling()) != null)
      {
         // Create key of the next sibling
         nextKey = IntMap.getSiblingKey(this.key, 0);

         // If an occurrence is found, returns the block with the next desc.
         if ((descOccurrenceCount = nextDesc.getOccurrenceCount(nextKey)) > 0)
         {
            return createOptimalBlock(nextDesc, nextKey, descOccurrenceCount);
         }
      }

      // At this step all next descriptors have been browsed then no next
      // sibling exists
      return null;
   }

   /**
    * Creates a new instance of AbstractBlock with the best implementation.
    * Depending of the passed values the optimal sub-class is selected.
    * 
    * @param descriptor The descriptor of the block.
    * @param key The key of the block.
    * @param occurrence_count The number of block occurrence(s) in the set.
    * @return AbstractBlock
    */
   protected static final AbstractBlock createOptimalBlock(
         final Descriptor descriptor, final int[] key,
         final int occurrence_count)
   {
      // Local declaration
      int lengthType; // The descriptor length value type

      // Get length value type
      lengthType = descriptor.getLengthType();

      // If the block has more than one occurrence and a length fixed or
      // constant in parent then creates a MultipleOccurrenceBlock instead of
      // a DefaultBlock
      if ((occurrence_count > 1)
            && ((lengthType == PhysicalAttribute.FIXED) || (lengthType == PhysicalAttribute.CONSTANT_IN_PARENT)))
      {
         return new MultipleOccurrenceBlock(descriptor, key, occurrence_count,
               descriptor.getOffset(key), descriptor.getLength(key));
      }

      // Else Return the parent block as a DefaultBlock
      return new DefaultBlock(descriptor, key);
   }

   /**
    * Checks nodes equality.
    * 
    * @param node The node supposed to be equal to the current one.
    * @param deep true if the equality has to be performed recursively on the
    *           children of the nodes to be compared.
    * @return true is the nodes are equals and false otherwise (i.e. including
    *         cases of null reference to node).
    */
   // public boolean isEqual(DrbNode node, boolean deep)
   // {
   // }
   /**
    * Checks nodes sameness.
    * 
    * @param node The node to test against to the current one.
    * @return true if the node references the same object as the current node
    *         and false otherwise (i.e. including null reference to node).
    */
   // public boolean isSame(DrbNode node)
   // {
   // }
   /**
    * Tests if a specific interface can be provided. Returns true if the passed
    * interface can be provided by the class, false otherwise. This operation is
    * left as abstract here. Sub-classes must decide which implementation to
    * provide.
    * 
    * @param api The class type to test.
    * @return true if an implementation of the interface can be provided and
    *         false otherwise.
    */
   // public abstract boolean hasImpl(Class api);
   /**
    * Returns a specific implementation. This operation is left as abstract
    * here. Sub-classes must decide which implementation to provide.
    * 
    * @param api The interface (or class) to be provided.
    * @return A reference to the object implementing the interface or a null
    *         reference otherwise.
    */
   // public abstract Object getImpl(Class api);
   /*-----------------------------------------------------------------------*/
   /* DrbNodeImpl Interface */
   /*-----------------------------------------------------------------------*/
   /**
    * Closes this node and releases any system resources associated with the
    * pointed file. A closed node cannot perform input or output operations and
    * cannot be reopened.
    * 
    * @param deep if this flag is disabled,the implementation shall not release
    *           the ressources shared with the descendants.
    */
   public void close(final boolean deep)
   {
      // Only the root can be closed.
      // If the deep flag is not activated, we do not close the children
      if (deep && (this.descriptor != null) && (this.key.length == 0))
      {
         this.descriptor.dispose();
      }
   }

   /*---------------------------------------------------------------------*/
   /* XsdNode Interface */
   /*---------------------------------------------------------------------*/
   /**
    * Check the conformance of a node to its type.
    * 
    * @return an object describing the errors encoutered or null if there are no
    *         errors.
    */
   public XsdInvalid isValid()
   {
      if (this.descriptor.getType() == null)
      {
         return null;
      }
      else
      {
         return this.descriptor.getType().isValid(this);
      }
   } // isValid

   /*------------------------------------------------------------------------*/
   /* DrbMutableNode Interface */
   /*------------------------------------------------------------------------*/
   /**
    * Changes the name of the node. In this implementation the operation is not
    * supported because a node name depends on the underlying associated schema.
    * <p>
    * <b>Events:</b> No particular event is fired in this implementation.
    * </p>
    * 
    * @param name Reference to the new name (unused).
    * @throws UnsupportedOperationException This exception is always raised in
    *            this implementation.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    */
   public void rename(final String name) throws NullPointerException,
         UnsupportedOperationException
   {
      throw new UnsupportedOperationException(
            "AbstractBlock.rename(): This operation is not supported. "
                  + "SDF node name is defined by the underlying schema.");
   }

   /**
    * Changes the value of the node. This implementation wraps the setValue()
    * operation from the descriptor. The value is written in the file using
    * offset and length declared or computed through the block descriptor and
    * corresponding to the current block occurrence.
    * <p>
    * <b>Events:</b> No particular event is fired in this implementation.
    * </p>
    * 
    * @param value The new value of the node. This value shall not be null.
    * @return The effectivelly assigned value. The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            offset or the length used to write is unknown.
    */
   public Value setValue(final Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      // Check passed value
      if (value == null)
      {
         throw new NullPointerException("AbstractBlock.setValue(): "
               + "The reference to the new value is null.");
      }
      // Wrap to Descriptor
      return this.descriptor.setValue(value, this.key);
   }

   /**
    * Set the attribute list of a node. In this implementation the operation is
    * not supported because node attributes are computed according to the file
    * instance and the underlying schema.
    * <p>
    * <b>Events:</b> No particular event is fired in this implementation.
    * </p>
    * 
    * @param attributes A reference to the new attribute list (unused).
    * @throws UnsupportedOperationException This exception is always raised in
    *            this implementation.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the node is null.
    */
   public void setAttributes(final DrbAttributeList attributes)
         throws NullPointerException, UnsupportedOperationException
   {
      throw new UnsupportedOperationException(
            "AbstractBlock.setAttributes(): This operation is not supported. "
                  + "SDF node attributes are computed according to the"
                  + " file instance " + "and the underlying schema.");
   }

   /**
    * Sets a namespace resource identifier. In this implementation the operation
    * is not supported because the SDF namespace is already defined and
    * constant.
    * <p>
    * <b>Events:</b> No particular event is fired in this implementation.
    * </p>
    * 
    * @param namespace_uri A reference to the new namespace identifier (unused)
    * @throws UnsupportedOperationException This exception is always raised in
    *            this implementation.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the node is null.
    */
   public void setNamespaceURI(final String namespace_uri)
         throws NullPointerException, UnsupportedOperationException
   {
      throw new UnsupportedOperationException(
            "AbstractBlock.setNamespaceURI(): This operation is not supported. "
                  + "SDF namespace is defined and constant.");
   }

   /**
    * Inserts a child at a given position. In this implementation the operation
    * is wrapped to the appendChild() because the order is fixed by the
    * underlying schema.
    * <p>
    * <b>Events:</b> No particular event is fired yet in this implementation.
    * </p>
    * 
    * @param node A reference to the node to be inserted.
    * @param index The expected index of the node after the insertion (unused).
    * @return A reference to the effectively inserted node. This reference
    *         always differs from the input one in this implementation.
    * @throws UnsupportedOperationException This exception is always raised in
    *            this implementation.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the node is null.
    * @throws IndexOutOfBoundsException This exception is raised when the list
    *            of child is too long.
    */
   public DrbNode insertChild(final DrbNode node, final int index)
         throws NullPointerException, UnsupportedOperationException,
         IndexOutOfBoundsException
   {
      // Checks the passed node
      if (node == null)
      {
         throw new NullPointerException(
               "AbstractBlock.insertChild(): The reference to the node to "
                     + "insert is null.");
      }
      // Wraps to appendChild() operation and returns the node
      return this.appendChild(node);
   }

   /**
    * Appends a child at the end of the children list. This implementation wraps
    * the appendChild() operation from the descriptor All values are recursively
    * written using the offsets and lengths corresponding to each block
    * descriptor and block occurrence. The order depends on the underlying
    * descriptor.
    * <p>
    * <b>Events:</b> No particular event is fired yet in this implementation.
    * </p>
    * 
    * @param node A reference to the node to be appended.
    * @return A reference to the node passed in parameter.
    * @throws NullPointerException This exception is raised when the passed node
    *            is a null reference.
    * @throws UnsupportedOperationException This exception is raised when the
    *            current block cannot accept any child or if the child name does
    *            not match any valid children name from the descriptor.
    */
   public DrbNode appendChild(final DrbNode node) throws NullPointerException,
         UnsupportedOperationException
   {
      // Checks the passed node
      if (node == null)
      {
         throw new NullPointerException("AbstractBlock.appendChild(): "
               + "The reference to the node to append is null.");
      }

      // Wrap to Descriptor
      return this.descriptor.appendChild(node, this.key, false, true, 1);
   }

   /**
    * Replaces a child of the current node. In this implementation the operation
    * is not supported yet.
    * 
    * @param index Index of the node to be replaced. This index starts at 0 and
    *           shall be less than the number of children (unused).
    * @param new_node A reference to the node that replaces the old one(unused)
    * @return null.
    * @throws UnsupportedOperationException This exception is always raised in
    *            this implementation.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the node is null.
    * @throws IndexOutOfBoundsException This exception is raised when the list
    *            of child is too long.
    */
   public DrbNode replaceChild(final int index, final DrbNode new_node)
         throws NullPointerException, IndexOutOfBoundsException,
         UnsupportedOperationException
   {
      // Used to bypass the compiler error: A "return" after a "throw" is not
      // a reachable statement but is missing if not written !
      if (true)
      {
         throw new UnsupportedOperationException(
               "AbstractBlock.replaceChild(): This operation is not supported "
                     + "yet.");
      }

      return null;
   }

   /**
    * Removes an existing child. In this implementation the operation is not
    * supported yet. In the future it will probably remove the reference to the
    * child block using the specified index and removing one occurrence in the
    * related Descriptor.
    * <p>
    * <b>Events:</b> No particular event is fired in this implementation.
    * </p>
    * 
    * @param index Index of the child to be removed (unused).
    * @throws UnsupportedOperationException This exception is always raised in
    *            this implementation.
    * @throws IndexOutOfBoundsException This exception is raised when the list
    *            of child is too long.
    */
   public void removeChild(final int index) throws IndexOutOfBoundsException,
         UnsupportedOperationException
   {
      throw new UnsupportedOperationException("AbstractBlock.removeChild(): "
            + "This operation is not supported yet.");
   }

   /*------------------------------------------------------------------------*/
   /* End of DrbMutableNode Interface */
   /*------------------------------------------------------------------------*/

   /**
    * Print the AbstractBlock info into a string. For instance string can have
    * the following format : "{ "MER_RR__1P/MDS/MDSR" {0 1} }". Where the first
    * element is the descriptor name tree and the {0 1} list the key of the
    * block.
    * 
    * @return The string containing key info.
    */
   public String toString()
   {
      // Print the descriptors tree names
      String info = this.descriptor.getName();
      Descriptor tmp = this.descriptor;
      while ((tmp = tmp.getParent()) != null)
      {
         info = tmp.getName() + "/" + info;
      }
      info = "{ \"" + info + "\" ";

      // Print the key and return info string
      info = info + IntMap.keyToString(this.key) + " }";
      return info;
   }
} // AbstractBlock
