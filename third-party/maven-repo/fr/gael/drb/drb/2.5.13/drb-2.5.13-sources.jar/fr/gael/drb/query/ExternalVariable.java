/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbSequence;

/**
 * Variable declared as external in the XQuery module prologs.
 * <p>
 * The variable may be provided before any phase of the processing of the XQuery
 * script. In most cases, the list of external variables is however, augmented
 * during the static analysis phase and used during the dynamic evaluation
 * phase.
 * </p>
 * <p>
 * Regarding the default value, it is evaluated as soon as the variable has been
 * declared. The default value is not re-evaluated each time they are use, and
 * therefore, their value is independent from the context during any dynamic
 * evaluation phase.
 * </p>
 */
public class ExternalVariable extends DefaultVariable
{
   /**
    * The label of the variable.
    * 
    * @deprecated the label should no longer be used.
    */
   private String label;

   /**
    * The default value evaluated at construction.
    */
   private DrbSequence defaultValue = null;

   /**
    * Constructor of an external variable.
    * 
    * @param name string form of the variable qualified name.
    * @param sequence_type the type of the variable.
    * @param default_value the default value of the variable.
    */
   protected ExternalVariable(final QName name,
         final SequenceType sequence_type, final DrbSequence default_value)
   {
      super(name, sequence_type, default_value);

      this.setDefaultValue(default_value);      
   }

   /**
    * Returns the default value of the variable. The default value is computed
    * from the value part of the external variable declaration of the XQuery
    * prolog. This evaluation may have lead to dynamic errors if the query is
    * not well-formed or contain a forbidden cyclic reference to the declared
    * variable. In those cases of error, the exception are caught and a empty
    * sequence is returned.
    * 
    * @return the default value of the variable if any, or null otherwise.
    */
   public DrbSequence getDefaultValue()
   {
      return this.defaultValue;
   }

   /**
    * Set the default value of the variable.
    * 
    * @param value the default value of the variable.
    */
   private void setDefaultValue(DrbSequence value)
   {
      this.defaultValue = value;
   }

   /**
    * Set the label of the external variable. The label is an explicit name of
    * the variable that should enhance the human readability and understanding
    * of the variable scope. The language of the label depends on the creator of
    * the variable and thus, the creator of the environment or the XQuery script
    * writer.
    * 
    * @deprecated this operation shall no longer be used as far as the label
    *             will no longer be supported in further versions of the engine.
    * @param label the label of the external variable.
    */
   protected void setLabel(final String label)
   {
      this.label = label;
   }

   /**
    * Returns the label of the external variable. The label is an explicit name
    * of the variable that should enhance the human readability and
    * understanding of the variable scope. The language of the label depends on
    * the creator of the variable and thus, the creator of the environment or
    * the XQuery script writer.
    * 
    * @deprecated this operation shall no longer be used as far as the label
    *             will no longer be supported in further versions of the engine.
    * @return the label of the variable, if any or null otherwise.
    */
   public String getLabel()
   {
      return this.label;
   }

   /**
    * Clones the current instance. The instance is duplicated with the same
    * reference to the name, the sequence type and the value of the variable.
    * 
    * @return a reference to the duplicated variable.
    */
   public Object clone()
   {
      final ExternalVariable variable =
         new ExternalVariable(this.getQName(), this.getSequenceType(), this
               .getDefaultValue());

      variable.setValue(this.getValue());
      variable.setDefaultValue(this.getDefaultValue());
      // TODO:The following line should be removed will discarding the label
      // attribute
      variable.setLabel(this.label);

      return variable;
   }
}
