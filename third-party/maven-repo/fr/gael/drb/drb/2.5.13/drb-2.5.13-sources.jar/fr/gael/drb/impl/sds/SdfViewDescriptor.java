/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import java.util.ArrayList;
import java.util.Hashtable;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.value.Value;
import fr.gael.drb.xsd.XsdComplexType;
import fr.gael.drb.xsd.XsdElement;
import fr.gael.drb.xsd.XsdModelGroup;
import fr.gael.drb.xsd.XsdParticle;
import fr.gael.drb.xsd.XsdSimpleType;
import fr.gael.drb.xsd.XsdType;

/**
 * SdfViewDescriptor class.
 */
public class SdfViewDescriptor
{
   /**
    * Logger
    */
   private static Logger logger = Logger.getLogger(SdfViewDescriptor.class);

   /**
    * Namespace of this node.
    */
   public final static String NAMESPACE = "sdf";

   /**
    * Map identifier.
    */
   public final static String MAP_ID = "view";

   /**
    * Context target identifier.
    */
   public final static int CONTEXT_TARGET = 0;

   /**
    * Self target identifier.
    */
   public final static int SELF_TARGET = 1;

   /**
    * Parent node.
    */
   protected SdfViewDescriptor parent;

   /**
    * Base type
    */
   protected XsdType baseType;

   /**
    * Query that gives the context of the node map.
    */
   protected String query;

   /**
    * Target of the query (context or self).
    */
   protected int target = CONTEXT_TARGET;

   /**
    * ???
    */
   protected String valueQuery;

   /**
    * Name of this node
    */
   protected String name;

   /**
    * Value type.
    */
   protected int valueType = Value.NULL_ID;

   /**
    * Children.
    */
   protected ArrayList children = null;

   /**
    * Class constructor.
    * 
    * @param element schema of this map
    */
   public SdfViewDescriptor(final XsdElement element)
   {
      this(element, new Hashtable());
   }

   /**
    * Class constructor.
    * 
    * @param element schema of this map
    * @param element_hash ???
    */
   protected SdfViewDescriptor(final XsdElement element,
         final Hashtable element_hash)
   {
      element_hash.put(element, this);
      this.name = element.getName();
      this.query = this.name;
      this.valueQuery = ".";
      this.target = CONTEXT_TARGET;

      final DrbNodeList ext_children = element.getExternalNodes();
      // = node_desc.getExternalChildren();

      DrbNode map_node = null;

      // Search Map node
      if (ext_children != null)
      {
         for (int i = 0; i < ext_children.getLength(); i++)
         {
            final DrbNode ext_child = ext_children.item(i);
            if (ext_child != null)
            {
               final String ext_child_name = ext_child.getName();
               if ((ext_child_name != null) && ext_child_name.equals(MAP_ID))
               {
                  map_node = ext_child;
                  break;
               }
            }
         }
      }

      // Import Map node
      if (map_node != null)
      {
         final DrbNodeList map_children = map_node.getChildren();
         if (map_children != null)
         {
            // Search query and value nodes
            DrbNode query_node = null;
            DrbNode value_node = null;

            // Retreive base type
            final DrbAttribute base_attr = map_node.getAttribute("base");
            System.err.println("SdvViewDescriptor: baseAttr " + base_attr);
            if (base_attr != null)
            {
               final String base_type_name = base_attr.getValue().toString();
               this.baseType =
                  element.getType().getSchema().getType(base_type_name);
               System.err.println("SdvViewDescriptor: baseTypeAttr "
                     + this.baseType);
            }

            for (int i = 0; i < map_children.getLength(); i++)
            {
               final DrbNode map_child = map_children.item(i);
               if (map_child != null)
               {
                  final String map_child_name = map_child.getName();
                  if (map_child_name != null)
                  {
                     if (map_child_name.equals("query"))
                     {
                        query_node = map_child;
                     }
                     if (map_child_name.equals("value"))
                     {
                        value_node = map_child;
                     }
                  }
               }
            }

            if (query_node != null)
            {
               final Value query_value = query_node.getValue();
               if (query_value != null)
               {
                  this.query = query_value.toString();
               }
               else
               {
                  this.query = null;
               }
               // Find target attribute if any
               final DrbAttributeList query_attribs =
                  query_node.getAttributes();
               if (query_attribs != null)
               {
                  for (int j = 0; j < query_attribs.getLength(); j++)
                  {
                     final DrbAttribute attrib = query_attribs.item(j);
                     if ((attrib != null) && (attrib.getName() != null)
                           && (attrib.getValue() != null)
                           && (attrib.getName().equals("target")))
                     {
                        final Value target_value = attrib.getValue();
                        if ((target_value.toString() != null)
                              && (target_value.toString().equals("self")))
                        {
                           this.target = SELF_TARGET;
                        }
                     }
                  }
               }
            }

            if (value_node != null)
            {
               final Value value = value_node.getValue();
               if (value != null)
               {
                  this.valueQuery = value.toString();
               }
               else
               {
                  this.valueQuery = null;
               }
            }
         }
      }

      if (element.getType() != null)
      {

         // Import children
         final XsdComplexType complex_type = null; // element.getType().getStructure();
         final XsdSimpleType simple_type =
            complex_type == null ? null : complex_type.getDatatype();

         // if simple type, si;ply solution
         if (simple_type != null)
         {
            this.valueType = simple_type.getTypeId();
         }
         else if (complex_type == null)
         {
            this.valueType = Value.UNKNOWN_ID;
         }
         else
         {
            this.valueType = Value.NULL_ID;
         }
         if (complex_type == null)
         {
            return;
         }

         /*
          * where as complex type, we have to recupere child elements that this
          * element contains
          */
         this.children = new ArrayList();
         final XsdModelGroup model_group = complex_type.getComplexContent();

         for (int ichild = 0; ichild < model_group.getLength(); ichild++)
         {
            final XsdParticle particle = model_group.getParticle(ichild);
            if (particle instanceof XsdElement)
            {
               final XsdElement child = (XsdElement) particle;
               final Object map_child = element_hash.get(child);
               if (map_child != null)
               {
                  this.children.add(map_child);
               }
               else
               {
                  this.children.add(new SdfViewDescriptor(child, element_hash));
               }
            }
            else
            {
               logger.error("group inside group not supported");
            }

         }
      } // end if (element.getType() != null)
   }

   /**
    * Prints header.
    * 
    * @param header header to be printed.
    */
   public void print(final String header)
   {
      System.out.println(header + this.name);
      if (this.children != null)
      {
         for (int i = 0; i < this.children.size(); i++)
         {
            ((SdfViewDescriptor) this.children.get(i)).print(header + "   ");
         }
      }
   }
}
