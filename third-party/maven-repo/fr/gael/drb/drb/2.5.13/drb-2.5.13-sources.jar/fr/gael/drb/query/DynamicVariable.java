/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

/**
 * Variable binding an expression.
 */
class DynamicVariable extends DefaultVariable
{
   // TODO: Verify the correctness of the implementation of Variable
   /**
    * Bound expression.
    */
   private Expression expression;

   /**
    * Constructor of a dynamic variable with known evaluation result.
    * 
    * @param name string form of the variable qualified name.
    * @param sequence_type the type of the variable.
    * @param expression the expression to compute the value of the variable.
    */
   protected DynamicVariable(final QName name,
         final SequenceType sequence_type, final Expression expression)
   {
      super(name, sequence_type);

      // Check parameters
      if (expression == null)
      {
         throw new DynamicException(expression, "Variable \"" + name
               + "\" has no bounding expression");
      }
      this.expression = expression;
   }

   /**
    * Returns the expression defining the value of the variable.
    * 
    * @return the bound expression.
    */
   Expression getExpression()
   {
      return this.expression;
   }

   /**
    * Returns the value of the variable. The expression bounded by this variable
    * is evaluated. This order of preference for output sequence is: the value
    * if set, the result of the evaluation of the expression if any and then an
    * empty sequence.
    * 
    * @param context a dynamic context not considered in this implementation.
    */
   public void initialize(final DynamicContext context)
   {
      try
      {
         this.setValue(this.expression.evaluate(context));
      }
      catch (final ClassCastException e)
      {
         throw new TypeException(this.expression, e.getMessage());
      }
   }

   /**
    * Returns a description of the current instance. This operation overrides
    * the super class operation to print the expression in addition to the name
    * and the value of the variable.*
    * 
    * @return the description of the dynamic variable.
    */
   public String toString()
   {
      String output_string = "";

      output_string += super.toString();

      if (this.expression != null)
      {
         output_string += " (bound to \"" + this.expression + "\")";
      }

      return output_string;
   }

   /**
    * Clones the current instance. The instance is duplicated with the same
    * reference to the name, the sequence type and the value of the variable.
    * 
    * @return a reference to the duplicated variable.
    */
   public Object clone()
   {
      final DynamicVariable variable =
         new DynamicVariable(this.getQName(), this.getSequenceType(),
               this.expression);

      variable.setValue(this.getValue());

      return variable;
   }
}
