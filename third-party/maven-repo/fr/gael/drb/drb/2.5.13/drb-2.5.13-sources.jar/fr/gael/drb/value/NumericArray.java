/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * Numeric array value wrapper.
 */
public interface NumericArray extends ValueArray, Comparison
{

   /**
    * Returns this value as a boolean.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type byte.
    */
   boolean booleanValue(int index);

   /**
    * Returns this value as a byte (signed 8 bits). The conversion may result in
    * a loss of precision.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type byte.
    */
   byte byteValue(int index);

   /**
    * Returns this value as a short integer (signed 16 bits). The conversion may
    * result in a loss of precision.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type short.
    */
   short shortValue(int index);

   /**
    * Returns this value as an integer (signed 32 bits). The conversion may
    * result in a loss of precision.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type int.
    */
   int intValue(int index);

   /**
    * Returns this value as a long integer (signed 64 bits). The conversion may
    * result in a loss of precision.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type long.
    */
   long longValue(int index);

   /**
    * Returns this value as a float (signed 32 bits IEEE 754). The conversion
    * may result in a loss of precision.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type float.
    */
   float floatValue(int index);

   /**
    * Returns this value as a double (signed 64 bits IEEE 754). The conversion
    * may result in a loss of precision.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type double.
    */
   double doubleValue(int index);

   /**
    * Assign a boolean value.
    * 
    * @param index index of element to replace.
    * @param v another value.
    */
   void assign(int index, boolean v);

   /**
    * Assign a byte value.
    * 
    * @param index index of element to replace.
    * @param v another value. The conversion may result in a loss of precision.
    */
   void assign(int index, byte v);

   /**
    * Assign an int value.
    * 
    * @param index index of element to replace.
    * @param v another value. The conversion may result in a loss of precision.
    */
   void assign(int index, int v);

   /**
    * Assign a long value.
    * 
    * @param index index of element to replace.
    * @param v another value. The conversion may result in a loss of precision.
    */
   void assign(int index, long v);

   /**
    * Assign short value.
    * 
    * @param index index of element to replace.
    * @param v another value. The conversion may result in a loss of precision.
    */
   void assign(int index, short v);

   /**
    * Assign a float value.
    * 
    * @param index index of element to replace.
    * @param v another value. The conversion may result in a loss of precision.
    */
   void assign(int index, float v);

   /**
    * Assign a double value.
    * 
    * @param index index of element to replace.
    * @param v another value. The conversion may result in a loss of precision.
    */
   void assign(int index, double v);
}
