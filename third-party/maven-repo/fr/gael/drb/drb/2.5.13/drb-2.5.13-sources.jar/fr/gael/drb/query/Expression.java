/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbSequence;

/**
 * Query expression interface.
 */
interface Expression
{
   /**
    * Launch a dynamic evaluation of the expression with respect to a specific
    * dynamic context.
    * <p>
    * During the dynamic evaluation, a dynamic or a type exception may occur
    * interrupting the processing of the query. They significate that an
    * unrecoverable error has been encountered in an expression may be due to
    * unsatisfied conditions departing from the XQuery specifications.
    * </p>
    * Moreover, while a dynamic evaluation is operating, a call of cancel()
    * operation may request the immediate interruption of the processing. On the
    * evaluation stop, a CanceException
    * </p>
    * 
    * @param context the outer-focus of the evalutation.
    * @return the sequence resulting from the dynamic evaluation.
    * @throws DynamicException when an error occured.
    * @throws TypeException when a type error has been encoutered.
    * @throws CancelException when the evaluation has been interrupted.
    */
   public DrbSequence evaluate(DynamicContext context) throws DynamicException,
         TypeException, CancelException;

   /**
    * Request cancellation of potentially running dynamic evaluations.
    * 
    * @param reason a explicit message describing the origin or reason of the
    *           cancellation request. This reason will be reported in the
    *           message of the cancel exception. The reason shall complete the
    *           following sentence: "the call-off as been requested due to...".
    *           Therefore the first character shall not be capitalized (e.g. "a
    *           user", "a system alert").
    */
   public void cancel(String reason);

   /**
    * Returns the name of the expression. This operation is useful for
    * convenient printing.
    * 
    * @return the name of the expression.
    */
   public String getName();

   /**
    * Returns the token related to the current expression. As far as the
    * expression derives from a XQuery script, a token may be associated to it.
    * This token is useful for reporting relevant messages when a dynamic, type
    * or cancel exception is to be raised.
    * 
    * @return the token related to the expression or null otherwise.
    */
   public Token getToken();

   /**
    * An expression which is constant means that it need no context item to be
    * evaluate. The returned sequence from its evaluation will always be the
    * same along the query script
    * 
    * @return true if this expression is constant
    */
   public boolean isConstant();

   /**
    * Identifies expression that can modify the state of an existing node. An
    * updating expression is an expression that use the updating operations
    * provided by the "XQuery Update Facility" : insert, delete, replace, rename
    * and transform.
    * 
    * @return true if this expression performs updating operations and false
    *         otherwise
    */
   public boolean isUpdating();
} // Expression
