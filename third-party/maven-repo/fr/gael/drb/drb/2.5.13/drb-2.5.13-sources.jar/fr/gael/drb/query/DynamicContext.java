/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbItem;
import fr.gael.drb.value.DateTime;
import fr.gael.drb.xsd.Namespace;

/**
 * Context during the dynamic evaluation phase of an XQuery.
 * <p>
 * The <b>dynamic context</b> of an expression is defined as information that
 * is available at the time the expression is evaluated. If evaluation of an
 * expression relies on some part of the dynamic context that has not been
 * assigned a value, a dynamic error is raised.
 * </p>
 * <p>
 * The individual components of the dynamic context are summarized in the XQuery
 * specifications <a href="http://www.w3.org/TR/xquery">
 * http://www.w3.org/TR/xquery</a>
 * </p>
 * <p>
 * A special attention has been paid in this class to inherit from the
 * vocabulary of the XQuery specifications. It is therefore strongly encouraged
 * to refer to the XQuery specificatios regarding to static contexts for a
 * complete definition of its role during the dynamic evalutation phase.
 * </p>
 */
class DynamicContext extends StaticContext
{
   /**
    * Inner-class gathering the focus sizes.
    */
   static class Size
   {
      /**
       * The size.
       */
      protected int size = 1;

      /**
       * Builds a Size with all parameters. For performance reasons, the
       * operation does not perform any integrity control before asigning the
       * values provided in argument.
       */
      public Size()
      {
         this.size = 0;
      }

      /**
       * Builds a Size with all parameters. For performance reasons, the
       * operation does not perform any integrity control before asigning the
       * values provided in argument.
       * 
       * @param size the context size.
       */
      public Size(final int size)
      {
         this.size = size;
      }

      /**
       * Returns the current size.
       * 
       * @return the current size.
       */
      protected int getSize()
      {
         return this.size;
      }
   }

   /**
    * Inner-class gathering the focus informations. As defined by the W3C, the
    * focus enables the processor to keep track of which nodes are being
    * processed by the expression. It embed the context item, context position,
    * context size.
    */
   class Focus
   {
      /**
       * The context item. The context item is the item currently being
       * processed in a path expression. An item is either an atomic value or a
       * node. When the context item is a node, it can also be referred to as
       * the context node. The context item is returned by the expression ".".
       * When an expression E1/E2 or E1[E2] is evaluated, each item in the
       * sequence obtained by evaluating E1 becomes the context item in the
       * inner focus for an evaluation of E2.
       */
      private DrbItem contextItem = null;

      /**
       * The context positiion. The context position is the position of the
       * context item within the sequence of items currently being processed in
       * a path expression. It changes whenever the context item changes. Its
       * value is always an integer greater than zero. The context position is
       * returned by the expression fn:position(). When an expression E1/E2 or
       * E1[E2] is evaluated, the context position in the inner focus for an
       * evaluation of E2 is the position of the context item in the sequence
       * obtained by evaluating E1. The position of the first item in a sequence
       * is always 1 (one). The context position is always less than or equal to
       * the context size.
       */
      private int contextPosition = 1;

      /**
       * The context size. The context size is the number of items in the
       * sequence of items currently being processed in a path expression. Its
       * value is always an integer greater than zero. The context size is
       * returned by the expression fn:last(). When an expression E1/E2 or
       * E1[E2] is evaluated, the context size in the inner focus for an
       * evaluation of E2 is the number of items in the sequence obtained by
       * evaluating E1.
       */
      private Size contextSize = new Size(1);

      /**
       * Builds a default focus. IT this case, the reference to the context item
       * is null, the position and the size are defaulted to 1.
       */
      public Focus()
      {
         this.contextItem = null;
         this.contextPosition = 1;
         this.contextSize = new Size(1);
      }

      /**
       * Builds a focus whit all parameters. For performance reasons, the
       * operation does not perform any integrity control before asigning the
       * values provided in argument.
       * 
       * @param item the context item of the focus.
       * @param position the intilial position in the context sequence.
       * @param size the context size.
       */
      public Focus(final DrbItem item, final int position, final int size)
      {
         this.contextItem = item;
         this.contextPosition = position;
         this.contextSize = new Size(size);
      }

      /**
       * Builds a focus from another one. This operation is useful to make an
       * inner-focus becoming an outer-focus and vice versa. For performance
       * reasons, the operation does not perform any integrity control before
       * asigning the values provided in argument.
       * 
       * @param focus the focus to inherit from.
       */
      public Focus(final Focus focus)
      {
         this.contextItem = focus.contextItem;
         this.contextPosition = focus.contextPosition;
         this.contextSize = focus.contextSize;
      }

      /**
       * Set context item of the focus. Any former context item will be discred
       * by this operation. For performance reasons, the operation does not
       * perform any integrity control before asigning the values provided in
       * argument.
       * 
       * @param item the new context item.
       */
      public void setContextItem(final DrbItem item)
      {
         this.contextItem = item;
      }

      /**
       * Get current context item. If the current focus does not refer to any
       * context item, the returned value may be null.
       * 
       * @return the latter context item.
       */
      public DrbItem getContextItem()
      {
         return this.contextItem;
      }

      /**
       * Set current position in the context. For performance reasons, the
       * operation does not perform any integrity control before asigning the
       * values provided in argument.
       * 
       * @param position new position to be considered.
       */
      public void setContextPosition(final int position)
      {
         this.contextPosition = position;
      }

      /**
       * Increment the position of 1.
       * 
       * @return the new position.
       */
      public int nextContextPosition()
      {
         this.contextPosition += 1;

         return this.contextPosition;
      }

      /**
       * Returns the current context position.
       * 
       * @return the current context position.
       */
      public int getContextPosition()
      {
         return this.contextPosition;
      }

      /**
       * Set the context size. For performance reasons, the operation does not
       * perform any integrity control before asigning the values provided in
       * argument.
       * 
       * @param size the neww context size to consider.
       */
      public void setContextSize(final int size)
      {
         this.contextSize = new Size(size);
      }

      /**
       * Set the context size. For performance reasons, the operation does not
       * perform any integrity control before asigning the values provided in
       * argument.
       * 
       * @param size the neww context size to consider.
       */
      public void setContextSize(final Size size)
      {
         this.contextSize = size;
      }

      /**
       * Returns the current context size.
       * 
       * @return the size of the current context.
       */
      public int getContextSize()
      {
         return this.contextSize.getSize();
      }
   }

   /**
    * Current focus. This field may be accessed directly by other classes of the
    * package. The operations of the present class are caring to assure that a
    * focus is always referenced by this attribute so its acessor may be called.
    */
   protected Focus focus = new Focus();

   /**
    * Current dateTime. This information represents an implementation-dependent
    * point in time during the processing of a query, and includes an explicit
    * timezone. It can be retrieved by the the fn:current-dateTime function. If
    * invoked multiple times during the execution of a query, this function
    * always return the same result.
    */
   protected DateTime currentDateTime = new DateTime();

   /**
    * In Scope Namespace of an element Sub-elements will use this object to know
    * if they have to store a namespace inside their declared namespace; if they
    * do so, they also update this set for its children to know that this
    * namespace is already bind. So they wont have to store it inside their own
    * declared namespace.
    */
   public Namespace elementNamespace = new Namespace();

   /**
    * Builds a dynamic context from a static context.
    * <p>
    * The principle of the initialisation of a dynamic context from an static
    * context is to clone it and in particular its external references but
    * without duplicating the referenced elements. As an example, the list of
    * namespaces is duplicated but the namespaces it refer to are not.
    * Therefore, the lists are independent and the dynamic context may augment
    * the list without modifying the originating static context. However, the
    * caller shall be careful while modifying the referenced elements. This may
    * alter the active or further processing of an XQuery.
    * </p>
    * <p>
    * The reference to the static context shall not be null.
    * </p>
    * 
    * @param context the static context to be considered as reference.
    */
   public DynamicContext(final StaticContext context)
   {
      /**
       * Re-use the constructor of the static context to duplicate the common
       * part.
       */
      super(context);
   }

   /**
    * Builds a context from another static context.
    * <p>
    * This constructor is mainly dedicated to derivate a new scope of context.
    * It performs the same tasks as the constructor from an environment. In
    * addition it duplicates the list of in-scope variable to avoid further
    * alteration of the out-scope ones.
    * </p>
    * <p>
    * The reference to the context shall not be null.
    * </p>
    * 
    * @param context the out-scope context to derivate.
    */
   public DynamicContext(final DynamicContext context)
   {
      this((StaticContext) context);

      this.focus = new Focus(context.focus);
      // Set the current dateTime. It shall remains the same through all the
      // query
      this.currentDateTime = context.currentDateTime;

      this.elementNamespace = context.elementNamespace.cloneNamespace();
   }
}
