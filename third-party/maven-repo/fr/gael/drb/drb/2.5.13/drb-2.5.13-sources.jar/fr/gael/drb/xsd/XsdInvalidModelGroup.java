/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbNodeList;

/**
 * Output of the XML-Schema ModelGroup validator.
 */
class XsdInvalidModelGroup extends XsdInvalidParticle
{

   /**
    * Index of the last particle in the model group
    */
   int stopParticle;

   /**
    * Build an XsdInvalidModelGroup
    * 
    * @param node_list the list nodes
    * @param model_group the model group
    * @param start_index the begining of thelist
    * @param stop_index the end of the list
    * @param stop_particle the end partiche
    */
   XsdInvalidModelGroup(final DrbNodeList node_list,
         final XsdModelGroup model_group, final int start_index,
         final int stop_index, final int stop_particle)
   {
      super(node_list, model_group, start_index, stop_index);
      this.stopParticle = stop_particle;
   } // XsdInvalidModelGroup

   /**
    * Set the index (+1) of the last particle in the model group.
    * 
    * @param stop_particle the index (+1) of the last particle in the model
    *           group.
    */
   void setStopParticle(final int stop_particle)
   {
      this.stopParticle = stop_particle;
   } // setStopParticle

   /**
    * Returns a message describing the validation result.
    * 
    * @return a message describing the validation result
    */
   public String getMessage()
   {
      String msg = "";
      if ((this.nodeList == null)
            || (this.stopIndex >= this.nodeList.getLength()))
      {
         msg = "Missing child at index " + this.stopIndex;
      }
      else
      {
         msg =
            "Unexpected child '" + this.nodeList.item(this.stopIndex).getName()
                  + "' found at index " + this.stopIndex;
         final XsdModelGroup modelGroup = (XsdModelGroup) this.particle;
         XsdElement element = null;
         if ((this.stopParticle < modelGroup.getContent().length)
               && (modelGroup.getContent()[this.stopParticle] instanceof XsdElement))
         {
            element = (XsdElement) modelGroup.getContent()[this.stopParticle];
            if ((element.getName() != null)
                  && element.getName().equals(
                        this.nodeList.item(this.stopIndex).getName()))
            {
               if (element.getMinOccurs() == element.getMaxOccurs())
               {
                  msg =
                     msg + ". Its occurrence shall be equal to "
                           + element.getMinOccurs();
               }
               else
               {
                  msg =
                     msg + ". Its occurrence shall be greater than "
                           + element.getMinOccurs();
                  if (element.getMaxOccurs() != XsdParticle.UNBOUNDED_OCCURS)
                  {
                     msg = msg + " and lower than " + element.getMaxOccurs();
                  }
               }
            }
            else
            {
               msg =
                  msg + ". The correct element should be " + element.getName();
            }
         }
      }

      /*
       * + " context : \" "; for (int i=stopIndex - 1; i<stopIndex + 1; i++) {
       * if (i == stopIndex) msg = msg + "^"; if ((nodeList != null) && (i >= 0) &&
       * (i < nodeList.getLength())) { msg = msg + nodeList.item(i).getName() + " "; } }
       * msg = msg + "\"";
       */
      return msg;
   } // getMessage

} // XsdInvalidModelGroup
