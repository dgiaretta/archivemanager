/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;

/**
 * Declaration of the XML-Schema element wildcard.
 */
public class XsdAny extends XsdParticle implements NodeValidator
{

   // =======================================================================
   // Static part.
   // =======================================================================
   /**
    * any attribute tag.
    */
   final static String TAG = "any";

   // =========================================================================
   // Methods part.
   // =========================================================================
   /**
    * Build an XML-Schema any element.
    * 
    * @param min_occurs The minumum occurence
    * @param max_occurs The maximum occurence
    * @param wildcard XsdWildcard
    */
   XsdAny(final int min_occurs, final int max_occurs, final XsdWildcard wildcard)
   {
      super(min_occurs, max_occurs);
   } // XsdAny

   // ------------------------------------------------------------------------
   // XsdComponent class overloading
   // ------------------------------------------------------------------------
   /**
    * Format this component into a string.
    * 
    * @return DrbNode
    */
   DrbNode toNode()
   {
      return null;
   } // toNode

   // -------------------------------------------------------------------------
   // XsdParticle class overloading
   // -------------------------------------------------------------------------
   /**
    * Returns the term attribute.
    * 
    * @return int
    */
   public final int getTerm()
   {
      return XsdParticle.WILDCARD_TERM;
   } // getTerm

   // -------------------------------------------------------------------------
   // NodeValidator interface implementation
   // -------------------------------------------------------------------------
   /**
    * Validates this node.
    * 
    * @param node The node
    * @return XsdInvalid
    */
   public XsdInvalid isValid(final DrbNode node)
   {
      final DrbDefaultNodeList nodeList = new DrbDefaultNodeList();
      final XsdInvalidParticle invalid =
         new XsdInvalidParticle(nodeList, this, 0, 0);
      if (node == null)
      {
         return (this.getMinOccurs() == 0) ? null : invalid;
      }
      return null;
   } // isValid

   // ------------------------------------------------------------------------
   // NodeListValidator interface implementation
   // ------------------------------------------------------------------------
   /**
    * Validates this node list.
    * 
    * @param node_list The node list
    * @return XsdInvalid
    */
   public XsdInvalid isValid(DrbNodeList node_list)
   {
      final XsdInvalidParticle invalid =
         new XsdInvalidParticle(node_list, this, 0, 0);
      // Node list must not be null
      if (node_list == null)
      {
         node_list = new DrbDefaultNodeList();
      }
      if (this.search(node_list, 0) == node_list.getLength())
      {
         return null;
      }
      return invalid;
   } // isValid

   /**
    * Search a pattern in the list.
    * 
    * @param node_list The node list
    * @param start The beginning of the list
    * @return -1 if it had not been found or the position
    */
   public int search(final DrbNodeList node_list, final int start)
   {
      return this.search(node_list, start, new XsdInvalidParticle(node_list,
            this, start, start));
   } // search

   /**
    * Search a pattern in the list.
    * 
    * @param node_list The node list
    * @param start The beginning of the list
    * @param invalid XsdInvalidParticle
    * @return -1 if it had not been found or the position
    */
   int search(DrbNodeList node_list, final int start,
         final XsdInvalidParticle invalid)
   {
      if (node_list == null)
      {
         node_list = new DrbDefaultNodeList();
      }

      if ((start < 0) || (start > node_list.getLength()))
      {
         return -1;
      }

      // Validate each node
      int occurs = 0;
      for (int i = start; i < node_list.getLength(); i++)
      {
         final DrbNode node = node_list.item(i);
         if (node == null)
         {
            return -1;
         }
         // Check namespace constraint
         // TBC

         // Check occurrence
         // if (occurs == getMaxOccurs())
         // break;
         occurs++;
      }
      invalid.setStopIndex(start + occurs);
      if (occurs < this.getMinOccurs())
      {
         return -1;
      }
      if (occurs > this.getMaxOccurs())
      {
         return -1;
      }

      return start + occurs;
   } // search

   // ================================================================
   // Unitary test part.
   // ================================================================
   /**
    * Makes this class runnable for testing.
    * 
    * @param args String[]
    */
   public static void main(final String[] args)
   {
   } // main

} // XsdAny
