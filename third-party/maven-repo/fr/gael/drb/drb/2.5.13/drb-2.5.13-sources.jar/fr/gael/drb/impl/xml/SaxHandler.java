/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.xml;

import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.ext.LexicalHandler;
import org.xml.sax.helpers.DefaultHandler;

import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.xsd.Namespace;

/**
 * SAX node handler. This implementation uses the SAX parser to comply the
 * DrbNode interface. It allows to browse the XML documents with the Data
 * Request Broker API.
 */
class SaxHandler extends DefaultHandler implements LexicalHandler
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(SaxHandler.class);

   /**
    * Locator.
    */
   private Locator locator;

   /**
    * The node to initialize.
    */
   private SaxNode node;

   /**
    * The current depth.
    */
   private int depth;

   /**
    * The match depth.
    */
   private int matchDepth;

   /**
    * The character data.
    */
   StringBuffer buffer = new StringBuffer();

   /**
    * The input stream.
    */
   protected SaxInputStream stream;

   /**
    * The current offset.
    */
   private long lexicalOffset;

   /**
    * The current node under processing.
    */
   private SaxNode currentNode;

   /**
    * Constructor.
    * 
    * @param node the input node
    * @param stream the input stream
    */
   protected SaxHandler(final SaxNode node, final SaxInputStream stream)
   {
      this.currentNode = node;
      this.node = node;
      this.stream = stream;
      // this.depth = node.depth - 1;
      this.depth = -1;
      this.matchDepth = this.depth;
      this.lexicalOffset = 0;

      logger.debug("Loading " + node.getName() + " at index " + node.getIndex()
            + " start_offset=" + node.tag.startOffset + ", end_offset="
            + node.tag.endOffset);
   }

   /**
    * Receive an object for locating the origin of SAX document events.
    * 
    * @param locator An object that can return the location of any SAX document
    *           event.
    */
   public void setDocumentLocator(final Locator locator)
   {
      this.locator = locator;
   }

   /**
    * Receive notification of character data. The Parser will call this method
    * to report each chunk of character data. SAX parsers may return all
    * contiguous character data in a single chunk, or they may split it into
    * several chunks; however, all of the characters in any single event must
    * come from the same external entity so that the Locator provides useful
    * information. The application must not attempt to read from the array
    * outside of the specified range. Note that some parsers will report
    * whitespace in element content using the ignorableWhitespace method rather
    * than this one (validating parsers must do so).
    * 
    * @param ch The characters from the XML document.
    * @param start The start position in the array.
    * @param length The number of characters to read from the array.
    * @throws SAXException The number of characters to read from the array.
    */
   public void characters(final char[] ch, final int start, final int length)
         throws SAXException
   {
      this.lexicalOffset =
         this.stream.getOffset(this.locator.getLineNumber(), this.locator
               .getColumnNumber() - 1) + 1;
      if (this.matchDepth == this.currentNode.depth)
      {
         int whitespace_count = 0;
         // Remove leading whitespace
         if (this.buffer.length() == 0)
         {
            while ((whitespace_count < length)
                  && ((ch[start + whitespace_count] == ' ')
                        || (ch[start + whitespace_count] == '\t') || (ch[start
                        + whitespace_count] == '\n')))
            {
               whitespace_count++;
            }
         }
         this.buffer.append(ch, start + whitespace_count, length
               - whitespace_count);
         this.currentNode.tag.startCloseOffset = this.lexicalOffset;
      }
      // Print offset
      /*
       * logger.debug(new String(ch, start, length) + "{" + lexicalOffset + "(" +
       * locator.getLineNumber() + "," + locator.getColumnNumber() + ")" + "}");
       */
   }

   /**
    * Receive notification of character data. The Parser will call this method
    * to report each chunk of character data. SAX parsers may return all
    * contiguous character data in a single chunk, or they may split it into
    * several chunks; however, all of the characters in any single event must
    * come from the same external entity so that the Locator provides useful
    * information. The application must not attempt to read from the array
    * outside of the specified range. Note that some parsers will report
    * whitespace in element content using the ignorableWhitespace method rather
    * than this one (validating parsers must do so).
    * 
    * @param ch The characters from the XML document.
    * @param start The start position in the array.
    * @param length The number of characters to read from the array.
    * @throws SAXException The number of characters to read from the array.
    */
   public void ignorableWhitespace(final char[] ch, final int start,
         final int length) throws SAXException
   {
      this.characters(ch, start, length);
   }

   /**
    * Receive notification of the beginning of an element.
    * 
    * @param namespaceURI The Namespace URI, or the empty string if the element
    *           has no Namespace URI or if Namespace processing is not being
    *           performed.
    * @param localName The local name (without prefix), or the empty string if
    *           Namespace processing is not being performed.
    * @param qName The qualified name (with prefix), or the empty string if
    *           qualified names are not available.
    * @param atts The attributes attached to the element. If there are no
    *           attributes, it shall be an empty Attributes object.
    */
   public void startElement(final String namespaceURI, final String localName, // local
         // name
         final String qName, // qualified name
         final Attributes atts)
   {
      /*
       * logger.debug("<" + localName+ ">" + "{" + (stream.getOffset(
       * locator.getLineNumber(), locator.getColumnNumber()-1)+1) + "(" +
       * locator.getLineNumber() + "," + locator.getColumnNumber() + ")" + "}");
       */
      this.depth = this.depth + 1;
      this.matchDepth = this.depth;

      /**
       * Case of child elements.
       */
      if (this.matchDepth == this.currentNode.depth + 1)
      {
         // Update tag property
         final SaxElementTag child_tag = new SaxElementTag();
         child_tag.index = this.currentNode.tag.childrenCount;
         child_tag.name = localName;
         child_tag.namespaceURI = namespaceURI;
         child_tag.startOffset = this.lexicalOffset;
         child_tag.endOpenOffset =
            this.stream.getOffset(this.locator.getLineNumber(), this.locator
                  .getColumnNumber() - 1) + 1;
         child_tag.childrenCount = 0;

         this.currentNode.children.add(child_tag);
         this.currentNode.tag.childrenCount++;

         // Create new child
         this.currentNode = new SaxNode(this.currentNode, child_tag.index);
      }
      // else
      /**
       * Case of target element.
       */
      if (this.matchDepth == this.currentNode.depth)
      {
         this.buffer = new StringBuffer();

         // Set element properties
         this.currentNode.tag.name = localName;
         if (!namespaceURI.equals(""))
         {
            this.currentNode.tag.namespaceURI = namespaceURI;
         }
         if (this.currentNode.depth == 0)
         {
            this.currentNode.tag.startOffset = this.lexicalOffset;
         }

         this.currentNode.tag.endOpenOffset =
            this.stream.getOffset(this.locator.getLineNumber(), this.locator
                  .getColumnNumber() - 1) + 1;
         this.currentNode.tag.startCloseOffset = this.lexicalOffset + 1;
         this.currentNode.tag.childrenCount = 0;
         this.currentNode.children = new java.util.ArrayList();
         // Set attributes and namespace declaration
         final DrbDefaultAttributeList attribs = new DrbDefaultAttributeList();
         final Namespace namespace = new Namespace();

         for (int iattr = 0; iattr < atts.getLength(); iattr++)
         {
            // Case of namespace declaration
            if (atts.getQName(iattr).startsWith("xmlns:"))
            {
               final String ns_prefix = Namespace.toLocal(atts.getQName(iattr));
               namespace.bind(ns_prefix, atts.getValue(iattr));
            }
            else
            // default namespace URI
            if (atts.getQName(iattr).equals("xmlns"))
            {
               namespace.setDefaultNamespaceURI(atts.getValue(iattr));
            }
            // Case of other attribute
            else
            {
               final DrbDefaultAttribute attr =
                  new DrbDefaultAttribute(atts.getLocalName(iattr),
                        new fr.gael.drb.value.String(atts.getValue(iattr)),
                        this.currentNode);
               if (!"".equals(atts.getURI(iattr)))
               {
                  attr.setNamespaceURI(atts.getURI(iattr));
               }
               attribs.add(attr);
            }
         }
         this.currentNode.attributes = attribs;
         this.currentNode.namespace = namespace;
      }
      this.lexicalOffset =
         this.stream.getOffset(this.locator.getLineNumber(), this.locator
               .getColumnNumber() - 1) + 1;
   }

   /**
    * Receive notification of the end of an element.
    * 
    * @param namespaceURI The Namespace URI, or the empty string if the element
    *           has no Namespace URI or if Namespace processing is not being
    *           performed.
    * @param localName The local name (without prefix), or the empty string if
    *           Namespace processing is not being performed.
    * @param qName The qualified XML 1.0 name (with prefix), or the empty string
    *           if qualified names are not available.
    */
   public void endElement(final java.lang.String namespaceURI,
         final java.lang.String localName, final java.lang.String qName)
         throws SAXException
   {
      /**
       * Case of target element.
       */
      if (this.matchDepth == this.currentNode.depth)
      {
         final String text = this.buffer.toString().trim(); // TBC: whitespace
         // handling
         if (text.length() > 0)
         {
            this.currentNode.value = new fr.gael.drb.value.String(text);
         }
         else
         {
            this.currentNode.value = null;
         }
         this.currentNode.tag.endOffset =
            this.stream.getOffset(this.locator.getLineNumber(), this.locator
                  .getColumnNumber() - 1) + 1;
         this.currentNode.loaded = true;

         if (this.currentNode.tag.endOffset - this.currentNode.tag.endOffset < 10000)
         {
            this.currentNode.tag.setNodeReference(this.currentNode, true);
         }
         else
         {
            this.currentNode.tag.setNodeReference(this.currentNode, false);
         }
         // Go to parent node
         if (this.currentNode.depth > this.node.depth)
         {
            this.currentNode = this.currentNode.parent;
         }
      }
      // else
      /**
       * Case of child element.
       */
      if (this.matchDepth == this.currentNode.depth + 1)
      {
         final SaxElementTag child_tag =
            this.currentNode.getTagAt(this.currentNode.tag.childrenCount - 1);
         child_tag.endOffset =
            this.stream.getOffset(this.locator.getLineNumber(), this.locator
                  .getColumnNumber() - 1) + 1;
         this.currentNode.tag.startCloseOffset = child_tag.endOffset;
         this.buffer = new StringBuffer();
      }
      else
      /**
       * Case of descendant (L2) element.
       */
      if (this.matchDepth == this.currentNode.depth + 2)
      {
         final SaxElementTag child_tag =
            this.currentNode.getTagAt(this.currentNode.tag.childrenCount - 1);
         child_tag.childrenCount++;
      }

      this.depth = this.depth - 1;
      this.matchDepth = this.depth;
      this.lexicalOffset =
         this.stream.getOffset(this.locator.getLineNumber(), this.locator
               .getColumnNumber() - 1) + 1;
      /*
       * logger.debug("</" + localName+ ">" + "{" + (stream.getOffset(
       * locator.getLineNumber(), locator.getColumnNumber()-1)+1) + "(" +
       * locator.getLineNumber() + "," + locator.getColumnNumber() + ")" + "}");
       */
   }

   /**
    * Receive notification of a processing instruction. The Parser will invoke
    * this method once for each processing instruction found: note that
    * processing instructions may occur before or after the main document
    * element. A SAX parser must never report an XML declaration (XML 1.0,
    * section 2.8) or a text declaration (XML 1.0, section 4.3.1) using this
    * method.
    * 
    * @param target The processing instruction target.
    * @param data The processing instruction data, or null if none was supplied.
    *           The data does not include any whitespace separating it from the
    *           target.
    * @throws SAXException Any SAX exception, possibly wrapping another
    *            exception.
    */
   public void processingInstruction(final String target, final String data)
         throws SAXException
   {
      // logger.debug("<? " + target + " " + data + ">");
      this.lexicalOffset =
         this.stream.getOffset(this.locator.getLineNumber(), this.locator
               .getColumnNumber() - 1) + 1;
   }

   /**
    * Receive notification of the beginning of a document. The SAX parser will
    * invoke this method only once, before any other methods in this interface
    * or in DTDHandler (except for setDocumentLocator
    */
   public void startDocument() throws SAXException
   {
      // do nothing
   }

   /**
    * Receive notification of the end of a document. The SAX parser will invoke
    * this method only once, and it will be the last method invoked during the
    * parse. The parser shall not invoke this method until it has either
    * abandoned parsing (because of an unrecoverable error) or reached the end
    * of input.
    */
   public void endDocument() throws SAXException
   {
      // do nothing
      logger.debug("End Document " + this.node.getName() + " at index "
            + this.node.getIndex() + " loaded=" + this.node.loaded
            + " childrenCount=" + this.node.tag.childrenCount
            + " start_offset=" + this.node.tag.startOffset + ", end_offset="
            + this.node.tag.endOffset + ", value='" + this.node.value + "'");

   }

   // Lexical Handler
   /**
    * Report an XML comment anywhere in the document.
    */
   public void comment(final char[] ch, final int start, final int length)
   {
      this.lexicalOffset =
         this.stream.getOffset(this.locator.getLineNumber(), this.locator
               .getColumnNumber() - 1) + 1;
      // logger.debug("<!--" + new String(ch, start, length)+ "-->" +
      // "{" + lexicalOffset + "}");
   }

   /**
    * Report the end of a CDATA section.
    */
   public void endCDATA()
   {
      this.lexicalOffset =
         this.stream.getOffset(this.locator.getLineNumber(), this.locator
               .getColumnNumber() - 1) + 1;
      // logger.debug("]]>" +
      // "{" + lexicalOffset + "}");
   }

   /**
    * Report the end of DTD declarations.
    */
   public void endDTD()
   {
   }

   /**
    * Report the end of an entity.
    */
   public void endEntity(final String name)
   {
   }

   /**
    * Report the start of a CDATA section.
    */
   public void startCDATA()
   {
      this.lexicalOffset =
         this.stream.getOffset(this.locator.getLineNumber(), this.locator
               .getColumnNumber() - 1) + 1;
      // logger.debug("<![CDATA[" +
      // "{" + lexicalOffset + "}");
   }

   /**
    * Report the start of DTD declarations, if any.
    */
   public void startDTD(final String name, final String publicId,
         final String systemId)
   {
   }

   /**
    * Report the beginning of some internal and external XML entities.
    */
   public void startEntity(final String name)
   {
   }
}
