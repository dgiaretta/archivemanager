/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import org.apache.log4j.Logger;

import fr.gael.drb.value.AbstractValueArray;
import fr.gael.drb.value.Value;

/**
 * Wraps a Literal expression result of XQuery language. A Literal expression is
 * a constant, either numeric or string.
 */
final class LiteralResult extends AbstractValueArray
{
   /**
    * Logger
    */
   final static private Logger logger = Logger.getLogger(LiteralResult.class);

   /**
    * Encapsulates the number 0.
    */
   final static LiteralResult ZERO =
      new LiteralResult(new fr.gael.drb.value.Int(0));

   /**
    * Encapsulates the number 1.
    */
   final static LiteralResult ONE =
      new LiteralResult(new fr.gael.drb.value.Int(1));

   /**
    * Encapsulates the empty string.
    */
   final static LiteralResult EMPTY_STRING =
      new LiteralResult(new fr.gael.drb.value.String(""));

   /**
    * Encapsulates the fn:true() result sequence.
    */
   final static LiteralResult TRUE =
      new LiteralResult(new fr.gael.drb.value.Boolean(true));

   /**
    * Encapsulates the fn:false() result sequence.
    */
   final static LiteralResult FALSE =
      new LiteralResult(new fr.gael.drb.value.Boolean(false));

   /**
    * The literal value.
    */
   private Value value;

   /**
    * Constructor of the literal result.
    * 
    * @param value the value of the literal.
    */
   LiteralResult(final Value value)
   {
      this.value = value;
   } // LiteralResult

   /**
    * Returns a string describing the range.
    * 
    * @return the description of the range.
    */
   public String toString()
   {
      return this.value.toString();
   }

   /**
    * The number of values in the literal result. The sequence is empty if the
    * range bounds are in reverse order; otherwise, the number of item is
    * computed as maximum - minimum + 1.
    * 
    * @return always 1, since a literal result is atomic.
    */
   public final int length()
   {
      return 1;
   } // length

   /**
    * Returns the LongArray priority
    * 
    * @return the LongArray priority
    */
   public final int getPriority()
   {
      return this.value.getPriority();
   }

   /**
    * Returns the Array type
    * 
    * @return the array type as an int (LONG_ID)
    */
   public final int getArrayType()
   {
      return this.value.getType();
   } // getArrayType

   /**
    * Return the specified item in the range sequence
    */
   public final Value getElement(final int indice)
   {
      if (indice == 0)
      {
         return this.value;
      }
      else
      {
         throw new IllegalArgumentException("Index is out of bounds");
      }
   }

   /**
    * Assign a value to an index This method always throw an
    * UnsupportedOperationException
    * 
    * @param index position where to insert the value.
    * @param element value to assign.
    */
   public final void assign(final int index, final Value element)
   {
      throw new UnsupportedOperationException("Literal values are not mutable");
   } // assign

   /**
    * Assign a new Value. This method always throw an
    * UnsupportedOperationException
    * 
    * @param v the value to be assigned.
    * @throws ClassCastException an exception
    */
   public final void assign(final Value v) throws ClassCastException
   {
      throw new UnsupportedOperationException("Literal values are not mutable");
   }
} // LiteralResult
