/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.file;

import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.value.Binary;
import fr.gael.drb.value.Value;

/**
 * This class represents a file value.
 */
class FileValue extends Binary
{
   /**
    * Node wrapped by the currence value. This attribute is used to access the
    * input stream of the wrapped file.
    */
   private DrbNodeImpl fileNode;

   /**
    * Builds a FileValue instance. This contructors sets the provided file. This
    * implementation does not check if the provided parameter is a null
    * reference. In such case, the implementation may become instable without
    * warning.
    * 
    * @param file The file to be wrapped.
    */
   FileValue(final DrbNodeImpl file_node)
   {
      this.fileNode = file_node;
   }

   /**
    * Get an input stream.
    * 
    * @return an input stream.
    */
   public java.io.InputStream getInput()
   {
      return (java.io.InputStream) this.fileNode
            .getImpl(java.io.InputStream.class);
   }

   /**
    * Assign a new Value. An implicit conversion may be performed to make the
    * assignment. This assignment may result in a loss of precision (ex : float
    * to int).
    * 
    * @param v the value to be assigned.
    */
   public void assign(final Value v)
   {
   }
}
