/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbSequence;

/**
 * Wraps an If expression of XQuery language. The if expression implement the
 * IF/THEN/ELSE conditional expression of the XQuery language. This expression
 * matches :
 * <p>
 * <code>
 * IfExpr ::= (<"if" "("> Expr ")" "then" Expr "else")* InstanceofExpr
 * </code>
 * </p>
 * <p>
 * The expression following the if keyword is called the test expression, and
 * the expressions following the then and else keywords are called the
 * then-expression and else-expression, respectively.
 * </p>
 * <p>
 * The first step in processing a conditional expression is to find the
 * effective boolean value of the test expression.
 * </p>
 * The value of a conditional expression is defined as follows: If the effective
 * boolean value of the test expression is true, the value of the
 * then-expression is returned. If the effective boolean value of the test
 * expression is false, the value of the else-expression is returned.
 * </p>
 * <p>
 * Conditional expressions have a special rule for propagating dynamic errors.
 * If the effective value of the test expression is true, the conditional
 * expression ignores (does not raise) any dynamic errors encountered in the
 * else-expression. In this case, since the else-expression can have no
 * observable effect, it need not be evaluated. Similarly, if the effective
 * value of the test expression is false, the conditional expression ignores any
 * dynamic errors encountered in the then-expression, and the then-expression
 * need not be evaluated.
 * </p>
 */
class IfExpression extends AbstractExpression
{
   /**
    * Logger.
    */
   Logger logger = Logger.getLogger(IfExpression.class);

   /**
    * The test expression. The test expression cannot be null. The evaluation of
    * this exression provides the effective boolen value of the conditional
    * expression.
    */
   private Expression testExpression = null;

   /**
    * The then expression. This expression cannot be null and if is evaluted if
    * the effective boolean value is true.
    */
   private Expression thenExpression = null;

   /**
    * The else expression. This expression cannot be null and if is evaluted if
    * the effective boolean value is false.
    */
   private Expression elseExpression = null;

   /**
    * Builds an instance of the IfExpression. The underlying expression (i.e.
    * test, then and else) are reset to null.
    * 
    * @param token the token related to the current expression.
    */
   public IfExpression(final Token token)
   {
      super("If", token);
   }

   /**
    * Accessor to the test expression. The parameter is not tested and the
    * reference is immediately assigned to the test expression.
    * 
    * @param test_expression the expression to be assigned.
    */
   public void setTestExpression(final Expression test_expression)
   {
      this.testExpression = test_expression;
   }

   /**
    * Accessor to the then expression. The parameter is not tested and the
    * reference is immeiately assigned to the then expression.
    * 
    * @param then_expression the expression to be assigned.
    */
   public void setThenExpression(final Expression then_expression)
   {
      this.thenExpression = then_expression;
   }

   /**
    * Accessor to the else expression. The parameter is not tested and the
    * reference is immeiately assigned to the else expression.
    * 
    * @param else_expression the expression to be assigned.
    */
   public void setElseExpression(final Expression else_expression)
   {
      this.elseExpression = else_expression;
   }

   /**
    * Return the conditional expression as a string. This operation overrides
    * the toString() operation of Object. The output string format is:
    * <p>
    * <code>
    * if <test-expression> then <then-expression> else <else-expression>
    * </code>
    * </p>
    * <p>
    * No cariage return is inserted in the string exept if the underlying
    * expressions contains one or more. The underlying expressions are printed
    * in the string using their respective toString() operations.
    * 
    * @return the conditional expression as a string.
    */
   public String toString()
   {
      return "if ( " + this.testExpression + " ) then " + this.thenExpression
            + " else " + this.elseExpression;
   }

   /**
    * Evaluates the conditional expression. The evaluation context is used as
    * outer focus of the three underlying expression. This means that the
    * conditional expression context is used for the evaluation of the test
    * expression as well as for the then and the else expression. The evaluation
    * is performed as follow :
    * <p>
    * <b>Check conditional expression consitency:</b> before evaluating the
    * expression, the Test, Then and Else expression shall not be null.
    * </p>
    * <p>
    * <b>Compute the effective boolean value:</b> the test exression is
    * evaluated and he the following rules are applied to compute the effective
    * boolean value of the conditional expression.
    * </p>
    * <p>
    * <b>Evaluate the then-expression or the else-expression:</b>the
    * then-expression is evaluated if the the effective boolean value of the
    * test-expression is true. Else if the effective boolean value of the
    * test-expression is false, the else-expression is evaluated.
    * </p>
    * 
    * @param context the context to be considered during the evaluation. This
    *           parameter is not mandatory so it is not controlled during the
    *           evaluation of the conditional expression. However, because it is
    *           directly used by the underlying expression a null context may
    *           raise an error if the expression requires a non null context.
    * @return the result of the eluation of the conditional expression or null
    *         if an error occured.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {

      DrbSequence output_sequence;
      /**
       * Checks the conditional expression consitency.
       */
      if ((this.testExpression == null) || (this.thenExpression == null)
            || (this.elseExpression == null))
      {
         throw new DynamicException(this, "Incomplete \"if\" declaration");
      }

      /**
       * Evaluates the then-expression or the else-expression according to the
       * efective boolen value of the test-expression.
       */
      final DrbSequence testSequence = this.testExpression.evaluate(context);

      if (testSequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the test expression");
      }

      /**
       * Check and process, should the occasion arise, the cancellation request.
       */
      if (this.isCancellationRequested() == true)
      {
         this.throwCancelException();
      }

      /**
       * Evaluates the result.
       */
      if (Query.getEffectiveBooleanValue(testSequence))
      {
         output_sequence = this.thenExpression.evaluate(context);
      }
      else
      {
         output_sequence = this.elseExpression.evaluate(context);
      }

      return output_sequence;

   }

   /**
    * A expression which is constant means that it need no context item to be
    * evaluate. The returned sequence from its evaluation will always be the
    * same along the query script
    * 
    * @return true if this expression is constant
    */
   public boolean isConstant()
   {
      return (this.testExpression.isConstant()
            && this.elseExpression.isConstant() && this.thenExpression
            .isConstant());
   }

   /**
    * Checks if this conditional expression can modify the state of an existing
    * node. A conditional expression is updating if any branch (then/else)
    * contains an updating expression.
    * 
    * @return true if this expression performs updating operations and false
    *         otherwise
    */
   public boolean isUpdating()
   {
      final double key = Math.random();
      this.logger.debug("If.isUpdating() : Start " + key);
      this.logger.debug("If.isUpdating() :  " + this.toString());
      final boolean bool =
         (this.testExpression.isUpdating() || this.elseExpression.isUpdating() || this.thenExpression
               .isUpdating());
      this.logger.debug("If.isUpdating() : Stop " + key);
      return bool;
   }
}
