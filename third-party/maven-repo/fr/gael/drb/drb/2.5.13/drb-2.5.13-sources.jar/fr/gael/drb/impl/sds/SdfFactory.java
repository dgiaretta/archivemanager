/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import java.net.URL;
import java.nio.charset.Charset;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheException;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAbstractNode;
import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbFactory;
import fr.gael.drb.DrbFactoryImpl;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.impl.DrbFactoryResolver;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.impl.spi.DrbNodeSpi;
import fr.gael.drb.impl.xml.XmlFactory;
import fr.gael.drb.meta.DrbMetadata;
import fr.gael.drb.value.Numeric;
import fr.gael.drb.value.Value;
import fr.gael.drb.xsd.Namespace;
import fr.gael.drb.xsd.XmlSchema;
import fr.gael.drb.xsd.XsdComplexType;
import fr.gael.drb.xsd.XsdElement;
import fr.gael.drb.xsd.XsdFacet;
import fr.gael.drb.xsd.XsdFactory;
import fr.gael.drb.xsd.XsdListType;
import fr.gael.drb.xsd.XsdModelGroup;
import fr.gael.drb.xsd.XsdParticle;
import fr.gael.drb.xsd.XsdSimpleType;
import fr.gael.drb.xsd.XsdType;

/**
 * Factory for Structured Data Files.
 */
public final class SdfFactory implements DrbFactoryImpl
{
   /**
    * The SDF 2005/04 namespace URI.
    */
   public final static String SDF_2005_04_NAMESPACE =
      "http://www.gael.fr/2005/04/drb/sdf";

   /**
    * The SDF 2004/12 namespace URI.
    */
   public final static String SDF_2004_12_NAMESPACE =
      "http://www.gael.fr/2004/12/drb/sdf";

   /**
    * The SDF 2002/02 namespace URI.
    */
   public final static String SDF_2002_02_NAMESPACE =
      "http://www.gael.fr/drb/impl/sdf-20020222";

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(SdfFactory.class);

   /**
    * The default SDF namespace.
    */
   private String defaultVersion = getDefaultVersion();

   /**
    * The default schema.
    */
   private String defaultSchema;

   /**
    * If, and only if {@link #isEhCacheChecked} is true, this member denotes
    * whether EhCache classes are available at runtime.
    */
   private static boolean isEhCacheAvailable;

   /**
    * Denotes if the presence of EhCache classes have been checked. This static
    * boolean is supposed to be check only once at the first initialization of
    * any instance of this class and is considered stable up to the end of the
    * execution of the entire application.
    */
   private static boolean isEhCacheChecked = false;

   /**
    * The caching management system: available only and only if
    * {@link #isEhCacheAvailable} is true.
    */
   private CacheManager cacheManager = null;

   /**
    * A cache of loaded XML Schema's. This cache is available only of the
    * {@link #cacheManager} is available.
    */
   private Cache xmlSchemaCache = null;

   /**
    * Name of the {@link #xmlSchemaCache} in the {@link #cacheManager}.
    */
   private static final String xmlSchemaCacheName =
      "fr.gael.drb.impl.sds.XmlSchemaCache";

   /**
    * Builds a default factory
    */
   public SdfFactory()
   {
      // Initializes caching system as far as available
      initializeXmlSchemaCache();
   }

   /**
    * @return the isEhCacheAvailable
    */
   private static boolean isEhCacheAvailable()
   {
      return isEhCacheAvailable;
   }

   /**
    * @return the isEhCacheChecked
    */
   private static boolean isEhCacheChecked()
   {
      return isEhCacheChecked;
   }

   /**
    * @param isEhCacheAvailable the isEhCacheAvailable to set
    */
   private static void setEhCacheAvailable(final boolean isEhCacheAvailable)
   {
      SdfFactory.isEhCacheAvailable = isEhCacheAvailable;
   }

   /**
    * @param isEhCacheChecked the isEhCacheChecked to set
    */
   private static void setEhCacheChecked(final boolean isEhCacheChecked)
   {
      SdfFactory.isEhCacheChecked = isEhCacheChecked;
   }

   /**
    * @return the cacheManager
    */
   private CacheManager getCacheManager()
   {
      return this.cacheManager;
   }

   /**
    * @param cacheManager the cacheManager to set
    */
   private void setCacheManager(final CacheManager cacheManager)
   {
      this.cacheManager = cacheManager;
   }

   /**
    * @return the xmlSchemaCacheName
    */
   private static String getXmlSchemaCacheName()
   {
      return xmlSchemaCacheName;
   }

   /**
    * @return the xmlSchemaCache
    */
   private Cache getXmlSchemaCache()
   {
      return this.xmlSchemaCache;
   }

   /**
    * @param xmlSchemaCache the xmlSchemaCache to set
    */
   private void setXmlSchemaCache(final Cache xmlSchemaCache)
   {
      this.xmlSchemaCache = xmlSchemaCache;
   }

   /**
    * Initialize or reset current caching system if any available at runtime.
    */
   private void initializeXmlSchemaCache()
   {
      // Return immediately if no caching system available at runtime
      if (isEhCacheChecked() && !isEhCacheAvailable())
      {
         return;
      }

      // Checks that a caching system is available if not already done
      if (!isEhCacheChecked())
      {
         try
         {
            Class.forName("net.sf.ehcache.Cache");
         }
         catch (final ClassNotFoundException exception)
         {
            logger.info("No caching system available at runtime.");

            setEhCacheAvailable(false);
            setEhCacheChecked(true);

            return;
         }

         logger.debug("Caching system available.");
         setEhCacheAvailable(true);
         setEhCacheChecked(true);
      }

      // Get reference to the current cache manager
      CacheManager cacheManager = this.getCacheManager();

      // Create cache manager and cache if not available
      if (cacheManager == null)
      {
         // Create cache manager
         try
         {
            cacheManager = CacheManager.create(
            		this.getClass().getResource("ehcache.xml"));
            logger.debug("XML Schema cache manager created.");
         }
         catch (final CacheException exception)
         {
            logger.error("Cannot create XML Schema cache manager - "
                  + "disabling caching functionality.", exception);
            this.setXmlSchemaCache(null);
            setEhCacheAvailable(false);
            return;
         }

         this.setCacheManager(cacheManager);

         // Create cache for item paths
         cacheManager.addCacheIfAbsent(getXmlSchemaCacheName());
         final Cache cache = cacheManager.getCache(getXmlSchemaCacheName());
         this.setXmlSchemaCache(cache);

         logger.debug("Cache of XML Schema's created.");

      }
      // Otherwise simply clear the item path cache
      else
      {
         final Cache cache = this.getXmlSchemaCache();

         // Remove all elements the cache
         if (cache != null)
         {
            cache.removeAll();

            logger.info("Cache of XML Schema's cleared.");
         }
         // Report inconsistent state and cancel functionality
         else
         {
            logger.error("Inconsistent XML Schema cache state: "
                  + "null cache with an available manager - "
                  + "functionality disabled");
            cacheManager.shutdown();
            this.setCacheManager(null);
            setEhCacheAvailable(false);
            return;
         }

      } // Clear the item path cache

   } // initializeCache()

   /**
    * Put XML Schema in cache according to a corresponding node path. This
    * method is ineffective if no caching system has been initialized.
    * 
    * @param schemaLocation the path to the corresponding item.
    * @param xmlSchema the XML Schema to cache.
    * @throws NullPointerException if one of the parameter is null.
    */
   private void putXmlSchemaInCache(final String schemaLocation,
      final XmlSchema xmlSchema)
   {
      // Check parameters
      if (schemaLocation == null)
      {
         throw new NullPointerException("Null schema location.");
      }

      if (xmlSchema == null)
      {
         throw new NullPointerException("Null XML Schema.");
      }

      // Get current cache of item paths if any
      final Cache cache = this.getXmlSchemaCache();

      // Alter cache only if available
      if (cache != null)
      {
         // Create caching element
         final Element element = new Element(schemaLocation, xmlSchema);

         // Cache element
         cache.put(element);

         logger.debug("Putting in XML Schema cache: \"" + schemaLocation + "\"");
      }
   } // putXmlSchemaInCache(String, XmlSchema)

   /**
    * Return a class from a given item path that could have been previously
    * stored in dedicated caching system. This method always return null if no
    * caching system has been initialized and therefore always return null.
    * 
    * @param schemaLocation the path to the item matching the class to be
    *           retrieved.
    * @return the class or null if not retrieved.
    */
   private XmlSchema getXmlSchemaFromCache(final String schemaLocation)
   {
      // Throws an exception if the provided path is null
      if (schemaLocation == null)
      {
         throw new NullPointerException("Null item path.");
      }

      // Retrieve class from cache if available
      final Cache cache = this.getXmlSchemaCache();

      if (cache != null)
      {
         final Element element = cache.get(schemaLocation);

         if (element != null)
         {
            logger.debug("Retrieved from XML Schema cache: \"" + schemaLocation
                  + "\"");

            return (XmlSchema) element.getObjectValue();
         }
      }
      // Return null in any other cases
      return null;

   } // getClassFromCache(String)

   /**
    * Allow to get the default version of the namespace use by SdfFactory.
    * 
    * @return the default version of the namespace for SDF.
    */
   public static String getDefaultVersion()
   {
      return SDF_2005_04_NAMESPACE;
   }

   /**
    * The scheme identifier of the implementation. Always returns "sdf" string,
    * which is defined as the scheme identifier of the implementation.
    * 
    * @return The "sdf" string.
    */
   public final String getIdentifier()
   {
      return "sdf";
   }

   /**
    * The name of the implementation. Always returns "Structured Data File"
    * string, which stands as the name of the implementation.
    * 
    * @return The "Structured Data File" string.
    */
   public final String getName()
   {
      return "Structured Data File";
   }

   /**
    * Sets the default SDF-Schema location In case of success a structure change
    * event is fired on the current node.
    * 
    * @param path the schema path to be set.
    * @throws UnsupportedOperationException This exception is raised when the
    *            schema cannot be applied to this node.
    */
   public final void setSchema(final String path)
      throws UnsupportedOperationException
   {
      this.defaultSchema = path;
   }

   /**
    * Opens the node matching a given URI. This implementation does not support
    * this operation and therefore always returns a null reference.
    * 
    * @param uri Unused.
    * @return null.
    */
   public final DrbNode open(final URL uri)
   {
      if (this.defaultSchema == null)
      {
         return null;
      }
      else
      {
         return DrbFactory.openURI(uri.toString());
      }
   }

   /**
    * Opens the node from an existing node. This implementation does not support
    * this operation and therefore always returns a null reference.
    * 
    * @param base_node Unused.
    * @return null.
    */
   public final DrbNode open(final DrbNode base_node)
   {
      // Check input node
      if (base_node == null)
      {
         return null;
      }

      // Schema location definition (to be resolved further)
      String schema_location = null;

      // Retrieve metadata associated to the base node
      final DrbMetadata metadata =
         DrbFactoryResolver.getMetadataResolver().resolveMetadata(base_node);

      if (metadata != null)
      {
         Value schema_location_value = metadata.getProperty("schemaLocation");

         if (schema_location_value != null)
         {
            schema_location = schema_location_value.toString();
         }
      }

      if (schema_location != null)
      {
         // Attempts to retrieve the XML Schema in cache if already loaded
         XmlSchema xmlSchema = getXmlSchemaFromCache(schema_location);

         // If schema found in cache open SDF node with this one
         if (xmlSchema != null)
         {
            return this.open(base_node, xmlSchema, schema_location);
         }
         
         logger.debug ("Opening schema \"" + schema_location + "\".");
         // Opens the schema
         DrbNode schema = DrbFactory.openURI(schema_location);

         if (schema == null)
         {
            logger.warn("Cannot open schema from: " + schema_location);
            return null;
         }

         schema = new XmlFactory().open(schema);

         if (schema == null)
         {
            logger.warn("Schema \"" + schema_location
                  + "\"has no root node.");
            return null;
         }

         // Open the SDF node
         return this.open(base_node, schema, schema_location);
      }

      return null;
   }

   /**
    * Opens the node matching a given URI from an existing node. This
    * implementation does not support this operation and therefore always
    * returns a null reference.
    * 
    * @param uri Unused.
    * @param base_node Unused.
    * @return null.
    */
   public final DrbNode open(final URL uri, final DrbNode base_node)
   {
      return null;
   }

   /**
    * Opens a node using the base node and associated the schema node. This
    * operation creates and returns a DrbNode using an existing node as base or
    * context. The input base node is asked for a RandomAccessFile
    * implementation in order to get data from associated file. The schema node
    * is used to describe the data structure of this file.<br>
    * The reference to the input nodes shall not be null.
    * 
    * @param base_node The input node to be used as RandomAccessFile.
    * @param schema_node The input node to be used as data description.
    * @param schemaLocation the location of the provided schema.
    * @return A root node or null if an error occurred or if the implementation
    *         does not supports the input node.
    */
   public DrbNode open(final DrbNode base_node, final DrbNode schema_node,
      final String schemaLocation)
   {
      // Local declarations
      XmlSchema schemaDesc; // The schema description
      XsdFactory descLoader; // The schema loader
      String descName; // The schema file name

      // Check integrity
      if ((base_node == null) || (schema_node == null))
      {
         logger.error("fr.gael.drb.impl.sdf.SdfFactory.open() : "
               + "null parameter.");
         logger.error("   base_node   = "
               + (base_node == null ? null : "\"" + base_node.getName() + "\""));
         logger.error("   schema_node = "
               + (schema_node == null ? null : "\"" + schema_node.getName()
                     + "\""));
         return null;
      }

      // Create schema loader
      descLoader = new XsdFactory();
      descName = schema_node.getName();

      // Load schema node descriptors
      schemaDesc = descLoader.open(schema_node);
      if ((schemaDesc == null) || (schemaDesc.getRootElements() == null))
      {
         logger.error("fr.gael.drb.impl.sdf.SdfFactory.open() : "
               + "No element found in  \"" + descName + "\"");
         return null;
      }

      // Cache loaded XML Schema
      this.putXmlSchemaInCache(schemaLocation, schemaDesc);

      // Retrieve the SDF namespace, in use.
      if (schema_node instanceof DrbAbstractNode)
      {
         final Namespace ns_bindings =
            ((DrbAbstractNode) schema_node).getNamespaceBindings();
         if (ns_bindings != null)
         {
            if (ns_bindings.resolvePrefix(SDF_2002_02_NAMESPACE) != null)
            {
               this.defaultVersion = SDF_2002_02_NAMESPACE;
               logger.warn("Activated compatibility with SDF-2002-02. "
                     + "New features of the SDF engine may not work. "
                     + "Declare the '" + AbstractBlock.SDF_NAMESPACE
                     + "' namespace to avoid this warning.");
            }
            else if (ns_bindings.resolvePrefix(SDF_2004_12_NAMESPACE) != null)
            {
               this.defaultVersion = SDF_2004_12_NAMESPACE;
            }
            else if (ns_bindings.resolvePrefix(SDF_2005_04_NAMESPACE) != null)
            {
               this.defaultVersion = SDF_2005_04_NAMESPACE;
            }
            else
            {
               logger.warn("No SDF namespace declaration in the schema.");
            }
         }
      }

      return this.open(base_node, schemaDesc, schema_node.getParent().getPath());
   }

   /**
    * Opens a node using the base node and associated the XML-Schema. This
    * operation creates and returns a DrbNode using an existing node as base or
    * context. The input base node is asked for a RandomAccessFile
    * implementation in order to get data from associated file. The schema is
    * used to describe the data structure of this file.<br>
    * The reference to the input nodes shall not be null.
    * 
    * @param base_node The input node to be used as RandomAccessFile.
    * @param xml_schema The XML-Schema containing the SDF parameters.
    * @param schema_path The path of the XML-Schema file.
    * @return A root node or null if an error occured or if the implementation
    *         does not supports the input node.
    */
   public DrbNode open(final DrbNode base_node, final XmlSchema xml_schema,
      final String schema_path)
   {
      // Local declarations
      final RandomAccessData fileData = null; // The file to use for data
      // access
      boolean create_mode = false;
      XsdElement nodeDesc; // The root schema element
      Descriptor rootDesc; // The root block descriptor
      DrbNode rootBlock; // The root block node

      // Check integrity
      if ((base_node == null) || (xml_schema == null))
      {
         logger.error("null parameter.");
         logger.error("   base_node   = "
               + (base_node == null ? null : "\"" + base_node.getName() + "\""));
         return null;
      }

      if (!(base_node instanceof DrbNodeImpl))
      {
         logger.error("cannot retrieve a valid implementation."
               + (base_node == null ? null : "\"" + base_node.getName() + "\""));
         return null;
      }

      final DrbNodeImpl baseImpl = (DrbNodeImpl) base_node;

      try
      {
         // Load schema node descriptors
         if (xml_schema.getRootElements() == null)
         {
            logger.error("fr.gael.drb.impl.sdf.SdfFactory.open() : "
                  + "No element found " + "from schema \"" + schema_path + "\"");
            return null;
         }

         // Test if schema root node is unique
         if (xml_schema.getRootElements().length != 1)
         {
            logger.error("fr.gael.drb.impl.sdf.SdfFactory.open() : "
                  + "Node descriptor is not unique (nb="
                  + xml_schema.getRootElements().length + ") from schema \""
                  + schema_path + "\"");
            return null;
         }
         // Get schema root node descriptor
         nodeDesc = xml_schema.getDefaultRootElement();

         // Get file size
         // fileSize = fileData.length();
         create_mode = false;
         if (baseImpl.hasImpl(java.io.File.class))
         {
            create_mode =
               ((java.io.File) baseImpl.getImpl(java.io.File.class)).length() <= 0;
         }

         // Parse schema in order to build block descriptors and set root
         // block descriptor properties
         rootDesc =
            this.parseNodeDescriptor(fileData, create_mode, nodeDesc, null, 0);

         // Start recursive solving of root, base node and single ancestors flag
         rootDesc.setAsRoot(base_node, schema_path);
      }
      catch (final StaticException e)
      {
         logger.error(e.getMessage(), e);
         return null;
      }
      catch (final Exception e)
      {
         logger.error("ERROR:" + e.getMessage(), e);
         e.printStackTrace();
         return null;
      }

      // Creates root block
      if (create_mode)
      {
         rootBlock = new WriterBlock(rootDesc, new int[] {});
      }
      else
      {
         rootBlock = AbstractBlock.createOptimalBlock(rootDesc, new int[] {}, 1);
      }
      // returns root block
      return DrbNodeSpi.getDrb250FileNodeFromImplNode(rootBlock, base_node);
   }

   /**
    * Parse the schema descriptors tree to build block descriptors. This
    * implementation is recursive, the operation calls itself for the children
    * of the current schema nodelist. The root block descriptor is returned to
    * the caller.
    * 
    * @param file the file to pass as a reference for the block descritor.
    * @param create_mode the creation mode.
    * @param particle The particle
    * @param parent_descriptor the block descriptor to reference as parent for
    *           the block descriptor of the current schema node list.
    * @param depth the depth in the tree.
    * @return The DrbNode corresponding to the current schema node list.
    */
   private Descriptor parseNodeDescriptor(final RandomAccessData file,
      final boolean create_mode, final XsdParticle particle,
      final Descriptor parent_descriptor, final int depth)
   {
      // Check particle
      if (particle == null)
      {
         return null;
      }

      // If the particle is an instance of element
      Descriptor currentDescriptor = null;
      XsdModelGroup complex_content = null;
      if (particle instanceof XsdElement)
      {
         // Create block Descriptor from current element
         final XsdElement element = (XsdElement) particle;
         currentDescriptor = new Descriptor(file, create_mode, element, depth);
         this.parseExternalChildren(currentDescriptor, element);
         final XsdType element_type = // block element type only (not view)
            (currentDescriptor.viewDesc != null) ? currentDescriptor.viewDesc.baseType
                  : element.getType();
         // Add derived types
         if ((element_type != null) && element_type.isComplex())
         {
            final Object[] type_derivation =
               element_type.getDerivation().toArray();
            for (int ideriv = 0; ideriv < type_derivation.length; ideriv++)
            {
               if (!((XsdType) type_derivation[ideriv]).isComplex())
               {
                  continue;
               }
               final XsdElement susbtitution_element =
                  new XsdElement(element.getMinOccurs(), element.getMaxOccurs(),
                     element.getName(), (XsdType) type_derivation[ideriv]);
               susbtitution_element.setAnnotation(element.getAnnotation());
               final Descriptor substitution_descriptor =
                  this.parseNodeDescriptor(file, create_mode,
                     susbtitution_element, parent_descriptor, depth);
               if (substitution_descriptor.hasSignature())
               {
                  currentDescriptor.addSubstitution(substitution_descriptor);
               }
            }
         }
         // Retrieve complex content (if any)
         if ((element_type == null) || (element_type.getStructure() == null))
         {
            return currentDescriptor;
         }
         final XsdComplexType structure_type = element_type.getStructure();
         complex_content = structure_type.getComplexContent();
      }
      // Else the model group has to be "transparent"
      else if (particle instanceof XsdModelGroup)
      {
         // this.logger.debug("particle is not instance of XsdElement : "+
         // "Wrap to parent_descriptor "+parent_descriptor.getName());
         // Wrap parent block Descriptor
         final XsdModelGroup group_content = (XsdModelGroup) particle;
         if (group_content.getCompositor() == XsdModelGroup.CHOICE_MODEL)
         {
            // Create block Descriptor from current element
            final XsdComplexType element_type =
               new XsdComplexType(null, (XsdModelGroup) particle, null);
            final XsdElement element =
               new XsdElement(particle.getMinOccurs(), particle.getMaxOccurs(),
                  "choice", element_type);
            element.setAnnotation(group_content.getAnnotation());
            element.setExternalNodes(group_content.getExternalNodes());
            element.setExternalAttributes(group_content.getExternalAttributes());
            currentDescriptor =
               new Descriptor(file, create_mode, element, depth);
            this.parseExternalChildren(currentDescriptor, element);
            for (int i = 0; i < group_content.getLength(); i++)
            {
               final XsdParticle choice_particle = group_content.getParticle(i);
               final Descriptor choice_descriptor =
                  this.parseNodeDescriptor(file, create_mode, choice_particle,
                     parent_descriptor, depth);
               currentDescriptor.addSubstitution(choice_descriptor);
            }
         }
         else if ((complex_content != null)
               && (complex_content.getCompositor() == XsdModelGroup.SEQUENCE_MODEL))
         {
            currentDescriptor = parent_descriptor;
         }
      }
      // Case of Wildcard not supported
      else
      {
         this.logger
            .error("fr.gael.drb.impl.sdf.SdfFactory.parseNodeDescriptor() : "
                  + "Only ELEMENT_TERM is implemented at this time.");
         throw new StaticException("Unrecognized XS particle");
      }

      if (complex_content == null)
      {
         return currentDescriptor;
      }

      if (complex_content.getCompositor() == XsdModelGroup.CHOICE_MODEL)
      {
         final Descriptor choiceDescriptor =
            this.parseNodeDescriptor(file, create_mode, complex_content,
               currentDescriptor, depth + 1);
         currentDescriptor.addChild(choiceDescriptor);
         return currentDescriptor;
      }

      // Loop on list children
      Descriptor nextDescriptor = null;
      final int length = complex_content.getLength();
      for (int i = 0; i < length; i++)
      {
         // Parse sub-particle
         nextDescriptor = this.parseNodeDescriptor(file, create_mode, 
            complex_content.getParticle(i), currentDescriptor, depth + 1);

         // If child descriptor is not null add tree cross references
         if (nextDescriptor != null)
         {
            // TBC !!?? filtrage etonnant, verifier les conditions de
            // recursivite lorsque les fils sont rattaches au parent au lieu
            // du noeud lui-meme (transparent) !
            if (currentDescriptor != nextDescriptor)
            {
               currentDescriptor.addChild(nextDescriptor);
            }
         }
      }
      return currentDescriptor;
   }

   /**
    * Block parser.
    */

   /**
    * Parse a "unit" attribute and return the type. The unit attribute value can
    * be one of the following :
    */
   private static short parseUnit(final DrbAttribute attribute)
   {
      logger.debug("parseUnit()");
      // Local declarations
      Value attributeValue = null; // Attribute value
      String attributeValueStr; // Attribute value string
      try
      {
         // Get attribute value and return if null
         if ((attributeValue = attribute.getValue()) == null)
         {
            logger.error("fr.gael.drb.impl.sdf.Descriptor.parseUnit() : "
                  + "Unit attribute value is null.");
            return -1;
         }
         // Get value string
         attributeValueStr = attributeValue.toString();
         // Case of byte unit
         if (attributeValueStr.equals("byte"))
         {
            return LengthAttribute.UNIT_BYTE;
         }
         // Case of byte unit
         else if (attributeValueStr.equals("bit"))
         {
            return LengthAttribute.UNIT_BIT;
         }
         // Case of unknown unit attribute value
         else
         {
            logger.error("fr.gael.drb.impl.sdf.SdfFactory.parseUnit() : "
                  + "Unknown unit attribute value (" + attributeValueStr + ").");
            return -1;
         }
      }
      catch (final ClassCastException e)
      {
         logger.error("fr.gael.drb.impl.sdf.SdfFactory.parseUnit() : "
               + "Error while extracting unit attribute value ("
               + attributeValue + ").");
         logger.error("   " + e);
         return -1;
      }
   }

   /**
    * Parse a "context" attribute and return the type. The context attribute
    * value can be one of the following :
    */
   private static short parseContext(final DrbAttribute attribute)
   {
      logger.debug("parseContext()");
      // Local declarations
      Value attributeValue = null; // Attribute value
      String attributeValueStr; // Attribute value string
      try
      {
         // Get attribute value and return if null
         if ((attributeValue = attribute.getValue()) == null)
         {
            logger.error("fr.gael.drb.impl.sdf.Descriptor.parseContext() : "
                  + "Unit attribute value is null.");
            return -1;
         }
         // Get value string
         attributeValueStr = attributeValue.toString();
         // Case of root context
         if (attributeValueStr.equals("root"))
         {
            return PhysicalAttribute.ROOT;
         }
         // Case of parent context
         else if (attributeValueStr.equals("parent"))
         {
            return PhysicalAttribute.PARENT;
         }
         // Case of self context
         else if (attributeValueStr.equals("self"))
         {
            return PhysicalAttribute.SELF;
         }

         // Case of unknown origin attribute value
         else
         {
            logger.error("fr.gael.drb.impl.sdf.Descriptor.parseContext() : "
                  + "Unknown origin attribute value (" + attributeValueStr
                  + ").");
            return -1;
         }
      }
      catch (final ClassCastException e)
      {
         logger.error("fr.gael.drb.impl.sdf.Descriptor.parseContext() : "
               + "Error while extracting origin attribute value ("
               + attributeValue + ").");
         logger.error("   " + e);
         return -1;
      }
   }

   /**
    * Parse a "origin" attribute and return the type. The origin attribute value
    * can be one of the following :
    * <dl>
    * <dd>ORIGIN_ROOT</dd>
    * <dd>ORIGIN_PARENT</dd>
    * <dd>ORIGIN_PREVIOUS</dd>
    * </dl>
    * 
    * @param attribute The attribute to parse.
    * @return the origin type or -1.
    */
   private static short parseOrigin(final DrbAttribute attribute)
   {
      logger.debug("parseOrigin()");
      // Local declarations
      Value attributeValue = null; // Attribute value
      String attributeValueStr; // Attribute value string
      try
      {
         // Get attribute value and return if null
         if ((attributeValue = attribute.getValue()) == null)
         {
            logger.error("fr.gael.drb.impl.sdf.Descriptor.parseOrigin() : "
                  + "Unit attribute value is null.");
            return -1;
         }
         // Get value string
         attributeValueStr = attributeValue.toString();
         // Case of root origin
         if (attributeValueStr.equals("root"))
         {
            return OffsetAttribute.ORIGIN_ROOT;
         }
         // Case of parent origin
         else if (attributeValueStr.equals("parent"))
         {
            return OffsetAttribute.ORIGIN_PARENT;
         }
         else if (attributeValueStr.equals("previous"))
         {
            return OffsetAttribute.ORIGIN_PREVIOUS;
         }
         // Case of unknown origin attribute value
         else
         {
            logger.error("fr.gael.drb.impl.sdf.Descriptor.parseOrigin() : "
                  + "Unknown origin attribute value (" + attributeValueStr
                  + ").");
            return -1;
         }
      }
      catch (final ClassCastException e)
      {
         logger.error("fr.gael.drb.impl.sdf.Descriptor.parseOrigin() : "
               + "Error while extracting origin attribute value ("
               + attributeValue + ").");
         logger.error("   " + e);
         return -1;
      }
   }

   /**
    * Parse a "signature" node.
    * 
    * @param descriptor The descriptor.
    * @param node The node to parse.
    * @return the query of the signature.
    */
   private Descriptor.Signature parseSignature(final Descriptor descriptor,
      final DrbNode node)
   {
      this.logger.debug("parseSignature()");
      // Local declaration
      final Value nodeValue = node.getValue(); // Node value

      // Extract signature query from attribute value
      if (nodeValue != null)
      {
         return new Descriptor.Signature(nodeValue.toString());
      }
      final DrbAttribute query_attrib = node.getAttribute("query");
      if (query_attrib != null)
      {
         return new Descriptor.Signature(query_attrib.getValue().toString());
      }

      final DrbAttribute value_attrib = node.getAttribute("value");
      if ((value_attrib != null) && (value_attrib.getValue() != null))
      {
         final Value target_value =
            value_attrib.getValue().convertTo(descriptor.valueType);
         return new Descriptor.Signature(target_value);
      }
      return null;
   }

   /**
    * Parse a "value" node.
    * 
    * @param node The node to parse.
    * @return the query of the value.
    */
   private String parseValue(final DrbNode node)
   {
      this.logger.debug("parseValue()");
      // Local declaration
      final Value nodeValue = node.getValue(); // Node value

      // Extract value query from attribute value
      if (nodeValue != null)
      {
         return nodeValue.toString();
      }

      return null;
   }

   /**
    * Parse a "nodeName" node.
    * 
    * @param node The node to parse.
    * @return The length attribute
    */
   private PhysicalAttribute parseNodeName(final DrbNode node)
      throws StaticException
   {
      this.logger.debug("parseNodeName()");
      // Local declaration
      final PhysicalAttribute nodeName =
         new PhysicalAttribute(PhysicalAttribute.READ_WRITE);
      boolean nameQueryDefined = false;
      int nbAttribute; // Number of attributes
      DrbAttributeList attributeList; // Attribute list of the node

      // Get attribute list
      nbAttribute = 0;
      attributeList = node.getAttributes();

      // By default length unit is byte and no query has been defined
      nameQueryDefined = false;

      // Case of attributes
      if ((attributeList != null)
            && ((nbAttribute = attributeList.getLength()) > 0))
      {
         // Loop on attributes
         for (int j = 0; j < nbAttribute; j++)
         {
            // Get current attribute
            final DrbAttribute attribute = attributeList.item(j);
            Value attributeValue = null; // Attribute value

            // Case of "context" occurrence attribute
            if ("context".equals(attribute.getName()))
            {
               // Sets the length unit
               final short query_context = parseContext(attribute);
               nodeName.setQueryContext(query_context);
            }
            // Case of "query" attribute
            else if ("query".equals(attribute.getName()))
            {
               try
               {
                  // Get attribute value and return if null
                  if ((attributeValue = attribute.getValue()) == null)
                  {
                     this.logger
                        .error("fr.gael.drb.impl.sds.Descriptor.parseNodeName() : "
                              + "Name query attribute value is null.");
                     throw new StaticException(
                        "Name query attribute value is null.");
                  }
                  // Extract length query from attribute value
                  final String nameQuery = attributeValue.toString();
                  nodeName.setQuery(nameQuery);
                  nodeName.setAccessType(PhysicalAttribute.READ_WRITE);
                  nameQueryDefined = true;
               }
               catch (final ClassCastException e)
               {
                  this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseNodeName() : "
                           + "Error while extracting name query attribute"
                           + " value (" + attributeValue + ").");
                  this.logger.error("   " + e);
                  throw new StaticException(
                     "Error while extracting name query attribute.");
               }
            }
            // Case of "constant" occurrence attribute
            else if ("constant".equals(attribute.getName()))
            {
               try
               {
                  // Get attribute value and return if null
                  if ((attributeValue = attribute.getValue()) == null)
                  {
                     this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseNodeName():"
                              + "Name 'constant' attribute value is null.");
                     throw new StaticException(
                        "Name 'constant' attribute value is null.");
                  }
                  // Extract attribute value
                  if (attributeValue.toString().equals("false"))
                  {
                     nodeName.setOccurrenceType(PhysicalAttribute.MULTIPLE);
                  }
                  else if (attributeValue.toString().equals("true"))
                  {
                     nodeName.setOccurrenceType(PhysicalAttribute.SINGLE);
                  }
                  else
                  {
                     this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseNodeName():"
                              + "Name 'constant' attribute value is invalid."
                              + " value='" + attributeValue.toString() + "'");
                     throw new StaticException(
                        "Name 'constant' attribute value is invalid.");
                  }
               }
               catch (final ClassCastException e)
               {
                  final String msg_error =
                     "fr.gael.drb.impl.sdf.Descriptor.parseNodeName() : "
                           + "Error while extracting name 'constant' "
                           + " attribute value (" + attributeValue + ").";
                  this.logger.error(msg_error);
                  this.logger.error("   " + e);
                  throw new StaticException(msg_error);
               }
            }

            // Unknown attribute
            else
            {
               this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parseNodeName() : "
                        + "Unknown nodeName attribute (" + attribute.getName()
                        + ").");
               throw new StaticException("Unknown nodeName attribute ("
                     + attribute.getName() + ").");
            }
         }
      }

      // Value is extracted
      return nodeName;
   }

   /**
    * Parse a "length" node.
    * 
    * @param node The node to parse.
    * @return The length attribute
    */
   private LengthAttribute parseLength(final DrbNode node)
      throws StaticException
   {
      this.logger.debug("parseLength()");
      // Local declaration
      final LengthAttribute length =
         new LengthAttribute(PhysicalAttribute.READ_WRITE);
      int nbAttribute; // Number of attributes
      DrbAttributeList attributeList; // Attribute list of the node
      boolean lengthQueryDefined; // True if a length query is defined

      // Get attribute list
      nbAttribute = 0;
      attributeList = node.getAttributes();

      // By default length unit is byte and no query has been defined
      length.setUnit(LengthAttribute.UNIT_BYTE);
      lengthQueryDefined = false;

      // Case of attributes
      if ((attributeList != null)
            && ((nbAttribute = attributeList.getLength()) > 0))
      {
         // Loop on attributes
         for (int j = 0; j < nbAttribute; j++)
         {
            // Get current attribute
            final DrbAttribute attribute = attributeList.item(j);
            Value attributeValue = null; // Attribute value

            // Case of "unit" occurrence attribute
            if (attribute.getName().equals("unit"))
            {
               // Sets the length unit
               final short unit = parseUnit(attribute);
               length.setUnit(unit);
            }
            else
            // Case of "context" occurrence attribute
            if (attribute.getName().equals("context"))
            {
               // Sets the length unit
               final short query_context = parseContext(attribute);
               length.setQueryContext(query_context);
            }
            // Case of "query" attribute
            else if (attribute.getName().equals("query"))
            {
               try
               {
                  // Get attribute value and return if null
                  if ((attributeValue = attribute.getValue()) == null)
                  {
                     this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseLength() : "
                              + "Length query attribute value is null.");
                     throw new StaticException(
                        "Length query attribute value is null.");
                  }
                  // Extract length query from attribute value
                  final String lengthQuery = attributeValue.toString();
                  length.setQuery(lengthQuery);
                  length.setAccessType(PhysicalAttribute.READ_WRITE);
                  lengthQueryDefined = true;
               }
               catch (final ClassCastException e)
               {
                  this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseLength() : "
                           + "Error while extracting length query attribute"
                           + " value (" + attributeValue + ").");
                  this.logger.error("   " + e);
                  throw new StaticException(
                     "Error while extracting length query attribute.");
               }
            }
            // Case of "constant" occurrence attribute
            else if (attribute.getName().equals("constant"))
            {
               try
               {
                  // Get attribute value and return if null
                  if ((attributeValue = attribute.getValue()) == null)
                  {
                     this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseLength():"
                              + "Length constant attribute value is null.");
                     throw new StaticException(
                        "Length constant attribute value is null.");
                  }
                  // Extract attribute value
                  if (attributeValue.toString().equals("false"))
                  {
                     length.setOccurrenceType(PhysicalAttribute.MULTIPLE);
                  }
                  else if (attributeValue.toString().equals("true"))
                  {
                     length.setOccurrenceType(PhysicalAttribute.SINGLE);
                  }
                  else
                  {
                     this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseLength():"
                              + "Length constant attribute value is invalid."
                              + " value='" + attributeValue.toString() + "'");
                     throw new StaticException(
                        "Length constant attribute value is invalid.");
                  }
               }
               catch (final ClassCastException e)
               {
                  this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseLength() : "
                           + "Error while extracting length constant "
                           + " attribute value (" + attributeValue + ").");
                  this.logger.error("   " + e);
                  throw new StaticException(
                     "Error while extracting length constant "
                           + " attribute value (" + attributeValue + ").");
               }
            }

            // Unknown attribute
            else
            {
               this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parseLength() : "
                        + "Unknown length attribute (" + attribute.getName()
                        + ").");
               throw new StaticException("Unknown length attribute ("
                     + attribute.getName() + ").");
            }
         }
      }
      // Get length value if no query has been defined
      if (!lengthQueryDefined)
      {
         Value nodeValue = null; // Node value
         try
         {
            // Get node value and return if null
            if ((nodeValue = node.getValue()) == null)
            {
               this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parseLength() : "
                        + "Length value is null.");
               throw new StaticException("Length value is null.");
            }
            // Extract length from node value
            if (nodeValue.toString().equals("unbounded"))
            {
               length.setAccessType(PhysicalAttribute.READ_WRITE);
            }
            else
            {
               final String node_string = nodeValue.toString().trim();
               final long valueLength = java.lang.Long.parseLong(node_string);
               length.setAccessType(PhysicalAttribute.READ_ONLY);
               length.setOccurrenceType(PhysicalAttribute.SINGLE);
               // Case of bit unit
               switch (length.getUnit())
               {
                  case LengthAttribute.UNIT_BIT:
                     // Keep fixed values (no need for key to set value)
                     length.setLength(null, new Length(0, valueLength));
                     break;
                  // Default : Case of byte unit
                  case LengthAttribute.UNIT_BYTE:
                     length.setLength(null, new Length(valueLength));
                     break;
               }
            }
         }
         // Value extraction problem
         catch (final ClassCastException e)
         {
            this.logger.error("fr.gael.drb.impl.sdf.Descriptor.parseLength() : "
                  + "Error while extracting length value (" + nodeValue + ").");
            this.logger.error("   " + e);
            throw new StaticException("Error while extracting length value.");
         }
      }
      length.setSpecified(true);
      // Value is extracted
      return length;
   }

   /**
    * Parse a "encoding" node.
    * 
    * @param node The node to parse.
    * @return the encoding extracted
    */
   private int parseEncoding(final DrbNode node) throws StaticException
   {
      this.logger.debug("parseEncoding()");
      // Local declaration
      String tmpString; // Extracted string
      Value nodeValue = null; // Node value

      // Get node value and return if null
      if ((nodeValue = node.getValue()) == null)
      {
         this.logger.error("Encoding value is null.");
         throw new StaticException("Encoding value is null.");
      }
      // Extract length from node value
      tmpString = nodeValue.toString().toUpperCase();
      // Case of "BINARY"
      if (tmpString.equals("BINARY"))
      {
         return Descriptor.ENCODING_BINARY;
      }
      else
      // Case of "TEXT"      
      {
         return Descriptor.ENCODING_TEXT;
      }      
   }

   /**
    * Parse a "charset" node.
    * 
    * @param node The node to parse.
    * @return the encoding extracted
    */
   private String parseCharset(final DrbNode node) throws StaticException
   {
      this.logger.debug("parseCharset)");
      // Local declaration
      String tmpString; // Extracted string
      Value nodeValue = null; // Node value

      // Get node value and return if null
      if ((nodeValue = node.getValue()) == null)
      {
         this.logger.error("Charset name is null.");
         throw new StaticException("Charset name is null.");
      }
      // Extract length from node value
      tmpString = nodeValue.toString().toUpperCase();
      // Case of "ASCII"
      if (tmpString.equals("ASCII"))
      {
         return Descriptor.CHARSET_ASCII;
      }
      // Case of "EBCDIC"
      else if (tmpString.equals("EBCDIC"))
      {
         return Descriptor.CHARSET_EBCDIC;
      }
      // Case of "US_ASCII"
      else if (tmpString.equals("US-ASCII"))
      {
         return Descriptor.CHARSET_US_ASCII;
      }
      // Case of known charset
      else if (Charset.isSupported(tmpString))
      {
         return tmpString;
      }
      // Case of invalid charset
      else
      {         
         this.logger.error("Unknown charset name (" + tmpString + ").");
         throw new StaticException("Unknown encoding value (" + tmpString + ").");
      }
   }

   /**
    * Parse a "byteOrder" node.
    * 
    * @param node The node to parse.
    * @return the byte order.
    */
   private int parseByteOrder(final DrbNode node) throws StaticException
   {
      this.logger.debug("parseByteOrder()");
      // Local declaration
      String tmpString; // Extracted string
      Value nodeValue = null; // Node value

      // Get node value and return if null
      if ((nodeValue = node.getValue()) == null)
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor.parseByteOrder() : "
               + "Byte Order value is null.");
         throw new StaticException("Byte Order value is null.");
      }
      // Extract length from node value
      tmpString = nodeValue.toString();
      // Case of "LSB"
      if (tmpString.equals("LSB"))
      {
         return Descriptor.BYTE_ORDERING_LSB;
      }
      // Case of "MSB"
      else if (tmpString.equals("MSB"))
      {
         return Descriptor.BYTE_ORDERING_MSB;
      }
      // Case of invalid Byte order
      else
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor.parseByteOrder() : "
               + "Unknown byte order value (" + tmpString + ").");
         throw new StaticException("Unknown byte order value (" + tmpString
               + ").");
      }
   }

   /**
    * Parse a "delimiter" node.
    * 
    * @param node The node to parse.
    * @return the delimiter
    */
   private String parseDelimiter(final DrbNode node)
   {
      this.logger.debug("parseDelimiter()");
      // Local declaration
      String tmpString = null; // Extracted string
      Value nodeValue = null; // Node value
      Value codeValue = null; // Node value

      // Get node value and return if null
      nodeValue = node.getValue();

      // Get the value attribute the node content is empty
      if (nodeValue == null) // value attribute
      {
         final DrbAttribute value_attrib = node.getAttribute("value");
         if (value_attrib != null)
         {
            nodeValue = value_attrib.getValue();
         }
      }
      if (nodeValue == null) // value attribute
      {
         final DrbAttribute value_attrib = node.getAttribute("code");
         if (value_attrib != null)
         {
            codeValue = value_attrib.getValue();
         }
         if (codeValue != null)
         {
            final String code_string =
               Character.toString((char) Integer.parseInt(codeValue.toString()));
            nodeValue = new fr.gael.drb.value.String(code_string);
         }
      }
      if (nodeValue != null)
      {
         tmpString = nodeValue.toString();
      }
      if (tmpString == null)
      {
         this.logger.debug("fr.gael.drb.impl.sdf.Descriptor.parseDelimiter() : "
               + "delimiter value is null.('" + (int) '\n' + ")");
         return "\n";
      }
      // Extract length from node value
      return tmpString;
   }

   /**
    * Parse a "block" node.
    * 
    * @param descriptor The descriptor.
    * @param node The node to parse.
    * @return True if value has been found and extracted
    */
   private void parseBlock(final Descriptor descriptor, final DrbNode node)
   {
      this.logger.debug("parseBlock()");
      // Local declaration
      DrbNode nodeChild; // Current node child
      String nodeName; // Current node name
      int nbAttribute; // Number of attributes
      DrbAttributeList attributeList; // Attribute list of the node
      DrbAttribute attribute; // Current attribute
      Value attributeValue = null; // Attribute value

      // Get attribute list
      nbAttribute = 0;
      attributeList = node.getAttributes();

      // Case of attributes
      if ((attributeList != null)
            && ((nbAttribute = attributeList.getLength()) > 0))
      {
         // Loop on attributes
         for (int j = 0; j < nbAttribute; j++)
         {
            // Get current attribute
            attribute = attributeList.item(j);
            // Case of "query" attribute
            if (attribute.getName().equals("query"))
            {
               try
               {
                  // Get attribute value and return if null
                  if ((attributeValue = attribute.getValue()) == null)
                  {
                     this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseLength() : "
                              + "Length query attribute value is null.");
                     return;
                  }
                  // Extract query from attribute value
                  descriptor.fileNodePath = attributeValue.toString();
               }
               catch (final ClassCastException e)
               {
                  this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseLength() : "
                           + "Error while extracting length query attribute"
                           + " value (" + attributeValue + ").");
                  this.logger.error("   " + e);
                  throw new StaticException(
                     "Error while extracting length query attribute"
                           + " value (" + attributeValue + ").");
               }
            }
            // Unknown attribute
            else
            {
               this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parseBlock() : "
                        + "Unknown attribute (" + attribute.getName() + ").");
               return;
            }
         }
      }

      // Loop on "drb:block" children nodes
      for (int i = 0; i < node.getChildrenCount(); i++)
      {
         // Get current node child and the corresponding name
         nodeChild = node.getChildAt(i);
         nodeName = nodeChild.getName();
         // Parse occurrence count
         if ("occurrence".equals(nodeName))
         {
            descriptor.occurrenceCount = this.parseOccurrence(nodeChild);
         }
         // Parse length
         else if ("length".equals(nodeName))
         {
            descriptor.contentLength = this.parseLength(nodeChild);
         }
         // Parse offset
         else if ("offset".equals(nodeName))
         {
            descriptor.blockOffset = parseOffset(nodeChild);
         }
         // Parse padding
         else if ("padding".equals(nodeName))
         {
            this.parsePadding(descriptor, nodeChild);
         }
         // Parse encoding
         else if ("encoding".equals(nodeName))
         {
            descriptor.encoding = this.parseEncoding(nodeChild);
            if (descriptor.encoding == Descriptor.ENCODING_TEXT)
            {
               descriptor.charsetName = this.parseCharset(nodeChild);
            }
         }
         // Parse numericFormat
         else if ("numericFormat".equals(nodeName))
         {
            descriptor.textFormat = this.parseNumericFormat(nodeChild);
         }
         // Parse dateFormat
         else if ("dateFormat".equals(nodeName))
         {
            descriptor.textFormat = this.parseDateFormat(nodeChild);
         }
         // Parse byteOrder
         else if ("byteOrder".equals(nodeName))
         {
            descriptor.byteOrdering = this.parseByteOrder(nodeChild);
         }
         // Parse delimiter
         else if ("delimiter".equals(nodeName))
         {
            descriptor.delimiter = this.parseDelimiter(nodeChild);
         }
         // Parse signature
         else if ("signature".equals(nodeName))
         {
            descriptor.signature = this.parseSignature(descriptor, nodeChild);
         }
         // Parse value
         else if ("value".equals(nodeName))
         {
            descriptor.valueQuery = this.parseValue(nodeChild);
         }
         // Parse array
         else if ("array".equals(nodeName))
         {
            this.parseArray(descriptor, nodeChild);
         }
         // Parse nodeName
         else if ("nodeName".equals(nodeName))
         {
            descriptor.blockName = this.parseNodeName(nodeChild);
         }
         // Unknown element
         else
         {
            this.logger.warn("fr.gael.drb.impl.sdf.Descriptor.parseBlock() : "
                  + "Unknown element \"" + nodeName + "\", ignored.");
         }
      }
   }

   /**
    * Parse a "block" for an array.
    * 
    * @param descriptor The descriptor.
    * @param node The node to parse.
    */
   private void parseArrayBlock(final Descriptor descriptor, final DrbNode node)
   {
      this.logger.debug("parseArrayBlock()");

      // Local declaration
      DrbNode nodeChild; // Current node child
      String nodeName; // Current node name

      // Loop on "sds:array" children nodes
      for (int i = 0; i < node.getChildrenCount(); i++)
      {
         // Get current node child and the corresponding name
         nodeChild = node.getChildAt(i);
         nodeName = nodeChild.getName();
         // Parse encoding
         if ("encoding".equals(nodeName))
         {
            descriptor.encoding = this.parseEncoding(nodeChild);
            if (descriptor.encoding == Descriptor.ENCODING_TEXT)
            {
               descriptor.charsetName = this.parseCharset(nodeChild);
            }
         }
         // Parse numericFormat
         else if ("numericFormat".equals(nodeName))
         {
            descriptor.textFormat = this.parseNumericFormat(nodeChild);
         }
         // Parse dateFormat
         else if ("dateFormat".equals(nodeName))
         {
            descriptor.textFormat = this.parseDateFormat(nodeChild);
         }
         // Parse byteOrder
         else if ("byteOrder".equals(nodeName))
         {
            descriptor.byteOrdering = this.parseByteOrder(nodeChild);
         }
         // Parse occurrence count
         else if ("occurrence".equals(nodeName))
         {
            descriptor.itemCount = this.parseOccurrence(nodeChild);
         }
         // Parse length
         else if ("length".equals(nodeName))
         {
            descriptor.itemLength = this.parseLength(nodeChild);
         }
         else if ("delimiter".equals(nodeName))
         {
            descriptor.arrayDelimiter = this.parseDelimiter(nodeChild);
         }
         // Unknown element
         else
         {
            this.logger
               .warn("fr.gael.drb.impl.sdf.Descriptor.parseArrayBlock() : "
                     + "Unknown element \"" + nodeName + "\", ignored.");
         }
      }
   }

   /**
    * Parse a "array" node.
    * 
    * @param descriptor The descriptor.
    * @param node The node to parse.
    */
   private void parseArray(final Descriptor descriptor, final DrbNode node)
   {
      this.logger.debug("parseArray()");
      // Local declaration
      DrbNode nodeChild; // Current node child
      String nodeName; // Current node name

      // Loop on "sds:array" children nodes
      for (int i = 0; i < node.getChildrenCount(); i++)
      {
         // Get current node child and the corresponding name
         nodeChild = node.getChildAt(i);
         nodeName = nodeChild.getName();
         // Parse occurrence count
         if ("occurrence".equals(nodeName))
         {
            descriptor.itemCount = this.parseOccurrence(nodeChild);
         }
         // Parse length
         else if ("length".equals(nodeName))
         {
            descriptor.itemLength = this.parseLength(nodeChild);
         }
         else if ("delimiter".equals(nodeName))
         {
            descriptor.arrayDelimiter = this.parseDelimiter(nodeChild);
         }
         // Unknown element
         else
         {
            this.logger.warn("fr.gael.drb.impl.sdf.Descriptor.parseArray() : "
                  + "Unknown element \"" + nodeName + "\", ignored.");
         }
      }
   }

   /**
    * Parse a "decimalFormat" node.
    * 
    * @param node The node to parse.
    * @return The DecimalFormat
    */
   private NumericFormat parseNumericFormat(final DrbNode node)
   {
      this.logger.debug("parseNumericFormat()");
      // Local declaration
      DrbNode nodeChild; // Current node child
      String nodeName; // Current node name
      int nbAttribute; // Number of attributes
      DrbAttributeList attributeList; // Attribute list of the node
      DrbAttribute attribute; // Current attribute
      Value attributeValue = null; // Attribute value

      NumericFormat format = new NumericFormat();

      // Get attribute list
      nbAttribute = 0;
      attributeList = node.getAttributes();

      // Case of attributes
      if ((attributeList != null)
            && ((nbAttribute = attributeList.getLength()) > 0))
      {
         // Loop on attributes
         for (int j = 0; j < nbAttribute; j++)
         {
            // Get current attribute
            attribute = attributeList.item(j);
            // Case of "query" attribute
            if (attribute.getName().equals("pattern"))
            {
               try
               {
                  // Get attribute value and return if null
                  if ((attributeValue = attribute.getValue()) == null)
                  {
                     this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseNumericFormat() : "
                              + "Pattern attribute value is null.");
                     throw new StaticException(
                        "fr.gael.drb.impl.sdf.Descriptor.parseNumericFormat() : "
                              + "Pattern attribute value is null.");
                  }
                  // Extract pattern from attribute value
                  String pattern = attributeValue.toString();
                  // Handle the negative pattern automatically
                  if (pattern.startsWith("+") && (pattern.indexOf(";") < 0))
                  {
                     final String positive_pattern = pattern;
                     final String negative_pattern =
                        "-" + positive_pattern.substring(1);
                     pattern = positive_pattern + ";" + negative_pattern;
                  }
                  format = new NumericFormat(attributeValue.toString());
               }
               catch (final ClassCastException e)
               {
                  this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseNumericFormat() : "
                           + "Error while extracting pattern attribute"
                           + " value (" + attributeValue + ").");
                  this.logger.error("   " + e);
                  throw new StaticException(
                     "Error while extracting pattern attribute" + " value ("
                           + attributeValue + ").");
               }
            }
            // Unknown attribute
            else
            {
               this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parseNumericFormat() : "
                        + "Unknown attribute (" + attribute.getName() + ").");
            }
         }
      }

      // Loop on "sdf:numericFormat" children nodes
      for (int i = 0; i < node.getChildrenCount(); i++)
      {
         // Get current node child and the corresponding name
         nodeChild = node.getChildAt(i);
         nodeName = nodeChild.getName();
         // Parse integerDigits
         if ("integerDigits".equals(nodeName))
         {
            if (nodeChild.getAttribute("min") != null)
            {
               final Value min = nodeChild.getAttribute("min").getValue();
               format.setMinimumIntegerDigits(((Numeric) min
                  .convertTo(Value.NUMERIC_ID)).intValue());
            }
            if (nodeChild.getAttribute("max") != null)
            {
               final Value max = nodeChild.getAttribute("max").getValue();
               format.setMaximumIntegerDigits(((Numeric) max
                  .convertTo(Value.NUMERIC_ID)).intValue());
            }
            if (nodeChild.getValue() != null)
            {
               final String node_string = nodeChild.getValue().toString().trim();
               final int val = java.lang.Integer.parseInt(node_string);
               format.setMinimumIntegerDigits(val);
               format.setMaximumIntegerDigits(val);
            }
         }
         // Parse fractionDigits
         else if ("fractionDigits".equals(nodeName))
         {
            if (nodeChild.getAttribute("min") != null)
            {
               final Value min = nodeChild.getAttribute("min").getValue();
               format.setMinimumFractionDigits(((Numeric) min
                  .convertTo(Value.NUMERIC_ID)).intValue());
            }
            if (nodeChild.getAttribute("max") != null)
            {
               final Value max = nodeChild.getAttribute("max").getValue();
               format.setMaximumFractionDigits(((Numeric) max
                  .convertTo(Value.NUMERIC_ID)).intValue());
            }
            if (nodeChild.getValue() != null)
            {
               final String node_string = nodeChild.getValue().toString().trim();
               final int val = java.lang.Integer.parseInt(node_string);
               format.setMinimumFractionDigits(val);
               format.setMaximumFractionDigits(val);
            }
         }
         /*
          * // Parse exponentDigits else if (nodeName.equals("exponentDigits"))
          * { }
          */
         // Unknown element
         else
         {
            this.logger
               .warn("fr.gael.drb.impl.sdf.Descriptor.parseNumericFormat() : "
                     + "Unknown element \"" + nodeName + "\", ignored.");
         }
      }

      return format;
   }

   /**
    * Parse a "dateFormat" node.
    * 
    * @param node The node to parse.
    * @return The DateFormat
    */
   private DateTimeFormat parseDateFormat(final DrbNode node)
   {
      this.logger.debug("parseDateTimeFormat()");
      // Local declaration
      final DrbNode nodeChild; // Current node child
      final String nodeName; // Current node name
      int nbAttribute; // Number of attributes
      DrbAttributeList attributeList; // Attribute list of the node
      DrbAttribute attribute; // Current attribute
      Value attributeValue = null; // Attribute value

      DateTimeFormat format = new DateTimeFormat();

      // Get attribute list
      nbAttribute = 0;
      attributeList = node.getAttributes();

      // Case of attributes
      if ((attributeList != null)
            && ((nbAttribute = attributeList.getLength()) > 0))
      {
         // Loop on attributes
         for (int j = 0; j < nbAttribute; j++)
         {
            // Get current attribute
            attribute = attributeList.item(j);
            // Case of "query" attribute
            if (attribute.getName().equals("pattern"))
            {
               try
               {
                  // Get attribute value and return if null
                  if ((attributeValue = attribute.getValue()) == null)
                  {
                     this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseDateFormat() : "
                              + "Pattern attribute value is null.");
                     throw new StaticException(
                        "fr.gael.drb.impl.sdf.Descriptor.parseDateFormat() : "
                              + "Pattern attribute value is null.");
                  }
                  // Extract pattern from attribute value
                  format = new DateTimeFormat(attributeValue.toString());
               }
               catch (final ClassCastException e)
               {
                  this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseDateFormat() : "
                           + "Error while extracting pattern attribute"
                           + " value (" + attributeValue + ").");
                  this.logger.error("   " + e);
                  throw new StaticException(
                     "Error while extracting pattern attribute" + " value ("
                           + attributeValue + ").");
               }
            }
            // Unknown attribute
            else
            {
               this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parseDateFormat() : "
                        + "Unknown attribute (" + attribute.getName() + ").");
            }
         }
      }

      return format;
   }

   /**
    * Parse a "occurrence" node.
    * 
    * @param node The node to parse.
    * @return The occurrenceCount attribute.
    */
   private PhysicalAttribute parseOccurrence(final DrbNode node)
      throws StaticException
   {
      this.logger.debug("parseOccurrence()");
      // Local declaration
      final PhysicalAttribute occurrenceCount =
         new PhysicalAttribute(PhysicalAttribute.READ_ONLY);
      int nbAttribute; // Number of attributes
      DrbAttributeList attributeList; // Attribute list of the node
      DrbAttribute attribute; // Current attribute
      int occurrence; // Occurrence
      Value nodeValue = null; // Node value
      Value attributeValue = null; // Attribute value
      String occurrenceCountQuery = null;
      boolean occurrenceCountQueryConstant = true;

      // Get attribute list
      nbAttribute = 0;
      attributeList = node.getAttributes();

      // Case of attributes
      if ((attributeList != null)
            && ((nbAttribute = attributeList.getLength()) > 0))
      {
         // Loop on attributes
         for (int j = 0; j < nbAttribute; j++)
         {
            // Get current attribute
            attribute = attributeList.item(j);

            // Case of "query" occurrence attribute
            if (attribute.getName().equals("query"))
            {
               try
               {
                  // Get attribute value and return if null
                  if ((attributeValue = attribute.getValue()) == null)
                  {
                     this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence() : "
                              + "Occurrence query attribute value is null.");
                     throw new StaticException(
                        "Occurrence query attribute value is null.");
                  }
                  // Extract occurrence from attribute value
                  occurrenceCountQuery = attributeValue.toString();
                  this.logger.debug("   occurrenceCountQuery=["
                        + occurrenceCountQuery + "]");
                  occurrenceCount.setQuery(occurrenceCountQuery);
                  occurrenceCount.setAccessType(PhysicalAttribute.READ_WRITE);
               }
               catch (final ClassCastException e)
               {
                  this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence() : "
                           + "Error while extracting occurrence query attribute"
                           + " value (" + attributeValue + ").");
                  this.logger.error("   " + e);
                  throw new StaticException(
                     "Occurrence query attribute value is null.");
               }
            }
            else
            // Case of "context" occurrence attribute
            if (attribute.getName().equals("context"))
            {
               // Sets the length unit
               final short query_context = parseContext(attribute);
               occurrenceCount.setQueryContext(query_context);
            }
            // Case of "constant" occurrence attribute
            else if (attribute.getName().equals("constant"))
            {
               try
               {
                  // Get attribute value and return if null
                  if ((attributeValue = attribute.getValue()) == null)
                  {
                     this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence():"
                              + "Occurrence constant attribute value is null.");
                     throw new StaticException(
                        "Occurrence constant attribute value is null.");
                  }
                  // Extract attribute value
                  if (attributeValue.toString().equals("false"))
                  {
                     occurrenceCountQueryConstant = false;
                  }
                  else
                  {
                     occurrenceCountQueryConstant = true;
                  }
               }
               catch (final ClassCastException e)
               {
                  this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence() : "
                           + "Error while extracting occurrence constant "
                           + " attribute value (" + attributeValue + ").");
                  this.logger.error("   " + e);
                  throw new StaticException(
                     "Error while extracting occurrence constant "
                           + " attribute value (" + attributeValue + ").");
               }
            }

            // Case of "parent" occurrence attribute
            else if (attribute.getName().equals("parent"))
            {
               this.logger
                  .warn("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence():"
                        + "Occurrence parent attribute is deprecated.");
            }

            // Unknown attribute
            else
            {
               this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence() : "
                        + "Unknown occurrence attribute name ("
                        + attribute.getName() + ").");
               throw new StaticException("Unknown occurrence attribute name ("
                     + attribute.getName() + ").");
            }
         }
         if (occurrenceCountQueryConstant)
         {
            occurrenceCount.setOccurrenceType(PhysicalAttribute.SINGLE);
         }
         else
         {
            occurrenceCount.setOccurrenceType(PhysicalAttribute.MULTIPLE);
         }
      }
      // Case of no attribute, a value is expected
      else
      {
         try
         {
            // Get node value and return if null
            if ((nodeValue = node.getValue()) == null)
            {
               this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence() : "
                        + "Occurrence value is null.");
               throw new StaticException("Occurrence value is null.");
            }
            final String node_string = nodeValue.toString().trim();
            // Extract occurrence from node value
            if (node_string.equals("unbounded"))
            {
               occurrence = -1;
               occurrenceCount.setAccessType(PhysicalAttribute.READ_WRITE);
               occurrenceCount.setOccurrenceType(PhysicalAttribute.MULTIPLE);
            }
            else
            {
               occurrence = java.lang.Integer.parseInt(node_string);
               occurrenceCount.setAccessType(PhysicalAttribute.READ_ONLY);
               occurrenceCount.setOccurrenceType(PhysicalAttribute.SINGLE);
               occurrenceCount.setValue(occurrence);
            }
         }
         // Value extraction problem
         catch (final ClassCastException e)
         {
            this.logger
               .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence() : "
                     + "Error while extracting occurrence value (" + nodeValue
                     + ").");
            this.logger.error("   " + e);
            throw new StaticException(
               "fr.gael.drb.impl.sdf.Descriptor.parseOccurrence() : "
                     + "Error while extracting occurrence value (" + nodeValue
                     + ").");
         }
      }

      // Debug information
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("   " + "query="
               + (occurrenceCountQuery != null ? true : false) + ", constant="
               + occurrenceCountQueryConstant + ", occurrence="
               + occurrenceCount);
      }
      occurrenceCount.setSpecified(true);

      // Value is extracted
      return occurrenceCount;
   }

   /**
    * Parse the "occurrence" from a particle.
    * 
    * @param particle The particle to parse.
    * @return The occurrenceCount attribute.
    */
   private PhysicalAttribute parseOccurrence(final XsdParticle particle)
      throws StaticException
   {
      this.logger.debug("parseOccurrence()");
      // Local declaration
      final PhysicalAttribute occurrenceCount =
         new PhysicalAttribute(PhysicalAttribute.READ_ONLY);

      // Case of minOccurs = maxOccurs
      if (particle.getMinOccurs() == particle.getMaxOccurs())
      {
         occurrenceCount.setOccurrenceType(PhysicalAttribute.SINGLE);
         occurrenceCount.setValue((long) particle.getMinOccurs());
      }
      else
      {
         occurrenceCount.setAccessType(PhysicalAttribute.READ_WRITE);
      }

      // Value is extracted
      return occurrenceCount;
   }

   /**
    * Parse the "occurrence" from a xs:list.
    * 
    * @param particle The particle to parse.
    * @return The occurrenceCount attribute.
    */
   private PhysicalAttribute parseOccurrence(final XsdListType list_type)
      throws StaticException
   {
      this.logger.debug("parseOccurrence()");
      // Local declaration
      final PhysicalAttribute occurrenceCount =
         new PhysicalAttribute(PhysicalAttribute.READ_ONLY);

      Value list_length = null;
      final XsdFacet[] list_facets = list_type.getFacets();

      if (list_facets != null)
      {
         for (int i = 0; i < list_facets.length; i++)
         {
            if (list_facets[i] instanceof fr.gael.drb.xsd.XsdLengthFacet)
            {
               list_length = list_facets[i].getValue();
            }
         }
      }

      if (list_length != null)
      {
         occurrenceCount.setOccurrenceType(PhysicalAttribute.SINGLE);
         occurrenceCount.setValue(((Numeric) list_length).longValue());
      }
      else
      {
         occurrenceCount.setAccessType(PhysicalAttribute.READ_WRITE);
      }

      // Value is extracted
      return occurrenceCount;
   }

   /**
    * Parse a "padding" node. TBF: unit management (byte and bit)
    * 
    * @param descriptor The descriptor.
    * @param node The node to parse.
    */
   private void parsePadding(final Descriptor descriptor, final DrbNode node)
   {
      this.logger.debug("parsePadding()");
      // Local declaration
      int padding; // Padding
      int nbAttribute; // Number of attributes
      DrbAttributeList attributeList; // Attribute list of the node
      DrbAttribute attribute; // Current attribute
      Value nodeValue = null; // Node value
      Value attributeValue = null; // Attribute value
      String content = ""; // Content string
      boolean innerType = false; // True if padding type is inner
      boolean leftType = false; // True if padding type is left

      // Get attribute list
      nbAttribute = 0;
      attributeList = node.getAttributes();

      // If no attribute exists, do not consider the padding node
      if ((attributeList == null)
            || ((nbAttribute = attributeList.getLength()) == 0))
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
               + "Missing padding attribute.");
         return;
      }
      // Loop on attributes
      for (int j = 0; j < nbAttribute; j++)
      {
         // Get current attribute
         attribute = attributeList.item(j);
         // Case of "type" padding attribute
         if (attribute.getName().equals("type"))
         {
            try
            {
               // Get attribute value and return if null
               if ((attributeValue = attribute.getValue()) == null)
               {
                  this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                           + "Padding type attribute value is null.");
                  return;
               }
               // Get node value and return if null
               if ((nodeValue = node.getValue()) == null)
               {
                  this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                           + "Padding value is null.");
                  return;
               }
               final String node_string = node.getValue().toString().trim();
               // Extract padding from node value
               padding = java.lang.Integer.parseInt(node_string);
               // Case of "header" padding
               if (attributeValue.toString().equals("header"))
               {
                  // Set header padding properties
                  innerType = false;
                  leftType = true;
                  descriptor.headerPadding.length += padding;
               }
               // Case of "footer" padding
               else if (attributeValue.toString().equals("footer"))
               {
                  // Set footer padding properties
                  innerType = false;
                  leftType = false;
                  descriptor.footerPadding.length += padding;
               }
               else
               // Case of "leading"
               if (attributeValue.toString().equals("leading"))
               {
                  // Set header padding properties
                  innerType = true;
                  leftType = true;
                  descriptor.leading.length += padding;
               }
               // Case of "trailing" padding
               else if (attributeValue.toString().equals("trailing"))
               {
                  // Set footer padding properties
                  innerType = true;
                  leftType = false;
                  descriptor.trailing.length += padding;
               }
               // Case of unknown attribute value
               else
               {
                  this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                           + "Unknown padding attribute value ("
                           + attributeValue + ").");
                  return;
               }
            }
            // Value extraction problem
            catch (final ClassCastException e)
            {
               this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                        + "Error while extracting padding value (" + nodeValue
                        + ").");
               this.logger.error("   " + e);
               return;
            }
         }
         // Case of "content" padding attribute
         else if ("content".equals(attribute.getName()))
         {
            try
            {
               // Get attribute value and return if null
               if ((attributeValue = attribute.getValue()) == null)
               {
                  this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                           + "Padding content attribute value is null.");
                  return;
               }
               // Store content string
               content = attributeValue.toString();
            }
            // Value extraction problem
            catch (final ClassCastException e)
            {
               this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                        + "Error while extracting padding content value ("
                        + nodeValue + ").");
               this.logger.error("   " + e);
               return;
            }
         }
         // Case of "code" padding attribute
         else if (attribute.getName().equals("code"))
         {
            try
            {
               // Get attribute value and return if null
               if ((attributeValue = attribute.getValue()) == null)
               {
                  this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                           + "Padding content attribute value is null.");
                  return;
               }
               // Store content string
               content =
                  Character.toString((char) Integer.parseInt(attributeValue
                     .toString()));
            }
            // Value extraction problem
            catch (final ClassCastException e)
            {
               this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                        + "Error while extracting padding code value ("
                        + nodeValue + ").");
               this.logger.error("   " + e);
               return;
            }
         }
         // Case of unknown attribute name
         else
         {
            this.logger
               .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                     + "Unknown padding attribute name (" + attribute.getName()
                     + ").");
            return;
         }
      } // End of loop on padding attributes

      // At this step padding type is known
      if (innerType)
      {
         if (leftType)
         {
            descriptor.leading.content = content;
         }
         else
         {
            descriptor.trailing.content = content;
         }
      }
      else
      {
         if (leftType)
         {
            descriptor.headerPadding.content = content;
         }
         else
         {
            descriptor.footerPadding.content = content;
         }
      }
   }

   /**
    * Parse a "annotation" node.
    * 
    * @param descriptor The descriptor.
    * @param node The node to parse.
    */
   private void parseAnnotation(final Descriptor descriptor, final DrbNode node)
   {
      this.logger.debug("parseAnnotation()");
      // Local declaration
      DrbNode nodeChild; // Current node child

      // Loop on annotation children nodes
      for (int i = 0; i < node.getChildrenCount(); i++)
      {
         // Get current node child
         nodeChild = node.getChildAt(i);

         // Parse documentation
         if ("documentation".equals(nodeChild.getName()))
         {
            descriptor.documentation = this.parseDocumentation(nodeChild);
         }
      }
   }

   /**
    * Parse a "documentation" node.
    * 
    * @param node The node to parse.
    * @return the documentation
    */
   private String parseDocumentation(final DrbNode node)
   {
      this.logger.debug("parseDocumentation()");
      // Local declaration
      Value nodeValue = null; // Node value
      final String tmpString; // Extracted string
      try
      {
         // Get node value and return if null
         if ((nodeValue = node.getValue()) != null)
         {
            // extract offset from node value
            return nodeValue.toString();
         }
      }
      // Value extraction problem
      catch (final ClassCastException e)
      {
         this.logger
            .error("fr.gael.drb.impl.sdf.Descriptor.parseDocumentation() : "
                  + "Error while extracting documentation value (" + nodeValue
                  + ").");
         this.logger.error("   " + e);
         throw new StaticException(
            "fr.gael.drb.impl.sdf.Descriptor.parseDocumentation() : "
                  + "Error while extracting documentation value (" + nodeValue
                  + ").");
      }
      // Value not extracted
      return null;
   }

   /**
    * Parse a "view" node.
    * 
    * @param descriptor The descriptor.
    * @param nodes The nodes to parse.
    * @return the documentation
    */
   private void parseView(final Descriptor descriptor, final DrbNodeList nodes)
   {
      this.logger.debug("parseView()");
      if (nodes == null)
      {
         return;
      }
      try
      {
         for (int i = 0; i < nodes.getLength(); i++)
         {
            if ("view".equals(nodes.getItem(i).getName()))
            {
               this.logger.debug("ParseView " + descriptor.getName());
               descriptor.viewDesc =
                  new SdfViewDescriptor(descriptor.getSchema());
            }
         }
      }
      // View extraction problem
      catch (final ClassCastException e)
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor.parseView() : "
               + "Error while parsing view description (" + ").");
         this.logger.error("   " + e);
         throw new StaticException(
            "fr.gael.drb.impl.sdf.Descriptor.parseView() : "
                  + "Error while parsing view description (" + ").");
      }
   }

   /**
    * Parse a "offset" node.
    * 
    * @param node The node to parse.
    * @return the offset attribute.
    */
   private static OffsetAttribute parseOffset(final DrbNode node)
   {
      logger.debug("parseOffset()");
      // Local declaration
      OffsetAttribute block_offset;
      block_offset = new OffsetAttribute(PhysicalAttribute.READ_WRITE);
      block_offset.setSpecified(true);

      Value nodeValue = null; // Node value
      int nbAttribute; // Number of attributes
      DrbAttributeList attributeList; // Attribute list of the node
      DrbAttribute attribute; // Current attribute
      Value attributeValue = null; // Attribute value
      String lengthQuery = null; // length query
      boolean lengthQueryDefined; // True if a length query is defined
      short offset_origin = OffsetAttribute.ORIGIN_PREVIOUS;

      // Get attribute list
      nbAttribute = 0;
      attributeList = node.getAttributes();

      // By default offset unit is byte and no query has been defined
      block_offset.setUnit(LengthAttribute.UNIT_BYTE);
      lengthQueryDefined = false;

      // Case of attributes
      if ((attributeList != null)
            && ((nbAttribute = attributeList.getLength()) > 0))
      {
         // Loop on attributes
         for (int j = 0; j < nbAttribute; j++)
         {
            // Get current attribute
            attribute = attributeList.item(j);
            // Case of "origin" occurrence attribute
            if (attribute.getName().equals("origin"))
            {
               // Sets the offset origin
               offset_origin = parseOrigin(attribute);
            }
            else
            // Case of "unit" occurrence attribute
            if (attribute.getName().equals("unit"))
            {
               // Sets the length unit
               final short unit = parseUnit(attribute);
               block_offset.setUnit(unit);
            }
            else
            // Case of "context" occurrence attribute
            if (attribute.getName().equals("context"))
            {
               // Sets the length unit
               final short query_context = parseContext(attribute);
               block_offset.setQueryContext(query_context);
            }
            // Case of "query" attribute
            else if (attribute.getName().equals("query"))
            {
               try
               {
                  // Get attribute value and return if null
                  if ((attributeValue = attribute.getValue()) == null)
                  {
                     logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseOffset() : "
                              + "Length query attribute value is null.");
                     return null;
                  }
                  // Extract length query from attribute value
                  lengthQuery = attributeValue.toString();
                  lengthQueryDefined = true;
               }
               catch (final ClassCastException e)
               {
                  logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseOffset() : "
                           + "Error while extracting length query attribute"
                           + " value (" + attributeValue + ").");
                  logger.error("   " + e);
                  throw new StaticException(
                     "fr.gael.drb.impl.sdf.Descriptor.parseOffset() : "
                           + "Error while extracting length query attribute"
                           + " value (" + attributeValue + ").");
               }
            }
            // Case of "constant" occurrence attribute
            else if (attribute.getName().equals("constant"))
            {
               try
               {
                  // Get attribute value and return if null
                  if ((attributeValue = attribute.getValue()) == null)
                  {
                     logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseOffset():"
                              + "Offset constant attribute value is null.");
                     throw new StaticException(
                        "Offset constant attribute value is null.");
                  }
                  // Extract attribute value
                  if (attributeValue.toString().equals("false"))
                  {
                     block_offset.setOccurrenceType(PhysicalAttribute.MULTIPLE);
                  }
                  else if (attributeValue.toString().equals("true"))
                  {
                     block_offset.setOccurrenceType(PhysicalAttribute.SINGLE);
                  }
                  else
                  {
                     logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseOffset():"
                              + "Offset constant attribute value is invalid."
                              + " value='" + attributeValue.toString() + "'");
                     throw new StaticException(
                        "Offset constant attribute value is invalid.");
                  }
               }
               catch (final ClassCastException e)
               {
                  logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseOffset() : "
                           + "Error while extracting offset.constant "
                           + " attribute value (" + attributeValue + ").");
                  logger.error("   " + e);
                  throw new StaticException(
                     "Error while extracting offset.constant "
                           + " attribute value (" + attributeValue + ").");
               }
            }
            // Unknown attribute
            else
            {
               logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parseOffset() : "
                        + "Unknown length attribute (" + attribute.getName()
                        + ").");
               throw new StaticException(
                  "fr.gael.drb.impl.sdf.Descriptor.parseOffset() : "
                        + "Unknown length attribute (" + attribute.getName()
                        + ").");
            }
         }
      }

      try
      {
         block_offset.setOrigin(offset_origin);
         if (lengthQueryDefined)
         {
            block_offset.setQuery(lengthQuery);
         }
         else
         // Get node value and return if null
         if ((nodeValue = node.getValue()) == null)
         {
            logger.error("fr.gael.drb.impl.sdf.Descriptor.parseOffset() : "
                  + "Offset value is null.");
            throw new StaticException("Offset value is null.");
         }
         else
         {
            final String node_string = node.getValue().toString().trim();
            final long valueLength = java.lang.Long.parseLong(node_string);
            // extract offset from node value and consider as additional offset
            block_offset.setAccessType(PhysicalAttribute.READ_ONLY);
            block_offset.setOccurrenceType(PhysicalAttribute.SINGLE);
            // Case of bit unit
            switch (block_offset.getUnit())
            {
               case LengthAttribute.UNIT_BIT:
                  // Keep fixed values (no need for key to set value)
                  block_offset.setLength(null, new Length(0, valueLength));
                  break;
               // Default : Case of byte unit
               case LengthAttribute.UNIT_BYTE:
                  block_offset.setLength(null, new Length(valueLength));
                  break;
            }
         }
      }
      // Value extraction problem
      catch (final ClassCastException e)
      {
         logger.error("fr.gael.drb.impl.sdf.Descriptor.parseOffset() : "
               + "Error while extracting offset value (" + nodeValue + ").");
         logger.error("   " + e);
         throw new StaticException(
            "fr.gael.drb.impl.sdf.Descriptor.parseOffset() : "
                  + "Error while extracting offset value (" + nodeValue + ").");
      }
      // Value is extracted
      return block_offset;
   }

   /**
    * Parse external children node to find "drb:block" information and set it.
    * Used by constructor to extract length, padding, offset information from
    * the "drb:block" node attached to the element or the structure. The padding
    * values are added to themselves in order to sum the padding defined from
    * the complex type and the one from the element.
    * 
    * @param descriptor The descriptor.
    * @param node The schema node descriptor.
    */
   private void parseExternalChildren(final Descriptor descriptor,
      final XsdElement node)
   {
      try
      {
         // Parse XS particle attributes
         if (!this.defaultVersion.equals(this.SDF_2002_02_NAMESPACE))
         {
            this.logger.debug(descriptor.getName() + ": Parse XS particle");
            descriptor.occurrenceCount = this.parseOccurrence(node);
         }

         // Parse array external children list
         this.logger.debug(descriptor.getName()
               + ": Parse array external children");
         final XsdType node_type = node.getType();
         
         // Set node value type
         XsdSimpleType value_type = null;

         if (node_type != null)
         {
            value_type = node_type.getDatatype();
         }

         if (!this.defaultVersion.equals(this.SDF_2002_02_NAMESPACE))
         {
            if ((value_type != null)
                  && (value_type.getVariety() == XsdSimpleType.LIST_VARIETY))
            {
               // Parse XS list facet
               descriptor.itemCount =
                  this.parseOccurrence((XsdListType) value_type);
               
               // Parse XS list attributes
               this.parseArrayExternalChildren(descriptor, node.getName(),
                  ((XsdListType) value_type).getItemType().getExternalNodes());
            }
         }

         this.parseView(descriptor, node.getExternalNodes());

         // Parse structure external children list
         if (descriptor.viewDesc != null)
         {
            this.logger.debug("Parse view/structure external children");
            if (descriptor.viewDesc.baseType != null)
            {
               this.parseExternalChildren(descriptor, node.getName(),
                  descriptor.viewDesc.baseType.getExternalNodes());
            }
         }
         else
         {
            this.logger.debug("Parse structure external children");
            this.parseExternalChildren(descriptor, node.getName(), node_type
               .getExternalNodes());
         }

         // Parse node external children list
         this.logger.debug("Parse node external children");
         this.parseExternalChildren(descriptor, node.getName(), node
            .getExternalNodes());

         // Check occurrence consistency
         if ((descriptor.occurrenceCount.getValue() >= 0)
               && ((node.getMinOccurs() > descriptor.occurrenceCount.getValue()) || (node
                  .getMaxOccurs() < descriptor.occurrenceCount.getValue())))
         {
            this.logger.error("The occurrence of " + descriptor.getPath()
                  + " is not consistent with the element definition.");
         }
      }
      catch (final StaticException e)
      {
         throw new StaticException("Cannot parse definition for element '"
               + descriptor.getPath() + "' : " + e.getMessage());
      }
   }

   /**
    * Parse external children node to find "drb:block" information and set it.
    * Used by constructor to extract length, padding, offset information from
    * the "drb:block" node attached to the element or the structure. The padding
    * values are added to themselves in order to sum the padding defined from
    * the complex type and the one from the element.
    * 
    * @param descriptor The descriptor.
    * @param parsed_node_name The name of the node, used for error messages.
    * @param external_children The external children node list.
    */
   private void parseExternalChildren(final Descriptor descriptor,
      final String parsed_node_name, final DrbNodeList external_children)
   {
      this.logger.debug("parseExternalChildren(" + parsed_node_name + ")");
      // Local declaration
      DrbNode nodeChild; // Current node child
      String nodeName; // Current node child name

      // Case of no external node, return without setting other values
      if (external_children == null)
      {
         return;
      }

      // Loop on external children nodes
      for (int i = 0; i < external_children.getLength(); i++)
      {
         // Get current node child
         nodeChild = external_children.item(i);
         nodeName = nodeChild.getName();

         // Parse block
         if (nodeName.equals("block"))
         {
            this.parseBlock(descriptor, nodeChild);

            // Specific case of 2002-02-22
            if (this.SDF_2002_02_NAMESPACE.equals(nodeChild.getNamespaceURI()))
            {
               // Numeric elements with multiple occurrence count are promoted
               // to array
               if ((descriptor.getType().getDatatype() != null)
                     && ((descriptor.occurrenceCount.getAccessType() == PhysicalAttribute.READ_WRITE) || (descriptor.occurrenceCount
                        .getValue() > 1)))
               {
                  int array_type = descriptor.valueType;
                  if (descriptor.valueType == Value.ARRAY_ID)
                  {
                     array_type = descriptor.arrayValueType;
                  }
                  else
                  {
                     this.logger.warn(descriptor.getPath()
                           + " considered as array. "
                           + "Use the <array> definition within '"
                           + AbstractBlock.SDF_NAMESPACE
                           + "' namespace to avoid this warning.");
                  }
                  descriptor.arrayValueType = array_type;
                  descriptor.valueType = Value.ARRAY_ID;
                  descriptor.itemCount = descriptor.occurrenceCount;
                  descriptor.itemLength = descriptor.contentLength;
                  // Set default value
                  descriptor.occurrenceCount =
                     new PhysicalAttribute(PhysicalAttribute.READ_ONLY);
                  descriptor.occurrenceCount
                     .setOccurrenceType(PhysicalAttribute.SINGLE);
                  descriptor.occurrenceCount.setValue(1);
                  descriptor.contentLength =
                     new LengthAttribute(PhysicalAttribute.READ_WRITE);
               }
            }
            // Specific case of 2004-12
            else if (this.SDF_2004_12_NAMESPACE.equals(nodeChild
               .getNamespaceURI()))
            {
            }
            // Specific case of 2005-04
            else if (this.SDF_2005_04_NAMESPACE.equals(nodeChild
               .getNamespaceURI()))
            {
            }
            else if (nodeChild.getNamespaceURI() != null)
            {
               this.logger.error(descriptor.getPath()
                     + ": invalid SDF namespace(uri="
                     + nodeChild.getNamespaceURI() + ")");
               throw new StaticException(descriptor.getPath()
                     + ": invalid SDF namespace(uri="
                     + nodeChild.getNamespaceURI() + ")");
            }
         }

         // Parse annotation
         else if (nodeName.equals("annotation"))
         {
            this.parseAnnotation(descriptor, nodeChild);
         }
      }
   }

   /**
    * Parse array external nodes to find "drb:block" information and set it.
    * Used by constructor to extract length, padding, offset information from
    * the "drb:block" node attached to the itemType.
    * 
    * @param descriptor The descriptor.
    * @param parsed_node_name The name of the node, used for error messages.
    * @param external_children The external children node list.
    * @return boolean
    */
   private void parseArrayExternalChildren(final Descriptor descriptor,
      final String parsed_node_name, final DrbNodeList external_children)
   {
      this.logger.debug("parseArrayExternalChildren(" + parsed_node_name + ")");
      // Local declaration
      DrbNode nodeChild; // Current node child
      String nodeName; // Current node child name

      // Case of no external node, return without setting other values
      if (external_children == null)
      {
         return;
      }

      // Loop on external children nodes
      for (int i = 0; i < external_children.getLength(); i++)
      {
         // Get current node child
         nodeChild = external_children.item(i);
         nodeName = nodeChild.getName();

         // Parse block
         if ("block".equals(nodeName))
         {
            this.parseArrayBlock(descriptor, nodeChild);
         }

         // Parse annotation
         else if ("annotation".equals(nodeName))
         {
            this.parseAnnotation(descriptor, nodeChild);
         }
      }
   }

   /**
    * Makes the class runnable for testing.
    * 
    * @param args main arguments
    */
   public static void main(final String[] args)
   {
      final DrbNode base_node = fr.gael.drb.DrbFactory.open(args[0]);
      final DrbNode schema_node =
         fr.gael.drb.DrbFactory.open(args[1]).getFirstChild();

      final SdfFactory sdffactory = new SdfFactory();
      final DrbNode node =
         sdffactory.open(base_node, schema_node, schema_node.getParent()
            .getPath());
      System.err.println("node " + node.getName());
   }
} // SdfFactory
