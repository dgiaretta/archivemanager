/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl;

import java.util.Hashtable;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.meta.DrbDefaultMetadata;
import fr.gael.drb.meta.DrbMetadata;
import fr.gael.drb.meta.DrbMetadataResolver;

/**
 * Standard Metadata Resolver.
 */
public class DrbDefaultMetadataResolver implements DrbMetadataResolver
{
   /**
    * A logger for this class.
    */
   private static Logger logger =
      Logger.getLogger(DrbDefaultMetadataResolver.class);

   /**
    * A register of item extensions. This register is a map of item extensions
    * to a implementation identifier.
    */
   static private Hashtable<String, String> extensionHash =
      new Hashtable<String, String>();

   static
   {
      // Statically Known extensions
      extensionHash.put("xsl", "xml");
      extensionHash.put("rdf", "xml");
      extensionHash.put("owl", "xml");
      extensionHash.put("gml", "xml");
      extensionHash.put("xml", "xml");
      extensionHash.put("xsd", "xml");
   }

   /**
    * A schema location register. The hash map is a series of schema locations
    * identified by the name extension of the matching items.
    */
   static private Hashtable<String, String> schemaHash =
      new Hashtable<String, String>();

   /**
    * Allow to get a hashtable containing mapping between extension and
    * implementations.
    * Note that the returned hashtable is a copy of the internal hashtable,
    * therefore the class behaviour can not be altered throw this returned 
    * instance.
    *
    * @return a copy of the internal hashtable containing mapping between
    * extension and implementations.
    */
   public static Hashtable<String, String> getExtensionHash()
   {
      return (Hashtable<String, String>)extensionHash.clone();
   }

   /**
    * Allow to get a hashtable containing mapping between extension and schemas.
    * Note that the returned hashtable is a copy of the internal hashtable,
    * therefore the class behaviour can not be altered throw this returned 
    * instance.
    *
    * @return a copy of the internal hashtable containing mapping between
    * extension and schemas.
    */
   public static Hashtable<String, String> getSchemaHash()
   {
      return (Hashtable<String, String>)schemaHash.clone();
   }

   /**
    * Resolve a specific implementation by its identifier. This methods uses the
    * given item name extension i.e. the trailing characters next to the last
    * period, to retrieve a corresponding implementation name. If the given name
    * does not contain any period, this method returns <code>null</code>. If
    * the extension does not match any entry of the internal registers, the this
    * method returns <code>null</code>.
    * <p>
    * Should the implementation be identified, the output
    * {@link fr.gael.drb.meta.DrbMetadata} object accept the
    * <code>implementationIdentifier</code> property, that is assigned with
    * the identifier retrieved from this class internal register. See
    * {@link #registerItemNameExtension(String, String)} for further information
    * about augmenting the internal extension register.
    * </p>
    * <p>
    * Should the given item name extension also match an entry of the schema
    * location register, the output {@link fr.gael.drb.meta.DrbMetadata} object
    * also accept a <code>schemaLocation</code> property that locates an XML
    * Schema document on the file system corresponding to any item with this
    * extension. <b>Warning</b>: this class is not responsible in verifying if
    * an actual XML Schema document exists at the given location. See
    * {@link #registerSchemaLocation(String, String)} for further information
    * about augmenting the internal schema location register.
    * </p>
    * 
    * @param item_name the name of the item from with the requested metadata
    *           should derive.
    * @return the metadata object matching the given item name.
    * @throws NullPointerException if the given item name is null.
    */
   public DrbMetadata resolveMetadata(final String item_name)
         throws NullPointerException
   {
      // Check input parameter
      if (item_name == null)
      {
         throw new NullPointerException(
               "Cannot get metadata object from a null item name.");
      }

      logger.debug("Resolving metadata for item: " + item_name);

      // Get default implementation from the item-name extension
      String extension = null;

      if (item_name.lastIndexOf(".") >= 0)
      {
         extension = item_name.substring(item_name.lastIndexOf(".") + 1);
         extension = extension.toLowerCase();
      }
      else
      {
         logger.debug("No extension found for item name \"" + item_name + "\"");
         return null;
      }

      logger.debug("Found extension \"" + extension + "\" for item name \""
            + item_name + "\"");

      // Get implementation identifier from extension register
      final String implementation_identifier = extensionHash.get(extension);

      // Get Schema location from corresponding register
      final String schema_location = schemaHash.get(extension);

      // Return immediately if both properties are null
      if ((implementation_identifier == null) && (schema_location == null))
      {
         logger.debug("No implementation nor schema location for item name \""
               + item_name + "\"");
         return null;
      }

      // Create output metadata object
      final DrbDefaultMetadata metadata = new DrbDefaultMetadata("", "");

      // Assign implementation identifier property that matches exactly the item
      // name extension
      if (implementation_identifier != null)
      {
         logger.debug("Adding \"implementationIdentifier\" property: \""
               + implementation_identifier + "\"");

         metadata.setProperty("implementationIdentifier",
               new fr.gael.drb.value.String(implementation_identifier));
      }

      // Assign the schema location property if the extension matches an entry
      // of the corresponding schema location register
      if (schema_location != null)
      {
         logger.debug("Adding \"schemaLocation\" property: \""
               + schema_location + "\"");

         metadata.setProperty("schemaLocation", new fr.gael.drb.value.String(
               schema_location));
      }

      // Return the metadata object
      return metadata;
   } // End resolveMetadata(String)

   /**
    * Resolve the metadata from a single item.
    * 
    * @param item The single item
    * @return The metadata associated to the resource.
    */
   public DrbMetadata resolveMetadata(final DrbItem item)
   {
      if (item == null)
      {
         return null;
      }

      DrbDefaultMetadata meta =
         (DrbDefaultMetadata) this.resolveMetadata(item.getName());

      if (item instanceof DrbNode)
      {
         final DrbNode node = (DrbNode) item;
         final DrbAttributeList attrs = node.getAttributes();

         if (attrs != null)
         {
            for (int i = 0; i < attrs.getLength(); i++)
            {
               final DrbAttribute attr = attrs.item(i);
               if (meta == null)
               {
                  meta = new DrbDefaultMetadata("", "");
               }
               meta.setProperty(attr.getName(), attr.getValue());
            }
         }
      }

      return meta;
   }

   /**
    * Resolve the metadata from a sequence.
    * 
    * @param sequence The sequence
    * @return The metadata associated to the ressource.
    */
   public DrbMetadata resolveMetadata(final DrbSequence sequence)
   {
      if ((sequence == null) || (sequence.getLength() != 1))
      {
         return null;
      }
      final DrbItem item = sequence.getItem(0);
      if (item == null)
      {
         return null;
      }
      return this.resolveMetadata(item.getName());
   }

   /**
    * Registers an extension. This method augments the internal register of item
    * name extensions. This register is a map of item name extensions i.e. the
    * trailing characters next to the last period of the name, to an
    * implementation identifier. It is an error to map either a
    * <code>null</code> extension or a <code>null</code> implementation
    * identifier.
    * 
    * @param extension item name extension that matches items to be attached to
    *           the given implementation.
    * @param schema_location the location path of the registered schema
    * @throws NullPointerException if one of the <code>extension</code> or the
    *            <code>implementation_identifier</code> is <code>null</code>.
    */
   public static void registerItemNameExtension(final String extension,
         final String implementation_identifier) throws NullPointerException
   {
      // Check parameters
      if (extension == null)
      {
         throw new NullPointerException("Cannot register a null extension.");
      }

      if (implementation_identifier == null)
      {
         throw new NullPointerException(
               "Cannot register a null imeplementation identifier.");
      }

      // Map extension
      extensionHash.put(extension, implementation_identifier);
   }

   /**
    * Registers a schema location path.
    * 
    * @param extension item name extension that matches items to be attached to
    *           the given schema_location.
    * @param schema_location the location path of the registered schema
    */
   public static void registerSchemaLocation(final String extension,
         final String schema_location)
   {
      schemaHash.put(extension, schema_location);
   }
} // DrbMetadataResolver
