/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbSequence;

/**
 * Wraps an Insert expression of XQuery Update Facility. The if expression
 * implement the DO/INSERT updating expression of the XQuery Update Facility.
 * This expression matches :
 * <p>
 * <code>
 * <Do> <Insert> <Expr> <Into> <Expr>
 * </code>
 * </p>
 * <p>
 * The expression following the insert keyword is called the source expression,
 * and the expressions following the into keyword is called the target
 * expression.
 * </p>
 */
class InsertExpression extends AbstractExpression
{
   /**
    * The source expression. The source expression cannot be null. The
    * evaluation of this expression provides the node to inserted.
    */
   private Expression sourceExpression = null;

   /**
    * The target expression. This expression cannot be null. The evaluation of
    * this expression provides the target node.
    */
   private Expression targetExpression = null;

   /**
    * Builds an instance of the InsertExpression. The underlying expression
    * (i.e. source, target) are reset to null.
    * 
    * @param token the token related to the current expression.
    */
   public InsertExpression(final Token token)
   {
      super("Insert", token);
   }

   /**
    * Accessor to the target expression. The parameter is not tested and the
    * reference is immeiately assigned to the target expression.
    * 
    * @param test_expression the expression to be assigned.
    */
   public void setTargetExpression(final Expression target_expression)
   {
      this.targetExpression = target_expression;
   }

   /**
    * Accessor to the sourceexpression. The parameter is not tested and the
    * reference is immediately assigned to the source expression.
    * 
    * @param source_expression the expression to be assigned.
    */
   public void setSourceExpression(final Expression source_expression)
   {
      this.sourceExpression = source_expression;
   }

   /**
    * Return the insert expression as a string. This operation overrides the
    * toString() operation of Object. The output string format is:
    * <p>
    * <code>
    * do insert <source-expression> into <target-expression>
    * </code>
    * </p>
    * <p>
    * No cariage return is inserted in the string except if the underlying
    * expressions contains one or more. The underlying expressions are printed
    * in the string using their respective toString() operations.
    * 
    * @return the conditional expression as a string.
    */
   public String toString()
   {
      return "do insert " + this.sourceExpression + " into "
            + this.targetExpression;
   }

   /**
    * Evaluates the insert expression. The evaluation context is used as outer
    * focus of the two underlying expressions. This means that the insert
    * expression context is used for the evaluation of the source expression as
    * well as for the target expression. The evaluation is performed as follow :
    * <p>
    * <b>Check source expression consitency:</b> before evaluating the
    * expression, the source and target expression shall not be null.
    * </p>
    * <p>
    * 
    * @param context the context to be considered during the evaluation. This
    *           parameter is mandatory so it is not controlled during the
    *           evaluation of the conditional expression. However, because it is
    *           directly used by the underlying expression a null context may
    *           raise an error if the expression requires a non null context.
    * @return the result of the evaluation of the insert expression is an empty
    *         sequence and a pending update list.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {

      DrbSequence output_sequence;
      /**
       * Checks the insert expression consitency.
       */
      if ((this.sourceExpression == null) || (this.targetExpression == null))
      {
         throw new DynamicException(this, "Incomplete \"insert\" declaration");
      }

      /**
       * Evaluates the target-expression
       */
      final DrbSequence target_sequence =
         this.targetExpression.evaluate(context);

      if (target_sequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the target expression");
      }

      if (target_sequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the target expression");
      }

      if (target_sequence.getLength() != 1)
      {
         throw new DynamicException(this,
               "First parameter must be a single element node "
                     + "or a single document node. Found a sequence of "
                     + target_sequence.getLength() + " item(s)");
      }

      final DrbItem target_item = target_sequence.getItem(0);

      if (target_item.getItemType() != DrbItem.NODE_ITEM)
      {
         throw new DynamicException(this,
               "First parameter is not a single element node "
                     + "or a single document node");
      }

      final DrbNode target_node = (DrbNode) target_item;

      /**
       * Check and process, should the occasion arise, the cancellation request.
       */
      if (this.isCancellationRequested() == true)
      {
         this.throwCancelException();
      }

      /**
       * Get the insertion sequence from parameter. This parameter is mandatory.
       */

      final DrbSequence content_sequence =
         this.sourceExpression.evaluate(context);

      if (content_sequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the content parameter");
      }

      /**
       * Update the target node.
       */
      for (int ichild = 0; ichild < content_sequence.getLength(); ichild++)
      {
         final DrbItem content_item = content_sequence.getItem(ichild);
         if (content_item instanceof DrbNode)
         {
            target_node.appendChild((DrbNode) content_item);
         }
      }

      /**
       * Evaluates the result (always an empty sequence).
       */
      output_sequence = new DrbDefaultSequence();

      return output_sequence;
   }

   /**
    * A expression which is constant means that it need no context item to be
    * evaluate. The returned sequence from its evaluation will always be the
    * same along the query script
    * 
    * @return true if this expression is constant
    */
   public boolean isConstant()
   {
      return false;
   }

   /**
    * Identifies expression that can modify the state of an existing node. This
    * function returns always true since 'insert' is a basic updating
    * expression.
    * 
    * @return true
    */
   public boolean isUpdating()
   {
      return true;
   }
}
