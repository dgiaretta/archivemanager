/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbSequence;
import fr.gael.drb.value.Comparison;
import fr.gael.drb.value.Value;
import fr.gael.drb.value.ValueArray;

/**
 * Wraps a general comparison ("=" | "!=" | "<" | "<=" | ">" | ">=") of the
 * XQuery language.
 */
class GeneralCompExpression extends AbstractExpression
{
   /**
    * EQUALS indicator.
    */
   protected final static int EQUALS = 0;

   /**
    * NOT_EQUALS indicator.
    */
   protected final static int NOT_EQUALS = 1;

   /**
    * LESS_THAN indicator.
    */
   protected final static int LESS_THAN = 2;

   /**
    * LESS_OR_EQUAL_TO indicator.
    */
   protected final static int LESS_OR_EQUAL_TO = 3;

   /**
    * GREATER_THAN indicator.
    */
   protected final static int GREATER_THAN = 4;

   /**
    * GREATER_OR_EQUAL_TO indicator.
    */
   protected final static int GREATER_OR_EQUAL_TO = 5;

   /**
    * Expression wrapping the left operand.
    */
   protected Expression leftOperand;

   /**
    * Expression wrapping the right operand.
    */
   protected Expression rightOperand;

   /**
    * Type of the operation of the current instance.
    */
   protected int comparison;

   /**
    * Builds a general comparison expression.
    * 
    * @param token the token related to the current expression.
    * @param left_operand the left oprand expression.
    * @param comparison indicator of the type of comparison expression.
    * @param right_operand the right oprand expression.
    */
   public GeneralCompExpression(final Token token,
         final Expression left_operand, final int comparison,
         final Expression right_operand)
   {
      super("General comparison", token);
      this.leftOperand = left_operand;
      this.comparison = comparison;
      this.rightOperand = right_operand;
   }

   /**
    * Returns a the general comparison expression as a convenient string.
    * 
    * @return the string detailing the general comparison operation.
    */
   public String toString()
   {
      String comparison_string;

      switch (this.comparison)
      {
         case EQUALS:
            comparison_string = "=";
            break;
         case NOT_EQUALS:
            comparison_string = "!=";
            break;
         case LESS_THAN:
            comparison_string = "<";
            break;
         case LESS_OR_EQUAL_TO:
            comparison_string = "<=";
            break;
         case GREATER_THAN:
            comparison_string = ">";
            break;
         case GREATER_OR_EQUAL_TO:
            comparison_string = ">=";
            break;
         default:
            comparison_string = "(unkown comparison #" + this.comparison + ")";
      }

      return this.leftOperand + " " + comparison_string + " "
            + this.rightOperand;
   }

   /**
    * Evaluates the current operation.
    * 
    * @param context the outer-focus of the evaluation.
    * @return the sequence resulting from the dynamic evaluation.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {
      /**
       * Evaluate and atomize the left operand.
       */
      final DrbSequence leftSequence = this.leftOperand.evaluate(context);

      final ValueArray leftArray = leftSequence.atomize();

      /**
       * Evaluate and atomize the right operand.
       */
      final DrbSequence rightSequence = this.rightOperand.evaluate(context);

      final ValueArray rightArray = rightSequence.atomize();

      /**
       * Perform comparison.
       */
      for (int ileft = 0; ileft < leftArray.length(); ileft++)
      {
         for (int iright = 0; iright < rightArray.length(); iright++)
         {
            // TODO: the two following seems invariable within this loop
            // they should be moved to the upper loop
            final Value leftValue = leftArray.getElement(ileft);

            if (!(leftValue instanceof fr.gael.drb.value.Comparison))
            {
               continue;
            }

            final int comparisonResult =
               ((Comparison) leftValue)
                     .compareTo(rightArray.getElement(iright));

            if ((comparisonResult < 0)
                  && ((this.comparison == this.NOT_EQUALS)
                        || (this.comparison == this.LESS_THAN) || (this.comparison == this.LESS_OR_EQUAL_TO)))
            {
               return LiteralResult.TRUE;
            }
            else if ((comparisonResult == 0)
                  && ((this.comparison == this.EQUALS)
                        || (this.comparison == this.LESS_OR_EQUAL_TO) || (this.comparison == this.GREATER_OR_EQUAL_TO)))
            {
               return LiteralResult.TRUE;
            }
            else if ((comparisonResult > 0)
                  && ((this.comparison == this.NOT_EQUALS)
                        || (this.comparison == this.GREATER_THAN) || (this.comparison == this.GREATER_OR_EQUAL_TO)))
            {
               return LiteralResult.TRUE;
            }
         }
      }

      /**
       * Return false if no couple matching the comparison has be retrieved.
       */
      return LiteralResult.FALSE;
   }

   /**
    * A expression which is constant means that it need no context item to be
    * evaluate. The returned sequence from its evaluation will always be the
    * same along the query script
    * 
    * @return true if this expression is constant
    */
   public boolean isConstant()
   {
      return (this.leftOperand.isConstant() && this.rightOperand.isConstant());
   }
}
