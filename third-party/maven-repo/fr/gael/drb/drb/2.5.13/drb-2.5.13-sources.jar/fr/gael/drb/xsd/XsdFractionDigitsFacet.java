/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import org.apache.log4j.Logger;

import fr.gael.drb.value.Int;
import fr.gael.drb.value.Numeric;
import fr.gael.drb.value.Value;

/**
 * Declaration of an XML-Schema fractionDigits Facet.
 */
public class XsdFractionDigitsFacet extends XsdFacet
{
   /**
    * Logger.
    */
   static private Logger logger =
      Logger.getLogger(XsdFractionDigitsFacet.class);

   /**
    * fractionDigits facet name.
    */
   final static String TAG = "fractionDigits";

   /**
    * The fractionDigits value.
    */
   private int value;

   /**
    * Build a fractionDigits facet.
    * 
    * @param value the maximum number of allowed digits.
    */
   XsdFractionDigitsFacet(final Value value)
   {
      this.value =
         ((fr.gael.drb.value.Int) value.convertTo(Value.INT_ID)).intValue();
   } // XsdFractionDigitsFacet

   /**
    * Identifier of this facet.
    * 
    * @return Identifier of this facet.
    */
   public final int getId()
   {
      return FRACTION_DIGITS_ID;
   } // getId

   /**
    * The fractionDigits value
    * 
    * @return The fractionDigits value
    */
   public final Value getValue()
   {
      return new Int(this.value);
   } // getValue

   /**
    * The name of this facet.
    * 
    * @return The name of this facet.
    */
   public final String getName()
   {
      return TAG;
   } // getName

   // -------------------------------------------------------
   // ValueValidator interface implementation
   // -------------------------------------------------------
   /**
    * Validates the present value.
    * 
    * @param v the value
    * @return true if this value satifies the type definition, else false
    */
   public boolean isValid(final Value v)
   {
      if (v == null)
      {
         return false;
      }
      try
      {
         switch (v.getType())
         {
            case Value.FLOAT_ID:
               logger
                     .error("fractionDigits facet is not allowed for xs:float datatype");
               return false;
            case Value.DOUBLE_ID:
               logger
                     .error("fractionDigits facet is not allowed for xs:double datatype");
               return false;
            case Value.ARRAY_ID:
               logger
                     .error("fractionDigits facet is not allowed for list datatype");
               return false;
         }
         final Numeric num = (Numeric) v.convertTo(Value.DECIMAL_ID);
         return true; //no validation
      }
      catch (final ClassCastException e)
      {
         logger.warn("fractionDigitsFacet: Cannot convert '" + v
               + "' to xs:decimal.");

         return false;
      }
   }

} // XsdFractionDigitsFacet class
