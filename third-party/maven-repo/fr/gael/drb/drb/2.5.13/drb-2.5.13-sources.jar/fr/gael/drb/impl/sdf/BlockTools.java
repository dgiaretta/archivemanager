/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sdf;

import java.io.EOFException;
import java.io.IOException;

import org.apache.log4j.Logger;

import fr.gael.drb.value.Value;

/**
 * Class utility for blocks. This class contains static operations to extract
 * values from byte and bit blocks with several encoding methods supported
 * (ASCII, Binary, IEEE, etc.).
 */
class BlockTools
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(BlockTools.class);

   /**
    * Static masks array used to remove bits when bitOffset is not 0.
    */
   static private final int[] MASK =
      { 0xff, 0x7f, 0x3f, 0x1f, 0x0f, 0x07, 0x03, 0x01 };

   /**
    * Static buffer used for value extraction.
    */
   private byte[] buffer = {};

   /**
    * Returns a long extracted from a ASCII buffer. This implementation assumes
    * that buffer is not null. It is a wrapper to extractAsciiLong(String) using
    * String(byte[]) constructor.
    * 
    * @param buffer The buffer containing the value to extract from.
    * @return The long value extracted from buffer.
    */
   protected final long extractAsciiLong(final byte[] buffer)
   {
      // Wrap to operation using String
      return this.extractAsciiLong(new String(buffer));
   }

   /**
    * Returns a long extracted from a ASCII buffer with offset and length
    * specified. This implementation assumes that buffer is not null. It is a
    * wrapper to extractAsciiLong(String) using String(byte[], int offset, int
    * length) constructor.
    * 
    * @param buffer The buffer containing the value to extract from.
    * @param offset The offset in the buffer.
    * @param length The length to use.
    * @return The long value extracted from buffer.
    */
   protected final long extractAsciiLong(final byte[] buffer, final int offset,
         final int length)
   {
      // Wrap to operation using String
      return this.extractAsciiLong(new String(buffer, offset, length));
   }

   /**
    * Returns a long extracted from a String. This implementation assumes that
    * string is not null. No exception is caught therefore NumberFormatException
    * shall be managed by the calling operation.
    */
   protected final long extractAsciiLong(final String buffer)
   {
      // Remove whitespaces from string
      String tmpStr = buffer.trim();

      // Check for "+" sign (Integer.parseInt() doesn't support a leading "+"
      // sign, only a "-" sign !) and remove it.
      if (tmpStr.startsWith("+"))
      {
         tmpStr = tmpStr.substring(1);
      }

      // Extract value from string
      return Long.parseLong(tmpStr);
   }

   /**
    * Returns a double extracted from a ASCII buffer. This implementation
    * assumes that buffer is not null. It is a wrapper to
    * extractAsciiDouble(String) using String(byte[]) constructor.
    * 
    * @param buffer The buffer containing the value to extract from.
    * @return The double value extracted from buffer.
    */
   protected final double extractAsciiDouble(final byte[] buffer)
   {
      // Wrap to operation using String
      return this.extractAsciiDouble(new String(buffer));
   }

   /**
    * Returns a double extracted from a ASCII buffer with offset and length
    * specified. This implementation assumes that buffer is not null. It is a
    * wrapper to extractAsciiDouble(String) using String(byte[], int offset, int
    * length) constructor.
    * 
    * @param buffer The buffer containing the value to extract from.
    * @param offset The offset in the buffer.
    * @param length The length to use.
    * @return The double value extracted from buffer.
    */
   protected final double extractAsciiDouble(final byte[] buffer,
         final int offset, final int length)
   {
      // Wrap to operation using String
      return this.extractAsciiDouble(new String(buffer, offset, length));
   }

   /**
    * Returns a double extracted from String. This implementation assumes that
    * string is not null. No exception is caught therefore NumberFormatException
    * shall be managed by the calling operation.
    */
   protected final double extractAsciiDouble(final String buffer)
   {
      // Remove whitespaces from string
      final String tmpStr = buffer.trim();

      // Extract value from string
      return Double.parseDouble(tmpStr);
   }

   /**
    * Returns a Value extracted from a file with a encoding method. If the file
    * is null or returns null. If encoding is not supported returns null. This
    * implementation supports the following encoding methods (defined in
    * Descriptor class) :
    * <dl>
    * <dd>ENCODING_ASCII</dd>
    * <dl>
    * ENCODING_BINARY
    * </dl>
    * </dl>
    * <dl>
    * <dt>The following exception are caught :</dt>
    * <dd>NumberFormatException
    * <dd>
    * <dd>IOException
    * <dd>
    * <dd>EOFException
    * <dd>
    * </dl>
    * In case of such exceptions returns null.
    * 
    * @param file The file containing the value to extract.
    * @param offset The offset in the file.
    * @param length The length to read in the file.
    * @param encoding The encoding method of the buffer.
    * @param value_type The value_type to return.
    * @param array_value_type The value type in array if value_type=ARRAY_ID.
    * @param array_size The array size if value_type=ARRAY_ID.
    * @param bit_offset the bit of the offset in the file
    * @param bit_length the size of the bit
    * @return The Integer extracted from buffer.
    * @throws EOFException This exception is raised when it is the end of the
    *            file
    * @throws IOException a IOExeption
    */
   protected final fr.gael.drb.value.Value extractValue(
         final RandomAccessData file, final long offset, final int bit_offset,
         final int length, final int bit_length, final int encoding,
         final int value_type, final int array_value_type, final int array_size)
         throws EOFException, IOException
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("extractValue(file, offset=" + offset + ", length="
               + length + ", bit_length=" + bit_length + ", encoding="
               + encoding + ", value_type=" + value_type
               + ", array_value_type=" + array_value_type + ", array_size="
               + array_size);
      }
      // Check parameter
      if (file == null)
      {
         return null;
      }

      int curOffset; // Current offset (for array)
      int itemLength; // Length of one array item
      int lengthRead; // Length read from file

      // Manage Exceptions
      try
      {
         // Set file pointer position
         file.seek(offset);

         // Get buffer if encoding is ASCII, if type is string, date or
         // (BINARY and array)
         if ((encoding == Descriptor.ENCODING_ASCII)
               || (value_type == Value.STRING_ID)
               || (value_type == Value.DATE_ID)
               || ((encoding == Descriptor.ENCODING_BINARY) && (value_type == Value.ARRAY_ID)))
         {
            // Read buffer from file
            this.buffer = new byte[length];
            lengthRead = length;
            file.readFully(this.buffer);

            // If read length is -1 EOF is reached
            if (lengthRead == -1)
            {
               throw new EOFException("BlockTools.extractValue(): "
                     + "Unable to read at offset " + offset);
            }
            // Other read error case
            if (lengthRead != length)
            {
               this.logger
                     .error("fr.gael.drb.impl.sdf.BlockTools.extractValue() : "
                           + "Cannot read " + length + " byte(s) from file.");
               return null;
            }
         }

         // Check if encoding is valid
         if ((encoding != Descriptor.ENCODING_ASCII)
               && (encoding != Descriptor.ENCODING_BINARY))
         {
            this.logger
                  .error("fr.gael.drb.impl.sdf.BlockTools.extractValue() : "
                        + "Encoding not supported ! (encoding=" + encoding
                        + ").");
            return null;
         }

         // Case of non 8-bit aligned structure
         if ((bit_offset > 0) || (bit_length > 0))
         {
            // Compute buffer length
            int bufferLength = length + (bit_offset + bit_length) / 8;
            if (((bit_offset + bit_length) % 8) > 0)
            {
               bufferLength += 1;
            }

            // Read buffer from file
            this.buffer = new byte[bufferLength];
            file.readFully(this.buffer);

            // Remove bit_offset using MASK (left part)
            this.buffer[0] = (byte) (this.buffer[0] & this.MASK[bit_offset]);

            // Copy buffer in a int (from the right)
            int value = 0;
            for (int i = bufferLength - 1; i >= 0; i--)
            {
               value += (this.buffer[i] & 0xff) << (8 * (bufferLength - 1 - i));
            }

            // Shift buffer to the right to align on int representation
            int rightShift = 8 - ((bit_offset + bit_length) % 8);
            if (rightShift == 8)
            {
               rightShift = 0;
            }
            value = value >> rightShift;
            return new fr.gael.drb.value.BinaryInteger(value, 8 * length
                  + bit_length);
         }

         // Switch on value type
         switch (value_type)
         {
            // Case of String
            case Value.STRING_ID:
               return new fr.gael.drb.value.String(this.buffer);

               // Case of Unsigned Byte
            case Value.UNSIGNED_BYTE_ID:
               if (encoding == Descriptor.ENCODING_ASCII)
               {
                  return new fr.gael.drb.value.UnsignedByte((byte) this
                        .extractAsciiLong(this.buffer));
               }
               else
               {
                  return new fr.gael.drb.value.UnsignedByte(file.readByte());
               }

               // Case of Byte
            case Value.BYTE_ID:
               if (encoding == Descriptor.ENCODING_ASCII)
               {
                  return new fr.gael.drb.value.Byte((byte) this
                        .extractAsciiLong(this.buffer));
               }
               else
               {
                  return new fr.gael.drb.value.Byte(file.readByte());
               }

               // Case of Unsigned Short
            case Value.UNSIGNED_SHORT_ID:
               if (encoding == Descriptor.ENCODING_ASCII)
               {
                  return new fr.gael.drb.value.UnsignedShort((short) this
                        .extractAsciiLong(this.buffer));
               }
               else
               {
                  return new fr.gael.drb.value.UnsignedShort(file.readShort());
               }

               // Case of Short
            case Value.SHORT_ID:
               if (encoding == Descriptor.ENCODING_ASCII)
               {
                  return new fr.gael.drb.value.Short((short) this
                        .extractAsciiLong(this.buffer));
               }
               else
               {
                  return new fr.gael.drb.value.Short(file.readShort());
               }

               // Case of Unsigned Int
            case Value.UNSIGNED_INT_ID:
               if (encoding == Descriptor.ENCODING_ASCII)
               {
                  return new fr.gael.drb.value.UnsignedInt((int) this
                        .extractAsciiLong(this.buffer));
               }
               else
               {
                  return new fr.gael.drb.value.UnsignedInt(file.readInt());
               }

               // Case of Int
            case Value.INT_ID:
               if (encoding == Descriptor.ENCODING_ASCII)
               {
                  return new fr.gael.drb.value.Int((int) this
                        .extractAsciiLong(this.buffer));
               }
               else
               {
                  return new fr.gael.drb.value.Int(file.readInt());
               }

               // Case of Unsigned Long
            case Value.UNSIGNED_LONG_ID:
               if (encoding == Descriptor.ENCODING_ASCII)
               {
                  return new fr.gael.drb.value.UnsignedLong(this
                        .extractAsciiLong(this.buffer));
               }
               else
               {
                  return new fr.gael.drb.value.UnsignedLong(file.readLong());
               }

               // Case of Long
            case Value.LONG_ID:
               if (encoding == Descriptor.ENCODING_ASCII)
               {
                  return new fr.gael.drb.value.Long(this
                        .extractAsciiLong(this.buffer));
               }
               else
               {
                  return new fr.gael.drb.value.Long(file.readLong());
               }

               // Case of Float
            case Value.FLOAT_ID:
               if (encoding == Descriptor.ENCODING_ASCII)
               {
                  return new fr.gael.drb.value.Float((float) this
                        .extractAsciiDouble(this.buffer));
               }
               else
               {
                  return new fr.gael.drb.value.Float(file.readFloat());
               }

               // Case of Double
            case Value.DOUBLE_ID:
               if (encoding == Descriptor.ENCODING_ASCII)
               {
                  return new fr.gael.drb.value.Double(this
                        .extractAsciiDouble(this.buffer));
               }
               else
               {
                  return new fr.gael.drb.value.Double(file.readDouble());
               }

               // Case of Date
            case Value.DATE_ID:
               // The representation is assumed as "UTC" time (27 bytes) :
               // format : "DD-MMM-YYYY hh:mm:ss.tttttt".
               if (encoding == Descriptor.ENCODING_ASCII)
               {
                  return new fr.gael.drb.value.DateTime(new String(this.buffer));
               }
               else
               {
                  return new fr.gael.drb.value.DateTime(this.buffer);
               }

               // Case of Array
            case Value.ARRAY_ID:
               // Compute array item size
               itemLength = length / array_size;
               curOffset = 0;
               // Check array value_type
               switch (array_value_type)
               {
                  // Case of byte in array
                  case Value.UNSIGNED_BYTE_ID:
                  case Value.BYTE_ID:
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_ASCII)
                     {
                        final byte[] byteArray = new byte[array_size];
                        for (int i = 0; i < array_size; i++)
                        {
                           byteArray[i] =
                              (byte) this.extractAsciiLong(this.buffer,
                                    curOffset, itemLength);
                           curOffset = curOffset + itemLength;
                        }
                        if (array_value_type == Value.UNSIGNED_BYTE_ID)
                        {
                           return new fr.gael.drb.value.UnsignedByteArray(
                                 byteArray);
                        }
                        else
                        {
                           return new fr.gael.drb.value.ByteArray(byteArray);
                        }
                     }
                     // Case of binary values, return the buffer itself
                     else
                     {
                        if (array_value_type == Value.UNSIGNED_BYTE_ID)
                        {
                           return new fr.gael.drb.value.UnsignedByteArray(
                                 this.buffer);
                        }
                        else
                        {
                           return new fr.gael.drb.value.ByteArray(this.buffer);
                        }
                     }

                     // Case of double in array
                  case Value.DOUBLE_ID:
                     final double[] doubleArray = new double[array_size];
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_ASCII)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           doubleArray[i] =
                              this.extractAsciiDouble(this.buffer, curOffset,
                                    itemLength);
                           curOffset = curOffset + itemLength;
                        }
                     }
                     // Case of binary values
                     else
                     {
                        // Create a long to use as bits reprensentation of
                        // a double with Double.longBitsToDouble(long bits).
                        long tmpLong = 0;
                        for (int i = 0; i < array_size; i++)
                        {
                           tmpLong =
                              ((long) ((this.buffer[i * 8] & 0xff)) << 56)
                                    + ((long) ((this.buffer[i * 8 + 1] & 0xff)) << 48)
                                    + ((long) ((this.buffer[i * 8 + 2] & 0xff)) << 40)
                                    + ((long) ((this.buffer[i * 8 + 3] & 0xff)) << 32)
                                    + ((long) ((this.buffer[i * 8 + 4] & 0xff)) << 24)
                                    + ((long) ((this.buffer[i * 8 + 5] & 0xff)) << 16)
                                    + ((long) ((this.buffer[i * 8 + 6] & 0xff)) << 8)
                                    + (this.buffer[i * 8 + 7] & 0xff);
                           doubleArray[i] = Double.longBitsToDouble(tmpLong);
                        }
                     }
                     // Return array
                     return new fr.gael.drb.value.DoubleArray(doubleArray);

                     // Case of float in array
                  case Value.FLOAT_ID:
                     final float[] floatArray = new float[array_size];
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_ASCII)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           floatArray[i] =
                              (float) this.extractAsciiDouble(this.buffer,
                                    curOffset, itemLength);
                           curOffset = curOffset + itemLength;
                        }
                     }
                     // Case of binary values
                     else
                     {
                        // Create a int to use as bits reprensentation of
                        // a float with Float.intBitsToFloat(int bits).
                        int tmpInt = 0;
                        for (int i = 0; i < array_size; i++)
                        {
                           tmpInt =
                              ((this.buffer[i * 4] & 0xff) << 24)
                                    + ((this.buffer[i * 4 + 1] & 0xff) << 16)
                                    + ((this.buffer[i * 4 + 2] & 0xff) << 8)
                                    + (this.buffer[i * 4 + 3] & 0xff);
                           floatArray[i] = Float.intBitsToFloat(tmpInt);
                        }
                     }
                     // Return array
                     return new fr.gael.drb.value.FloatArray(floatArray);

                     // Case of unsigned int in array
                  case Value.UNSIGNED_INT_ID:
                     int[] intArray = new int[array_size];
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_ASCII)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           intArray[i] =
                              (int) this.extractAsciiLong(this.buffer,
                                    curOffset, itemLength);
                           curOffset = curOffset + itemLength;
                        }
                     }
                     // Case of binary values
                     else
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           intArray[i] =
                              ((this.buffer[i * 4] & 0xff) << 24)
                                    + ((this.buffer[i * 4 + 1] & 0xff) << 16)
                                    + ((this.buffer[i * 4 + 2] & 0xff) << 8)
                                    + (this.buffer[i * 4 + 3] & 0xff);
                        }
                     }
                     // Return array
                     return new fr.gael.drb.value.UnsignedIntArray(intArray);

                     // Case of int in array
                  case Value.INT_ID:
                     intArray = new int[array_size];
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_ASCII)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           intArray[i] =
                              (int) this.extractAsciiLong(this.buffer,
                                    curOffset, itemLength);
                           curOffset = curOffset + itemLength;
                        }
                     }
                     // Case of binary values
                     else
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           intArray[i] =
                              ((this.buffer[i * 4] & 0xff) << 24)
                                    + ((this.buffer[i * 4 + 1] & 0xff) << 16)
                                    + ((this.buffer[i * 4 + 2] & 0xff) << 8)
                                    + (this.buffer[i * 4 + 3] & 0xff);
                        }
                     }
                     // Return array
                     return new fr.gael.drb.value.IntArray(intArray);

                     // Case of long in array
                  case Value.UNSIGNED_LONG_ID:
                  case Value.LONG_ID:
                     final long[] longArray = new long[array_size];
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_ASCII)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           longArray[i] =
                              this.extractAsciiLong(this.buffer, curOffset,
                                    itemLength);
                           curOffset = curOffset + itemLength;
                        }
                     }
                     // Case of binary values
                     else
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           longArray[i] =
                              ((long) ((this.buffer[i * 8] & 0xff)) << 56)
                                    + ((long) ((this.buffer[i * 8 + 1] & 0xff)) << 48)
                                    + ((long) ((this.buffer[i * 8 + 2] & 0xff)) << 40)
                                    + ((long) ((this.buffer[i * 8 + 3] & 0xff)) << 32)
                                    + ((long) ((this.buffer[i * 8 + 4] & 0xff)) << 24)
                                    + ((long) ((this.buffer[i * 8 + 5] & 0xff)) << 16)
                                    + ((long) ((this.buffer[i * 8 + 6] & 0xff)) << 8)
                                    + (this.buffer[i * 8 + 7] & 0xff);
                        }
                     }
                     // Return array
                     if (array_value_type == Value.UNSIGNED_LONG_ID)
                     {
                        return new fr.gael.drb.value.UnsignedLongArray(
                              longArray);
                     }
                     else
                     {
                        return new fr.gael.drb.value.LongArray(longArray);
                     }

                     // Case of unsigned short in array
                  case Value.UNSIGNED_SHORT_ID:
                     short[] shortArray = new short[array_size];
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_ASCII)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           shortArray[i] =
                              (short) this.extractAsciiLong(this.buffer,
                                    curOffset, itemLength);
                           curOffset = curOffset + itemLength;
                        }
                     }
                     // Case of binary values
                     else
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           shortArray[i] =
                              (short) ((this.buffer[i * 2] << 8) + (this.buffer[i * 2 + 1] & 0xff));
                        }
                     }
                     // Return array
                     return new fr.gael.drb.value.UnsignedShortArray(shortArray);

                     // Case of short in array
                  case Value.SHORT_ID:
                     shortArray = new short[array_size];
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_ASCII)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           shortArray[i] =
                              (short) this.extractAsciiLong(this.buffer,
                                    curOffset, itemLength);
                           curOffset = curOffset + itemLength;
                        }
                     }
                     // Case of binary values
                     else
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           shortArray[i] =
                              (short) ((this.buffer[i * 2] << 8) + (this.buffer[i * 2 + 1] & 0xff));
                        }
                     }
                     // Return array
                     return new fr.gael.drb.value.ShortArray(shortArray);
                  default:
                     return null;
               }

               // Case of
            case Value.BOOLEAN_ID:
            default:
               this.logger
                     .error("fr.gael.drb.impl.sdf.BlockTools.extractValue() : "
                           + "Value type not supported (" + value_type + ").");
               return null;
         }
      }
      // Case of NumberFormatException
      catch (final NumberFormatException e)
      {
         this.logger.error("fr.gael.drb.impl.sdf.BlockTools.extractValue() : "
               + "Error while extracting value from Ascii buffer.");
         this.logger.error("   " + e);
         return null;
      }
      /*
       * catch (EOFException e) { logger.error(
       * "fr.gael.drb.impl.sdf.BlockTools.extractValue() : " + "End of file
       * reached."); logger.error(" " + e); return null; }
       */
      catch (final Exception e)
      {
         this.logger.error("fr.gael.drb.impl.sdf.BlockTools.extractValue() : "
               + "Error while reading file (offset=" + offset + ", length="
               + length + ").");
         this.logger.error("   " + e);
         return null;
      }
   }
} // BlockTools
