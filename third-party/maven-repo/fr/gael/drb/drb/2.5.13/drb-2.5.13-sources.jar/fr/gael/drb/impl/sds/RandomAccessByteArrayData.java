/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * Random Access Data.
 */
class RandomAccessByteArrayData extends RandomAccessData
{
   /**
    * The wrapped buffer.
    */
   ByteBuffer buffer;

   /**
    * offset
    */
   long offset = 0;

   /**
    * Creates a RandomAccessByteArrayData from the specified buffer.
    * 
    * @param buffer The specified buffer
    */
   public RandomAccessByteArrayData(final ByteBuffer buffer)
   {
      this.buffer = buffer;
   }

   // ---
   // DataInput implementation.
   // ---

   /**
    * Reads one input byte and returns true if that byte is nonzero, false if
    * that byte is zero.
    * 
    * @return true if the buffer's current position is superior than 0, else
    *         return false
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public boolean readBoolean() throws IOException
   {
      return this.buffer.get() != 0;
   }

   /**
    * Reads and returns one input byte.
    * 
    * @return The byte at the buffer's current position
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public byte readByte() throws IOException
   {
      return this.buffer.get();
   }

   /**
    * Reads an input char and returns the char value.
    * 
    * @return The char value at the buffer's current position
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public char readChar() throws IOException
   {
      return this.buffer.getChar();
   }

   /**
    * Reads eight input bytes and returns a double value.
    * 
    * @return The double value at the buffer's current position
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public double readDouble() throws IOException
   {
      return this.buffer.getDouble();
   }

   /**
    * Reads four input bytes and returns a float value.
    * 
    * @return The float the buffer's current position
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public float readFloat() throws IOException
   {
      return this.buffer.getFloat();
   }

   /**
    * Reads some bytes from an input stream and stores them into the buffer
    * array b.
    * 
    * @param b The array into which bytes are to be read
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void readFully(final byte[] b) throws IOException
   {
      this.buffer.get(b);
   }

   /**
    * Reads len bytes from an input stream.
    * 
    * @param b The array into which bytes are to be read
    * @param off The offset within the array of the first byte to be read; must
    *           be non-negative and no larger than <tt>b.len</tt>
    * @param len The maximum number of bytes to be read to the given array; must
    *           be non-negative and no larger than <tt>b.len - off</tt>
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void readFully(final byte[] b, final int off, final int len)
         throws IOException
   {
      this.buffer.get(b, off, len);
   }

   /**
    * Reads four input bytes and returns an int value.
    * 
    * @return The int value at the buffer's current position
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public int readInt() throws IOException
   {
      return this.buffer.getInt();
   }

   /**
    * Reads the next line of text from the input stream.
    * 
    * @return The string value at the buffer's current position
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public String readLine() throws IOException
   {
      throw new java.io.IOException();
   }

   /**
    * Reads eight input bytes and returns a long value.
    * 
    * @return The long value at the buffer's current position
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public long readLong() throws IOException
   {
      return this.buffer.getLong();
   }

   /**
    * Reads two input bytes and returns a short value.
    * 
    * @return The short value at the buffer's current position
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public short readShort() throws IOException
   {
      return this.buffer.getShort();
   }

   /**
    * Reads one input byte, zero-extends it to type int, and returns the result,
    * which is therefore in the range 0 through 255.
    * 
    * @return The input byte
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public int readUnsignedByte() throws IOException
   {
      return (this.buffer.get() & 0xff);
   }

   /**
    * Reads one input byte, zero-extends it to type int, and returns the result,
    * which is therefore in the range 0 through 255.
    * 
    * @return The input byte
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public int readUnsignedShort() throws IOException
   {
      return (this.buffer.getShort() & 0xffff);
   }

   /**
    * Makes an attempt to skip over n bytes of data from the input stream,
    * discarding the skipped bytes.
    * 
    * @param n bytes to skip
    * @return The input byte
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public int skipBytes(final int n) throws IOException
   {
      try
      {
         this.buffer.position(this.buffer.position() + n);
         return n;
      }
      catch (final IllegalArgumentException e)
      {
         throw new IOException();
      }
   }

   /**
    * Reads in a string that has been encoded using a modified UTF-8 format.
    * 
    * @return The string
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public String readUTF() throws IOException
   {
      throw new IOException();
   }

   // ---
   // DataOuput implementation.
   // ---

   /**
    * Writes a boolean value to this output stream.
    * 
    * @param v The boolean to write
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void writeBoolean(final boolean v) throws IOException
   {
      this.buffer.put(v ? (byte) 1 : (byte) 0);
   }

   /**
    * Writes to the output stream the eight low- order bits of the argument v.
    * 
    * @param v The int to write
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void writeByte(final int v) throws IOException
   {
      this.buffer.put((byte) v);
   }

   /**
    * Writes a char value, wich is comprised of two bytes, to the output stream.
    * 
    * @param v The char to write
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void writeChar(final int v) throws IOException
   {
      this.buffer.putChar((char) v);
   }

   /**
    * Writes every character in the string s, to the output stream, in order,
    * two bytes per character.
    * 
    * @param s The string to write
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void writeChars(final String s) throws IOException
   {
      this.buffer.put(s.getBytes());
   }

   /**
    * Writes a string to the output stream.
    * 
    * @param s The string to write
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void writeBytes(final String s) throws IOException
   {
      this.buffer.put(s.getBytes());
   }

   /**
    * Writes a double value, which is comprised of eight bytes, to the output
    * stream.
    * 
    * @param v The double to write
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void writeDouble(final double v) throws IOException
   {
      this.buffer.putDouble(v);
   }

   /**
    * Writes a float value, which is comprised of four bytes, to the output
    * stream.
    * 
    * @param v The float to write
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void writeFloat(final float v) throws IOException
   {
      this.buffer.putFloat(v);
   }

   /**
    * Writes to the output stream all the bytes in array b.
    * 
    * @param b The byte[] to write
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void write(final byte[] b) throws IOException
   {
      this.buffer.put(b);
   }

   /**
    * Writes len bytes from array b, in order, to the output stream.
    * 
    * @param b The array from which bytes are to be read
    * @param off The offset within the array of the first byte to be read; must
    *           be non-negative and no larger than <tt>array.length</tt>
    * @param len The number of bytes to be read from the given array; must be
    *           non-negative and no larger than <tt>array.length - offset</tt>
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void write(final byte[] b, final int off, final int len)
         throws IOException
   {
      this.buffer.put(b, off, len);
   }

   /**
    * Writes an int value, which is comprised of four bytes, to the output
    * stream.
    * 
    * @param v The int to write
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void writeInt(final int v) throws IOException
   {
      this.buffer.putInt(v);
   }

   /**
    * Writes to the output stream the eight low-order bits of the argument b.
    * 
    * @param v The int to write
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void write(final int v) throws IOException
   {
      this.buffer.put((byte) (v & 0xff));
   }

   /**
    * Writes a long value, which is comprised of eight bytes, to the output
    * stream.
    * 
    * @param v The long to write
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void writeLong(final long v) throws IOException
   {
      this.buffer.putLong(v);
   }

   /**
    * Writes two bytes to the output stream to represent the value of the
    * argument.
    * 
    * @param v The int to write as short
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void writeShort(final int v) throws IOException
   {
      this.buffer.putShort((short) v);
   }

   /**
    * Writes two bytes of length information to the output stream, followed by
    * the Java modified UTF representation of every character in the string s.
    * 
    * @param str The string to write
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   public void writeUTF(final String str) throws IOException
   {
      throw new IOException();
   }

   /**
    * Closes this random access buffer stream and releases any system resources
    * associated with the stream.
    * 
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   void close() throws java.io.IOException
   {
   }

   /**
    * Returns the number of bytes that can be read (or skipped over) from this
    * input stream without blocking by the next caller of a method for this
    * input stream. The next caller might be the same thread or or another
    * thread.
    * 
    * @throws java.io.IOException if an I/O error occurs.
    * @return the number of byte that can be read without blocking.
    */
   public long available() throws java.io.IOException
   {
      return (this.buffer.capacity() - this.buffer.position());
   } // available

   /**
    * Sets the data-pointer offset, measured from the beginning of this data, at
    * which the next read or write occurs.
    * 
    * @param pos The new position value; must be non-negative and no larger than
    *           the current limit
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   void seek(final long pos) throws IOException
   {
      this.buffer.position((int) pos);
   }

   /**
    * Returns the length of this dta.
    * 
    * @return long The buffer capacity
    * @throws IOException This exception is raised, If the buffer's current
    *            position is not smaller than its limit
    */
   long length() throws java.io.IOException
   {
      return this.buffer.capacity();
   }
} // RandomAccessByteArrayData
