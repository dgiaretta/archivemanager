/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

import java.io.InputStream;

/**
 * The Binary class is a generic wrapper for binary values.
 */
public abstract class Binary extends AbstractValue
{
   // ===========================================================================
   // Attributes part.
   // ===========================================================================
   /**
    * The Binary priority.
    */
   final static int PRIORITY = 0;

   // ===========================================================================
   // Methods part.
   // ===========================================================================
   /**
    * Returns this value as string.
    * 
    * @return the string corresponding to this value.
    */
   public final java.lang.String toString()
   {
      return "";
   }

   // --------------------------------------------------------------------------
   // Value interface implementation
   // ---------------------------------------------------------------------------
   /**
    * The type identifier of the value.
    * 
    * @return an identifier of the value type.
    */
   public final int getType()
   {
      return Value.BINARY_ID;
   }

   /**
    * Return the Binary priority.
    * 
    * @return the binary priority.
    */
   public final int getPriority()
   {
      return this.PRIORITY;
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself should be returned. If the conversion is not allowed a
    * ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException if the conversion is impossible.
    */
   public final Value convertTo(final int type) throws ClassCastException
   {
      switch (type)
      {
         // Binary -> Binary conversion
         case BINARY_ID:
            return this;

            // Boolean -> String conversion
         case Value.STRING_ID:
            return new String(this.toString());

         default:
            throw new ClassCastException("Binary: unreconized type (" + type
                  + ")");

      }
   }

   /**
    * Get an input stream.
    * 
    * @return an input stream.
    */
   public abstract InputStream getInput();

   /**
    * Get an output stream.
    * 
    * @return an output stream.
    */
   // public abstract OutputStream getOutput();
}
