/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.value.Value;

/**
 * Wraps a Literal expression of XQuery language. A Literal expression is a
 * constant, either numeric or string. The literal cannot be cancelled.
 */
final class LiteralExpression extends AbstractExpression
{

   /**
    * The contant value of the literal.
    */
   Value value = null;

   /**
    * The value in a singleton.
    */
   DrbDefaultSequence sequence = null;

   /**
    * Constructor of the literal.
    * 
    * @param token the token associated to the literal value.
    * @param value the value of the literal.
    */
   public LiteralExpression(final Token token, final Value value)
   {
      super("Literal", token);
      this.value = value;
      this.sequence = new DrbDefaultSequence();
      this.sequence.add(value);
   }

   /**
    * Returns the value of the Literal.
    * 
    * @return the values of the literal.
    */
   public Value getValue()
   {
      return this.value;
   }

   /**
    * Evaluates the literal expression. Just return the singleton sequence
    * embedding the literal value.
    * 
    * @return the sequence resulting from the dynamic evaluation.
    * @throws DynamicException
    * @throws TypeException
    * @throws CancelException
    */
   public final DrbSequence evaluate() throws DynamicException, TypeException,
         CancelException
   {
      return this.sequence;
   }

   /**
    * Evaluates the literal expression. Just return the singleton sequence
    * embedding the literal value.
    * 
    * @param context the outer-focus of the evaluation.
    * @return the sequence resulting from the dynamic evaluation.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {
      return this.sequence;
   }

   /**
    * Returns the literal as a string.
    * 
    * @return the string reporting the value of the literal.
    */
   public String toString()
   {
      if (this.value != null)
      {
         if (this.value instanceof fr.gael.drb.value.String)
         {
            return "\"" + this.value.toString() + "\"";
         }
         else
         {
            return this.value.toString();
         }
      }
      else
      {
         return "";
      }
   }

   /**
    * A expression which is constant means that it need no context item to be
    * evaluate. The returned sequence from its evaluation will always be the
    * same along the query script
    * 
    * @return true if this expression is constant
    */
   public boolean isConstant()
   {
      return true;
   }
} // LiteralExpression
