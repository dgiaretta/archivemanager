/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.file;

import fr.gael.drb.impl.DrbProvider;
import fr.gael.drb.value.Logic;

/**
 * File provider.
 */
public final class FileProvider extends DrbProvider
{
   /**
    * the file Node
    */
   FileNode fileNode;

   /**
    * mustSort
    */
   boolean mustSort = true;

   /**
    * Build a file provider with the file
    * 
    * @param file_node the file node
    */
   protected FileProvider(final FileNode file_node)
   {
      this.fileNode = file_node;
   }

   /**
    * This method gets the name
    * 
    * @return String the file name
    */
   public String getName()
   {
      return "file";
   }

   /**
    * This method get the identifier
    * 
    * @return String the identifier
    */
   public String getIdentifier()
   {
      return "file";
   }

   /**
    * This method sets the properties of the file which have the name in params
    * 
    * @param name the name of the file
    * @param value the object value
    * @throws IllegalArgumentException This exception is raised when the
    *            property name is not supported
    */
   public void setProperty(final String name, final Object value)
         throws IllegalArgumentException
   {
      if (new String("mustSort").equals(name))
      {
         this.mustSort = ((Logic) value).booleanValue();
      }
      else
      {
         throw new IllegalArgumentException("FileProvider.setProperty() : "
               + "The property '" + name + "' is not supported.");
      }
   }

   /**
    * This method get the value of the file name
    * 
    * @param name the name of the file
    * @return Object the value of this file
    */
   public Object getProperty(final String name)
   {
      if (new String("mustSort").equals(name))
      {
         return new fr.gael.drb.value.Boolean(this.mustSort);
      }
      return null;
   }

   /**
    * This method commit the provider
    */
   public void commit()
   {
      // do nothing
   }

   /**
    * This method attach the parend file
    * 
    * @param parent the file parent provider
    */
   protected void attachParent(final FileProvider parent)
   {
      this.setProperty("mustSort", parent.getProperty("mustSort"));
   }
} // DrbProvider
