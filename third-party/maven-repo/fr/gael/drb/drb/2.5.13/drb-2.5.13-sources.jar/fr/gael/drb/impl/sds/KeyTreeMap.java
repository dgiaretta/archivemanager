/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.log4j.Logger;

/**
 */
final class KeyTreeMap
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(KeyTreeMap.class);

   /**
    * The depth of the tree.
    */
   private int depth;

   /**
    * The number of values in the tree.
    */
   private int size;

   /**
    * The map of children.
    */
   private Map children;

   /**
    * The root value.
    */
   private Object value;

   /**
    * The last key.
    */
   private int[] lastKey;

   /**
    * The last value.
    */
   private Object lastValue;

   /**
    * Create a KeyTreeMap instance with an unknown depth. The depth will be set
    * during the first add() call and will be equal to the length of the given
    * key.
    */
   protected KeyTreeMap()
   {
      // Wrap to other constructor with unknown depth
      this(-1);
   }

   /**
    * Create a KeyTreeMap instance with a specified depth.
    * 
    * @param depth The depth of the tree, must be greater than 0.
    */
   protected KeyTreeMap(final int depth)
   {
      // Set the depth and size
      this.depth = depth;
      this.size = 0;

      // Create the map
      this.children = new TreeMap();
   }

   /**
    * Adds the value in the tree using the given key. If the given key is null
    * nothing is added to the map. The value can be retreived later by the
    * get(key) operation.
    * 
    * @param key The key to identify the value.
    * @param value The value to add in the map.
    */
   protected final void add(final int[] key, final Object value)
   {
      // Local declarations
      Map curLevelMap; // Map of the current level
      Map tmpLevelMap; // Temporary Map of the current level

      // Set the depth if unknown
      if (this.depth < 0)
      {
         if (key == null)
         {
            this.depth = 0;
         }
         else
         {
            this.depth = key.length;
         }
      }
      if (this.depth == 0)
      {
         this.value = value;
         return;
      }
      else if ((key == null) || (key.length < this.depth))
      {
         logger.error("KeyTreeMap.add() ERROR: "
               + "The given key is not consistent with the depth of the tree.");
         return;
      }

      // Parse tree using the given key
      curLevelMap = this.children;
      for (int i = 0; i < this.depth - 1; i++)
      {
         // Get the sub map from the current level
         tmpLevelMap = (Map) curLevelMap.get(new Integer(key[i]));

         // Create new map if not existing and add it to current level
         if (tmpLevelMap == null)
         {
            tmpLevelMap = new TreeMap();
            curLevelMap.put(new Integer(key[i]), tmpLevelMap);
         }

         // Go to next level
         curLevelMap = tmpLevelMap;
      }

      // Store value (replace if exists) and change size if new
      if (curLevelMap.put(new Integer(key[this.depth - 1]), value) == null)
      {
         this.size++;
      }

      this.lastKey = new int[key.length];
      this.lastValue = value;
      System.arraycopy(key, 0, this.lastKey, 0, key.length);
   }

   /**
    * Returns the value at the floor level if any..
    * 
    * @return The value associated to the floor level or null.
    */
   protected final Object get()
   {
      return this.value;
   }

   /**
    * Adds the value in the tree. The value can be retreived later by the get()
    * operation.
    * 
    * @param value The value to add in the map.
    */
   protected final void add(final Object value)
   {
      this.value = value;
   }

   /**
    * Returns the value associated to the key. If the given key is null returns
    * null. If no entry matches the key returns null. Else returns the value
    * associated to the key.
    * 
    * @param key The key used to find the value.
    * @return The value associated to the key.
    */
   protected final Object get(final int[] key)
   {
      // Local declarations
      Map curLevelMap; // Map of the current level
      Map tmpLevelMap; // Temporary Map of the current level
      Object value; // The value to get from tree

      // Returns immediatly if the depth is null
      if ((this.depth <= 0) || (key == null))
      {
         return this.value;
      }

      // Parse tree using the given key
      if ((this.lastKey != null) && Arrays.equals(this.lastKey, key))
      {
         return this.lastValue;
      }
      curLevelMap = this.children;
      for (int i = 0; i < this.depth - 1; i++)
      {
         // Get the sub map from the current level
         tmpLevelMap = (Map) curLevelMap.get(new Integer(key[i]));

         // Create new map if not existing and add it to current level
         if (tmpLevelMap == null)
         {
            return null;
         }

         // Go to next level
         curLevelMap = tmpLevelMap;
      }

      // Get value from last level
      value = curLevelMap.get(new Integer(key[this.depth - 1]));

      // Return value
      return value;
   }

   /**
    * Returns the sibling keys associated to the key. If the given key is null
    * returns null.
    * 
    * @param key The key used to find the value.
    * @return The value associated to the key.
    */
   protected final Set getSiblingKeys(final int[] key)
   {
      // Local declarations
      Map curLevelMap; // Map of the current level
      Map tmpLevelMap; // Temporary Map of the current level
      // Check parameter
      if ((key == null) || (this.depth <= 0))
      {
         return new TreeSet();
      }

      // Parse tree using the given key
      curLevelMap = this.children;
      for (int i = 0; i < this.depth - 1; i++)
      {
         // Get the sub map from the current level
         tmpLevelMap = (Map) curLevelMap.get(new Integer(key[i]));

         // Create new map if not existing and add it to current level
         if (tmpLevelMap == null)
         {
            return new TreeSet();
         }

         // Go to next level
         curLevelMap = tmpLevelMap;
      }

      // Get key set from last level
      return curLevelMap.keySet();
   }

   /**
    * Returns the number of values stored in the tree.
    * 
    * @return The number of values stored in the tree.
    */
   protected final int getSize()
   {
      if ((this.depth == 0) && (this.value != null))
      {
         return 1;
      }
      else
      {
         return this.size;
      }
   }

   /**
    * Clear the content of the map. This operation does not modify the depth
    * attribute. Therefore its value remains unchanged.
    */
   protected final void clear()
   {
      // Wrap to the map operation
      this.children.clear();
      this.lastKey = null;
      this.lastValue = null;
      this.value = null;

      // Reset the size
      this.size = 0;
   }

   /**
    * Print info into a string.
    * 
    * @return String
    */
   public String toString()
   {
      String tmpStr =
         "{depth=" + this.depth + ", size=" + this.getSize() + ", ";
      if (this.depth == 0)
      {
         tmpStr = tmpStr + this.value;
      }
      else
      {
         tmpStr = tmpStr + this.children;
      }
      return tmpStr + "}";
   }

   /**
    * TBC.
    * 
    * @return KeyTreeMapIterator
    */
   protected final KeyTreeMapIterator iterator()
   {
      return new KeyTreeMapIterator();
   }

   /**
    * TBC.
    */
   final class KeyTreeMapIterator implements Iterator
   {
      /**
       * TBC.
       */
      Map map[];

      /**
       * TBC.
       */
      Iterator iterator[];

      /**
       * TBC.
       */
      Iterator subIterator;

      /**
       * TBC.
       */
      int level = -1;

      /**
       * TBC.
       */
      protected KeyTreeMapIterator()
      {
         // Initialize if depth is valid
         if (KeyTreeMap.this.depth > 0)
         {
            // Set start level
            this.level = 0;

            // Create arrays to cache the maps and iterators used for the
            // current key and initialize the first cache elements
            this.map = new Map[KeyTreeMap.this.depth];
            this.map[0] = KeyTreeMap.this.children;
            this.iterator = new Iterator[KeyTreeMap.this.depth];
            this.iterator[0] = this.map[0].values().iterator();

            // Get the first values iterator
            this.subIterator = this.nextSubIterator();
         }
      }

      /**
       * TBC.
       * 
       * @return Iterator
       */
      private final Iterator nextSubIterator()
      {
         while (this.level >= 0)
         {
            if (this.iterator[this.level].hasNext())
            {
               if (this.level < KeyTreeMap.this.depth - 1)
               {
                  this.map[this.level + 1] =
                     (Map) this.iterator[this.level].next();
                  this.iterator[this.level + 1] =
                     this.map[this.level + 1].values().iterator();
                  this.level++;
               }
               else
               {
                  return this.iterator[this.level];
               }
            }
            else
            {
               this.level--;
            }
         }
         return null;
      }

      /**
       * TBC.
       * 
       * @return boolean
       */
      public final boolean hasNext()
      {
         // Case of floor level
         if (this.level < 0)
         {
            return (KeyTreeMap.this.value != null);
         }

         // Case of next() available in the current sub iterator
         if (this.subIterator.hasNext())
         {
            return true;
            // Else get next sub iterator
         }
         else
         {
            this.subIterator = this.nextSubIterator();
         }

         // Case of next() available in the new sub iterator
         if ((this.subIterator != null) && (this.subIterator.hasNext()))
         {
            return true;
            // Else
         }
         else
         {
            return false;
         }
      }

      /**
       * TBC.
       * 
       * @return Object
       */
      public final Object next()
      {
         if (this.subIterator == null)
         {
            if (KeyTreeMap.this.value == null)
            {
               throw new NoSuchElementException();
            }
            else
            {
               return KeyTreeMap.this.value;
            }
         }

         if (!this.subIterator.hasNext())
         {
            this.subIterator = this.nextSubIterator();
         }

         return this.subIterator.next();
      }

      /**
       * TBC.
       */
      public final void remove()
      {
         if (this.subIterator == null)
         {
            KeyTreeMap.this.value = null;
            KeyTreeMap.this.size = 0;
            return;
         }
         // Remove the current value
         this.subIterator.remove();
         KeyTreeMap.this.size--;

         // Check if map at current level is empty and loop until the
         // root level to remove empty maps.
         int tmpLevel = this.level;
         while ((tmpLevel >= 0) && (this.map[tmpLevel].size() == 0))
         {
            tmpLevel--;
            this.iterator[tmpLevel].remove();
         }
      }
   } // End of inner class KeyTreeMapIterator

   /**
    * Main operation used for unitary tests.
    * 
    * @param args String[]
    */
   public static void main(final String[] args)
   {
      System.out.println("\nTest part 1");
      KeyTreeMap ktree = new KeyTreeMap();
      ktree.add(new int[] { 0, 2, 0, 0 }, new Long(66));
      ktree.add(new int[] { 0, 2, 0, 1 }, new Long(177));
      ktree.add(new int[] { 1, 0, 0, 0 }, new Long(321));
      ktree.add(new int[] { 1, 0, 0, 1 }, new Long(457));
      ktree.add(new int[] { 0, 1, 0, 1 }, new Long(44));
      ktree.add(new int[] { 0, 2, 0, 4 }, new Long(205));
      ktree.add(new int[] { 0, 2, 0, 1 }, new Long(186));
      // ktree.add(new int[] {0,2,0}, new Long(99));
      System.out.println(ktree.get(new int[] { 1, 0, 0, 0 }));
      System.out.println(ktree.get(new int[] { 0, 2, 0, 2 }));
      System.out.println(ktree.get(new int[] { 0, 2, 0, 1 }));
      // System.out.println(ktree.get(new int[] {0,2,0}));
      System.out.println("toString() = " + ktree);
      ktree.clear();
      System.out.println("after clear() = " + ktree);

      System.out.println("\nTest part 2");
      ktree = new KeyTreeMap();
      System.out.println("toString() = " + ktree);
      for (int i = 0; i < 3; i++)
      {
         if (i == 1)
         {
            ktree.add(new int[] { i, 0, 0 }, new Long(100 * i));
         }
         else
         {
            for (int j = 0; j < 5; j++)
            {
               if (j < 2)
               {
                  ktree.add(new int[] { i, j, 0 }, new Long(100 * i + 10 * j));
               }
               else
               {
                  for (int k = 0; k < 3; k++)
                  {
                     ktree.add(new int[] { i, j, k }, new Long(100 * i + 10 * j
                           + k));
                  }
               }
            }
         }
      }
      System.out.println("toString() = " + ktree);
      Iterator iterator = ktree.iterator();
      System.out.println("iterator = " + iterator);
      int i = 1;
      while (iterator.hasNext())
      {
         System.out.print(iterator.next() + " ");
         if (i % 2 == 0)
         {
            iterator.remove();
         }
         i++;
      }
      System.out.println();
      System.out.println("toString() = " + ktree);

      iterator = ktree.iterator();
      System.out.println("iterator = " + iterator);
      while (iterator.hasNext())
      {
         System.out.print(iterator.next() + " ");
      }
      System.out.println();
   }
}
