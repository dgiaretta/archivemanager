/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import java.io.EOFException;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import fr.gael.drb.value.AbstractValueArray;
import fr.gael.drb.value.DateTime;
import fr.gael.drb.value.Numeric;
import fr.gael.drb.value.Value;
import fr.gael.drb.value.ValueArray;
import fr.gael.drb.value.ValueFormat;

/**
 * Class utility for blocks. This class contains static operations to extract
 * values from byte and bit blocks with several encoding methods supported
 * (ASCII, Binary, IEEE, etc.).
 */
class BlockTools
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(BlockTools.class);

   /**
    * Static buffer used for value extraction.
    */
   // private byte[] buffer = {};
   /**
    * Static float pattern.
    */
   static private Pattern doublePattern = null;

   /**
    * Static integer pattern.
    */
   static private Pattern integerPattern = null;

   /**
    * Static boolean pattern.
    */
   static private Pattern booleanPattern = null;

   /**
    * Returns a long extracted from a ASCII buffer. This implementation assumes
    * that buffer is not null. It is a wrapper to extractAsciiLong(String) using
    * String(byte[]) constructor.
    * 
    * @param buffer The buffer containing the value to extract from.
    * @param stop_index The stop index in the buffer.
    * @return The long value extracted from buffer.
    */
   protected final static long extractAsciiLong(final byte[] buffer,
         final Length stop_index)
   {
      // Wrap to operation using String
      return extractAsciiLong(new String(buffer), stop_index);
   }

   /**
    * Returns a long extracted from a ASCII buffer with offset and length
    * specified. This implementation assumes that buffer is not null. It is a
    * wrapper to extractAsciiLong(String) using String(byte[], int offset, int
    * length) constructor.
    * 
    * @param buffer The buffer containing the value to extract from.
    * @param offset The offset in the buffer.
    * @param length The length to use.
    * @return The long value extracted from buffer.
    */
   protected final static long extractAsciiLong(final byte[] buffer,
         final int offset, final int length)
   {
      // Wrap to operation using String
      return extractAsciiLong(new String(buffer, offset, length), new Length(
            length, 0));
   }

   /**
    * Returns a long extracted from a ASCII buffer with offset and length
    * specified. This implementation assumes that buffer is not null. It is a
    * wrapper to extractAsciiLong(String) using String(byte[], int offset, int
    * length) constructor.
    * 
    * @param buffer The buffer containing the value to extract from.
    * @param offset The offset in the buffer.
    * @param stop_index The stop index
    * @return The long value extracted from buffer.
    */
   protected final static long extractAsciiLong(final byte[] buffer,
         final int offset, final Length stop_index)
   {
      // Wrap to operation using String
      return extractAsciiLong(
            new String(buffer, offset, buffer.length - offset), stop_index);
   }

   /**
    * Returns a long extracted from a String. This implementation assumes that
    * string is not null. No exception is caught therefore NumberFormatException
    * shall be managed by the calling operation.
    */
   protected final static long extractAsciiLong(final String buffer,
         final Length stop_index)
   {
      // Remove whitespaces from string
      // WARNING: check the lexical space
      // String tmpStr = buffer.trim();

      int start_index = 0;
      for (start_index = 0; start_index < buffer.length(); start_index++)
      {
         if (!Character.isWhitespace(buffer.charAt(start_index)))
         {
            break;
         }
      }

      if (integerPattern == null)
      {
         integerPattern = Pattern.compile("(\\+|\\-)?[0-9]+");
      }
      final Matcher matcher = integerPattern.matcher(buffer);
      matcher.find(start_index);
      final int end_index = matcher.end();

      // Check for "+" sign (Integer.parseInt() doesn't support a leading "+"
      // sign, only a "-" sign !) and remove it.
      if (buffer.charAt(start_index) == '+')
      {
         start_index++;
      }

      final String tmpStr = buffer.substring(start_index, end_index);
      stop_index.setLength(end_index, 0);

      // Extract value from string
      return Long.parseLong(tmpStr);
   }

   /**
    * Returns a boolean extracted from a String. This implementation assumes
    * that string is not null. No exception is caught therefore
    * NumberFormatException shall be managed by the calling operation.
    */
   protected final static String extractAsciiBoolean(final String buffer,
         final Length stop_index)
   {
      // Remove whitespaces from string
      // WARNING: check the lexical space
      // String tmpStr = buffer.trim();

      int start_index = 0;
      for (start_index = 0; start_index < buffer.length(); start_index++)
      {
         if (!Character.isWhitespace(buffer.charAt(start_index)))
         {
            break;
         }
      }

      if (booleanPattern == null)
      {
         booleanPattern = Pattern.compile("true|false|0|1");
      }

      final Matcher matcher = booleanPattern.matcher(buffer);
      matcher.find(start_index);

      stop_index.setLength(matcher.end(), 0);

      // Extract value from string
      return matcher.group();
   }

   /**
    * Returns a double extracted from a ASCII buffer. This implementation
    * assumes that buffer is not null. It is a wrapper to
    * extractAsciiDouble(String) using String(byte[]) constructor.
    * 
    * @param buffer The buffer containing the value to extract from.
    * @param stop_index The stop index in the buffer.
    * @return The double value extracted from buffer.
    */
   protected final static double extractAsciiDouble(final byte[] buffer,
         final Length stop_index)
   {
      // Wrap to operation using String
      return extractAsciiDouble(new String(buffer), stop_index);
   }

   /**
    * Returns a double extracted from a ASCII buffer with offset and length
    * specified. This implementation assumes that buffer is not null. It is a
    * wrapper to extractAsciiDouble(String) using String(byte[], int offset, int
    * length) constructor.
    * 
    * @param buffer The buffer containing the value to extract from.
    * @param start_index The start_index in the buffer.
    * @param stop_index The stop index in the buffer.
    * @return The double value extracted from buffer.
    */
   protected final static double extractAsciiDouble(final byte[] buffer,
         final int start_index, final Length stop_index)
   {
      // Wrap to operation using String
      return extractAsciiDouble(new String(buffer, start_index, buffer.length
            - start_index), stop_index);
   }

   /**
    * Returns a double extracted from String. This implementation assumes that
    * string is not null. No exception is caught therefore NumberFormatException
    * shall be managed by the calling operation.
    * <dl>
    * <dt>For instance :</dt>
    * <dd>Whitespaces are permitted : " 1.7 " returns 1.7</dd>
    * <dd>Leading "-" and "+" sign are supported (Double.parseDouble() native).</dd>
    * <dd>"-12.4" buffer returns -12.4</dd>
    * <dd>"+3.5e2" buffer returns 350</dd>
    * <dd>"3.5e+2" buffer returns 350</dd>
    * <dd>"3.5e-2" buffer returns 0.35</dd>
    * </dl>
    * 
    * @param buffer The buffer containing the value to extract from.
    * @param stop_index The stop index in the buffer.
    * @return The double value extracted from buffer.
    */
   protected final static double extractAsciiDouble(final String buffer,
         final Length stop_index)
   {
      // WARNING: check the lexical space
      // String tmpStr = buffer.trim();
      int start_index = 0;
      for (start_index = 0; start_index < buffer.length(); start_index++)
      {
         if (!Character.isWhitespace(buffer.charAt(start_index)))
         {
            break;
         }
      }
      final int end_index = start_index;

      if (doublePattern == null)
      {
         doublePattern =
            Pattern.compile("(\\+|\\-)?[0-9]*\\.?[0-9]*"
                  + "((d|D|e|E)(\\+|\\-)?[0-9]+)?");
      }
      final Matcher matcher = doublePattern.matcher(buffer);
      matcher.find(start_index);

      final String tmpStr = matcher.group().replace('D', 'E');
      stop_index.setLength(matcher.end(), 0);

      // Remove whitespaces from string
      // String tmpStr = buffer.trim();

      // Extract value from string
      return Double.parseDouble(tmpStr);
   }

   /**
    * Returns a decimal extracted from String. This implementation assumes that
    * string is not null. No exception is caught therefore NumberFormatException
    * shall be managed by the calling operation.
    * 
    * @param buffer The buffer containing the value to extract from.
    * @param stop_index The stop index in the buffer.
    * @return The decimal value extracted from buffer.
    */
   protected final static String extractAsciiDecimal(final String buffer,
         final Length stop_index)
   {
      // WARNING: check the lexical space
      int start_index = 0;
      for (start_index = 0; start_index < buffer.length(); start_index++)
      {
         if (!Character.isWhitespace(buffer.charAt(start_index)))
         {
            break;
         }
      }
      final int end_index = start_index;

      if (doublePattern == null)
      {
         doublePattern =
            Pattern.compile("(\\+|\\-)?[0-9]*\\.?[0-9]*"
                  + "((d|D|e|E)(\\+|\\-)?[0-9]+)?");
      }
      final Matcher matcher = doublePattern.matcher(buffer);
      matcher.find(start_index);

      final String tmpStr = matcher.group().replace('D', 'E');
      stop_index.setLength(matcher.end(), 0);

      // Extract value from string
      return matcher.group().replace('D', 'E');
   }

   /**
    * Skip to the next delimiter and returns the number of byte read.
    * 
    * @param buffer The buffer containing the value to extract from.
    * @param stop_index The stop index in the buffer.
    * @param end_delimiter The end delimiter.
    */
   protected final static int skipDelimiter(final byte[] buffer,
         final int stop_index, final String end_delimiter)
   {
      if (end_delimiter.length() == 0)
      {
         return stop_index;
      }
      final byte delimiter_char = (byte) end_delimiter.charAt(0);
      for (int i = stop_index; i < buffer.length; i++)
      {
         if (buffer[i] == delimiter_char)
         {
            return i + 1;
         }
      }
      return buffer.length;
   }

   /**
    * Extracts a BINARY integer
    * 
    * @param buffer The buffer containing the value to extract from.
    * @param len the length of the integer value
    * @return The integer value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   protected final static java.math.BigInteger extractBinaryInteger(
         final byte[] buffer, final Length len, boolean is_signed)
   {
      final int byte_len = (int) len.getLength();
      final int bit_len = (int) len.getBitLength();
      if (bit_len > 0)
      {
         final int comp_bit_len = 8 - bit_len;
         for (int i = byte_len; i > 0; i--)
         {
            buffer[i] =
               (byte) (((buffer[i] & 0xff) >>> comp_bit_len) | ((buffer[i - 1] & 0xff) << bit_len));
         }
         buffer[0] = (byte) ((buffer[0] & 0xff) >>> comp_bit_len);
         if (is_signed)
         {
            buffer[0] = (byte) ((buffer[0] & 0xff) | (0xff << bit_len));
         }
      }
      if (!is_signed && (buffer[0] < 0))
      {
         return new java.math.BigInteger(+1, buffer);
      }
      else
      {
         return new java.math.BigInteger(buffer);
      }
   }

   /**
    * Swap a byte buffer.
    * 
    * @param buffer The buffer containing the value to extract from.
    * @param off the offset in the buffer
    * @param len the number of byte values to swap
    */
   protected final static void swapBuffer(final byte[] buffer, final int off,
         final int len)
   {
      // Swap bytes
      int i1 = off;
      int i2 = len - 1;

      while (i1 < i2)
      {
         final byte tmp = buffer[i1];
         buffer[i1++] = buffer[i2];
         buffer[i2--] = tmp;
      }
   }

   /**
    * Returns a Value extracted from a file with a encoding method. If the file
    * is null or returns null. If encoding is not supported returns null. This
    * implementation supports the following encoding methods (defined in
    * Descriptor class) :
    * <dl>
    * <dd>ENCODING_ASCII</dd>
    * <dl>
    * ENCODING_BINARY
    * </dl>
    * </dl>
    * <dl>
    * <dt>The following exception are caught :</dt>
    * <dd>NumberFormatException
    * <dd>
    * <dd>IOException
    * <dd>
    * <dd>EOFException
    * <dd>
    * </dl>
    * In case of such exceptions returns null.
    * 
    * @param descriptor The descriptor of the block.
    * @param start_offset The start offset in the file.
    * @param stop_offset The stop offset in the file.
    * @param array_size The array size if value_type=ARRAY_ID.
    * @param array_element_size The size of an element in the array
    * @return The Integer extracted from buffer.
    * @throws EOFException This exception is raised when it is the end of the
    *            file
    * @throws IOException a ioexception
    */
   protected final static fr.gael.drb.value.Value extractValue(
         final Descriptor descriptor, final Length start_offset,
         Length stop_offset, final long item_count, final Length item_length)
         throws EOFException, IOException
   {
      final RandomAccessData file = descriptor.getFile();
      int encoding = descriptor.getEncoding();
      final int byte_order = descriptor.getByteOrdering();
      final int value_type = descriptor.getValueType();
      final int array_value_type = descriptor.getArrayValueType();
      final String array_delimiter = descriptor.getArrayDelimiter();
      /*
       * DEBUG if (logger.isDebugEnabled()) { logger.debug( "extractValue(file,
       * start_offset=" + start_offset + ", stop_offset=" + stop_offset + ",
       * encoding=" + encoding + ", byte_order=" + byte_order + ", value_type=" +
       * value_type + ", array_value_type=" + array_value_type + ", array_size=" +
       * array_size); } DEBUG
       */
      // Check parameter
      if (file == null)
      {
         return null;
      }

      // Local declarations
      byte[] buffer = {};
      final Value curValue; // Current value in array
      int curOffset; // Current offset (for array)
      final int lengthRead; // Length read from file
      final int bit_offset = start_offset.getBitLength();
      final long offset = start_offset.getLength();
      Length value_length = null;
      int bit_length = -1;
      int length = -1;
      final int array_size = (int) item_count;
      int element_bit_length = -1;
      int element_length = -1;

      // Manage Exceptions
      try
      {
         // Set file pointer position

         if (stop_offset.getLength() >= 0)
         {
            length = (int) (stop_offset.getLength() - start_offset.getLength());
            bit_length =
               (int) (stop_offset.getBitLength() - start_offset.getBitLength());
            value_length = new Length(length, bit_length);
            if (bit_length != 0)
            {
               length = (int) value_length.getLength();
               bit_length = value_length.getBitLength();
            }
         }
         if (item_length != null)
         {
            element_length = (int) item_length.getLength();
            element_bit_length = (int) item_length.getBitLength();
         }

         // Read buffer from file
         file.seek(start_offset);
         if (length >= 0)
         {
            buffer = new byte[(8 * length + bit_length + 7) / 8];
            if (bit_length > 0)
            {
               file.readFully(buffer, 0, new Length(length, bit_length));
            }
            else
            {
               file.readFully(buffer, 0, length);
            }
         }
         else
         // unknown length
         {
            Length buf_length = null;
            final String delimiter = descriptor.getDelimiter();
            if (delimiter.length() > 0)
            {
               int bufsize = 0;
               final char delimiter_char = delimiter.charAt(0);
               while (file.available() > 0)
               {
                  final char cur_char = (char) file.readByte();
                  if (cur_char == delimiter_char)
                  {
                     break;
                  }
                  bufsize++;
               }
               // rewind the file
               file.seek(start_offset);
               stop_offset.setLength(start_offset.getLength() + bufsize);
               buffer = new byte[bufsize];
               stop_offset = new Length(stop_offset.getLength(), 0);
               buf_length = new Length(bufsize);
               logger.debug("Extracted " + bufsize + " bytes delimited by '"
                     + delimiter + "'");
            }
            else // Case of array
            if ((value_type != Value.ARRAY_ID) || (item_count >= 0))
            {
               if ((element_length >= 0) && (element_bit_length >= 0))
               {
                  buf_length =
                     new Length(item_count * element_length, item_count
                           * element_bit_length);
               }
               else if (value_type == Value.ARRAY_ID)
               {
                  buf_length = new Length((int) item_count * 32);
               }
               else
               {
                  buf_length = new Length(32);
               }
               int bufsize =
                  (int) (8 * buf_length.getLength() + buf_length.getBitLength() + 7) / 8;
               int max_len = file.skipBytes(bufsize);
               file.seek(start_offset);
               if (max_len < bufsize)
               {
                  max_len = Math.max(max_len, 0);
                  bufsize = max_len;
                  buf_length = new Length(max_len);
               }
               buffer = new byte[bufsize];
            }
            file.readFully(buffer, 0, buf_length);
         }

         // Translates bytes to ASCII
         if (encoding == Descriptor.ENCODING_TEXT)
         {
            if (descriptor.charsetName == Descriptor.CHARSET_US_ASCII)
            {
               for (int i=0; i<buffer.length; i++)
               {
                  buffer[i] = (byte)(buffer[i] & 0x7F);
               }
            }
            else
            if (descriptor.charsetName != Descriptor.CHARSET_ASCII)
            {
               String text = new String(buffer, descriptor.charsetName);
               buffer = text.getBytes();
            }
         }

         // Check if encoding is valid
         if ((encoding != Descriptor.ENCODING_TEXT)
               && (encoding != Descriptor.ENCODING_BINARY))
         {
            logger.error("fr.gael.drb.impl.sdf.BlockTools.extractValue() : "
                  + "Encoding not supported ! (encoding=" + encoding + ").");
            return null;
         }

         // Switch on value type
         switch (value_type)
         {
            // Case of String
            case Value.STRING_ID:
               return new fr.gael.drb.value.String(buffer);

               // Case of Unsigned Byte
            case Value.UNSIGNED_BYTE_ID:
               // Case of Byte
            case Value.BYTE_ID:
               byte byte_value;
               if (encoding == Descriptor.ENCODING_TEXT)
               {
                  final Length stop_index = new Length(length, 0);
                  byte_value = (byte) extractAsciiLong(buffer, stop_index);
                  stop_offset.setLength(start_offset.getLength()
                        + stop_index.getLength());
                  logger.debug("Extracted ASCII byte value (" + byte_value
                        + ")");
               }
               else if ((bit_length == 0) && (length == 1))
               {
                  byte_value = buffer[0];
               }
               else
               {
                  byte_value =
                     extractBinaryInteger(buffer, value_length,
                           (value_type == Value.BYTE_ID)).byteValue();
               }
               if (value_type == Value.BYTE_ID)
               {
                  return new fr.gael.drb.value.Byte(byte_value);
               }
               else
               {
                  return new fr.gael.drb.value.UnsignedByte(byte_value);
               }

               // Case of Unsigned Short
            case Value.UNSIGNED_SHORT_ID:
               // Case of Short
            case Value.SHORT_ID:
               short short_value;
               if (encoding == Descriptor.ENCODING_TEXT)
               {
                  final Length stop_index = new Length(length, 0);
                  short_value = (short) extractAsciiLong(buffer, stop_index);
                  stop_offset.setLength(start_offset.getLength()
                        + stop_index.getLength());
               }
               else // BINARY
               if ((bit_length == 0) && (length == 2))
               {
                  if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                  {
                     short_value =
                        (short) (((buffer[1] & 0xff) << 8) + (buffer[0] & 0xff));
                  }
                  else
                  // MSB
                  {
                     short_value =
                        (short) (((buffer[0] & 0xff) << 8) + (buffer[1] & 0xff));
                  }
               }
               else
               {
                  short_value =
                     extractBinaryInteger(buffer, value_length,
                           value_type == Value.SHORT_ID).shortValue();
               }
               if (value_type == Value.SHORT_ID)
               {
                  return new fr.gael.drb.value.Short(short_value);
               }
               else
               {
                  return new fr.gael.drb.value.UnsignedShort(short_value);
               }

               // Case of Unsigned Int
            case Value.UNSIGNED_INT_ID:
               // Case of Int
            case Value.INT_ID:
               int int_value;
               if (encoding == Descriptor.ENCODING_TEXT)
               {
                  final Length stop_index = new Length(length, 0);
                  int_value = (int) extractAsciiLong(buffer, stop_index);
                  stop_offset.setLength(start_offset.getLength()
                        + stop_index.getLength());
               }
               else if ((bit_length == 0) && (length == 4))
               {
                  if (byte_order == Descriptor.BYTE_ORDERING_MSB)
                  {
                     int_value =
                        ((buffer[0] & 0xff) << 24) + ((buffer[1] & 0xff) << 16)
                              + ((buffer[2] & 0xff) << 8) + (buffer[3] & 0xff);
                  }
                  else
                  // LSB
                  {
                     int_value =
                        ((buffer[3] & 0xff) << 24) + ((buffer[2] & 0xff) << 16)
                              + ((buffer[1] & 0xff) << 8) + (buffer[0] & 0xff);
                  }
               }
               else
               {
                  int_value =
                     extractBinaryInteger(buffer, value_length,
                           value_type == Value.INT_ID).intValue();
               }
               if (value_type == Value.INT_ID)
               {
                  return new fr.gael.drb.value.Int(int_value);
               }
               else
               {
                  return new fr.gael.drb.value.UnsignedInt(int_value);
               }

               // Case of Unsigned Long
            case Value.UNSIGNED_LONG_ID:
               // Case of Long
            case Value.LONG_ID:
               long long_value;
               if (encoding == Descriptor.ENCODING_TEXT)
               {
                  final Length stop_index = new Length(length, 0);
                  long_value = (long) extractAsciiLong(buffer, stop_index);
                  stop_offset.setLength(start_offset.getLength()
                        + stop_index.getLength());
               }
               else if ((bit_length == 0) && (length == 8))
               {
                  if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                  {
                     long_value =
                        ((long) ((buffer[7] & 0xff)) << 56)
                              + ((long) ((buffer[6] & 0xff)) << 48)
                              + ((long) ((buffer[5] & 0xff)) << 40)
                              + ((long) ((buffer[4] & 0xff)) << 32)
                              + ((long) ((buffer[3] & 0xff)) << 24)
                              + ((long) ((buffer[2] & 0xff)) << 16)
                              + ((long) ((buffer[1] & 0xff)) << 8)
                              + (long) (buffer[0] & 0xff);
                  }
                  else
                  {
                     long_value =
                        ((long) ((buffer[0] & 0xff)) << 56)
                              + ((long) ((buffer[1] & 0xff)) << 48)
                              + ((long) ((buffer[2] & 0xff)) << 40)
                              + ((long) ((buffer[3] & 0xff)) << 32)
                              + ((long) ((buffer[4] & 0xff)) << 24)
                              + ((long) ((buffer[5] & 0xff)) << 16)
                              + ((long) ((buffer[6] & 0xff)) << 8)
                              + (long) (buffer[7] & 0xff);
                  }
               }
               else
               {
                  long_value =
                     extractBinaryInteger(buffer, value_length,
                           value_type == Value.LONG_ID).longValue();
               }
               if (value_type == Value.LONG_ID)
               {
                  return new fr.gael.drb.value.Long(long_value);
               }
               else
               {
                  return new fr.gael.drb.value.UnsignedLong(long_value);
               }

               // Case of Float
            case Value.FLOAT_ID:
               float float_value;
               if (encoding == Descriptor.ENCODING_TEXT)
               {
                  final Length stop_index = new Length(length, 0);
                  float_value = (float) extractAsciiDouble(buffer, stop_index);
                  if (length < 0)
                  {
                     stop_offset.setLength(start_offset.getLength()
                           + stop_index.getLength());
                  }
               }
               else if ((bit_length == 0) && (length == 4))
               {
                  if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                  {
                     float_value =
                        Float.intBitsToFloat(((buffer[3] & 0xff) << 24)
                              + ((buffer[2] & 0xff) << 16)
                              + ((buffer[1] & 0xff) << 8) + (buffer[0] & 0xff));
                  }
                  else
                  {
                     float_value =
                        Float.intBitsToFloat(((buffer[0] & 0xff) << 24)
                              + ((buffer[1] & 0xff) << 16)
                              + ((buffer[2] & 0xff) << 8) + (buffer[3] & 0xff));
                  }
               }
               else
               {
                  logger
                        .error("Only IEEE format is supported for BINARY float. "
                              + "(length="
                              + length
                              + ", bits="
                              + bit_length
                              + ")");
                  return null;
               }
               return new fr.gael.drb.value.Float(float_value);

               // Case of Double
            case Value.DOUBLE_ID:
               double double_value;
               if (encoding == Descriptor.ENCODING_TEXT)
               {
                  final Length stop_index = new Length(length, 0);
                  double_value = extractAsciiDouble(buffer, stop_index);
                  if (length < 0)
                  {
                     stop_offset.setLength(start_offset.getLength()
                           + stop_index.getLength());
                  }
               }
               else if ((bit_length == 0) && (length == 8))
               {
                  if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                  {
                     long_value =
                        ((long) ((buffer[7] & 0xff)) << 56)
                              + ((long) ((buffer[6] & 0xff)) << 48)
                              + ((long) ((buffer[5] & 0xff)) << 40)
                              + ((long) ((buffer[4] & 0xff)) << 32)
                              + ((long) ((buffer[3] & 0xff)) << 24)
                              + ((long) ((buffer[2] & 0xff)) << 16)
                              + ((long) ((buffer[1] & 0xff)) << 8)
                              + (long) (buffer[0] & 0xff);
                  }
                  else
                  {
                     long_value =
                        ((long) ((buffer[0] & 0xff)) << 56)
                              + ((long) ((buffer[1] & 0xff)) << 48)
                              + ((long) ((buffer[2] & 0xff)) << 40)
                              + ((long) ((buffer[3] & 0xff)) << 32)
                              + ((long) ((buffer[4] & 0xff)) << 24)
                              + ((long) ((buffer[5] & 0xff)) << 16)
                              + ((long) ((buffer[6] & 0xff)) << 8)
                              + (long) (buffer[7] & 0xff);
                  }
                  double_value = Double.longBitsToDouble(long_value);
               }
               else
               {
                  logger
                        .error("Only IEEE format is supported for BINARY double. "
                              + "(length="
                              + length
                              + ", bits="
                              + bit_length
                              + ")");
                  return null;
               }
               return new fr.gael.drb.value.Double(double_value);

               // Case of Decimal
            case Value.DECIMAL_ID:
               if (encoding == Descriptor.ENCODING_TEXT)
               {
                  final Length stop_index = new Length(length, 0);
                  final Value value =
                     new fr.gael.drb.value.Decimal(extractAsciiDecimal(
                           new String(buffer), stop_index));
                  if (length < 0)
                  {
                     stop_offset.setLength(start_offset.getLength()
                           + stop_index.getLength());
                  }
                  return value;
               }
               else
               {
                  logger.warn("decimal is not supported for BINARY encoding.");
                  return null;
               }

               // Case of Integer
            case Value.INTEGER_ID:
               java.math.BigInteger integer_value;
               if (encoding == Descriptor.ENCODING_TEXT)
               {
                  final Length stop_index = new Length(length, 0);
                  integer_value =
                     new java.math.BigInteger(extractAsciiDecimal(new String(
                           buffer), stop_index));
                  if (length < 0)
                  {
                     stop_offset.setLength(start_offset.getLength()
                           + stop_index.getLength());
                  }
               }
               else if (byte_order == Descriptor.BYTE_ORDERING_LSB)
               {
                  // Swap bytes
                  int i1 = 0;
                  int i2 = length - 1;
                  while (i1 < i2)
                  {
                     final byte tmp = buffer[i1];
                     buffer[i1++] = buffer[i2];
                     buffer[i2--] = tmp;
                  }
                  integer_value = new java.math.BigInteger(buffer);
               }
               else
               {
                  integer_value =
                     extractBinaryInteger(buffer, value_length, true);
               }
               return new fr.gael.drb.value.Integer(integer_value);

               // Case of Date
            case Value.DATE_ID:
               // The representation is assumed as "UTC" time (27 bytes) :
               // format : "DD-MMM-YYYY hh:mm:ss.tttttt".
               if (encoding == Descriptor.ENCODING_TEXT)
               {
                  int len = buffer.length;
                  if (buffer.length > 27)
                  {
                     len = 27;
                  }
                  final Value value =
                     new fr.gael.drb.value.DateTime(new String(buffer, 0, len));
                  stop_offset.setLength(start_offset.getLength()
                        + value.toString().length());
                  return value;
               }
               else
               {
                  return new fr.gael.drb.value.DateTime(buffer);
               }

            case Value.BOOLEAN_ID:
               if (encoding == Descriptor.ENCODING_TEXT)
               {
                  final Length stop_index = new Length(length, 0);
                  final Value value =
                     new fr.gael.drb.value.Boolean(extractAsciiBoolean(
                           new String(buffer), stop_index));

                  stop_offset.setLength(start_offset.getLength()
                        + stop_index.getLength());
                  return value;
               }
               else if ((bit_length == 0) && (length == 1))
               {
                  return new fr.gael.drb.value.Boolean((int) buffer[0]);
               }
               else
               {
                  return new fr.gael.drb.value.Boolean(extractBinaryInteger(
                        buffer, value_length, false).intValue());
               }

               // Case of Array
            case Value.ARRAY_ID:
               // Compute array item size
               curOffset = 0;
               final Length stop_index =
                  new Length(element_length, element_bit_length);

               // Check array value_type
               switch (array_value_type)
               {
                  // Case of byte in array
                  case Value.UNSIGNED_BYTE_ID:
                  case Value.BYTE_ID:
                     // Case of ascii values
                     byte[] byteArray = buffer;
                     if (encoding == Descriptor.ENCODING_TEXT)
                     {
                        byteArray = new byte[array_size];
                        for (int i = 0; i < array_size; i++)
                        {
                           byteArray[i] =
                              (byte) extractAsciiLong(buffer, curOffset,
                                    stop_index);
                           if (element_length > 0)
                           {
                              curOffset += element_length;
                           }
                           else
                           {
                              curOffset =
                                 skipDelimiter(buffer, curOffset
                                       + (int) stop_index.getLength(),
                                       array_delimiter);
                           }
                        }
                        stop_offset.setLength(start_offset.getLength()
                              + curOffset);
                     }
                     // Case of binary values, return the buffer itself
                     else if ((element_bit_length != 0)
                           || (element_length != 1))
                     {
                        file.seek(start_offset);
                        for (int i = 0; i < array_size; i++)
                        {
                           byteArray[i] =
                              file.readInteger(item_length,
                                    (array_value_type == Value.BYTE_ID))
                                    .byteValue();
                        }
                     }
                     else
                     {
                        byteArray = buffer;
                     }
                     // Return array
                     if (array_value_type == Value.UNSIGNED_BYTE_ID)
                     {
                        return new fr.gael.drb.value.UnsignedByteArray(
                              byteArray);
                     }
                     else
                     {
                        return new fr.gael.drb.value.ByteArray(byteArray);
                     }

                     // Case of double in array
                  case Value.DOUBLE_ID:
                     final double[] doubleArray = new double[array_size];
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_TEXT)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           doubleArray[i] =
                              extractAsciiDouble(buffer, curOffset, stop_index);
                           if (element_length > 0)
                           {
                              curOffset += element_length;
                           }
                           else
                           {
                              curOffset =
                                 skipDelimiter(buffer, curOffset
                                       + (int) stop_index.getLength(),
                                       array_delimiter);
                           }
                        }
                        stop_offset.setLength(start_offset.getLength()
                              + curOffset);
                     }
                     // Case of binary values
                     else if ((element_bit_length == 0)
                           && (element_length == 8))
                     {
                        // Create a long to use as bits reprensentation of
                        // a double with Double.longBitsToDouble(long bits).
                        long tmpLong = 0;
                        if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                        {
                           for (int i = 0; i < array_size; i++)
                           {
                              tmpLong =
                                 ((long) ((buffer[i * 8 + 7] & 0xff)) << 56)
                                       + ((long) ((buffer[i * 8 + 6] & 0xff)) << 48)
                                       + ((long) ((buffer[i * 8 + 5] & 0xff)) << 40)
                                       + ((long) ((buffer[i * 8 + 4] & 0xff)) << 32)
                                       + ((long) ((buffer[i * 8 + 3] & 0xff)) << 24)
                                       + ((long) ((buffer[i * 8 + 2] & 0xff)) << 16)
                                       + ((long) ((buffer[i * 8 + 1] & 0xff)) << 8)
                                       + (long) (buffer[i * 8] & 0xff);
                              doubleArray[i] = Double.longBitsToDouble(tmpLong);
                           }
                        }
                        else
                        {
                           for (int i = 0; i < array_size; i++)
                           {
                              tmpLong =
                                 ((long) ((buffer[i * 8] & 0xff)) << 56)
                                       + ((long) ((buffer[i * 8 + 1] & 0xff)) << 48)
                                       + ((long) ((buffer[i * 8 + 2] & 0xff)) << 40)
                                       + ((long) ((buffer[i * 8 + 3] & 0xff)) << 32)
                                       + ((long) ((buffer[i * 8 + 4] & 0xff)) << 24)
                                       + ((long) ((buffer[i * 8 + 5] & 0xff)) << 16)
                                       + ((long) ((buffer[i * 8 + 6] & 0xff)) << 8)
                                       + (long) (buffer[i * 8 + 7] & 0xff);
                              doubleArray[i] = Double.longBitsToDouble(tmpLong);
                           }
                        }
                     }
                     else
                     {
                        logger
                              .error("Only IEEE format is supported for BINARY double. "
                                    + "(length="
                                    + element_length
                                    + ", bits="
                                    + element_bit_length + ")");
                        return null;
                     }
                     // Return array
                     return new fr.gael.drb.value.DoubleArray(doubleArray);

                     // Case of float in array
                  case Value.FLOAT_ID:
                     final float[] floatArray = new float[array_size];
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_TEXT)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           floatArray[i] =
                              (float) extractAsciiDouble(buffer, curOffset,
                                    stop_index);
                           if (element_length > 0)
                           {
                              curOffset += element_length;
                           }
                           else
                           {
                              curOffset =
                                 skipDelimiter(buffer, curOffset
                                       + (int) stop_index.getLength(),
                                       array_delimiter);
                           }
                        }
                        stop_offset.setLength(start_offset.getLength()
                              + curOffset);
                     }
                     // Case of binary values
                     else if ((element_bit_length == 0)
                           && (element_length == 4))
                     {
                        // Create a int to use as bits reprensentation of
                        // a float with Float.intBitsToFloat(int bits).
                        int tmpInt = 0;
                        for (int i = 0; i < array_size; i++)
                        {
                           if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                           {
                              tmpInt =
                                 ((buffer[i * 4 + 3] & 0xff) << 24)
                                       + ((buffer[i * 4 + 2] & 0xff) << 16)
                                       + ((buffer[i * 4 + 1] & 0xff) << 8)
                                       + (buffer[i * 4] & 0xff);
                           }
                           else
                           {
                              tmpInt =
                                 ((buffer[i * 4] & 0xff) << 24)
                                       + ((buffer[i * 4 + 1] & 0xff) << 16)
                                       + ((buffer[i * 4 + 2] & 0xff) << 8)
                                       + (buffer[i * 4 + 3] & 0xff);
                           }
                           floatArray[i] = Float.intBitsToFloat(tmpInt);
                        }
                     }
                     else
                     {
                        logger
                              .error("Only IEEE format is supported for BINARY float. "
                                    + "(length="
                                    + element_length
                                    + ", bits="
                                    + element_bit_length + ")");
                        return null;
                     }

                     // Return array
                     return new fr.gael.drb.value.FloatArray(floatArray);

                     // Case of decimal in array
                  case Value.DECIMAL_ID:
                     final fr.gael.drb.value.DefaultValueArray decimalArray =
                        new fr.gael.drb.value.DefaultValueArray(array_size);
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_TEXT)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           decimalArray.assign(i,
                                 new fr.gael.drb.value.Decimal(
                                       extractAsciiDecimal(new String(buffer,
                                             curOffset, buffer.length
                                                   - curOffset), stop_index)));

                           if (element_length > 0)
                           {
                              curOffset += element_length;
                           }
                           else
                           {
                              curOffset =
                                 skipDelimiter(buffer, curOffset
                                       + (int) stop_index.getLength(),
                                       array_delimiter);
                           }
                        }
                        stop_offset.setLength(start_offset.getLength()
                              + curOffset);
                     }
                     // Case of binary values
                     else
                     {
                        logger
                              .error("fr.gael.drb.impl.sdf.BlockTools.extractValue() : "
                                    + "Decimal array not supported for BINARY encoding.");
                        return null;
                     }
                     // Return array
                     return decimalArray;

                     // Case of unsigned int in array
                  case Value.UNSIGNED_INT_ID:
                  case Value.INT_ID: // Case of int in array
                     final int[] intArray = new int[array_size];
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_TEXT)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           intArray[i] =
                              (int) extractAsciiLong(buffer, curOffset,
                                    stop_index);
                           if (element_length > 0)
                           {
                              curOffset += element_length;
                           }
                           else
                           {
                              curOffset =
                                 skipDelimiter(buffer, curOffset
                                       + (int) stop_index.getLength(),
                                       array_delimiter);
                           }
                        }
                        stop_offset.setLength(start_offset.getLength()
                              + curOffset);
                     }
                     // Case of binary values
                     else if ((element_bit_length != 0)
                           || (element_length != 4))
                     {
                        file.seek(start_offset);
                        for (int i = 0; i < array_size; i++)
                        {
                           intArray[i] =
                              file.readInteger(item_length,
                                    (array_value_type == Value.INT_ID))
                                    .intValue();
                        }
                     }
                     else if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           intArray[i] =
                              ((buffer[i * 4 + 3] & 0xff) << 24)
                                    + ((buffer[i * 4 + 2] & 0xff) << 16)
                                    + ((buffer[i * 4 + 1] & 0xff) << 8)
                                    + (buffer[i * 4 + 0] & 0xff);
                        }
                     }
                     else
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           intArray[i] =
                              ((buffer[i * 4] & 0xff) << 24)
                                    + ((buffer[i * 4 + 1] & 0xff) << 16)
                                    + ((buffer[i * 4 + 2] & 0xff) << 8)
                                    + (buffer[i * 4 + 3] & 0xff);
                        }
                     }
                     // Return array
                     if (array_value_type == Value.UNSIGNED_INT_ID)
                     {
                        return new fr.gael.drb.value.UnsignedIntArray(intArray);
                     }
                     else
                     {
                        return new fr.gael.drb.value.IntArray(intArray);
                     }

                     // Case of long in array
                  case Value.UNSIGNED_LONG_ID:
                  case Value.LONG_ID:
                     final long[] longArray = new long[array_size];
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_TEXT)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           longArray[i] =
                              (long) extractAsciiLong(buffer, curOffset,
                                    stop_index);
                           if (element_length > 0)
                           {
                              curOffset += element_length;
                           }
                           else
                           {
                              curOffset =
                                 skipDelimiter(buffer, curOffset
                                       + (int) stop_index.getLength(),
                                       array_delimiter);
                           }
                        }
                        stop_offset.setLength(start_offset.getLength()
                              + curOffset);
                     }
                     // Case of binary values
                     else if ((element_bit_length != 0)
                           || (element_length != 8))
                     {
                        file.seek(start_offset);
                        for (int i = 0; i < array_size; i++)
                        {
                           longArray[i] =
                              file.readInteger(item_length,
                                    (array_value_type == Value.LONG_ID))
                                    .longValue();
                        }
                     }
                     else if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           longArray[i] =
                              ((long) ((buffer[i * 8 + 7] & 0xff)) << 56)
                                    + ((long) ((buffer[i * 8 + 6] & 0xff)) << 48)
                                    + ((long) ((buffer[i * 8 + 5] & 0xff)) << 40)
                                    + ((long) ((buffer[i * 8 + 4] & 0xff)) << 32)
                                    + ((long) ((buffer[i * 8 + 3] & 0xff)) << 24)
                                    + ((long) ((buffer[i * 8 + 2] & 0xff)) << 16)
                                    + ((long) ((buffer[i * 8 + 1] & 0xff)) << 8)
                                    + (long) (buffer[i * 8] & 0xff);
                        }
                     }
                     else
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           longArray[i] =
                              ((long) ((buffer[i * 8] & 0xff)) << 56)
                                    + ((long) ((buffer[i * 8 + 1] & 0xff)) << 48)
                                    + ((long) ((buffer[i * 8 + 2] & 0xff)) << 40)
                                    + ((long) ((buffer[i * 8 + 3] & 0xff)) << 32)
                                    + ((long) ((buffer[i * 8 + 4] & 0xff)) << 24)
                                    + ((long) ((buffer[i * 8 + 5] & 0xff)) << 16)
                                    + ((long) ((buffer[i * 8 + 6] & 0xff)) << 8)
                                    + (long) (buffer[i * 8 + 7] & 0xff);
                        }
                     }
                     // Return array
                     if (array_value_type == Value.UNSIGNED_LONG_ID)
                     {
                        return new fr.gael.drb.value.UnsignedLongArray(
                              longArray);
                     }
                     else
                     {
                        return new fr.gael.drb.value.LongArray(longArray);
                     }

                     // Case of unsigned short in array
                  case Value.UNSIGNED_SHORT_ID:
                  case Value.SHORT_ID: // Case of short in array
                     final short[] shortArray = new short[array_size];
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_TEXT)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           shortArray[i] =
                              (short) extractAsciiLong(buffer, curOffset,
                                    stop_index);
                           if (element_length > 0)
                           {
                              curOffset += element_length;
                           }
                           else
                           {
                              curOffset =
                                 skipDelimiter(buffer, curOffset
                                       + (int) stop_index.getLength(),
                                       array_delimiter);
                           }
                        }
                        stop_offset.setLength(start_offset.getLength()
                              + curOffset);
                     }
                     // Case of binary values
                     else if ((element_bit_length != 0)
                           || (element_length != 2))
                     {
                        file.seek(start_offset);
                        for (int i = 0; i < array_size; i++)
                        {
                           shortArray[i] =
                              file.readInteger(item_length,
                                    (array_value_type == Value.SHORT_ID))
                                    .shortValue();
                        }
                     }
                     else if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           shortArray[i] =
                              (short) ((buffer[i * 2 + 1] << 8) + (buffer[i * 2] & 0xff));
                        }

                     }
                     else
                     // MSB
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           shortArray[i] =
                              (short) ((buffer[i * 2] << 8) + (buffer[i * 2 + 1] & 0xff));
                        }
                     }
                     // Return array
                     if (array_value_type == Value.UNSIGNED_SHORT_ID)
                     {
                        return fr.gael.drb.value.UnsignedShortArray.
                           wrap(shortArray);
                     }
                     else
                     {
                        return new fr.gael.drb.value.ShortArray(shortArray);
                     }

                     // Case of boolean in array
                  case Value.BOOLEAN_ID:
                     final boolean[] booleanArray = new boolean[array_size];
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_TEXT)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           final String bool_str =
                              extractAsciiBoolean(new String(buffer, curOffset,
                                    buffer.length - curOffset), stop_index);
                           booleanArray[i] =
                              bool_str.equals("1") || bool_str.equals("true");
                           if (element_length > 0)
                           {
                              curOffset += element_length;
                           }
                           else
                           {
                              curOffset =
                                 skipDelimiter(buffer, curOffset
                                       + (int) stop_index.getLength(),
                                       array_delimiter);
                           }
                        }
                        stop_offset.setLength(start_offset.getLength()
                              + curOffset);
                     }
                     // Case of binary values
                     else if ((bit_length == 0) && (length == 1))
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           booleanArray[i] = (buffer[i] != 0);
                        }
                     }
                     else
                     {
                        file.seek(start_offset);
                        for (int i = 0; i < array_size; i++)
                        {
                           booleanArray[i] =
                              (file.readInteger(item_length, false).intValue() != 0);
                        }
                     }
                     // Return array
                     return new fr.gael.drb.value.BooleanArray(booleanArray);

                     // Case of Integer in array
                  case Value.INTEGER_ID:
                     final fr.gael.drb.value.DefaultValueArray integerArray =
                        new fr.gael.drb.value.DefaultValueArray(array_size);
                     // Case of ascii values
                     if (encoding == Descriptor.ENCODING_TEXT)
                     {
                        for (int i = 0; i < array_size; i++)
                        {
                           integerArray.assign(i,
                                 new fr.gael.drb.value.Integer(
                                       extractAsciiDecimal(new String(buffer,
                                             curOffset, buffer.length
                                                   - curOffset), stop_index)));

                           if (element_length > 0)
                           {
                              curOffset += element_length;
                           }
                           else
                           {
                              curOffset =
                                 skipDelimiter(buffer, curOffset
                                       + (int) stop_index.getLength(),
                                       array_delimiter);
                           }
                        }
                        stop_offset.setLength(start_offset.getLength()
                              + curOffset);
                     }
                     // Case of binary values
                     else if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                     {
                        int k = 0;
                        final byte[] integerBuffer = new byte[element_length];
                        for (int i = 0; i < array_size; i++)
                        {
                           int j = element_length - 1;
                           // Swap bytes: copy from end to start
                           while (j >= 0)
                           {
                              integerBuffer[j--] = buffer[k++];
                           }
                           integerArray.assign(i,
                                 new fr.gael.drb.value.Integer(integerBuffer));
                        }
                     }
                     else
                     {
                        file.seek(start_offset);
                        for (int i = 0; i < array_size; i++)
                        {
                           integerArray.assign(i,
                                 new fr.gael.drb.value.Integer(file
                                       .readInteger(new Length(element_length,
                                             element_bit_length), true)));
                        }
                     }
                     // Return array
                     return integerArray;

                     // Case of Date
                  case Value.DATE_ID:
                     // Local declaration
                     final fr.gael.drb.value.DefaultValueArray dateArray =
                        new fr.gael.drb.value.DefaultValueArray(array_size);
                     byte[] dateBuffer = new byte[] {};
                     if (element_length > 0)
                     {
                        dateBuffer = new byte[element_length];
                     }

                     curOffset = 0;
                     for (int i = 0; i < array_size; i++)
                     {
                        int date_length = element_length;
                        if ((element_length < 0)
                              && (array_delimiter.length() > 0))
                        {
                           final int end_offset =
                              skipDelimiter(buffer, curOffset, array_delimiter);
                           date_length =
                              end_offset - curOffset - array_delimiter.length();
                        }
                        for (int j = 0; j < date_length; j++)
                        {
                           dateBuffer[j] = buffer[curOffset++];
                        }
                        if (element_length >= 0)
                        {
                           curOffset =
                              skipDelimiter(buffer, curOffset, array_delimiter);
                        }
                        if (encoding == Descriptor.ENCODING_TEXT)
                        {
                           // The representation is assumed as "UTC" time (27
                           // bytes) :
                           // format : "DD-MMM-YYYY hh:mm:ss.tttttt".
                           dateArray.assign(i, new fr.gael.drb.value.DateTime(
                                 new String(dateBuffer, 0, date_length)));
                        }
                        else
                        {
                           // The representation is assumed as "MJD2000" time
                           // (12 bytes) :
                           dateArray.assign(i, new fr.gael.drb.value.DateTime(
                                 dateBuffer));
                        }
                     }
                     stop_offset
                           .setLength(start_offset.getLength() + curOffset);
                     return dateArray;

                     // Case of String
                  case Value.STRING_ID:
                     // Local declaration
                     final fr.gael.drb.value.DefaultValueArray stringArray =
                        new fr.gael.drb.value.DefaultValueArray(array_size);

                     curOffset = 0;
                     for (int i = 0; i < array_size; i++)
                     {
                        String current_string = null;
                        if (element_length >= 0)
                        {
                           current_string =
                              new String(buffer, curOffset, element_length);
                           curOffset = curOffset + element_length;
                        }
                        if (array_delimiter.length() > 0)
                        {
                           final int old_offset = curOffset;
                           curOffset =
                              skipDelimiter(buffer, curOffset, array_delimiter);
                           if (element_length < 0)
                           {
                              current_string =
                                 new String(buffer, old_offset, curOffset
                                       - old_offset - array_delimiter.length());
                           }
                        }
                        stringArray.assign(i, new fr.gael.drb.value.String(
                              current_string));
                     }
                     stop_offset
                           .setLength(start_offset.getLength() + curOffset);
                     return stringArray;
               }
               logger.error("fr.gael.drb.impl.sdf.BlockTools.extractValue() : "
                     + "Array type not supported (" + array_value_type + ").");
               return null;

               // Case of
            default:
               if (encoding == Descriptor.ENCODING_TEXT)
               {
                  return new fr.gael.drb.value.String(buffer)
                        .convertTo(value_type);
               }
               else
               {
                  logger.warn("The value type (" + value_type
                        + ") is not supported for BINARY encoding.");
                  return null;
               }
         }
      }
      // Case of NumberFormatException
      catch (final NumberFormatException e)
      {

         logger.debug("fr.gael.drb.impl.sdf.BlockTools.extractValue() : "
               + "Error while extracting value from Ascii buffer."
               + "descriptor=" + descriptor.getName() + ", offset=" + offset
               + ", length=" + length + ", buffer='" + new String(buffer)
               + "').");
         logger.debug("   " + e);

         return null;
      }
      catch (final EOFException e)
      {
         logger.debug("fr.gael.drb.impl.sdf.BlockTools.extractValue() : "
               + "End of file reached.");
         logger.debug("   " + e);
         return null;
      }
      catch (final Exception e)
      {
         logger.debug("fr.gael.drb.impl.sdf.BlockTools.extractValue() : "
               + "Error while reading file (" + "descriptor="
               + descriptor.getName() + ", offset=" + offset + ", length="
               + length + ", item_count=" + item_count + ", item_length="
               + item_length + ", value_type=" + value_type + ", buffer='"
               + new String(buffer) + "').");
         logger.debug("   " + e);
         return null;
      }
   }

   /**
    * Constraints a string to a specified length. If the input string is too
    * long it will be truncated as follow:<br>
    * getFixedString("Good Morning", 6, ' ') : "Good M"<br>
    * If the input string is too short it will be completed by the fill
    * character as follow:<br>
    * getFixedString("Good Morning", 16, '* ') : "Good Morning****".
    * 
    * @param in_value The input value.
    * @param length The output length (must be positive).
    * @param fill_char The char used to fill the string if needed.
    * @return The resulting string with the specified length or itself if
    *         lengths are equals or "" (empty String) in case of error.
    */
   private static final String getFixedString(final Value in_value,
         final int length, final char fill_char)
   {
      // Output length is 0, return empty string
      if (length == 0)
      {
         return "";
      }

      // Null input string, change to empty string
      if (in_value == null)
      {
         return getFixedString("", length, fill_char);
      }
      else
      {
         return getFixedString(in_value.toString(), length, fill_char);
      }
   }

   /**
    * Constraints a string to a specified length. If the input string is too
    * long it will be truncated as follow:<br>
    * getFixedString("Good Morning", 6, ' ') : "Good M"<br>
    * If the input string is too short it will be completed by the fill
    * character as follow:<br>
    * getFixedString("Good Morning", 16, '* ') : "Good Morning****".
    * 
    * @param in_str The input string.
    * @param length The output length (must be positive).
    * @param fill_char The char used to fill the string if needed.
    * @return The resulting string with the specified length or itself if
    *         lengths are equals or "" (empty String) in case of error.
    */
   public final static String getFixedString(String in_str, final int length,
         final char fill_char)
   {
      // Output length is 0, return empty string
      if (length == 0)
      {
         return "";
      }

      // Null input string, change to empty string
      if (in_str == null)
      {
         in_str = "";
      }

      // Lengths are equal, return the string itself
      final int inStrLength = in_str.length();
      if ((inStrLength == length) || (length < 0))
      {
         return in_str;
      }

      // Input string is too long, return a substring with good length
      if (inStrLength > length)
      {
         return in_str.substring(0, length);
      }

      // At this step the string is too short, append input string with the
      // needed number of fill characters and return it.
      for (int i = 0; i < (length - inStrLength); i++)
      {
         in_str = fill_char + in_str;
      }
      return in_str;
   }

   /**
    * Encodde a Value in a file with a encoding method. If the file is null
    * returns null. If encoding is not supported returns null. This
    * implementation supports the following encoding methods (defined in
    * Descriptor class) :
    * <dl>
    * <dd>ENCODING_ASCII</dd>
    * <dl>
    * ENCODING_BINARY
    * </dl>
    * </dl>
    * <dl>
    * <dt>The following exception are caught :</dt>
    * <dd>NumberFormatException
    * <dd>
    * <dd>IOException
    * <dd>
    * <dd>EOFException
    * <dd>
    * </dl>
    * In case of such exceptions returns null.
    * 
    * @param file The output file.
    * @param descriptor The descriptor of the block.
    * @param start_offset The start offset in the file.
    * @param stop_offset The stop offset in the file.
    * @param item_count The array size if value_type=ARRAY_ID.
    * @param item_length The length of an item in the array
    * @param value The value to encode.
    * @return The length of the encoded value.
    */
   protected final static Length encodeValue(final RandomAccessData file,
         final Descriptor descriptor, final Length start_offset,
         Length value_length, long item_count, final Length item_length,
         final Value value) throws IOException
   {
      final int encoding = descriptor.getEncoding();
      final int byte_order = descriptor.getByteOrdering();
      final int value_type = descriptor.getValueType();
      final int array_value_type = descriptor.getArrayValueType();
      final String array_delimiter = descriptor.getArrayDelimiter();
      byte[] buffer = {};

      if (logger.isDebugEnabled())
      {
         logger.debug("encodeValue(file, start_offset=" + start_offset
               + ", value_length=" + value_length + ", item_length="
               + item_length + ", encoding=" + encoding + ", byte_order="
               + byte_order + ", value_type=" + value_type
               + ", array_value_type=" + array_value_type);
      }

      // Check parameter
      if (file == null)
      {
         return null;
      }

      // Local declarations
      Value output_value = value; // The output value
      ValueArray value_array = null;
      int array_size = 0;

      final int bit_offset = start_offset.getBitLength();
      final long offset = start_offset.getLength();
      int bit_length = -1;
      int length = -1;
      int element_bit_length = -1;
      int element_length = -1;

      if (item_length != null)
      {
         element_length = (int) item_length.getLength();
         element_bit_length = (int) item_length.getBitLength();
      }
      if (value_length != null)
      {
         length = (int) value_length.getLength();
         bit_length = value_length.getBitLength();
      }
      // Manage Exceptions
      try
      {
         // Set file pointer position
         file.seek(start_offset);

         // Check if encoding is valid
         if ((encoding != Descriptor.ENCODING_TEXT)
               && (encoding != Descriptor.ENCODING_BINARY))
         {
            logger.error("fr.gael.drb.impl.sdf.BlockTools.encodeValue() : "
                  + "Encoding not supported ! (encoding=" + encoding + ").");
            return null;
         }

         /**
          * Case of ASCII encoding.
          */
         if (encoding == Descriptor.ENCODING_TEXT)
         {
            if (value_type != Value.ARRAY_ID)
            {
               String out_string = null;
               if (value != null)
               {
                  output_value = value.convertTo(value_type);
               }
               if ((descriptor.textFormat == null) || (value == null))
               {
                  out_string = getFixedString(output_value, length, ' ');
               }
               else
               {
                  out_string = descriptor.textFormat.formatString(output_value);
                  out_string = getFixedString(out_string, length, ' ');
               }
               logger.debug("Encoded input '" + value + "' as '" + out_string
                     + "'");
               file.writeBytes(out_string);
               return new Length(out_string.length());
            }
            else
            {
               value_array = null;
               if (value != null)
               {
                  output_value = value.convertTo(Value.ARRAY_ID);
                  value_array = (ValueArray) output_value;
               }
               if ((item_count < 0) && (value_array != null))
               {
                  item_count = value_array.length();
               }

               long total_length = 0;
               for (int i = 0; i < item_count; i++)
               {
                  Value value_item = null;
                  if ((value_array != null) && (i < value_array.length()))
                  {
                     value_item =
                        value_array.getElement(i).convertTo(array_value_type);
                  }
                  String out_string = null;
                  if ((descriptor.textFormat == null) || (value_item == null))
                  {
                     out_string =
                        getFixedString(value_item, element_length, ' ');
                  }
                  else
                  {
                     out_string =
                        descriptor.textFormat.formatString(value_item);
                     out_string =
                        getFixedString(out_string, element_length, ' ');
                  }
                  // Add delimiter if necessary
                  if ((element_length < 0) && (array_delimiter.length() == 0)
                        && (i != item_count - 1))
                  {
                     out_string = out_string + " ";
                  }
                  file.writeBytes(out_string + array_delimiter);

                  total_length += out_string.length();
               }
               if (length < 0)
               {
                  value_length = new Length(total_length);
               }
               else if (total_length < length)
               {
                  file.writeBytes(getFixedString("",
                        (int) (length - total_length), ' '));
               }
            }
            return value_length;
         }

         /**
          * Case of BINARY encoding.
          */
         // Switch on value type
         switch (value_type)
         {
            // Case of Byte or Boolean
            case Value.UNSIGNED_BYTE_ID:
            case Value.BYTE_ID:
            case Value.BOOLEAN_ID:
               if ((bit_length == 0) && (length == 1))
               {
                  if (value == null)
                  {
                     file.writeByte(0);
                  }
                  else
                  {
                     output_value = value.convertTo(Value.NUMERIC_ID);
                     file.writeByte(((Numeric) output_value).byteValue());
                  }
                  return value_length;
               }
               else if (value != null)
               {
                  output_value = value.convertTo(Value.NUMERIC_ID);
                  file.writeInteger((Numeric) output_value, value_length,
                        value_type == Value.BYTE_ID);
                  return value_length;
               }
               else
               {
                  file.writeInteger(new fr.gael.drb.value.Short(0),
                        value_length, false);
                  return value_length;
               }

               // Case of Short
            case Value.UNSIGNED_SHORT_ID:
            case Value.SHORT_ID:
               short short_value = 0;
               if ((bit_length == 0) && (length == 2))
               {
                  if (value != null)
                  {
                     output_value = value.convertTo(Value.NUMERIC_ID);
                     short_value = ((Numeric) output_value).shortValue();
                  }
                  if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                  {
                     short_value =
                        (short) (((short_value & 0xff00) >>> 8) | ((short_value & 0x00ff) << 8));
                  }
                  file.writeShort(short_value);
                  return value_length;
               }
               else if (value != null)
               {
                  output_value = value.convertTo(Value.NUMERIC_ID);
                  file.writeInteger((Numeric) output_value, value_length,
                        value_type == Value.SHORT_ID);
                  return value_length;
               }
               else
               {
                  file.writeInteger(new fr.gael.drb.value.Short(0),
                        value_length, false);
                  return value_length;
               }

               // Case of Int
            case Value.UNSIGNED_INT_ID:
            case Value.INT_ID:
               if ((bit_length == 0) && (length == 4))
               {
                  int int_value = 0;
                  if (value != null)
                  {
                     output_value = value.convertTo(Value.NUMERIC_ID);
                     int_value = ((Numeric) output_value).intValue();
                  }
                  if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                  {
                     int_value =
                        (int) (((int_value & 0xff000000) >>> 24)
                              | ((int_value & 0x00ff0000) >>> 8)
                              | ((int_value & 0x0000ff00) << 8) | ((int_value & 0x000000ff) << 24));
                  }
                  file.writeInt(int_value);
                  return value_length;
               }
               else if (value != null)
               {
                  output_value = value.convertTo(Value.NUMERIC_ID);
                  file.writeInteger((Numeric) output_value, value_length,
                        value_type == Value.INT_ID);
                  return value_length;
               }
               else
               {
                  file.writeInteger(new fr.gael.drb.value.Int(0), value_length,
                        false);
                  return value_length;
               }

               // Case of Long
            case Value.UNSIGNED_LONG_ID:
            case Value.LONG_ID:
               if ((bit_length == 0) && (length == 8))
               {
                  long long_value = 0;
                  if (value != null)
                  {
                     output_value = value.convertTo(Value.NUMERIC_ID);
                     long_value = ((Numeric) output_value).longValue();
                  }
                  if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                  {
                     long_value =
                        (long) (((long_value & 0xFF00000000000000L) >>> 56)
                              | ((long_value & 0x00FF000000000000L) >>> 40)
                              | ((long_value & 0x0000FF0000000000L) >>> 24)
                              | ((long_value & 0x000000FF00000000L) >>> 8)
                              | ((long_value & 0x00000000FF000000L) << 8)
                              | ((long_value & 0x0000000000FF0000L) << 24)
                              | ((long_value & 0x000000000000FF00L) << 40) | ((long_value & 0x00000000000000FFL) << 56));
                  }
                  file.writeLong(long_value);
                  return value_length;
               }
               else if (value != null)
               {
                  output_value = value.convertTo(Value.NUMERIC_ID);
                  file.writeInteger((Numeric) output_value, value_length,
                        value_type == Value.LONG_ID);
                  return value_length;
               }
               else
               {
                  file.writeInteger(new fr.gael.drb.value.Int(0), value_length,
                        false);
                  return value_length;
               }

               // Case of Float
            case Value.FLOAT_ID:
               if ((bit_length == 0) && (length == 4))
               {
                  float float_value = 0.0f;
                  if (value != null)
                  {
                     output_value = value.convertTo(Value.NUMERIC_ID);
                     float_value = ((Numeric) output_value).floatValue();
                  }
                  file.writeFloat(float_value);
                  return value_length;
               }
               else
               {
                  logger
                        .error("Only IEEE format is supported for BINARY float. "
                              + "(length="
                              + length
                              + ", bits="
                              + bit_length
                              + ")");
               }
               return null;

               // Case of Double
            case Value.DOUBLE_ID:
               if ((bit_length == 0) && (length == 8))
               {
                  double double_value = 0.0;
                  if (value != null)
                  {
                     output_value = value.convertTo(Value.DOUBLE_ID);
                     double_value = ((Numeric) output_value).doubleValue();
                  }
                  if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                  {
                  }
                  else
                  {
                     file.writeDouble(double_value);
                  }
                  return value_length;
               }
               else
               {
                  logger
                        .error("Only IEEE format is supported for BINARY double. "
                              + "(length="
                              + length
                              + ", bits="
                              + bit_length
                              + ")");
               }
               return null;

               // Case of Decimal
            case Value.DECIMAL_ID:
            {
               logger.warn("decimal is not supported for BINARY encoding.");
            }
               return null;

               // Case of Integer
            case Value.INTEGER_ID:
               if (value == null)
               {
                  file.writeInteger(new fr.gael.drb.value.Int(0), value_length,
                        false);
                  return value_length;
               }
               if (byte_order == Descriptor.BYTE_ORDERING_LSB)
               {
                  buffer = new byte[length];
                  output_value = value.convertTo(Value.INTEGER_ID);
                  final byte[] int_buf =
                     ((fr.gael.drb.value.Integer) output_value).integerValue()
                           .toByteArray();
                  // Swap bytes
                  int i1 = 0;
                  int i2 = int_buf.length - 1;
                  while ((i1 < length) && (i2 >= 0))
                  {
                     buffer[i1++] = int_buf[i2--];
                  }
                  final byte pad =
                     (byte) (((int_buf[0] & 0x80) != 0) ? 0xff : 0);
                  while (i1 < length)
                  {
                     buffer[i1++] = pad;
                  }
                  file.write(buffer, 0, value_length);
                  return value_length;
               }
               else
               {
                  output_value = value.convertTo(Value.INTEGER_ID);
                  file.writeInteger((Numeric) output_value, value_length, true);
                  return value_length;
               }

               // Case of Date
            case Value.DATE_ID:
               if ((bit_length == 0) && (length == 12))
               {
                  DateTime date_value = null;
                  if (value != null)
                  {
                     output_value = value.convertTo(Value.DATE_ID);
                     date_value = (DateTime) output_value;
                  }
                  else
                  {
                     date_value = new DateTime(0);
                  }
                  final byte[] date_buffer = date_value.getFormattedBuffer();
                  file.write(date_buffer);
                  return value_length;
               }
               else
               {
                  logger
                        .error("Only MJD2000 format is supported for BINARY dateTime. "
                              + "(length="
                              + length
                              + ", bits="
                              + bit_length
                              + ")");
               }
               return null;

               // Case of Array
            case Value.ARRAY_ID:
               // Compute array item size
               if (value != null)
               {
                  output_value = value.convertTo(Value.ARRAY_ID);
                  value_array = (fr.gael.drb.value.ValueArray) output_value;
                  array_size = value_array.length();
               }

               // Check parameters

               if (((item_count > 0) || (array_size * item_count != 0))
                     && ((element_length < 0) || (element_bit_length < 0)))
               {
                  logger
                        .error("Cannot encode array with undefined item length. "
                              + "(length="
                              + element_length
                              + ", bits="
                              + element_bit_length + ")");
                  return null;
               }

               if ((value == null) && (length >= 0))
               {
                  final byte[] byte_array = new byte[length];
                  java.util.Arrays.fill(byte_array, (byte) 0);
                  file.write(byte_array); // TBC: bit length
                  return value_length;
               }

               if (value_length == null)
               {
                  value_length =
                     new Length(array_size * element_length, array_size
                           * element_bit_length);
               }

               if (item_count < 0)
               {
                  item_count = array_size;
               }
               break;

            default:
               logger.error("fr.gael.drb.impl.sdf.BlockTools.encodeValue() : "
                     + "Value type not supported (" + value_type + ").");
               return null;
         }

         // TBC: Handle overflow and underflow

         // Check array value_type
         switch (array_value_type)
         {
            // Case of byte in array
            case Value.UNSIGNED_BYTE_ID:
            case Value.BYTE_ID:
            case Value.BOOLEAN_ID:
               value_array =
                  ((AbstractValueArray) output_value)
                        .convertArrayTo(array_value_type);
               if ((element_bit_length == 0) && (element_length == 1))
               {
                  final byte[] byte_array =
                     ((ValueFormat) value_array).getFormattedBuffer();
                  file.write(byte_array);
                  return value_length;
               }
               else
               {
                  for (int i = 0; i < item_count; i++)
                  {
                     file.writeInteger((Numeric) value_array.getElement(i),
                           item_length, array_value_type == Value.BYTE_ID);
                  }
                  return value_length;
               }

               // Case of double in array
            case Value.DOUBLE_ID:
               value_array =
                  ((AbstractValueArray) output_value)
                        .convertArrayTo(array_value_type);
               if ((element_bit_length == 0) && (element_length == 8))
               {
                  final byte[] byte_array =
                     ((ValueFormat) value_array).getFormattedBuffer();
                  file.write(byte_array);
                  return value_length;
               }
               logger.error("Only IEEE format is supported for BINARY double. "
                     + "(length=" + element_length + ", bits="
                     + element_bit_length + ")");
               return null;

               // Case of float in array
            case Value.FLOAT_ID:
               value_array =
                  ((AbstractValueArray) output_value)
                        .convertArrayTo(array_value_type);
               if ((element_bit_length == 0) && (element_length == 4))
               {
                  final byte[] byte_array =
                     ((ValueFormat) value_array).getFormattedBuffer();
                  file.write(byte_array);
                  return value_length;
               }
               logger.error("Only IEEE format is supported for BINARY float. "
                     + "(length=" + element_length + ", bits="
                     + element_bit_length + ")");
               return null;

               // Case of unsigned int in array
            case Value.UNSIGNED_INT_ID:
            case Value.INT_ID:
               value_array =
                  ((AbstractValueArray) output_value)
                        .convertArrayTo(array_value_type);
               if ((element_bit_length == 0) && (element_length == 4))
               {
                  final byte[] b =
                     ((ValueFormat) value_array).getFormattedBuffer();
                  if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                  {
                     byte tmp;
                     for (int i = 0; i < item_count; i++)
                     {
                        final int j = i * 4;
                        tmp = b[j + 0];
                        b[j + 0] = b[j + 3];
                        b[j + 3] = tmp;
                        tmp = b[j + 1];
                        b[j + 1] = b[j + 2];
                        b[j + 2] = tmp;
                     }
                  }
                  file.write(b);
                  return value_length;
               }
               else
               {
                  for (int i = 0; i < item_count; i++)
                  {
                     file.writeInteger((Numeric) value_array.getElement(i),
                           item_length, array_value_type == Value.INT_ID);
                  }
                  return value_length;
               }

               // Case of long in array
            case Value.UNSIGNED_LONG_ID:
            case Value.LONG_ID:
               value_array =
                  ((AbstractValueArray) output_value)
                        .convertArrayTo(array_value_type);
               if ((element_bit_length == 0) && (element_length == 8))
               {
                  final byte[] b =
                     ((ValueFormat) value_array).getFormattedBuffer();
                  if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                  {
                     byte tmp;
                     for (int i = 0; i < item_count; i++)
                     {
                        final int j = i * 8;
                        tmp = b[j + 0];
                        b[j + 0] = b[j + 7];
                        b[j + 7] = tmp;
                        tmp = b[j + 1];
                        b[j + 1] = b[j + 6];
                        b[j + 6] = tmp;
                        tmp = b[j + 2];
                        b[j + 2] = b[j + 5];
                        b[j + 5] = tmp;
                        tmp = b[j + 3];
                        b[j + 3] = b[j + 4];
                        b[j + 4] = tmp;
                     }
                  }
                  file.write(b);
                  return value_length;
               }
               else
               {
                  for (int i = 0; i < item_count; i++)
                  {
                     file.writeInteger((Numeric) value_array.getElement(i),
                           item_length, array_value_type == Value.LONG_ID);
                  }
                  return value_length;
               }

               // Case of unsigned short in array
            case Value.UNSIGNED_SHORT_ID:
            case Value.SHORT_ID:
               value_array =
                  ((AbstractValueArray) output_value)
                        .convertArrayTo(array_value_type);
               if ((element_bit_length == 0) && (element_length == 2))
               {
                  final byte[] b =
                     ((ValueFormat) value_array).getFormattedBuffer();
                  if (byte_order == Descriptor.BYTE_ORDERING_LSB)
                  {
                     for (int i = 0; i < item_count; i++)
                     {
                        final int j = i * 2;
                        final byte tmp = b[j];
                        b[j] = b[j + 1];
                        b[j + 1] = tmp;
                     }
                  }
                  file.write(b);
                  return value_length;
               }
               else
               {
                  for (int i = 0; i < item_count; i++)
                  {
                     file.writeInteger((Numeric) value_array.getElement(i),
                           item_length, array_value_type == Value.SHORT_ID);
                  }
                  return value_length;
               }

               // Case of integer in array
            case Value.INTEGER_ID:
               if (byte_order == Descriptor.BYTE_ORDERING_LSB)
               {
                  final byte[] integerBuffer = new byte[element_length];
                  for (int i = 0; i < item_count; i++)
                  {
                     final fr.gael.drb.value.Integer integer_value =
                        (fr.gael.drb.value.Integer) value_array.getElement(i)
                              .convertTo(Value.INTEGER_ID);
                     buffer = integer_value.integerValue().toByteArray();
                     int k = buffer.length - 1;
                     int j = 0;
                     // Swap bytes: copy from end to start
                     while ((k >= 0) && (j < element_length))
                     {
                        integerBuffer[j++] = buffer[k--];
                     }
                     final byte pad =
                        (byte) (((buffer[0] & 0x80) != 0) ? 0xff : 0);
                     while (j < element_length)
                     {
                        integerBuffer[j++] = pad;
                     }
                     file.write(integerBuffer);
                  }
               }
               else
               {
                  for (int i = 0; i < item_count; i++)
                  {
                     final Numeric integer_value =
                        (Numeric) value_array.getElement(i).convertTo(
                              Value.INTEGER_ID);
                     file.writeInteger(integer_value, item_length, true);
                  }
               }
               return value_length;

               // Case of dateTime in array
            case Value.DATE_ID:
               if ((element_bit_length == 0) && (element_length == 12))
               {
                  for (int i = 0; i < item_count; i++)
                  {
                     final DateTime date_value =
                        (DateTime) value_array.getElement(i).convertTo(
                              Value.DATE_ID);
                     final byte[] date_buffer = date_value.getFormattedBuffer();
                     file.write(date_buffer);
                  }
                  return value_length;
               }
               else
               {
                  logger
                        .error("Only MJD2000 format is supported for BINARY dateTime. "
                              + "(length="
                              + element_length
                              + ", bits="
                              + element_bit_length + ")");
                  return null;
               }

               // Case of decimal in array
            case Value.DECIMAL_ID:
               logger.error("fr.gael.drb.impl.sdf.BlockTools.encodeValue() : "
                     + "Decimal array not supported for BINARY encoding.");
               return null;

               // Case of duration in array
            case Value.DURATION_ID:
               logger.error("fr.gael.drb.impl.sdf.BlockTools.encodeValue() : "
                     + "Duration array not supported for BINARY encoding.");
               return null;

            default:
               logger.error("fr.gael.drb.impl.sdf.BlockTools.encodeValue() : "
                     + "Array type not supported (" + array_value_type + ").");
               return null;
         } // switch array_type
      }
      catch (final ClassCastException e)
      {
         logger.error("fr.gael.drb.impl.sdf.BlockTools.encodeValue() : "
               + "Error while encoding value (" + "descriptor="
               + descriptor.getPath() + " value_type=" + value_type
               + ", array_value_type=" + array_value_type + ", value='" + value
               + "').");
         logger.error("   " + e);
         e.printStackTrace();
         return null;
      }
   }

   /**
    * Main.
    * 
    * @param args args
    */
   public static void main(final String[] args) throws Exception
   {
      final Pattern integerPattern =
         Pattern.compile("(\\+|\\-)?\\p{Digit}*\\.?\\p{Digit}*"
               + "((d|D|e|E)(\\+|\\-)?\\p{Digit}+)?");
      final Matcher matcher = integerPattern.matcher("1 04");
      matcher.find(0);
      System.err.println("[" + matcher.start() + " - " + matcher.end() + "]:'"
            + matcher.group() + "'");
      /*
       * System.err.println("readByte benchmark"); fr.gael.drb.DrbNode node =
       * fr.gael.drb.DrbFactory.open(args[0]); java.io.RandomAccessFile file =
       * (java.io.RandomAccessFile)
       * ((fr.gael.drb.impl.DrbNodeImpl)node).getImpl(
       * java.io.RandomAccessFile.class); int line_number = 0; long length =
       * file.length(); byte[] buf = new byte[1024]; for (long i=0; i<length;
       * i+=1024) { int len = file.read(buf); for (int j=0; j<1024; j++) if
       * ((char)(buf[j]) == '\n') line_number ++; }
       * System.err.println(line_number + " line(s).");
       */
   } // main
} // BlockTools
