/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

/**
 * Mutable node interface. Nodes are considered mutable when they provide an
 * interface that enables to change their content or structure (i.e. attribute,
 * name, children, etc.). This interface has been separated from the DrbNode
 * because all the implementations are not supposed to provide a change
 * interface. All the following operations are supposed to fire the most
 * accurate events according to their business. DrbMutableNode interface has
 * been designed on the basis of the MutableTreeNode provided by the Java API
 * and by the DOM Event specifications of the W3C.
 * <p>
 * <b>Important note: </b> If the node has a physical representation (e.g. a
 * file, an XML document) the any call of the operations defined in
 * DrbMutableNode interface changes this physical representation. For instance
 * renaming a node wrapping a file will effectively rename the file in the file
 * system. The operations does not already support transactions supposed to
 * store the changes until a commit. The changes may therefore take a variable
 * amount of time according to the underlying implementation. For instance the
 * insertion of a node as first child may require to copy a huge file even if
 * the node value has small footprint in the final file.
 * </p>
 */
public interface DrbMutableNode extends DrbNode
{

}
