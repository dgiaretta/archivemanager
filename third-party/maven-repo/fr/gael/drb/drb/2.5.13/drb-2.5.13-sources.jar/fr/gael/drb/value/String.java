/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

import java.math.BigInteger;

/**
 * The String class is a generic wrapper for string values.
 */
public class String extends AbstractValue implements Value, Sumable, Comparison
{

   // ========================================
   // Attributes part.
   // =======================================
   /**
    * The String value.
    */
   protected java.lang.String string;

   // =========================================
   // Methods part.
   // ==========================================
   /**
    * Constructs an String object initialized to empty string.
    */
   public String()
   {
      this("");
   }

   /**
    * Constructs an String object initialized to the specified byte array.
    * 
    * @param strbuf a byte array representing the String
    */
   public String(final byte[] strbuf)
   {
      this.string = new java.lang.String(strbuf);
   }

   /**
    * Constructs an String object initialized to the specified standard string.
    * 
    * @param str a standard string
    */
   public String(final java.lang.String str)
   {
      this.string = str;
   }

   /**
    * Returns a new standard String object representing this value.
    * 
    * @return a string representation of the object.
    */
   public final java.lang.String toString()
   {
      return this.string;
   }

   // -----------------------------------------------------
   // Value interface implementation
   // -----------------------------------------------------
   /**
    * The type identifier of this String value.
    * 
    * @return an identifier of the String type.
    */
   public final int getType()
   {
      return Value.STRING_ID;
   }

   /**
    * Returns the String priority
    * 
    * @return the String priority
    */
   public final int getPriority()
   {
      return 0;
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself is returned. If the conversion is not allowed a
    * ClassCastException is thrown. The types must be in : String, Boolean to
    * Double, Date and Array.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException exception
    */
   public final Value convertTo(final int type) throws ClassCastException
   {
      // try to convert the String into the specified type (if possible)
      try
      {
         Value v = null;
         switch (type)
         {
            // String -> String
            case Value.STRING_ID:
               return this;

               // String -> Numeric conversion
            case Value.NUMERIC_ID:
               try
               {
                  return new Long(java.lang.Long.parseLong(this.string.trim()));
               }
               catch (final Exception e)
               {
                  // vide
               }
               try
               {
                  return new Double(java.lang.Double.parseDouble(this.string
                        .trim()));
               }
               catch (final Exception e)
               {
                  // vide
               }

               try
               {
                  return (new DateTime(this.string.trim()))
                        .convertTo(Value.NUMERIC_ID);
               }
               catch (final Exception e)
               {
                  // vide
               }

               break;
            // String -> Int conversion
            case Value.INT_ID:
               return new Int(java.lang.Integer.parseInt(this.string.trim()));

               // String -> UnsignedInt conversion
            case Value.UNSIGNED_INT_ID:
               return new UnsignedInt((int) java.lang.Long
                     .parseLong(this.string.trim()));

               // String -> Float conversion
            case Value.FLOAT_ID:
               return new Float(java.lang.Float.parseFloat(this.string.trim()));

               // String -> Date conversion
            case Value.DATE_ID:
               return new DateTime(this.string.trim());

               // String -> Duration conversion
            case Value.DURATION_ID:
               v = Duration.parseDuration(this.string.trim());
               if (v == null)
               {
                  throw new Exception();
               }
               return v;

               // String -> Byte conversion
            case Value.BYTE_ID:
               return new Byte(java.lang.Byte.parseByte(this.string.trim()));

               // String -> UnsignedByte conversion
            case Value.UNSIGNED_BYTE_ID:
               return new UnsignedByte((byte) java.lang.Long
                     .parseLong(this.string.trim()));

               // String -> Long conversion
            case Value.LONG_ID:
               return new Long(java.lang.Long.parseLong(this.string.trim()));

               // String -> UnsignedLong conversion
            case Value.UNSIGNED_LONG_ID:
               return new UnsignedLong(new BigInteger(this.string.trim())
                     .longValue());

               // String -> Double conversion
            case Value.DOUBLE_ID:
               return new Double(java.lang.Double.parseDouble(this.string
                     .trim()));

               // String -> Short conversion
            case Value.SHORT_ID:
               return new Short(java.lang.Short.parseShort(this.string.trim()));

               // String -> UnsignedShort conversion
            case Value.UNSIGNED_SHORT_ID:
               return new UnsignedShort((short) java.lang.Integer
                     .parseInt(this.string.trim()));

               // String -> Integer
            case Value.INTEGER_ID:
               try
               {
                  return new Integer(this.string.trim());
               }
               catch (final Exception e)
               {
                  java.lang.String tmp_string = this.string.trim();

                  if (tmp_string.startsWith("+"))
                  {
                     tmp_string = tmp_string.substring(1);
                  }
                  return new Integer(tmp_string);
               }

               // String -> Decimal
            case Value.DECIMAL_ID:
               try
               {
                  return new Decimal(this.string.trim());
               }
               catch (final Exception e)
               {
                  java.lang.String tmp_string = this.string.trim();

                  if (tmp_string.startsWith("+"))
                  {
                     tmp_string = tmp_string.substring(1);
                  }
                  return new Decimal(tmp_string);
               }

               // String -> Boolean conversion
            case Value.BOOLEAN_ID:
               return new fr.gael.drb.value.Boolean(this.string.trim());

               // String -> Array
            case Value.ARRAY_ID:
               final java.lang.String[] string_array =
                  this.string.trim().split(" ");
               final DefaultValueArray value_array =
                  new DefaultValueArray(string_array.length);
               for (int i = 0; i < string_array.length; i++)
               {
                  value_array.assign(i, new String(string_array[i].trim()));
               }
               return value_array;
         }
      }
      catch (final Exception e)
      {
         // VIDE
      }

      // The conversion is impossible : we throw an exception
      throw new ClassCastException("String.convertTo: type " + type
            + " unrecognized '" + this.string + "'");
   }

   /**
    * Assign a new Value. An implicit conversion may be performed to make the
    * assignment.
    * 
    * @param v the value to be assigned.
    * @throws ClassCastException exception
    */
   public void assign(final Value v) throws ClassCastException
   {
      this.string = (v.convertTo(STRING_ID)).toString();
   }

   // -------------------------------------------------------
   // Summable interface implementation
   // -------------------------------------------------------
   /**
    * Compute a string concatenation.
    * 
    * @param x another value.
    * @return the concatenation of the two values.
    * @throws ClassCastException exception
    */
   public Value add(final Value x) throws ClassCastException
   {
      return new String(this.toString() + ((String) x).toString());
   }

   // ---------------------------------------------------------
   // Comparison interface implementation
   // --------------------------------------------------------
   /**
    * Compare this string with another string in lexicographic order (a b ...
    * z).
    * 
    * @param v another value.
    * @return The returned value is :
    *         <ul>
    *         <li>negative if this value is lower than another value</li>
    *         <li>zero if the two values are equal</li>
    *         <li>positive if this value is greater than another value</li>
    *         </ul>
    * @throws ClassCastException exception
    */
   public int compareTo(final Value v) throws ClassCastException
   {
      return this.string.compareTo(v.convertTo(STRING_ID).toString());
   }

   // ================================================
   // Unitary test part.
   // ================================================
   /**
    * Makes this class runnable for testing.
    */
   /*
    * public static void main(java.lang.String[] args) {
    * fr.gael.drb.value.String str = new fr.gael.drb.value.String(args[0]);
    * System.out.println("Test : convert a String(" + str + ")");
    * System.out.println("toDouble : " + str.convertTo(Value.DOUBLE_ID));
    * System.out.println("toFloat : " + str.convertTo(Value.FLOAT_ID));
    * System.out.println("toUnsignedLong : " +
    * str.convertTo(Value.UNSIGNED_LONG_ID)); System.out.println("MAX_LONG : " +
    * java.lang.Long.MAX_VALUE); System.out.println("toLong : " +
    * str.convertTo(Value.LONG_ID)); System.out.println("toUnsignedInt : " +
    * str.convertTo(Value.UNSIGNED_INTEGER_ID)); System.out.println("MAX_INT : " +
    * java.lang.Integer.MAX_VALUE); System.out.println("toInt : " +
    * str.convertTo(Value.INTEGER_ID)); System.out.println("toUnsignedShort : " +
    * str.convertTo(Value.UNSIGNED_SHORT_ID)); System.out.println("MAX_SHORT : " +
    * java.lang.Short.MAX_VALUE); System.out.println("toShort : " +
    * str.convertTo(Value.SHORT_ID)); System.out.println("toUnsignedByte : " +
    * str.convertTo(Value.UNSIGNED_BYTE_ID)); System.out.println("toByte : " +
    * str.convertTo(Value.BYTE_ID)); } //main
    */
} // String
