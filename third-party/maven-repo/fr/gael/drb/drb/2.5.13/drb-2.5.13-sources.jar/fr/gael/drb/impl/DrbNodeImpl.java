/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl;

import fr.gael.drb.DrbAbstractNode;
import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbNode;

/**
 * DrbNode implementation. This interface allows to perform "implementation
 * specific" operations.
 */
public abstract class DrbNodeImpl extends DrbAbstractNode
{
   /**
    * Closes this node and releases any system resources associated with the
    * implementation. A closed node cannot perform input or output operations
    * and cannot be reopened.
    * 
    * @param deep if this flag is disabled, the implementation shall not release
    *           the ressources shared with the descendants. WARNING: This
    *           parameter is not fully supported.
    */
   public void close(final boolean deep)
   {
      // do nothing
   }

   /**
    * Performs any pending changes. This methods forces the underlying
    * implementation to perform all changes. The current node may use a buffer
    * for caching input/output operations. In that case, this method will write
    * the node to the system ressource.
    */
   public void flush()
   {
      // do nothing
   }

   /**
    * Tests if a specific interface can be provided. This operations tests with
    * a minimum of time and memory consumption if the current implementation can
    * provide a specific interface. It important to consider that hasImpl()
    * provides information about the ability to provide such interface in
    * general cases but not focused on the current instance. It may therefore be
    * impossible to get a specific implementation from a node whereas hasImpl()
    * operation returns true.
    * 
    * @param api The class type to test.
    * @return true if an implementation of the interface can be provided and
    *         false otherwise.
    */
   public boolean hasImpl(final Class api)
   {
      if (api == null)
      {
         return false;
      }
      if (api.isInstance(this))
      {
         return true;
      }
      return false;
   }

   /**
    * Returns a specific implementation. This operation returns a reference to
    * an object implementing a specific interface. This mean is useful to
    * benefit by a specific and direct API instead of using the DrbNode
    * interface. The provided object shall represent the current node such as it
    * is possible after a call to this operation, to dismiss the reference to
    * the node. For instance, a file is usually wrapped as a drb.imple.file.File
    * class and thanks to this operation can be seen as a InputStream anabling
    * direct access to the handled file.
    * 
    * @param api The interface (or class) to be provided.
    * @return A reference to the object implementing the interface or a null
    *         reference otherwise.
    */
   public Object getImpl(final Class api)
   {

      if (api == null)
      {
         return null;
      }
      if (api.isInstance(this))
      {
         return this;
      }
      return null;
   }

   /**
    * Create a node with the specified name.
    * 
    * @param name The expected name of the node.
    * @return A reference to the new node.
    * @throws NullPointerException This exception is raised when the name
    *            provided in parameter is null.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation is not able to create a node.
    */
   public DrbNode createNode(final String name)
   {
      throw new UnsupportedOperationException("DrbNodeImpl.createNode() : "
            + "This operation is not supported by this implementation.");
   }

   /**
    * Create a node with the specified name.
    * 
    * @param name the name of the node
    * @return DrbAttribute the attribute of the node
    */
   public DrbAttribute createAttribute(final String name)
   {
      throw new UnsupportedOperationException(
            "DrbNodeImpl.createAttribute() : "
                  + "This operation is not supported by this implementation.");
   }

   /**
    * Returns the provider of this node.
    * 
    * @return DrbProvider the provider node
    */
   public DrbProvider getProvider()
   {
      return null;
   }
} // DrbNodeImpl
