/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.xml;

import org.w3c.dom.Node;

import fr.gael.drb.DrbItem;
import fr.gael.drb.value.Value;

/**
 * XML item implementation. This class is a convenient class that implements the
 * DrbItem class. It is useful if no specific operations are required for an
 * item. It holds a name, a value and enable to configute the specification
 * level (i.e. default value).
 */
class XmlItem implements DrbItem
{
   /**
    * The item is an element.
    */
   public static final int ELEMENT_ITEM = NODE_ITEM;

   /**
    * The item is a text.
    */
   public static final int TEXT_ITEM = VALUE_ITEM;

   /**
    * The item is a comment.
    */
   public static final int COMMENT_ITEM = 4;

   /**
    * The item is an processing instruction.
    */
   public static final int PROCESSING_INSTRUCTION_ITEM = 5;

   /**
    * The item is a notation.
    */
   public static final int NOTATION_ITEM = 6;

   /**
    * The item is an entity.
    */
   public static final int ENTITY_ITEM = 7;

   /**
    * The item is a document type.
    */
   public static final int DOCUMENT_TYPE_ITEM = 8;

   /**
    * DOM node wrapped by this implementation. This reference is never null.
    */
   private Node node;

   /**
    * Simple constructor of an item. This operation creates an item witn a name
    * and its corresponding value but without owner. The value is considered as
    * specified. Both parameters shall never be null.
    * 
    * @param node the DOM node
    */
   XmlItem(final Node node)
   {
      this.node = node;
   }

   /**
    * Name of the item. Returns the name of the item set at construction.
    * 
    * @return The name of the item.
    */
   public String getName()
   {
      return this.node.getLocalName();
   }

   /**
    * Changes the name of the item. This method always throw an
    * UnsupportedOperationException.
    * 
    * @param name Reference to the new name.
    * @throws UnsupportedOperationException This exception always raised because
    *            the name property is not defined for values.
    * @throws NullPointerException This exception is overriden by an
    *            UnsupportedOperationException.
    */
   public void rename(final java.lang.String name) throws NullPointerException,
         UnsupportedOperationException
   {
      throw new UnsupportedOperationException("Cannot rename an XML item");
   }

   /**
    * A code representing the type of the underlying object, as defined above.
    * 
    * @return The code of this item.
    */
   public int getItemType()
   {
      switch (this.node.getNodeType())
      {
         case Node.ELEMENT_NODE:
            return NODE_ITEM;

         case Node.ATTRIBUTE_NODE:
            return ATTRIBUTE_ITEM;

         case Node.TEXT_NODE:
         case Node.CDATA_SECTION_NODE:
            return VALUE_ITEM;

         case Node.COMMENT_NODE:
            return COMMENT_ITEM;

         case Node.PROCESSING_INSTRUCTION_NODE:
            return PROCESSING_INSTRUCTION_ITEM;

         case Node.NOTATION_NODE:
            return NOTATION_ITEM;

         case Node.DOCUMENT_TYPE_NODE:
            return DOCUMENT_TYPE_ITEM;

         case Node.ENTITY_NODE:
            return ENTITY_ITEM;
      }
      return DrbItem.UNDEFINED_ITEM;
   }

   /**
    * Get namespace URI. The namespace URI of this item is always null.
    * 
    * @return The namspace URI or null if unspecified.
    */
   public String getNamespaceURI()
   {
      return this.node.getNamespaceURI();
   }

   /**
    * Sets a namespace resource identifier. This method always throw an
    * UnsupportedOperationException.
    * 
    * @param namespace_uri A reference to the new namespace identifier.
    * @throws UnsupportedOperationException This exception always raised because
    *            the name property is not defined for values.
    * @throws NullPointerException This exception is overriden by an
    *            UnsupportedOperationException.
    */
   public void setNamespaceURI(final java.lang.String namespace_uri)
         throws NullPointerException, UnsupportedOperationException
   {
      throw new UnsupportedOperationException("Cannot rename an XML item");
   }

   /**
    * The value of the item. The returned value is the one passed at
    * construction.
    * 
    * @return The value of the item.
    */
   public Value getValue()
   {
      final String text = this.node.getNodeValue();
      if (text == null)
      {
         return null;
      }
      else
      {
         return new fr.gael.drb.value.String(text);
      }
   }

   /**
    * Changes the value of the item. This operation sets a new value of the
    * current item.The value type of the item shall be compatible with the item
    * implementation. If the type does not match exactly it is casted to a
    * compatible one based on the the fr.gael.drb.value capabilities. A
    * reference to the effectivelly assigned value is returned by the operation
    * so it is possible to check if a cast has been performed and therefore
    * assess the accuracy of the assignement. If the cast is not possible the
    * operation raises an UnsupportedOperationException. If the assignment is
    * possible and the item implementation has a physical representation the
    * value is updated in the physical source in order to persist among
    * sessions. It therefore possible that this operation consumses an variable
    * time.
    * 
    * @param value The new value of the item. This value shall not be null
    * @return The effectivelly assigned value.The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested assignment for
    *            any reason.
    */
   public Value setValue(final Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      if (value == null)
      {
         throw new NullPointerException("The value shall not be null.");
      }
      this.node.setNodeValue(value.toString());
      return value.convertTo(Value.STRING_ID);
   }

   /**
    * Returns a description of the current item. The output format is : "@"
    * <name> "=" <value> .
    * 
    * @return the description of the item.
    */
   public String toString()
   {
      return "@" + this.getName() + "=" + this.getValue();
   }
}// XmlItem
