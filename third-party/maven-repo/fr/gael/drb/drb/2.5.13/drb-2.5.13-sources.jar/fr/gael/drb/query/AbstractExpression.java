/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbSequence;

/**
 * Provides convenient/common implementation for expressions.
 */
abstract class AbstractExpression implements Expression
{
   /**
    * Logger
    */
   static private Logger logger = Logger.getLogger(AbstractExpression.class);

   /**
    * Name of the expression. The name of the expression is useful to report
    * exception, error, warning or debug messages. If not altered, the default
    * name of an expression is "Unknown". Usually, the responsibility of naming
    * the expression is to the extender of this class (i.e. the class wrapping
    * the expression) instead of any other component such as the parser.
    */
   private String name = "Unknown";

   /**
    * Token related to the expression. This token may be useful for locating
    * dynamic errors while evaluating the expression.
    */
   private Token token;

   /**
    * Cancellation request indicator. As long as the indicator is false, the
    * potentially running dynamic evaluations shall continue. Otherwise they
    * should stop as soon as possible.
    */
   private boolean cancelRequested = false;

   /**
    * Cancellation message. The reason of cancellation originating from the
    * caller that has trigerred the interruption. The default value of the
    * message is "Unknown reason".
    */
   private String cancelReason = "Unknown reason";

   /**
    * Builds a named expression with a token.
    * 
    * @param name the name of the expression.
    * @param token token related to the delaration of the expression.
    */
   public AbstractExpression(final String name, final Token token)
   {
      this.setName(name);
      this.setToken(token);
   }

   /**
    * Alter the name of the expression.
    * 
    * @param name the new name of the expression.
    */
   public void setName(final String name)
   {
      this.name = name;
   }

   /**
    * Launch a dynamic evaluation of the expression with no dynamic context.
    * <p>
    * During the dynamic evaluation, a dynamic or a type exception may occur
    * interrupting the processing of the query. They significate that an
    * unrecoverable error has been encountered in an expression may be due to
    * unsatisfied conditions departing from the XQuery specifications.
    * </p>
    * Moreover, while a dynamic evaluation is operating, a call of cancel()
    * operation may request the immediate interruption of the processing. On the
    * evaluation stop, a CanceException
    * </p>
    * 
    * @return the sequence resulting from the dynamic evaluation.
    * @throws DynamicException when an error occurred.
    * @throws TypeException when a type error has been encountered.
    * @throws CancelException when the evaluation has been interrupted.
    */
   public DrbSequence evaluate() throws DynamicException, TypeException,
         CancelException
   {
      throw new DynamicException(this, "The context shall not be empty.");
   }

   /**
    * Request cancellation of potentially running dynamic evaluations.
    * <p>
    * The abstract class changes the cancelRequested boolean attribute to true.
    * The operation should be overriden to detect and dispatch the informatio to
    * sub-expressions. A care shoulf be synchronize the writting access to the
    * cancelRequested boolean to avoid multi-thread conflicts.
    * </p>
    * <p>
    * The reason of cancellation is managed by the current abstraction.
    * Implementers have not to take into accound the reason as far as they use
    * the present method. The cancel exception and message may also be managed
    * by the present class (i.e. for an homogeneous reporting layout) through
    * the operation throwCancelException().
    * </p>
    * 
    * @param reason a explicit message describing the origin or reason of the
    *           cancellation request. This reason will be reported in the
    *           message of the cancel exception.
    */
   public synchronized void cancel(final String reason)
   {
      this.cancelRequested = true;
   }

   /**
    * Check if a cancellation has been requested.
    * 
    * @return true if a cancellation has been requested, and false otherwise.
    */
   public boolean isCancellationRequested()
   {
      return this.cancelRequested;
   }

   /**
    * Throw a cancel exception. The concern of such an operation is to provide
    * an homogeneous exception message for all the implementers. Before throwing
    * the exception, the cancellation request flag is called off for furture
    * evaluations.
    */
   public void throwCancelException()
   {
      /**
       * Builds the message with respect to the available information.
       */
      String message = "";

      if (this.getName() != null)
      {
         message += "The " + this.getName();
      }
      else
      {
         message += "An";
      }

      message += " expression";

      if (this.getToken() != null)
      {
         message +=
            ", declared at line " + this.getToken().beginLine + ", column "
                  + this.getToken().beginColumn + ",";
      }

      message += " has been cancelled due to " + this.cancelReason;

      /**
       * Call off the cancel request before interrupting the evaluation.
       */
      this.cancelRequested = false;

      /**
       * Throws the exception.
       */
      throw new CancelException(message);
   }

   /**
    * Returns the name of the expression.
    * 
    * @return the name of the expression.
    */
   public String getName()
   {
      return this.name;
   }

   /**
    * Set the token of the expression.
    * 
    * @param token the new token to be considered.
    */
   public void setToken(final Token token)
   {
      this.token = token;
   }

   /**
    * Returns the token associated to the expression.
    * 
    * @return the related token.
    */
   public Token getToken()
   {
      return this.token;
   }

   /**
    * A expression which is constant means that it need no context item to be
    * evaluate. The returned sequence from its evaluation will always be the
    * same along the query script
    * 
    * @return true if this expression is constant
    */
   public boolean isConstant()
   {
      return false;
   }

   /**
    * Identifies expression that can modify the state of an existing node. An
    * updating expression is an expression that use the updating operations
    * provided by the "XQuery Update Facility" : insert, delete, replace, rename
    * and transform.
    * 
    * @return true if this expression performs updating operations and false
    *         otherwise
    */
   public boolean isUpdating()
   {
      return false;
   }
}
