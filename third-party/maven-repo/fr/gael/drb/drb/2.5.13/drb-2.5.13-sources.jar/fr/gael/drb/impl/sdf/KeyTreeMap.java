/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sdf;

import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.TreeMap;

import org.apache.log4j.Logger;

/**
 */
final class KeyTreeMap
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(KeyTreeMap.class);

   /**
    * The depth of the tree.
    */
   private int depth;

   /**
    * The number of values in the tree.
    */
   private int size;

   /**
    * The map of children.
    */
   private Map children;

   /**
    * Create a KeyTreeMap instance with an unknown depth. The depth will be set
    * during the first add() call and will be equal to the length of the given
    * key.
    */
   protected KeyTreeMap()
   {
      // Wrap to other constructor with unknown depth
      this(-1);
   }

   /**
    * Create a KeyTreeMap instance with a specified depth.
    * 
    * @param depth The depth of the tree, must be greater than 0.
    */
   protected KeyTreeMap(final int depth)
   {
      // Set the depth and size
      this.depth = depth;
      this.size = 0;

      // Create the map
      this.children = new TreeMap();
   }

   /**
    * Adds the value in the tree using the given key. If the given key is null
    * or empty (length==0) nothing is added to the map. The value can be
    * retreived later by the get(key) operation.
    * 
    * @param key The key to identify the value.
    * @param value The value to add in the map.
    */
   protected final void add(final int[] key, final long value)
   {
      // Local declarations
      Map curLevelMap; // Map of the current level
      Map tmpLevelMap; // Temporary Map of the current level

      // Check parameter
      if ((key == null) || (key.length == 0))
      {
         this.logger.warn("KeyTreeMap.add() WARNING: "
               + "key is null or empty, nothing added to the tree.");
         return;
      }

      // Set the depth if unknown
      // Else checks the consistency with the given key
      if (this.depth <= 0)
      {
         this.depth = key.length;
      }
      else if (key.length != this.depth)
      {
         this.logger.error("KeyTreeMap.add() ERROR: "
               + "The given key is not consistent with the depth of the tree.");
         return;
      }

      // Parse tree using the given key
      curLevelMap = this.children;
      for (int i = 0; i < this.depth - 1; i++)
      {
         // Get the sub map from the current level
         tmpLevelMap = (Map) curLevelMap.get(new Integer(key[i]));

         // Create new map if not existing and add it to current level
         if (tmpLevelMap == null)
         {
            tmpLevelMap = new TreeMap();
            curLevelMap.put(new Integer(key[i]), tmpLevelMap);
         }

         // Go to next level
         curLevelMap = tmpLevelMap;
      }

      // Store value (replace if exists) and change size if new
      if (curLevelMap.put(new Integer(key[this.depth - 1]), new Long(value)) == null)
      {
         this.size++;
      }
   }

   /**
    * Returns the value associated to the key. If the given key is null returns
    * -1. If no entry matches the key returns -1. Else returns the value
    * associated to the key.
    * 
    * @param key The key used to find the value.
    * @return The value associated to the key.
    */
   protected final long get(final int[] key)
   {
      // Local declarations
      Map curLevelMap; // Map of the current level
      Map tmpLevelMap; // Temporary Map of the current level
      Long value; // The value to get from tree

      // Check parameter
      if ((key == null) || (key.length != this.depth))
      {
         return -1;
      }

      // Parse tree using the given key
      curLevelMap = this.children;
      for (int i = 0; i < this.depth - 1; i++)
      {
         // Get the sub map from the current level
         tmpLevelMap = (Map) curLevelMap.get(new Integer(key[i]));

         // Create new map if not existing and add it to current level
         if (tmpLevelMap == null)
         {
            return -1;
         }

         // Go to next level
         curLevelMap = tmpLevelMap;
      }

      // Get value from last level
      value = (Long) curLevelMap.get(new Integer(key[this.depth - 1]));

      // Return value
      if (value == null)
      {
         return -1;
      }
      return value.longValue();
   }

   /**
    * Returns the number of values stored in the tree.
    * 
    * @return The number of values stored in the tree.
    */
   protected final int getSize()
   {
      return this.size;
   }

   /**
    * Clear the content of the map. This operation does not modify the depth
    * attribute. Therefore its value remains unchanged.
    */
   protected final void clear()
   {
      // Wrap to the map operation
      this.children.clear();

      // Reset the size
      this.size = 0;
   }

   /**
    * Print info into a string.
    * 
    * @return String
    */
   public String toString()
   {
      return "{depth=" + this.depth + ", size=" + this.getSize() + ", "
            + this.children + "}";
   }

   /**
    * TBC.
    * 
    * @return KeyTreeMapIterator
    */
   protected final KeyTreeMapIterator iterator()
   {
      return new KeyTreeMapIterator();
   }

   /**
    * TBC.
    */
   final class KeyTreeMapIterator implements Iterator
   {
      /**
       * TBC.
       */
      Map map[];

      /**
       * TBC.
       */
      Iterator iterator[];

      /**
       * TBC.
       */
      Iterator subIterator;

      /**
       * TBC.
       */
      int level = -1;

      /**
       * TBC.
       */
      protected KeyTreeMapIterator()
      {
         // Initialize if depth is valid
         if (KeyTreeMap.this.depth > 0)
         {
            // Set start level
            this.level = 0;

            // Create arrays to cache the maps and iterators used for the
            // current key and initialize the first cache elements
            this.map = new Map[KeyTreeMap.this.depth];
            this.map[0] = KeyTreeMap.this.children;
            this.iterator = new Iterator[KeyTreeMap.this.depth];
            this.iterator[0] = this.map[0].values().iterator();

            // Get the first values iterator
            this.subIterator = this.nextSubIterator();
         }
      }

      /**
       * TBC.
       * 
       * @return Iterator
       */
      private final Iterator nextSubIterator()
      {
         while (this.level >= 0)
         {
            if (this.iterator[this.level].hasNext())
            {
               if (this.level < KeyTreeMap.this.depth - 1)
               {
                  this.map[this.level + 1] =
                     (Map) this.iterator[this.level].next();
                  this.iterator[this.level + 1] =
                     this.map[this.level + 1].values().iterator();
                  this.level++;
               }
               else
               {
                  return this.iterator[this.level];
               }
            }
            else
            {
               this.level--;
            }
         }
         return null;
      }

      /**
       * TBC.
       * 
       * @return boolean
       */
      public final boolean hasNext()
      {
         // Case of invalid level
         if (this.level < 0)
         {
            return false;
         }

         // Case of next() available in the current sub iterator
         if (this.subIterator.hasNext())
         {
            return true;
            // Else get next sub iterator
         }
         else
         {
            this.subIterator = this.nextSubIterator();
         }

         // Case of next() available in the new sub iterator
         if ((this.subIterator != null) && (this.subIterator.hasNext()))
         {
            return true;
            // Else
         }
         else
         {
            return false;
         }
      }

      /**
       * TBC.
       * 
       * @return Object
       */
      public final Object next()
      {
         if (!this.subIterator.hasNext())
         {
            this.subIterator = this.nextSubIterator();
         }

         if (this.subIterator == null)
         {
            throw new NoSuchElementException();
         }

         return this.subIterator.next();
      }

      /**
       * TBC.
       */
      public final void remove()
      {
         // Remove the current value
         this.subIterator.remove();
         KeyTreeMap.this.size--;

         // Check if map at current level is empty and loop until the
         // root level to remove empty maps.
         int tmpLevel = this.level;
         while ((tmpLevel >= 0) && (this.map[tmpLevel].size() == 0))
         {
            tmpLevel--;
            this.iterator[tmpLevel].remove();
         }
      }
   } // End of inner class KeyTreeMapIterator

   /**
    * Main operation used for unitary tests.
    * 
    * @param args String[]
    */
   public static void main(final String[] args)
   {
      System.out.println("\nTest part 1");
      KeyTreeMap ktree = new KeyTreeMap();
      ktree.add(new int[] { 0, 2, 0, 0 }, 66);
      ktree.add(new int[] { 0, 2, 0, 1 }, 177);
      ktree.add(new int[] { 1, 0, 0, 0 }, 321);
      ktree.add(new int[] { 1, 0, 0, 1 }, 457);
      ktree.add(new int[] { 0, 1, 0, 1 }, 44);
      ktree.add(new int[] { 0, 2, 0, 4 }, 205);
      ktree.add(new int[] { 0, 2, 0, 1 }, 186);
      ktree.add(new int[] { 0, 2, 0 }, 99);
      System.out.println(ktree.get(new int[] { 1, 0, 0, 0 }));
      System.out.println(ktree.get(new int[] { 0, 2, 0, 2 }));
      System.out.println(ktree.get(new int[] { 0, 2, 0, 1 }));
      System.out.println(ktree.get(new int[] { 0, 2, 0 }));
      System.out.println("toString() = " + ktree);
      ktree.clear();
      System.out.println("after clear() = " + ktree);

      System.out.println("\nTest part 2");
      ktree = new KeyTreeMap();
      System.out.println("toString() = " + ktree);
      for (int i = 0; i < 3; i++)
      {
         if (i == 1)
         {
            ktree.add(new int[] { i, 0, 0 }, 100 * i);
         }
         else
         {
            for (int j = 0; j < 5; j++)
            {
               if (j < 2)
               {
                  ktree.add(new int[] { i, j, 0 }, 100 * i + 10 * j);
               }
               else
               {
                  for (int k = 0; k < 3; k++)
                  {
                     ktree.add(new int[] { i, j, k }, 100 * i + 10 * j + k);
                  }
               }
            }
         }
      }
      System.out.println("toString() = " + ktree);
      Iterator iterator = ktree.iterator();
      System.out.println("iterator = " + iterator);
      int i = 1;
      while (iterator.hasNext())
      {
         System.out.print(iterator.next() + " ");
         if (i % 2 == 0)
         {
            iterator.remove();
         }
         i++;
      }
      System.out.println();
      System.out.println("toString() = " + ktree);

      iterator = ktree.iterator();
      System.out.println("iterator = " + iterator);
      while (iterator.hasNext())
      {
         System.out.print(iterator.next() + " ");
      }
      System.out.println();
   }
}
