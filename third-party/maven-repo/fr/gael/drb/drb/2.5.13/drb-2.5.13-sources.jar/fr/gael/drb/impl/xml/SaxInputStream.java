/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.xml;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import org.apache.log4j.Logger;

/**
 * SAX input stream.
 */
class SaxInputStream extends InputStream
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(SaxInputStream.class);

   /**
    * The base index for the line entries.
    */
   int lineIndex = 0;

   /**
    * The total number of lines.
    */
   int lineCount = 0;

   /**
    * The offset of each line.
    */
   ArrayList lineOffset = new ArrayList();

   /**
    * The encapsulated input stream.
    */
   InputStream input;

   /**
    * The start offset of the hole.
    */
   Long startHole=Long.MAX_VALUE;

   /**
    * The stop offset of the hole.
    */
   Long stopHole=Long.MAX_VALUE;

   /**
    * The absolute offset
    */
   Long offset = new Long(0);

   /**
    * The SAX node.
    */
   SaxNode node;

   /**
    * The SAX ancestors.
    */
   SaxNode[] ancestor;

   /**
    * The current depth in the path.
    */
   int depth = 0;

   /**
    * Ascending/Descending phase flag.
    */
   boolean descending = true;

   /**
    * Builds a SaxInputStream.
    * 
    * @param input the raw input stream.
    * @param node the SAX node
    */
   SaxInputStream(final InputStream input, final SaxNode node)
   {
      this.input = input;
      this.node = node;
      this.ancestor = new SaxNode[node.depth + 1];
      SaxNode cur_node = node;
      for (int i = node.depth; i >= 0; i--)
      {
         this.ancestor[i] = cur_node;
         if (i > 0)
         {
            cur_node = (SaxNode) cur_node.getParent();
         }
      }
      this.depth = 1;
      this.addOffset(1, 1, 0);
      this.update();
   }

   /**
    * Returns the offset of the specified line.
    * 
    * @param line_number the line number.
    * @param column_number the column number.
    * @return the offset of the specified line.
    */
   public long getOffset(final int line_number, final int column_number)
   {
      if ((line_number < this.lineIndex + 1) || (line_number > this.lineCount)
            || (column_number < 0))
      {
         this.logger.warn("Cannot find the offset for character at ("
               + line_number + ", " + column_number
               + ") within the incope lines.");
         return -1;
      }
      final ArrayList columnOffset =
         (ArrayList) this.lineOffset.get(line_number - 1 - this.lineIndex);

      // Search the column in the offset mappings
      // currentLine -> {[column_1,offset_1], ..., [column_N,offset_N]}
      for (int i = columnOffset.size() - 1; i > 0; i = i - 2)
      {
         final long colOffsetMap = ((Number) columnOffset.get(i)).longValue();
         final int colNumberMap = ((Number) columnOffset.get(i - 1)).intValue();
         if ((column_number >= colNumberMap)
               || ((i == 1) && (column_number == 0)))
         {
            return colOffsetMap + (column_number - colNumberMap);
         }
      }
      // This should never happen
      this.logger.warn("Cannot find offset for character at (" + line_number
            + ", " + column_number + ").");
      return -1;
   }

   /**
    * Add a new offset mapping.
    * 
    * @param line_number the line number.
    * @param column_number the column number.
    * @param offset the offset of the specified character.
    */
   private void addOffset(final int line_number, final int column_number,
         final long offset)
   {
      /*
       * if (((line_number % 10000) == 0) && (column_number == 1)) {
       * System.err.print("Processing line " + line_number + ", offset=" +
       * offset + " \r"); }
       */
      // Keeps no more than 2000 inscope lines
      // Remove 1000 lines in the buffer once
      if (line_number - this.lineIndex > 2000)
      {
         for (int i = 1000; i < this.lineOffset.size(); i++)
         {
            final ArrayList oldColumnOffset =
               (ArrayList) this.lineOffset.get(i - 1000);
            this.lineOffset.set(i - 1000, this.lineOffset.get(i));
            oldColumnOffset.clear();
            this.lineOffset.set(i, oldColumnOffset);
         }
         this.lineIndex += 1000;
      }
      ArrayList columnOffset;
      // Case of unknown line number => append a new line
      if (line_number > this.lineIndex + this.lineOffset.size())
      {
         columnOffset = new ArrayList();
         this.lineOffset.add(columnOffset);
      }
      // Case of a existing line number => retrieve the line (current?)
      else
      {
         columnOffset =
            (ArrayList) this.lineOffset.get(line_number - this.lineIndex - 1);
      }
      if (line_number > this.lineCount)
      {
         this.lineCount = line_number;
      }
      // Add column number and offset
      columnOffset.add(new Integer(column_number));
      columnOffset.add(new Long(offset));

   }

   /**
    * Remove an offset range inside a line.
    * 
    * @param line_number the line number.
    * @param start_offset the start_offset of the removed bytes (included).
    * @param end_offset the end offset of removed bytes (not included).
    */
   private void removeOffset(final int line_number, final long start_offset,
         final long end_offset)
   {
      this.logger.debug("Removing offset range at line " + line_number
            + ": start=" + start_offset + " end=" + end_offset);
      final ArrayList columnOffsets =
         (ArrayList) this.lineOffset.get(line_number - this.lineIndex - 1);
      // Add a new column offset mapping
      final int lastColNumber =
         ((Number) columnOffsets.get(columnOffsets.size() - 2)).intValue();
      final long lastColOffset =
         ((Number) columnOffsets.get(columnOffsets.size() - 1)).longValue();

      // Case of continuation
      // We just replace the previous offset mapping by the new one
      if (lastColOffset == start_offset)
      {
         this.logger.debug("Case of reiterated column mapping (L="
               + line_number + " C=" + lastColNumber + ") -> offset="
               + lastColOffset + " --> " + end_offset);
         columnOffsets.set(columnOffsets.size() - 1, new Long(end_offset));
      }
      // Case of new offset mapping
      else if (start_offset > lastColOffset)
      {
         final int columnNumber =
            lastColNumber + (int) (start_offset - lastColOffset);
         this.logger.debug("Case of new column mapping (L=" + line_number
               + " C=" + columnNumber + ") -> offset=" + end_offset);
         columnOffsets.add(new Integer(columnNumber));
         columnOffsets.add(new Long(end_offset));
      }
      // this should never happen
      else
      {
      }
   }

   /**
    * Update the hole boundaries.
    */
   private void update()
   {
      if (this.node == null)
      {
         return;
      }
      // Case of descending phase
      // Remove previous-sibling nodes
      if (this.descending && (this.depth < this.ancestor.length))
      {
         this.stopHole = this.startHole;
         if (this.ancestor[this.depth].tag.index > 0)
         {
            final SaxNode parentNode = this.ancestor[this.depth - 1];
            this.startHole = parentNode.tag.endOpenOffset;
            // stopHole = parentNode.getTagAt(previous_index).endOffset;
            this.stopHole = this.ancestor[this.depth].tag.startOffset;
         }
         if (this.depth == this.node.depth)
         {
            this.descending = false;
         }
         else
         {
            this.depth = this.depth + 1;
         }
         if (this.startHole.equals (this.stopHole))
         {
            this.update();
         }
      }
      else if ((this.depth > 0) && (this.depth < this.ancestor.length))
      {
         final SaxNode parentNode = this.ancestor[this.depth - 1];
         final int currentIndex = this.ancestor[this.depth].tag.index;
         final int lastIndex =
            this.ancestor[this.depth - 1].tag.childrenCount - 1;
         this.startHole = parentNode.getTagAt(currentIndex).endOffset;
         this.stopHole = parentNode.getTagAt(lastIndex).endOffset;
         this.depth = this.depth - 1;
         if (this.startHole.equals (this.stopHole))
         {
            this.update();
         }
      }
   }

   /**
    * Reads the next byte of data from the input stream.
    * 
    * @return he next byte of data, or -1 if the end of the stream is reached.
    * @throws IOException if an I/O error occurs.
    */
   public int read() throws IOException
   {
      if (this.offset.equals (this.startHole))
      {
         if (this.stopHole == Long.MAX_VALUE)
         {
            return -1;
         }
         final long size = this.stopHole - this.startHole;
         this.input.skip(size);
         this.removeOffset(this.lineCount, this.startHole, this.stopHole);
         this.update();
         this.offset += size;
         return this.read();
      }
      final int ch = this.input.read();
      if (ch == '\n')
      {
         this.addOffset(this.lineCount + 1, 1, this.offset + 1);
      }
      if (ch != -1)
      {
         this.offset = this.offset + 1;
      }
      return ch;
   }

   /**
    * Reads some number of bytes from the input stream and stores them into the
    * buffer array b.
    * 
    * @param b the buffer into which the data is read.
    * @return the total number of bytes read into the buffer, or -1 is there is
    *         no more data because the end of the stream has been reached.
    * @throws IOException if an I/O error occurs.
    */
   public int read(final byte[] b) throws IOException
   {
      return this.read(b, 0, b.length);
   }

   /**
    * Reads up to len bytes of data from the input stream into an array of
    * bytes. An attempt is made to read as many as len bytes, but a smaller
    * number may be read, possibly zero. The number of bytes actually read* is
    * returned as an integer.
    * 
    * @param b the buffer into which the data is read.
    * @param off the start offset in array b at which the data is written.
    * @param len the maximum number of bytes to read.
    * @return the total number of bytes read into the buffer, or -1 is there is
    *         no more data because the end of the stream has been reached.
    * @throws IOException if an I/O error occurs.
    */
   public int read(final byte[] b, final int off, final int len)
         throws IOException
   {
      if (this.offset.equals (this.startHole))
      {
         if (this.stopHole == Long.MAX_VALUE)
         {
            return -1;
         }
         final long size = this.stopHole - this.startHole;
         this.input.skip(size);
         this.removeOffset(this.lineCount, this.startHole, this.stopHole);
         this.update();
         this.offset += size;
         return this.read(b, off, len);
      }
      if (this.offset >= this.stopHole)
      {
         final int lenRead = this.input.read(b, off, len);
         if (lenRead == -1)
         {
            return -1;
         }
         for (int i = 0; i < lenRead; i++)
         {
            if (b[off + i] == '\n')
            {
               this.addOffset(this.lineCount + 1, 1, this.offset + i + 1);
            }
         }
         this.offset = this.offset + lenRead;
         return lenRead;
      }
      if (this.offset < this.startHole)
      {
         final long left = this.startHole - this.offset;
         if (len <= left)
         {
            final int lenRead = this.input.read(b, off, len);
            if (lenRead == -1)
            {
               return -1;
            }
            for (int i = 0; i < lenRead; i++)
            {
               if (b[off + i] == '\n')
               {
                  this.addOffset(this.lineCount + 1, 1, this.offset + i + 1);
               }
            }
            this.offset = this.offset + lenRead;
            return lenRead;
         }
         final int len1 = this.input.read(b, off, (int) left);
         if (len1 == -1)
         {
            return -1;
         }
         for (int i = 0; i < len1; i++)
         {
            if (b[off + i] == '\n')
            {
               this.addOffset(this.lineCount + 1, 1, this.offset + i + 1);
            }
         }
         this.offset = this.offset + len1;
         if (this.stopHole == Long.MAX_VALUE)
         {
            return len1;
         }
         final long size = this.stopHole - this.startHole;
         this.input.skip(size);
         this.removeOffset(this.lineCount, this.startHole, this.stopHole);
         this.update();
         this.offset += size;
         final int len2 = this.read(b, off + len1, len - len1);
         if (len2 == -1)
         {
            return len1;
         }
         return len1 + len2;
      }
      return -1;
   }

   /**
    * Returns the number of bytes that can be read (or skipped over) from this
    * input stream without blocking by the next caller of a method for this
    * input stream. The next caller might be the same thread or or another
    * thread.
    * 
    * @return the number of bytes that can be read from this input stream
    *         without blocking.
    * @throws IOException if an I/O error occurs.
    */
   public int available() throws IOException
   {
      if (this.offset.equals (this.startHole))
      {
         if (this.stopHole == Long.MAX_VALUE)
         {
            return 0;
         }
         final long size = this.stopHole - this.startHole;
         this.input.skip(size);
         this.removeOffset(this.lineCount, this.startHole, this.stopHole);
         this.offset += size;
         this.update();
         // TODO: warning
         return this.available();
      }
      if (this.offset >= this.stopHole)
      {
         return this.input.available();
      }
      if (this.offset < this.startHole)
      {
         final int left = this.input.available();
         if (left < this.startHole - this.offset)
         {
            return left;
         }
         return (int) (this.startHole - this.offset);
      }
      return 0;
   }

   /**
    * Closes this input stream and releases any system resources associated with
    * the stream.
    * 
    * @throws IOException if an I/O error occurs.
    */
   public void close() throws IOException
   {
      this.input.close();
   }

   /**
    * Marks the current position in this input stream.
    * 
    * @param readlimit the maximum limit of bytes that can be read before the
    *           mark position becomes invalid.
    */
   public void mark(final int readlimit)
   {
   }

   /**
    * Repositions this stream to the position at the time the mark method was
    * last called on this input stream.
    * 
    * @throws IOException if an I/O error occurs.
    */
   public void reset() throws IOException
   {
      throw new IOException("Mark not supported");
   }

   /**
    * Tests if this input stream supports the mark and reset methods.
    * 
    * @return true if this stream instance supports the mark and reset methods;
    *         false otherwise.
    */
   public boolean markSupported()
   {
      return false;
   }
}
