/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbDefaultMutableNode;
import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbFactory;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.impl.DrbDefaultMetadataResolver;
import fr.gael.drb.impl.xml.XmlWriter;
import fr.gael.drb.impl.sds.SdfFactory;
import fr.gael.drb.value.Value;
import fr.gael.drb.xsd.Namespace;
import fr.gael.drb.xsd.XsdElement;
import fr.gael.drb.xsd.XsdFactory;
import fr.gael.drb.xsd.XmlSchema;
import fr.gael.drb.xsd.XsdAnnotation;
import fr.gael.drb.xsd.XsdDocumentation;
import fr.gael.drb.xsd.XsdType;
import fr.gael.drb.xsd.XsdComplexType;
import fr.gael.drb.xsd.XsdParticle;
import fr.gael.drb.xsd.XsdModelGroup;
import fr.gael.drb.xsd.XsdAttributeGroup;
import fr.gael.drb.xsd.XsdAttribute;

/**
 * Top level class for the evaluation of a query. The Query class is dedicated
 * to the evaluation of an XQuery script. The XQuery shall comply the
 * specifications laid down in the working draft <a
 * href="http://www.w3.org/TR/2002/WD-xquery-20021115/">
 * http://www.w3.org/TR/2002/WD-xquery-20021115/</a> developed by the World
 * Wild Web Consortium (W3C).
 * <h2>Interest of evaluating XQuery scripts</h2>
 * <p>
 * As large amounts of information are handled by the "Data Request Broker"
 * (DRB), the ability to intelligently query the supported data sources becomes
 * increasingly important. One of the great strengths of DRB is its flexibility
 * in representing many different kinds of information from diverse sources. To
 * exploit this flexibility, this class and all other of the present package
 * (i.e. fr.gael.drb.query) implement a query engine that benefits from the
 * emerging XQuery Language that provides features for retrieving and
 * interpreting information from these data.
 * </p>
 * <h2>XQuery language</h2>
 * <p>
 * XQuery is a query language initially designed for querying XML documents.
 * Detached from XML specificities, it provides however a large amount of
 * features for any data source broken down in a tree of nodes and leaves.
 * Almost all data sources have such hierarchical structure and thanks to DRB,
 * it is possible to benefit from XQuery properties applied to these sources.
 * </p>
 * <p>
 * XQuery is designed to meet the requirements and the use cases identified by
 * the W3C XML Query Working Group. It is designed to be a language in which
 * queries are concise and easily understood. It is also flexible enough to
 * query a broad spectrum of information sources, including both databases and
 * documents. The Query Working Group has identified a requirement for both a
 * human-readable query syntax and an XML-based query syntax. XQuery is designed
 * to meet the first of these requirements. XQuery is derived from an XML query
 * language called "Quilt", which in turn borrowed features from several other
 * languages, including "XPath 1.0", "XQL", "XML-QL", "SQL" and "OQL".
 * </p>
 * <p>
 * XQuery is currently under development by the World Wild Web Consortium (W3C)
 * Members. The language specifications have, however, reached a mature level of
 * consolidation and it is possible today to consider that the language basics
 * are stable enough to be implemented.
 * </p>
 * <h2>Basic principles of evaluation</h2>
 * <p>
 * The queries are processed in three main stages:
 * <ol>
 * <li>Static compilation of the XQuery script
 * <li>Query plan optimization
 * <li>Dynamic evalutation
 * </ol>
 * <h3>Static compilation</h3>
 * <p>
 * In the first hand, the query string provided at the construction is
 * statically compiled to generate a tree of expressions, formally called the
 * body expression. To perform this construction the XQuery script is
 * syntactically and lexically parsed. Each XQuery expression (e.g. FLWOR, IF
 * THEN ELSE expressions) produces a expression class in the body expression
 * tree. At this stage an exception may be raised in case of syntax or lexical
 * error also called static errors.
 * </p>
 * <h3>Query plan optimization</h3>
 * <p>
 * Then the expression tree is optimized by re-organizing the tree to minimize
 * the evaluation performances. For instance the body tree corresponding to the
 * query "(1 + 2) - 1" that involves three constants, two operations and a
 * parenthesis expression may be replaced by a single constant expression: "1"
 * such as shown in the figure below.
 * </p>
 * <p>
 * <center><img src="doc-files/optimization.gif"></center>
 * </p>
 * <h3>Dynamic evaluation</h3>
 * <p>
 * After optimization the body expression may be evaluated. This means the
 * expressions will be processed to extract, filter and compute the values as
 * stated in the initial query script. The evaluation may be performed with a
 * context such as described in the section named "Evaluation context" below.
 * The type of the evaluation result is described in the following section named
 * "Evaluation result".
 * </p>
 * <h2>Evaluation context</h2>
 * <p>
 * The evaluation context of an expression is defined as information that is
 * available at the time the expression is evaluated. The assessment context
 * consists of the components listed below.
 * </p>
 * <p>
 * The first three components of the evaluation context (context item, context
 * position and context size) are called the focus of the expression. The focus
 * enables the processor to keep track of which nodes are being processed by the
 * expression.
 * </p>
 * <p>
 * The focus for the outermost expression is supplied by the environment in
 * which the expression is evaluated. Certain language constructs, notably the
 * path expression E1/E2,create a new focus for the evaluation of a
 * sub-expression. In these constructs, E2 is evaluated once for each item in
 * the sequence that results from evaluating E1. Each time E2 is evaluated, it
 * is evaluated with a different focus. The focus for evaluating E2 is referred
 * to below as the inner focus, while the focus for evaluating E1 is referred to
 * as the outer focus. The inner focus exists only while E2 is being evaluated.
 * When this evaluation is complete, evaluation of the containing expression
 * continues with its original focus unchanged.
 * </p>
 * <h2>Evaluation result</h2>
 * <p>
 * The value of an expression is always a Sequence, which is an ordered
 * collection of zero or more items (i.e. see Item class). An item is either an
 * atomic value or a node (i.e. AtomicValue class and DrbNode implementation).
 * An atomic value is a value in the value space of an XML Schema atomic type,
 * as defined in <a href="http://www.w3.org/TR/xquery/#XMLSchema ">
 * http://www.w3.org/TR/xquery/#XMLSchema</a> (that is, a simple type that is
 * not a list type or a union type). A node conforms to one of the seven node
 * kinds described in XQuery 1.0 and XPath 2.0 Data Model (i.e. <a
 * href="http://www.w3.org/TR/xquery/#datamodel">
 * http://www.w3.org/TR/xquery/#datamodel</a>. Each node has a unique node
 * identity. Some kinds of nodes have typed values, string values, and names,
 * which can be extracted from the node. The typed value of a node is a sequence
 * of zero or more atomic values. The string value of a node is a value of type
 * xs:string. The name of a node is a value of type xs:QName. A sequence
 * containing exactly one item is called a singleton sequence. An item is
 * identical to a singleton sequence containing that item. Sequences are never
 * nested: for example, combining the values 1, (2, 3), and ( ) into a single
 * sequence results in the sequence (1, 2, 3). A sequence containing zero items
 * is called an empty sequence.
 * </p>
 * <h2>Query class usage</h2>
 * <p>
 * The usage of the present Query class is very easy and may be as simple as
 * shown in the next source code sample:
 * </p>
 * <p>
 * <table border=0 align=center bg=#f0f0f0>
 * <tr>
 * <td>
 * 
 * <pre>
 *  import fr.gael.drb.query.Query;
 *  import fr.gael.drb.DrbItem; 
 *  import fr.gael.drb.DrbSequence;
 *  (...)
 *  try
 *  {
 *     Query my_query = new Query(&quot;doc.xml/company[1 to 3]/employee&quot;);
 *  }
 *  catch (Exception exception)
 *  {
 *     System..out.println(&quot;MyProgram : the query cannot be parsed.&quot;);
 *     System..out.println(exception);
 *  }
 *  Sequence result = my_query.evaluate();
 *  System.out.println(result.getLength() +
 *     &quot; items resulting from this query&quot;);
 *  for (int i=0; i&lt; result.getLength(); i++)
 *  {
 *     System.out.println(&quot;Item #&quot; + i +&quot;: &quot; + result.item(i));
 *  }
 * </pre>
 * 
 * </td>
 * </tr>
 * </table>
 * </p>
 * <p>
 * For a complete description of XQuery language, please refer to the latest
 * XQuery working draft http://www.w3.org/TR/xquery/ .
 * </p>
 */
public class Query
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(Query.class);

   /**
    * Static parser. The parser has to be initialized once for the overall
    * process. it is not necessary to have several instances of the parser that
    * has been generated in static mode.
    */
   private QueryParser parser = null;

   /**
    * Static context. This is the top level static context after the static
    * analysis of the input query.
    */
   private StaticContext context;

   /**
    * Body expression. The body expression is the top level expression of the
    * parsed query script.
    */
   private Expression body;

   /**
    * Currently running evaluation indocator. True if a dynamic evaluation is
    * currently running and false otherwise.
    */
   private boolean isRunningEvaluation = false;

   /**
    * Builds a Query class instance from a simple string. In this specific
    * constructor no environment is provided: a default one containing the
    * default definitions (e.g. namespaces, functions, etc.) is instanciated.
    * 
    * @param query_string the string containing the XQuery expression to be
    *           parsed and furtherly evaluated. This parmeter shall never be
    *           null.
    * @throws StaticException when the parser encourter an error in the
    *            specified XQuery script different from type errors. The
    *            complete list of errors is provided in the XQuery
    *            specifications.
    * @throws TypeException when the parser encourter an error that regard the
    *            type matching. The complete list of errors is provided in the
    *            XQuery specifications.
    * @see <a href="http://www.w3.org/TR/xquery">http://www.w3.org/TR/xquery</a>
    */
   public Query(final String query_string) throws StaticException,
         TypeException
   {
      this(query_string, new StaticContext());
   }

   /**
    * Builds a Query class instance from an input stream. In this specific
    * constructor no environment is provided: a default one containing the
    * default definitions (e.g. namespaces, functions, etc.) is instanciated.
    * 
    * @param stream the input stream feeding the XQuery expression to be parsed
    *           and furtherly evaluated. This parmeter shall never be null.
    * @throws StaticException when the parser encourter an error in the
    *            specified XQuery script different from type errors. The
    *            complete list of errors is provided in the XQuery
    *            specifications.
    * @throws TypeException when the parser encourter an error that regard the
    *            type matching. The complete list of errors is provided in the
    *            XQuery specifications.
    * @see <a href="http://www.w3.org/TR/xquery">http://www.w3.org/TR/xquery</a>
    */
   public Query(final InputStream stream) throws StaticException, TypeException
   {
      this(stream, new StaticContext());
   }

   /**
    * Builds a Query class instance from a simple string considereing a specific
    * environment. If the reference to the environment is null, a default one
    * will be considered: this called would be equivalent to the same call
    * without the parameter.
    * 
    * @param query_string the string containing the XQuery expression to be
    *           parsed and furtherly evaluated. This parmeter shall never be
    *           null.
    * @param environment the environment to be considered during the static
    *           analysis phase.
    * @throws StaticException when the parser encourter an error in the
    *            specified XQuery script different from type errors. The
    *            complete list of errors is provided in the XQuery
    *            specifications.
    * @throws TypeException when the parser encourter an error that regard the
    *            type matching. The complete list of errors is provided in the
    *            XQuery specifications.
    * @see <a href="http://www.w3.org/TR/xquery">http://www.w3.org/TR/xquery</a>
    */
   public Query(final String query_string, final Environment environment)
         throws StaticException, TypeException
   {
      this(query_string, new StaticContext(environment));
   }

   /**
    * Builds a Query class instance from a simple string considereing a specific
    * static context. If the reference to the static context is null, a default
    * one will be considered: this called would be equivalent to the same call
    * without the parameter.
    * 
    * @param query_string the string containing the XQuery expression to be
    *           parsed and furtherly evaluated. This parmeter shall never be
    *           null.
    * @param static_context the static context to be considered during the
    *           static analysis phase.
    * @throws StaticException when the parser encourter an error in the
    *            specified XQuery script different from type errors. The
    *            complete list of errors is provided in the XQuery
    *            specifications.
    * @throws TypeException when the parser encourter an error that regard the
    *            type matching. The complete list of errors is provided in the
    *            XQuery specifications.
    * @see <a href="http://www.w3.org/TR/xquery">http://www.w3.org/TR/xquery</a>
    */
   protected Query(final String query_string, final StaticContext static_context)
         throws StaticException, TypeException
   {
      /**
       * Initializes the query parser.
       */
      this.parser = new QueryParser();

      /**
       * Creates a static context from the provided static context.
       */
      this.context = new StaticContext(static_context);

      /**
       * Parses the string with the static query parser. The string is first
       * converted to an implementation of Reader. The output of the parsing is
       * the top level expression set to the body private attribute of the
       * class.
       */
      this.body =
         this.parser.parse(new StringReader(query_string), this.context);
   }

   /**
    * Builds a Query class instance from an input stream considereing a specific
    * environment. If the reference to the environment is null, a default one
    * will be considered: this called would be equivalent to the same call
    * without the parameter.
    * 
    * @param stream the input stream feeding the XQuery expression to be parsed
    *           and furtherly evaluated. This parameter shall never be null.
    * @param environment the environment to be considered during the static
    *           analysis phase.
    * @throws StaticException when the parser encounter an error in the
    *            specified XQuery script different from type errors. The
    *            complete list of errors is provided in the XQuery
    *            specifications.
    * @throws TypeException when the parser encounter an error that regard the
    *            type matching. The complete list of errors is provided in the
    *            XQuery specifications.
    * @see <a href="http://www.w3.org/TR/xquery">http://www.w3.org/TR/xquery</a>
    */
   public Query(final InputStream stream, final Environment environment)
         throws StaticException, TypeException
   {
      this(stream, new StaticContext(environment));
   }

   /**
    * Builds a Query class instance from an input stream considering a specific
    * static context. If the reference to the static context is null, a default
    * one will be considered: this called would be equivalent to the same call
    * without the parameter.
    * 
    * @param stream the input stream feeding the XQuery expression to be parsed
    *           and furtherly evaluated. This parameter shall never be null.
    * @param static_context the static context to be considered during the
    *           static analysis phase.
    * @throws StaticException when the parser encounter an error in the
    *            specified XQuery script different from type errors. The
    *            complete list of errors is provided in the XQuery
    *            specifications.
    * @throws TypeException when the parser encounter an error that regard the
    *            type matching. The complete list of errors is provided in the
    *            XQuery specifications.
    * @see <a href="http://www.w3.org/TR/xquery">http://www.w3.org/TR/xquery</a>
    */
   protected Query(final InputStream stream, final StaticContext static_context)
         throws StaticException, TypeException
   {
      /**
       * Initializes the satic query parser.
       */
      this.parser = new QueryParser();

      /**
       * Creates a static context from the provided static context.
       */
      this.context = new StaticContext(static_context);

      /**
       * Parses the input stream with the static query parser. The output of the
       * parsing is the top level expression set to the body private attribute
       * of the class.
       */
      this.body = this.parser.parse(stream, this.context);
   }

   /**
    * Returns the environment. The returned environment may differ from the one
    * provided at construction. It may have been augmented during the static
    * analysis phase. In particular the external variable potentially declared
    * in the module prologs are already referenced at this stage.
    * 
    * @return the environment augmented during the static analysis phase.
    */
   public Environment getEnvironment()
   {
      return this.context;
   }

   /**
    * Returns the set of external variables of the current context/environment.
    * The external variable may originate from the environment creator or may
    * have been added during the satic analysis phase of the XQuery processing.
    * Any call of this operation is equivalent to the following code:
    * 
    * <pre>
    * query.getEnvironment().getExternalVariables()
    * </pre>.
    * 
    * @return the array of external variables, if any, or null otherwise.
    */
   public ExternalVariable[] getExternalVariables()
   {
      if (this.context != null)
      {
         return this.context.getExternalVariables();
      }
      else
      {
         return null;
      }
   }

   /**
    * Identifies queries that can modify the state of the context item. An
    * updating query has a main expression that use the updating operations
    * provided by the "XQuery Update Facility" : insert, delete, replace, rename
    * and transform.
    * 
    * @return true if this query performs updating operations and false
    *         otherwise
    */
   public boolean isUpdating()
   {
      return this.body.isUpdating();
   }

   /**
    * Launchs a dynamic evaluation of query with respect to an initial context
    * item.
    * <p>
    * The dynamic context of evaluation is automatically derived from the top
    * level static context resulting from the static analysis phase.
    * </p>
    * <p>
    * During the dynamic evaluation, a dynamic or a type exception may occur
    * interrupting the processing of the query. They significate that an
    * unrecoverable error has been encountered in an expression may be due to
    * unsatisfied conditions departing from the XQuery specifications.
    * </p>
    * <p>
    * Moreover, while a dynamic evaluation is operating, a call of cancel()
    * operation may request the immediate interruption of the processing. On the
    * evaluation stop, a <code>CancelException</code> is thrown.
    * </p>
    * 
    * @param context_item the initial context item to be put in the focus of the
    *           dynamic evaluation context.
    * @param context_position the initial position in the context sequence.
    * @param context_size the initial context size.
    * @return the sequence resulting from the dynamic evaluation.
    * @throws DynamicException when an error occurred.
    * @throws TypeException when a type error has been encountered.
    * @throws CancelException when the evaluation has been interrupted.
    */
   public DrbSequence evaluate(final DrbItem context_item,
         final int context_position, final int context_size)
         throws DynamicException, TypeException, CancelException
   {

      /**
       * Verify that a body expression results from the static analysis phase.
       */
      if (this.body == null)
      {
         throw new DynamicException(null, "No \"body\" expression to evaluate");
      }

      /**
       * Verify the focus consistency.
       */
      if ((context_size < 0) || (context_position > context_size))
      {
         throw new DynamicException(null, "Invalid initial context (position="
               + context_position + " size=" + context_size + ")");
      }

      /**
       * Creates a dynamic context from the static one at the end of the static
       * analysis phase.
       */
      final DynamicContext dynamic_context = new DynamicContext(this.context);
      dynamic_context.focus.setContextPosition(context_position);
      dynamic_context.focus.setContextSize(context_size);

      /**
       * Alter the focus of the dynamic context with the provided context item.
       */
      if (context_item != null)
      {
         dynamic_context.focus.setContextItem(context_item);
      }

      /**
       * Evaluate the root expression. The CancelException is catched and
       * re-thrown to manage the running evaluation flag.
       */
      this.isRunningEvaluation = true;
      DrbSequence result = null;

      /**
       * Evaluation of all the variables declared in prolog
       */
      for (final Variable variable : dynamic_context.getInScopeVariables())
      {
         variable.initialize(dynamic_context);
      }

      /**
       * Evaluation of body
       */
      try
      {
         result = this.body.evaluate(dynamic_context);
      }
      catch (final CancelException cancel_exception)
      {
         this.isRunningEvaluation = false;
         throw new CancelException(cancel_exception.getMessage());
      }

      return result;
   }

   /**
    * Launchs a dynamic evaluation of query with respect to an initial context
    * item.
    * <p>
    * The dynamic context of evaluation is automatically derived from the top
    * level static context resulting from the static analysis phase.
    * </p>
    * <p>
    * During the dynamic evaluation, a dynamic or a type exception may occur
    * interrupting the processing of the query. They significate that an
    * unrecoverable error has been encountered in an expression may be due to
    * unsatisfied conditions departing from the XQuery specifications.
    * </p>
    * <p>
    * Moreover, while a dynamic evaluation is operating, a call of cancel()
    * operation may request the immediate interruption of the processing. On the
    * evaluation stop, a <code>CancelException</code> is thrown.
    * </p>
    * 
    * @param context_item the initial context item to be put in the focus of the
    *           dynamic evaluation context.
    * @return the sequence resulting from the dynamic evaluation.
    * @throws DynamicException when an error occurred.
    * @throws TypeException when a type error has been encountered.
    * @throws CancelException when the evaluation has been interrupted.
    */
   public DrbSequence evaluate(final DrbItem context_item)
         throws DynamicException, TypeException, CancelException
   {
      return this.evaluate(context_item, 1, 1);
   }

   /**
    * Cancel current evaluation.
    * <p>
    * This operation request a call off to the running evaluation. The effective
    * cancellation depends on the nature of the query script and its current
    * processing status. Actually, the expression tree may or not involve
    * expressions that support cancellation request. Basically, the support of
    * this feature has been primarily assigned to time consuming expression such
    * a FLWOR expression. If the script does not involve any expression
    * supporting cancellation requests, it will never stop before the normal end
    * of dynamic evaluation.
    * </p>
    * <p>
    * When a understanding expression detects a cancellation request, it
    * interrupts is current processing and throws a CancelException in order to
    * inform its holding thread that the evaluation has been called off. If that
    * case the evaluation result may be incomplete and should be used carefully,
    * should the case arise (e.g. a interrupted query tracing records in the
    * logger).
    * </p>
    * <p>
    * This operation has no effect is no evaluation is currently running. The
    * operation return a boolean status wether the cancellation has been
    * requested or not.
    * </p>
    * <p>
    * Caller may provide a message detailing the reason of cancellation. This
    * message will be used for formatting the exception message. Caller should
    * consider that its message will be appended to a sentence ending with an
    * expression equivalent to "... has been cancelled due to ". Caller should
    * not begin with an upper-case character appart if mandatory and end its
    * message with a trailing dot for convenient reasons.
    * </p>
    * 
    * @param reason reason of cancellation request to be reported in the
    *           exception.
    * @return true if the cancellation request has been sent and false if it has
    *         no sense.
    */
   public synchronized boolean cancel(final String reason)
   {
      if (this.isRunningEvaluation == true)
      {
         this.body.cancel(reason);
         return true;
      }
      else
      {
         return false;
      }
   }

   /**
    * Evaluates the body expression without initial context node.
    * 
    * @return the list of nodes resulting from the evaluation of the query. The
    *         result can be null if the expression does not match any node.
    * @see <a href="http://www.w3.org/TR/xquery">http://www.w3.org/TR/xquery</a>
    * @deprecated this operation has been replaced by the evaluate() series of
    *             operations. The main difference consist in the change of
    *             output type that now is Sequence and, therefore, may be a
    *             collection of mixed nodes, attributes and atomic values.
    */
   public DrbNodeList eval()
   {
      return this.eval(null, null);
   }

   /**
    * Evaluates the body expression with a resolver.
    * 
    * @param resolver the optional parameter resolver.
    * @return the list of nodes resulting from the evaluation of the query. The
    *         result can be null if the expression does not match any node.
    * @see <a href="http://www.w3.org/TR/xquery">http://www.w3.org/TR/xquery</a>
    * @deprecated this operation has been replaced by the evaluate() series of
    *             operations. The main difference consist in the change of
    *             output type that now is Sequence and, therefore, may be a
    *             collection of mixed nodes, attributes and atomic values.
    */
   public DrbNodeList eval(final ParameterResolver resolver)
   {
      return this.eval(null, resolver);
   }

   /**
    * Evaluates the body expression with an initial context node. The context
    * node is the default node from witch all relative paths of the query shall
    * refer to. For instance, an initial context node wrapping the current
    * working directory allows to parse path expressions relative to this
    * current working directory.
    * <p>
    * The initial context instanciated at the beginning of the evaluation has
    * the following properties :
    * <ul>
    * <li><b>Context item:</b> the specified context node;</dd>
    * <li><b>Position:</b> the position is defaulted to 1;</dd>
    * <li><b>Bindings:</b> no binding are set.</dd>
    * </ul>
    * </p>
    * See the XQuery specifications for a complete description of what is an
    * evaluation context.
    * 
    * @param context_node the node to be considered as initial context node.
    * @return the list of nodes resulting from the evaluation of the query. The
    *         result can be null if the expression does not match any node.
    * @see <a href="http://www.w3.org/TR/xquery">http://www.w3.org/TR/xquery</a>
    * @deprecated this operation has been replaced by the evaluate() series of
    *             operations. The main difference consist in the change of
    *             output type that now is Sequence and, therefore, may be a
    *             collection of mixed nodes, attributes and atomic values.
    */
   public DrbNodeList eval(final DrbNode context_node)
   {
      return this.eval(context_node, null);
   }

   /**
    * Evaluates the body expression with an initial context node and a resolver.
    * The context node is the default node from witch all relative paths of the
    * query shall refer to. For instance, an initial context node wrapping the
    * current working directory allows to parse path expressions relative to
    * this current working directory.
    * <p>
    * The initial context instanciated at the beginning of the evaluation has
    * the following properties :
    * <ul>
    * <li><b>Context item:</b> the specified context node;</dd>
    * <li><b>Position:</b> the position is defaulted to 1;</dd>
    * <li><b>Bindings:</b> no binding are set.</dd>
    * </ul>
    * </p>
    * See the XQuery specifications for a complete description of what is an
    * evaluation context. The parameter resolver allows to evaluate queries with
    * variable parameters (i.e. basically XQueries calling the built-in function
    * parameter()).
    * 
    * @param context_node the context node (may be null).
    * @param resolver the resolver to be used (may be null).
    * @return the list of nodes resulting from the evaluation of the query. The
    *         result can be null if the expression does not match any node.
    * @see <a href="http://www.w3.org/TR/xquery">http://www.w3.org/TR/xquery</a>
    * @deprecated this operation has been replaced by the evaluate() series of
    *             operations. The main difference consist in the change of
    *             output type that now is Sequence and, therefore, may be a
    *             collection of mixed nodes, attributes and atomic values.
    */
   public DrbNodeList eval(final DrbNode context_node,
         final ParameterResolver resolver)
   {
      /**
       * Put the resolver in the static context.
       */
      // TODO: remove this deprecated field.
      this.context.resolver = resolver;

      /**
       * Creates the environment based on the context node and the former
       * resolver.
       */
      final DrbSequence sequence = this.evaluate(context_node);

      /**
       * Convert what can be converted of the resulting sequence in a node list.
       */
      final DrbNodeList output_node_list = new DrbDefaultNodeList();

      for (int iitem = 0; iitem < sequence.getLength(); iitem++)
      {
         final DrbItem item = sequence.getItem(iitem);

         DrbNode output_node = null;

         if (item.getItemType() == DrbItem.NODE_ITEM)
         {
            output_node = (DrbNode) item;
         }
         else if (item.getItemType() == DrbItem.VALUE_ITEM)
         {
            output_node = new DrbDefaultMutableNode(null);
            output_node.setValue((Value) item);
         }
         else
         {
            logger.warn("Deprecated eval() implementation does not "
                  + "support attrbiute in output.");
            continue;
         }

         output_node_list.addItem(output_node_list.getLength(), output_node);
      }

      return output_node_list;
   }

   /**
    * Returns the effective boolean value of a sequence.
    * <p>
    * The effective boolean value of a sequence is defined as the result of
    * applying the fn:boolean function to the value, as defined in the "XQuery
    * 1.0 and XPath 2.0 Functions and Operators".
    * </p>
    * <p>
    * The semantics of fn:boolean are repeated here for convenience. fn:boolean
    * returns false if its operand is any of the following:
    * </p>
    * <ul>
    * <li>An empty sequence</li>
    * <li>The boolean value false</li>
    * <li>A zero-length value of type xs:string or xdt:untypedAtomic</li>
    * <li>A numeric value that is equal to zero</li>
    * <li>The xs:double or xs:float value NaN</li>
    * </ul>
    * 
    * @param sequence the sequence to be assessed.
    * @return the computed effective boolean value.
    */
   public static boolean getEffectiveBooleanValue(final DrbSequence sequence)
   {
      /**
       * Case of empty sequence.
       */
      if ((sequence == null) || (sequence.getLength() == 0))
      {
         return false;
      }

      /**
       * Case of singleton
       */
      if (sequence.getLength() == 1)
      {
         final DrbItem item = sequence.getItem(0);

         if (item != null)
         {
            final Value value = item.getValue();

            if (value != null)
            {
               // Case of false boolean value.

               if (((value.getType() == Value.BOOLEAN_ID) && (((fr.gael.drb.value.Boolean) value)
                     .booleanValue() == false))

                     // Case of zero-length string.

                     || ((value.getType() == Value.STRING_ID) && (((fr.gael.drb.value.String) value)
                           .toString().length() == 0))

                     // Case of zero numeric value

                     || ((value instanceof fr.gael.drb.value.Numeric) && (((fr.gael.drb.value.Numeric) value)
                           .doubleValue() == 0.0))

                     // Case of NaN double values.

                     || ((value.getType() == Value.DOUBLE_ID) && ((((fr.gael.drb.value.Numeric) value)
                           .doubleValue() == java.lang.Double.NaN)
                           || (((fr.gael.drb.value.Numeric) value)
                                 .doubleValue() == java.lang.Double.POSITIVE_INFINITY) || (((fr.gael.drb.value.Numeric) value)
                           .doubleValue() == java.lang.Double.NEGATIVE_INFINITY)))

                     // Case of Nan float values.

                     || ((value.getType() == Value.FLOAT_ID) && ((((fr.gael.drb.value.Numeric) value)
                           .floatValue() == java.lang.Float.NaN)
                           || (((fr.gael.drb.value.Numeric) value).floatValue() == java.lang.Float.POSITIVE_INFINITY) || (((fr.gael.drb.value.Numeric) value)
                           .floatValue() == java.lang.Float.NEGATIVE_INFINITY))))
               {
                  return false;
               }
            }
         }
         else
         {
            throw new NullPointerException(
                  "The item of a singleton sequence shall never be null");
         }
      }

      /**
       * Otherwwise the boolean value is true.
       */
      return true;
   }

   /**
    * Returns the command line usage of main operation.
    * 
    * @return String object containing a command line usage help.
    */
   public static String usage()
   {
      final String message =
         ""
               + "Usage:\n"
               + "\n"
               + "java fr.gael.drb.query.Query [options]\n"
               + "\n"
               + "This command evaluates the XQuery script provided as a string or\n"
               + "a file. The output of the evaluation is printed out in the\n"
               + "standard output. The output format may have several forms\n"
               + "according to the resulting sequence. Basically the resulting\n"
               + "nodes are output as XML fragments, the attributes not attached\n"
               + "to nodes are written as in XML but prefixed with '@' symbol and\n"
               + "fianlly, the atomic values are printed without decoration, \n"
               + "according to the XML Schema lexical space definitions. All items\n"
               + "of the output sequence are comma separated. A '()' result dennotes\n"
               + "the empty sequence.\n"
               + "\n"
               + "The warning or error are printed in the log4j logger (c.f.\n"
               + "http://logging.apache.org/log4j/docs/index.html for detailed\n"
               + "information of the logging system).\n"
               + "\n"
               + "[ [-s | --query] <xquery_string> ]\n"
               + "\n"
               + "   Command line string to be evaluated as XQuery script.\n"
               + "   This parameter cannot be used jointly with -f. At least -s\n"
               + "   or -f is to be set.\n"
               + "\n"
               + "[ [-f | --query-file] <xquery_file> ]\n"
               + "\n"
               + "   Path to a file containing the sctript to be evaluated. This\n"
               + "   parameter cannot be used jointly with -s. At least -f or -s is\n"
               + "   to be set.\n"
               + "\n"
               + "[ -variable <QName> <value> [ as <type> ]]\n"
               + "\n"
               + "   Pushses an external variable in the environment prior to parse\n"
               + "   and evaluate the XQuery script.  The variable is pushed in the\n"
               + "   the environment altough it has not been declared has an\n"
               + "   external variable, to provide it to the potential nested\n"
               + "   XQuerys (e.g. a call to evaluate-uri() built-in function).\n"
               + "   <QName> is the qualified name of the variable to declare\n"
               + "   whether <value> is a string to bind as value of the variable.\n"
               + "   If <QName> matches a typed external variable declared in the\n"
               + "   script, <value> is converted to that type before being bound.\n"
               + "   The trailing \"as <type>\" is optional and shall follow the\n"
               + "   XQuery sequence type declaration (e.g. as xs:integer+ ).\n"
               + "\n"
               + "[[ -help | --help | -h ] [subject [name]]]\n"
               + "\n"
               + "   If no [subject] is specified then prints out the present help\n"
               + "   message. This parameter overides all others.\n"
               + "   [subject] can be one of the following:\n"
               + "     'impl'      : Prints out the available implementations\n"
               + "     'sdf' [name]: Prints out the available sdf tags\n"
               + "                   If a [name] is specify then try to display\n"
               + "                   the detailed information about the specified\n"
               + "                   tag\n"
               + "     'xql' [name]: Prints out the available XQuery functions\n"
               + "                   If a [name] is specify then try to display\n"
               + "                   the detailed information about all matching\n"
               + "                   XQuery functions\n"
               + "     'xsd'       : Prints the supported XML Schema version\n"
               + "\n"
               + "[ -v | --version ]\n"
               + "\n"
               + "   Prints out the current version of the CLI. This parameter \n"
               + "   overides all others apart the help trigger.\n"
               + "\n"
               + "It is assumed that DRB classpath and dependecies are correctly\n"
               + "configured.\n";

      return message;
   }

   /**
    * Returns the command line help message for the specified subject.
    * 
    * @param subject the type of help requested
    * @param name name of the thing to be detailed inside the subject
    * @return String object containing a command line help corresponding to the
    * subject or null if the subject is invalid.
    */
   public static String helpMsgFor(String subject, String name)
   {
      String message = null;

      // Case: "XQL"
      if ("xql".equalsIgnoreCase(subject))
      {
         final String xqlDocFile = "doc/query_functions.xml";

         // Get its url (since it is in the jar file)
         final java.net.URL xql_url =
            Query.class.getClassLoader().getResource(xqlDocFile);

         /* OLD code to be removed
         fr.gael.drb.impl.xml.XmlFactory myFactory =
            new fr.gael.drb.impl.xml.XmlFactory(); 
         
         try 
         {
            DrbNode myNode = myFactory.open(xql_url);

            System.err.println(myNode);
         } catch (Exception exp)
         {
            System.err.println(exp);
         }
         */

         // Obtain the Node corresponding to the resource file
         DrbNode myNode = DrbFactory.openURI(xql_url+"");

         // Retrieve the data root node
         DrbNode dataRootNode = myNode.getFirstChild();

         // In case where the user ask for a specific function
         if (name != null)
         {
            final String xqlQueryFunctionsList = "doc/list_function.xql";
            // Open a stream for that script
            final InputStream xql_script_is =
               Query.class.getClassLoader().getResourceAsStream(
                     xqlQueryFunctionsList);
            
            // Create the corresponding query instance
            Query query = new Query(xql_script_is);

            // Get the external variables
            ExternalVariable[] extVariables = query.getExternalVariables();

            // Set the external variables
            if (extVariables != null)
            {
               // Loop on them
               for (int iext = 0; iext < extVariables.length; iext++)
               {
                  ExternalVariable var = extVariables[iext];

                  // Get the variable name
                  String varName = var.getName();

                  if (varName.equals("func_pattern"))
                  {
                     // Set it a new value
                     var.setValue(new
                           fr.gael.drb.value.String(name));
                  } else
                  {
                     logger.warn("Unexpected external variable in internal " +
                     "script file: " + xqlQueryFunctionsList);
                  }
               }
            }

            // Evaluate the query
            // Execute the dedicated script for retrieving the function list
            DrbSequence mySequence = query.evaluate(myNode);

            /* TODO: OLD code to be removed
            // Get the node corresponding to the function
            Query myQuery =
               new Query("for $fnt in QueryFunction[fn:matches(fn:substring-before(fn:data(signature[1]),'('), '.*:.*" + name + ".*')] return fn:concat(fn:string-join(fn:data($fnt/signature), '\n'), '\n      ', fn:data($fnt/doc), if (fn:count($fnt/conformance) != 0) then fn:concat('\n      [Conformance] ', fn:data($fnt/conformance)) else '', if (fn:count($fnt/specificity) != 0) then fn:concat('\n      [!] ', fn:data($fnt/specificity)) else '', if (fn:count($fnt/deprecated) != 0) then fn:concat('\n      [DEPRECATED] ', fn:data($fnt/deprecated)) else '', if ($fnt/@supported = 'false') then xs:string('\n      [NOT SUPPORTED] This function is not supported!') else '', if (fn:count($fnt/example) != 0) then fn:concat('\n\n[Example]\n', fn:data($fnt/example[1])) else '')");
            DrbSequence mySequence = myQuery.evaluate(dataRootNode);
            */

            // Case where the evaluation gives no result
            if (mySequence.getLength() == 0)
            {
               message = "No match found for pattern '" + name + "'";
            } else
            {
               // Initialize the message with empty string (no more 'null')
               message = "";

               // Add a intro message specifying how much function have been found
               String plural = (mySequence.getLength() > 1)? "s":"";
               message += "Pattern \'" + name + "\' match " +
                  mySequence.getLength() + " function" + plural + ":\n\n";

               // Loop on each result (ie. each matching function)
               for (int iitem = 0; iitem < mySequence.getLength(); iitem++)
               {
                  DrbItem myItem = mySequence.getItem(iitem);

                  // Required replacement for interpreting the \n as a new line
                  message += myItem.toString().replaceAll("\\\\n", "\n") + "\n\n";
               }
            }

         } else // Case where the user wants all the function list
         {
            // Retrieve the functions list
            DrbNodeList fntList = dataRootNode.getChildren();

            // Initialize the message with empty string (no more 'null')
            if (fntList.getLength() >= 1)
            {
               message = "";
            }

            // Loop on each function description
            for (int ifnt = 0; ifnt < fntList.getLength(); ifnt++)
            {
               DrbNode fntNode = fntList.item(ifnt);

               // Retrieve the supported status
               Value supported_val =
                  fntNode.getAttribute("supported").getValue();
               boolean supported = Boolean.parseBoolean(supported_val + "");

               String supported_str = "";
               if (supported == false)
               {
                  supported_str = "[NOT SUPPORTED] ";
               }

               // Retrieve the deprecated status
               String deprecated_str = "";
               if (fntNode.getNamedChild("deprecated", 1) != null)
               {
                  deprecated_str = "[DEPRECATED] ";
               }

               // Compose the signature to be displayed in the synthetic view
               String fntSignature =
                  fntNode.getNamedChild("signature",1).getValue() + "";

               message += supported_str + deprecated_str + fntSignature + "\n";
            }
         }
      // Case: "IMPL"
      } else if ("impl".equalsIgnoreCase(subject))
      {
         message = "Implementation list:\n";

         Hashtable<String, String> extensionHash = 
            DrbDefaultMetadataResolver.getExtensionHash();

         message += "  MIME Type -> DRB implementation:\n";
         for (Enumeration<String> keys = extensionHash.keys();
               keys.hasMoreElements() ;)
         {
            String key = keys.nextElement();

            message += "  ." + key + " -> " + extensionHash.get(key) + "\n";
         }

         /* TOSEE: this section may not work with Cortex... To be validated!
         Hashtable<String, String> schemaHash = 
            DrbDefaultMetadataResolver.getSchemaHash();

         message += "\n";
         message += "  2) file extension -> schema path:\n";
         if (schemaHash.isEmpty())
         {
            message += "     <none>\n";
         } else
         {
            for (Enumeration<String> keys = schemaHash.keys();
                  keys.hasMoreElements() ;)
            {
               String key = keys.nextElement();

               message += "    ." + key + " -> " + schemaHash.get(key) + "\n";
            }
         }
         */
      // Case: "sdf"
      } else if ("sdf".equalsIgnoreCase(subject))
      {
         message = "Current SDF namespace is: \""
            + SdfFactory.getDefaultVersion() + "\"\n";

         // Open the SDF schema and parse it for extracting required information
         final String xsdFile = "xsd/sdf-2_3.xsd";

         // Get its url (since it is in the jar file)
         final java.net.URL xsd_url =
            Query.class.getClassLoader().getResource(xsdFile);

         // Obtain the Node corresponding to the resource file
         DrbNode myNode = DrbFactory.openURI(xsd_url+"");

         // Use the XSD factory to interpret the schema
         XmlSchema mySchema = new XsdFactory().open(myNode.getFirstChild());


         // Case where the user wants a detailled help on a SDF tag
         if (name != null)
         {
            boolean found = false;
            // Retrieve all the root elements of the schema file
            XsdElement[] rootElts = mySchema.getRootElements();
            // Select the right node to be detailed (loop also on root nodes)
            for (int i_root = 0; i_root < rootElts.length; i_root++)
            {
               XsdElement xsdElt = rootElts[i_root];
               XsdType    type   = xsdElt.getType();
               XsdComplexType structure = type.getStructure();

               XsdModelGroup mg = structure.getComplexContent();

               // Initialize the handle on the particule to find
               XsdParticle part = null;

               // Indent value to be used
               String indent = "";

               // Check if the name request by user is the root node
               if (xsdElt.getName().equals(name))
               {
                  part = xsdElt;
                  found = true;
               } else
               {
                  // Try to found the particle corresponding to the tag enter by
                  // user in the 'second level child'.
                  for (int i = 0; i < mg.getLength(); i++)
                  {
                     XsdParticle tmpPart = mg.getParticle(i);
                     XsdElement tmpElt = (XsdElement)tmpPart;

                     if (tmpElt.getName().equals(name))
                     {
                        part = tmpPart;
                        found = true;
                        indent = "   ";
                     }
                  }
               }

               // In case we found a matching particle
               if (part != null)
               {
                  message += "\nDetail tag content: (from sdf:"
                     + xsdElt.getName() + ")\n"
                     + "------------------\n\n";

                  message += getDocRecursive(part, indent, true);
               }
            }

            // Case of error (no tag found with the specified name in any of the
            // root elements)
            if (found == false)
            {
               message = "No match found for SDF tag '" + name + "'";
            }
         } else // Case of all SDF tags to be listed
         {
            // First prints out the notes about the whole schema
            XsdAnnotation mySchemaAnnot = mySchema.getAnnotation();

            if (mySchemaAnnot != null)
            {
               XsdDocumentation[] mySchemaDocs =
                  mySchemaAnnot.getDocumentations();

               if ((mySchemaDocs != null) && (mySchemaDocs.length >= 1))
               {
                  message += "\nNote:\n";
                  // Loop on all documentation nodes
                  for (int i = 0; i < mySchemaDocs.length; i++)
                  {
                     message += "       " + mySchemaDocs[i].getContent() + "\n";
                  }
               }
            }

            // Now prints out all elements tags names with their attributes
            // without their documentation!
            message += "\nSupported SDF tags:\n"
               + "------------------\n";

            XsdElement[] rootElts = mySchema.getRootElements();
            for (int i = 0; i < rootElts.length; i++)
            {
               message += "\n" + getDocRecursive(rootElts[i], "", false);
            }
         }

      // Case: "xsd"
      } else if ("xsd".equalsIgnoreCase(subject))
      {
         message = "Current XML Schema namespace: \""
            + Namespace.XML_SCHEMA_NAMESPACE + "\"\n"
            + "Note that some restrictions may occurred; please contact "
            + "drb-support@gael.fr for details\n";
      }
 

      return message;
   }

   /**
    * Allow to retrieve the documentation content from an Annotation node.
    *
    * @param annot the annotation node from which we try to retrieve the
    * documentation.
    *
    * @return the documenation if any, otherwise the empty string.
    */
   private static String getDocumentation(XsdAnnotation annot)
   {
      String doc = "";

      // If the annotation exist try to retrieve its doc
      if (annot != null)
      {
         XsdDocumentation[] docs = annot.getDocumentations();

         if ((docs != null) && (docs.length >= 1))
         {
            // Loop on all documentation nodes
            for (int i = 0; i < docs.length; i++)
            {
               DrbSequence tmp = docs[i].getContent();
               if (tmp != null)
               {
                  doc += tmp + "\n";
               }
            }
         }
      }

      return doc;
   }

   /**
    * Allow to retrieve the documentation of a schema particle instance.
    *
    * @param xsdPart the schema particle from which the documentation is
    * to be extracted
    *
    * @return the formated documentation corresponding to the schema particle.
    */
   private static String getSchemaParticleDocumentation(XsdParticle xsdPart)
   {
      XsdAnnotation annot = xsdPart.getAnnotation();

      return getDocumentation(annot);
   }

   /**
    * Allow to retieve all the node and attributes documentation with
    * appropriate indentation.
    *
    * @param xsdPart the XSD particle to be displayed (with its child)
    * @param indent the current required indentation.
    * @param detailed indicates if the method shall return the detailed content
    * of the node (documentation...)
    *
    * @return the formated documentation correspondind to the node pass in arg.
    */
   private static String getDocRecursive(XsdParticle xsdPart, String indent,
         boolean detailed)
   {
      String msg = "";

      // Check we have an element (otherwise just return)
      if (xsdPart.getTerm() != XsdParticle.ELEMENT_TERM)
      {
         // The particle xsdPart is not an element!
         return "";
      }

      XsdElement xsdElt = (XsdElement)xsdPart;
      XsdType    type   = xsdElt.getType();

      // Get the attributes (if any)
      String att_str = "";
      String doc_att = ""; // The doc of attribute
      if (type.isComplex())
      {
         XsdComplexType structure = type.getStructure();
         XsdAttributeGroup attGrp = structure.getAttributeGroup();
         if (attGrp != null)
         {
            XsdAttribute[] xsdAtts = attGrp.getContent();

            for (int i = 0; i < xsdAtts.length; i++)
            {
               att_str += " " + xsdAtts[i].getName() + "=\"\"";

               // Update doc
               doc_att += "\n" + indent + "   @" + xsdAtts[i].getName() +
                  ":\n" + indent + "   " + "      " +
                  getDocumentation(xsdAtts[i].getAnnotation());
            }
         }
      }

      // Display name for this element with its attributes (if any)
      // The closing syntax is managed later...
      msg += indent + "<sdf:" + xsdElt.getName() + att_str;


      // Get detail doc for this element and its attributes (only if required!)
      String doc = "";
      if (detailed)
      {
         doc = getSchemaParticleDocumentation(xsdPart);
         // Complete the doc with the attributes documenation
         doc += doc_att + "\n";
      }

      // Adapt behaviour depending on the type ('complex' or 'simple')
      boolean hasChild = false;
      XsdComplexType structure = null;
      XsdModelGroup mg = null;
      // Check the existance of child (if any)
      if (type.isComplex())
      {
         structure = type.getStructure();
         mg = structure.getComplexContent();
         if (mg.getLength() > 0)
         {
            hasChild = true;
         }
      }

      if (hasChild)
      {
         // Close the opening element tag (but the element stay open!)
         msg += ">\n";

         // Paste documentation of the element
         if (doc != "")
         {
            msg += indent + "         " + doc;
         }

         for (int i = 0; i < mg.getLength(); i++)
         {
            XsdParticle part = mg.getParticle(i);
            msg += getDocRecursive(part, indent+"   ", detailed);
         }

         // Since the element contains other elements, now close it
         msg += indent + "</sdf:" + xsdElt.getName() + ">\n";
      } else
      {
         // In case of simpleType just close the element (one line)
         msg += "/>\n";

         // Paste documentation of the element
         if (doc != "")
         {
            msg += indent + "         " + doc;
         }
      }

      return msg;
   }

   /**
    * XQuery engine command line (CLI). This command evaluates the XQuery script
    * provided as a string or a file. The output of the evaluation is printed
    * out in the standard output. The output format may have several forms
    * according to the resulting sequence. Basically the resulting nodes are
    * output as XML fragments, the attributes not attached to nodes are written
    * as in XML but prefixed with '@' symbol and finally, the atomic values are
    * printed without decoration, according to the XML Schema lexical space
    * definitions. All items of the output sequence are comma separated. A '()'
    * result dennotes the empty sequence. The warning or error are printed in
    * the log4j logger (c.f. http://logging.apache.org/log4j/docs/index.html for
    * detailed information of the logging system).
    * {@code [ -s <xquery_string> ]}
    * Command line string to be evaluated as XQuery script. This parameter
    * cannot be used jointly with -f. At least -s or -f is to be set.
    * {@code [ -f <xquery_file> ]}
    * Path to a file containing the sctript to be evaluated.
    * This parameter cannot be used jointly with -s. At least -f or -s is to be
    * set. {@code [ -variable <QName> <value> [ as <type> ]]}
    * 
    * Pushses an external variable in the environment prior to parse and
    * evaluate the XQuery script.  The variable is pushed in the the
    * environment altough it has not been declared has an external variable, to
    * provide it to the potential nested XQuerys (e.g. a call to evaluate-uri()
    * built-in function). {@code <QName>} is the qualified name of the variable
    * to
    * declare whether {@code <value>} is a string to bind as value of the
    * variable.  If
    * {@code <QName>} matches a typed external variable declared in the script,
    * {@code <value>}
    * is converted to that type before being bound.  The trailing
    * \"{@code as <type>}\"
    * is optional and shall follow the XQuery sequence type declaration (e.g.
    * as xs:integer+ ).
    *
    * [ -help | --help | -h ]
    *
    * Prints out the present help message. This parameter overides all others.
    *
    * [ -v | --version ]
    *
    * Prints out the current version of the CLI. This parameter overides all
    * others apart the help trigger.
    *
    * It is assumed that DRB classpath and dependecies are correctly
    * configured.
    *
    * The command exits with a 0 status if no error occured and 1 otherwise.
    *
    * @param args the concatenation of the arguments forms the XQuery script
    *               to be evaluated.
    */
   public static void main(final String args[])
   {
      /**
       * The parameters are parsed accoding to the
       */
      String xquery_string = null;
      String xquery_file_name = null;
      FileInputStream xquery_file = null;

      final Vector<String> variable_name = new Vector<String>();
      final Vector<DrbSequence> variable_value = new Vector<DrbSequence>();
      final Vector<SequenceType> variable_type = new Vector<SequenceType>();

      // Arguments processing
      int iarg;
      boolean argument_error = false;
      boolean display_usage = false;

      // A first loop on arguments to identify help parameter that
      // overrides any others.
      for (iarg = 0; iarg < args.length; iarg++)
      {
         /**
          * Case of HELP parameter.
          * Sub-case 1: 'user add some "subject" option'
          *   Prints the corresponding help.
          * Sub-case 2: 'user just want the basic help'
          *   Prints the usage message and exit the application.
          */
         if (args[iarg].equals("-help") || args[iarg].equals("--help")
               || args[iarg].equals("-h"))
         {
            // Test the 'subject' option
            if((iarg+1 < args.length) && (!args[iarg+1].startsWith("-")))
            {
               String name = null;
               // Test the 'name' option
               if ((iarg+2 < args.length) && (!args[iarg+2].startsWith("-")))
               {
                  name = args[iarg+2];
               }

               String helpMsg = helpMsgFor(args[iarg+1], name);
               if (helpMsg == null)
               {
                  logger.error("Invalid subject '" + args[iarg+1] +
                        "' for detailed help!");
                  return;
               }
               else
               {
                  System.out.println(helpMsg);
                  return;
               }
            }
            else // case of no option for help
            {
               System.out.println(usage());
               return;
            }
         }
      }

      // A first loop on arguments to identify version parameter that
      // overrides any others but the help message.
      for (iarg = 0; iarg < args.length; iarg++)
      {
         /**
          * Case of Version request.
          */
         if (args[iarg].equals("-v") || args[iarg].equals("--version"))
         {
            Package drb_package = Query.class.getPackage();

            System.out.println(drb_package.getImplementationTitle() + " - " +
                  drb_package.getImplementationVersion() + " (" +
                  drb_package.getImplementationVendor() + ")");

            return;
         }
      }

      for (iarg = 0; iarg < args.length; iarg++)
      {
         /**
          * Case of XQuery string.
          */
         if (args[iarg].equals("-s") || args[iarg].equals("--query"))
         {
            if (iarg >= (args.length - 1))
            {
               logger.error("\"-s\" option shall be followed by an argument.");
               display_usage = true;
               argument_error = true;
               continue;
            }

            iarg += 1;

            xquery_string = args[iarg];
         }

         /**
          * Case of XQuery file. Check that a file path has been provded and
          * open it.
          */
         else if (args[iarg].equals("-f") || args[iarg].equals("--query-file"))
         {
            if (xquery_file != null)
            {
               logger.error("The file \"" + xquery_file_name
                     + "\" has already been provided as XQuery script.");
               argument_error = true;
            }

            if (xquery_string != null)
            {
               logger
                     .error("A string has already been provided as XQuery script.");
               argument_error = true;
            }

            if (iarg >= (args.length - 1))
            {
               logger.error("\"-f\" option shall be followed by a file name.");
               display_usage = true;
               argument_error = true;
               continue;
            }

            iarg += 1;

            try
            {
               xquery_file = new FileInputStream(args[iarg]);
            }
            catch (final FileNotFoundException exception)
            {
               logger.error(exception.getMessage());
               argument_error = true;
            }

            xquery_file_name = args[iarg];
         }

         /**
          * Case of environment variable.
          */
         else if (args[iarg].equals("-variable"))
         {
            if (iarg >= (args.length - 2))
            {
               logger.error("\"-variable\" option shall be followed by a "
                     + "qualified name and a value (not enougth arguments).");
               display_usage = true;
               argument_error = true;
               continue;
            }

            iarg += 1;

            if (variable_name.contains(args[iarg]))
            {
               logger
                     .error("Variable \"" + args[iarg] + "\" already declared.");
               argument_error = true;
               continue;
            }

            variable_name.add(args[iarg]);

            iarg += 1;

            final Value value_string = new fr.gael.drb.value.String(args[iarg]);
            SequenceType sequence_type = null;

            if ((iarg < (args.length - 2)) && (args[iarg + 1].equals("as")))
            {
               iarg += 2;

               int occurence_indicator = SequenceType.ONE_OCCURRENCE;
               String type_name = args[iarg];

               if (args[iarg].endsWith("?"))
               {
                  occurence_indicator = SequenceType.ZERO_OR_ONE_OCCURRENCE;
                  type_name = args[iarg].substring(0, args[iarg].indexOf('?'));
               }
               else if (args[iarg].endsWith("+"))
               {
                  occurence_indicator = SequenceType.ONE_OR_MORE_OCCURRENCE;
                  type_name = args[iarg].substring(0, args[iarg].indexOf('+'));
               }
               else if (args[iarg].endsWith("*"))
               {
                  occurence_indicator = SequenceType.ZERO_OR_MORE_OCCURRENCE;
                  type_name = args[iarg].substring(0, args[iarg].indexOf('*'));
               }

               sequence_type = new SequenceType(type_name, occurence_indicator);
            }
            else
            {
               sequence_type =
                  new SequenceType("xs:string",
                        SequenceType.ONE_OR_MORE_OCCURRENCE);
            }

            variable_type.add(sequence_type);

            variable_value.add(sequence_type.convert(new DrbDefaultSequence(
                  value_string)));
         }

         /**
          * Case of unsupported argument
          */
         else
         {
            logger.warn("Unsupported argument \"" + args[iarg]
                  + "\" (Ignored).");
         }
      } // Loop on arguments

      /**
       * Checks that an XQuery script has been provided as string or file.
       */
      if ((xquery_string == null) && (xquery_file == null))
      {
         logger.error("No XQuery script specified (\"-s\" or \"-f\" options).");
         display_usage = true;
         argument_error = true;
      }

      /**
       * Process parameter error if exists.
       */
      if (display_usage)
      {
         logger.error("Use the \"-h\" or \"--help\" option for a detailed "
               + "specification of the parameters.");
      }

      if (argument_error)
      {
         Runtime.getRuntime().exit(1);
      }

      /**
       * Parses the XQuery script.
       */
      Query query = null;

      try
      {
         if (xquery_file != null)
         {
            final Environment env = new Environment();
            env.setBaseURI(new File(xquery_file_name).toURI().toString());
            query = new Query(xquery_file, env);
         }
         else
         {
            query = new Query(xquery_string);
         }
      }
      catch (final Exception exception)
      {
         exception.printStackTrace();
         logger.error(exception.getMessage());
         Runtime.getRuntime().exit(1);
      }

      /**
       * Opens the current working directory to be used as context item.
       */
      final DrbNode root_node = DrbFactory.openURI(".");

      /**
       * Pushes the declared variables.
       */
      final Environment environment = query.getEnvironment();

      for (int ivar = 0; ivar < variable_name.size(); ivar++)
      {
         final QName name = environment.resolveQName(variable_name.get(ivar));

         ExternalVariable external_variable =
            environment.getExternalVariable(name);

         if (external_variable == null)
         {
            external_variable =
               new ExternalVariable(name, variable_type.get(ivar), null);

            environment.addExternalVariable(external_variable);
         }

         external_variable.setValue(variable_value.get(ivar));
      }

      /**
       * Evaluates the query.
       */
      DrbSequence result = null;

      try
      {
         result = query.evaluate(root_node);
      }
      catch (final Throwable exception)
      {
         logger.error(exception.getMessage());
         exception.printStackTrace();
         Runtime.getRuntime().exit(1);
      }

      /**
       * Prints out the resulting sequence.
       */
      for (int iitem = 0; iitem < result.getLength(); iitem++)
      {
         final DrbItem item = result.getItem(iitem);

         if (iitem != 0)
         {
            System.out.print(", ");
         }

         if (item.getItemType() == DrbItem.NODE_ITEM)
         {
            XmlWriter.writeXML((DrbNode) item, System.out, null, false);
         }
         else
         {
            System.out.print(item);
         }
      }
      System.out.println();
   }
}
