/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.file;

import java.io.IOException;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbNode;
import fr.gael.drb.impl.spi.DrbNodeSpi;

/**
 * File or Directory of a local file system. This implementation breaks down the
 * local file system into file and directories. It is useful to browse the local
 * file system as a file manager. The file nodes have no specific attribute.
 * <p>
 * <b>Thread safe strategy:</b> This class is thread safe. The strategy to
 * prevent access collisions between two or more treads, all the writting
 * accesses to the ressources (i.e. attributes of this class) that may be
 * changed by a thread are synchronised. Only the accesses occurring after the
 * constructor are affected by this rule.
 * </p>
 */
public final class File extends DrbNodeSpi
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(File.class);

   /**
    * Builds a File instance. This contructors sets the provided Java File and
    * caches its children. This implementation does not check if the provided
    * parameter is a null reference. In such case, the implementation may become
    * instable without warning. If already known, the children of the current
    * node or its parent children list (i.e. its siblings and itself) can be
    * passed. This is an optimization avoiding re-creation of children lists.
    * For instance, the parent children list of a child is the chidren list of
    * the current node. In addition the children list of a parent is the parent
    * children list of the current node. Note: all the children collections
    * created by this operation are sorted. For optimization, if the children
    * and/or the parent children are already known, they can be passed in
    * parameter. This avoid reconstruction of the children lists. For the parnet
    * children list does not change from a node to any of its sibling.
    * 
    * @param file The Java File to be wrapped.
    * @param children The list of children if already known or null.
    * @param parent_children The children of the parent if already known or
    *           null.
    * @deprecated This constructor shall not be used.
    */
   public File(final java.io.File file, final java.io.File[] children,
         final java.io.File[] parent_children)
   {
      super(new FileNode(file, null));
   }

   /**
    * Builds a File instance. This contructors sets the provided Java File and
    * caches its children. This implementation does not check if the provided
    * parameter is a null reference. In such case, the implementation may become
    * instable without warning. Note: all the children collections created by
    * this operation are sorted.
    * 
    * @param file The Java File to be wrapped.
    */
   protected File(final java.io.File file)
   {
      super(new FileNode(file, null));
   }

   /**
    * Builds a File instance. This contructors sets the provided Java File and
    * caches its children. This implementation does not check if the provided
    * parameter is a null reference. In such case, the implementation may become
    * instable without warning.
    * 
    * @param file_node The File node to be wrapped.
    */
   protected File(final FileNode file_node)
   {
      super(file_node);
   }

   /**
    * Builds a getInstance from a base node and a parent TODO : this operation
    * shall raise an exception in case of null parameter.
    * 
    * @param base_node The node to be wrapped. This parameter shall never be
    *           null.
    * @return DrbNodeSpi
    */
   protected DrbNodeSpi DrbNodeSpi(final DrbNode base_node,
         final DrbNode parent)
   {
      if (base_node instanceof FileNode)
      {
         return new File((FileNode) base_node);
      }
      else
      {
         return new DrbNodeSpi(base_node, parent);
      }
   }

   /**
    * Create a node with the specified name.
    * 
    * @param name The expected name of the node.
    * @return A reference to the new file node.
    * @throws NullPointerException This exception is raised when the name
    *            provided in parameter is null.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation is not able to create a node.
    */
   public DrbNode createNode(final String name) throws NullPointerException,
         UnsupportedOperationException
   {
      try
      {
         return this.createNewFile(name);
      }
      catch (final java.io.IOException e)
      {
         return null;
      }
   }

   /**
    * Creates a new file as children of the current directory. A new file is
    * created with the passed file name. This operation is possible only if the
    * current node wraps a directory and if it has the correcte write
    * permissions. The provided name shall not already be used as name of an
    * existing file in the current directory.
    * <p>
    * <b>Events:</b> This operation fires a node change event. The node
    * affected by the change is the added node and the source is the current
    * node. The called operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param file_name The expected name of the file.
    * @return A reference to the new file node.
    * @throws NullPointerException This exception is raised when the name
    *            provided in parameter is null.
    * @throws UnsupportedOperationException This exception is raised when the
    *            current node is node a directory.
    * @throws IOException This exception is raised when the new file cannot be
    *            created in the current directory.
    * @throws SecurityException This exception is raised when a security manager
    *            exists and its SecurityManager.checkWrite
    *            (java.io.FileDescriptor) method denies write access to the file
    *            be created in the current directory.
    * @deprecated As of DRB 2.0, added createNode
    * @see createNode(java.lang.String)
    */
   public DrbNode createNewFile(final String file_name)
         throws NullPointerException, UnsupportedOperationException,
         IOException, SecurityException
   {
      return new File(((FileNode) this.baseNode).createNewFile(file_name));
   }
}
