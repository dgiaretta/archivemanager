/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * The UnsignedByte class is a generic wrapper for unsigned byte values.
 */
public class UnsignedByte extends AbstractNumeric implements ValueFormat
{
   // ========================================================================
   // Attributes part.
   // ========================================================================
   /**
    * The Byte priority.
    */
   final static int PRIORITY = 1;

   /**
    * The Byte value.
    */
   byte value;

   // ========================================================================
   // Methods part.
   // ========================================================================
   /**
    * Constructs a Byte object initialized to the specified byte value.
    * 
    * @param v the value of the Byte.
    */
   public UnsignedByte(final byte v)
   {
      this.value = v;
   }

   /**
    * Allocates a Byte object representing the value argument.
    * 
    * @param v the value of the Byte.
    */
   public UnsignedByte(final int v)
   {
      this.value = (byte) (v & 0xff);
   }

   /**
    * Constructs a UnsignedByte object initialized to the specified integer
    * buffer.
    * 
    * @param val two's-complement binary representation of UnsignedByte. The
    *           array must contain at least one byte.
    */
   public UnsignedByte(final byte[] val)
   {
      this.value = val[0];
   }

   /**
    * Constructs a UnsignedByte object initialized to the specified integer
    * buffer.
    * 
    * @param val two's-complement binary representation of UnsignedByte. The
    *           array must contain at least one byte.
    * @param off The offset of the byte in the array.
    */
   public UnsignedByte(final byte[] val, final int off)
   {
      this.value = val[off];
   }

   /**
    * Returns a new String object representing the specified Byte.
    * 
    * @return a string representation of the object.
    */
   public java.lang.String toString()
   {
      return java.lang.Short.toString((short) (this.value & (short) 0xff));
   }

   // ----------------------------------------------------------
   // Value interface implementation
   // ----------------------------------------------------------
   // see interface Value for more information.

   /**
    * Return a string containing the value with a fixed format.
    * 
    * @param length The expected length of the output string
    * @return The formatted string.
    */
   public java.lang.String getFormattedString(final int length)
   {
      return Byte.getFormattedString(length, this.value, false);
   }

   /**
    * Return a byte buffer containing the value in a fixed format.
    * 
    * @return The formatted buffer.
    */
   public byte[] getFormattedBuffer()
   {
      return Byte.getFormattedBuffer(this.value);
   }

   // ------------------------------------------------------------------------
   // Value interface implementation
   // ------------------------------------------------------------------------
   // see interface Value for more information.

   /**
    * Returns the current type.
    * 
    * @return the current type.
    */
   public final int getType()
   {
      return Value.UNSIGNED_BYTE_ID;
   }

   /**
    * Returns the current priority.
    * 
    * @return the current priority.
    */
   public final int getPriority()
   {
      return this.PRIORITY;
   }

   /**
    * Convert this Byte value into the specified type. In case of identity
    * conversion the value itself should be returned. If the conversion is not
    * allowed a ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException if the conversion is impossible
    */
   public final Value convertTo(final int type) throws ClassCastException
   {
      switch (type)
      {
         // UnsignedByte -> UnsignedByte
         case Value.UNSIGNED_BYTE_ID:
         case Value.NUMERIC_ID:
            return this;
            // UnsignedByte -> Unknown
         default:
            return super.convertTo(type);
      }
   }

   /**
    * assign a new Value to the current one.
    * 
    * @param v the new Value
    */
   public void assign(final Value v)
   {
      final Numeric vub = (Numeric) v.convertTo(Value.NUMERIC_ID);
      this.value = vub.byteValue();
   }

   // -------------------------------------------------------------------------
   // Arithmetic interface implementation
   // -------------------------------------------------------------------------
   // see interface Arithmetic for more information about these operators.
   /**
    * unary Minus
    * 
    * @return the value
    */
   public Value unaryMinus()
   {
      return new Byte(-this.value);
   }

   /**
    * Adds the current Value to the current one
    * 
    * @param x the Value to add to
    * @return the current Value added by the current one
    */
   public final Value add(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).add(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final short sum = (short) (this.shortValue() + num.shortValue());
      // Check the integrety of the result
      if (sum < 128)
      {
         return new Byte((byte) sum);
      }
      else if (sum < 256)
      {
         return new UnsignedByte((byte) sum);
      }
      else
      {
         // short range
         return new Short(sum);
      }
   }

   /**
    * Substracts the current Value by the current one
    * 
    * @param x the Value to substract to
    * @return the current Value substracted by the current one
    */
   public final Value sub(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).sub(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final short dif = (short) (this.shortValue() - num.shortValue());
      // Check the integrety of the result
      if ((dif < -128) || (dif > 255))
      {
         return new Short(dif);
      }
      if (dif < 128)
      {
         return new Byte((byte) dif);
      }
      else
      {
         return new UnsignedByte((byte) dif);
      }
   }

   /**
    * Multiplies the current Value by the current one
    * 
    * @param x the Value to multiply by
    * @return the current Value multiplied by the current one
    */
   public final Value multiply(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).multiply(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final short prod = (short) (this.shortValue() * num.shortValue());
      // Check the integrety of the result
      if ((prod < -128) || (prod > 255))
      {
         return new Short(prod);
      }
      if (prod < 128)
      {
         return new Byte((byte) prod);
      }
      else
      {
         return new UnsignedByte((byte) prod);
      }
   }

   /**
    * Divides the current Value by the current one
    * 
    * @param x the Value to divide by
    * @return the current Value divided by the current one
    */
   public final Value divide(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).divide(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final short div = (short) (this.shortValue() / num.shortValue());
      // Check the integrety of the result
      if ((div < -128) || (div > 255))
      {
         return new Short(div);
      }
      if (div < 128)
      {
         return new Byte((byte) div);
      }
      else
      {
         return new UnsignedByte((byte) div);
      }
   }

   /**
    * Calculates the current value modulus the given one.
    * 
    * @param x the Value to modulate by
    * @return the current value modulus the given one
    */
   public final Value modulus(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).modulus(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final short mod = (short) (this.shortValue() % num.shortValue());
      // Check the integrety of the result
      if ((mod < -128) || (mod > 255))
      {
         return new Short(mod);
      }
      if (mod < 128)
      {
         return new Byte((byte) mod);
      }
      else
      {
         return new UnsignedByte((byte) mod);
      }
   }

   // -------------------------------------------------------------------------
   // Comparison interface implementation
   // -------------------------------------------------------------------------
   // see interface Comparison for more information.
   /**
    * Compares the current Value to the given one
    * 
    * @param x the Value to compare with
    * @return a negative integer, zero, or a positive integer as the argument is
    *         less than, equal to, or greater than the current Value
    */
   public int compareTo(Value x)
   {
      if (this.getPriority() >= x.getPriority())
      {
         x = x.convertTo(Value.NUMERIC_ID);

         return (this.shortValue() - ((Numeric) x).shortValue());
      }

      return -((Comparison) x).compareTo(this);
   }

   // ------------------------------------------------------------------------
   // Logic interface implementation
   // ------------------------------------------------------------------------
   // see interface Logic for more information about these operators.
   /**
    * gives the logical value of this Value.
    * 
    * @return the logical value of this Value.
    */
   public final boolean booleanValue()
   {
      return (this.value != 0);
   }

   // ------------------------------------------------------------------------
   // Numeric interface implementation
   // ------------------------------------------------------------------------
   /**
    * Convert the value into byte (signed 8 bits). The conversion may result in
    * a loss of precision.
    * 
    * @return an equivalent byte value.
    */
   public final byte byteValue()
   {
      return this.value;
   }

   /**
    * Convert the value into integer (signed 32 bits). The conversion may result
    * in a loss of precision.
    * 
    * @return an equivalent integer value.
    */
   public final int intValue()
   {
      return this.value & 0xff;
   }

   /**
    * Convert the value into long integer (signed 64 bits). The conversion may
    * result in a loss of precision.
    * 
    * @return an equivalent long integer value.
    */
   public final long longValue()
   {
      return this.value & (long) 0xff;
   }

   /**
    * Convert the value into short integer (signed 16 bits). The conversion may
    * result in a loss of precision.
    * 
    * @return an equivalent short integer value.
    */
   public final short shortValue()
   {
      return (short) (this.value & (short) 0xff);
   }

   /**
    * Convert the value into float (signed 32 bits IEEE 754). The conversion may
    * result in a loss of precision.
    * 
    * @return an equivalent float value.
    */
   public final float floatValue()
   {
      return this.shortValue();
   }

   /**
    * Convert the value into float (signed 64 bits IEEE 754). The conversion may
    * result in a loss of precision.
    * 
    * @return an equivalent double float value.
    */
   public final double doubleValue()
   {
      return this.shortValue();
   }

   /**
    * Assign a boolean value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final boolean value)
   {
      this.value = (value ? (byte) 1 : (byte) 0);
   }

   /**
    * Assign a byte value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final byte value)
   {
      this.value = value;
   }

   /**
    * Assign an int value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final int value)
   {
      this.value = (byte) (value & 0xff);
   }

   /**
    * Assign short value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final short value)
   {
      this.value = (byte) (value & 0xff);
   }

   /**
    * Assign a long value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final long value)
   {
      this.value = (byte) (value & 0xff);
   }

   /**
    * Assign a float value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final float value)
   {
      this.value = (byte) value;
   }

   /**
    * Assign a double value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final double value)
   {
      this.value = (byte) value;
   }

   /**
    * @param args the given arguments in the commad line
    */
   public static void main(final java.lang.String[] args)
   {
      final UnsignedByte ub = new UnsignedByte(82);
      final UnsignedByte ub2 = new UnsignedByte(3);
      System.out.println(ub.multiply(ub2));

      System.out.println("23 compareTo 130 = "
            + (new UnsignedByte(23)).compareTo(new UnsignedByte(130)));
      System.out.println("23 compareTo 47 = "
            + (new UnsignedByte(23)).compareTo(new UnsignedByte(47)));
      System.out.println("137 compareTo 155 = "
            + (new UnsignedByte(137)).compareTo(new UnsignedByte(155)));
      System.out.println("   0 = [" + new UnsignedByte(0) + "]");
      System.out.println(" 127 = [" + new UnsignedByte(127) + "]");
      System.out.println(" 128 = [" + new UnsignedByte(128) + "]");
      System.out.println(" 255 = [" + new UnsignedByte(255) + "]");
      System.out.println(" 256 = [" + new UnsignedByte(256) + "]");
      System.out.println("  -1 = [" + new UnsignedByte(-1) + "]");
      System.out.println("-127 = [" + new UnsignedByte(-127) + "]");
      System.out.println("-128 = [" + new UnsignedByte(-128) + "]");
      System.out.println("getFormattedString :    0 = ["
            + new UnsignedByte(0).getFormattedString(1) + "]");
      System.out.println("getFormattedString :  127 = ["
            + new UnsignedByte(127).getFormattedString(1) + "]");
      System.out.println("getFormattedString :  128 = ["
            + new UnsignedByte(128).getFormattedString(1) + "]");
      System.out.println("getFormattedString :  255 = ["
            + new UnsignedByte(255).getFormattedString(1) + "]");
      System.out.println("getFormattedString :  256 = ["
            + new UnsignedByte(256).getFormattedString(1) + "]");
      System.out.println("getFormattedString :   -1 = ["
            + new UnsignedByte(-1).getFormattedString(1) + "]");
      System.out.println("getFormattedString : -127 = ["
            + new UnsignedByte(-127).getFormattedString(1) + "]");
      System.out.println("getFormattedString : -128 = ["
            + new UnsignedByte(-128).getFormattedString(1) + "]");
   }
}
