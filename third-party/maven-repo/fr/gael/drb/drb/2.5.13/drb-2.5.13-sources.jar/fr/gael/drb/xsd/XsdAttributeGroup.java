/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbNode;
import fr.gael.drb.value.Value;

/**
 * Declaration of a general XML-Schema attribute group.
 */
public class XsdAttributeGroup extends XsdComponent
{

   // ================================================
   // Static part.
   // ================================================
   /**
    * attribute group tag.
    */
   final static String TAG = "attributeGroup";

   /**
    * name tag.
    */
   final static String NAME_TAG = "name";

   /**
    * ref tag.
    */
   final static String REF_TAG = "ref";

   // ===================================================
   // Attributes part.
   // ===================================================
   /**
    * The name of this attribute.
    */
   private String name = null;

   /**
    * The type of this attribute.
    */
   private XsdAttribute[] attribute = null;

   // ======================================================
   // Methods part.
   // ======================================================
   /**
    * Build an XML-Schema attribute group.
    * 
    * @param name The name of the attribute group
    * @param attribute The attribute
    */
   XsdAttributeGroup(final String name, final XsdAttribute[] attribute)
   {
      this.name = name;
      this.attribute = attribute;
   } // XsdAttribute

   /**
    * Returns the name of this attribute.
    * 
    * @return String The name of the attribute group
    */
   public final String getName()
   {
      return this.name;
   } // getName

   /**
    * Returns the attributes of this group.
    * 
    * @return The attributes group
    */
   public final XsdAttribute[] getContent()
   {
      return this.attribute;
   } // getContent

   /**
    * Performs an extension.
    * 
    * @param extension The extension of the attribute groups
    * @return The attributes group
    */
   XsdAttributeGroup deriveByExtension(final XsdAttributeGroup extension)
   {
      XsdAttribute[] ext_content = null;
      String derive_name = "";
      if (extension != null)
      {
         derive_name = extension.getName();
         ext_content =
            new XsdAttribute[this.attribute.length + extension.attribute.length];
         System.arraycopy(extension.attribute, 0, ext_content,
               this.attribute.length, extension.attribute.length);
      }
      else
      {
         ext_content = new XsdAttribute[this.attribute.length];
      }
      System
            .arraycopy(this.attribute, 0, ext_content, 0, this.attribute.length);
      return new XsdAttributeGroup(derive_name, ext_content);
   } // deriveByExtension

   // --------------------------------------------------------
   // XsdComponent class overloading
   // --------------------------------------------------------
   /**
    * Format this component into a string.
    * 
    * @return The node
    */
   DrbNode toNode()
   {
      return null;
   } // toNode

   // =====================================================
   // Unitary test part.
   // =====================================================
   /**
    * Makes this class runnable for testing.
    * 
    * @param args String[]
    */
   public static void main(final String[] args)
   {
      final XsdAtomicType floatType = new XsdAtomicType(Value.FLOAT_ID, null);
   } // main

} // XsdAttributeGroup
