/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import org.apache.log4j.Logger;

/**
 * Offset attribute in descriptor. This class is used to manage a offset
 * attribute
 */
final class OffsetAttribute extends LengthAttribute
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(OffsetAttribute.class);

   /**
    * Constant : Origin is "Root".
    */
   static protected final short ORIGIN_ROOT = 1;

   /**
    * Constant : ORIGIN is "Parent".
    */
   static protected final short ORIGIN_PARENT = 2;

   /**
    * Constant : ORIGIN is "Previous sibling".
    */
   static protected final short ORIGIN_PREVIOUS = 3;

   /**
    * The origin of the offset attribute.
    */
   protected short origin;

   /**
    * Builds an OffsetAttribute instance.
    */
   protected OffsetAttribute()
   {
      this(READ_WRITE);
   }

   /**
    * Builds a OffsetAttribute instance with the given value type. In case of
    * non fixed value type the map will be created.
    * 
    * @param type The type of the physical attribute value. It shall be
    *           READ_ONLY or READ_WRITE.
    */
   protected OffsetAttribute(final int type)
   {
      // Call parent constructor
      super(type);
      this.origin = ORIGIN_PREVIOUS;
   }

   /**
    * Returns the offset origin.
    * 
    * @return The type of the length attribute value. It shall be ROOT, PARENT,
    *         PREVIOUS.
    */
   protected final short getOrigin()
   {
      return this.origin;
   }

   /**
    * Sets the offset origin.
    * 
    * @param origin the origin
    */
   protected final void setOrigin(final short origin)
   {
      this.origin = origin;
   }

   /**
    * Prints info into a string.
    * 
    * @return String
    */
   public String toString()
   {
      // Local declarations
      String tmpStr;

      switch (this.accessType)
      {
         case FIXED:
            tmpStr = "access=READ_ONLY";
            break;
         case VARIABLE:
            tmpStr = "access=READ_WRITE";
            break;
         default:
            tmpStr = "access=INVALID (" + this.accessType + ")";
            break;
      }

      if (this.unit == UNIT_BIT)
      {
         tmpStr = tmpStr + " unit=bit";
      }
      else if (this.unit == UNIT_BYTE)
      {
         tmpStr = tmpStr + " unit=byte";
      }

      switch (this.occurrenceType)
      {
         case SINGLE:
            tmpStr += " occurs=SINGLE " + this.map;
            break;
         case MULTIPLE:
            tmpStr += " occurs=MULTIPLE " + this.map;
            break;
         default:
            tmpStr += " occurs=INVALID (" + this.occurrenceType + ")";
            break;
      }

      switch (this.origin)
      {
         case ORIGIN_ROOT:
            tmpStr = tmpStr + " origin=ROOT";
            break;
         case ORIGIN_PREVIOUS:
            tmpStr = tmpStr + " origin=PREVIOUS";
            break;
         case ORIGIN_PARENT:
            tmpStr = tmpStr + " origin=PARENT";
            break;
      }
      // Return info string
      return "{" + tmpStr + "}";
   }
} // OffsetAttribute
