/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.value.Value;

/**
 * Declaration of an XML-Schema atomic type.
 */
public class XsdAtomicType extends XsdSimpleType
{
   // =======================================================
   // Static part.
   // =======================================================
   /**
    * XML Schema's boolean type
    */
   final static String BOOLEAN_TAG = "boolean";

   /**
    * XML Schema's byte type
    */
   final static String BYTE_TAG = "byte";

   /**
    * XML Schema's unsignedByte type
    */
   final static String UNSIGNED_BYTE_TAG = "unsignedByte";

   /**
    * XML Schema's short type
    */
   final static String SHORT_TAG = "short";

   /**
    * XML Schema's unsignedShort type
    */
   final static String UNSIGNED_SHORT_TAG = "unsignedShort";

   /**
    * XML Schema's int type
    */
   final static String INT_TAG = "int";

   /**
    * XML Schema's unsignedInt type
    */
   final static String UNSIGNED_INT_TAG = "unsignedInt";

   /**
    * XML Schema's long type
    */
   final static String LONG_TAG = "long";

   /**
    * XML Schema's unsignedLong type
    */
   final static String UNSIGNED_LONG_TAG = "unsignedLong";

   /**
    * XML Schema's int type
    */
   final static String INTEGER_TAG = "integer";

   /**
    * XML Schema's unsignedInteger type
    */
   final static String UNSIGNED_INTEGER_TAG = "unsignedInteger";

   /**
    * XML Schema's nonNegativeInteger type
    */
   final static String NON_NEGATIVE_INTEGER_TAG = "nonNegativeInteger";

   /**
    * XML Schema's positiveInteger type
    */
   final static String POSITIVE_INTEGER_TAG = "positiveInteger";

   /**
    * XML Schema's nonPositiveInteger type
    */
   final static String NON_POSITIVE_INTEGER_TAG = "nonPositiveInteger";

   /**
    * XML Schema's negativeInteger type
    */
   final static String NEGATIVE_INTEGER_TAG = "negativeInteger";

   /**
    * XML Schema's float type
    */
   final static String FLOAT_TAG = "float";

   /**
    * XML Schema's double type
    */
   final static String DOUBLE_TAG = "double";

   /**
    * XML Schema's decimal type
    */
   final static String DECIMAL_TAG = "decimal";

   /**
    * XML Schema's string type
    */
   final static String STRING_TAG = "string";

   /**
    * XML Schema's dateTime type
    */
   final static String DATE_TIME_TAG = "dateTime";

   /**
    * XML Schema's duration type
    */
   final static String DURATION_TAG = "duration";

   /**
    * XML Schema's anyURI type
    */
   final static String ANY_URI_TAG = "anyURI";

   /**
    * XML Schema's date type
    */
   final static String DATE_TAG = "date";

   // =========================================================
   // Attributes part.
   // =========================================================

   /**
    * Primitive of this atomic type.
    */
   protected int primitive;

   /**
    * The bounded fundamental facet.
    */
   private boolean bounded;

   /**
    * The ordered fundamental facet.
    */
   private boolean ordered;

   /**
    * The order-relation fundamental facet.
    */
   private int orderRelation;

   /**
    * The numeric fundamental facet.
    */
   private boolean numeric;

   /**
    * The cardinality fundamental facet.
    */
   private int cardinality;

   /**
    * The inclusive lower bound.
    */
   private Value inclusiveLowerBound;

   /**
    * The inclusive upper bound.
    */
   private Value inclusiveUpperBound;

   /**
    * The value space.
    */
   private XsdValueSpace valueSpace;

   // =========================================================
   // Methods part.
   // =========================================================
   /**
    * Build an XsdAtomicType from a primitive.
    * 
    * @param primitive The primitif type
    */
   public XsdAtomicType(final int primitive)
   {
      this.init(primitive);
      this.facets = new XsdFacet[] {};
   } // XsdAtomicType

   /**
    * Initialize an XsdAtomicType from a primitive.
    * 
    * @param primitive The primitif type
    */
   protected void init(final int primitive)
   {
      this.primitive = primitive;
      this.valueSpace = this;
      switch (primitive)
      {
         case Value.BOOLEAN_ID:
            this.name = BOOLEAN_TAG;
            this.ordered = false;
            this.orderRelation = XsdValueSpace.UNDEFINED;
            this.bounded = false;
            this.cardinality = XsdValueSpace.FINITE;
            break;
         case Value.BYTE_ID:
            this.name = BYTE_TAG;
            this.ordered = true;
            this.orderRelation = XsdValueSpace.TOTAL;
            this.bounded = true;
            this.numeric = true;
            this.cardinality = XsdValueSpace.FINITE;
            this.inclusiveLowerBound = new fr.gael.drb.value.Byte(-128);
            this.inclusiveUpperBound = new fr.gael.drb.value.Byte(127);
            break;
         case Value.UNSIGNED_BYTE_ID:
            this.name = UNSIGNED_BYTE_TAG;
            this.ordered = true;
            this.orderRelation = XsdValueSpace.TOTAL;
            this.bounded = true;
            this.numeric = true;
            this.cardinality = XsdValueSpace.FINITE;
            this.inclusiveLowerBound = new fr.gael.drb.value.UnsignedByte(0);
            this.inclusiveUpperBound = new fr.gael.drb.value.UnsignedByte(255);
            break;
         case Value.SHORT_ID:
            this.name = SHORT_TAG;
            this.ordered = true;
            this.orderRelation = XsdValueSpace.TOTAL;
            this.bounded = true;
            this.numeric = true;
            this.cardinality = XsdValueSpace.FINITE;
            this.inclusiveLowerBound = new fr.gael.drb.value.Short(-32768);
            this.inclusiveUpperBound = new fr.gael.drb.value.Short(32767);
            break;
         case Value.UNSIGNED_SHORT_ID:
            this.name = UNSIGNED_SHORT_TAG;
            this.ordered = true;
            this.orderRelation = XsdValueSpace.TOTAL;
            this.bounded = true;
            this.numeric = true;
            this.cardinality = XsdValueSpace.FINITE;
            this.inclusiveLowerBound = new fr.gael.drb.value.UnsignedShort(0);
            this.inclusiveUpperBound =
               new fr.gael.drb.value.UnsignedShort(65535);
            break;
         case Value.INT_ID:
            this.name = INT_TAG;
            this.ordered = true;
            this.orderRelation = XsdValueSpace.TOTAL;
            this.bounded = true;
            this.numeric = true;
            this.cardinality = XsdValueSpace.FINITE;
            this.inclusiveLowerBound = new fr.gael.drb.value.Int(-2147483648);
            this.inclusiveUpperBound = new fr.gael.drb.value.Int(2147483647);
            break;
         case Value.UNSIGNED_INT_ID:
            this.name = UNSIGNED_INT_TAG;
            this.ordered = true;
            this.orderRelation = XsdValueSpace.TOTAL;
            this.bounded = true;
            this.numeric = true;
            this.cardinality = XsdValueSpace.FINITE;
            this.inclusiveLowerBound = new fr.gael.drb.value.UnsignedInt(0);
            this.inclusiveUpperBound =
               new fr.gael.drb.value.UnsignedInt(0xffffffff);
            break;
         case Value.LONG_ID:
            this.name = LONG_TAG;
            this.ordered = true;
            this.orderRelation = XsdValueSpace.TOTAL;
            this.bounded = true;
            this.numeric = true;
            this.cardinality = XsdValueSpace.FINITE;
            this.inclusiveLowerBound =
               new fr.gael.drb.value.Long(-9223372036854775808L);
            this.inclusiveUpperBound =
               new fr.gael.drb.value.Long(9223372036854775807L);
            break;
         case Value.UNSIGNED_LONG_ID:
            this.name = UNSIGNED_LONG_TAG;
            this.ordered = true;
            this.orderRelation = XsdValueSpace.TOTAL;
            this.bounded = true;
            this.numeric = true;
            this.cardinality = XsdValueSpace.FINITE;
            this.inclusiveLowerBound = new fr.gael.drb.value.UnsignedLong(0L);
            this.inclusiveUpperBound =
               new fr.gael.drb.value.UnsignedLong(0xffffffffffffffffL);
            break;
         case Value.INTEGER_ID:
            this.name = INTEGER_TAG;
            this.ordered = true;
            this.orderRelation = XsdValueSpace.TOTAL;
            this.bounded = false;
            this.numeric = true;
            this.cardinality = XsdValueSpace.COUNTABLY_INFINITE;
            break;
         case Value.FLOAT_ID:
            this.name = FLOAT_TAG;
            this.ordered = true;
            this.orderRelation = XsdValueSpace.TOTAL;
            this.bounded = true;
            this.numeric = true;
            this.cardinality = XsdValueSpace.FINITE;
            this.inclusiveLowerBound =
               new fr.gael.drb.value.Float(-Float.MAX_VALUE);
            this.inclusiveUpperBound =
               new fr.gael.drb.value.Float(Float.MAX_VALUE);
            break;
         case Value.DOUBLE_ID:
            this.name = DOUBLE_TAG;
            this.ordered = true;
            this.orderRelation = XsdValueSpace.TOTAL;
            this.bounded = true;
            this.numeric = true;
            this.cardinality = XsdValueSpace.FINITE;
            this.inclusiveLowerBound =
               new fr.gael.drb.value.Double(-Double.MAX_VALUE);
            this.inclusiveUpperBound =
               new fr.gael.drb.value.Double(Double.MAX_VALUE);
            break;
         case Value.DECIMAL_ID:
            this.name = DECIMAL_TAG;
            this.ordered = true;
            this.orderRelation = XsdValueSpace.TOTAL;
            this.bounded = false;
            this.numeric = true;
            this.cardinality = XsdValueSpace.COUNTABLY_INFINITE;
            break;
         case Value.STRING_ID:
            this.name = STRING_TAG;
            this.ordered = false;
            this.orderRelation = XsdValueSpace.UNDEFINED;
            this.bounded = false;
            this.numeric = false;
            this.cardinality = XsdValueSpace.COUNTABLY_INFINITE;
            break;
         case Value.DATE_ID:
            this.name = DATE_TIME_TAG;
            this.ordered = true;
            this.orderRelation = XsdValueSpace.PARTIAL;
            this.bounded = false;
            this.numeric = false;
            this.cardinality = XsdValueSpace.COUNTABLY_INFINITE;
            break;
         case Value.DURATION_ID:
            this.name = DURATION_TAG;
            this.ordered = true;
            this.orderRelation = XsdValueSpace.PARTIAL;
            this.bounded = false;
            this.numeric = false;
            this.cardinality = XsdValueSpace.COUNTABLY_INFINITE;
            break;

         case Value.UNKNOWN_ID:
            this.name = "anySimpleType";
            this.ordered = false;
            this.orderRelation = XsdValueSpace.UNDEFINED;
            this.bounded = false;
            this.numeric = false;
            this.cardinality = XsdValueSpace.COUNTABLY_INFINITE;
            break;
      }
   } // init

   /**
    * Build an XsdAtomicType from a primitive.
    * 
    * @param primitive The primitif type
    * @param facets The facets
    */
   XsdAtomicType(final int primitive, final XsdFacet[] facets)
   {
      this(null, primitive, facets);
   } // XsdAtomicType

   /**
    * Build an XsdAtomicType from a primitive.
    * 
    * @param name The name of the type
    * @param primitive The primitif type
    * @param facets The facets
    */
   XsdAtomicType(final String name, final int primitive, final XsdFacet[] facets)
   {
      this(name, new XsdAtomicType(primitive), facets);
   } // XsdAtomicType

   /**
    * Build an XsdAtomicType.
    * 
    * @param name The name of the type
    * @param base_type The atomic type
    * @param facets The facets
    */
   XsdAtomicType(final String name, final XsdAtomicType base_type,
         XsdFacet[] facets)
   {
      if (facets == null)
      {
         facets = new XsdFacet[] {};
      }

      this.name = name;
      this.primitive = base_type.getTypeId();
      this.facets = facets;
      this.base = base_type;
      this.valueSpace = base_type.valueSpace;
      final XsdFacet[] base_facets = base_type.getFacets();
      this.facets = new XsdFacet[facets.length + base_facets.length];
      System.arraycopy(base_facets, 0, this.facets, 0, base_facets.length);
      System.arraycopy(facets, 0, this.facets, base_facets.length,
            facets.length);
      // Build value space from parent
      this.ordered = base_type.isOrdered();
      this.orderRelation = base_type.getOrderRelation();
      this.bounded = base_type.isBounded();
      this.numeric = base_type.isNumeric();
      this.cardinality = base_type.getCardinality(); // TBC: use facets
      this.inclusiveLowerBound = base_type.getInclusiveLowerBound();
      this.inclusiveUpperBound = base_type.getInclusiveUpperBound();
      this.setBase(base_type);
   } // XsdAtomicType

   /**
    * Returns the variety of this simple type.
    * 
    * @return int The variety atomic type
    */
   public final int getVariety()
   {
      return XsdSimpleType.ATOMIC_VARIETY;
   } // getVariety

   /**
    * Returns the identifier of this simple type.
    * 
    * @return int The type
    */
   public int getTypeId()
   {
      return this.primitive;
   } // getTypeId

   /**
    * Create a value from a string.
    * 
    * @param text the string representation of the value.
    * @return the text converted to this value type.
    */
   public Value getValue(final String text)
   {
      return new fr.gael.drb.value.String(text).convertTo(this.primitive);
   }

   // ----------------------------------------------
   // XsdValueSpace interface implementation
   // ----------------------------------------------
   /**
    * A value space, is said to be ordered if there exists an order-relation
    * defined for that value space.
    * 
    * @return true if this value space is ordered and false otherwise.
    */
   public boolean isOrdered()
   {
      return this.ordered;
   }

   /**
    * Returns the order-relation of this value space. An order relation on a
    * value space is a mathematical relation that imposes a total order or a
    * partial order on the members of the value space
    * 
    * @see #PARTIAL
    * @see #TOTAL
    * @return the order-relation defined on that value space
    */
   public int getOrderRelation()
   {
      return this.orderRelation;
   }

   /**
    * A datatype is bounded if its value space has either an inclusive upper
    * bound or an exclusive upper bound and either an inclusive lower bound and
    * an exclusive lower bound.
    * 
    * @return true if this value space is bounded and false otherwise.
    */
   public boolean isBounded()
   {
      return this.bounded;
   }

   /**
    * Returns the inclusive lower bound.
    * 
    * @return The inclusive lower bound or null if not defined.
    */
   public Value getInclusiveLowerBound()
   {
      return this.inclusiveLowerBound;
   }

   /**
    * Returns the inclusive upper bound.
    * 
    * @return The inclusive upper bound or null if not defined.
    */
   public Value getInclusiveUpperBound()
   {
      return this.inclusiveUpperBound;
   }

   /**
    * Returns the exclusive lower bound.
    * 
    * @return The exclusive lower bound or null if not defined.
    */
   public Value getExclusiveLowerBound()
   {
      return null;
   }

   /**
    * Returns the exclusive upper bound.
    * 
    * @return The exclusive upper bound or null if not defined.
    */
   public Value getExclusiveUpperBound()
   {
      return null;
   }

   /**
    * Returns the cardinality of this value space. Every value space has
    * associated with it the concept of cardinality. Some value spaces are
    * finite, some are countably infinite while still others could conceivably
    * be uncountably infinite (although no value space defined by the XML-Schema
    * specification is uncountable infinite). A datatype is said to have the
    * cardinality of its value space.
    * 
    * @return The cardinality of this value space.
    */
   public int getCardinality()
   {
      return this.cardinality;
   }

   /**
    * A datatype is said to be numeric if its values are conceptually quantities
    * (in some mathematical number system).
    * 
    * @return true if the datatype is numeric and false otherwise
    */
   public boolean isNumeric()
   {
      return this.numeric;
   }

   // ---------------------------------------------------------
   // ValueValidator interface implementation
   // ---------------------------------------------------------

   /**
    * Validates the present value.
    * 
    * @param value the value
    * @return an error report or null.
    */
   protected boolean isValidType(final Value value)
   {
      if (value == null)
      {
         return false;
      }
      final int value_type = value.getType();

      if (value_type == this.primitive)
      {
         return true;
      }

      if (value_type == Value.ARRAY_ID)
      {
         return false;
      }

      if (value_type == Value.STRING_ID)
      {
         // Check that the lexical value of this string is valid
         // The conversion must succeed.
         try
         {
            Value v = null;
            if (this.numeric && (this.primitive != Value.FLOAT_ID)
                  && (this.primitive != Value.DOUBLE_ID)
                  && (this.primitive != Value.DECIMAL_ID))
            {
               v = value.convertTo(Value.INTEGER_ID);
            }
            else
            {
               v = value.convertTo(this.primitive);
            }
            return true;
         }
         catch (final ClassCastException e)
         {
            return false;
         }
      }

      // Case of numeric type
      if (this.numeric)
      {
         return value instanceof fr.gael.drb.value.Numeric;
      }
      // Otherwise
      return false;
   }

   /**
    * Check if this value satifies the type definition.
    * 
    * @param value The value
    * @return true if it is valid , else false
    */
   public boolean isValid(Value value)
   {
      if (value != null)
      {
         try
         {
            value = value.convertTo(this.primitive);
         }
         catch (final ClassCastException e)
         {
            return false;
         }
      }
      return super.isValid(value);
   } // isValid

   // ========================================================
   // Unitary test part.
   // ========================================================
   /**
    * Makes this class runnable for testing.
    * 
    * @param args String[]
    */
   public static void main(final String[] args)
   {
      final Value int_value = new fr.gael.drb.value.Int(9942);
      final fr.gael.drb.DrbNode int_node =
         new fr.gael.drb.DrbDefaultMutableNode("toto");
      int_node.setValue(int_value);
      final XsdSimpleType int_type =
         (XsdSimpleType) XmlSchema.getDefaultSchema().getType("int");
      System.out.println("Test 1 : ");
      fr.gael.drb.impl.xml.XmlWriter.writeXML(int_type.toNode(), System.out);
      System.out.println("Checking int_value (" + int_value + ") -> "
            + int_type.isValid(int_node));

      System.out.println("Test 2 : <xsd:simpleType name='myFloat'>");
      System.out.println("           <xsd:restriction base='xsd:float'>");
      System.out.println("             <xsd:minInclusive value='15'/>");
      System.out.println("             <xsd:maxInclusive value='25'/>");
      System.out.println("           </xsd:restriction>");
      System.out.println("         </xsd:simpleType>");

      final XsdFacet[] facets =
         new XsdFacet[] {
               new XsdMinInclusiveFacet(new fr.gael.drb.value.Float(15.0f)),
               new XsdMaxInclusiveFacet(new fr.gael.drb.value.Float(25.0f)) };
      final XsdAtomicType atomic =
         new XsdAtomicType("myFloat", Value.FLOAT_ID, facets);
      final Value float_value = new fr.gael.drb.value.Float(10.0f);
      final Value float_value2 = new fr.gael.drb.value.Float(20.0f);
      final Value float_value3 = new fr.gael.drb.value.Float(30.0f);
      final Value boolean_value = new fr.gael.drb.value.Boolean(true);

      System.out.println("Checking float_value (" + float_value + ") -> "
            + atomic.isValid(float_value));
      System.out.println("Checking float_value2 (" + float_value2 + ") -> "
            + atomic.isValid(float_value2));
      System.out.println("Checking float_value3 (" + float_value3 + ") -> "
            + atomic.isValid(float_value3));
      System.out.println("Checking boolean_value (" + boolean_value + ") -> "
            + atomic.isValid(boolean_value));

      System.out
            .println("\n\nTest 2 : <xsd:simpleType name='ProductFilename'>");
      System.out.println("           <xsd:restriction base='xsd:string'>");
      System.out.println("             <xsd:pattern value='???_???_???*.N1'/>");
      System.out.println("           </xsd:restriction>");
      System.out.println("         </xsd:simpleType>");
      final XsdFacet[] facets2 =
         new XsdFacet[] { new XsdPatternFacet("..._..._...*\\.N1") };
      final XsdAtomicType atomic2 =
         new XsdAtomicType("ProductFilename", Value.STRING_ID, facets2);
      final Value string_value = new fr.gael.drb.value.String("toto");
      final Value string_value2 =
         new fr.gael.drb.value.String(
               "MER_FR__1PTACR20000620_104323_00000099X000_00000_00000_0000.N1");
      final Value string_value3 =
         new fr.gael.drb.value.String(
               "MER_FR__1PTACR20000620_104323_00000099X000_00000_00000_0000.N2");
      System.out.println("Checking float_value (" + float_value + ") -> "
            + atomic2.isValid(float_value));
      System.out.println("Checking string_value (" + string_value + ") -> "
            + atomic2.isValid(string_value));
      System.out.println("Checking string_value (" + string_value2 + ") -> "
            + atomic2.isValid(string_value2));
      System.out.println("Checking string_value (" + string_value3 + ") -> "
            + atomic2.isValid(string_value3));
   } // main

} // XsdSimpleType
