/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import java.util.EventListener;

/**
 * Interface for listening DRB node changes. It is useful to monitor the changes
 * of a node. For instance, a node may change when any sibling, child has been
 * set or when a feature of node has been modified (e.g. its name). This
 * interface unifies the way the event are fired from the nodes to the any
 * monitoring object. It is important to keep in mind that NOT ALL the DrbNodes
 * are able to handle change events. The use of this interface is similar to the
 * listener of most of the Java API and in particular the <code>
 * TreeModelListener</code>.
 */
public interface DrbNodesChangeListener extends EventListener
{
   /**
    * Invoked after a node (or a set of siblings) has changed. The node(s) have
    * not changed locations in the tree or altered their children, but other
    * attributes have changed and may affect presentation. Example: the name of
    * a wrapped file has changed, but it is in the same location in the file
    * system.
    * 
    * @param event The event that references the changes.
    */
   void nodesChanged(DrbNodesChangeEvent event);

   /**
    * Invoked after nodes have been inserted. Only inserted elements are
    * referenced in the passed event. The parent of the inserted nodes can be
    * the source of event when only one parent is affected by the change.
    * Otherwise the parent can be retreived throught the DrbNode API of the
    * inserted nodes.
    * 
    * @param event The event that references the changes.
    */
   void nodesInserted(DrbNodesChangeEvent event);

   /**
    * Invoked after nodes have been removed. This opertation is invoked only
    * onces when a subtree has been removed and not for each node belonging to
    * this subtree. The event references the removed nodes. A special attention
    * shall be paid to these references that may have a important memory
    * footprint.
    * 
    * @param event The event that references the changes.
    */
   void nodesRemoved(DrbNodesChangeEvent event);

   /**
    * Invoked when the DRB tree structure has been drastically changed. The
    * changed nodes hold by the event are the top subtree element from which a
    * drastic change has been performed (from these nodes to there leaves).
    * 
    * @param event The event that references the changes.
    */
   void structureChanged(DrbNodesChangeEvent event);
}// DrbNodesChangeListener
