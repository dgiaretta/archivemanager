/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.value.Value;

/**
 * Wraps an Replace expression of XQuery Update Facility. The if expression
 * implement the DO/INSERT updating expression of the XQuery Update Facility.
 * This expression matches :
 * <p>
 * <code>
 * <Do> <Replace> <Expr> <With> <Expr>
 * </code>
 * </p>
 * <p>
 * The expression following the replace keyword is called the source expression,
 * and the expressions following the into keyword is called the target
 * expression.
 * </p>
 */
class ReplaceExpression extends AbstractExpression
{
   /**
    * The source expression. The source expression cannot be null. The
    * evaluation of this expression provides the node to replaceed.
    */
   private Expression sourceExpression = null;

   /**
    * The target expression. This expression cannot be null. The evaluation of
    * this expression provides the target node.
    */
   private Expression targetExpression = null;

   /**
    * The replace mode (value or content). This flag specify wether the updating
    * expression shall replace a node or the value of a node.
    */
   private boolean valueSpecified = false;

   /**
    * Builds an instance of the ReplaceExpression. The underlying expression
    * (i.e. source, target) are reset to null.
    * 
    * @param token the token related to the current expression.
    */
   public ReplaceExpression(final Token token)
   {
      super("Replace", token);
   }

   /**
    * Accessor to the target expression. The parameter is not tested and the
    * reference is immeiately assigned to the target expression.
    * 
    * @param test_expression the expression to be assigned.
    */
   public void setTargetExpression(final Expression target_expression)
   {
      this.targetExpression = target_expression;
   }

   /**
    * Accessor to the sourceexpression. The parameter is not tested and the
    * reference is immediately assigned to the source expression.
    * 
    * @param source_expression the expression to be assigned.
    */
   public void setSourceExpression(final Expression source_expression)
   {
      this.sourceExpression = source_expression;
   }

   /**
    * Set the replacing mode (node or value). If "value of" is specified, a
    * replace expression is used to modify the value of a node while preserving
    * its node identity. If "value of" is not specified, a replace expression
    * replaces one node with a new sequence of zero or more nodes.
    * 
    * @param value_specified a replace expression has two forms, depending on
    *           wether "value of" is specified.
    */
   public void setValueSpecified(final boolean value_specified)
   {
      this.valueSpecified = value_specified;
   }

   /**
    * Evaluates the replace expression. The evaluation context is used as outer
    * focus of the two underlying expressions. This means that the replace
    * expression context is used for the evaluation of the source expression as
    * well as for the target expression. The evaluation is performed as follow :
    * <p>
    * <b>Check source expression consitency:</b> before evaluating the
    * expression, the source and target expression shall not be null.
    * </p>
    * <p>
    * 
    * @param context the context to be considered during the evaluation. This
    *           parameter is mandatory so it is not controlled during the
    *           evaluation of the conditional expression. However, because it is
    *           directly used by the underlying expression a null context may
    *           raise an error if the expression requires a non null context.
    * @return the result of the evaluation of the replace expression is an empty
    *         sequence and a pending update list.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {

      DrbSequence output_sequence;
      /**
       * Checks the replace expression consitency.
       */
      if ((this.sourceExpression == null) || (this.targetExpression == null))
      {
         throw new DynamicException(this, "Incomplete \"replace\" declaration");
      }

      /**
       * Evaluates the target-expression
       */
      final DrbSequence target_sequence =
         this.targetExpression.evaluate(context);

      if (target_sequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the target expression");
      }

      if (target_sequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the target expression");
      }

      if (target_sequence.getLength() != 1)
      {
         throw new DynamicException(this,
               "First parameter must be a single element node "
                     + "or a single document node. Found a sequence of "
                     + target_sequence.getLength() + " item(s)");
      }

      final DrbItem target_item = target_sequence.getItem(0);

      /**
       * Check and process, should the occasion arise, the cancellation request.
       */
      if (this.isCancellationRequested() == true)
      {
         this.throwCancelException();
      }

      /**
       * Get the replacing sequence from parameter. This parameter is mandatory.
       */

      final DrbSequence content_sequence =
         this.sourceExpression.evaluate(context);

      if (content_sequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the content parameter");
      }

      /**
       * Update the target node.
       */
      // Case 1 : Replacing the Value of a Node
      if (this.valueSpecified)
      {
         final Value replacing_value = content_sequence.atomize();
         target_item.setValue(replacing_value);
      }
      else
      // Case 2.1 : Replacing an element node (value not specified)
      // An element node can be replaced by zero or more element nodes
      if (target_item.getItemType() == DrbItem.NODE_ITEM)
      {
         final DrbNode target_node = (DrbNode) target_item;
         final DrbNode target_parent = target_node.getParent();
         final int target_index = target_node.getIndex();

         if (target_parent == null)
         {
            throw new DynamicException(this,
                  "[XUST0001] - While replacing an element, the target node must have a parent");
         }
         if (content_sequence.getLength() == 0)
         {
            target_parent.removeChild(target_index);
         }
         else
         {
            for (int ichild = 0; ichild < content_sequence.getLength(); ichild++)
            {
               final DrbItem content_item = content_sequence.getItem(ichild);
               if (content_item instanceof DrbNode)
               {
                  if (ichild == 0)
                  {
                     target_parent.replaceChild(target_index,
                           (DrbNode) content_item);
                  }
                  else
                  {
                     target_node.insertChild((DrbNode) content_item,
                           target_index + ichild);
                  }
               }
            }
         }
      }
      else
      // Case 2.2 : Replacing an attribute node (value not specified)
      // An attribute node can be replaced by zero or more attribute nodes
      if (target_item.getItemType() == DrbItem.ATTRIBUTE_ITEM)
      {
         throw new DynamicException(this,
               "[XUST0001] - Attribute replacement is not implemented");
      }
      else
      {
         throw new DynamicException(this,
               "[XUST0001] - The target of a 'replace' expression must be a node");
      }
      /**
       * Evaluates the result (always an empty sequence).
       */
      output_sequence = new DrbDefaultSequence();

      return output_sequence;
   }

   /**
    * A expression which is constant means that it need no context item to be
    * evaluate. The returned sequence from its evaluation will always be the
    * same along the query script
    * 
    * @return true if this expression is constant
    */
   public boolean isConstant()
   {
      return false;
   }

   /**
    * Identifies expression that can modify the state of an existing node. This
    * function returns always true since 'replace' is a basic updating
    * expression.
    * 
    * @return true
    */
   public boolean isUpdating()
   {
      return true;
   }
}
