/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sdf;

import java.util.ArrayList;
import java.util.Arrays;

import org.apache.log4j.Logger;

/**
 * A map of (int[], long) key-value pairs. This class is designed to store
 * values associated to keys. Instead of a HashMap it uses an ArrayList of
 * LongMapEntry items. Using a int[] key, it is possible to retreive the
 * associated long value. For instance, this map can store the offset values
 * corresponding to several occurrences in a tree.
 */
final class LongMap
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(LongMap.class);

   /**
    * The list of items.
    */
   private ArrayList item;

   /**
    * Create a LongMap instance.
    */
   protected LongMap()
   {
      // Create the ArrayList
      this.item = new ArrayList();
   }

   /**
    * Returns the entry associated to the key. If the given key is null returns
    * null. If no entry matches the key returns null. Else returns the entry
    * associated to the key. Note: The search is in O(n*d) where n is the number
    * of elements in the map and d the depth of the structured data file tree.
    * The search is done in reverse order of the ArrayList items.
    * 
    * @param key The key from which to get the value.
    * @return The entry associated to the key.
    */
   private final LongMapEntry getEntry(final int[] key)
   {
      // Local declarations
      LongMapEntry entry;

      // Check parameter
      if (key == null)
      {
         this.logger.error("LongMap.getEntry() ERROR: " + "Invalid parameter.");
         this.logger.error("   key is null.");
         return null;
      }

      // Parse the items
      final int size = this.item.size();
      for (int i = size - 1; i >= 0; i--)
      {
         // Get the map entry
         entry = (LongMapEntry) this.item.get(i);

         // Test key equality
         if (Arrays.equals(entry.getKey(), key))
         {
            // Return the entry
            return entry;
         }
      }
      // At this step no entry matched the key
      return null;
   }

   /**
    * Returns the value associated to the key. If the given key is null returns
    * -1. If no entry matches the key returns -1. Else returns the value
    * associated to the key. Note: The search is in O(n*d) where n is the number
    * of elements in the map and d the depth of the structured data file tree.
    * The search is done in reverse order of the ArrayList items.
    * 
    * @param key The key from which to get the value.
    * @return The value associated to the key.
    */
   protected final long get(final int[] key)
   {
      // Local declarations
      LongMapEntry entry;

      // Get the related entry and return -1 in case of missing entry
      if ((entry = this.getEntry(key)) == null)
      {
         return -1;
      }

      // Return the value
      return entry.getValue();
   }

   /**
    * Adds the key-value pair map entry to the map. If the given key is null
    * nothing is added to the map. The value can be retreive later by the
    * get(key) operation.
    * 
    * @param key The key to identify the value.
    * @param value The value to add in the map.
    */
   protected final void add(final int[] key, final long value)
   {
      // Local declarations
      LongMapEntry entry;

      // Check parameter
      if (key == null)
      {
         this.logger.warn("LongMap.add() WARNING: " + "Invalid parameter.");
         this.logger.warn("   key is null, nothing added to the map.");
         return;
      }

      // Case of existing entry
      if ((entry = this.getEntry(key)) != null)
      {
         // Change the value of the existing entry
         entry.setValue(value);
      }
      // Case of new entry
      else
      {
         // Create a map entry
         entry = new LongMapEntry(key, value);

         // Add the map entry to the map
         this.item.add(entry);
      }
   }

   /**
    * Returns the number of item(s) in the map.
    * 
    * @return The number of item(s) in the map.
    */
   protected final int getSize()
   {
      return this.item.size();
   }

   /**
    * Print the map into a string. For instance it can returns "{2 [{3 41 6}
    * 50], [{1} 23]}" in case of to map entries [{3 41 6} 50] and [{1} 23].
    * 
    * @return The string containing map info.
    */
   public final String toString()
   {
      // Print the key content
      String info = "{" + this.item.size() + " ";
      for (int i = 0; i < this.item.size(); i++)
      {
         info = info + (this.item.get(i));
         if (i < this.item.size() - 1)
         {
            info = info + ", ";
         }
      }
      info = info + "}";

      // Return info string
      return info;
   }

   /**
    * Main operation used for unitary tests.
    * 
    * @param args String[]
    */
   public static void main(final String[] args)
   {
      System.out.println("\nTest part 1");
      LongMap map = new LongMap();
      map.get(null);
      map.get(new int[] {});
      System.out.println("map = " + map);
      map.add(new int[] {}, 10);
      map.add(new int[] { 1 }, 1L << 32);
      map.add(new int[] { 2 }, 20);
      map.add(new int[] { 1, 0 }, -1L << 32);
      map.add(new int[] { 1, 0, 1 }, 90);
      map.add(new int[] { 1, 0, 5 }, 340);
      System.out.println("map avant = " + map);
      System.out.println("Add sur cle existante ({1,0,5}).");
      map.add(new int[] { 1, 0, 5 }, 12);
      System.out.println("map apres = " + map);

      System.out.println("getKey() = "
            + IntMap.keyToString(((LongMapEntry) (map.item.get(5))).getKey()));

      System.out
            .println("\nparentKey({5,4,3,2}) = "
                  + IntMap.keyToString(IntMap.getParentKey(new int[] { 5, 4, 3,
                        2 })));
      System.out.println("\nchildKey({5,4,3,2},7) = "
            + IntMap.keyToString(IntMap
                  .getChildKey(new int[] { 5, 4, 3, 2 }, 7)));
      System.out.println("\nsiblingKey({5,4,3,2},7) = "
            + IntMap.keyToString(IntMap.getSiblingKey(new int[] { 5, 4, 3, 2 },
                  7)));

      if (true)
      {
         return;
      }

      // Part 2
      System.out.println("\nTest part 2");
      map = new LongMap();
      final int max = 400;
      long initTime;
      long finalTime;
      long length;

      System.out.println("Insert and get " + max + " elements");
      initTime = System.currentTimeMillis();
      for (int i = 0; i < max; i++)
      {
         map.add(new int[] { 0, i, 0, 0 }, 1000 + i);
         length = map.get(new int[] { 0, i, 0, 0 });
         System.out.println("Length = " + length);
      }
      finalTime = System.currentTimeMillis();
      System.out.println("\nMap : " + map);
      System.out.println("Total time : " + (finalTime - initTime) + " ms.");
   }
}
