/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * The YearMonthDuration class is a generic wrapper for year/month duration.
 */
public class YearMonthDuration extends AbstractValue implements Arithmetic,
      Comparison
{
   // =========================================================================
   // Attributes part.
   // =========================================================================
   /**
    * The YearMonthDuration priority.
    */
   final static int PRIORITY = 7;

   /**
    * Definition of the number of month in a year.
    */
   final static int MONTHS_PER_YEAR = 12;

   /**
    * The year/month part of this duration (in month).
    */
   protected long yearMonth;

   // =========================================================================
   // Methods part.
   // =========================================================================

   /**
    * Attempts to interpret the string s as a representation of an ISO duration.
    * The pattern is currently PnYnM or -PnYnM if the duration is negative.
    * 
    * @param a string to be parsed as a year/month duration.
    */
   // public YearMonthDuration(java.lang.String s)
   // {
   // }
   /**
    * Build a duration from a number of years and months.
    * 
    * @param year_month number of months in this duration
    * @see java.util.Date
    */
   public YearMonthDuration(final long year_month)
   {
      this.yearMonth = year_month;
   }

   /**
    * Returns the year/month part of this duration in months.
    * 
    * @return the year/month part of this duration in months
    */
   public long getYearMonth()
   {
      return this.yearMonth;
   }

   /**
    * Returns the years part of this duration.
    * 
    * @return the years part of this duration
    */
   long getYears()
   {
      return (Math.abs(this.yearMonth) / 12);
   }

   /**
    * Returns the months part of this duration.
    * 
    * @return the months parts of this duration
    */
   int getMonths()
   {
      return (int) (Math.abs(this.yearMonth) % 12);
   }

   /**
    * Return the duration in a string.
    * 
    * @return The formatted string.
    */
   public java.lang.String toString()
   {
      final java.lang.String str =
         "P" + this.getYears() + "Y" + this.getMonths() + "M";
      if (this.yearMonth < 0)
      {
         return "-" + str;
      }
      else
      {
         return str;
      }
   }

   // ----------------------------------------------------------------------
   // Value interface implementation
   // ----------------------------------------------------------------------
   /**
    * The type identifier of the value.
    * 
    * @return an identifier of the value type.
    */
   public int getType()
   {
      return Value.YEAR_MONTH_DURATION_ID;
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself should be returned. If the conversion is not allowed a
    * ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws java.lang.ClassCastException if the conversion is impossible
    */
   public Value convertTo(final int type) throws java.lang.ClassCastException
   {
      switch (type)
      {
         // YearMonthDuration -> YearMonthDuration conversion
         case Value.YEAR_MONTH_DURATION_ID:
            return this;

            // YearMonthDuration -> DayTimeDuration conversion
         case Value.DAY_TIME_DURATION_ID:
            return new DayTimeDuration((double) this.yearMonth
                  * Duration.SECONDS_PER_MONTH);

            // YearMonthDuration -> Duration conversion
         case Value.DURATION_ID:
            return new Duration(this.yearMonth, 0.0);

            // YearMonthDuration -> String conversion
         case Value.STRING_ID:
            return new String(this.toString());

            // YearMonthDuration-> Numeric conversion (in months)
         default:
            return new Long(this.yearMonth).convertTo(type);
      }
   } // convertTo

   /**
    * Assign a new Value. An implicit conversion may be performed to make the
    * assignment.
    * 
    * @param v the value to be assigned.
    */
   public void assign(final Value v)
   {
      final YearMonthDuration vd =
         (YearMonthDuration) v.convertTo(Value.YEAR_MONTH_DURATION_ID);
      this.yearMonth = vd.getYearMonth();
   }

   /**
    * The absolute priority of the value.
    * 
    * @return The value priority.
    */
   public int getPriority()
   {
      return PRIORITY;
   }

   // ---------------------------------------------------------------------
   // Sumable interface implementation
   // ---------------------------------------------------------------------
   /**
    * Compute an addition.
    * 
    * @param x another value.
    * @return the sum of the two values.
    */
   public Value add(final Value x)
   {
      final YearMonthDuration vd =
         (YearMonthDuration) (x.convertTo(Value.YEAR_MONTH_DURATION_ID));
      return new YearMonthDuration(this.getYearMonth() + vd.getYearMonth());
   }

   // ---------------------------------------------------------------------
   // Arithmetic interface implementation
   // ---------------------------------------------------------------------
   /**
    * Compute an unary minus.
    * 
    * @return The unary minus of this duration.
    */
   public Value unaryMinus()
   {
      return new YearMonthDuration(-this.getYearMonth());
   } // unaryMinus

   /**
    * Compute a substraction.
    * 
    * @param x another value.
    * @return the difference between the two duration.
    */
   public Value sub(final Value x)
   {
      final YearMonthDuration vd =
         (YearMonthDuration) (x.convertTo(Value.YEAR_MONTH_DURATION_ID));
      return new YearMonthDuration(this.getYearMonth() - vd.getYearMonth());
   } // sub

   /**
    * Compute a multiplication.
    * 
    * @param x another value.
    * @return the product of this duration by a number.
    */
   public Value multiply(final Value x)
   {
      final Numeric num = (Numeric) (x.convertTo(NUMERIC_ID));
      return new YearMonthDuration((long) (this.getYearMonth() * num
            .doubleValue()));
   } // multiply

   /**
    * Compute a division.
    * 
    * @param x another value.
    * @return the ratio of this duration by a number.
    */
   public Value divide(final Value x)
   {
      final Numeric num = (Numeric) (x.convertTo(NUMERIC_ID));
      return new YearMonthDuration((long) (this.getYearMonth() / num
            .doubleValue()));
   } // divide

   /**
    * Compute a modulus.
    * 
    * @param x another value.
    * @return the modulus of this duration by a number.
    */
   public Value modulus(final Value x)
   {
      final Numeric num = (Numeric) (x.convertTo(NUMERIC_ID));
      return new YearMonthDuration((long) (this.getYearMonth() % num
            .doubleValue()));
   } // modulus

   // ----------------------------------------------------------------------
   // Comparison interface implementation
   // ----------------------------------------------------------------------
   /**
    * Compare this value with another value.
    * 
    * @param v another value.
    * @return The returned value is :
    *         <ul>
    *         <li> negative if this value is lower than another value
    *         <li> zero if the two values are equal
    *         <li> positive if this value is greater than another value
    *         </ul>
    */
   public int compareTo(final Value v)
   {
      final YearMonthDuration vd =
         (YearMonthDuration) (v.convertTo(Value.YEAR_MONTH_DURATION_ID));
      final double diff = this.getYearMonth() - vd.getYearMonth();
      if (diff < 0.0)
      {
         return -1;
      }
      else if (diff > 0.0)
      {
         return +1;
      }
      else
      {
         return 0;
      }
   } // compareTo

   // ========================================================================
   // Unitary test part.
   // ========================================================================
   /**
    * Makes this class runnable for testing.
    * 
    * @param args the given arguements in the command line
    */
   public static void main(final java.lang.String[] args)
   {
      final fr.gael.drb.value.YearMonthDuration dur =
         new fr.gael.drb.value.YearMonthDuration(java.lang.Long
               .parseLong(args[0]));
      System.out
            .println("Test :  convert a yearMonthDuration(" + args[0] + ")");
      System.out.println("toString : " + dur.convertTo(Value.STRING_ID));

      if (args.length > 1)
      {
         System.out.println("-- CMP --");
         final fr.gael.drb.value.YearMonthDuration dur2 =
            new fr.gael.drb.value.YearMonthDuration(java.lang.Long
                  .parseLong(args[1]));
         System.out.println("'" + dur + "' compareTo '" + dur2 + " = "
               + dur.compareTo(dur2));
      }
      final java.lang.String[] dates =
         new java.lang.String[] { "01-JAN-2000 00:00:00.000000",
               "31-DEC-1999 04:00:00.004321", "01-JUL-1973 15:15:00.000937",
               "01-JAN-2002 10:30:50.876543" };

      System.out.println("-- SUM --");
      DateTime date_time1 = null;
      for (int iDate = 0; iDate < dates.length; iDate++)
      {
         date_time1 = new DateTime(dates[iDate]);
         System.out.println("'" + date_time1 + "' + '" + dur + " = "
               + date_time1.add(dur).convertTo(Value.DATE_ID));
         System.out.println("'" + date_time1 + "' - '" + dur + " = "
               + date_time1.sub(dur).convertTo(Value.DATE_ID));
      }
   } // main

}
