/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * The Byte class is a generic wrapper for byte values.
 */
public class Byte extends AbstractNumeric implements ValueFormat
{
   // =================================================
   // Attributes part.
   // =================================================
   /**
    * The Byte priority.
    */
   public final static int PRIORITY = 1;

   /**
    * The Byte value.
    */
   protected byte value;

   // ===============================================
   // Methods part.
   // ===============================================
   /**
    * Constructs a Byte object initialized to the specified byte value.
    * 
    * @param v the value of the Byte.
    */
   public Byte(final byte v)
   {
      this.value = v;
   }

   /**
    * Allocates a Byte object representing the value argument.
    * 
    * @param v the value of the Byte.
    */
   public Byte(final int v)
   {
      this.value = (byte) v;
   }

   /**
    * Returns a new String object representing the specified Byte.
    * 
    * @return a string representation of the object.
    */
   public java.lang.String toString()
   {
      return java.lang.Byte.toString(this.value);
   }

   // ------------------------------------------------
   // Value interface implementation
   // -------------------------------------------------
   // see interface Value for more information.

   /**
    * Return a string containing the value with a fixed format.
    * 
    * @param length The expected length of the output string
    * @return The formatted string.
    */
   public java.lang.String getFormattedString(final int length)
   {
      return getFormattedString(length, this.value, true);
   }

   /**
    * Return a byte buffer containing the value in a fixed format.
    * 
    * @return The formatted buffer.
    */
   public byte[] getFormattedBuffer()
   {
      return getFormattedBuffer(this.value);
   }

   /**
    * Return a string containing the passed value with a fixed format.
    * 
    * @param length The expected length of the output string
    * @param value The value to use for output string.
    * @param is_signed True if the value is signed, false if unsigned.
    * @return The formatted string.
    */
   public static java.lang.String getFormattedString(final int length,
         final byte value, final boolean is_signed)
   {
      if (is_signed)
      {
         return new java.lang.String(new java.text.DecimalFormat("+000;-000")
               .format(value));
      }
      else
      {
         return new java.lang.String(new java.text.DecimalFormat("+000;-000")
               .format((short) (value & (short) 0xff)));
      }
   }

   /**
    * Return a byte buffer containing the passed value in a fixed format.
    * 
    * @param value The value to use for output buffer.
    * @return The formatted buffer.
    */
   public static byte[] getFormattedBuffer(final byte value)
   {
      final byte[] buffer = new byte[1];
      buffer[0] = value;
      return buffer;
   }

   // --------------------------------------------------
   // Value interface implementation
   // ---------------------------------------------------
   // see interface Value for more information.
   /**
    * The type identifier of this Byte value.
    * 
    * @return an identifier of the Byte type.
    */
   public final int getType()
   {
      return Value.BYTE_ID;
   }

   /**
    * Returns the Byte priority
    * 
    * @return the Byte priority
    */
   public final int getPriority()
   {
      return PRIORITY;
   }

   /**
    * Convert this Byte value into the specified type. In case of identity
    * conversion the value itself should be returned. If the conversion is not
    * allowed a ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException is the convertion is impossible
    */
   public final Value convertTo(final int type) throws ClassCastException
   {
      switch (type)
      {
         // Byte -> Byte
         case Value.BYTE_ID:
         case Value.NUMERIC_ID:
            return this;
            // byte -> Unknown conversion
         default:
            return super.convertTo(type);
      }
   }

   /**
    * Assign a new Value. An implicit conversion may be performed to make the
    * assignment. This assignment may result in a loss of precision (ex : int to
    * double).
    * 
    * @param v the value to be assigned.
    */
   public final void assign(final Value v)
   {
      final Byte vb = (Byte) v.convertTo(Value.BYTE_ID);
      this.value = vb.byteValue();
   }

   // ----------------------------------------------------
   // Arithmetic interface implementation
   // ----------------------------------------------------
   // see interface Arithmetic for more information about these operators.
   /**
    * Compute the unary minus of this value.
    * 
    * @return The unary minus of this value.
    */
   public final Value unaryMinus()
   {
      return new Byte(-this.value);
   }

   /**
    * Compute an addition.
    * 
    * @param x another value.
    * @return the sum of the two values.
    */
   public final Value add(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).add(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final short sum = (short) (this.shortValue() + num.shortValue());
      // Check the integrety of the result
      if (sum >= -128)
      {
         if (sum < 128)
         {
            return new Byte((byte) sum);
         }
         else if (sum < 256)
         {
            return new UnsignedByte((byte) sum);
         }
      }
      // short range
      return new Short(sum);
   }

   /**
    * Compute a substraction.
    * 
    * @param x another value.
    * @return the difference between the two values.
    */
   public final Value sub(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).sub(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final short dif = (short) (this.shortValue() - num.shortValue());
      // Check the integrety of the result
      if ((dif < -128) || (dif > 255))
      {
         return new Short(dif);
      }
      if (dif < 128)
      {
         return new Byte((byte) dif);
      }
      else
      {
         return new UnsignedByte((byte) dif);
      }
   }

   /**
    * Compute a multiplication.
    * 
    * @param x another value.
    * @return the product of the two values.
    */
   public final Value multiply(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).multiply(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final short prod = (short) (this.shortValue() * num.shortValue());
      // Check the integrety of the result
      if ((prod < -128) || (prod > 255))
      {
         return new Short(prod);
      }
      if (prod < 128)
      {
         return new Byte((byte) prod);
      }
      else
      {
         return new UnsignedByte((byte) prod);
      }
   }

   /**
    * Compute a division.
    * 
    * @param x another value.
    * @return the ratio of the two values.
    */
   public final Value divide(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).divide(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final short div = (short) (this.shortValue() / num.shortValue());
      // Check the integrety of the result
      if ((div < -128) || (div > 255))
      {
         return new Short(div);
      }
      if (div < 128)
      {
         return new Byte((byte) div);
      }
      else
      {
         return new UnsignedByte((byte) div);
      }
   }

   /**
    * Compute a modulus.
    * 
    * @param x another value.
    * @return the modulus of the values.
    */
   public final Value modulus(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).modulus(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final short mod = (short) (this.shortValue() % num.shortValue());
      // Check the integrety of the result
      if ((mod < -128) || (mod > 255))
      {
         return new Short(mod);
      }
      if (mod < 128)
      {
         return new Byte((byte) mod);
      }
      else
      {
         return new UnsignedByte((byte) mod);
      }
   }

   // -------------------------------------------------------
   // Comparison interface implementation
   // -------------------------------------------------------
   // see interface Comparison for more information.
   /**
    * Compare this value with another value.
    * 
    * @param x another value.
    * @return The returned value is :
    *         <ul>
    *         <li>negative if this value is lower than another value</li>
    *         <li>zero if the two values are equal</li>
    *         <li>positive if this value is greater than another value</li>
    *         </ul>
    */
   public int compareTo(Value x)
   {
      if (this.getPriority() >= x.getPriority())
      {
         x = x.convertTo(Value.NUMERIC_ID);

         return (this.intValue() - ((Numeric) x).intValue());
      }

      return -((Comparison) x).compareTo(this);
   }

   // --------------------------------------------------
   // Logic interface implementation
   // -------------------------------------------------
   // see interface Logic for more information about these operators.

   /**
    * Returns this value as a boolean
    * 
    * @return the numeric value represented by this object after conversion to
    *         type boolean.
    */
   public final boolean booleanValue()
   {
      return (this.value != 0);
   }

   // -------------------------------------------------------
   // Numeric interface implementation
   // -------------------------------------------------
   /**
    * Convert the value into byte (signed 8 bits). The conversion may result in
    * a loss of precision.
    * 
    * @return an equivalent byte value.
    */
   public final byte byteValue()
   {
      return this.value;
   }

   /**
    * Convert the value into integer (signed 32 bits). The conversion may result
    * in a loss of precision.
    * 
    * @return an equivalent integer value.
    */
   public final int intValue()
   {
      return this.value;
   }

   /**
    * Convert the value into long integer (signed 64 bits). The conversion may
    * result in a loss of precision.
    * 
    * @return an equivalent long integer value.
    */
   public final long longValue()
   {
      return this.value;
   }

   /**
    * Convert the value into short integer (signed 16 bits). The conversion may
    * result in a loss of precision.
    * 
    * @return an equivalent short integer value.
    */
   public final short shortValue()
   {
      return this.value;
   }

   /**
    * Convert the value into float (signed 32 bits IEEE 754). The conversion may
    * result in a loss of precision.
    * 
    * @return an equivalent float value.
    */
   public final float floatValue()
   {
      return this.value;
   }

   /**
    * Convert the value into float (signed 64 bits IEEE 754). The conversion may
    * result in a loss of precision.
    * 
    * @return an equivalent double float value.
    */
   public final double doubleValue()
   {
      return this.value;
   }

   /**
    * Assign a boolean value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final boolean value)
   {
      this.value = (value ? (byte) 1 : (byte) 0);
   }

   /**
    * Assign a byte value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final byte value)
   {
      this.value = value;
   }

   /**
    * Assign an int value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final int value)
   {
      this.value = (byte) value;
   }

   /**
    * Assign short value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final short value)
   {
      this.value = (byte) value;
   }

   /**
    * Assign a long value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final long value)
   {
      this.value = (byte) value;
   }

   /**
    * Assign a float value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final float value)
   {
      this.value = (byte) value;
   }

   /**
    * Assign a double value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final double value)
   {
      this.value = (byte) value;
   }

   /**
    * main
    * 
    * @param args strng[]
    */
   public static void main(final java.lang.String[] args)
   {
      final Byte ub = new Byte(127);
      final UnsignedByte ub2 = new UnsignedByte(255);
      System.out.println(ub.add(ub2));
      System.out.println("toString(127) : [" + new Byte(127) + "]");
      System.out.println("toString(-128): [" + new Byte(-128) + "]");
      System.out.println("toString(0)   : [" + new Byte(0) + "]");
      System.out.println("toString(-5)  : [" + new Byte(-5) + "]");
   }
}
