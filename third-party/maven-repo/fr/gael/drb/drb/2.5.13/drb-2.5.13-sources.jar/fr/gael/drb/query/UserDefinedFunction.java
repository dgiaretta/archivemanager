/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.util.List;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbSequence;

/**
 * Function declaration of XQuery language.
 */
class UserDefinedFunction extends Function
{
   /**
    * A logger for this class.
    */
   private Logger logger = Logger.getLogger(UserDefinedFunction.class);

   /**
    * Function body.
    */
   private Expression body;

   /**
    * True if a parameter warning message has already been printed: false
    * otherwise. The warning message deals with current type error tolerance
    * observed for backward compatibility purpose.
    */
   private static boolean isParameterTypeExpectionWarningPrinted = false;

   /**
    * True if a return type warning message has already been printed: false
    * otherwise. The warning message deals with current type error tolerance
    * observed for backward compatibility purpose.
    */
   private static boolean isReturnTypeExpectionWarningPrinted = false;

   /**
    * Complete constructor of a function.
    * 
    * @param signature the function signature.
    */
   protected UserDefinedFunction(final FunctionSignature signature)
   {
      super(signature);
   }

   /**
    * Complete constructor of a function.
    * 
    * @param name string form of the function qualified name.
    * @param updating updating
    */
   protected UserDefinedFunction(final QName name, final boolean updating)
   {
      this(new FunctionSignature(name, new SequenceType(), updating));
   }

   /**
    * Returns the expression defining the value of the function.
    * 
    * @return the bound expression.
    */
   protected Expression getExpression()
   {
      return this.body;
   }

   /**
    * Assign an expression to the function.
    * 
    * @param expression the expression to be bound.
    */
   protected void setExpression(final Expression expression)
   {
      this.body = expression;
   }

   /**
    * Returns the value of the function.
    * 
    * @param context a dynamic context not considered in this implementation.
    * @param values the values of the parameter list.
    * @return the value of the function.
    */
   public DrbSequence evaluate(final DynamicContext context,
      final List<DrbSequence> values)
   {
      /**
       * Creates a inner context.
       */
      final DynamicContext innerContext = new DynamicContext(context);

      /**
       * Check arity of the parameters.
       */
      if (values.size() != this.getArity())
      {
         throw new DynamicException(this.body,
            "XP0017 - Invalid arity of function \"" +
            this.getName() + "\" parameters (maximum expected: "
                  + this.getArity() + ", provided: " + values.size() + ")");
      }

      /**
       * Bind the variables for each parameter in the inner context.
       */
      for (int iparam = 0; iparam < values.size(); iparam++)
      {
         try
         {
            final DefaultVariable variable =
               new DefaultVariable(this.getParameter(iparam), this
                  .getParameterType(iparam), values.get(iparam));

            innerContext.addInScopeVariable(variable);
         }
         catch (TypeCastException e)
         {
            TypeException type_exception =
               new TypeException(this.getExpression(),
                  "Cannot convert the parameter \"" + this.getParameter(iparam)
                        + "\" of function \"" + this.getName() + "\" to "
                        + getParameterType(iparam) + ": given value is \""
                        + values.get(iparam) + "\"");
            
            if (!context.isBackwardCompatibilityMode())
            {
               throw type_exception;
            }

            this.logger.error("Type Exception: " + type_exception.getMessage());

            if (!UserDefinedFunction.isParameterTypeExpectionWarningPrinted)
            {
               this.logger.warn("Previous parameter type error did not "
                  + "interrupt the evaluation because the backward "
                  + "compatibility mode has been set. This compatibility may "
                  + "be disrupted in any future version so users are strongly "
                  + "invited to update their XQuery scripts to comply the W3C "
                  + "recommendation c.f. "
                  + "http://www.w3.org/TR/2007/REC-xquery-20070123"
                  + " (This message will not be repeated in this session).");

               UserDefinedFunction.isParameterTypeExpectionWarningPrinted = true;
            }

            final DefaultVariable variable =
               new DefaultVariable(this.getParameter(iparam), null, values
                  .get(iparam));

            innerContext.addInScopeVariable(variable);
         }
      }

      /**
       * Evaluates and return the value of the function.
       */
      DrbSequence result = this.body.evaluate(innerContext);
      try
      {
         return getReturnType().convert(result);
      }
      catch (TypeCastException e)
      {
         TypeException type_exception =
            new TypeException(this.getExpression(),
               "Cannot convert the result of function \"" + this.getName()
                     + "\" to return type " + getReturnType() + " ("
                     + e.getMessage() + ")");
         
         if (!context.isBackwardCompatibilityMode())
         {
            throw type_exception;
         }

         this.logger.error("Type Exception: " + type_exception.getMessage());

         if (!UserDefinedFunction.isReturnTypeExpectionWarningPrinted)
         {
            this.logger.warn("Previous return type error did not "
               + "interrupt the evaluation because the backward "
               + "compatibility mode has been set. This compatibility may "
               + "be disrupted in any future version so users are strongly "
               + "invited to update their XQuery scripts to comply the W3C "
               + "recommendation c.f. "
               + "http://www.w3.org/TR/2007/REC-xquery-20070123"
               + " (This message will not be repeated in this session).");

            UserDefinedFunction.isReturnTypeExpectionWarningPrinted = true;
         }

         return result;
      }
   }
}
