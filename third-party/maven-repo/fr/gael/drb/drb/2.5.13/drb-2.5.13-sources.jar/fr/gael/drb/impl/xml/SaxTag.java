/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.xml;

import org.apache.log4j.Logger;

/**
 * SAX Tag implementation.
 */
class SaxTag
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(SaxTag.class);

   /**
    * Index of the node in its parent children list. Because a node may have no
    * parent, this index is defaulted to 0.
    */
   protected int index = -1;

   /**
    * The node kind (see DOM).
    */
   protected short nodeKind = -1;

   /**
    * The start offset in the input stream.
    */
   protected long startOffset = -1;

   /**
    * The end offset in the input stream.
    */
   protected long endOffset = -1;

   /**
    * Move the tag to a position.
    * 
    * @param pos the absolute offset in bytes.
    */
   protected void moveTo(final long pos)
   {
      final long diffOffset = pos - this.startOffset;
      this.startOffset = pos;
      this.endOffset += diffOffset;
   }
} // SaxTag
