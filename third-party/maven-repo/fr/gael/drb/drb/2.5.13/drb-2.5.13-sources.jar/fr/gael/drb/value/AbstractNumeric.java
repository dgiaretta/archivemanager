/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * Generic value wrapper.
 */
abstract class AbstractNumeric extends AbstractValue implements Numeric,
      Comparable
{

   /**
    * The type identifier of the value.
    * 
    * @return an identifier of the value type.
    */
   public int getType()
   {
      return NUMERIC_ID;
   }

   /**
    * Indicates whether this value is "equal to" to another value. See
    * Object.equals() for the general contract of this method.
    * 
    * @param obj another value.
    * @return true if this object is the same as the obj argument
    */
   public boolean equals(final Object obj)
   {
      // Check reference equality
      if (this == obj)
      {
         return true;
      }
      // Check value equality if possible
      if (obj instanceof Value)
      {
         return this.compareTo((Value) obj) == 0;
      }
      // Otherwise the object is different
      return false;
   }

   /**
    * Returns a hash code value for the object. See Object.hashCode() for the
    * general contract of this method.
    * 
    * @return a hash code value for this object.
    */
   public int hashCode()
   {
      return this.intValue();
   }

   /**
    * Compares this object with the specified object for order. See
    * Comparable.compareTo() for the general contract of this method.
    * 
    * @param obj the Object to be compared.
    * @return a negative integer, zero, or a positive integer as this object is
    *         less than, equal to, or greater than the specified object.
    */
   public int compareTo(final Object obj)
   {
      // This code will throw an exception if the object is not an instance of
      // Value
      return this.compareTo((Value) obj);
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself should be returned. If the conversion is not allowed a
    * ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws java.lang.ClassCastException is the convertion is impossible
    */
   public Value convertTo(final int type) throws java.lang.ClassCastException
   {
      switch (type)
      {
         // Numeric -> Numeric conversion
         case Value.NUMERIC_ID:
            return this;

            // Numeric -> Int conversion
         case Value.INT_ID:
            return new Int(this.intValue());

            // Numeric -> Double conversion
         case Value.DOUBLE_ID:
            return new Double(this.doubleValue());

            // Numeric -> String conversion
         case Value.STRING_ID:
            return new String(this.toString());

            // Numeric -> Float conversion
         case Value.FLOAT_ID:
            return new Float(this.floatValue());

            // Numeric -> Long conversion
         case Value.LONG_ID:
            return new Long(this.longValue());

            // Numeric -> Short conversion
         case Value.SHORT_ID:
            return new Short(this.shortValue());

            // Numeric -> Byte conversion
         case Value.BYTE_ID:
            return new Byte(this.byteValue());

            // Numeric -> Boolean conversion
         case Value.BOOLEAN_ID:
            return new fr.gael.drb.value.Boolean(this.booleanValue());

            // Numeric -> UnsignedLong conversion
         case Value.UNSIGNED_LONG_ID:
            return new UnsignedLong(this.longValue());

            // Numeric -> UnsignedInteger conversion
         case Value.UNSIGNED_INT_ID:
            return new UnsignedInt(this.intValue());

            // Numeric -> UnsignedShort conversion
         case Value.UNSIGNED_SHORT_ID:
            return new UnsignedShort(this.shortValue());

            // Numeric -> UnsignedByte conversion
         case Value.UNSIGNED_BYTE_ID:
            return new UnsignedByte(this.byteValue());

            // Numeric -> Integer conversion
         case Value.INTEGER_ID:
            return new Integer(this.integerValue());

            // Numeric -> Decimal conversion
         case Value.DECIMAL_ID:
            return new Decimal(this.decimalValue());

            // Numeric -> Unknown
         default:
            throw new ClassCastException(this.getClass().getName()
                  + ": cannot cast to " + type);
      }
   }

   /**
    * Convert the value into the numeric type. In case of identity conversion
    * the value itself should be returned. If the conversion is not allowed a
    * ClassCastException is thrown.
    * 
    * @return The converted value.
    * @throws java.lang.ClassCastException is the convertion is impossible
    */
   public final Numeric toNumeric() throws java.lang.ClassCastException
   {
      return this;
   }

   /**
    * Returns this value as a BigInteger. The conversion may result in a loss of
    * precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type BigInteger.
    */
   protected BigInteger integerValue()
   {
      return BigInteger.valueOf(this.longValue());
   }

   /**
    * Returns this value as a BigDecimal. The conversion may result in a loss of
    * precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type BigDecimal.
    */
   protected BigDecimal decimalValue()
   {
      return BigDecimal.valueOf(this.longValue());
   }

   // ----------------------------------------------
   // Logic interface implementation
   // --------------------------------------------
   /**
    * Compute a logical AND.
    * 
    * @param x another value.
    * @return logical AND of the two values.
    */
   public final boolean and(final Value x)
   {
      return this.booleanValue() && ((Logic) x).booleanValue();
   }

   /**
    * Compute a logical OR.
    * 
    * @param x another value.
    * @return logical OR of the two values.
    */
   public final boolean or(final Value x)
   {
      return this.booleanValue() || ((Logic) x).booleanValue();
   }

} // AbstractValue
