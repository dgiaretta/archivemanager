/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbAttributeList;

/**
 * Output of the XML-Schema attributeGroup validator.
 */
class XsdInvalidAttributeGroup extends XsdAbstractInvalid
{

   /**
    * The validated attribute list.
    */
   DrbAttributeList attribList;

   /**
    * Index of the last declaration in the attribute group
    */
   XsdAttribute stopAttribute;

   /**
    * Index of the last attribute in the attribute group
    */
   int stopIndex;

   /**
    * The simple type report
    */
   XsdInvalid simpleType = null;

   /**
    * Build an XsdInvalidAttributeGroup
    * 
    * @param node_attribs the attribute nodes
    * @param stop_attribute the last attribute
    * @param stop_index the index to stop
    */
   XsdInvalidAttributeGroup(final DrbAttributeList node_attribs,
         final XsdAttribute stop_attribute, final int stop_index)
   {
      super();
      this.attribList = node_attribs;
      this.stopAttribute = stop_attribute;
      this.stopIndex = stop_index;
   } // XsdInvalidAttributeGroup

   /**
    * Set the index (+1) of the last attribute in the attribute group.
    * 
    * @param stop_attribute the index (+1) of the last attribute in the
    *           attribute group.
    */
   void setStopAttribute(final XsdAttribute stop_attribute)
   {
      this.stopAttribute = stop_attribute;
   } // setStopAttribute

   /**
    * Set the index (+1) of the last attribute in the attribute group.
    * 
    * @param stop_index the index (+1) of the last attribute in the attribute
    *           group.
    */
   void setStopIndex(final int stop_index)
   {
      this.stopIndex = stop_index;
   } // setStopIndex

   /**
    * Replace the simple type result.
    * 
    * @param simple_type the simple type result
    */
   void setSimpleType(final XsdInvalid simple_type)
   {
      if (this.simpleType != null)
      {
         this.remove(this.simpleType);
      }
      this.simpleType = simple_type;
      if (this.simpleType != null)
      {
         this.add(this.simpleType);
      }
   } // setSimpleType

   /**
    * Returns a message describing the validation result.
    * 
    * @return a message describing the validation result
    */
   public String getMessage()
   {
      String msg = "";
      /**
       * Case of missing attributes.
       */
      if ((this.attribList == null)
            || (this.stopIndex >= this.attribList.getLength()))
      {
         if ((this.stopAttribute != null)
               && (this.stopAttribute.getUse() == XsdAttribute.REQUIRED_USE))
         {
            msg =
               "The attribute '" + this.stopAttribute.getName()
                     + "' is required.";
         }
      }
      /**
       * Case of unexpected attribute.
       */
      else if (this.stopAttribute == null)
      {
         msg =
            "Unknown attribute '"
                  + this.attribList.item(this.stopIndex).getName()
                  + "' found at index " + this.stopIndex;
      }
      /**
       * Case of prohibited attribute.
       */
      else if (this.stopAttribute.getUse() == XsdAttribute.PROHIBITED_USE)
      {
         msg =
            "The attribute '" + this.stopAttribute.getName()
                  + "' is prohibited.";
      }
      /**
       * Case of fixed attribute.
       */
      else if ((this.stopAttribute.getUse() != XsdAttribute.OPTIONAL_USE)
            && (this.stopAttribute.getValueConstraint() != null))
      {
         msg =
            "The attribute value of '" + this.stopAttribute.getName()
                  + "' shall be '"
                  + this.stopAttribute.getValueConstraint().toString() + "'";
      }
      /**
       * Case of bad attribute type.
       */
      else
      {
         msg =
            "The attribute '" + this.stopAttribute.getName()
                  + "' has a bad value.";
         if (this.simpleType != null)
         {
            msg = msg + this.simpleType.getMessage();
         }
      }
      return msg;
   } // getMessage

   /**
    * Returns the component.
    * 
    * @return the component
    */
   public XsdComponent getComponent()
   {
      return this.stopAttribute;
   } // getComponent

} // XsdInvalidAttributeGroup
