/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

import fr.gael.drb.DrbItem;

/**
 * Generic value wrapper for multiple purposes. This class allows easy
 * evaluation of various kinds of expressions :
 * <ul>
 * <li>Arithmetic Expressions</li>
 * <li>Comparison Expressions</li>
 * <li>Logical Expressions</li>
 * </ul>
 * There is no need to know the real type embedded in the value. If required an
 * implicit conversion will be performed at run-time. It is also possible to
 * perform an explicit conversion to any desired type. Each value has an unique
 * type identifier (ID) associated with it. Two value of same type must also
 * have the same ID. A range of ID defined below is reserved to identify
 * primitive. The other ID can be freely used.
 */
public interface Value extends DrbItem
{
   // -------------------------------------------------------------------------
   // Attributes part.
   // -------------------------------------------------------------------------
   /**
    * UNKNOWN value identifier.
    */
   static final int UNKNOWN_ID = -2;

   /**
    * NULL value identifier.
    */
   static final int NULL_ID = -1;

   /**
    * Boolean value identifier.
    */
   static final int BOOLEAN_ID = 0;

   /**
    * Byte value identifier.
    */
   static final int BYTE_ID = 1;

   /**
    * Short value identifier.
    */
   static final int SHORT_ID = 2;

   /**
    * Int value identifier.
    */
   static final int INT_ID = 3;

   /**
    * Long value identifier.
    */
   static final int LONG_ID = 4;

   /**
    * Float value identifier.
    */
   static final int FLOAT_ID = 5;

   /**
    * Double value identifier.
    */
   static final int DOUBLE_ID = 6;

   /**
    * String value identifier.
    */
   static final int STRING_ID = 7;

   /**
    * Date value identifier.
    */
   static final int DATE_ID = 8;

   /**
    * Numeric value identifier.
    */
   static final int NUMERIC_ID = 9;

   /**
    * Array value identifier.
    */
   static final int ARRAY_ID = 10;

   /**
    * BinaryInteger value identifier.
    */
   static final int BINARY_INTEGER_ID = 11;

   /**
    * UnsignedByte value identifier.
    */
   static final int UNSIGNED_BYTE_ID = 12;

   /**
    * UnsignedShort value identifier.
    */
   static final int UNSIGNED_SHORT_ID = 13;

   /**
    * UnsignedInt value identifier.
    */
   static final int UNSIGNED_INT_ID = 14;

   /**
    * UnsignedLong value identifier.
    */
   static final int UNSIGNED_LONG_ID = 15;

   /**
    * Duration value identifier.
    */
   static final int DURATION_ID = 16;

   /**
    * Day/Time duration value identifier.
    */
   static final int DAY_TIME_DURATION_ID = 17;

   /**
    * Year/Month duration value identifier.
    */
   static final int YEAR_MONTH_DURATION_ID = 18;

   /**
    * Year value identifier.
    */
   static final int YEAR_ID = 19;

   /**
    * Year/Month value identifier.
    */
   static final int YEAR_MONTH_ID = 20;

   /**
    * Month value identifier.
    */
   static final int MONTH_ID = 21;

   /**
    * Month/Day value identifier.
    */
   static final int MONTH_DAY_ID = 22;

   /**
    * Day value identifier.
    */
   static final int DAY_ID = 23;

   /**
    * Date/Time value identifier.
    */
   static final int DATE_TIME_ID = 24;

   /**
    * Time value identifier.
    */
   static final int TIME_ID = 25;

   /**
    * Decimal value identifier.
    */
   static final int DECIMAL_ID = 26;

   /**
    * Integer value identifier.
    */
   static final int INTEGER_ID = 27;

   /**
    * Binary value identifier.
    */
   static final int BINARY_ID = 28;

   /**
    * Other value identifier.
    */
   static final int OTHER_ID = 100;

   // --------------------------------------------------------------------------
   // Methods part.
   // --------------------------------------------------------------------------
   /**
    * The type identifier of the value.
    * 
    * @return an identifier of the value type.
    */
   int getType();

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself should be returned. If the conversion is not allowed a
    * ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws java.lang.ClassCastException the exception
    */
   Value convertTo(int type) throws java.lang.ClassCastException;

   /**
    * Convert the value into the numeric type. In case of identity conversion
    * the value itself should be returned. If the conversion is not allowed a
    * ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    */
   // Numeric toNumeric() throws java.lang.ClassCastException;
   /**
    * Assign a new Value. An implicit conversion may be performed to make the
    * assignment. This assignment may result in a loss of precision (ex : float
    * to int).
    * 
    * @param v the value to be assigned.
    */
   void assign(Value v);

   /**
    * The absolute priority of the value.
    * 
    * @return The value priority.
    */
   int getPriority();

   /**
    * Check if the value is equal to another value.
    * 
    * @param v another value.
    */
   // boolean equals(Value v);
}
