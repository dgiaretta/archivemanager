/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

/**
 * Abstract attribute implementation. This class is a convenient class that
 * implements the DrbAttribute interface.
 */
public abstract class DrbAbstractAttribute implements DrbAttribute
{
   /**
    * A code representing the type of the underlying object, as defined above.
    * 
    * @return The code of this item.
    */
   public int getItemType()
   {
      return ATTRIBUTE_ITEM;
   }

   /**
    * Returns a description of the current attribute. The output format is : "@"
    * <name> "=" <value> .
    * 
    * @return the description of the attribute.
    */
   public String toString()
   {
      return "@" + this.getName() + "=" + this.getValue();
   }
} // DrbAbstractAttribute
