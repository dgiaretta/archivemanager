/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.util.Vector;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAbstractNode;
import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.value.Value;
import fr.gael.drb.value.ValueArray;
import fr.gael.drb.xsd.Namespace;

/**
 * Wraps element constructor expression of XQuery language.
 */
class ConstructorExpression extends AbstractExpression
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(ConstructorExpression.class);

   /**
    * Qualifed name of the element.
    */
   protected QName name = null;

   /**
    * Expressions producing the value and the children of the element.
    */
   protected Vector expressions = new Vector();

   /**
    * Qualified name of the attributes. This list is kept up to date
    * respectively with the list of attribute expressions.
    */
   private Vector attributeNames = new Vector();

   /**
    * Lis of attribute expressions.
    */
   private Vector attributeExpressions = new Vector();

   /**
    * Declared namespaces.
    */
   protected Namespace declaredNamespaces = new Namespace();

   /**
    * Default element namespace URI. This element is not null if an "xmlns"
    * attribute has been specified in the direct element constructor
    * declaration.
    */
   String elementDefaultNamespaceURI = null;

   /**
    * say if the content will be only a concatenated string
    */
   private boolean is_string_value = false;

   /**
    * Builds an element constructor expression.
    * 
    * @param token the tolen related to the current expression.
    * @param name string form of the element qualified name.
    */
   public ConstructorExpression(final Token token, final String name)
   {
      super("Element constructor", token);
      this.name = new QName(name);
   }

   /**
    * Builds an element constructor expression.
    * 
    * @param name the name of the expression.
    * @param token the tolen related to the current expression.
    */
   public ConstructorExpression(final String name, final Token token)
   {
      super(name, token);
   }

   /**
    * Appends a child expression to the element. This expression will be
    * evaluated during the dynamic evualuation phase. The children resulting
    * from the evaluation will be collected and appended to the produced
    * element.
    * 
    * @param child_expression the expression producing children.
    */
   public void addChildExpression(final Expression child_expression)
   {
      this.expressions.add(child_expression);
   }

   /**
    * Adds an attribute definition to the element. The expression is provided as
    * a sequence of expressions due to the potentially enclosed expression
    * contained in the original XQuery script. If one item results from the
    * evaluation of the expresssion, its type is kept for the definition of the
    * constructed output attribute. Otherwise, they are converted to a string
    * that will be concatenated to form the constructed attribute value.
    * 
    * @param name the string form of the attribute qualified name.
    * @param expressions the expressions producing the attribute value.
    */
   public void addAttributeExpressions(final String name,
         final Vector expressions)
   {
      final QName attribute_name = new QName(name);

      this.attributeNames.add(attribute_name);
      this.attributeExpressions.add(expressions);
   }

   /**
    * Bind a new namespace.
    * 
    * @param prefix namespace prefix to be bound.
    * @param uri the namespace URI to bind.
    */
   public void bindNamespace(final String prefix, final String uri)
   {
      this.declaredNamespaces.bind(prefix, uri);
   }

   /**
    * Bind a namespace only if it has not been already bind by an ancestor node
    * which we know thanks to the elementNamespace variable of the context
    * 
    * @param context DynamicContext to know if the bind has not already been
    *           processed
    * @param prefix namespace prefix to be bound.
    * @param uri the namespace URI to bind.
    */
   public void bindNamespace(final DynamicContext context, final String prefix,
         final String uri)
   {

      if ((uri == null) || (prefix == null))
      {
         return;
      }

      final String element_uri =
         context.elementNamespace.resolveNamespace(prefix);

      if (element_uri != null)
      {

         if (!(element_uri.equals(uri)))
         {
            this.declaredNamespaces.bind(prefix, uri);
            context.elementNamespace.bind(prefix, uri);
         }

      }
      else
      {
         this.declaredNamespaces.bind(prefix, uri);
         context.elementNamespace.bind(prefix, uri);
      }

   }

   /**
    * Assign an element default namespace URI. This default namespace URI is to
    * be set only if an attribute default namespace URI has been set.
    * 
    * @param uri the default element/type namespace URI.
    */
   public void setElementDefaultNamespaceURI(final String uri)
   {
      this.elementDefaultNamespaceURI = uri;
   }

   /**
    * Evaluates the element contructor expression.
    * 
    * @param outer_context the dynamic evaluation context to consider.
    * @return the evaluated sequence.
    */
   public DrbSequence evaluate(final DynamicContext outer_context)
   {
      /**
       * Create an inner context.
       */
      final DynamicContext context = new DynamicContext(outer_context);

      /**
       * The output node and possible string value.
       */
      final ConstructorNode node =
         new ConstructorNode(this.name.getLocalName());

      /**
       * Bind namespaces.
       */
      final Namespace namespaces = context.getNamespace();

      if (namespaces != null)
      {
         namespaces.addNamespaces(this.declaredNamespaces);
      }
      else
      {
         context.setNamespace(this.declaredNamespaces);
      }

      context.elementNamespace.addNamespaces(this.declaredNamespaces);

      /**
       * Bind default namespace in the context.
       */
      if (this.elementDefaultNamespaceURI != null)
      {
         context.setDefaultElementNamespaceURI(this.elementDefaultNamespaceURI);
      }

      /**
       * Checking the node name (resolving its prefix if any) and augmenting in
       * scope namespaces
       */
      this.setNodeURI(context, node, this.name);

      /**
       * Processes the possible attributes of the node If there are attributes
       */
      this.processAttributes(context, node);

      /**
       * Processes the possible expressions of the node.
       */
      this.processContent(context, node);

      node.setNamespaceBindings(this.declaredNamespaces);

      return new DrbDefaultSequence(node);
   }

   /**
    * Check the prefix has been bound to an URI, if any. If any, set this
    * namespaceURI to this node and add it to the inscope namespace else set the
    * namespace URI to the defaultNamespaceURI, if any
    * 
    * @param context The dynamic context of evaluation
    * @param node The node being constructed
    * @param name The name of the node (may be provided by a name expression)
    */
   protected void setNodeURI(final DynamicContext context,
         final ConstructorNode node, final QName name)
   {

      final Namespace namespace = context.getNamespace();

      if ((name.getPrefix() == null)
            && (context.getDefaultElementNamespaceURI() != null))
      {
         /**
          * Updating inscope namespace
          */
         final String prefix =
            namespace.resolvePrefix(context.getDefaultElementNamespaceURI());
         if ((prefix != null) && !(prefix.equals("")))
         {
            this.bindNamespace(context, prefix, context
                  .getDefaultElementNamespaceURI());
         }
         node.setNamespaceURI(context.getDefaultElementNamespaceURI());

      }
      else if (name.getPrefix() != null)
      {
         final String nURI = namespace.resolveNamespace(name.getPrefix());
         if (nURI == null)
         {
            throw new DynamicException(this, "XQDY0074 - The prefix \""
                  + name.getPrefix() + "\" has not been bound.");
         }
         else
         {
            node.setNamespaceURI(nURI);

            /**
             * Also adding the namespace binding to the inscope namespace
             */
            this.bindNamespace(context, namespace.resolvePrefix(nURI), nURI);
         }
      }

   }

   /**
    * Process the content of the node, browsing the content expressions to get a
    * content sequence.
    * 
    * @param context Dynamic context for evaluation of the content expressions
    * @param node The node which has the content
    */
   protected void processContent(final DynamicContext context,
         final DrbNode node)
   {

      /**
       * The final string of a text node, all adjacent items which are not a
       * node are converted into a string and concatened, whatever its type
       * (String, integer ...)
       */
      StringBuffer content_final_string = new StringBuffer();

      /**
       * The final string which contains the concatenation of all adjacent items
       * which are a String and only a String because it will be stored inside
       * the Value of the node (representing the typed value), so items which
       * are no string (integer, ...) are not converted and added to the Value
       * Array.
       */
      StringBuffer value_final_string = new StringBuffer();

      final DrbDefaultSequence content = new DrbDefaultSequence();
      final DrbDefaultSequence valueArray = new DrbDefaultSequence();

      for (int iexpression = 0; iexpression < this.expressions.size(); iexpression++)
      {
         /**
          * Evaluates the expression.
          */
         final DrbSequence expression_sequence =
            ((Expression) this.expressions.get(iexpression)).evaluate(context);

         if (expression_sequence == null)
         {
            logger.warn("Error while evaluating sub-expression #"
                  + (iexpression + 1) + " value for element constructor "
                  + this.name + ".");
            continue;
         }

         /**
          * Appends the node items to the output node, set the value of the
          * output node.
          */
         // concatenation of all item values converted into string for the final
         // content text node
         StringBuffer content_item_string = new StringBuffer();

         // concatenation of all items which are a string
         StringBuffer value_item_string = new StringBuffer();

         for (int iitem = 0; iitem < expression_sequence.getLength(); iitem++)
         {
            final DrbItem item = expression_sequence.getItem(iitem);

            if (item.getItemType() == DrbItem.NODE_ITEM)
            {
               // adding to the content the concatenation of the previous text
               // nodes
               content_final_string.append(content_item_string);
               if (content_final_string.length() != 0)
               {
                  content.addItem(new fr.gael.drb.value.String(
                        content_final_string.toString()));
                  content_final_string = new StringBuffer();
                  content_item_string = new StringBuffer();
               }

               // adding to the value the concatenation of the previous string
               // values
               if (!this.isStringValue())
               {
                  value_final_string.append(value_item_string);
                  if (value_final_string.length() != 0)
                  {
                     valueArray.addItem(new fr.gael.drb.value.String(
                           value_final_string.toString()));
                     value_final_string = new StringBuffer();
                     value_item_string = new StringBuffer();
                  }
               }
               if (this.expressions.get(iexpression) instanceof ConstructorExpression)
               {
                  node.appendChild((DrbNode) item);
               }
               else
               {
                  ((DrbAbstractNode) node).appendReference((DrbNode) item); // BUGBUG
               }
               content.addItem(item);
            }
            else if (item.getItemType() == DrbItem.ATTRIBUTE_ITEM)
            {
               // adding to the content the concatenation of the previous text
               // nodes
               content_final_string.append(content_item_string);
               if (content_final_string.length() != 0)
               {
                  content.addItem(new fr.gael.drb.value.String(
                        content_final_string.toString()));
                  content_final_string = new StringBuffer();
                  content_item_string = new StringBuffer();
               }

               // adding to the value the concatenation of the previous string
               // values
               if (!this.isStringValue())
               {
                  value_final_string.append(value_item_string);
                  if (value_final_string.length() != 0)
                  {
                     valueArray.addItem(new fr.gael.drb.value.String(
                           value_final_string.toString()));
                     value_final_string = new StringBuffer();
                     value_item_string = new StringBuffer();
                  }
               }

               DrbAttributeList list = node.getAttributes();
               if (list == null)
               {
                  list = new DrbDefaultAttributeList();
               }

               /**
                * checking if an attribute with the same XQName not already
                * exists
                */
               this.checkExistingAttribute(list, (DrbAttribute) item);

               /**
                * Making a copy of the attribute and adding it to the list
                */
               list.addItem(list.getLength(), item);
               node.setAttributes(list);

               /**
                * Update inscope namespace of the owner node
                */
               final String attr_uri = ((DrbAttribute) item).getNamespaceURI();
               if (attr_uri != null)
               {
                  this.bindNamespace(context, context.getNamespace()
                        .resolvePrefix(attr_uri), attr_uri);
               }

            }
            else if (item.getItemType() == DrbItem.VALUE_ITEM)
            {
               final Value item_value = (Value) item;

               try
               {
                  /*************************************************************
                   * Content
                   ************************************************************/
                  // concatening each item of a sequence to obtain a single text
                  // node
                  if (iitem >= 1)
                  {
                     content_item_string.append(this
                           .getAdjacentTextNodeSeparator());
                  }

                  content_item_string.append(item_value
                        .convertTo(Value.STRING_ID));

                  /*************************************************************
                   * Value
                   ************************************************************/

                  /**
                   * Case where the value is a string only so concatenation of
                   * all the items no matter their types and if they are
                   * adjacent or not
                   */
                  if (this.isStringValue())
                  {
                     if (value_item_string.length() != 0)
                     {
                        value_item_string.append(this
                              .getAdjacentTextNodeSeparator());
                     }
                     value_item_string.append(item_value
                           .convertTo(Value.STRING_ID));
                  }
                  else
                  {
                     // Concatenation for the Value, only for a string
                     if (item_value instanceof fr.gael.drb.value.String)
                     {
                        if (value_item_string.length() != 0)
                        {
                           value_item_string.append(this
                                 .getAdjacentTextNodeSeparator());
                        }
                        value_item_string.append(item_value);
                     }
                     else
                     {
                        value_final_string.append(value_item_string);
                        if (value_final_string.length() != 0)
                        {
                           valueArray.addItem(new fr.gael.drb.value.String(
                                 value_final_string.toString()));
                           value_final_string = new StringBuffer();
                           value_item_string = new StringBuffer();
                        }
                        valueArray.addItem(item_value);

                     }
                  }
               }
               catch (final ClassCastException e)
               {
                  throw new DynamicException(this, "Unable to convert item #"
                        + (iitem + 1) + " to string (element constructor "
                        + this.name + ")");
               }
            }
            else
            {
               logger.warn("Attribute items are not supported nested in "
                     + "an element constructor " + this.name + ".");
            }
         }// end items

         // concatening with no intervening blank
         content_final_string.append(content_item_string);

         // concatening with no intervening blank
         value_final_string.append(value_item_string);

      }// end expressions

      // adding the last text node to the content
      if (content_final_string.length() != 0)
      {
         content.addItem(new fr.gael.drb.value.String(content_final_string
               .toString()));
      }

      // adding to the value the concatenation of the previous string value
      if (value_final_string.length() != 0)
      {
         valueArray.addItem(new fr.gael.drb.value.String(value_final_string
               .toString()));
      }

      // setting the content //TBC - WARNING
      // ((ConstructorNode)node).setContent(content);

      // setting the value
      final ValueArray array = valueArray.atomize();
      if (array.length() != 0)
      {
         ((DrbAbstractNode) node)
               .setValue((array.getLength() == 1) ? (Value) array.getItem(0)
                     : array);
      }

   }

   /**
    * Process all the attributes of the node
    * 
    * @param context The context for evaluation
    * @param node The node whose attributes belong
    */
   private void processAttributes(final DynamicContext context,
         final DrbNode node)
   {

      DrbDefaultAttributeList attribute_list = null;

      /**
       * Browsing attributes list
       */
      for (int iattr = 0; iattr < this.attributeNames.size(); iattr++)
      {
         /**
          * Creating the attribute
          */
         final DrbDefaultAttribute attribute =
            new DrbDefaultAttribute(((QName) this.attributeNames.get(iattr))
                  .getLocalName(), null, node);

         /**
          * Evaluate the expressions of the attribute.
          */
         final Vector expressions =
            (Vector) this.attributeExpressions.get(iattr);

         boolean value_initialized = false;
         boolean concatenation_performed = false;

         if (expressions == null)
         {
            throw new DynamicException(this,
                  "Invalid expression vector for attribute "
                        + ((QName) this.attributeNames.get(iattr)).getName());
         }

         String attribute_string = "";

         /**
          * Browsing the expressions for the current attribute
          */
         for (int iexpression = 0; iexpression < expressions.size(); iexpression++)
         {
            /**
             * Evaluates the expression.
             */
            final Expression current_expression =
               (Expression) expressions.get(iexpression);

            if (current_expression == null)
            {
               throw new DynamicException(this, "The nested expression #"
                     + (iexpression + 1) + " of attribute \""
                     + ((QName) this.attributeNames.get(iattr)).getName()
                     + "\" is null");
            }

            DrbSequence attribute_item = current_expression.evaluate(context);

            if (attribute_item != null)
            {
               attribute_item = attribute_item.atomize();
            }

            if (attribute_item == null)
            {
               throw new DynamicException(this,
                     "Error while evaluating sub-expression #"
                           + (iexpression + 1) + " value for attribute "
                           + ((QName) this.attributeNames.get(iattr)).getName());
            }

            /**
             * Appends the items to the attribute sequence.
             */
            String attribute_string_item = "";

            for (int iitem = 0; iitem < attribute_item.getLength(); iitem++)
            {
               /**
                * Extract current value.
                */
               final DrbItem item = attribute_item.getItem(iitem);

               if (item == null)
               {
                  throw new DynamicException(this,
                        "Null item resulting from evaluation of attribute "
                              + ((QName) this.attributeNames.get(iattr))
                                    .getName());
               }

               final Value attribute_value = (Value) item;

               if (attribute_value == null)
               {
                  throw new DynamicException(this,
                        "Null value resulting from evaluation of attribute "
                              + ((QName) this.attributeNames.get(iattr))
                                    .getName());
               }

               /**
                * If the attribute value has not already been assigned, do it
                * with the current item. This operation intends to keep the
                * value type of the current expression as far as it is the
                * unique non_null item of the attribute sequence. It does not
                * conform the W3C specification but cope the DRB policy.
                */
               if (!value_initialized)
               {
                  attribute.setValue(attribute_value);
                  value_initialized = true;
                  attribute_string_item +=
                     ((fr.gael.drb.value.String) attribute_value
                           .convertTo(Value.STRING_ID)).toString();

               }
               /**
                * Concatenate the current value to the output attribute value.
                */
               else
               {
                  try
                  {
                     if (!(attribute_string_item.equals("")))
                     {
                        attribute_string_item += " ";
                     }

                     attribute_string_item +=
                        ((fr.gael.drb.value.String) attribute_value
                              .convertTo(Value.STRING_ID)).toString();

                  }
                  catch (final ClassCastException e)
                  {
                     throw new DynamicException(this,
                           "XQ0052 - Unable to cast item #"
                                 + (iitem + 1)
                                 + " to string (attribute "
                                 + ((QName) this.attributeNames.get(iattr))
                                       .getName() + ")");
                  }

                  concatenation_performed = true;
               }
            }// end for item

            attribute_string += attribute_string_item;

         }// end for expressions

         /**
          * Setting the value for the current attribute if not already done
          */
         if (!((value_initialized == true) && (concatenation_performed == false)))
         {
            attribute.setValue(new fr.gael.drb.value.String(attribute_string));
         }

         /**
          * Checking its name and update its namespaceURI
          */
         this.setAttributeURI(context, attribute, ((QName) this.attributeNames
               .get(iattr)));

         /**
          * Creates the attribute list if not already performed.
          */
         if (attribute_list == null)
         {
            attribute_list = new DrbDefaultAttributeList();
         }

         /**
          * checking if an attribute with the same XQName not already exists
          */
         this.checkExistingAttribute(attribute_list, attribute);

         /**
          * Updating inscope namespace with the prefix of the attribute
          */
         final QName attr_name = ((QName) this.attributeNames.get(iattr));
         if (attr_name.getPrefix() != null)
         {
            this.bindNamespace(context, context.getNamespace().resolvePrefix(
                  attribute.getNamespaceURI()), attribute.getNamespaceURI());
         }

         /**
          * Add the attribute to the attribute list.
          */
         attribute_list.add(attribute);

      }

      /**
       * Assign the attribute list to the node if it has been created.
       */
      if (attribute_list != null)
      {
         node.setAttributes(attribute_list);
      }

   }

   /**
    * Check if an attribute with the same expanded QName (same local name and
    * same URI) not already exists inside the DrbAttributeList provided
    * 
    * @param attribute_list The list of attributes to consider
    * @param attribute The attribute to compare with the attributes inside the
    *           list
    */
   private void checkExistingAttribute(final DrbAttributeList attribute_list,
         final DrbAttribute attribute)
   {
      for (int i = 0; i < attribute_list.getLength(); i++)
      {
         final DrbItem current_item = attribute_list.getItem(i);

         if (current_item.getName().equals(attribute.getName()))
         {
            if ((current_item.getNamespaceURI() == null)
                  && (attribute.getNamespaceURI() == null))
            {
               throw new DynamicException(this,
                     "XQDY0025 - Impossible to declare two attributes with"
                           + " the same name " + current_item.getName());
            }
            else if (current_item.getNamespaceURI() != null)
            {
               if (current_item.getNamespaceURI().equals(
                     attribute.getNamespaceURI()))
               {
                  throw new DynamicException(this,
                        "XQDY0025 - Impossible to declare two attributes with"
                              + " the same name " + current_item.getName());
               }
            }
         }
      }
   }

   /**
    * Check the prefix has been bound to an URI, if any. Check also if its not a
    * namespace declaration attribute. If any, set this namespaceURI to this
    * attribute.
    * 
    * @param context The dynamic context of evaluation
    * @param attribute The attribute being constructed
    * @param name The name of the attribute (may be provided by a name
    *           expression)
    */
   private void setAttributeURI(final DynamicContext context,
         final DrbDefaultAttribute attribute, final QName name)
   {

      final Namespace namespace = context.getNamespace();

      if (name.getPrefix() == null)
      {
         attribute.setNamespaceURI(null);
      }

      else if (name.getPrefix() != null)
      {
         final String nURI = namespace.resolveNamespace(name.getPrefix());
         if (nURI == null)
         {
            throw new DynamicException(this, "XQDY0074 - The prefix \""
                  + name.getPrefix() + "\" has not been bound.");
         }
         else
         {
            attribute.setNamespaceURI(nURI);
         }
      }
   }

   /**
    * set the in_string_value value
    * 
    * @param bool The boolean to set
    */
   public void setIsStringValue(final boolean bool)
   {
      this.is_string_value = bool;

   }

   /**
    * Say if the content value of the node will be only a concatenated string
    * Thats occurs if in the value appear a direct string value (using element
    * content char)
    * 
    * @return true if the value will be a unique string no matter the content
    */
   public boolean isStringValue()
   {
      return this.is_string_value;
   }

   /**
    * Return the separator used when encounter adjacent text nodes among items
    * of a sequence
    * 
    * @return The separator (often a blank space or the empty string)
    */
   protected String getAdjacentTextNodeSeparator()
   {

      return " ";
   }

   /**
    * Returns a detailed description of the element.
    * 
    * @return the description of the element.
    */
   public String toString()
   {
      QName effective_name = this.name;

      if (this.name == null)
      {
         effective_name = new QName("unnamed");
      }

      String output = "<" + this.name + ">\n   ";

      if (this.expressions.size() > 0)
      {
         for (int iexpression = 0; iexpression < this.expressions.size(); iexpression++)
         {
            output = output + this.expressions.get(iexpression);
         }
      }

      output = output + "\n</" + this.name + ">";

      return output;
   }

}
