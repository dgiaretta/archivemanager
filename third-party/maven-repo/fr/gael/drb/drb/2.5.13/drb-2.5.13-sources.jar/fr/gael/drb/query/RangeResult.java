/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.value.AbstractNumericArray;
import fr.gael.drb.value.Value;

/**
 * Wraps a Range expression result of XQuery language. e.g. in "/mds/mdsr[
 * position()=123 to $b ]", "123 to $b" is a range expression.
 */
final class RangeResult extends AbstractNumericArray
{
   /**
    * PRIORITY
    */
   final static int PRIORITY = 4;

   /**
    * The minimum value.
    */
   private long minimum;

   /**
    * The maximum value.
    */
   private long maximum;

   /**
    * The range result size.
    */
   private long count;

   /**
    * Builds a range expression result sequence.
    * 
    * @param min the minimum of the range.
    * @param max the maximum of the range.
    */
   RangeResult(final long min, final long max)
   {
      /**
       * Sets the bounds of the range result
       */
      this.minimum = min;
      this.maximum = max;

      /**
       * Computes the size of the range sequence
       */
      if (this.minimum <= this.maximum)
      {
         this.count = this.maximum - this.minimum + 1;
      }
      else
      {
         this.count = 0;
      }
   } // RangeResult

   /**
    * Returns a string describing the range.
    * 
    * @return the description of the range.
    */
   public String toString()
   {
      return this.minimum + " to " + this.maximum;
   }

   /**
    * The number of values in the range result. The sequence is empty if the
    * range bounds are in reverse order; otherwise, the number of item is
    * computed as maximum - minimum + 1.
    * 
    * @return 0 if the bounds are in reverse order (lower>upper); otherwise, the
    *         size of the range.
    */
   public int length()
   {
      return (int) this.count;
   } // length

   /**
    * Returns the LongArray priority
    * 
    * @return the LongArray priority
    */
   public final int getPriority()
   {
      return this.PRIORITY;
   }

   /**
    * Returns the Array type
    * 
    * @return the array type as an int (LONG_ID)
    */
   public final int getArrayType()
   {
      return Value.LONG_ID;
   } // getArrayType

   /**
    * Return the specified item in the range sequence
    * 
    * @param indice indice
    * @return Long
    */
   public final Value getElement(final int indice)
   {
      if ((indice >= 0) || (indice < this.count))
      {
         return new fr.gael.drb.value.Long(this.minimum + indice);
      }
      else
      {
         throw new IllegalArgumentException("Index is out of bounds");
      }
   }

   /**
    * Assign a value to an index This method always throw an
    * UnsupportedOperationException
    * 
    * @param index position where to insert the value.
    * @param element value to assign.
    */
   public final void assign(final int index, final Value element)
   {
      throw new UnsupportedOperationException("Range sequence are not mutable");
   } // assign

   /**
    * Assign a new Value. This method always throw an
    * UnsupportedOperationException
    * 
    * @param v the value to be assigned.
    * @throws ClassCastException an exception
    */
   public final void assign(final Value v) throws ClassCastException
   {
      throw new UnsupportedOperationException("Range sequence are not mutable");
   }

   /**
    * Returns the range result as a long array.    
    * @return a long array.
    */
   @Override
   public long[] getData()
   {
      long[] data = new long[(int)count];
      for (int i=0; i<count; i++)
      {
         data[i] = minimum + i; 
      }
      return data;
   }
} // RangeResult
