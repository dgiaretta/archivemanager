/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import java.util.HashMap;
import java.util.Iterator;

/**
 * Declaration of a namespace.
 */
public class Namespace implements Cloneable
{
   /**
    * XML_SCHEMA_NAMESPACE
    */
   public final static String XML_SCHEMA_NAMESPACE =
      "http://www.w3.org/2001/XMLSchema";

   /**
    * XML_SCHEMA_INSTANCE
    */
   public final static String XML_SCHEMA_INSTANCE =
      "http://www.w3.org/2001/XMLSchema-instance";

   // ==============================================
   // Attributes part.
   // ==============================================
   /**
    * The namespace binding.
    */
   protected HashMap namespaceMap = new HashMap();

   /**
    * The prefix binding.
    */
   protected HashMap prefixMap = new HashMap();

   /**
    * The default namespace URI.
    */
   protected String defaultNamespaceURI = null;

   // =================================================
   // Methods part.
   // =================================================
   /**
    * Clones the current class. <b>Caution:</b> The constructor clones the
    * lists of prefix and URIs but does not their referenced elements.
    * 
    * @return the cloned namespace.
    */
   public Namespace cloneNamespace()
   {
      final Namespace namespace = new Namespace();

      namespace.namespaceMap = (HashMap) this.namespaceMap.clone();
      namespace.prefixMap = (HashMap) this.prefixMap.clone();
      namespace.defaultNamespaceURI = this.defaultNamespaceURI;

      return namespace;
   }

   /**
    * Add a set of namespaces to the current set.
    * 
    * @param namespaces the container of the namespaces to add.
    */
   public void addNamespaces(final Namespace namespaces)
   {
      if (namespaces == null)
      {
         return;
      }
      final String[] prefixes = namespaces.getDeclaredPrefixes();
      for (int i = 0; i < prefixes.length; i++)
      {
         this.bind(prefixes[i], namespaces.resolveNamespace(prefixes[i]));
      }
   }

   /**
    * Returns the namespace from a prefix.
    * 
    * @param ns_prefix String
    * @return String
    */
   public String resolveNamespace(final String ns_prefix)
   {
      return (String) this.namespaceMap.get(ns_prefix);
   } // resolveNamespace

   /**
    * Returns the prefix from a namespace.
    * 
    * @param ns_full String
    * @return String
    */
   public String resolvePrefix(final String ns_full)
   {
      return (String) this.prefixMap.get(ns_full);
   } // resolvePrefix

   /**
    * Bind a namespace to a prefix. If a binding already exist for that prefix,
    * the namespace will be replaced.
    * 
    * @param ns_prefix a prefix
    * @param ns_full the namespace URI
    */
   public void bind(final String ns_prefix, final String ns_full)
   {
      this.namespaceMap.put(ns_prefix, ns_full);
      this.prefixMap.put(ns_full, ns_prefix);
   } // bind

   /**
    * Create a prefix and bind it to a namespace.
    * 
    * @param ns_prefix a prefix (must never be empty)
    * @param ns_full String
    * @return the new prefix.
    */
   public String createPrefix(final String ns_prefix, final String ns_full)
   {
      int count = 1;
      String new_prefix = ns_prefix;
      while (this.resolveNamespace(new_prefix) != null)
      {
         new_prefix = ns_prefix + (count++);
      }
      this.bind(new_prefix, ns_full);
      return new_prefix;
   }

   /**
    * Unbind a prefix.
    * 
    * @param ns_prefix String
    */
   public void unbind(final String ns_prefix)
   {
      final String nsFull = this.resolveNamespace(ns_prefix);
      this.namespaceMap.remove(ns_prefix);
      if (nsFull != null)
      {
         this.prefixMap.remove(nsFull);
      }
   } // unbind

   /**
    * Returns the default namespace URI
    * 
    * @return the default namespace URI
    */
   public String getDefaultNamespaceURI()
   {
      return this.defaultNamespaceURI;
   } // getDefaultNamespaceURI

   /**
    * Set the default namespace URI.
    * 
    * @param ns_uri the default namespace URI
    */
   public void setDefaultNamespaceURI(final String ns_uri)
   {
      this.defaultNamespaceURI = ns_uri;
   } // setDefaultNamespaceURI

   /**
    * Returns all the declared prefixes.
    * 
    * @return The declared prefixes.
    */
   public String[] getDeclaredPrefixes()
   {
      final Object[] array = this.namespaceMap.keySet().toArray();
      final String[] prefixes = new String[array.length];
      for (int i = 0; i < array.length; i++)
      {
         prefixes[i] = array[i].toString();
      }
      return prefixes;
   }

   /**
    * Returns the prefix of the specified qualified name. It is assumed that
    * there is at most one prefix.
    * 
    * @param qualified_name a qualified name.
    * @return The prefix of the specified qualified name.
    */
   public static String toPrefix(final String qualified_name)
   {
      final char[] str = qualified_name.toCharArray();

      // Search the separator

      for (int i = 0; i < str.length; i++)
      {
         if (str[i] == ':')
         {
            return qualified_name.substring(0, i);
         }
      }
      return null;
   }

   /**
    * Returns the local part of the specified qualified name. It is assumed that
    * there is at most one prefix.
    * 
    * @param qualified_name a qualified name.
    * @return The local part of the specified qualified name.
    */
   public static String toLocal(final String qualified_name)
   {
      final char[] str = qualified_name.toCharArray();

      // Search the separator
      for (int i = 0; i < str.length; i++)
      {
         if (str[i] == ':')
         {
            return qualified_name.substring(i + 1, qualified_name.length());
         }
      }
      return qualified_name;
   }

   /**
    * Returns the list of (prefix, URI) couples on a line per line basis.
    * 
    * @return the couples of prefix, URI.
    */
   public String toString()
   {
      String string = "";
      final Iterator prefixIterator = this.prefixMap.values().iterator();

      while (prefixIterator.hasNext())
      {
         final String currentPrefix = (String) prefixIterator.next();

         string =
            string + currentPrefix + " -> "
                  + (String) this.namespaceMap.get(currentPrefix) + "\n";
      }

      return string;
   }
} // Namespace
