/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

/**
 * Declaration of a Xsd name.
 */
public class XsdName
{
   // ==============================================
   // Attributes part.
   // ==============================================
   /**
    * The namespace URI.
    */
   protected String namespaceURI;

   /**
    * The local name.
    */
   protected String localName;

   // =================================================
   // Methods part.
   // =================================================
   /**
    * Build an Xsd name.
    * 
    * @param name the local part of the QName.
    * @param namespace_uri the namespace URI.
    */
   protected XsdName(String name, final String namespace_uri)
   {
      if (name == null)
      {
         name = "";
      }
      this.localName = name;
      this.namespaceURI = namespace_uri;
   }

   /**
    * Returns the hash code.
    * 
    * @return an hash code.
    */
   public int hashCode()
   {
      return this.localName.hashCode();
   }

   /**
    * Check equality with another XsdName
    * 
    * @param object the object to be compared.
    * @return true false
    */
   public boolean equals(final Object object)
   {
      if (object instanceof XsdName)
      {
         final XsdName xsdName = (XsdName) object;
         if (!this.localName.equals(xsdName.localName))
         {
            return false;
         }
         if (this.namespaceURI != null)
         {
            return (xsdName.namespaceURI != null)
                  && this.namespaceURI.equals(xsdName.namespaceURI);
         }
         return (xsdName.namespaceURI == null);
      }
      if (object instanceof String)
      {
         return this.localName.equals(object);
      }
      return super.equals(object);
   }
} // XsdName
