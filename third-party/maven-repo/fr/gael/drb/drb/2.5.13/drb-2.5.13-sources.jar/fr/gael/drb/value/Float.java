/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * The Float class is a generic wrapper for float values.
 */
public class Float extends AbstractNumeric implements ValueFormat
{
   // =======================================================
   // Attributes part.
   // =======================================================
   /**
    * The float priority.
    */
   final static int PRIORITY = 6;

   /**
    * The Float value.
    */
   float value;

   // ========================================================
   // Methods part.
   // ========================================================
   /**
    * Constructs an Float object initialized to the specified float value.
    * 
    * @param v the value of the Float.
    */
   public Float(final float v)
   {
      this.value = v;
   }

   /**
    * Returns a new String object representing this Float
    * 
    * @return a string representation of the object.
    */
   public java.lang.String toString()
   {
      return java.lang.Float.toString(this.value);
   }

   // -----------------------------------------------------------
   // ValueFormat interface implementation
   // -----------------------------------------------------------
   // see interface ValueFormat for more information.

   /**
    * Return a string containing the value with a fixed format.
    * 
    * @param length The expected length of the output string
    * @return The formatted string.
    */
   public java.lang.String getFormattedString(final int length)
   {
      return getFormattedString(length, this.value);
   }

   /**
    * Return a byte buffer containing the value in a fixed format.
    * 
    * @return The formatted buffer.
    */
   public byte[] getFormattedBuffer()
   {
      final byte[] buffer = new byte[4];
      final int int_value = java.lang.Float.floatToRawIntBits(this.value);

      buffer[0] = (byte) (int_value >>> 24);
      buffer[1] = (byte) (int_value >>> 16);
      buffer[2] = (byte) (int_value >>> 8);
      buffer[3] = (byte) (int_value);

      return buffer;
   }

   /**
    * Return a string containing the passed value with a fixed format.
    * 
    * @param length The expected length of the output string
    * @param value The value to use for output string.
    * @return The formatted string.
    */
   public static java.lang.String getFormattedString(final int length,
         final float value)
   {
      return new java.lang.String(new java.text.DecimalFormat(
            "+0.00000000E00;-0.00000000E00").format(value));
   }

   // ----------------------------------------------------
   // Value interface implementation
   // ----------------------------------------------------
   /**
    * The type identifier of this Float value.
    * 
    * @return an identifier of the Float type.
    */
   public final int getType()
   {
      return Value.FLOAT_ID;
   }

   /**
    * Returns the Float priority
    * 
    * @return the Float priority
    */
   public final int getPriority()
   {
      return PRIORITY;
   }

   /**
    * This method converts a type in a value
    * 
    * @param type The type to be converted
    * @return the value which had been converted
    */
   public final Value convertTo(final int type)
   {
      switch (type)
      {
         // Float -> Float conversion
         case FLOAT_ID:
            return this;

            // Float -> FloatArray conversion
         case ARRAY_ID:
            final FloatArray floatArray = new FloatArray(1);
            floatArray.assign(0, this.floatValue());
            return floatArray;

            // Float -> Unknown conversion
         default:
            return super.convertTo(type);
      }
   }

   /**
    * This method assigned the value passed in param
    * 
    * @param v The value to be assigned
    */
   public void assign(final Value v)
   {
      final Float vf = (Float) v.convertTo(Value.FLOAT_ID);
      this.value = vf.floatValue();
   }

   // --------------------------------------------------
   // Arithmetic interface implementation
   // ---------------------------------------------------
   /**
    * This method converts a float in a unary minus value
    * 
    * @return The value
    */
   public Value unaryMinus()
   {
      return new Float(-this.value);
   }

   /**
    * This method adds a value
    * 
    * @param x The value to add
    * @return The value which had been added
    */
   public Value add(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).add(x);
      }
      return new Float(this.floatValue() + ((Numeric) x).floatValue());
   }

   /**
    * This method subs a value
    * 
    * @param x The value to sub
    * @return The value which had been subed
    */
   public Value sub(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).sub(x);
      }
      return new Float(this.floatValue() - ((Numeric) x).floatValue());
   }

   /**
    * This method multiplies a value
    * 
    * @param x The value to multiply
    * @return The value which had been multiplied
    */
   public Value multiply(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).multiply(x);
      }
      return new Float(this.floatValue() * ((Numeric) x).floatValue());
   }

   /**
    * This method divides a value
    * 
    * @param x The value to divide
    * @return The value which had been divided
    */
   public final Value divide(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).divide(x);
      }
      return new Float(this.floatValue() / ((Numeric) x).floatValue());
   }

   /**
    * Calculates the current value modulus the given one.
    * 
    * @param x the Value to modulate by
    * @return the current value modulus the given one
    */
   public Value modulus(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).modulus(x);
      }
      return new Float(this.floatValue() % ((Numeric) x).floatValue());
   }

   // -------------------------------------------------------
   // Comparison interface implementation
   // -------------------------------------------------------
   /**
    * Compares the current Value to the given one
    * 
    * @param x the Value to be compared
    * @return a negative integer, zero, or a positive integer as the argument is
    *         less than, equal to, or greater than the current Value.
    */
   public int compareTo(final Value x)
   {
      if (this.getPriority() >= x.getPriority())
      {
         final float cmp = this.floatValue() - ((Numeric) x).floatValue();
         if (cmp == 0.0f)
         {
            return 0;
         }
         else if (cmp < 0.0f)
         {
            return -1;
         }
         else
         {
            return +1;
         }
      }
      return -((Comparison) x).compareTo(this);
   }

   // -------------------------------------------------
   // Logic interface implementation
   // -------------------------------------------------
   /**
    * Returns the logical representation of the current Value
    * 
    * @return the logical representation of the current Value
    */
   public final boolean booleanValue()
   {
      if (java.lang.Float.isNaN(this.value) || (this.value == 0.0f))
      {
         return false;
      }
      return true;
   }

   // ----------------------------------------------------
   // Numeric interface implementation
   // ----------------------------------------------------
   /**
    * Returns this value as a byte (signed 8 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type byte.
    */
   public final byte byteValue()
   {
      return (byte) this.value;
   }

   /**
    * Returns this value as a short integer (signed 16 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type short.
    */
   public final short shortValue()
   {
      return (short) this.value;
   }

   /**
    * Returns this value as an integer (signed 32 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type int.
    */
   public final int intValue()
   {
      return (int) this.value;
   }

   /**
    * Returns this value as a long integer (signed 64 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type long.
    */
   public final long longValue()
   {
      return (long) this.value;
   }

   /**
    * Returns this value as a float (signed 32 bits IEEE 754). The conversion
    * may result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type float.
    */
   public final float floatValue()
   {
      return this.value;
   }

   /**
    * Returns this value as a double (signed 64 bits IEEE 754). The conversion
    * may result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type double.
    */
   public final double doubleValue()
   {
      return this.value;
   }

   /**
    * Returns this value as a BigInteger. The conversion may result in a loss of
    * precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type BigInteger.
    */
   protected BigInteger integerValue()
   {
      return new BigDecimal(this.toString()).toBigInteger();
   }

   /**
    * Returns this value as a BigDecimal. The conversion may result in a loss of
    * precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type BigDecimal.
    */
   protected BigDecimal decimalValue()
   {
      return new BigDecimal(this.toString());
   }

   /**
    * Assign a boolean Value to the current one.
    * 
    * @param value the Value to set.
    */
   public final void assign(final boolean value)
   {
      this.value = (value ? 1.0f : 0.0f);
   }

   /**
    * Assign a byte Value to the current one.
    * 
    * @param value the Value to set.
    */
   public final void assign(final byte value)
   {
      this.value = value;
   }

   /**
    * Assign an int Value to the current one.
    * 
    * @param value the Value to set.
    */
   public final void assign(final int value)
   {
      this.value = value;
   }

   /**
    * Assign a short Value to the current one.
    * 
    * @param value the Value to set.
    */
   public final void assign(final short value)
   {
      this.value = value;
   }

   /**
    * Assign a long Value to the current one.
    * 
    * @param value the Value to set.
    */
   public final void assign(final long value)
   {
      this.value = value;
   }

   /**
    * Assign a float Value to the current one.
    * 
    * @param value the Value to set.
    */
   public final void assign(final float value)
   {
      this.value = value;
   }

   /**
    * Assign a double Value to the current one.
    * 
    * @param value the Value to set.
    */
   public final void assign(final double value)
   {
      this.value = (float) value;
   }

   /**
    * main
    * 
    * @param args string[]
    */
   public static void main(final java.lang.String[] args)
   {
      System.out.println(" 123456.78 toString() : ["
            + new Float((float) 123456.78) + "]");
      System.out.println("-1234.5678 toString() : ["
            + new Float((float) -1234.5678) + "]");
      System.out.println(" 0.0012345 toString() : ["
            + new Float((float) 0.0012345) + "]");
      System.out.println("-0.0012345 toString() : ["
            + new Float((float) -0.0012345) + "]");
   }
}
