/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.file;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbFactoryImpl;
import fr.gael.drb.DrbNode;

/**
 * Factory of local file or directory nodes. This class implements the
 * DrbFactoryImpl interface to create fr.drb.impl.file.File nodes that handles
 * file system elements such has directories or files. This factory is not
 * supposed to be used directly from any component but has been designed for the
 * fr.gael.drb.Factory class.
 * 
 * @see fr.gael.drb.impl.file.File
 * @see fr.gael.drb.DrbFactory
 */
public final class FileFactory implements DrbFactoryImpl
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(FileFactory.class);

   /**
    * Returns "file" string. "file" is defined as scheme identifier of the
    * implementation.
    * 
    * @return "file".
    */
   public final String getIdentifier()
   {
      return "file";
   }

   /**
    * Returns "Local file system" string. "Local file system" stands as the name
    * of the implementation.
    * 
    * @return "Local file system".
    */
   public final String getName()
   {
      return "Local file system";
   }

   /**
    * Create a file node matching the provided URI. The returned node may
    * correspond to a directory or a file depending of the resource pointed by
    * the provided URI. Note : The URI scheme (i.e. file protocol is not checked
    * and is considered as default).
    * 
    * @param url The "Uniform Resource Locator" (URL) to be handled. This
    *           parameter shall not be null.
    * @return A reference to a File node or null if the URL does not match any
    *         component of the local file system.
    */
   public final DrbNode open(final URL url)
   {

      /**
       * Checks input URL reference.
       */
      if (url == null)
      {
         return null;
      }

      try
      {
         /**
          * creates and stores a file instance corresponding to the uri.
          */
         final URI local = new java.io.File(".").toURI();
         final URI uri = local.resolve(url.toString());
         java.io.File file;

         if (uri.isOpaque())
         {
            file =
               new java.io.File(URLDecoder.decode(uri.getSchemeSpecificPart(),
                     "UTF-8"));
         }
         else
         {
            file = new java.io.File(uri);
         }

         /**
          * checks the file matches an existing file or directory of the local
          * file system.
          */
         if (file.exists() == false)
         {
            this.logger.info("FileFactory.openURL(" + url + ") : file '"
                  + file.getPath() + "' does not exist.");
            return null;
         }

         return new File(file);
      }
      catch (final IllegalArgumentException e1)
      {
         this.logger.info("FileFactory.openURL(" + url + ") : " + e1);
         return null;
      }
      catch (final java.io.UnsupportedEncodingException e2)
      {
         this.logger.info("FileFactory.openURL(" + url + ") : " + e2);
         return null;
      }
   }

   /**
    * Create a file node matching the provided path. The returned node may
    * correspond to a directory or a file depending of the resource pointed by
    * the provided path.
    * 
    * @param file_path The path of the target file. This parameter shall not be
    *           null.
    * @return A reference to a File node or null if the path does not match any
    *         component of the local file system.
    */
   public final DrbNode open(final String file_path)
   {
      /**
       * Checks input path reference.
       */
      if (file_path == null)
      {
         return null;
      }

      /**
       * Creates and stores a File instance corresponding to the URI.
       */
      java.io.File file = new java.io.File(file_path);

      /**
       * Checks the file matches an existing file or directory of the local file
       * system.
       */
      if (!file.exists())
      {
         if (logger.isDebugEnabled())
         {
            this.logger.debug("File path " + file_path
                  + " is not an abstract path name or file does not exist."
                  + "(probing file path as a URI)...");
         }

         try
         {
            file = new java.io.File(new URI(file_path));

            if (!file.exists())
            {
               if (logger.isDebugEnabled())
               {
                  this.logger.debug("File path " + file_path
                        + " is not a URI or file does not exist (aborting).");
               }

               return null;
            }
            else
            {
               if (logger.isDebugEnabled())
               {
                  this.logger.debug("File path " + file_path
                        + " follows a URI and corresponding file has "
                        + "been found.");
               }
            }
         }
         catch (URISyntaxException exception)
         {
            if (logger.isDebugEnabled())
            {
               this.logger.debug("File path " + file_path
                     + " has not a URI syntax (aborting).", exception);
            }

            return null;
         }
      }

      return new File(file);
   }

   /**
    * Opens the node from an existing node. The current implementation of file
    * does not support this operation and returns always a null reference
    * disregarding the input node.
    * 
    * @param base_node A node reference that is not considered.
    * @return Always null.
    */
   public final DrbNode open(final DrbNode base_node)
   {
      return null;
   }

   /**
    * Opens the node matching a given URI from an existing node. This operation
    * returns a reference to a File node has done by the open(URL uri)
    * operation, disregarding the input node.
    * 
    * @param uri The "Uniform Resource Identifier" (URI) to be handled. This
    *           parameter shall never be null.
    * @param base_node Not considered.
    * @return A reference to a File node or null if the URI does not match any
    *         component of the local file system.
    */
   public final DrbNode open(final URL uri, final DrbNode base_node)
   {
      return this.open(uri);
   }

   /**
    * Creates a file node from an abstract path file.
    * 
    * @param file the abstract path file of the file to be opened.
    * @return A reference to a File node or null if the input abstract path file
    *         is null.
    */
   public final DrbNode open(final java.io.File file)
   {

      /**
       * Checks input URL reference.
       */
      if (file == null)
      {
         return null;
      }

      /**
       * Open file
       */
      return new File(file);
   } // End open(java.io.File)
}
