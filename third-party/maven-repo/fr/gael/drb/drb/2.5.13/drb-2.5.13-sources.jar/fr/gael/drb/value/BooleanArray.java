/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * The BooleanArray class is a generic wrapper for boolean array values.
 */
public class BooleanArray extends AbstractValueArray implements NumericArray
{
   // ==========================================================================
   // Attributes part.
   // ==========================================================================

   /**
    * PRIORITY
    */
   final static int PRIORITY = 0;

   /**
    * value
    */
   private boolean[] value;

   // ==========================================================================
   // Methods part.
   // ==========================================================================

   /**
    * Build an BooleanArray value.
    * 
    * @param v the BooleanArray value
    */
   public BooleanArray(final boolean[] v)
   {
      this.value = new boolean[v.length];
      System.arraycopy(v, 0, this.value, 0, v.length);
   }

   /**
    * Build an BooleanArray value.
    * 
    * @param v the BooleanArray string
    */
   public BooleanArray(final java.lang.String v)
   {
      final java.lang.String[] list = v.toString().trim().split(" ");
      this.value = new boolean[list.length];
      for (int i = 0; i < this.length(); i++)
      {
         this.assign(i, new fr.gael.drb.value.Boolean(list[i]));
      }
   }

   /**
    * Build an BooleanArray value with the specified size.
    * 
    * @param size the size of the array.
    */
   public BooleanArray(final int size)
   {
      this.value = new boolean[size];
   }

   /**
    * Returns the underlying object for optimization.    
    * @return a backing array.
    */
   public final boolean[] getData()
   {
      return this.value;
   }

   // --------------------------------------------------------------------------
   // Value interface implementation
   // --------------------------------------------------------------------------

   /**
    * The type identifier of this BooleanArray value.
    * 
    * @return an identifier of the array type, namely ARRAY_ID
    */
   public final int getType()
   {
      return Value.ARRAY_ID;
   }

   /**
    * Returns the BooleanArray priority
    * 
    * @return the BooleanArray priority
    */
   public final int getPriority()
   {
      return this.PRIORITY;
   }

   /**
    * Convert the value into the specified type. The type must be ARRAY_ID or
    * STRING_ID otherwise a ClassCastException is thrown
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException the conversion is impossible
    */
   public final Value convertTo(final int type) throws ClassCastException
   {
      if (type == ARRAY_ID)
      {
         return this;
      }

      if (type == STRING_ID)
      {
         return new String(this.toString());
      }

      throw new ClassCastException();
   }

   /**
    * Assign a value. This value must be a NumericArray otherwise a
    * ClassCastException is thrown.
    * 
    * @param v the value to be assigned.
    * @throws ClassCastException the conversion is impossible
    */
   public final void assign(Value v) throws ClassCastException
   {
      if (v.getType() == Value.STRING_ID)
      {
         v = new BooleanArray(v.toString());
      }

      if (v instanceof NumericArray)
      {
         final NumericArray b = (NumericArray) v;
         this.value = new boolean[b.length()];
         for (int i = 0; i < this.length(); i++)
         {
            this.value[i] = b.booleanValue(i);
         }
      }
      else if (v.getType() == Value.ARRAY_ID)
      {
         final ValueArray b = (ValueArray) v;
         this.value = new boolean[b.length()];
         for (int i = 0; i < this.length(); i++)
         {
            this.assign(i, b.getElement(i));
         }
      }
   }

   // --------------------------------------------------------------------------
   // ValueArray interface implementation
   // --------------------------------------------------------------------------

   /**
    * Returns the Array type
    * 
    * @return the array type as an int
    */
   public final int getArrayType()
   {
      return Value.BOOLEAN_ID;
   }

   /**
    * Returns the Element value at the specified index
    * 
    * @param index the index position
    * @return the value at this index
    */
   public final Value getElement(final int index)
   {
      return new fr.gael.drb.value.Boolean(this.value[index]);
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param element value to assign as a double.
    */
   public final void assign(final int index, Value element)
   {
      element = element.convertTo(Value.BOOLEAN_ID);
      this.value[index] = ((Boolean) element).booleanValue();
   }

   /**
    * Returns the number of elements in this array.
    * 
    * @return the number of elements in this array.
    */
   public final int length()
   {
      return this.value.length;
   }

   // --------------------------------------------------------------------------
   // NumericArray interface implementation
   // --------------------------------------------------------------------------

   /**
    * Returns this value as a boolean
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion
    */
   public final boolean booleanValue(final int index)
   {
      return this.value[index];
   }

   /**
    * Returns this value as a byte
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion
    */
   public final byte byteValue(final int index)
   {
      return (byte) (this.value[index] ? 1 : 0);
   }

   /**
    * Returns this value as a int
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion
    */
   public final int intValue(final int index)
   {
      return (this.value[index] ? 1 : 0);
   }

   /**
    * Returns this value as a long
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion
    */
   public final long longValue(final int index)
   {
      return (this.value[index] ? 1 : 0);
   }

   /**
    * Returns this value as a short
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion
    */
   public final short shortValue(final int index)
   {
      return (short) (this.value[index] ? 1 : 0);
   }

   /**
    * Returns this value as a float
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion
    */
   public final float floatValue(final int index)
   {
      return (this.value[index] ? 1.0f : 0.0f);
   }

   /**
    * Returns this value as a double
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion
    */
   public final double doubleValue(final int index)
   {
      return (this.value[index] ? 1.0 : 0.0);
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a boolean.
    */
   public final void assign(final int index, final boolean value)
   {
      this.value[index] = value;
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a byte.
    */
   public final void assign(final int index, final byte value)
   {
      this.value[index] = (value != 0);
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a int.
    */
   public final void assign(final int index, final int value)
   {
      this.value[index] = (value != 0);
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a short.
    */
   public final void assign(final int index, final short value)
   {
      this.value[index] = (value != 0);
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a long.
    */
   public final void assign(final int index, final long value)
   {
      this.value[index] = (value != 0);
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a float.
    */
   public final void assign(final int index, final float value)
   {
      this.value[index] = (value != 0.0f);
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a double.
    */
   public final void assign(final int index, final double value)
   {
      this.value[index] = (value != 0.0);
   }

   /**
    * Returns the boolean array
    * 
    * @return the boolean array
    */
   public java.lang.String toString()
   {
      java.lang.String str = "";
      for (int i = 0; i < this.length(); i++)
      {
         if (i != 0)
         {
            str += " ";
         }

         str += (this.value[i] ? "true" : "false");
      }
      return str;
   }

   /**
    * @param args the main arguments.
    */
   /*
    * public static void main(java.lang.String[] args) { BooleanArray b = new
    * BooleanArray("true false true"); System.out.println("b={" + b + "}"); }
    */
}
