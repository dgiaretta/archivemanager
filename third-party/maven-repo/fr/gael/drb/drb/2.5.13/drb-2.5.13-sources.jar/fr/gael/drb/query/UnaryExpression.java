/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.value.Arithmetic;
import fr.gael.drb.value.Value;
import fr.gael.drb.value.ValueArray;

/**
 * Wraps the unary expression (i.e. "+", "-") of XQuery language.
 */
class UnaryExpression extends AbstractExpression
{
   /**
    * PLUS indicator.
    */
   protected static int PLUS = 0;

   /**
    * MINUS indicator.
    */
   protected static int MINUS = 1;

   /**
    * Expression wrapping the operand.
    */
   private Expression operand;

   /**
    * The the current instance operation type.
    */
   private int operation;

   /**
    * Builds an unary expression.
    * 
    * @param token the token related to the current range expression.
    * @param operand the expression wrapping the operand.
    * @param operation the operation to perform.
    */
   public UnaryExpression(final Token token, final Expression operand,
         final int operation)
   {
      super("Unary", token);

      this.operand = operand;
      this.operation = operation;
   }

   /**
    * Returns a string decribing the unary expression.
    * 
    * @return the description of the unary expression.
    */
   public String toString()
   {
      String operation_string;

      if (this.operation == PLUS)
      {
         operation_string = "+";
      }
      else if (this.operation == MINUS)
      {
         operation_string = "-";
      }
      else
      {
         operation_string =
            "(unkown arithmetic operation #" + this.operation + ")";
      }

      return "(" + operation_string + this.operand + ")";
   }

   /**
    * Evaluate the operation.
    * 
    * @param context the outer-focus of the evalutation.
    * @return the sequence resulting from the dynamic evaluation.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {
      /**
       * Evaluates the operand and extract its value.
       */
      final DrbSequence sequence = this.operand.evaluate(context);

      if (sequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the operand expression");
      }

      /**
       * If unary is "+", return the sequence.
       */
      if (this.operation == PLUS)
      {
         return sequence;
      }

      /**
       * Else extract value and change its sign.
       */
      final ValueArray array = sequence.atomize();

      if (array.length() == 0)
      {
         return array;
      }

      if (array.length() > 1)
      {
         throw new TypeException(this,
               "The sequence length of operand is greater than one");
      }

      final Value value = array.getElement(0);

      /**
       * Compute the operation result.
       */
      final DrbDefaultSequence ouput_sequence = new DrbDefaultSequence();

      if (value instanceof Arithmetic)
      {
         Value zero = new fr.gael.drb.value.Integer(0);

         try
         {
            zero = zero.convertTo(value.getType());
         }
         catch (final ClassCastException e)
         {
            throw new DynamicException(this, e.getMessage());
         }

         ouput_sequence.add(((Arithmetic) zero).sub(value));
         return ouput_sequence;
      }
      else
      {
         throw new TypeException(this,
               "Invalid type of operand (should derive from Arithmetic type)");
      }
   }
}
