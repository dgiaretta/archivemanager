/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * Arithmetic expression evaluation.
 */
public interface Arithmetic extends Sumable
{

   /**
    * Compute an unary minus.
    * 
    * @return The unary minus of the value.
    */
   Value unaryMinus();

   /**
    * Compute a substraction.
    * 
    * @param x another value.
    * @return the difference between the two values.
    */
   Value sub(Value x);

   /**
    * Compute a multiplication.
    * 
    * @param x another value.
    * @return the product of the two values.
    */
   Value multiply(Value x);

   /**
    * Compute a division.
    * 
    * @param x another value.
    * @return the ratio of the two values.
    */
   Value divide(Value x);

   /**
    * Compute a modulus.
    * 
    * @param x another value.
    * @return the modulus of the values.
    */
   Value modulus(Value x);
}
