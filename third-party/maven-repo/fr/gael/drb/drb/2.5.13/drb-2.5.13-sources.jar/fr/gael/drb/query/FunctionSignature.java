/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import fr.gael.drb.DrbSequence;

/**
 * Function declaration of XQuery language.
 */
class FunctionSignature
{
   /**
    * The name of the function.
    */
   private QName name;

   /**
    * The return type of the function.
    */
   private SequenceType returnType;

   /**
    * Variable arity.
    */
   private boolean isVarArgs;

   /**
    * Updating flag
    */
   private boolean updating;

   /**
    * Parameter names.
    */
   private List<QName> parameterNames = new Vector<QName>();
   
   /**
    * Parameter types.
    */
   private List<SequenceType> parameterTypes = new Vector<SequenceType>();

   /**
    * Constructor of a non-updating function with untyped return value.
    * 
    * @param name string form of the function qualified name.
    */
   protected FunctionSignature(final QName name)
   {
      this (name, new SequenceType());      
   }

   /**
    * Constructor of a non-updating function.
    * 
    * @param name string form of the function qualified name.  
    */
   protected FunctionSignature(final QName name, SequenceType return_type)
   {
     this (name, return_type, false);  
   } //FunctionSignature

   /**
    * Complete constructor of a function.
    * 
    * @param name string form of the function qualified name.
    * @param return_type the return type.
    * @param updating updating
    */
   protected FunctionSignature(final QName name, SequenceType return_type,
                               boolean updating)
   {
      if (name == null)
      {
         throw new NullPointerException(
               "Cannot initialize a function with a null name.");
      }
      this.name = new QName(name); // copy name argument
      setReturnType(return_type);
      this.updating = updating;
      this.isVarArgs = false;
   } //FunctionSignature

   protected FunctionSignature(final String local_name, final String uri,
         final String return_type_name, final String[] parameter_type_names)
   {
      //Set name and arity  
      this.name = new QName(local_name, uri);
      this.isVarArgs = false;

      //Add parameters
      for (String parameter_type_name: parameter_type_names)
      {
         SequenceType parameter_type = new SequenceType();
         if (parameter_type_name != null)
         {
            parameter_type = new SequenceType(parameter_type_name);            
         }
         QName parameter_name = new QName("arg" + getArity());
         addParameter(parameter_name, parameter_type);
      }

      //Set return type
      this.updating = false;
      SequenceType return_type = new SequenceType();
      if (return_type_name != null)
      {
         return_type = new SequenceType(return_type_name);
      }
      setReturnType(return_type);      
   } //FunctionSignature

   /**
    * Returns the qualified name of the function. Any function shall return a
    * qualified name, even if it is not prefixed.
    * 
    * @return the qualified name of the function.
    */
   protected QName getQName()
   {
      return this.name;
   }

   /**
    * Returns the string form of the qualified name of the function.
    * 
    * @return the string form of the qualified name.
    */
   public String getName()
   {
      return this.name.getName();
   }

   /**
    * Returns the return type of the function.
    * 
    * @return the return type of the function.
    */
   protected SequenceType getReturnType()
   {
      return this.returnType;
   }
   
   /**
    * Set the return type of the function.
    * 
    * @param return_type the return type of the function.
    */
   protected void setReturnType(SequenceType return_type)
   {
      if (return_type == null)
      {
         throw new NullPointerException(
         "Cannot initialize a function with a null return type.");
      }
      this.returnType = return_type;
   }

   /**
    * Assigns a new name to the function. The provided name shall be the
    * qualified name of the function such as the one provided at construction.
    * The operation replaces the old name with the new one although the prefix
    * part has changed or not. The operation raises a NullPointerException if
    * the provided name is null.
    * 
    * @param name the new qualified name of the function.
    */
   protected void setName(final String name)
   {
      if (name == null)
      {
         throw new NullPointerException(
               "Cannot replace name with a null reference.");
      }

      this.name = new QName(name);
   }

   /**
    * Returns the string form of the qualified name of the sequence type of the
    * function. The name of the sequence type does not include the occurrence
    * indicator.
    * 
    * @return the string form of the qualified name of the sequence type.
    */
   public String getSequenceTypeName()
   {
      return this.returnType.getName();
   }

   /**
    * Returns true if the function signatures matches the given name and arity.
    * @param name the function name.
    * @param arity the function arity.
    * @return true if and onlyf if the function signatures matches the given
    * name and arity; false otherwise.
    */
   public boolean matches(QName name, int arity)
   {
      return this.name.equals(name) && (isVarArgs || this.getArity() == arity);
   }

   /**
    * Declare a new parameter to the function.
    * 
    * @param parameter_name string form of the qualified name of the parameter.
    */
   public void addParameter(final QName parameter_name)
   {
      this.addParameter(parameter_name, new SequenceType());
   }
   
   /**
    * Declare a new parameter to the function.
    * 
    * @param parameter_name string form of the qualified name of the parameter.
    */
   public void addParameter(final QName parameter_name,
                            final SequenceType parameter_type)
   {
      if ((parameter_name == null) || (parameter_type == null))
      {
         throw new NullPointerException("Cannot add a null parameter");
      }
      this.parameterNames.add(new QName(parameter_name));
      this.parameterTypes.add(parameter_type);
   }

   /**
    * Returns the arity of the function signature.
    * 
    * @return the number of declared parameters.
    */
   public int getArity()
   {
      return this.parameterNames.size();
   }

   /**
    * Returns true if this function was declared to take a variable number of
    * parameters; returns false otherwise. 
    * @return true if an only if this function was declared to take a variable
    * number of parameters.
    */
   boolean isVarArgs()
   {
      return isVarArgs;
   }

   /**
    * Returns a declared parameter of the function.
    * 
    * @param parameter_index index of the parameter starting at zero.
    * @return declared parameter of the function
    */
   public QName getParameter(final int parameter_index)
   {
      return this.parameterNames.get(parameter_index);
   }
   
   /**
    * Returns a declared parameter type of the function.
    * 
    * @param parameter_index index of the parameter starting at zero.
    * @return declared parameter type of the function
    */
   public SequenceType getParameterType(final int parameter_index)
   {
      return this.parameterTypes.get(parameter_index);
   }

   /**
    * Identifies function that can modify the state of an existing node. An
    * updating function can use the updating operations provided by the "XQuery
    * Update Facility" : insert, delete, replace, rename and transform.
    * 
    * @return true if this function performs updating operations and false
    *         otherwise
    */
   public boolean isUpdating()
   {
      return this.updating;
   }

   /**
    * Converts a given list of parameters to the declared sequence type.
    * 
    * @param parameters the list of sequence to be converted.
    * @return the converted sequence (may be the input one if no conversion was
    *         necessary).
    */
   public List<DrbSequence> convert(final List<DrbSequence> parameters)
      throws TypeCastException
   {
      if (!isVarArgs() || (parameters.size() != getArity()))
      {
         throw new IllegalArgumentException(
               "The function " + getName() + "() requires " +
               getArity() + " parameter(s)");
      }

      List<DrbSequence> typed_values = new ArrayList<DrbSequence>();
      for (int iparam = 0; iparam < parameters.size(); iparam++)
      {
         try
         {
            typed_values.add(this.getParameterType(iparam)
               .convert(parameters.get(iparam)));
         }
         catch (TypeCastException e)
         {
            throw new TypeCastException("Cannot convert the parameter " +
               this.getParameter(iparam) + " to " + getParameterType(iparam));
         }
      }
      return typed_values;
   }

   /**
    * Returns a detailed description of the function.
    * 
    * @return the description of the function.
    */
   public String toString()
   {
      if (this.returnType != null)
      {
         return this.name.getName() + "()" + this.returnType;
      }
      else
      {
         return this.name.getName() + "()";
      }
   }
}
