/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbSequence;

/**
 * Wraps zero or more results of XQuery language.
 */
final class DefaultResult extends DrbDefaultSequence
{
   /**
    * Logger
    */
   final static private Logger logger = Logger.getLogger(DefaultResult.class);

   /**
    * Constructor of an empty sequence
    */
   DefaultResult()
   {
      super();
   } // DefaultResult

   /**
    * Constructor of the default result with a singleton
    * 
    * @param singleton an item.
    */
   DefaultResult(final DrbItem singleton)
   {
      super(singleton);
   } // DefaultResult

   /**
    * Append a sub-sequence.
    * 
    * @param sequence sequence
    */
   void append(final DrbSequence sequence)
   {
      final int first = this.getLength();
      final int last = first + sequence.getLength();

      // Append all item in the sub-sequence
      for (int i = first; i < last; i++)
      {
         this.addItem(sequence.getItem(i - first));
      }
   } // append

} // DefaultResult
