/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import java.util.HashSet;
import java.util.Set;

/**
 * Declaration of a general XML-Schema type.
 */
public abstract class XsdType extends XsdComponent implements NodeValidator
{
   /**
    * extension method.
    */
   public final static int EXTENSION_METHOD = 1;

   /**
    * restriction method.
    */
   public final static int RESTRICTION_METHOD = 2;

   /**
    * name tag.
    */
   final static String NAME_TAG = "name";

   /**
    * extension tag.
    */
   final static String EXTENSION_TAG = "extension";

   /**
    * derivation tag.
    */
   final static String DERIVATION_BASE_TAG = "base";

   /**
    * restriction tag.
    */
   final static String RESTRICTION_TAG = "restriction";

   // ==================================================
   // Attributes part.
   // ==================================================
   /**
    * The base of this type.
    */
   protected XsdType base = null;

   /**
    * The derivation method.
    */
   protected int derivationMethod = this.EXTENSION_METHOD;

   /**
    * The XML-Schema of this type.
    */
   protected XmlSchema schema = null;

   /**
    * Name of this type definition.
    */
   protected String name = null;

   // ====================================================
   // Methods part.
   // ====================================================
   /**
    * Build a default type definition
    */
   protected XsdType()
   {
      this(null, null);
   } // XsdType

   /**
    * Build a default type definition
    * 
    * @param name String name
    * @param base XsdType
    */
   protected XsdType(final String name, final XsdType base)
   {
      this.name = name;
      this.base = base;
   } // XsdType

   /**
    * Returns the name of this type.
    * 
    * @return String the name
    */
   public final String getName()
   {
      return this.name;
   } // getName

   /**
    * Set the name of this type.
    * 
    * @param name the string
    */
   final void setName(final String name)
   {
      this.name = name;
   } // setName

   /**
    * Returns the base of this type.
    * 
    * @return XsdType
    */
   public final XsdType getBase()
   {
      return this.base;
   } // getBase

   /**
    * Set the schema of this type.
    * 
    * @param schema the schema of this type.
    */
   final void setSchema(final XmlSchema schema)
   {
      this.schema = schema;
   } // setSchema

   /**
    * Returns the schema of this type.
    * 
    * @return schema the schema of this type.
    */
   public final XmlSchema getSchema()
   {
      return this.schema;
   } // getSchema

   /**
    * Returns the local derivation of this type.
    * 
    * @return the set of derived
    */
   public final Set<XsdType> getDerivation()
   {
      if (this.schema != null)
      {
         return this.schema.getDerivation(this);
      }
      return new HashSet<XsdType>();
   } // getDerivation

   /**
    * Set the base of this type.
    * 
    * @param base the XsdType
    */
   final void setBase(final XsdType base)
   {
      this.base = base;
   } // setBase

   /**
    * Returns whether this type is complex or simple.
    * 
    * @return true or false
    */
   public abstract boolean isComplex();

   /**
    * Returns the simple content of this type.
    * 
    * @return XsdSimpleType
    */
   public abstract XsdSimpleType getDatatype();

   /**
    * Returns the structure of this type.
    * 
    * @return XsdComplexType
    */
   public abstract XsdComplexType getStructure();

   /**
    * Returns a string description of this type.
    * 
    * @return String name
    */
   public String toString()
   {
      if (this.getName() == null)
      {
         return "";
      }
      return this.getName();
   } // toString

} // XsdType
