/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

import org.apache.log4j.Logger;

/**
 * Random Access File Data.
 */
class RandomAccessFileData extends RandomAccessData
{

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(RandomAccessFileData.class);

   /**
    * The wrapped random access file.
    */
   RandomAccessFile file;

   /**
    * The remaining bit position.
    */
   int bitPosition = 0;

   /**
    * The remaining bit value.
    */
   int bitValue = -1;

   /**
    * Creates a RandomAccessFileData from the specified file.
    * 
    * @param file The ramdomAccessFile
    */
   public RandomAccessFileData(final RandomAccessFile file)
   {
      this.file = file;
   }

   /**
    * Creates a RandomAccessFileData from the specified file.
    * 
    * @param file The file
    */
   public RandomAccessFileData(final File file) throws IOException
   {
      this.file = new RandomAccessFile(file, "rw");
   }

   /**
    * Finalize.
    * 
    * @throws Throwable the Exception raised by this method
    */
   protected void finalize() throws Throwable
   {
      this.file.close();
   }

   // ---
   // DataInput implementation.
   // ---

   /**
    * Reads one input byte and returns true if that byte is nonzero, false if
    * that byte is zero.
    * 
    * @return true if the buffer's current position is superior than 0, else
    *         return false
    * @throws IOException if an I/O error occurs.
    */
   public boolean readBoolean() throws IOException
   {
      return this.file.readBoolean();
   }

   /**
    * Reads and returns one input byte.
    * 
    * @return The byte at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public byte readByte() throws IOException
   {
      return this.file.readByte();
   }

   /**
    * Reads an input char and returns the char value.
    * 
    * @return The char value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public char readChar() throws IOException
   {
      return this.file.readChar();
   }

   /**
    * Reads eight input bytes and returns a double value.
    * 
    * @return The double value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public double readDouble() throws IOException
   {
      return this.file.readDouble();
   }

   /**
    * Reads four input bytes and returns a float value.
    * 
    * @return The float the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public float readFloat() throws IOException
   {
      return this.file.readFloat();
   }

   /**
    * Reads some bytes from an input stream and stores them into the buffer
    * array b.
    * 
    * @param b The array into which bytes are to be read
    * @throws IOException if an I/O error occurs.
    */
   public void readFully(final byte[] b) throws IOException
   {
      if (this.bitPosition > 0)
      {
         this.readFully(b, 0, b.length);
      }
      else
      {
         this.file.read(b);
      }
   }

   /**
    * Reads len bytes from an input stream.
    * 
    * @param b The array into which bytes are to be read
    * @param off The offset within the array of the first byte to be read; must
    *           be non-negative and no larger than <tt>b.len</tt>
    * @param len The maximum number of bytes to be read to the given array; must
    *           be non-negative and no larger than <tt>b.len - off</tt>
    * @throws IOException if an I/O error occurs.
    */
   public void readFully(final byte[] b, final int off, final int len)
         throws IOException
   {
      if (this.bitPosition > 0)
      {
         final int bit_pos = this.bitPosition;
         final int comp_bit_pos = 8 - this.bitPosition;
         final byte[] buffer = new byte[len + 1];
         if (this.bitValue == -1)
         {
            this.file.read(buffer, off, len + 1);
         }
         else
         {
            this.file.read(buffer, off + 1, len);
            buffer[off] = (byte) this.bitValue;
         }
         final int count = len;
         for (int i = 0; i < count; i++)
         {
            b[off + i] =
               (byte) (((buffer[i] & 0xff) << bit_pos) | ((buffer[i + 1] & 0xff) >>> comp_bit_pos));
         }
         this.bitValue = buffer[buffer.length - 1] & 0xff;
      }
      else
      {
         this.file.read(b, off, len);
      }
   }

   /**
    * Reads len bytes from an input stream.
    * 
    * @param b The array into which bytes are to be read
    * @param off The offset within the array of the first byte to be read; must
    *           be non-negative and no larger than <tt>b.len</tt>
    * @param len The number of bits to be read from the given array; must be
    *           non-negative and no larger than <tt>array.length - offset</tt>
    * @throws IOException if an I/O error occurs.
    */
   public void readFully(final byte[] b, final int off, final Length len)
         throws IOException
   {
      final int byte_len = (int) len.getLength();
      final int bit_len = len.getBitLength();

      if (bit_len == 0)
      {
         this.readFully(b, off, byte_len);
      }
      else if (this.bitPosition > 0)
      {
         final int bit_pos = this.bitPosition;
         final int comp_bit_pos = 8 - this.bitPosition;
         if (this.bitValue == -1)
         {
            this.file.read(b, off, byte_len + 1);
         }
         else
         {
            this.file.read(b, off + 1, byte_len);
            b[off] = (byte) this.bitValue;
         }
         this.bitValue = b[off + byte_len] & 0xff;
         for (int i = 0; i < byte_len; i++)
         {
            b[i + off] =
               (byte) (((b[i + off] & 0xff) << bit_pos) | ((b[i + off + 1] & 0xff) >>> comp_bit_pos));
         }
         if (this.bitPosition + bit_len <= 8)
         {
            b[off + byte_len] = (byte) ((b[off + byte_len] & 0xff) << bit_pos);
         }
         else
         {
            this.bitValue = this.file.read();
            b[off + byte_len] =
               (byte) (((b[off + byte_len] & 0xff) << bit_pos) | ((this.bitValue & 0xff) >>> comp_bit_pos));
         }
         this.bitPosition = (this.bitPosition + bit_len) % 8;
      }
      else
      {
         this.file.read(b, off, byte_len + 1);
         this.bitValue = b[off + byte_len] & 0xff;
         this.bitPosition = bit_len;
      }
   }

   /**
    * Reads four input bytes and returns an int value.
    * 
    * @return The int value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public int readInt() throws IOException
   {
      return this.file.readInt();
   }

   /**
    * Reads the next line of text from the input stream.
    * 
    * @return The string value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public String readLine() throws IOException
   {
      return this.file.readLine();
   }

   /**
    * Reads eight input bytes and returns a long value.
    * 
    * @return The long value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public long readLong() throws IOException
   {
      return this.file.readLong();
   }

   /**
    * Reads two input bytes and returns a short value.
    * 
    * @return The short value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public short readShort() throws IOException
   {
      return this.file.readShort();
   }

   /**
    * Reads one input byte, zero-extends it to type int, and returns the result,
    * which is therefore in the range 0 through 255.
    * 
    * @return The input byte
    * @throws IOException if an I/O error occurs.
    */
   public int readUnsignedByte() throws IOException
   {
      return this.file.readUnsignedByte();
   }

   /**
    * Reads one input byte, zero-extends it to type int, and returns the result,
    * which is therefore in the range 0 through 255.
    * 
    * @return The input byte
    * @throws IOException if an I/O error occurs.
    */
   public int readUnsignedShort() throws IOException
   {
      return this.file.readUnsignedShort();
   }

   /**
    * Makes an attempt to skip over n bytes of data from the input stream,
    * discarding the skipped bytes.
    * 
    * @param n bytes to skip
    * @return The input byte
    * @throws IOException if an I/O error occurs.
    */
   public int skipBytes(final int n) throws IOException
   {
      return this.file.skipBytes(n);
   }

   /**
    * Reads in a string that has been encoded using a modified UTF-8 format.
    * 
    * @return The string
    * @throws IOException if an I/O error occurs.
    */
   public String readUTF() throws IOException
   {
      return this.file.readUTF();
   }

   // ---
   // DataOuput implementation.
   // ---

   /**
    * Writes a boolean value to this output stream.
    * 
    * @param v The boolean to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeBoolean(final boolean v) throws IOException
   {
      this.file.writeBoolean(v);
   }

   /**
    * Writes to the output stream the eight low- order bits of the argument v.
    * 
    * @param v The int to write
    * @throws IOException if an I/O error occurs.
    */
   public final void writeByte(final int v) throws IOException
   {
      this.file.writeByte(v);
   }

   /**
    * Writes to the output stream the the len low-order bits of the argument v.
    * 
    * @param v The int to write
    * @param bit_len The number of bit to write
    * @throws IOException if an I/O error occurs.
    */
   public final void writeBits(final int v, final int bit_len)
         throws java.io.IOException
   {
      this.logger.debug("v=" + v + " (" + Integer.toBinaryString(v) + ") "
            + " len=" + bit_len + " bitValue="
            + Integer.toBinaryString(this.bitValue) + " offs="
            + this.file.getFilePointer() + " bit_offs=" + this.bitPosition);
      if (bit_len < 8)
      {
         byte val = 0;
         if (this.bitPosition == 0)
         {
            final int b = this.file.read();
            if (b != -1)
            {
               val = (byte) (b & 0xff);
               final long off = this.file.getFilePointer();
               this.file.seek(off);
            }
         }
         else if (this.bitValue != -1)
         {
            val = (byte) (this.bitValue & 0xff);
            final long off = this.file.getFilePointer();
            this.file.seek(off - 1);
            this.logger.debug("WriteBits: seeked to " + (off - 1));
         }
         this.logger.debug("val=" + Integer.toBinaryString(val & 0xff));

         if (this.bitPosition + bit_len <= 8)
         {
            final int mask =
               (0xff >>> this.bitPosition)
                     & (0xff << (8 - this.bitPosition - bit_len));
            this.logger.debug("mask=" + Integer.toBinaryString(mask));
            this.logger.debug("~mask=" + Integer.toBinaryString(mask ^ 0xff));
            this.bitValue =
               (val & (mask ^ 0xff))
                     | (((v & 0xff) << (8 - this.bitPosition - bit_len)) & mask);
            this.file.writeByte(this.bitValue);
         }
         else
         {
         }
         this.logger.debug("new bitValue="
               + Integer.toBinaryString(this.bitValue));
         this.bitPosition = (this.bitPosition + bit_len) % 8;
         if (this.bitPosition == 0)
         {
            this.bitValue = 0;
         }
      }
   }

   /**
    * Writes a char value, wich is comprised of two bytes, to the output stream.
    * 
    * @param v The char to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeChar(final int v) throws IOException
   {
      this.file.writeChar(v);
   }

   /**
    * Writes every character in the string s, to the output stream, in order,
    * two bytes per character.
    * 
    * @param s The string to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeChars(final String s) throws IOException
   {
      this.file.writeChars(s);
   }

   /**
    * Writes a string to the output stream.
    * 
    * @param s The string to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeBytes(final String s) throws IOException
   {
      this.file.writeBytes(s);
   }

   /**
    * Writes a double value, which is comprised of eight bytes, to the output
    * stream.
    * 
    * @param v The double to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeDouble(final double v) throws IOException
   {
      this.file.writeDouble(v);
   }

   /**
    * Writes a float value, which is comprised of four bytes, to the output
    * stream.
    * 
    * @param v The float to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeFloat(final float v) throws IOException
   {
      this.file.writeFloat(v);
   }

   /**
    * Writes to the output stream all the bytes in array b.
    * 
    * @param b The byte[] to write
    * @throws IOException if an I/O error occurs.
    */
   public final void write(final byte[] b) throws IOException
   {
      if (this.bitPosition == 0)
      {
         this.file.write(b);
      }
      else
      {
         this.write(b, 0, new Length(b.length, 0));
      }
   }

   /**
    * Insert into the output stream all the bytes in array b.
    * 
    * @param b The byte[] to write
    * @throws IOException if an I/O error occurs.
    */
   void insert(final byte[] b) throws IOException
   {
      throw new IOException("Insert not supported");
   }

   /**
    * Writes len bytes from array b, in order, to the output stream.
    * 
    * @param b The array from which bytes are to be read
    * @param off The offset within the array of the first byte to be read; must
    *           be non-negative and no larger than <tt>array.length</tt>
    * @param len The number of bytes to be read from the given array; must be
    *           non-negative and no larger than <tt>array.length - offset</tt>
    * @throws IOException if an I/O error occurs.
    */
   public void write(final byte[] b, final int off, final int len)
         throws IOException
   {
      if (this.bitPosition == 0)
      {
         this.file.write(b, off, len);
      }
      else
      {
         this.write(b, off, new Length(len, 0));
      }
   }

   /**
    * Writes an int value, which is comprised of four bytes, to the output
    * stream.
    * 
    * @param v The int to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeInt(final int v) throws IOException
   {
      this.file.writeInt(v);
   }

   /**
    * Writes to the output stream the eight low-order bits of the argument b.
    * 
    * @param v The int to write
    * @throws IOException if an I/O error occurs.
    */
   public void write(final int v) throws IOException
   {
      this.file.write(v);
   }

   /**
    * Writes a long value, which is comprised of eight bytes, to the output
    * stream.
    * 
    * @param v The long to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeLong(final long v) throws IOException
   {
      this.file.writeLong(v);
   }

   /**
    * Writes two bytes to the output stream to represent the value of the
    * argument.
    * 
    * @param v The int to write into short
    * @throws IOException if an I/O error occurs.
    */
   public void writeShort(final int v) throws IOException
   {
      this.file.writeShort(v);
   }

   /**
    * Writes two bytes of length information to the output stream, followed by
    * the Java modified UTF representation of every character in the string s
    * 
    * @param str The string to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeUTF(final String str) throws IOException
   {
      this.file.writeUTF(str);
   }

   /**
    * Writes len bits from array b, in order, to the output stream.
    * 
    * @param b The array from which bytes are to be read
    * @param off The offset within the array of the first byte to be read; must
    *           be non-negative and no larger than <tt>array.length</tt>
    * @param len The number of bits to be read from the given array; must be
    *           non-negative and no larger than <tt>array.length - offset</tt>
    * @throws IOException if an I/O error occurs.
    */
   public void write(final byte[] b, final int off, final Length len)
         throws IOException
   {
      final int byte_len = (int) len.getLength();
      final int bit_len = len.getBitLength();
      final int comp_bit_pos = 8 - this.bitPosition;
      this.logger.debug("writeBytes: in file_pos=" + this.file.getFilePointer()
            + ", file_size=" + this.file.length());
      this.logger.debug("writeBytes: in bitPosition=" + this.bitPosition);
      this.logger.debug("writeBytes: in bitValue="
            + new fr.gael.drb.value.BinaryInteger(this.bitValue, 9));
      for (int i = 0; i < byte_len + (7 + bit_len) / 8; i++)
      {
         this.logger.debug("writeBytes: inValue[" + i + "]="
               + new fr.gael.drb.value.BinaryInteger(b[off + i] & 0xff, 8));
      }
      // Case of byte-align offset
      if (this.bitPosition == 0)
      {
         if (byte_len > 0)
         {
            this.logger.debug("write(b,off,len): Writing " + byte_len
                  + " first bytes "
                  + new fr.gael.drb.value.BinaryInteger(b[off] & 0xff, 8));
            this.file.write(b, off, byte_len);
         }
      }
      // Case of 1 byte or more
      else if (this.bitPosition + 8 * byte_len + bit_len >= 8)
      {
         final byte[] buffer =
            new byte[byte_len + (bit_len + this.bitPosition) / 8];
         /**
          * Shift the buffer to the right at bitPosition i 0 i-1 i i+1 n bits:
          * 12345678 12345678 12345678 12345678 12345678 file AAAAAAAA BBBBBBBB
          * CCCCCCCC DDDDDDDD EEEEEEEE b: WWWWWWWW XXXXXXXX YYYYYYYY ZZZZZZ..
          * bitPos ###~~~~~ ~~~~~~~~ ~~~~~~~~ ~~~~~~~~ ~~~~~~~~ buffer: AAAWWWWW
          * WWWXXXXX XXXYYYYY YYYZZZZZ ZEEEEEEE bits: 12312345 67812345 67812345
          * 67812345 62345678
          */
         // Case of first byte
         final long fp = this.file.getFilePointer();

         if (this.bitValue == -1)
         {
            final int v = this.file.read();
            if (v != -1)
            {
               this.bitValue = (v & 0xff);
               this.file.seek(fp);
            }
            else
            {
               this.bitValue = 0;
            }
         }
         else
         {
            this.file.seek(fp - 1);
         }
         buffer[0] =
            (byte) (((b[off] & 0xff) >>> this.bitPosition) | (this.bitValue & (0xff << comp_bit_pos)));

         // Case of bytes in the middle part (neither first or last)
         for (int i = buffer.length - 1; i > 0; i--)
         {
            buffer[i] =
               (byte) (((b[off + i] & 0xff) >>> this.bitPosition) | ((b[off + i
                     - 1] & 0xff) << comp_bit_pos));
         }
         for (int j = 0; j < buffer.length; j++)
         {
            this.logger.debug("write(b,off,len): " + "Shifted byte[" + j + "]="
                  + new fr.gael.drb.value.BinaryInteger(buffer[j] & 0xff, 8));
         }
         this.file.write(buffer);
         this.bitValue = -1;
      }
      if ((this.bitPosition + bit_len) % 8 != 0)
      {
         final long fp = this.file.getFilePointer();
         int v = this.bitValue;
         if (this.bitValue == -1)
         {
            v = this.file.read();
            this.file.seek(fp);
         }
         else
         {
            this.file.seek(fp - 1);
         }
         if (v == -1)
         {
            v = 0;
         }
         int mask = 0; // 1 if the buffer is visible and false otherwise
         /**
          * Case of more than 8 bits to write (split bits). index N-1 N bits:
          * 12345678 12345678 12345678 bitPos: #####~~~ ~~~~~~~~ in: CCCCCCCC
          * DDDDDDDD EEEEEEEE b: YYYYYYYY ZZZZZ... out: XXXXXYYY YYYYYZZZ
          * ZZEEEEEE bits: 45678123 45678123 45123456
          */
         if (this.bitPosition + bit_len > 8)
         {
            mask = 0xff << (16 - this.bitPosition - bit_len);
            this.bitValue = ((b[off + byte_len] & 0xff) << comp_bit_pos) & 0xff;
         }
         /**
          * Case of less than 8 remaining bits to write (mixed). index N-1 N
          * bitPos: #####~~~ ~~~~~~~~ in: CCCCCCCC DDDDDDDD 1: YYYYYYYY ZZ......
          * out: XXXXXYYY YYYYYZZD
          */
         else if (byte_len > 0)
         {
            mask = 0xff << (8 - this.bitPosition - bit_len);
            if (bit_len > 0)
            {
               this.bitValue =
                  ((b[off + byte_len] & 0xff) >>> this.bitPosition)
                        | ((b[off + byte_len - 1] & 0xff) << comp_bit_pos);
            }
            else
            {
               this.bitValue = ((b[off + byte_len - 1] & 0xff) << comp_bit_pos);
            }
         }
         else
         /**
          * Case of less than 8 bits to write. bitPos: ###~~~~~ in: CCCCCCCC b:
          * YYY..... out: CCCYYYCC
          */
         if (bit_len > 0)
         {
            mask =
               (0xff >>> this.bitPosition)
                     & (0xff << (8 - this.bitPosition - bit_len));
            this.bitValue = ((b[off + byte_len] & 0xff) >>> this.bitPosition);
         }
         this.logger.debug("writeBytes: File bits="
               + new fr.gael.drb.value.BinaryInteger(v, 8));
         this.logger.debug("writeBytes: Shift bits="
               + new fr.gael.drb.value.BinaryInteger(this.bitValue, 8));
         this.logger.debug("writeBytes: mask="
               + new fr.gael.drb.value.BinaryInteger(mask, 8));
         this.bitValue = (v & (mask ^ 0xff)) | (this.bitValue & mask);
         this.file.write(this.bitValue);
      }
      this.bitPosition = (this.bitPosition + bit_len) % 8;
      if (this.bitPosition == 0)
      {
         this.bitValue = -1;
      }
      this.logger.debug("writeBytes: out bitPosition=" + this.bitPosition);
      this.logger.debug("writeBytes: out bitValue="
            + new fr.gael.drb.value.BinaryInteger(this.bitValue, 8));
   }

   /**
    * Closes this random access file stream and releases any system resources
    * associated with the stream.
    * 
    * @throws IOException if an I/O error occurs.
    */
   void close() throws java.io.IOException
   {
      this.file.close();
   }

   /**
    * Returns the number of bytes that can be read (or skipped over) from this
    * input stream without blocking by the next caller of a method for this
    * input stream. The next caller might be the same thread or or another
    * thread.
    * 
    * @throws java.io.IOException if an I/O error occurs.
    * @return the number of byte that can be read without blocking.
    */
   public final long available() throws java.io.IOException
   {
      return this.file.length() - this.file.getFilePointer();
   }

   /**
    * Sets the data-pointer offset, measured from the beginning of this data, at
    * which the next read or write occurs.
    * 
    * @param pos The new position value; must be non-negative and no larger than
    *           the current limit
    * @throws IOException if an I/O error occurs.
    */
   final void seek(final long pos) throws IOException
   {
      this.file.seek(pos);
      this.bitPosition = 0;
      this.bitValue = -1;
   }

   /**
    * Sets the data-pointer offset, measured from the beginning of this data, at
    * which the next read or write occurs.
    * 
    * @param pos The new position value; must be non-negative and no larger than
    *           the current limit
    * @param bit_pos The new position value; must be non-negative and no larger
    *           than the current limit
    * @throws java.io.IOException This exception is raised, If the buffer's
    *            current position is not smaller than its limit
    */
   final void seek(final long pos, final int bit_pos)
         throws java.io.IOException
   {
      this.file.seek(pos);
      this.bitPosition = bit_pos;
      this.bitValue = -1;
   }

   /**
    * Returns the length of this dta.
    * 
    * @return long The buffer capacity
    * @throws IOException if an I/O error occurs.
    */
   final long length() throws java.io.IOException
   {
      return this.file.length();
   }

   /**
    * Set the length of this data.
    * 
    * @return long The buffer capacity
    * @throws java.io.IOException This exception is raised, If the buffer's
    *            current position is not smaller than its limit
    */
   void setLength(final long len) throws java.io.IOException
   {
      this.file.setLength(len);
   }

   /**
    * Main.
    */
   public static void main(final String[] args) throws Exception
   {
      File temp_file = File.createTempFile("sdf-bit5-", ".tmp");
      RandomAccessFileData file = new RandomAccessFileData(temp_file);

      System.out.println("Writing 5-bits unsigned values");
      for (int i = 0; i < 32; i++)
      {
         logger.debug("Writing " + i + " on 5-bits.");
         file.writeInteger(new fr.gael.drb.value.Int(i), new Length(0, 5),
               false);
      }
      /*
       * file.seek(0); byte[] buf_5 = new byte[20]; for (int i=0; i<20; i++) {
       * buf_5[i] = file.readByte(); } java.math.BigInteger int_5 = new
       * java.math.BigInteger(buf_5); for (int i=159; i>=0; i--) {
       * System.out.print(int_5.testBit(i) ? "1" : "0"); if (i % 5 == 0)
       * System.out.println(""); }
       */
      file.seek(0);
      for (int i = 0; i < 32; i++)
      {
         final int val = file.readInteger(new Length(0, 5), false).intValue();
         if (val != i)
         {
            System.err.println("Expected  " + i + " instead of " + val);
            return;
         }
         else
         {
            System.out.println(new fr.gael.drb.value.BinaryInteger(val, 5));
         }
      }
      System.out.println("");

      temp_file = File.createTempFile("sdf-bit7-", ".tmp");
      file = new RandomAccessFileData(temp_file);

      System.out.println("Writing 7-bits values");
      file.seek(0);
      for (int i = 0; i < 128; i++)
      {
         logger.debug("Writing " + i + " on 7-bits.");
         file.writeInteger(new fr.gael.drb.value.Int(i), new Length(0, 7),
               false);
      }
      /*
       * file.seek(0); byte[] buf_7 = new byte[20]; for (int i=0; i<20; i++) {
       * buf_7[i] = file.readByte(); } java.math.BigInteger int_7 = new
       * java.math.BigInteger(buf_7); for (int i=159; i>=0; i--) {
       * System.out.print(int_7.testBit(i) ? "1" : "0"); if ((159 - i + 1) % 7 ==
       * 0) System.out.println(""); } System.out.println("");
       */
      file.seek(0);
      for (int i = 0; i < 128; i++)
      {
         final int val = file.readInteger(new Length(0, 7), false).intValue();
         if (val != i)
         {
            System.err.println("Expected  " + i + " instead of " + val);
            return;
         }
      }
      System.out.println("");

      System.out.println("Writing 13-bits values");
      temp_file = File.createTempFile("sdf-bit13-", ".tmp");
      file = new RandomAccessFileData(temp_file);
      file.seek(0);
      for (int i = 0; i < 8192; i++)
      {
         logger.debug("Writing " + i + " on 13-bits.");
         file.writeInteger(new fr.gael.drb.value.Int(i), new Length(0, 13),
               false);
      }
      file.seek(0);
      final byte[] buf_13 = new byte[80];
      for (int i = 0; i < buf_13.length; i++)
      {
         buf_13[i] = file.readByte();
      }
      /*
       * java.math.BigInteger int_13 = new java.math.BigInteger(buf_13); int
       * j=0; for (int i=buf_13.length*8-1; i>=0; i--) {
       * System.out.print(int_13.testBit(i) ? "1" : "0"); if ((buf_13.length*8 -
       * i) % 13 == 0) System.out.println(" - " + (j++)); }
       */
      file.seek(0);
      for (int i = 0; i < 8192; i++)
      {
         final int val = file.readInteger(new Length(0, 13), false).intValue();
         if (val != i)
         {
            System.err.println("Expected  " + i + " instead of " + val);
            break;
         }
      }
      System.out.println("");
   }

} // RandomAccessFileData
