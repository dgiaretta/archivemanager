/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.file;

import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.Vector;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbFactoryImpl;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.DrbNodesChangeEvent;
import fr.gael.drb.DrbUpdateImpl;
import fr.gael.drb.impl.DrbFactoryResolver;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.impl.DrbProvider;
import fr.gael.drb.value.Value;

/**
 * File or Directory of a local file system. This implementation breaks down the
 * local file system into file and directories. It is useful to browse the local
 * file system as a file manager. The file nodes have no specific attribute.
 * <p>
 * <b>Thread safe strategy:</b> This class is thread safe. The strategy to
 * prevent access collisions between two or more treads, all the writting
 * accesses to the ressources (i.e. attributes of this class) that may be
 * changed by a thread are synchronised. Only the accesses occurring after the
 * constructor are affected by this rule.
 * </p>
 */
public final class FileNode extends DrbNodeImpl
{

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(FileNode.class);

   /**
    * Java File wrapped by the current node. This attribute is used to access
    * the system information of the wrapped file. For instance, it enables to
    * identify the children of a directory, the parent of any regular file or
    * identify the root node.
    */
   java.io.File file;

   /**
    * Cached list of children. This list of Java Files is used to cache and
    * therefore optimize the accesses that require the list of children of the
    * current node. This strategy may however create discrepencies is the file
    * system is updated. For instance if a file is created as child of a
    * directory, the children list will not be automatically updated and several
    * calls to getChildren() will never take this change into account. It has
    * been decided to use this optimization because it is very efficient and the
    * need of change management of the file system is not yet clearly
    * identified.
    */
   private java.io.File[] children;
   
   private DrbNodeList drbChildren;

   /**
    * Cached parent of the current node.
    */
   private FileNode parent;

   /**
    * index of the file
    */
   private int index = -1;

   /**
    * The file provider.
    */
   private FileProvider provider;
   /**
    * List of stream to be close on node close request
    */
   private Vector<Closeable>closeables=new Vector<Closeable>();

   /**
    * Builds a File instance. This contructors sets the provided Java File and
    * caches its children. This implementation does not check if the provided
    * parameter is a null reference. In such case, the implementation may become
    * instable without warning. If already known, the parent of the current node
    * can be passed. This is an optimization avoiding re-creation of children
    * lists. Note: all the children collections created by this operation are
    * sorted. For optimization, if the children and/or the parent children are
    * already known, they can be passed in parameter. This avoid reconstruction
    * of the children lists. For the parnet children list does not change from a
    * node to any of its sibling.
    * 
    * @param file The Java File to be wrapped.
    * @param parent The parent file if already known or null.
    */
   FileNode(java.io.File file, final FileNode parent)
   {
      /**
       * Checks that non null reference has been passed as file. This may raise
       * an exception in a future implementation.
       */
      if (file == null)
      {
         return;
      }

      /**
       * Set the reference to the file.
       */
      try
      {
         final String path = file.getPath();
         if (!file.isAbsolute() || (parent == null))
         {
            file = file.getCanonicalFile();
         }
      }
      catch (final Exception e)
      {
         this.logger.debug(e.getMessage());
         // e.printStackTrace();
      }
      this.file = file;
      this.parent = parent;
      this.children = null;
   }

   /**
    * Indicates whether this node is "equal to" to another node. See
    * Object.equals() for the general contract of this method.
    * 
    * @param obj another value.
    * @return true if this object is the same as the obj argument
    */
   public boolean equals(final Object obj)
   {
      // Check reference equality
      if (this == obj)
      {
         return true;
      }

      // Check I/O
      if (obj instanceof FileNode)
      {
         final FileNode file_node = (FileNode) obj;
         return file_node.file.equals(this.file);
      }

      // Otherwise the object is different
      return false;
   } // equals

   /**
    * Check if this node may have multiple occurrence
    * 
    * @return Always return true since filenames shall be unique within a
    *         directory.
    */
   public boolean allowsMultiOccurrence()
   {
      return false;
   } // allowsMultiOccurrence

   /**
    * Closes this node and releases any system resources associated with the
    * implementation. A closed node cannot perform input or output operations
    * and cannot be reopened.
    * 
    * @param deep if this flag is disabled, the implementation shall not release
    *           the ressources shared with the descendants. WARNING: This
    *           parameter is not fully supported.
    */
   public void close(final boolean deep)
   {
      for (Closeable closeable: this.closeables)
      {
         try
         {
            closeable.close();   
         }
         catch (Exception e)
         {
            // Probably already closed.
         }
      }  
   }

   /**
    * Returns the provider of this file.
    * 
    * @return DrbProvider
    */
   public DrbProvider getProvider()
   {
      if (this.provider == null)
      {
         this.provider = new FileProvider(this);
      }
      return this.provider;
   }

   /**
    * Returns the chilren list of the specified file. The children are sorted
    * with directories first diresgrading the other properties of the children
    * (e.g. hidden. size, etc.). It is not necessary to check the input file is
    * a directory. This operation does it for the caller and return null (non
    * verbose) if not a directory.
    * <p>
    * <b>Synchronisation note:</b> The operation synchronises the acesses to
    * the file attribute that is shared between several instances.
    * </p>
    * 
    * @param file A reference to the parent file.
    * @return a reference to the array of children or null if the parent has no
    *         child.
    */
   private final java.io.File[] getSortedChildren(final java.io.File file)
   {
      /**
       * The following block synchronizes the file attribute in order to assure
       * the several values read from this class are coherent.
       */
      java.io.File[] children;

      synchronized (file)
      {
         /**
          * Check input file.
          */
         if (file == null)
         {
            this.logger.error("File.getSortedChildren() : Null file pointer.");
            return null;
         }

         /**
          * Get the children list (unsorted).
          */
         children = file.listFiles();
      }

      /**
       * Checks that this file has at least one child.
       */
      if (children == null)
      {
         return new java.io.File[] {};
      }

      /**
       * Sort the children alphabetically if "mustSort" option" is true.
       */
      try
      {
         if (((FileProvider) this.getProvider()).mustSort)
         {
            Arrays.sort(children);
         }
      }
      catch (final ClassCastException e)
      {
         this.logger.error("File.getSortedChildren() : "
               + "Cannot sort children list.");
         this.logger.error("File.getSortedChildren() : " + e.getMessage());
      }

      /**
       * Put directories on top position. The list of children is sorted in
       * order to place the directory in top. This sort algorithm benefit by the
       * previous sorting pass and therefore consider the list previously order
       * in alphabetical order.
       */
      java.io.File aux_file = null;
      int last_dir = -1;

      for (int ifile = 0; ifile < children.length; ifile++)
      {
         if (children[ifile].isDirectory())
         {
            aux_file = children[ifile];

            for (int ishift = ifile; ishift > last_dir + 1; ishift--)
            {
               children[ishift] = children[ishift - 1];
            }

            children[last_dir + 1] = aux_file;
            last_dir = last_dir + 1;
         }
      }

      return children;
   }

   /**
    * Returns the name of the wrapped file. This name is the basename of the
    * file without absolute or relative component of the path. This operation
    * wraps the java.io.File.getName() operation. The returned reference cannot
    * be null but the string may be empty (i.e. ""). This may occur for UNIX
    * root nodes that have no specific name.
    * <p>
    * <b>Synchronisation note:</b> no synchronisation performed.
    * </p>
    * 
    * @return The file name in the local file system.
    */
   public final String getName()
   {
      return this.file.getName();
   }

   /**
    * Returns the index of the file in the parent children list. If the current
    * node is a root node it has no parent and its index is 0. This
    * consideration (i.e. index = 0) may not be true for Windows or DOS file
    * systems that have several root nodes.
    * <p>
    * <b>Synchronisation note:</b> The accesses to the cache of parent children
    * are synchronized.
    * </p>
    * 
    * @return Index of the file within is parent children list or -1 in case of
    *         node inconsitcency.
    */
   public final int getIndex()
   {
      if (this.index >= 0)
      {
         return this.index;
      }

      /**
       * Returns 0 index if the current has no parent. This may occur only if
       * the current node is the root node.
       */
      if (this.getParent() == null)
      {
         return 0;
      }

      /**
       * Make sure the parent children list will not be changed during its
       * processing.
       */
      synchronized (this.parent)
      {
         /**
          * Seach the current node in the parent children list. The search keys
          * are the names of the files.
          */
         final String name = this.getName();
         final int count = this.parent.getChildrenCount();
         for (int ifile = 0; ifile < count; ifile++)
         {
            if (name.equals(this.parent.children[ifile].getName()))
            {
               this.index = ifile;
               return ifile;
            }
         }
      }

      /**
       * Returns a negative value if the search failed.
       */
      return -1;
   }

   /**
    * Returns the root node of the current node. The root node determination is
    * performed by looking recursively for the parents from the current node.
    * This strategy has been selected because some file system such as Windows
    * or DOS have several root nodes. It was necessary to retreive the root node
    * holding the current node.
    * <p>
    * <b>Synchronisation note:</b> no synchronisation performed.
    * </p>
    * 
    * @return A reference to the root node of the current one.
    */
   public final DrbNode getRoot()
   {
      FileNode current_root = this;
      java.io.File parent;
      java.io.File current_file = this.file;

      while ((parent = current_file.getParentFile()) != null)
      {
         current_file = parent;
         if (current_root != null)
         {
            current_root = current_root.parent;
         }
      }

      /**
       * Returns a reference to the root node. This code is optimized to
       * benefitby the precomputed ancestors of the current node. If the current
       * node is the root node, a reference to it is returned without creating a
       * new instance of node.
       */
      if (current_root != null)
      {
         return current_root;
      }
      else
      {
         return new FileNode(current_file, null);
      }
   }

   /**
    * Returns the absolute path of the file. Because file implementation relies
    * directly on the file system, this operation delegates the path generation
    * to the wrapped file. The returned path is a canonical path (unique for
    * with for instance removal redundant names such as "." or ".." from the
    * path). Because file system queries are required to process the path and
    * because that queries may fail (for example because of permissions). In
    * such case the operation returns null without exception.
    * <p>
    * <b>Synchronisation note:</b> the entire operation is synchronized.
    * </p>
    * 
    * @return The canonical path of the wrapped file.
    */
   public synchronized final String getPath()
   {
      if (this.file != null)
      {
         final String path = this.file.toURI ().getPath();
         return path;
      }
      else
      {
         return null;
      }
   }

   /**
    * The file namespace. Basically, until a schema has not been affected to the
    * files tree, no namespace is attached to its nodes. Thus, because the
    * support of schema definition attached to the node is not supported, null
    * is returned systematically.
    * 
    * @return null.
    */
   public final String getNamespaceURI()
   {
      return null;
   }

   /**
    * The value type of the file. The files have a binary content while
    * directories have child nodes only.
    * 
    * @return NULL_ID for directories and BINARY_ID for files.
    */
   public final int getValueType()
   {
      if (this.file.isDirectory())
      {
         return Value.NULL_ID;
      }
      else
      {
         return Value.BINARY_ID;
      }
   }

   /**
    * The value of the node. The content of the file is always represented by a
    * binary value.
    * 
    * @return the content of the file as a binary value or null for directories.
    */
   public final Value getValue()
   {
      if (this.file.isFile())
      {
         return new FileValue(this);
      }
      else
      {
         return null;
      }
   }

   /**
    * The attributes of the node. The file nodes have no specific attribute and
    * this operation returns therefore a null value at each call. <b>The
    * attributes are:</b>
    * <p>
    * The following table specifies the attributes that are available for a
    * file. No atribute is provided optionally. The type of the attribute are
    * expressed using the type identifer of the fr.gael.drb.value.Value class.
    * </p>
    * <p>
    * <table border=1 cellspaceing=0 cellpadding=2>
    * <tr>
    * <td><b>Name</b></td>
    * <td><b>Description</b></td>
    * <td><b>Value Type</b></td>
    * </tr>
    * <tr>
    * <td>size</td>
    * <td>the length of the file in bytes. If the file is a directory, the size
    * is equal to 0. </td>
    * <td>UNSIGNED_LONG_ID</td>
    * </tr>
    * <tr>
    * <td>modified</td>
    * <td>the date the file was last modified.</td>
    * <td>DATE_ID</td>
    * </tr>
    * <tr>
    * <td>readable</td>
    * <td>true whether the application can read the file. false otherwise.</td>
    * <td>BOOLEAN_ID</td>
    * </tr>
    * <tr>
    * <td>writable</td>
    * <td>true whether the application can write the file. false otherwise.</td>
    * <td>BOOLEAN_ID</td>
    * </tr>
    * <tr>
    * <td>hidden</td>
    * <td>true whether the file is hidden. false otherwise.</td>
    * <td>BOOLEAN_ID</td>
    * </tr>
    * </table>
    * </p>
    * <p>
    * <b>Synchronisation note:</b> the accesses to the file are synchronized.
    * </p>
    * 
    * @return the lsit of attributes of the file.
    */
   public final DrbAttributeList getAttributes()
   {
      /**
       * The attribute reference for all attributes.
       */
      DrbAttribute attr = null;

      /**
       * Creates output attribute list.
       */
      final DrbDefaultAttributeList attr_list = new DrbDefaultAttributeList();

      synchronized (this.file)
      {
         /**
          * Adds the "directory" attribute"
          */
         attr = new FileAttribute("directory", this);
         attr_list.add(attr);

         /**
          * Adds the "size" attribute"
          */
         attr = new FileAttribute("size", this);
         attr_list.add(attr);

         /**
          * Adds the "modified" attribute"
          */
         attr = new FileAttribute("modified", this);
         attr_list.add(attr);

         /**
          * Adds the "readable" attribute"
          */
         attr = new FileAttribute("readable", this);
         attr_list.add(attr);

         /**
          * Adds the "writable" attribute"
          */
         attr = new FileAttribute("writable", this);
         attr_list.add(attr);

         /**
          * Adds the "hidden" attribute"
          */
         attr = new FileAttribute("hidden", this);
         attr_list.add(attr);
      }

      return attr_list;
   }

   /**
    * Returns the parent file. A file or directory of a file system has a parent
    * but the apart the root node.
    * 
    * @return A reference to the parent file if any or null otherwise.
    */
   public final DrbNode getParent()
   {
      if (this.parent == null)
      {
         java.io.File parent_file = this.file.getParentFile();

         if (parent_file == null)
         {
            final java.io.File absolute_file = new java.io.File(this.getPath());

            parent_file = absolute_file.getParentFile();
         }

         if (parent_file != null)
         {
            this.parent = new FileNode(parent_file, null);
            this.parent.setListenerList(this.getListenerList()); // TBC
         }
      }

      return this.parent;
   }

   /**
    * Returns the children list of the current directory. If the current node
    * does not wrap a directory or if it has no child, the returned reference
    * may be null. This implementation returns a reference to a
    * DrbDefaultNodeList.
    * 
    * @return The list of children or null otherwise.
    */
   public final DrbNodeList getChildren()
   {
      if (drbChildren==null)
         this.drbChildren = _getChildren();
      return this.drbChildren;
   }
   
   public final DrbNodeList _getChildren()
   {
      /**
       * Build the children if not done.
       */
      if (this.children == null)
      {
         this.children = this.getSortedChildren(this.file);
      }

      /**
       * Checks the current node has at least one child.
       */
      if ((this.children == null) || (this.children.length == 0))
      {
         return null;
      }

      final DrbDefaultNodeList list = new DrbDefaultNodeList();

      /**
       * Initialize the output node list. The nodes are created benefiting from
       * the children list as parent children list of the created nodes.
       */
      for (int ifile = 0; ifile < this.children.length; ifile++)
      {
         list.add(new FileNode(this.children[ifile], this));
      }

      return list;
   }

   /**
    * Checks if any child exists. Returns whether the current node has at least
    * a child.
    * 
    * @return true if this node has any children, false otherwise.
    */
   public final boolean hasChild()
   {
      if (this.children != null)
      {
         return (this.children.length > 0);
      }
      else
      {
         return this.file.isDirectory();
      }
   }

   /**
    * Reference to a specific child. The child is extracted from the children
    * list previously set.
    * 
    * @param index The position of the node to retreive starting from 0 and not
    *           greater or equal to the number of children.
    * @return A reference to specified child or null if no such node.
    */
   public DrbNode getChildAt(final int index)
   {
      if ((index < 0) || (index >= this.getChildrenCount()))
      {
         return null;
      }
      else
      {
         return new FileNode(this.children[index], this);
      }
   } // getChildAt

   /**
    * Returns an occurence of child matching a specific name. The occurence
    * number starts from 1.
    * 
    * @param name The name to match.
    * @param occurence The occurence number of the desired child.
    * @return A reference to the child or null is not found.
    */
   public DrbNode getNamedChild(final String name, final int occurence)
   {
      /**
       * Checks parameters.
       */
      if ((name == null) || (occurence <= 0))
      {
         this.logger.error("File.getNamedChild(): Invalid parameters.");
         return null;
      }

      /**
       * General case. Only one occurence of name is possible in file systems.
       */
      if (occurence == 1)
      {
         final java.io.File child_file = new java.io.File(this.file, name);

         if (child_file.exists() != true)
         {
            return null;
         }

         return new FileNode(child_file, this);
      }

      return null;
   }

   /**
    * Number of files or directory hold by the current node (directory). Returns
    * the number of children belonging to the current node.
    * 
    * @return The number of children of the current node (directory).
    */
   public final int getChildrenCount()
   {
      /**
       * Build the children if not done.
       */
      if (this.children == null)
      {
         this.children = this.getSortedChildren(this.file);
      }

      return this.children.length;
   }

   /**
    * Tests if a specific implementation is supported. The current
    * implementation supports : FileInputStream, FileOutputStream,
    * RandomAccessFile and java.io.File implementation.
    * 
    * @see java.io.FileInputStream
    * @see java.io.FileOutputStream
    * @see java.io.RandomAccessFile
    * @see java.io.File
    * @param api The requested implementation.
    * @return true if the implementation is supported and false otherwise.
    */
   public final boolean hasImpl(final Class api)
   {
      if (api == null)
      {
         return false;
      }
      if (api.isAssignableFrom(FileInputStream.class)
            || api.isAssignableFrom(FileOutputStream.class)
            || api.isAssignableFrom(RandomAccessFile.class)
            || api.isAssignableFrom(java.io.File.class) || (api == URL.class))
      {
         return true;
      }
      else
      {
         return super.hasImpl(api);
      }
   }

   /**
    * Returns a specific implementation of the node. Only regular file (i.e.
    * difference from directory) have specific implementations. The possible
    * implementations are FileInputStream, FileOutputStream, RandomAccessFile or
    * java.io.File. The returned implementation are instanciated from the Java
    * File embedded in the current node implementation. They are completely
    * disconnected from the current node and can be considered has effective
    * Java implementation and any reference to the current node can be
    * dismissed. The RandomAccessFile is opened in read and write mode.
    * 
    * @see FileInputStream
    * @see FileOutputStream
    * @see RandomAccessFile
    * @see java.io.File
    * @param api The requested implmentation.
    * @return A reference to the reqested implementation is supported or null
    *         otherwise.
    */
   public final Object getImpl(final Class api)
   {
      /**
       * Discards null file.
       */
      if ((this.file == null) || (api == null))
      {
         return null;
      }

      Object impl = null;

      /**
       * Case of FileInputStream request.
       */
      if (api.isAssignableFrom(FileInputStream.class))
      {
         // Return if file is a directory
         if (file.isDirectory())
         {
            return null;
         }

         try
         {
            impl = new FileInputStream(this.file);
            closeables.addElement((Closeable)impl);
         }
         catch (final FileNotFoundException e)
         {
            this.logger.error("fr.gael.drb.impl.file.File : "
                  + "Cannot create an instance of FileInputStream", e);
         }
         catch (final SecurityException e)
         {
            this.logger.error("fr.gael.drb.impl.file.File : "
                  + "Cannot create an instance of FileInputStream", e);
         }
      }
      /**
       * Case of FileOutputStream request.
       */
      else if (api.isAssignableFrom(FileOutputStream.class))
      {
         // Return if file is a directory
         if (file.isDirectory())
         {
            return null;
         }

         try
         {
            impl = new FileOutputStream(this.file);
            closeables.addElement((Closeable)impl);
         }
         catch (final FileNotFoundException e)
         {
            this.logger.error("fr.gael.drb.impl.file.File : "
                  + "Cannot create an instance of FileOutputStream");
            this.logger.error("fr.gael.drb.impl.file.File : " + e.getMessage());
         }
         catch (final SecurityException e)
         {
            this.logger.error("fr.gael.drb.impl.file.File : "
                  + "Cannot create an instance of FileOutputStream");
            this.logger.error("fr.gael.drb.impl.file.File : " + e.getMessage());
         }
      }
      /**
       * Case of RandomAccessFile request.
       */
      else if (api.isAssignableFrom(RandomAccessFile.class))
      {
         // Return if file is a directory
         if (file.isDirectory())
         {
            return null;
         }

         try
         {
            /**
             * Open the random access file. The file is opened in write mode
             * only if possible. The created random access file is a subclass of
             * RandomAccessFile that overrides the default finalize() operation,
             * in order to close the file when no longer referenced.
             */
            if (this.file.canWrite())
            {
               try
               {
                  impl = new AutoFinalizeRandomAccessFile(this.file, "rw");
                  closeables.addElement((Closeable)impl);
               }
               catch(IllegalArgumentException e)
               {
                  logger.info("Cannot open file in read/write mode. " +
                              "Trying read only ...", e);
               }
            }
            if (impl == null)
            {
               impl = new AutoFinalizeRandomAccessFile(this.file, "r");
               closeables.addElement((Closeable)impl);
            }
         }
         catch (final IllegalArgumentException e)
         {
            this.logger.error("fr.gael.drb.impl.file.File : "
                  + "Cannot create an instance of RandomAccessFile");
            this.logger.error("fr.gael.drb.impl.file.File : " + e.getMessage());
         }
         catch (final FileNotFoundException e)
         {
            this.logger.error("fr.gael.drb.impl.file.File : "
                  + "Cannot create an instance of RandomAccessFile");
            this.logger.error("fr.gael.drb.impl.file.File : " + e.getMessage());
         }
         catch (final SecurityException e)
         {
            this.logger.error("fr.gael.drb.impl.file.File : "
                  + "Cannot create an instance of RandomAccessFile");
            this.logger.error("fr.gael.drb.impl.file.File : " + e.getMessage());
         }
      }
      /**
       * Case of java.io.File request.
       */
      else if (api.isAssignableFrom(java.io.File.class))
      {
         impl = this.file;
      }

      else if (api == URL.class)
      {
         try
         {
            impl = new URL(this.file.getName());
         }
         catch (final MalformedURLException e)
         {
            return null;
         }
      }

      else
      {
         return super.getImpl(api);
      }

      return impl;
   }

   /**
    * Automatic finalizable random access file class. This class overrides the
    * default Object.finalize() operation to insure the file is closed (i.e.
    * call close() operation) when no longer referenced.
    */
   class AutoFinalizeRandomAccessFile extends RandomAccessFile
   {
      /**
       * Wrap superclass constructor.
       * 
       * @param file the file
       * @param mode the mode
       * @throws FileNotFoundException This exception is raised when the file
       *            doesn't exist
       */
      AutoFinalizeRandomAccessFile(final java.io.File file, final String mode)
            throws FileNotFoundException
      {
         super(file, mode);
      }

      /**
       * Close the file. 
       * Bad way to release file handlers : Finalize method is called by 
       * garbage collector when many memory is used. In the case of huge
       * usage of FileNode with very few memory usage, GC is never called
       * and file system limits are quickly reached. 
       * 
       * @throws Throwable throwable
       */
      protected void finalize() throws Throwable
      {
         super.close();

         super.finalize();
      }
   }

   /**
    * Overrides the default string representation. This operation wraps the
    * getName() to the toString(). It is not part of the DrbNode implementation
    * but easethe use of the file nodes in standard Java API such as printing,
    * persistency, etc.
    * 
    * @return The name of the file node.
    */
   public final String toString()
   {
      return this.getName();
   }

   /**
    * Copy the specified input stream to an output file. This operation copies
    * the content of a stream in a file. The copy is performed with a unit block
    * size of 1024 kilobytes.
    * 
    * @param input_stream The stream in input.
    * @param output The File in output.
    */
   private boolean copyStream(final java.io.InputStream input_stream,
         final java.io.File output)
   {
      // TODO: This operation shall raise progress events.
      /**
       * Check input parameters before buffer allocation.
       */
      if ((input_stream == null) || (output == null))
      {
         this.logger.error("File.copyStream() : invalid parameter.");
         return false;
      }

      /**
       * Open stream s.
       */
      FileOutputStream output_stream;
      try
      {
         output_stream = new FileOutputStream(output);
      }
      catch (final Exception e)
      {
         this.logger.error("File.copyStream() : " + e);
         return false;
      }

      /**
       * Allocates copy buffer.
       */
      final byte[] buffer = new byte[1024 * 1024];

      /**
       * Copy file contents.
       */

      try
      {
         int read_count;

         while ((read_count = input_stream.read(buffer)) > 0)
         {
            output_stream.write(buffer, 0, read_count);
         }
      }
      catch (final IOException e)
      {
         this.logger.error("File.copyStream() : " + e);
         return false;
      }
      finally
      {
         try
         {
            output_stream.close();
         }
         catch (Exception e)
         {
            // Nothing to do
         }
      }
      return true;
   }

   /**
    * Adds a child to the current node. The current node has to be a directory
    * with correct write permissions. This operation performs different actions
    * according to the input node type. This operation does nothing if a file
    * already exists in the children list with the same name (even if the
    * contents of the input node is different from the existing). The current
    * child has to be removed first or the replaceChild() operation shall be
    * used.
    * <p>
    * <b>Case of File input node:</b> If the input node is a regular file, a
    * new file is created with the same name and its contents is copied
    * recursively.
    * </p>
    * <p>
    * <b>Case of non File input node:</b> A file is created with the same name
    * has the input node and is filled with the value of the input node. The
    * value of the children is completely dismissed.
    * </p>
    * After the node has been added, the children list of the current node is
    * updated.
    * <p>
    * <b>Events:</b> This operation fires a node change event. The node
    * affected by the change is the added node and the source is the current
    * node. The called operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param node A reference to the input node to be added.
    * @return A reference to the effectivelly added node.
    * @throws NullPointerException This exception is raised when the node is
    *            null
    * @throws UnsupportedOperationException This exception is raised when the
    *            current node is not a directory or if it does not allows to
    *            remove the file for security reasons (e.g. file permissions).
    */
   private FileNode addChild(final DrbNode node) throws NullPointerException,
         UnsupportedOperationException
   {
      /**
       * Check the input node.
       */
      if (node == null)
      {
         throw new NullPointerException("File.addChild() : Null input node.");
      }

      /**
       * Checks the current node is a directory.
       */
      if (!this.file.isDirectory())
      {
         final DrbFactoryImpl impl = DrbFactoryResolver.resolveImpl(this);
         if ((impl == null) || !(impl instanceof DrbUpdateImpl))
         {
            throw new UnsupportedOperationException("File.addChild() : "
                  + "Current node is not a directory.");
         }
         ((DrbUpdateImpl) impl).put(node, this);
         return null;
      }

      /**
       * Declares the output file for further use.
       */
      java.io.File output_file;
      FileNode output_node;

      /**
       * Create an instance of file corresponding to the output file.
       */
      output_file = new java.io.File(this.file, node.getName());

      /**
       * Check that file does not already exists.
       */
      /*
       * if (output_file.exists()) { throw new UnsupportedOperationException(
       * "File.addChild() : " + "File \"" + output_file.getName() + "\" already
       * exists !"); }
       */

      /**
       * Check whether to create a directory of a file.
       */
      boolean create_directory = false;

      // Check directory attribute, if any
      final DrbAttribute directory_attribute = node.getAttribute("directory");
      if (directory_attribute != null)
      {
         final Value directory_value = directory_attribute.getValue();
         if (directory_value == null)
         {
            throw new UnsupportedOperationException("File.addChild() : "
                  + "Cannot assess whether the node \"" + output_file.getName()
                  + "\" is a file or a directory. Attributes must not be null.");
         }
         try
         {
            create_directory =
               ((fr.gael.drb.value.Logic) directory_value
                     .convertTo(Value.BOOLEAN_ID)).booleanValue();
         }
         catch (final ClassCastException e)
         {
            throw new UnsupportedOperationException("File.addChild() : "
                  + "Cannot assess whether the node \"" + output_file.getName()
                  + "\" is a file or a directory. Attributes must be valid.");
         }
      }
      else
      // Otherwise, check node content
      if (node.hasChild() || (node.getValue() == null))
      {
         this.logger.warn("File.addChild() : " + "The node \""
               + output_file.getName()
               + "\" should have no 'directory' attribute.");
      }

      /**
       * Reset the children list of the current node.
       */
      this.children = null;

      /**
       * Add the node recursively as a directory file.
       */
      if (create_directory)
      {
         if (!output_file.exists() && !output_file.mkdir())
         {
            throw new UnsupportedOperationException("File.addChild() : "
                  + "Cannot create new directory.");
         }
         final int count = node.getChildrenCount();
         output_node = new FileNode(output_file, this);
         for (int ichild = 0; ichild < count; ichild++)
         {
            output_node.addChild(node.getChildAt(ichild));
         }
      }
      /**
       * Add the node as a normal file.
       */
      else
      {
         try
         {
            output_file.createNewFile();
         }
         catch (final java.io.IOException e)
         {
            throw new UnsupportedOperationException("File.addChild() : "
                  + "Cannot create new file.");
         }

         output_node = new FileNode(output_file, this);

         final DrbFactoryImpl impl = DrbFactoryResolver.resolveImpl(node);
         Value output_value = node.getValue();

         /**
          * If the node is serializable, write it in the input file
          */
         if (impl instanceof DrbUpdateImpl)
         {
            final DrbNode input_node = node.getFirstChild();
            if (input_node != null)
            {
               ((DrbUpdateImpl) impl).put(input_node, output_node);
            }
         }
         else
         /**
          * If the node have no value, try to get an input stream
          */
         if ((output_value == null) && (node instanceof DrbNodeImpl))
         {
            final DrbNodeImpl nodeImpl = (DrbNodeImpl) node;
            if (nodeImpl.hasImpl(java.io.InputStream.class))
            {
               output_value = new FileValue(nodeImpl);
            }
            else
            {
               final int count = node.getChildrenCount();
               output_node = new FileNode(output_file, this);
               for (int ichild = 0; ichild < count; ichild++)
               {
                  output_node.addChild(node.getChildAt(ichild));
               }
            }
         }
         else if (output_value != null)
         {
            output_node.setValue(output_value);
         }
      }

      /**
       * Fires node change events.
       */
      final DrbDefaultNodeList node_list = new DrbDefaultNodeList();

      node_list.add(output_node);

      this.nodesInserted(new DrbNodesChangeEvent(this, node_list));

      return output_node;
   }

   /**
    * Appends a child to the current node. Because the children of the
    * filesystem has its self operdering strategy, (i.e. lexicographical order
    * of files and directories first), this operation is a wrapper to the
    * addChild() operation. The index of the resulting children may therefore
    * not be inserted at the end of the children list.
    * <p>
    * Please refer to the addChild operation to known which events are fired and
    * in which cases exceptions are thrown.
    * </p>
    * 
    * @param node A reference to the node to be appended.
    * @return A reference to the effectivelly appended node. This reference
    *         always differs from the inpt one.
    * @throws UnsupportedOperationException This exception is raised when the
    *            current node is not a directory or if it does not allows to
    *            remove the file for security reasons (e.g. file permissions).
    */
   public DrbNode appendChild(final DrbNode node)
         throws UnsupportedOperationException
   {
      return this.addChild(node);
   }

   /**
    * Inserts a child to the current node children list. Because the children of
    * the filesystem has its self operdering strategy, (i.e. lexicographical
    * order of files and directories first), this operation is a wrapper to the
    * addChild() operation. The index of the resulting children may therefore be
    * different from the requested one.
    * <p>
    * Please refer to the addChild operation to known which events are fired and
    * in which cases exceptions are thrown.
    * </p>
    * 
    * @param node A reference to the node to be inserted.
    * @param index Has no effect in this implementation.
    * @return A reference to the effectively inserted node. This reference
    *         always differs from the input one in this implementation.
    * @throws UnsupportedOperationException This exception is raised when the
    *            current node is not a directory or if it does not allows to
    *            remove the file for security reasons (e.g. file permissions).
    */
   public DrbNode insertChild(final DrbNode node, final int index)
         throws UnsupportedOperationException
   {
      return this.addChild(node);
   }

   /**
    * Removes a file from the children list. This operation removes the file or
    * directory located at the given index. It fails when the current node is
    * not writable or if the index is out of bound.
    * <p>
    * <b>Events:</b> This operation fires a node change even. The node affected
    * by the change is the removed node and the source is the current node. The
    * called operation is the nodesRemoved() of the listeners.
    * </p>
    * <p>
    * <b>Warning:</b> The reference to the removed child in the fired event
    * enable to re-create the same file, but its contents is definitely lost.
    * </p>
    * 
    * @param index Index of the child to be removed.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            current node is not a directory or if it does not allows to
    *            remove the file for security reasons (e.g. file permissions).
    */
   public void removeChild(final int index) throws IndexOutOfBoundsException,
         UnsupportedOperationException
   {
      /**
       * Checks the index is in bound.
       */
      if ((index < 0) || (index >= this.getChildrenCount()))
      {
         throw new IndexOutOfBoundsException("File.removeChild() : " + "Index #"
               + index + " out of bound (children count ="
               + ((this.children == null) ? 0 : this.children.length) + ")");
      }
      /**
       * Instanciate the child.
       */
      final FileNode removed_child = (FileNode) this.getChildAt(index);
      // Pour mettre en cache l'index
      removed_child.index = index;

      /**
       * Remove child.
       */
      try
      {
         if (!this.deleteFile(this.children[index]))
         {
            this.logger.error("File.removeChild() : Warning : "
                  + "Unable to remove file \"" + this.children[index].getName()
                  + "\"");
            throw new UnsupportedOperationException(
                  "File.removeChild() : Warning : " + "Unable to remove file \""
                        + this.children[index].getName() + "\"");
         }
      }
      catch (final SecurityException e)
      {
         throw new UnsupportedOperationException("File.removeChild() : " + e);
      }
      /**
       * Update the children list of the current node.
       */
      this.children = null;

      /**
       * Fire changed node event.
       */
      final DrbDefaultNodeList node_list = new DrbDefaultNodeList();

      node_list.add(removed_child);

      this.nodesRemoved(new DrbNodesChangeEvent(this, node_list));
   }

   /**
    * Delete a file or a directory recursively. This operation removes the file
    * or directory located givenindex. It fails when the current file is not
    * writable.
    * 
    * @param file the Java file to be removed
    */
   private boolean deleteFile(final java.io.File file)
   {
      try
      {
         /**
          * Remove child if any.
          */
         final java.io.File[] list_child = file.listFiles();
         if (list_child != null)
         {
            for (int i = 0; i < list_child.length; i++)
            {
               if (!this.deleteFile(list_child[i]))
               {
                  return false;
               }
            }
         }

         if (!file.delete())
         {
            this.logger.error("File.deleteFile() : Warning : "
                  + "Unable to remove file \"" + file.getName() + "\"");
            return false;
         }
      }
      catch (final SecurityException e)
      {
         this.logger.error("File.deleteFile() : " + "Unable to remove file \""
               + file.getName() + "\" : " + e);
         return false;
      }
      return true;
   }

   /**
    * Changes the name of the node. This operation is allowed only if the
    * wrapped file can be renamed. See the <code>java.io.File</code> class for
    * more information about right persmissions.
    * <p>
    * <b>Events:</b> his operation fires a node change event. The node affected
    * by the change is the current standing also as the source of the event. The
    * called opetation is the nodesChanged() of the listeners.
    * </p>
    * 
    * @param name Reference to the new name.
    * @throws UnsupportedOperationException This exception is raised when the
    *            wrapped file cannot be renamed.
    * @throws NullPointerException This exception is raised when the passed name
    *            is a null reference. This exception may be overriden by an
    *            UnsupportedOperationException.
    */
   public void rename(final String name) throws NullPointerException,
         UnsupportedOperationException
   {
      /**
       * Checks the reference to the input name
       */
      if (name == null)
      {
         throw new NullPointerException("File.rename() : "
               + "The reference to the new name is null.");
      }
      /**
       * Renames the file.
       */
      try
      {
         final java.io.File new_file =
            new java.io.File(this.file.getParentFile(), name);

         this.file.renameTo(new_file);

         this.file = new_file;

         // Erase the cached children in the parent
         if (this.parent != null)
         {
            this.parent.children = null;
         }
      }
      catch (final SecurityException e)
      {
         throw new UnsupportedOperationException("File.rename() : " + e);
      }

      /**
       * Fires node change event.
       */
      this.nodesChanged(new DrbNodesChangeEvent(this));
   }

   /**
    * Replaces a child of the current node. This operation removes first the
    * child at the given index and replace it by the new one. These actions are
    * performed by the removeChild() and addChild() actions of the present
    * class.
    * <p>
    * Please refer to the addChild() and removeChild() operations to known which
    * events are fired and in which cases exceptions are thrown.
    * </p>
    * <p>
    * <b>Warning:</b> Event if a minimal checking is performed before removing
    * the child (i.e. shall be a regular file because other addings are not
    * supported), the corresponding file may be lost if the addChild() aborts.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event. The node
    * affected by the change is the new node and the source is the current node.
    * The called operation is the structureChanged() of the listeners.
    * </p>
    * 
    * @param node A reference to the node to be appended.
    * @param index the index of the node
    * @return A reference to the effectivelly appended node. This reference
    *         always differs from the inpt one.
    * @throws NullPointerException This exception is raised when the reference
    *            to the new node is null.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index does not correspond to any effective child.
    * @throws UnsupportedOperationException This exception is raised if one of
    *            the calls to removeChild() and addChild() operations has raised
    *            it.
    */
   public DrbNode replaceChild(final int index, final DrbNode node)
         throws NullPointerException, IndexOutOfBoundsException,
         UnsupportedOperationException
   {
      /**
       * Check the reference to the replacing node.
       */
      if (node == null)
      {
         throw new NullPointerException("File.replaceChild() :"
               + " Reference to the node is null.");
      }

      /**
       * Checks the index is in bound.
       */
      if ((index < 0) || (index >= this.getChildrenCount()))
      {
         throw new IndexOutOfBoundsException("File.replaceChild() : "
               + "Index #" + index + " out of bound (children count ="
               + ((this.children == null) ? 0 : this.children.length) + ")");
      }
      /**
       * Deletes file.
       */
      this.removeChild(index);

      /**
       * Adds the new node.
       */
      final DrbNode replacing_node = this.addChild(node);

      /**
       * Fires structure change event.
       */
      final DrbDefaultNodeList node_list = new DrbDefaultNodeList();

      node_list.add(replacing_node);

      this.structureChanged(new DrbNodesChangeEvent(this, node_list));

      /**
       * Returns the replacing node.
       */
      return replacing_node;
   }

   /**
    * The namespace of a file cannot be changed.
    * 
    * @param namespace_uri the uri name
    * @throws UnsupportedOperationException Always raised.
    * @throws NullPointerException This exception is raised when the name is
    *            null
    */
   public void setNamespaceURI(final String namespace_uri)
         throws NullPointerException, UnsupportedOperationException
   {
      throw new UnsupportedOperationException("File.setNamespaceURI() : "
            + "Unsupported operation.");
   }

   /**
    * Sets the value pf a file. The file contents is replaced by the passed
    * value. This is possible only if the file is a regular file.
    * 
    * @param value A reference to the value to write.
    * @return The input value.
    * @throws NullPointerException This exception is raised when the value
    *            parameter is null.
    * @throws ClassCastException This exception is never raised.
    * @throws UnsupportedOperationException This exception is raised when the
    *            file is not a regular file or if an error occurs because of
    *            security reasons.
    */
   public Value setValue(final Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      /**
       * Checks the input parameter.
       */
      if (value == null)
      {
         throw new NullPointerException("File.setValue() : "
               + "Null value parameter.");
      }

      /**
       * Assure the file exit until the creation of the output stream.
       */
      synchronized (this.file)
      {
         /**
          * Checks the current node wraps a regular file.
          */
         if (!this.file.isFile())
         {
            throw new UnsupportedOperationException("File.setValue() : "
                  + "Cannot set value of a directory.");
         }
      }

      /**
       * Writes the value in the output file.
       */
      InputStream input_stream;
      if (value.getType() != Value.BINARY_ID)
      {
         input_stream = new ByteArrayInputStream(value.toString().getBytes());
      }
      else
      {
         input_stream = ((fr.gael.drb.value.Binary) value).getInput();
      }

      try
      {
         if ((input_stream != null) && !this.copyStream(input_stream, this.file))
         {
            input_stream.close();
            throw new UnsupportedOperationException(
                  "File.setValue() : cannot copy value to file.");
         }

         if (input_stream != null)
         {
            input_stream.close();
         }
      }
      catch (final IOException e)
      {
         this.logger.warn("File.setValue() : cannot close input stream.");
      }

      return value;
   }

   /**
    * Create a node with the specified name.
    * 
    * @param name The expected name of the node.
    * @return A reference to the new file node.
    * @throws NullPointerException This exception is raised when the name
    *            provided in parameter is null.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation is not able to create a node.
    */
   public DrbNode createNode(final String name) throws NullPointerException,
         UnsupportedOperationException
   {
      try
      {
         return this.createNewFile(name);
      }
      catch (final java.io.IOException e)
      {
         return null;
      }
   }

   /**
    * Creates a new file as children of the current directory. A new file is
    * created with the passed file name. This operation is possible only if the
    * current node wraps a directory and if it has the correcte write
    * permissions. The provided name shall not already be used as name of an
    * existing file in the current directory.
    * <p>
    * <b>Events:</b> This operation fires a node change event. The node
    * affected by the change is the added node and the source is the current
    * node. The called operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param file_name The expected name of the file.
    * @return A reference to the new file node.
    * @throws NullPointerException This exception is raised when the name
    *            provided in parameter is null.
    * @throws UnsupportedOperationException This exception is raised when the
    *            current node is node a directory.
    * @throws IOException This exception is raised when the new file cannot be
    *            created in the current directory.
    * @throws SecurityException This exception is raised when a security manager
    *            exists and its SecurityManager.checkWrite
    *            (java.io.FileDescriptor) method denies write access to the file
    *            be created in the current directory.
    */
   protected FileNode createNewFile(final String file_name)
         throws NullPointerException, UnsupportedOperationException,
         IOException, SecurityException
   {
      /**
       * Checks the provided file name. The file name shall not be null.
       */
      if (file_name == null)
      {
         throw new NullPointerException("File.createNewFile() : "
               + "Null file name.");
      }

      /**
       * Assure the fil is an existing directory until the child file is
       * created.
       */
      java.io.File new_file;

      synchronized (this.file)
      {
         /**
          * Checks the current node is a directory.
          */
         if (!this.file.isDirectory())
         {
            throw new UnsupportedOperationException("File.createNewFile() : "
                  + "Current node is not a directory.");
         }

         /**
          * Tries to create the new file.
          */
         new_file = new java.io.File(this.file, file_name);

         new_file.createNewFile();
      }

      /**
       * Update the children list of the current node.
       */
      this.children = this.getSortedChildren(this.file);

      /**
       * Creates a new instance of new node.
       */
      final FileNode output_node = new FileNode(new_file, this);

      /**
       * Fires node change events.
       */
      final DrbDefaultNodeList node_list = new DrbDefaultNodeList();

      node_list.add(output_node);

      this.nodesInserted(new DrbNodesChangeEvent(this, node_list));

      return output_node;
   }
}
