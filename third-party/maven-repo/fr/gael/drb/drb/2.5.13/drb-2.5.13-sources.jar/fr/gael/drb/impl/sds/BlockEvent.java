/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import java.util.EventObject;

/**
 * Handle events of block changes.
 */
class BlockEvent extends EventObject
{
   /**
    * Indicates selft source.
    */
   public static int SELF = 0;

   /**
    * Indicates parent source.
    */
   public static int PARENT = 1;

   /**
    * Indicates child source.
    */
   public static int CHILD = 2;

   /**
    * Indicates previous source.
    */
   public static int PREVIOUS = 4;

   /**
    * Remove event.
    */
   public static int REMOVE = 8;

   /**
    * Insert event.
    */
   public static int INSERT = 16;

   /**
    * Move event.
    */
   public static int MOVE = 32;

   /**
    * Resize event.
    */
   public static int RESIZE = 64;

   /**
    * Replace event.
    */
   public static int REPLACE = 128;

   /**
    * The block offset.
    */
   Length offset;

   /**
    * The block length.
    */
   Length length;

   /**
    * The block descriptor.
    */
   Descriptor descriptor;

   /**
    * The block key.
    */
   int[] key;

   /**
    * The event reason.
    */
   int reason = 0;

   /**
    * Constructor of the block event class.
    * 
    * @param descriptor the descriptor.
    * @param key the block key.
    * @param offset the block offset or null.
    * @param length the block length or null.
    */
   BlockEvent(final Descriptor descriptor, final int[] key,
         final Length offset, final Length length)
   {
      super(descriptor);

      this.descriptor = descriptor;
      this.key = key;
      this.offset = offset;
      this.length = length;
   }

   /**
    * Constructor of the block event class.
    * 
    * @param reason the event reason.
    * @param descriptor the descriptor.
    * @param key the block key.
    * @param offset the block offset or null.
    * @param length the block length or null.
    */
   BlockEvent(final int reason, final Descriptor descriptor, final int[] key,
         final Length offset, final Length length)
   {
      super(descriptor);

      this.descriptor = descriptor;
      this.key = key;
      this.offset = offset;
      this.length = length;
      this.reason = reason;
   }

   /**
    * Constructor of the block event class.
    * 
    * @param reason the event reason.
    * @param descriptor the descriptor.
    * @param key the block key.
    */
   BlockEvent(final int reason, final Descriptor descriptor, final int[] key)
   {
      super(descriptor);

      this.descriptor = descriptor;
      this.key = key;
      this.reason = reason;
   }

   /**
    * Constructor of the block event class.
    * 
    * @param descriptor the descriptor.
    * @param key the block key.
    */
   BlockEvent(final Descriptor descriptor, final int[] key)
   {
      super(descriptor);

      this.descriptor = descriptor;
      this.key = key;
   }

   /**
    * Returns the offset of the block.
    * 
    * @return the block offset.
    */
   final Length getOffset()
   {
      return this.offset;
   }

   /**
    * Returns the length of the block.
    * 
    * @return the block length.
    */
   final Length getLength()
   {
      return this.length;
   }

   /**
    * Returns the descriptor.
    * 
    * @return the block descriptor.
    */
   final Descriptor getDescriptor()
   {
      return this.descriptor;
   }

   /**
    * Returns the block key.
    * 
    * @return the block key.
    */
   final int[] getKey()
   {
      return this.key;
   }

   /**
    * Returns the event reason.
    * 
    * @return the event reason.
    */
   final int getReason()
   {
      return this.reason;
   }

   /**
    * Returns whether or not this event is coming from the parent.
    * 
    * @return true if the event is coming from the parent and false otherwise.
    */
   final boolean isParent()
   {
      return (this.reason & this.PARENT) != 0;
   }
}
