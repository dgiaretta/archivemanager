/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbSequence;

/**
 * Default implementation of the Variable interface. This class augment the
 * interface of the AbstractVariable to provide a default implementation for
 * managing the values of a variable. The value of a variable is always a
 * sequence. It default value is null, acting as an empty sequence.
 */
class DefaultVariable extends AbstractVariable
{
   /**
    * Value of the variable.
    */
   private DrbSequence value = null;

   /**
    * Copy constructor Builds an exact copy of the passed variable.
    * 
    * @param variable the variable to copy.
    */
   DefaultVariable(final DefaultVariable variable)
   {
      super(variable);
      this.value = variable.value;
   }

   /**
    * Builds a variable based on the string form of its qualified name.
    * 
    * @param name string form of the variable qualified name.
    */
   DefaultVariable(final QName name)
   {
      super(name);
   }

   /**
    * Builds a variable based on the string form of its qualified name and its
    * assigned sequence type.
    * 
    * @param name string form of the variable qualified name.
    * @param sequence_type the type of the variable.
    */
   DefaultVariable(final QName name, final SequenceType sequence_type)
   {
      super(name, sequence_type);
   }

   /**
    * Builds a variable based on the string form of its qualified name and its
    * asigned sequence type and with an assigned value.
    * 
    * @param name string form of the variable qualified name.
    * @param sequence_type the type of the variable.
    * @param value value of the variable.
    * @throws TypeCastException if the value cannot be cast to the target type.
    */
   DefaultVariable(final QName name, final SequenceType sequence_type,
         final DrbSequence value)
          throws TypeCastException
   {
      super(name, sequence_type);

      if (value != null)
      {
         this.setValue(value);
      }
   }

   /**
    * Assigns a value to the variable. The value shall be a sequence. Any
    * previous value of the variable will be overridden. Null values are
    * allowed. If the provided value does not match the variable sequence type,
    * it is converted. A cast exception is thrown if the cast fails.
    * 
    * @param value sequence to be assigned as value of the variable.
    */
   public void setValue(DrbSequence value) throws TypeCastException
   {
      if (value == null)
      {
         this.value = null;
         return;
      }

      final SequenceType sequence_type = this.getSequenceType();

      /**
       * Case of strongly typed variable. The value is converted to the target
       * sequence type potentially throwing a cast exception if the cast fails.
       */
      if (sequence_type != null)
      {
         value = sequence_type.convert(value);
      }

      this.value = value;
   }

   /**
    * Assigns item as value of the variable. This operation inserts the item in
    * a default sequence and assign the value to the variable. According to the
    * XQuery specifications, an item is equivalent to a singleton, a sequence of
    * exactly one item. However, calls to further getValue() will return a
    * sequence and not an item.
    * 
    * @param value item to be assigned as value of the variable.
    */
   public void setValue(final DrbItem value)
   {
      if (value == null)
      {
         this.value = null;
         return;
      }

      this.setValue(new DrbDefaultSequence(value));
   }

   /**
    * Returns the value of the variable.
    * 
    * @return the value of the variable if any, or null otherwise.
    */
   public DrbSequence getValue()
   {
      return this.value;
   }

   /**
    * Returns the value of the variable. As in default variable, the value is
    * static, the current value is returned whatever context is provided in
    * input.
    * 
    * @param context a dynamic context not considered in this impelmentation.
    * @return the value of the variable.
    */
   public void initialize(final DynamicContext context)
   {
      if (this.value == null)
      {
         this.value = new DrbDefaultSequence();
      }
   }

   /**
    * Returns a detailed description of the variable and its value.
    * 
    * @return the variable name and is potential value.
    */
   public String toString()
   {
      String output_string = "$" + this.getName();

      final SequenceType sequence_type = this.getSequenceType();
      if (sequence_type != null)
      {
         output_string += " " + sequence_type;
      }

      final DrbSequence value = this.getValue();
      if (value != null)
      {
         output_string += " := " + value;
      }

      return output_string;
   }

   /**
    * Clones the current instance. The instance is duplicated with the same
    * reference to the name, the sequence type and the value of the variable.
    * 
    * @return a reference to the duplicated variable.
    */
   public Object clone()
   {
      return new DefaultVariable(this.getQName(), this.getSequenceType(),
            this.value);
   }
} // DefaultVariable
