/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import org.apache.log4j.Logger;

import fr.gael.drb.value.Decimal;
import fr.gael.drb.value.Int;
import fr.gael.drb.value.Value;

/**
 * Declaration of an XML-Schema totalDigits Facet.
 */
public class XsdTotalDigitsFacet extends XsdFacet
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(XsdTotalDigitsFacet.class);

   /**
    * totalDigits facet name.
    */
   final static String TAG = "totalDigits";

   /**
    * The totalDigits value.
    */
   private int totalDigits;

   /**
    * Build a totalDigits facet.
    * 
    * @param value the maximum number of allowed digits.
    */
   XsdTotalDigitsFacet(final Value value)
   {
      this.totalDigits =
         ((fr.gael.drb.value.Int) value.convertTo(Value.INT_ID)).intValue();
   } // XsdTotalDigitsFacet

   /**
    * Identifier of this facet.
    * 
    * @return Identifier of this facet.
    */
   public final int getId()
   {
      return TOTAL_DIGITS_ID;
   } // getId

   /**
    * The totalDigits value
    * 
    * @return The totalDigits value
    */
   public final Value getValue()
   {
      return new Int(this.totalDigits);
   } // getValue

   /**
    * The name of this facet.
    * 
    * @return The name of this facet.
    */
   public final String getName()
   {
      return TAG;
   } // getName

   // -------------------------------------------------------
   // ValueValidator interface implementation
   // -------------------------------------------------------
   /**
    * Validates the present value.
    * 
    * @param v the value
    * @return true if this value satisfies the type definition, else false
    */
   public boolean isValid(final Value v)
   {
      if (v == null)
      {
         return false;
      }
      try
      {
         switch (v.getType())
         {
            case Value.FLOAT_ID:
               logger
                     .error("totalDigits facet is not allowed for xs:float datatype");
               return false;
            case Value.DOUBLE_ID:
               logger
                     .error("totalDigits facet is not allowed for xs:double datatype");
               return false;
            case Value.ARRAY_ID:
               logger
                     .error("totalDigits facet is not allowed for list datatype");
               return false;
         }
         final Decimal num = (Decimal) v.convertTo(Value.DECIMAL_ID);
         String str = num.toString().trim(); //ignore whitespace characters
         int canonical_len = str.length(); //canonicalized string length  
         if (str.contains("."))
         {
            while(str.charAt(--canonical_len) == '0'); //ignore trailing zeros
            //ignore decimal point in last step
         }
         if (str.startsWith("-")) //ignore negative sign indicator
         {
            canonical_len --;
         }

         return canonical_len <= totalDigits;
      }
      catch (final ClassCastException e)
      {
         logger.warn("totalDigitsFacet: Cannot convert '" + v
               + "' to xs:decimal.");

         return false;
      }
   }

} // XsdTotalDigitsFacet class
