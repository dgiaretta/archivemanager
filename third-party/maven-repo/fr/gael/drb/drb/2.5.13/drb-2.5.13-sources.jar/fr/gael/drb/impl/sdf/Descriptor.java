/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sdf;

import java.io.EOFException;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.query.Query;
import fr.gael.drb.value.Int;
import fr.gael.drb.value.Value;
import fr.gael.drb.xsd.XsdElement;
import fr.gael.drb.xsd.XsdSimpleType;
import fr.gael.drb.xsd.XsdType;

/**
 * Description of a single or multiple occurrence block.
 */
class Descriptor
{
   /**
    * Constant : Maximum block size for file segment copy. Set to 10240 bytes
    * (10 KB).
    */
   static protected final int MAX_BUFFER_SIZE = 10240;

   /**
    * Constant : Unit is "Bit".
    */
   static protected final int UNIT_BIT = 1;

   /**
    * Constant : Unit is "Byte".
    */
   static protected final int UNIT_BYTE = 2;

   /**
    * Constant : Encoding is "BINARY".
    */
   static protected final int ENCODING_BINARY = 1;

   /**
    * Constant : Encoding is "ASCII".
    */
   static protected final int ENCODING_ASCII = 2;

   /**
    * Constant : Encoding is "EBCDIC".
    */
   static protected final int ENCODING_EBCDIC = 3;

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(Descriptor.class);

   /**
    * The file containing the structured data. This random access file will be
    * used to access the data. It has to be given to the constructor and will be
    * shared by the root descriptor and all its children.
    */

   protected PhysicalAttribute occurrenceCount;

   /**
    * The offset in bytes from the beginning of the file. This class is used to
    * manage the different types of offset: fixed or not. It permits to retreive
    * the value for any specific block occurrence.
    */
   protected PhysicalAttribute offset;

   /**
    * The offset in bits to add to offset in bytes in case of non 8-bits aligned
    * structure. It is added to offset in bytes to compute the exact offset at a
    * bit level. This value is 0 by default and maximum of 7.<br>
    * If the previous structure is at prev_offset=30 with prev_bitOffset=5,
    * prev_length=1 and prev_bitLength=6<br>
    * then offset=32 and bitOffset=3<br>
    * Note: Value is fixed. It is not managed as the length in bytes (no
    * "constant in parent" or "variable" bit length possibility).
    */
   protected int bitOffset;

   /**
    * The length in bytes. This class is used to manage the different types of
    * length: fixed or not. It permits to retreive the value for any specific
    * block occurrence.
    */
   protected PhysicalAttribute length;

   /**
    * The length in bits to add to length in bytes in case of non 8-bits aligned
    * structure. It is added to length in bytes to compute the exact length at a
    * bit level. This value is 0 by default and maximum of 7. If the structure
    * has 11 bits it will be distributed as length=1 and bitLength=3.<br>
    * Note: Value is fixed. It is not managed as the length in bytes (no
    * "constant in parent" or "variable" bit length possibility).
    */
   protected int bitLength;

   /**
    * occurrenceCountQuery
    */
   protected String occurrenceCountQuery;

   /**
    * Flag to indicate if the query occurrenceCountQuery is constant. If it is
    * false the query will be processed for each occurrence.
    */
   protected boolean occurrenceCountQueryConstant;

   /**
    * Flag to indicate if the occurrence count depends on the parent. True if
    * the occurrence count can only be solved by the parent.
    */
   protected boolean occurrenceCountFromParent;

   /**
    * Query object to use to process in order to solve occurrence count.
    */
   protected Query occurrenceCountQueryObject;

   /**
    * Context Node to use for query.eval().
    */
   protected DrbNode contextNode;

   /**
    * Query to process in order to solve offset.
    */
   protected String offsetQuery;

   /**
    * Query to process in order to solve length.
    */
   protected String lengthQuery;

   /**
    * Query object to use to process in order to solve length.
    */
   protected Query lengthQueryObject;

   /**
    * Flag to indicate if the query occurrenceCountQuery is constant. If it is
    * false the query will be processed for each occurrence.
    */
   protected boolean lengthQueryConstant;

   /**
    * Flag to indicate the current solved length query occurrence in case of
    * variable length. Starts at 0.
    */
   protected int lengthQuerySolvedId;

   /**
    * Documentation attached to the descriptor.
    */
   protected String documentation;

   /**
    * Encoding method. Unless encoding is specified a child block inheritates
    * the value from its parent.
    */
   private RandomAccessData file;

   /**
    * The base node. This is the base node wich was used to create the root
    * descriptor from. All descriptors have a reference to this one.
    */
   private DrbNode baseNode;

   /**
    * The schema node path. This is the path of the schema node. The path string
    * is stored during descriptor creation in factory. Therefore the value will
    * not be updated in case of schema node changes because schema node
    * descriptors are parsed in factory to create block descriptors. Then no
    * further schema change is applied to descriptors.
    */
   private String schemaNodePath;

   /**
    * The root descriptor. This is the top-level descriptor for a specific
    * structured data file. All descriptors have a reference to this one.
    */
   private Descriptor root;

   /**
    * The parent descriptor. This is a reference to the descriptor of the
    * structure containing the current one. The root descriptor has its parent
    * attribute set to null.
    */
   private Descriptor parent;

   /**
    * The children descriptors. This is a list of references to the children
    * descriptors. The number of children is included in the list. This
    * attribute can be null in case of "leaf" descriptor.
    */
   private ArrayList children;

   /**
    * The previous sibling descriptor. This is a reference to the descriptor
    * just before this one in the children list of the parent.
    */
   private Descriptor previousSibling;

   /**
    * The next sibling descriptor. This is a reference to the descriptor just
    * after this one in the children list of the parent.
    */
   private Descriptor nextSibling;

   /**
    * The name of the described block. This is the short name of the described
    * block. Other descriptors can have the same. Therefore it cannot be
    * considered as an identifier.<br>
    * For instance it can be "MPH".
    */
   private String name;

   /**
    * The full name of the described block. This is the detailed name of the
    * described block. Other descriptors can have the same. Therefore it cannot
    * be considered as an identifier.<br>
    * For instance it can be "Main Product Header".
    */
   private String fullName;

   /**
    * The description of the block.
    */
   private XsdElement nodeDesc;

   /**
    * The type of the described block. This is the schema type definition and
    * validator.
    */
   private XsdType type;

   /**
    * The value type of the described block. This is the value type identifier
    * as described in fr.gael.drb.value.Value.
    */
   private int valueType;

   /**
    * The array value type, used if valueType attribute is ARRAY_ID. This is the
    * value type identifier as described in fr.gael.drb.value.Value used to
    * create the array in case of valueType=ARRAY_ID.
    * 
    * @see Descriptor(file,node) constructor.
    */
   private int arrayValueType;

   /**
    * The size of the array, used if valueType attribute is ARRAY_ID. This is
    * the size used to create the array in case of valueType=ARRAY_ID.
    * 
    * @see Descriptor(file,node) constructor.
    */
   private int arraySize;

   /**
    * The size of the element in the array, used if valueType attribute is
    * ARRAY_ID. This is the element size used to create the array in case of
    * valueType=ARRAY_ID.
    * 
    * @see Descriptor(file,node) constructor.
    */
   private long arrayElementSize;

   /**
    * True if descriptor has ancestors with only one block occurrence each. Used
    * to compute the result of isSingleOccurrence(). By default value is set to
    * true and changed to false (or unchanged) while solving occurrence counts.
    */
   private boolean singleAncestors;

   /**
    * The offset from previous sibling information. When absolute offset is not
    * set yet, it is usefull to keep the relative information given. For
    * instance it can be set that there is an offset of 8 from the end of the
    * previous sibling.
    */
   private int offsetFromPreviousSibling;

   /**
    * The inner header padding in bytes. This is the length to skip before to
    * consider the value in the block. Therefore the real offset of the block
    * value is : offset+headerPadding.
    */
   private int headerPadding;

   /**
    * The header padding content string. This is the string defining the content
    * of the header padding.
    */
   private String headerPaddingContent;

   /**
    * The inner footer padding in bytes. This is the length to skip after the
    * value in the block. Therefore the real length of the block value is :
    * length-footerPadding.
    */
   private int footerPadding;

   /**
    * The footer padding content string. This is the string defining the content
    * of the footer padding.
    */
   private String footerPaddingContent;

   /**
    * The number of occurrence(s) of the described block. This class is used to
    * manage the different types of occurrence count : fixed or not. It permits
    * to retreive the value for any specific block occurrence.
    */

   private int encoding;

   /**
    * Query to process in order to solve occurrence count (string).
    */

   /**
    * Default constructor with name and fullname. Builds a Descriptor instance
    * setting the name and full_name.
    * 
    * @param file The RandomAccessFile containing the data.
    * @param name The short name.
    * @param full_name The detailed name.
    */
   protected Descriptor(final RandomAccessData file, final String name,
         final String full_name)
   {
      // Set default values
      this.name = name;
      this.fullName = full_name;
      this.file = file;
      this.encoding = this.ENCODING_BINARY;
      this.valueType = Value.UNKNOWN_ID;
      this.arrayValueType = Value.UNKNOWN_ID;
      this.arraySize = 0;
      this.arrayElementSize = 0;
      this.children = new ArrayList();
      this.occurrenceCount = new PhysicalAttribute();
      this.offset = new PhysicalAttribute();
      this.bitOffset = 0;
      this.length = new PhysicalAttribute();
      this.bitLength = 0;
      this.offsetFromPreviousSibling = 0;
      this.headerPadding = 0;
      this.footerPadding = 0;
      this.singleAncestors = true;
      this.occurrenceCountQueryConstant = true;
      this.occurrenceCountFromParent = false;
      this.lengthQueryConstant = true;
      this.lengthQuerySolvedId = 0;
   }

   /**
    * Constructor with common values except padding. Builds a Descriptor
    * instance setting the common description values. Header and footer padding
    * are set to 0;
    * 
    * @param file The RandomAccessFile containing the data.
    * @param name The short name.
    * @param full_name The detailed name.
    * @param encoding The encoding method.
    * @param occurrenceCount The number of occurrence(s), must be positive or
    *           zero for fixed value, else must be set to -1.
    * @param offset The offset, must be positive or zero for fixed value, else
    *           must be set to -1.
    * @param length The length, must be positive or zero for fixed value, else
    *           must be set to -1.
    * @param valueType The value type identifer, as defined in
    *           fr.gael.drb.value.Value.
    */
   /*
    * protected Descriptor(RandomAccessFile file, String name, String full_name
    * int encoding, int occurrenceCount, int offset, int length, int valueType) { //
    * Calls default constructor and sets values this(file, name, full_name);
    * this.encoding = encoding; // Sets occurrenceCount if fixed. if
    * (occurrenceCount >= 0) {
    * this.setOccurrenceCountType(PhysicalAttribute.FIXED);
    * this.setOccurrenceCount(null, occurrenceCount); } // Sets offset if fixed.
    * if (offset >= 0) { this.setOffsetType(PhysicalAttribute.FIXED);
    * this.setOffset(null, offset); } // Sets length if fixed. if (length >= 0) {
    * this.setLengthType(PhysicalAttribute.FIXED); this.setLength(null, length); } //
    * Sets value type identifer. this.valueType = valueType; // Sets padding
    * values to 0. this.headerPadding = 0; this.footerPadding = 0; }
    */

   /**
    * Constructor with common values and padding. Builds a Descriptor instance
    * setting the common description and padding values.
    * 
    * @param file The RandomAccessFile containing the data.
    * @param name The short name.
    * @param full_name The detailed name.
    * @param encoding The encoding method.
    * @param occurrenceCount The number of occurrence(s), must be positive or
    *           zero for fixed value, else must be set to -1.
    * @param offset The offset, must be positive or zero for fixed value, else
    *           must be set to -1.
    * @param length The length, must be positive or zero for fixed value, else
    *           must be set to -1.
    * @param valueType The value type identifer, as defined in
    *           fr.gael.drb.value.Value.
    * @param headerPadding The header padding.
    * @param footerPadding The footer padding.
    */
   /*
    * protected Descriptor(RandomAccessFile file, String name, String full_name
    * int encoding, int occurrenceCount, int offset, int length, int valueType,
    * int headerPadding, int footerPadding) { // Calls default constructor
    * this(file, name, full_name, encoding, occurrenceCount, offset, length,
    * valueType); // Sets padding values this.headerPadding = headerPadding;
    * this.footerPadding = footerPadding; }
    */

   /**
    * Constructor with common values, padding and references to other
    * descriptors. Builds a Descriptor instance setting the common description,
    * padding values and references to its relatives.
    * 
    * @param file The RandomAccessFile containing the data.
    * @param name The short name.
    * @param full_name The detailed name.
    * @param encoding The encoding method.
    * @param occurrenceCount The number of occurrence(s), must be positive or
    *           zero for fixed value, else must be set to -1.
    * @param offset The offset, must be positive or zero for fixed value, else
    *           must be set to -1.
    * @param length The length, must be positive or zero for fixed value, else
    *           must be set to -1.
    * @param valueType The value type identifer, as defined in
    *           fr.gael.drb.value.Value.
    * @param headerPadding The header padding.
    * @param footerPadding The footer padding.
    * @param root The root descriptor.
    * @param parent The parent descriptor.
    * @param previousSibling The previous sibling descriptor.
    */
   /*
    * protected Descriptor(RandomAccessFile file, String name, String full_name
    * int encoding, int occurrenceCount, int offset, int length, int valueType,
    * int headerPadding, int footerPadding, Descriptor root, Descriptor parent,
    * Descriptor previousSibling) { // Call constructor to initialize common
    * values and paddings this(file, name, full_name, encoding, occurrenceCount,
    * offset, length, valueType, headerPadding, footerPadding); // Set
    * additional values this.root = root; this.setParent(parent);
    * this.previousSibling = previousSibling; }
    */

   /**
    * Create a root block descriptor. Builds a "root" Descriptor instance with
    * minimal values. All other values and references are set internally. Only
    * children list will have to be modified later.
    * 
    * @param file The RandomAccessFile containing the data.
    * @param name The short name.
    * @param full_name The detailed name.
    * @param encoding The encoding method.
    */
   /*
    * protected Descriptor(RandomAccessFile file, String name, String full_name
    * int encoding) { // Initialize default values : no offset, no padding, etc.
    * this(file, name, full_name, encoding, 1, 0, -1, Value.NULL_ID); this.root =
    * this; }
    */

   /**
    * Create a block descriptor from a NodeDescriptor.
    * 
    * @param file The RandomAccessFile containing the data.
    * @param create_mode Says whether this file must be created.
    * @param node The schema node descriptor.
    * @param depth The depth in the tree.
    */
   protected Descriptor(final RandomAccessData file, final boolean create_mode,
         final XsdElement node, final int depth)
   {
      // Initialize default values
      this(file, (node.getName() != null ? node.getName() : ""), "");
      this.logger.debug("New Descriptor \"" + this.name + "\"");

      // Set node type
      this.setSchema(node);
      final XsdType nodeType = node.getType();

      // Set node value type
      final XsdSimpleType valueType = nodeType.getDatatype();
      if (valueType != null)
      {
         this.setValueType(valueType.getTypeId());
      }
      else
      {
         this.setValueType(Value.NULL_ID);
      }

      // Parse structure external children list
      this.logger.debug("Parse structure external children");
      if (!this.parseExternalChildren(node.getName(), nodeType
            .getExternalNodes()))
      {
         this.logger
               .error("fr.gael.drb.impl.sdf.Descriptor.Descriptor(file, node) : "
                     + "Error while parsing structure external children for node \""
                     + node.getName() + "\".");
         this.logger.error("   Descriptor may be inconsistent and cause "
               + "wrong data access in file.");
      }

      // Parse node external children list
      this.logger.debug("Parse node external children");
      if (!this.parseExternalChildren(node.getName(), node.getExternalNodes()))
      {
         this.logger
               .error("fr.gael.drb.impl.sdf.Descriptor.Descriptor(file, node) : "
                     + "Error while parsing external children for node \""
                     + node.getName() + "\".");
         this.logger.error("   Descriptor may be inconsistent and cause "
               + "wrong data access in file.");
      }

      // Get current length (can be unknown = -1)
      long length = this.length.getValue(null);
      this.logger.debug("Get current length (" + this.name + ")= " + length);

      // Case of Array : Occurrence count is determining the length
      if (this.valueType == Value.ARRAY_ID)
      {
         this.logger.debug("Case of array");
         // If array defined without length, unable to get arrayElementSize.
         if (length == -1)
         {
            this.logger
                  .warn("fr.gael.drb.impl.sdf.Descriptor.Descriptor(file, node) : "
                        + "Will be unable to solve array element size for \""
                        + this.name + "\".");
            this.arrayElementSize = 0;
         }
         // Else current length is in fact the size of an array element
         else
         {
            this.arrayElementSize = length;
            this.setLength(null, -1);
         }

         // Case of existing occurrence count query
         if (this.occurrenceCountQuery != null)
         {
            this.logger.debug("Swap occurrence count query to length query");
            // Swap query to length and reset for occurrence count
            // CD : Attention si une query de length etait definie !!
            // Elle devrait servir a resoudre le arrayElementSize, mais ce
            // n'est pas encore supporte.
            this.lengthQuery = this.occurrenceCountQuery;
            this.occurrenceCountQuery = null;
            this.lengthQueryConstant = this.occurrenceCountQueryConstant;
            this.occurrenceCountQueryConstant = true;
         }
         // Case of no query and still unknown occurrence count (ArraySize)
         else if (this.arraySize == -1)
         {
            this.logger
                  .warn("fr.gael.drb.impl.sdf.Descriptor.Descriptor(file, node) : "
                        + "Will be unable to solve array size for \""
                        + this.name + "\".");
         }
         // Case of already known occurrence count (arraySize)
         else
         {
            // Compute array length
            length = this.arraySize * this.arrayElementSize;
         }
      }

      // If occurrence count query is not constant set as variable
      if (!this.occurrenceCountQueryConstant)
      {
         this.setOccurrenceCountType(PhysicalAttribute.VARIABLE);
      }
      // Else set as fixed
      else
      {
         this.setOccurrenceCountType(PhysicalAttribute.FIXED);

         // Case of unknown occurrence count, set to 1 by default
         if ((this.occurrenceCountQuery == null)
               && (this.occurrenceCount.getValue(null) == -1))
         {
            this.logger.debug("Set occurrence count to default value (1)");
            this.setOccurrenceCount(null, 1);
         }
      }

      // If length query is not constant set as variable
      if (!this.lengthQueryConstant)
      {
         this.logger
               .debug("Length query is not constant, set type to VARIABLE");
         this.setLengthType(PhysicalAttribute.VARIABLE);
      }
      // Else
      else
      {
         // Case of known length (no query)
         if ((this.lengthQuery == null)
               && (this.getLengthType() != PhysicalAttribute.UNKNOWN))
         {
            // Add padding and set fixed length
            this.logger.debug("Set length to FIXED");
            length = length + this.headerPadding + this.footerPadding;
            this.setLengthType(PhysicalAttribute.FIXED);
            this.setLength(null, length);
         }
      }

      // Case of 0 byte size file : Will be used for appendChild then
      // change occurrence count type variable and then value unknown
      if (create_mode)
      {
         this.logger.debug("Case of 0 byte size file");
         // For the direct children of the root (depth==1) the
         // CONSTANT_IN_PARENT type is equivalent to FIXED. This prevents the
         // bug from the KeyMapTree.add() call with empty '{}' key.
         if (depth == 1)
         {
            this.setOccurrenceCountType(PhysicalAttribute.FIXED);
            this.setOccurrenceCount(null, 0);
         }
         else
         {
            this.setOccurrenceCountType(PhysicalAttribute.CONSTANT_IN_PARENT);
            this.occurrenceCountQuery = null;
         }
      }

      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("+++ " + this.name + " :" + " occCount = "
               + this.occurrenceCount + ", length = " + this.length
               + ", arraySize = " + this.arraySize + ", arrayElementSize = "
               + this.arrayElementSize + ", occConst="
               + this.occurrenceCountQueryConstant + ", occFromParent="
               + this.occurrenceCountFromParent + ", lenConst="
               + this.lengthQueryConstant);
      }
   }

   /**
    * Parse a "unit" attribute an return the type. The unit attribute value can
    * be one of the following :
    */
   private int parseUnit(final DrbAttribute attribute)
   {
      this.logger.debug("parseUnit()");
      // Local declarations
      Value attributeValue = null; // Attribute value
      String attributeValueStr; // Attribute value string
      try
      {
         // Get attribute value and return if null
         if ((attributeValue = attribute.getValue()) == null)
         {
            this.logger.error("fr.gael.drb.impl.sdf.Descriptor.parseUnit() : "
                  + "Unit attribute value is null.");
            return -1;
         }
         // Get value string
         attributeValueStr = attributeValue.toString();
         // Case of byte unit
         if (attributeValueStr.equals("byte"))
         {
            return this.UNIT_BYTE;
         }
         // Case of byte unit
         else if (attributeValueStr.equals("bit"))
         {
            return this.UNIT_BIT;
         }
         // Case of unknown unit attribute value
         else
         {
            this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parseUnit() : "
                        + "Unknown unit attribute value (" + attributeValueStr
                        + ").");
            return -1;
         }
      }
      catch (final ClassCastException e)
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor.parseUnit() : "
               + "Error while extracting unit attribute value ("
               + attributeValue + ").");
         this.logger.error("   " + e);
         return -1;
      }
   }

   /**
    * Parse a "length" node.
    * 
    * @param node The node to parse.
    * @return True if value has been found and extracted
    */
   private boolean parseLength(final DrbNode node)
   {
      this.logger.debug("parseLength()");
      // Local declaration
      int length; // Extracted length
      final int byteLength; // Length in bytes
      Value nodeValue = null; // Node value
      int nbAttribute; // Number of attributes
      DrbAttributeList attributeList; // Attribute list of the node
      DrbAttribute attribute; // Current attribute
      boolean bitLengthUnit; // True if length unit is bit
      Value attributeValue = null; // Attribute value
      boolean lengthQueryDefined; // True if a length query is defined

      // Get attribute list
      nbAttribute = 0;
      attributeList = node.getAttributes();

      // By default length unit is byte and no query has been defined
      bitLengthUnit = false;
      lengthQueryDefined = false;

      // Case of attributes
      if ((attributeList != null)
            && ((nbAttribute = attributeList.getLength()) > 0))
      {
         // Loop on attributes
         for (int j = 0; j < nbAttribute; j++)
         {
            // Get current attribute
            attribute = attributeList.item(j);
            // Case of "unit" occurrence attribute
            if (attribute.getName().equals("unit"))
            {
               // Sets the length unit
               switch (this.parseUnit(attribute))
               {
                  // Case of byte unit
                  case UNIT_BYTE:
                     bitLengthUnit = false;
                     break;
                  // Case of bit unit
                  case UNIT_BIT:
                     bitLengthUnit = true;
                     break;
                  // Case of unknown unit
                  default:
                     this.logger
                           .error("fr.gael.drb.impl.sdf.Descriptor.parseLength() : "
                                 + "Error while parsing unit attribute.");
                     return false;
               }
            }
            // Case of "query" attribute
            else if (attribute.getName().equals("query"))
            {
               try
               {
                  // Get attribute value and return if null
                  if ((attributeValue = attribute.getValue()) == null)
                  {
                     this.logger
                           .error("fr.gael.drb.impl.sdf.Descriptor.parseLength() : "
                                 + "Length query attribute value is null.");
                     return false;
                  }
                  // Extract length query from attribute value
                  this.lengthQuery = attributeValue.toString();
                  lengthQueryDefined = true;
               }
               catch (final ClassCastException e)
               {
                  this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseLength() : "
                              + "Error while extracting length query attribute"
                              + " value (" + attributeValue + ").");
                  this.logger.error("   " + e);
                  return false;
               }
            }
            // Unknown attribute
            else
            {
               this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseLength() : "
                           + "Unknown length attribute (" + attribute.getName()
                           + ").");
               return false;
            }
         }
      }
      // Get length value if no query has been defined
      if (lengthQueryDefined == false)
      {
         try
         {
            // Get node value and return if null
            if ((nodeValue = node.getValue()) == null)
            {
               this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseLength() : "
                           + "Length value is null.");
               return false;
            }
            // Extract length from node value
            length =
               ((fr.gael.drb.value.Int) nodeValue.convertTo(Value.INT_ID))
                     .intValue();
            // Set fixed length property
            this.setLengthType(PhysicalAttribute.FIXED);
            // Case of bit unit
            if (bitLengthUnit)
            {
               // Maximum bit stream supported is int size (32 bits)
               if (length > 32)
               {
                  this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseLength() : "
                              + "Length value greater than 32 bits is not"
                              + " supported yet.");
               }
               // Keep fixed values (no need for key to set value)
               this.bitLength = length % 8;
               this.setLength(null, (length / 8));
            }
            // Default : Case of byte unit
            else
            {
               this.bitLength = 0;
               this.setLength(null, length);
            }
         }
         // Value extraction problem
         catch (final ClassCastException e)
         {
            this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parseLength() : "
                        + "Error while extracting length value (" + nodeValue
                        + ").");
            this.logger.error("   " + e);
            return false;
         }
      }
      // Value is extracted, return true
      return true;
   }

   /**
    * Parse a "encoding" node.
    * 
    * @param node The node to parse.
    * @return True if value has been found and extracted
    */
   private boolean parseEncoding(final DrbNode node)
   {
      this.logger.debug("parseEncoding()");
      // Local declaration
      String tmpString; // Extracted string
      Value nodeValue = null; // Node value

      // Get node value and return if null
      if ((nodeValue = node.getValue()) == null)
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor.parseEncoding() : "
               + "Encoding value is null.");
         return false;
      }
      // Extract length from node value
      tmpString = nodeValue.toString();
      // Case of "ASCII"
      if (tmpString.equals("ASCII"))
      {
         this.encoding = this.ENCODING_ASCII;
      }
      // Case of "BINARY"
      else if (tmpString.equals("BINARY"))
      {
         this.encoding = this.ENCODING_BINARY;
      }
      // Case of "EBCDIC"
      else if (tmpString.equals("EBCDIC"))
      {
         this.encoding = this.ENCODING_EBCDIC;
      }
      // Case of invalid encoding
      else
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor.parseEncoding() : "
               + "Unknown encoding value (" + tmpString + ").");
         return false;
      }
      // Value is extracted, return true
      return true;
   }

   /**
    * Parse a "block" node.
    * 
    * @param node The node to parse.
    * @return True if value has been found and extracted
    */
   private boolean parseBlock(final DrbNode node)
   {
      this.logger.debug("parseBlock()");
      // Local declaration
      DrbNode nodeChild; // Current node child
      String nodeName; // Current node name

      // Loop on "drb:block" children nodes
      for (int i = 0; i < node.getChildrenCount(); i++)
      {
         // Get current node child and the corresponding name
         nodeChild = node.getChildAt(i);
         nodeName = nodeChild.getName();
         // Parse occurrence count
         if (nodeName.equals("occurrence"))
         {
            if (!this.parseOccurrence(nodeChild))
            {
               this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseBlock() : "
                           + "Error while parsing occurrence node.");
               return false;
            }
         }
         // Parse length
         else if (nodeName.equals("length"))
         {
            if (!this.parseLength(nodeChild))
            {
               this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseBlock() : "
                           + "Error while parsing length node.");
               return false;
            }
         }
         // Parse offset
         else if (nodeName.equals("offset"))
         {
            if (!this.parseOffset(nodeChild))
            {
               this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseBlock() : "
                           + "Error while parsing offset node.");
               return false;
            }
         }
         // Parse padding
         else if (nodeName.equals("padding"))
         {
            if (!this.parsePadding(nodeChild))
            {
               this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseBlock() : "
                           + "Error while parsing padding node.");
               return false;
            }
         }
         // Parse encoding
         else if (nodeName.equals("encoding"))
         {
            if (!this.parseEncoding(nodeChild))
            {
               this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseBlock() : "
                           + "Error while parsing encoding node.");
               return false;
            }
         }
         // Unknown element
         else
         {
            this.logger.warn("fr.gael.drb.impl.sdf.Descriptor.parseBlock() : "
                  + "Unknown element \"" + nodeName + "\", ignored.");
         }
      }
      // Value is extracted, return true
      return true;
   }

   /**
    * Parse a "occurrence" node.
    * 
    * @param node The node to parse.
    * @return True if value has been found and extracted
    */
   private boolean parseOccurrence(final DrbNode node)
   {
      this.logger.debug("parseOccurrence()");
      // Local declaration
      int nbAttribute; // Number of attributes
      DrbAttributeList attributeList; // Attribute list of the node
      DrbAttribute attribute; // Current attribute
      int occurrence; // Occurrence
      Value nodeValue = null; // Node value
      Value attributeValue = null; // Attribute value

      // Get attribute list
      nbAttribute = 0;
      attributeList = node.getAttributes();

      // Case of attributes
      if ((attributeList != null)
            && ((nbAttribute = attributeList.getLength()) > 0))
      {
         // Loop on attributes
         for (int j = 0; j < nbAttribute; j++)
         {
            // Get current attribute
            attribute = attributeList.item(j);

            // Case of "query" occurrence attribute
            if (attribute.getName().equals("query"))
            {
               try
               {
                  // Get attribute value and return if null
                  if ((attributeValue = attribute.getValue()) == null)
                  {
                     this.logger
                           .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence() : "
                                 + "Occurrence query attribute value is null.");
                     return false;
                  }
                  // Extract occurrence from attribute value
                  this.occurrenceCountQuery = attributeValue.toString();
                  this.logger.debug("   occurrenceCountQuery=["
                        + this.occurrenceCountQuery + "]");

                  // CD : It is assumed that in case of query the occurrence
                  // count can be greater than 1 then type is set to ARRAY.
                  // Keep value type and size for further array creation
                  // change value type to ARRAY_ID
                  if ((this.valueType == Value.BOOLEAN_ID)
                        || (this.valueType == Value.UNSIGNED_BYTE_ID)
                        || (this.valueType == Value.BYTE_ID)
                        || (this.valueType == Value.DOUBLE_ID)
                        || (this.valueType == Value.FLOAT_ID)
                        || (this.valueType == Value.UNSIGNED_INT_ID)
                        || (this.valueType == Value.INT_ID)
                        || (this.valueType == Value.UNSIGNED_LONG_ID)
                        || (this.valueType == Value.LONG_ID)
                        || (this.valueType == Value.UNSIGNED_SHORT_ID)
                        || (this.valueType == Value.SHORT_ID))
                  {
                     this.logger.debug("   Consider as array");
                     this.arrayValueType = this.valueType;
                     this.arraySize = -1;
                     this.valueType = Value.ARRAY_ID;
                  }
               }
               catch (final ClassCastException e)
               {
                  this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence() : "
                              + "Error while extracting occurrence query attribute"
                              + " value (" + attributeValue + ").");
                  this.logger.error("   " + e);
                  return false;
               }
            }

            // Case of "constant" occurrence attribute
            else if (attribute.getName().equals("constant"))
            {
               try
               {
                  // Get attribute value and return if null
                  if ((attributeValue = attribute.getValue()) == null)
                  {
                     this.logger
                           .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence():"
                                 + "Occurrence constant attribute value is null.");
                     return false;
                  }
                  // Extract attribute value
                  if (attributeValue.toString().equals("false"))
                  {
                     this.occurrenceCountQueryConstant = false;
                  }
                  else
                  {
                     this.occurrenceCountQueryConstant = true;
                  }
               }
               catch (final ClassCastException e)
               {
                  this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence() : "
                              + "Error while extracting occurrence constant "
                              + " attribute value (" + attributeValue + ").");
                  this.logger.error("   " + e);
                  return false;
               }
            }

            // Case of "parent" occurrence attribute
            else if (attribute.getName().equals("parent"))
            {
               try
               {
                  // Get attribute value and return if null
                  if ((attributeValue = attribute.getValue()) == null)
                  {
                     this.logger
                           .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence():"
                                 + "Occurrence parent attribute value is null.");
                     return false;
                  }
                  // Extract attribute value
                  if (attributeValue.toString().equals("true"))
                  {
                     this.occurrenceCountFromParent = true;
                  }
               }
               catch (final ClassCastException e)
               {
                  this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence() : "
                              + "Error while extracting occurrence parent "
                              + " attribute value (" + attributeValue + ").");
                  this.logger.error("   " + e);
                  return false;
               }
            }

            // Unknown attribute
            else
            {
               this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence() : "
                           + "Unknown occurrence attribute name ("
                           + attribute.getName() + ").");
               return false;
            }
         }
      }
      // Case of no attribute, a value is expected
      else
      {
         try
         {
            // Get node value and return if null
            if ((nodeValue = node.getValue()) == null)
            {
               this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence() : "
                           + "Occurrence value is null.");
               return false;
            }
            // Extract occurrence from node value
            occurrence =
               ((fr.gael.drb.value.Int) nodeValue.convertTo(Value.INT_ID))
                     .intValue();
            // In case of multiple occurrence and simple value type
            // change value type to ARRAY_ID and keep current type in
            // order getValue() to return an array instead of having
            // multiple nodes.
            if ((occurrence > 1)
                  && ((this.valueType == Value.BOOLEAN_ID)
                        || (this.valueType == Value.UNSIGNED_BYTE_ID)
                        || (this.valueType == Value.BYTE_ID)
                        || (this.valueType == Value.DOUBLE_ID)
                        || (this.valueType == Value.FLOAT_ID)
                        || (this.valueType == Value.UNSIGNED_INT_ID)
                        || (this.valueType == Value.INT_ID)
                        || (this.valueType == Value.UNSIGNED_LONG_ID)
                        || (this.valueType == Value.LONG_ID)
                        || (this.valueType == Value.UNSIGNED_SHORT_ID) || (this.valueType == Value.SHORT_ID)))
            {
               // Keep value type and size for further array creation
               // change value type to ARRAY_ID
               this.arrayValueType = this.valueType;
               this.arraySize = occurrence;
               this.valueType = Value.ARRAY_ID;
               // Set occurrence to 1 (no key needed)
               this.setOccurrenceCountType(PhysicalAttribute.FIXED);
               this.setOccurrenceCount(null, 1);
            }
            // Value is not an array, keep occurrence count to have
            // multiple nodes.
            else
            {
               // Set fixed occurrence properties (no key needed)
               this.setOccurrenceCountType(PhysicalAttribute.FIXED);
               this.setOccurrenceCount(null, occurrence);
            }
         }
         // Value extraction problem
         catch (final ClassCastException e)
         {
            this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parseOccurrence() : "
                        + "Error while extracting occurrence value ("
                        + nodeValue + ").");
            this.logger.error("   " + e);
            return false;
         }
      }

      // Debug information
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("   " + "query="
               + (this.occurrenceCountQuery != null ? true : false)
               + ", constant=" + this.occurrenceCountQueryConstant
               + ", fromParent=" + this.occurrenceCountFromParent + ", array="
               + (this.valueType == Value.ARRAY_ID ? true : false)
               + ", occurrence=" + this.occurrenceCount);
      }

      // Value is extracted, return true
      return true;
   }

   /**
    * Parse a "padding" node. TBF: unit management (byte and bit)
    * 
    * @param node The node to parse.
    * @return True if value has been found and extracted
    */
   private boolean parsePadding(final DrbNode node)
   {
      this.logger.debug("parsePadding()");
      // Local declaration
      int padding; // Padding
      int nbAttribute; // Number of attributes
      DrbAttributeList attributeList; // Attribute list of the node
      DrbAttribute attribute; // Current attribute
      Value nodeValue = null; // Node value
      Value attributeValue = null; // Attribute value
      String content = ""; // Content string
      boolean headerType = false; // True if padding type is header

      // Get attribute list
      nbAttribute = 0;
      attributeList = node.getAttributes();

      // If no attribute exists, do not consider the padding node
      if ((attributeList == null)
            || ((nbAttribute = attributeList.getLength()) == 0))
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
               + "Missing padding attribute.");
         return false;
      }
      // Loop on attributes
      for (int j = 0; j < nbAttribute; j++)
      {
         // Get current attribute
         attribute = attributeList.item(j);
         // Case of "type" padding attribute
         if (attribute.getName().equals("type"))
         {
            try
            {
               // Get attribute value and return if null
               if ((attributeValue = attribute.getValue()) == null)
               {
                  this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                              + "Padding type attribute value is null.");
                  return false;
               }
               // Get node value and return if null
               if ((nodeValue = node.getValue()) == null)
               {
                  this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                              + "Padding value is null.");
                  return false;
               }
               // Extract padding from node value
               padding =
                  ((fr.gael.drb.value.Int) nodeValue.convertTo(Value.INT_ID))
                        .intValue();
               // Case of "header" padding
               if (attributeValue.toString().equals("header"))
               {
                  // Set header padding properties
                  headerType = true;
                  this.headerPadding += padding;
               }
               // Case of "footer" padding
               else if (attributeValue.toString().equals("footer"))
               {
                  // Set footer padding properties
                  headerType = false;
                  this.footerPadding += padding;
               }
               // Case of unknown attribute value
               else
               {
                  this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                              + "Unknown padding attribute value ("
                              + attributeValue + ").");
                  return false;
               }
            }
            // Value extraction problem
            catch (final ClassCastException e)
            {
               this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                           + "Error while extracting padding value ("
                           + nodeValue + ").");
               this.logger.error("   " + e);
               return false;
            }
         }
         // Case of "content" padding attribute
         else if (attribute.getName().equals("content"))
         {
            try
            {
               // Get attribute value and return if null
               if ((attributeValue = attribute.getValue()) == null)
               {
                  this.logger
                        .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                              + "Padding content attribute value is null.");
                  return false;
               }
               // Store content string
               content = attributeValue.toString();
            }
            // Value extraction problem
            catch (final ClassCastException e)
            {
               this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                           + "Error while extracting padding content value ("
                           + nodeValue + ").");
               this.logger.error("   " + e);
               return false;
            }
         }
         // Case of unknown attribute name
         else
         {
            this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parsePadding() : "
                        + "Unknown padding attribute name ("
                        + attribute.getName() + ").");
            return false;
         }
      } // End of loop on padding attributes

      // At this step padding type is known
      if (headerType)
      {
         this.headerPaddingContent = content;
      }
      else
      {
         this.footerPaddingContent = content;
      }

      // Value is extracted, return true
      return true;
   }

   /**
    * Parse a "annotation" node.
    * 
    * @param node The node to parse.
    * @return True if value has been found and extracted
    */
   private boolean parseAnnotation(final DrbNode node)
   {
      this.logger.debug("parseAnnotation()");
      // Local declaration
      DrbNode nodeChild; // Current node child

      // Loop on annotation children nodes
      for (int i = 0; i < node.getChildrenCount(); i++)
      {
         // Get current node child
         nodeChild = node.getChildAt(i);

         // Parse documentation
         if (nodeChild.getName().equals("documentation"))
         {
            if (!this.parseDocumentation(nodeChild))
            {
               this.logger
                     .error("fr.gael.drb.impl.sdf.Descriptor.parseAnnotation() : "
                           + "Error while parsing documentation node.");
               return false;
            }
         }
      }
      // Value is extracted, return true
      return true;
   }

   /**
    * Parse a "documentation" node.
    * 
    * @param node The node to parse.
    * @return True if value has been found and extracted
    */
   private boolean parseDocumentation(final DrbNode node)
   {
      this.logger.debug("parseDocumentation()");
      // Local declaration
      Value nodeValue = null; // Node value
      String tmpString; // Extracted string
      try
      {
         // Get node value and return if null
         if ((nodeValue = node.getValue()) == null)
         {
            this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parseDocumentation() : "
                        + "Documentation value is null.");
            return false;
         }
         // extract offset from node value
         tmpString = nodeValue.toString();
         // Set documentation
         this.documentation = tmpString;
      }
      // Value extraction problem
      catch (final ClassCastException e)
      {
         this.logger
               .error("fr.gael.drb.impl.sdf.Descriptor.parseDocumentation() : "
                     + "Error while extracting documentation value ("
                     + nodeValue + ").");
         this.logger.error("   " + e);
         return false;
      }
      // Value is extracted, return true
      return true;
   }

   /**
    * Parse a "offset" node. TBF: unit management (byte and bit) TBF: ref
    * management (root and parent), here it is only considered as offset from
    * previous sibling
    * 
    * @param node The node to parse.
    * @return True if value has been found and extracted
    */
   private boolean parseOffset(final DrbNode node)
   {
      this.logger.debug("parseOffset()");
      // Local declaration
      Value nodeValue = null; // Node value
      try
      {
         // Get node value and return if null
         if ((nodeValue = node.getValue()) == null)
         {
            this.logger
                  .error("fr.gael.drb.impl.sdf.Descriptor.parseOffset() : "
                        + "Offset value is null.");
            return false;
         }
         // extract offset from node value and consider as additional offset
         this.offsetFromPreviousSibling =
            ((fr.gael.drb.value.Int) nodeValue.convertTo(Value.INT_ID))
                  .intValue();
      }
      // Value extraction problem
      catch (final ClassCastException e)
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor.parseOffset() : "
               + "Error while extracting offset value (" + nodeValue + ").");
         this.logger.error("   " + e);
         return false;
      }
      // Value is extracted, return true
      return true;
   }

   /**
    * Parse external children node to find "drb:block" information and set it.
    * Used by constructor to extract length, padding, offset information from
    * the "drb:block" node attached to the element or the structure. The padding
    * values are added to themselves in order to sum the padding defined from
    * the complex type and the one from the element.
    * 
    * @param parsed_node_name The name of the node, used for error messages.
    * @param external_children The external children node list.
    * @return boolean
    */
   private boolean parseExternalChildren(final String parsed_node_name,
         final DrbNodeList external_children)
   {
      this.logger.debug("parseExternalChildren(" + parsed_node_name + ")");
      // Local declaration
      DrbNode nodeChild; // Current node child
      String nodeName; // Current node child name

      // Case of no external node, return without setting other values
      if (external_children == null)
      {
         return true;
      }

      // Loop on external children nodes
      for (int i = 0; i < external_children.getLength(); i++)
      {
         // Get current node child
         nodeChild = external_children.item(i);
         nodeName = nodeChild.getName();

         // Parse block
         if (nodeName.equals("block"))
         {
            if (!this.parseBlock(nodeChild))
            {
               this.logger
                     .warn("fr.gael.drb.impl.sdf.Descriptor.parseExternalChildren() : "
                           + "Error while parsing block information in node \""
                           + parsed_node_name + "\", ignored.");
               return false;
            }
         }

         // Parse annotation
         else if (nodeName.equals("annotation"))
         {
            if (!this.parseAnnotation(nodeChild))
            {
               this.logger
                     .warn("fr.gael.drb.impl.sdf.Descriptor.parseExternalChildren():"
                           + "Error while parsing annotation in node \""
                           + parsed_node_name + "\", ignored.");
               return false;
            }
         }
      }
      // Values are extracted, return true
      return true;
   }

   /**
    * Returns the documentation associated to the descriptor.
    * 
    * @return String
    */
   protected final String getDocumentation()
   {
      return this.documentation;
   }

   /**
    * Returns the file associated to the descriptor.
    * 
    * @return RandomAccessData
    */
   protected final RandomAccessData getFile()
   {
      return this.file;
   }

   /**
    * Close this descriptor.
    */
   protected final void dispose()
   {
      try
      {
         if (this.file != null)
         {
            this.file.close();
         }
      }
      catch (final java.io.IOException e)
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor : "
               + "Cannot close the file.");
      }
   }

   /**
    * Returns true if descriptor and all its parents are associated to only one
    * block each.
    * 
    * @param key int[]
    * @return true if descriptor describes only one block.
    */
   protected final boolean isSingleOccurrence(final int[] key)
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.isSingleOccurrence("
               + IntMap.keyToString(key) + ")");
      }

      // Return true if single occurrence
      return ((this.singleAncestors) && (this.getOccurrenceCount(key) == 1));
   }

   /**
    * Returns the value type identifer. This identifier is described in
    * fr.gael.drb.value.Value.
    * 
    * @return the value type identifer.
    */
   protected final int getValueType()
   {
      return this.valueType;
   }

   /**
    * Returns the XML-Schema type .
    * 
    * @return the XML-Schema type.
    */
   protected final XsdType getType()
   {
      return this.type;
   }

   /**
    * Returns the XML-Schema definition .
    * 
    * @return the XML-Schema definition.
    */
   protected final XsdElement getSchema()
   {
      return this.nodeDesc;
   }

   /**
    * Sets the value type identifer. This identifier is described in
    * fr.gael.drb.value.Value. Value is not checked and therefore must be
    * consistent.
    * 
    * @param valueType the value type
    */
   protected final void setValueType(final int valueType)
   {
      this.valueType = valueType;
   }

   /**
    * Sets the XML-Schema definition.
    * 
    * @param node_desc XsdElement
    */
   protected final void setSchema(final XsdElement node_desc)
   {
      this.nodeDesc = node_desc;
      if ((node_desc != null) && (node_desc.getType() != null))
      {
         this.type = node_desc.getType();
      }
   }

   /**
    * Returns the name of the described block.
    * 
    * @return String
    */
   protected final String getName()
   {
      return this.name;
   }

   /**
    * Returns the full name of the described block.
    * 
    * @return String
    */
   protected final String getFullName()
   {
      return this.fullName;
   }

   /**
    * Returns the number of children descriptor(s).
    * 
    * @return The the number of children descriptors.
    */
   protected int getChildrenCount()
   {
      return this.children.size();
   }

   /**
    * Returns the encoding method of the descriptor.
    * 
    * @return The encoding method of the descriptor.
    */
   protected int getEncoding()
   {
      return this.encoding;
   }

   /**
    * Returns the value of the described block with the given key.
    * 
    * @param key The key of the described block.
    * @return The encoding method of the descriptor.
    */
   protected final Value getValue(final int[] key)
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.getValue("
               + IntMap.keyToString(key) + ")");
      }

      // Local declarations
      long offset; // Offset
      long length; // Length

      // Get length
      if ((length = this.getLength(key)) == -1)
      {
         this.logger.info("fr.gael.drb.impl.sdf.Descriptor.getValue() : "
               + "length is UNKNOWN.");
      }

      // In case of array, compute array size
      if ((this.valueType == fr.gael.drb.value.Value.ARRAY_ID)
            && (this.arrayElementSize > 0) && (length >= 0))
      {
         this.arraySize = (int) (length / this.arrayElementSize);
      }

      // Get offset
      if ((offset = this.getOffset(key)) == -1)
      {
         this.logger.info("fr.gael.drb.impl.sdf.Descriptor.getValue() : "
               + "offset is UNKNOWN.");
      }

      // Get value from file
      try
      {
         BlockTools blockTools = new BlockTools();
         final Value value =
            blockTools.extractValue(this.file, offset + this.headerPadding,
                  this.bitOffset,
                  (int) (length - (this.headerPadding + this.footerPadding)),
                  this.bitLength, this.encoding, this.valueType,
                  this.arrayValueType, this.arraySize);
         blockTools = null;
         return value;
      }
      // Or remove occurrence if EOF is reached
      catch (final EOFException e)
      {
         this.logger.error(e);
         this.logger.error("Descriptor.getValue(): Unable to read value "
               + "for node \"" + this.name + "\" (key="
               + IntMap.keyToString(key) + ").");
      }
      catch (final IOException e)
      {
         this.logger.error(e);
         this.logger.error("Descriptor.getValue(): Unable to read value "
               + "for node \"" + this.name + "\" (key="
               + IntMap.keyToString(key) + ").");
      }

      /*
       * CD : A continuer pour ne pas afficher la partie tronquee d'un fichier //
       * Set occurrence count to 0 for this key and return null
       * setOccurrenceCount(key, 0); System.out.println(name+"
       * occ="+this.occurrenceCount+ " off="+this.offset+ " len="+this.length); //
       * Propagate to next sibling descriptors and parent recursively up
       * Descriptor siblingDesc = this; Descriptor parentDesc = this; while
       * (parentDesc != null) { // Propagate to next sibling descriptors while
       * ((siblingDesc = siblingDesc.getNextSibling()) != null) {
       * System.out.println("Set "+siblingDesc.name+" occ to 0");
       * siblingDesc.setOccurrenceCountType(PhysicalAttribute.FIXED);
       * siblingDesc.setOccurrenceCount(key, 0); } // Goto parent parentDesc =
       * parentDesc.getParent(); siblingDesc = parentDesc; } CD fin
       */

      return null;
   }

   /**
    * Sets the value of the described block with the given key. TBD
    * 
    * @param value the value
    * @param key The key of the described block.
    * @return The encoding method of the descriptor.
    * @throws UnsupportedOperationException exception
    */
   protected Value setValue(final Value value, final int[] key)
         throws UnsupportedOperationException
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.setValue([" + value + "], "
               + IntMap.keyToString(key) + ")");
      }

      // Local declarations
      long offset; // Offset
      long length; // Total length of the field
      long valueLength; // Length of the value
      String outString; // Output string
      final byte[] outBuffer; // Output buffer
      Value output_value; // Output value converted to output type

      // Check passed value
      if (value == null)
      {
         throw new NullPointerException("Descriptor.setValue(): "
               + "the value to set is null.");
      }

      // Convert value to output type if necesary
      if ((value != null) && (value.getType() != this.valueType))
      {
         try
         {
            output_value = value.convertTo(this.valueType);
         }
         catch (final ClassCastException exception)
         {
            this.logger.error(this.name + " : Cannot convert value (type = #"
                  + value.getType() + ") to output type #" + this.valueType
                  + ".");
            output_value = null;
         }
      }
      else
      {
         output_value = value;
      }

      // Get length
      if ((length = this.getLength(key)) == -1)
      {
         throw new UnsupportedOperationException("Descriptor.setValue(): "
               + "length is UNKNOWN.");
      }
      valueLength = length - this.headerPadding - this.footerPadding;

      // Get offset
      if ((offset = this.getOffset(key)) == -1)
      {
         throw new UnsupportedOperationException("Descriptor.setValue(): "
               + "offset is UNKNOWN.");
      }

      // Place file cursor to offset
      try
      {
         // Case of ACII encoding
         if (this.encoding == this.ENCODING_ASCII)
         {
            // Seek position including offset to write
            this.file.seek(offset - this.offsetFromPreviousSibling);

            // Check offset from previous sibling and add necessary space char
            outString =
               this.getFixedString("", this.offsetFromPreviousSibling, ' ');

            // Check header padding
            outString =
               outString
                     + this.getFixedString(this.headerPaddingContent,
                           this.headerPadding, ' ');

            // Check null value
            if (output_value == null)
            {
               outString =
                  outString + this.getFixedString(null, (int) valueLength, ' ');
            }
            // Else if value can format the string
            else if (output_value instanceof fr.gael.drb.value.ValueFormat)
            {
               outString =
                  outString
                        + this.getFixedString(
                              ((fr.gael.drb.value.ValueFormat) output_value)
                                    .getFormattedString((int) valueLength),
                              (int) valueLength, ' ');
            }
            // else default string format (with length constraint)
            else
            {
               outString =
                  outString
                        + this.getFixedString(output_value.toString(),
                              (int) valueLength, ' ');
            }

            // Check footer padding
            outString =
               outString
                     + this.getFixedString(this.footerPaddingContent,
                           this.footerPadding, ' ');

            // Write string to file
            this.file.writeBytes(outString);
         }
         else
         {
            // Seek position to write value into file
            this.file.seek(offset);

            byte[] buffer;
            // If the value can format the buffer
            if (output_value instanceof fr.gael.drb.value.ValueFormat)
            {
               buffer =
                  ((fr.gael.drb.value.ValueFormat) output_value)
                        .getFormattedBuffer();
            }
            else
            {
               // TODO: Fix the SPR-435 BEGIN
               if (output_value != null)
               {
                  this.logger.warn(this.name
                        + " : Value type not supported yet "
                        + "for binary output ! valueType="
                        + output_value.getType());
               }

               final byte[] outputString = output_value.toString().getBytes();

               buffer = new byte[(int) valueLength];

               for (int ichar = 0; (ichar < outputString.length)
                     && (ichar < valueLength); ichar++)
               {
                  buffer[ichar] = outputString[ichar];
               }
            }
            // Write buffer and paddings to file

            if (this.headerPadding > 0)
            {
               this.file.writeBytes(this.getFixedString(
                     this.headerPaddingContent, this.headerPadding, ' '));
            }

            this.file.write(buffer);

            if (this.footerPadding > 0)
            {
               this.file.writeBytes(this.getFixedString(
                     this.footerPaddingContent, this.footerPadding, ' '));
            }
            // TODO: Fix the SPR-435 END
         }
      }
      // Exceptions
      catch (final IOException e)
      {
         this.logger.error(e);
         this.logger.error("Descriptor.setValue(): "
               + "Error while writing value for node \"" + this.name
               + "\" (key=" + IntMap.keyToString(key) + ").");
      }

      // Return the value
      return output_value;
   }

   /**
    * Set values recursively, using the passed node. The passed node tree will
    * be parsed and compared to the possible tree defined from the current
    * descriptor.
    * 
    * @param node The node to append as child.
    * @param key The key of the calling block (where to append).
    * @param is_copying True if currently using file copy, false by default.
    * @param return_node True if the appended node has to be returned else null
    * @param level Recursive depth level (useful for indenting the printouts).
    * @return The encoding method of the descriptor.
    * @throws UnsupportedOperationException exception
    */
   protected DrbNode appendChild(final DrbNode node, final int[] key,
         boolean is_copying, boolean return_node, final int level)
         throws UnsupportedOperationException
   {
      // Debug info
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.appendChild(node, key="
               + IntMap.keyToString(key) + ", is_copying=" + is_copying
               + ", return_node=" + return_node + ", level=" + level + ")");
      }

      // Local declarations
      Descriptor childDesc; // reference to a child descriptor
      int[] childKey; // Key of the child
      boolean found; // True if child desc is found
      final long childOffset; // Offset of the child
      final long childLength; // Length of the child
      int childrenCount; // Number of children in the node

      // Checks the passed node
      if (node == null)
      {
         throw new NullPointerException(
               "Descriptor.appendChild(): The reference to the node to "
                     + "append is null.");
      }

      // Test if node can accept child
      if (this.getChildrenCount() == 0)
      {
         throw new UnsupportedOperationException("Descriptor.appendChild(): "
               + "\"" + this.name + "\" node does not accept any child.");
      }

      // Get the corresponding descriptor
      found = false;
      childDesc = this.getFirstChild();
      while ((!found) && (childDesc != null))
      {
         // Check name
         if (childDesc.getName().equals(node.getName()))
         {
            found = true;
         }
         // Go to next child
         else
         {
            childDesc = childDesc.getNextSibling();
         }
      }

      // Check that a valid child has been found
      if (!found)
      {
         throw new UnsupportedOperationException("Descriptor.appendChild(): "
               + "\"" + this.getName()
               + "\" node does not accept any child named " + "\""
               + node.getName() + "\".");
      }
      // Create child key for first occurrence
      childKey = IntMap.getChildKey(key, 0);

      // Get occurrence count before appending to build the right child key
      final int currentOccurrenceCount = childDesc.getOccurrenceCount(childKey);

      // Create child key for current occurrence
      childKey = IntMap.getChildKey(key, currentOccurrenceCount);

      // Case of SDF DrbNode to append
      if ((!is_copying) && (node instanceof AbstractBlock))
      {
         // Flag for copy method
         is_copying = true;

         final AbstractBlock block = (AbstractBlock) node;
         final long blockLength = block.getLength();

         // Copy node directly from file
         final long result =
            this.copyFileSegment(block.descriptor.file, block.getOffset(),
                  childDesc.file, childDesc.getOffset(childKey), block
                        .getLength());
      }

      // Case of node having children
      if (node.hasChild())
      {
         // Loop on childen
         childrenCount = node.getChildrenCount();
         for (int i = 0; i < childrenCount; i++)
         {
            // Add occurrence : TBC avant ou apres le appendChild
            childDesc.setOccurrenceCount(childKey, currentOccurrenceCount + 1);

            // Call recursively to append current node child
            childDesc.appendChild(node.getChildAt(i), childKey, is_copying,
                  false, level + 1);
         }
      }
      // Case of leaf, set the value if any
      else
      {
         // Wrap to Descriptor
         if (!is_copying)
         {
            final Value value = node.getValue();

            if (value != null)
            {
               childDesc.setValue(value, childKey);
            }
         }

         // Add occurrence
         childDesc.setOccurrenceCount(childKey, currentOccurrenceCount + 1);
      }

      // if (!is_copying) this.logger.info("<"+name+">.appendChild():
      // current occurrence count = "+currentOccurrenceCount+1);

      // Returns a new instance of the appended node if necessary
      if (!return_node)
      {
         return null;
      }

      return AbstractBlock.createOptimalBlock(childDesc, childKey,
            currentOccurrenceCount + 1);
   }

   /**
    * Copies a file segment to another file. Reads the given number of bytes in
    * the input file, starting from the given input offset. Then writes to the
    * output file, starting to the given output offset. A maximum number of 1024
    * bytes is read at a time in order to avoid memory problem with huge
    * segments.<br>
    * This operation doesn't close any of input and output files.
    * 
    * @param input_file The file to read the bytes from.
    * @param input_offset The offset where to start in input file.
    * @param output_file The file to write the bytes to.
    * @param output_offset The offset in the input file.
    * @param length The number of bytes to copy.
    * @return The length of the bytes read.
    */
   protected static final long copyFileSegment(
         final RandomAccessData input_file, final long input_offset,
         final RandomAccessData output_file, final long output_offset,
         final long length)
   {
      // Check parameters
      if ((input_file == null) || (output_file == null) || (input_offset < 0)
            || (output_offset < 0) || (length < 0))
      {
         logger.error("Descriptor.copyFileSegment(): "
               + "Invalid parameter(s) :");
         logger.error("   input_file    = " + input_file);
         logger.error("   input_offset  = " + input_offset);
         logger.error("   output_file   = " + output_file);
         logger.error("   output_offset = " + output_offset);
         logger.error("   length       = " + length);
         return -1;
      }

      int curRead = 0;
      int totalRead = 0;
      try
      {
         // Set input and output files positions
         input_file.seek(input_offset);
         output_file.seek(output_offset);

         // Allocate limited read buffer for huge segment
         byte[] buffer = new byte[MAX_BUFFER_SIZE];

         // Compute the number of loop in case of huge segment and the
         // size of the last part (size < MAX_BUFFER_SIZE then integer)
         final long loopNumber = length / MAX_BUFFER_SIZE;
         int curLength = MAX_BUFFER_SIZE;
         final int lastLength = (int) (length % MAX_BUFFER_SIZE);

         // Loop on limited segment plus one for last part
         for (long i = 0; i <= loopNumber; i++)
         {
            // Reduce the buffer length for last part to read
            if (i == loopNumber)
            {
               buffer = new byte[(int) lastLength];
               curLength = lastLength;
            }

            // Read bytes from input file
            curRead = curLength;
            input_file.readFully(buffer);

            // Case of EOF reached
            if (curRead < curLength)
            {
               if (curRead == -1)
               {
                  logger.info("Descriptor.copyFileSegment(): "
                        + "EOF reached in input file");
                  return totalRead;
               }
               // Create new array with the real size and copy usefull bytes
               final byte[] tmpBuffer = new byte[curRead];
               System.arraycopy(buffer, 0, tmpBuffer, 0, curRead);
               buffer = tmpBuffer;

               // Flag as last read loop
               i = loopNumber;
            }

            // Add read bytes to total and write bytes to output file
            totalRead += curRead;
            output_file.write(buffer);
         }
         // Return the number of read bytes
         return totalRead;
      }

      // Exceptions
      catch (final IOException e)
      {
         logger.error(e);
         logger.error("Descriptor.copyFileSegment(): " + "Unable to copy "
               + length + " byte(s) from \"" + input_file + "\" (offset="
               + input_offset + ") to \"" + output_file + "\" (offset="
               + output_offset + ").");
         return -1;
      }
   }

   /**
    * Solve the number of occurrence(s) of the described block.
    * 
    * @param key The key of the described block.
    * @return The solved occurrence count or -1 if not solved.
    */
   protected final long solveOccurrenceCount(final int[] key)
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.solveOccurrenceCount("
               + IntMap.keyToString(key) + ")");
      }

      // Case of empty query
      if (this.occurrenceCountQuery == null)
      {
         // this.logger.error(
         // "fr.gael.drb.impl.sdf.Descriptor.solveOccurrenceCount() : \"" +
         // name + "\" Query is empty, value cannot be solved.");
         return -1;
      }

      return this.queryEval(key, this.occurrenceCountQueryObject,
            this.occurrenceCountQuery);
   }

   /**
    * Solve the offset of the described block.
    * 
    * @param key The key of the described block.
    * @return The solved offset or -1 if not solved.
    */
   protected final long solveOffset(final int[] key)
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.solveOffset("
               + IntMap.keyToString(key) + ")");
      }

      // Case of no query, current offset is the offset plus the length of
      // the previous block.
      if (this.offsetQuery == null)
      {
         int offsetType; // Type of the offset
         long solvedOffset; // Solved offset value
         Descriptor previousDesc; // reference to a previous descriptor
         int[] previousKey; // Key of the previous sibling
         long previousOffset; // Offset of the previous block
         long previousLength; // Length of the previous block
         boolean previousFound; // True if the prev. valid sibling found
         int previousFactor; // Factor for previous block length
         int occurrence; // Occurrence in the current desc
         int descOccurrenceCount; // Occurrence count in the current desc
         int lengthType; // Length type
         long previousBitsFromOffset; // Bits from previous sibling offset

         // Loop on previous descriptors until a block occurrence is found.
         occurrence = key[key.length - 1];
         descOccurrenceCount = occurrence; // nb occur-1 => key value
         previousFound = false;
         previousFactor = 1;
         previousDesc = this;
         previousKey = key;
         while ((!previousFound) && (previousDesc != null))
         {
            // If an occurrence is found creates key of the previous sibling
            // which is the last occurrence in the previous descriptor
            if (descOccurrenceCount > 0)
            {
               // If previous descriptor has more than 1 occurrence and
               // "fixed" or "constant in parent" length then optimises access
               // using first occurrence of the previous serie.
               lengthType = previousDesc.getLengthType();
               if ((descOccurrenceCount > 1)
                     && ((lengthType == PhysicalAttribute.FIXED) || (lengthType == PhysicalAttribute.CONSTANT_IN_PARENT)))
               {
                  // Uses the key of the first occurrence and keeps factor
                  // to multiply it by length of one occurrence
                  previousKey = IntMap.getSiblingKey(key, 0);
                  previousFactor = descOccurrenceCount;
               }
               // Else uses last occurrence of the previous serie factor set
               // to 1.
               else
               {
                  previousKey =
                     IntMap.getSiblingKey(key, descOccurrenceCount - 1);
               }

               // at this step a valid previous sibling has been found.
               previousFound = true;
            }
            // Else get previous sibling descriptor and occurrence count if
            // not null (using key of the first occurrence because count is
            // unknown yet).
            else
            {
               previousDesc = previousDesc.getPreviousSibling();
               if (previousDesc != null)
               {
                  previousKey = IntMap.getSiblingKey(key, 0);
                  descOccurrenceCount =
                     previousDesc.getOccurrenceCount(previousKey);
               }
            }
         }

         // At this step all previous descriptors have been browsed
         // If no one is valid (has one occurence) uses the parent and
         // does not consider the parent length
         if (!previousFound)
         {
            previousDesc = this.getParent();
            previousKey = IntMap.getParentKey(key);
            previousLength = 0;
         }
         // Else uses length of the previous valid descriptor
         else
         {
            // Case of variable length of the previous descriptor, force to
            // compute length in the rigth order (from occur 0 to n). This will
            // avoid the recursion stack overflow due to getLength using query.
            // Because the query will call getValue which needs the offset.
            if (previousDesc.getLengthType() != PhysicalAttribute.FIXED)
            {
               for (int i = previousDesc.lengthQuerySolvedId; i < previousKey[previousKey.length - 1]; i++)
               {
                  previousDesc.getLength(IntMap.getSiblingKey(previousKey, i));
                  previousDesc.lengthQuerySolvedId = i;
               }
            }
            previousLength = previousDesc.getLength(previousKey);
         }

         // Get offset of the previous valid descriptor (can be the parent)
         previousOffset = previousDesc.getOffset(previousKey);

         // Compute bit offset
         previousBitsFromOffset =
            previousDesc.getBitOffset()
                  + (previousFactor * (8 * previousLength + previousDesc
                        .getBitLength()));
         this.bitOffset = (int) (previousBitsFromOffset % 8);
         // Compute absolute offset in bytes
         solvedOffset = previousOffset + (previousBitsFromOffset / 8);

         // Case of first occurrence : add offset from previous
         if (occurrence == 0)
         {
            solvedOffset = solvedOffset + this.getOffsetFromPreviousSibling();
         }

         // If offset value type is "unknown", set it to "fixed".
         offsetType = this.getOffsetType();
         if (offsetType == PhysicalAttribute.UNKNOWN)
         {
            this.offset.setType(PhysicalAttribute.FIXED);
         }

         // CD: If offset value type is not "fixed", reset to variable
         // to flush the map.
         // Useful to save memory and improve performances
         if (offsetType != PhysicalAttribute.FIXED)
         // offset.setType(PhysicalAttribute.VARIABLE);
         {
            this.offset.clear();
         }

         // Return computed value
         return solvedOffset;
      }
      // Case of query to be processed
      else
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor.solveOffset() : "
               + "NOT IMPLEMENTED YET !");
         return -1;
      }
   }

   /**
    * Solve the length of the described block. If the query exists then
    * processes it, else loops on children descriptors to sum length of all
    * occurrences (with additional offsets).<br>
    * If descriptor length value type is unknown and all children have a "fixed"
    * or "constant in parent" length value type then desciptor length value type
    * is set to "fixed".<br>
    * For optimisation purpose,if a child descriptor has a "fixed" or "constant
    * in parent" length value type and more than one occurrence, then
    * corresponding length will be get only once from child descriptor and
    * therefore multiplied by occurrence count to get the length of the serie.<br>
    * Once length value solved, it is stored in length attribute for future
    * calls. In case of no query and descriptor with no child, returns -1.
    * 
    * @param key The key of the described block.
    * @return The solved length or -1 if not solved.
    */
   protected final long solveLength(final int[] key)
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.solveLength("
               + IntMap.keyToString(key) + ")");
      }

      // Local declarations
      long totalLength; // Total children length
      boolean fixedChildrenLength; // True if all children have fixed length

      // Set flag fixed flag to true by default, will be changed to false if
      // one child has not a fixed length
      fixedChildrenLength = true;
      totalLength = 0;

      // Case of no query, length is the sum of the children lengths
      if (this.lengthQuery == null)
      {
         // Local declarations
         Descriptor childDesc; // Child descriptor
         long childLength; // Child length
         int childOccurrenceCount; // Child occurrence count
         int childAdditionalOffset; // Additional offset of child desc
         int lengthType; // Length type

         // If descriptor has no child return -1 because value cannot be solved
         if (this.children.size() == 0)
         {
            return -1;
         }

         // Loop on children descriptors
         for (int iDesc = 0; iDesc < this.children.size(); iDesc++)
         {
            // Get Child descriptor
            childDesc = (Descriptor) this.children.get(iDesc);

            // Get child descriptor additional offset
            childAdditionalOffset = childDesc.getOffsetFromPreviousSibling();

            // Get child descriptor occurrence count
            childOccurrenceCount =
               childDesc.getOccurrenceCount(IntMap.getChildKey(key, 0));

            // Loop on occurrences for the current child descriptor
            for (int iOccur = 0; iOccur < childOccurrenceCount; iOccur++)
            {
               // Get current occurrence length
               childLength =
                  childDesc.getLength(IntMap.getChildKey(key, iOccur));

               // Check for unknown length
               if (childLength == -1)
               {
                  this.logger
                        .warn("fr.gael.drb.impl.sdf.Descriptor.solveLength() : "
                              + "Unable to get \""
                              + childDesc.getName()
                              + "\" length.");
                  return -1;
               }

               // At first occurrence check if child descriptor has fixed or
               // constant in parent length in order to call getLength() only
               // once and then multiply by the occurrence count.
               lengthType = childDesc.getLengthType();
               if ((iOccur == 0)
                     && ((lengthType == PhysicalAttribute.FIXED) || (lengthType == PhysicalAttribute.CONSTANT_IN_PARENT)))
               {
                  // Add length of all occurrences of the child desc
                  totalLength =
                     totalLength + childAdditionalOffset
                           + (childLength * childOccurrenceCount);

                  // Set counter to max in order to exit the loop
                  iOccur = childOccurrenceCount;
               }
               // Else adds current occurrence length to total length
               else
               {
                  totalLength =
                     totalLength + childAdditionalOffset + childLength;
               }
            }

            // If child descriptor has not fixed length then set flag to false
            if (childDesc.getLengthType() != PhysicalAttribute.FIXED)
            {
               fixedChildrenLength = false;
            }
         }
      }
      // Case of query to be processed
      else
      {
         int[] keyToUse;
         // In case of FIXED length, the query will be done only once, for
         // the first occurrence of the serie.
         if (this.getLengthType() == PhysicalAttribute.FIXED)
         {
            // Create key of the first occurrence (contains only 0)
            keyToUse = new int[key.length];
            for (int i = 0; i < key.length; i++)
            {
               keyToUse[i] = 0;
            }
         }
         else
         {
            keyToUse = key;
         }

         // Process the query
         totalLength =
            this.queryEval(keyToUse, this.lengthQueryObject, this.lengthQuery);
      }

      // Set the length type if unknown
      if (this.getLengthType() == PhysicalAttribute.UNKNOWN)
      {
         // Case of all children with fixed length
         if (fixedChildrenLength)
         {
            this.setLengthType(PhysicalAttribute.FIXED);
         }
         // Variable case
         else
         {
            this.setLengthType(PhysicalAttribute.VARIABLE);
         }
      }

      // Return total length
      return totalLength;
   }

   /**
    * Eval a query returning a long.
    * 
    * @param key The key of the described block.
    * @param query_obj The query object (initialized or not, will be done).
    * @param query_str The query string (parsed to initialize query_obj if
    *           needed).
    * @return The solved long value or -1 if not solved.
    */
   protected final long queryEval(final int[] key, Query query_obj,
         final String query_str)
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.queryEval(key="
               + IntMap.keyToString(key) + ", query_obj, query_str=\""
               + query_str + "\")");
      }

      // Creates an instance of current node if needed
      // CD : Optimisation pour eviter la creation du contextNode, il n'y a
      // donc qu'un seul new et on ne fait que changer la cle (Warning !)
      // Apparemmet ca change pas beaucoup les perf...(10%)
      if (this.contextNode == null)
      {
         this.contextNode = new DefaultBlock(this, key);
      }
      else
      {
         ((DefaultBlock) this.contextNode).key = key;
      }

      // Parses the query if not done yet
      if (query_obj == null)
      {
         try
         {
            query_obj = new Query(query_str);
         }
         catch (final Exception e)
         {
            this.logger.error("fr.gael.drb.impl.sdf.Descriptor.queryEval() : "
                  + "Cannot parse query (" + e + ")");
            return -1;
         }
      }

      // Eval the query
      final DrbSequence itemList = query_obj.evaluate(this.contextNode);

      if ((itemList == null) || (itemList.getLength() <= 0))
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor.queryEval() : "
               + "Empty result list.");
         return -1;
      }

      final DrbItem resultItem = itemList.getItem(0);
      Value result_value = resultItem.getValue();

      if (result_value == null)
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor.queryEval() : "
               + "Empty result value");
         return -1;
      }

      try
      {
         result_value = result_value.convertTo(Value.INT_ID);
      }
      catch (final ClassCastException e)
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor.queryEval() : "
               + "Cannot convert value to integer.");
         return -1;
      }

      return ((Int) result_value).intValue();
   }

   /**
    * Returns the offset from the previous sibling descriptor.
    * 
    * @return The offset from the previous sibling descriptor.
    */
   protected final int getOffsetFromPreviousSibling()
   {
      return this.offsetFromPreviousSibling;
   }

   /**
    * Sets the offset from the previous sibling descriptor.
    * 
    * @param offset_from_previous_sibling The offset from the previous sibling
    *           descriptor to be set.
    */
   protected final void setOffsetFromPreviousSibling(
         final int offset_from_previous_sibling)
   {
      this.offsetFromPreviousSibling = offset_from_previous_sibling;
   }

   /**
    * Returns the bit offset from the byte offset.
    * 
    * @return int the bit offset
    */
   protected final int getBitOffset()
   {
      return this.bitOffset;
   }

   /**
    * Returns the bit length from the byte length.
    * 
    * @return int the bit length
    */
   protected final int getBitLength()
   {
      return this.bitLength;
   }

   /**
    * Returns the occurrence count of the block associated to the key.
    * 
    * @param key The key of the described block.
    * @return The occurrence count or -1 if not solved.
    */
   protected final int getOccurrenceCount(final int[] key)
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.getOccurrenceCount("
               + IntMap.keyToString(key) + ")");
      }

      // Local declarations
      long tmpValue; // Temporary value

      // Get length value
      tmpValue = this.occurrenceCount.getValue(key);

      // Solve occurrence count if unknown yet
      if (tmpValue == -1)
      {
         this.logger.debug("   case of unknown occurrence count value");
         if ((tmpValue = this.solveOccurrenceCount(key)) == -1)
         {
            // if (this.logger.isEnabledFor(Level.WARN))
            this.logger.debug("   unable to solve occurrence count");

            // Case of occurrence count to solve from the parent
            /*
             * CD: A terminer la resolution des occurrences par le parent if
             * (occurrenceCountFromParent) { this.logger.debug(" solve
             * occurrence count from parent"); Descriptor parentDesc =
             * getParent(); int[] parentKey = IntMap.getParentKey(key);
             * this.logger.debug(" parentLength="+parent.getLength(parentKey)); }
             */

            // this.logger.error(
            // "fr.gael.drb.impl.sdf.Descriptor.getOccurrenceCount() : " +
            // "Unable to solve occurrence count ! Set default to 0.");
            // this.setOccurrenceCountType(PhysicalAttribute.FIXED);
            // this.setOccurrenceCount(key, 0);
            return 0;
         }

         // Set solved value (fixed or not)
         this.setOccurrenceCount(key, tmpValue);
      }

      // Return value
      return (int) tmpValue;
   }

   /**
    * Returns the offset of the block associated to the key (from
    * offsetReference).
    * 
    * @param key The key of the described block.
    * @return The offset or -1 if not solved.
    */
   protected final long getOffset(final int[] key)
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.getOffset("
               + IntMap.keyToString(key) + ")");
      }

      // Local declarations
      long tmpValue; // Temporary value

      // Get length value
      tmpValue = this.offset.getValue(key);

      // Solve offset if unknown
      if (tmpValue == -1)
      {
         // this.logger.debug("getOffset : Case of unknown value");
         tmpValue = this.solveOffset(key);

         // Store the value
         this.setOffset(key, tmpValue);
      }

      // Return value
      return tmpValue;
   }

   /**
    * Returns the length of the block associated to the key.
    * 
    * @param key The key of the described block.
    * @return The length or -1 if not solved.
    */
   protected final long getLength(final int[] key)
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.getLength("
               + IntMap.keyToString(key) + ")");
      }

      // Local declarations
      long tmpValue; // Temporary value

      // Get length value
      tmpValue = this.length.getValue(key);

      // Solve length if unknown
      if (tmpValue == -1)
      {
         // this.logger.debug("getLength : Case of unknown value");
         // Solve value
         tmpValue = this.solveLength(key);
         this.logger.debug("   solveLength=" + tmpValue);

         // Case of array, multiply by element size
         if (this.valueType == Value.ARRAY_ID)
         {
            tmpValue = tmpValue * this.arrayElementSize;
            this.logger.debug("   case of array, length=" + tmpValue);
         }

         // Add padding and store the solved length (fixed or not)
         tmpValue = tmpValue + this.headerPadding + this.footerPadding;
         this.logger.debug("   length with paddings=" + tmpValue);
         this.setLength(key, tmpValue);
      }

      // Return value
      return tmpValue;
   }

   /**
    * Sets the occurrence count value type.
    * 
    * @param type the type
    */
   protected final void setOccurrenceCountType(final int type)
   {
      this.logger.debug("<" + this.name + ">.setOccurrenceCountType(" + type
            + ")");

      // Sets the value type
      this.occurrenceCount.setType(type);
   }

   /**
    * Returns the occurrence count value type.
    * 
    * @return int the occurence count type
    */
   protected final int getOccurrenceCountType()
   {
      // Return the value type
      return this.occurrenceCount.getType();
   }

   /**
    * Sets the offset value type.
    * 
    * @param type the type
    */
   protected final void setOffsetType(final int type)
   {
      this.logger.debug("<" + this.name + ">.setOffsetType(" + type + ")");

      // If offset is variable set also all children to variable
      if (type == PhysicalAttribute.VARIABLE)
      {
         this.logger.debug("   offset is variable, set offset type to VARIABLE"
               + " for all children");
         for (int i = 0; i < this.children.size(); i++)
         {
            ((Descriptor) this.children.get(i)).setOffsetType(type);
         }
      }

      // Sets the value type
      this.offset.setType(type);
   }

   /**
    * Returns the offset value type.
    * 
    * @return int
    */
   protected final int getOffsetType()
   {
      // Return the value type
      return this.offset.getType();
   }

   /**
    * Sets the length value type.
    * 
    * @param type the type
    */
   protected final void setLengthType(final int type)
   {
      this.logger.debug("<" + this.name + ">.setLengthType(" + type + ")");

      // Sets the value type
      this.length.setType(type);
   }

   /**
    * Returns the length value type.
    * 
    * @return int
    */
   protected final int getLengthType()
   {
      // Return the value type
      return this.length.getType();
   }

   /**
    * Sets the occurrenceCount for a specific key. Value must be positive or
    * zero, else value will stay unchanged.
    * 
    * @param key The key of the block.
    * @param value The occurrenceCount value to set for this block.
    */
   protected final void setOccurrenceCount(final int[] key, final long value)
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.setOccurrenceCount(key="
               + IntMap.keyToString(key) + ", value=" + value + ")");
      }

      // Sets the value
      this.occurrenceCount.setValue(key, value);
   }

   /**
    * Sets the offset for a specific key (from offsetReference). Value must be
    * positive or zero, else value will stay unchanged.
    * 
    * @param key The key of the block.
    * @param value The offset value to set for this block.
    */
   protected final void setOffset(final int[] key, final long value)
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.setOffset(key="
               + IntMap.keyToString(key) + ", value=" + value + ")");
      }

      // Sets the value
      this.offset.setValue(key, value);
   }

   /**
    * Sets the length for a specific key. Value must be positive or zero, else
    * value will stay unchanged.
    * 
    * @param key The key of the block.
    * @param value The length value to set for this block.
    */
   protected final void setLength(final int[] key, final long value)
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.setLength(key="
               + IntMap.keyToString(key) + ", value=" + value + ")");
      }

      // Sets the value
      this.length.setValue(key, value);
   }

   /**
    * Returns the path of the base node.
    * 
    * @return DrbNode
    */
   protected final DrbNode getBaseNode()
   {
      return this.baseNode;
   }

   /**
    * Returns the path of the base node.
    * 
    * @return String
    */
   protected final String getBaseNodePath()
   {
      return this.baseNode.getPath();
   }

   /**
    * Returns the path of the schema node.
    * 
    * @return String
    */
   protected final String getSchemaNodePath()
   {
      return this.schemaNodePath;
   }

   /**
    * Returns a reference to the root descriptor.
    * 
    * @return Descriptor
    */
   protected final Descriptor getRoot()
   {
      return this.root;
   }

   /**
    * Sets the current descriptor as root descriptor. This operation must be
    * called when all descriptor tree is built-up. This implementation is a
    * wrapper to the setRoot() operation. If baseNode is null do nothing.
    * 
    * @param base_node The base node to keep a reference from.
    * @param schema_node_path The path of the schema node.
    */
   protected final void setAsRoot(final DrbNode base_node,
         final String schema_node_path)
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.setAsRoot(base_node="
               + ((base_node == null) ? null : base_node.getName())
               + ", schema_node_path=" + schema_node_path + ")");
      }

      // Test parameter
      if (base_node == null)
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor.setAsRoot() : "
               + "base_node is null.");
         return;
      }

      // Wrap to setRoot operation with single ancestors property set to true
      this.setRoot(this, base_node, schema_node_path, true, 0);
   }

   /**
    * Sets references to the root descriptor and base node. All children
    * desciptors will have the root and the given base node references set up.
    * The singleAncestors property is also set with the given parameter and the
    * operation is called for the children using the current
    * isSingleOccurrence() result. If offset type is unknown, it is set to fixed
    * or variable according to the isSingleOccurrence() result.
    * 
    * @param root The root descriptor to keep the reference.
    * @param base_node The base node to keep the reference.
    * @param schema_node_path The path of the schema node.
    * @param single_ancestors True if descriptor has single ancestors.
    * @param depth Depth in the descriptors tree used for key generation
    */
   private final void setRoot(final Descriptor root, final DrbNode base_node,
         final String schema_node_path, final boolean single_ancestors,
         final int depth)
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.setRoot(root="
               + ((root == null) ? null : root.name) + ", base_node="
               + ((base_node == null) ? null : base_node.getName())
               + ", schema_node_path=" + schema_node_path
               + ", single_ancestors=" + single_ancestors + ", depth=" + depth
               + ")");
      }

      // Set root reference
      this.root = root;

      // Set base node reference
      this.baseNode = base_node;

      // Set schema node path reference
      this.schemaNodePath = schema_node_path;

      // Set the singleAncestors property
      this.singleAncestors = single_ancestors;

      // Create default key (first occurrence) for the current depth
      int[] key = new int[] {};
      for (int i = 0; i < depth; i++)
      {
         key = IntMap.getChildKey(key, 0);
      }

      // Get single occurrence result
      final boolean singleOccurrence = this.isSingleOccurrence(key);

      // Set offset attribute type if unknown
      if (this.getOffsetType() == PhysicalAttribute.UNKNOWN)
      {
         // Case of fixed offset
         if (singleOccurrence)
         {
            this.offset.setType(PhysicalAttribute.FIXED);
         }
         // Case of variable offset
         else
         {
            this.offset.setType(PhysicalAttribute.VARIABLE);
         }
      }

      // Loop on children descriptors
      for (int i = 0; i < this.children.size(); i++)
      {
         // Recursive call on children descriptors
         ((Descriptor) this.children.get(i)).setRoot(root, base_node,
               schema_node_path, singleOccurrence, depth + 1);
      }

      // If the occurrence count type is variable
      if (this.getOccurrenceCountType() == PhysicalAttribute.VARIABLE)
      {
         this.logger
               .debug("   occurrence count is variable, check if ancestors are single");

         this.logger.debug("   To be implemented !");
         /*
          * CD: A decommenter pour terminer // Get parent descriptor Descriptor
          * upDesc = this.getParent(); int[] upKey = IntMap.getParentKey(key);
          * for (int i=depth; (i>=0) && (upDesc!=null); i--) { // If parent is
          * not a single occurrence and length type is // UNKNOWN, set it to
          * VARIABLE this.logger.debug(" Check <"+upDesc.getName()+">"); if ((!
          * upDesc.isSingleOccurrence(upKey)) && (upDesc.getLengthType() ==
          * PhysicalAttribute.UNKNOWN)) { this.logger.debug(" Set length type to
          * VARIABLE"); upDesc.setLengthType(PhysicalAttribute.VARIABLE); } //
          * Go to upper descriptor upKey = IntMap.getParentKey(upKey); upDesc =
          * upDesc.getParent(); }
          */
         /*
          * this.logger.debug(" occurrence count is variable, s et length type
          * to"+ " VARIABLE for the parent if it is not a single occurrence");
          * if (parent != null)
          * parent.setOccurrenceCountType(PhysicalAttribute.VARIABLE); // Set
          * ancestors length type to variable if they are not single //
          * occurrence
          */
      }
   }

   /**
    * Returns a reference to the parent descriptor.
    * 
    * @return Descriptor the parent descriptor
    */
   protected final Descriptor getParent()
   {
      return this.parent;
   }

   /**
    * Sets a reference to the parent descriptor. Parent can be null.
    * 
    * @param parent the descriptor parent
    */
   protected final void setParent(final Descriptor parent)
   {
      if (this.logger.isDebugEnabled())
      {
         this.logger.debug("<" + this.name + ">.setParent("
               + ((parent == null) ? null : parent.name) + ")");
      }

      // Set reference
      this.parent = parent;
   }

   /**
    * Returns a reference to the first child descriptor.
    * 
    * @return Decriptor the first child descriptor
    */
   protected final Descriptor getFirstChild()
   {
      return this.getChildAt(0);
   }

   /**
    * Returns a reference to the last child descriptor.
    * 
    * @return Decriptor the last child descriptor
    */
   protected final Descriptor getLastChild()
   {
      return this.getChildAt(this.children.size() - 1);
   }

   /**
    * Returns a reference to the "index"th child descriptor.
    * 
    * @param index the "index"th child
    * @return Descriptor the "index"th child descriptor
    */
   protected final Descriptor getChildAt(final int index)
   {
      // Check parameters
      if (index < 0)
      {
         this.logger.error("fr.gael.drb.impl.sdf.Descriptor.getChildAt() : "
               + "Invalid parameter.");
         this.logger.error("   index = " + index);
         return null;
      }

      // Check children list
      if ((this.children.size() == 0) || (index >= this.children.size()))
      {
         // this.logger.debug("fr.gael.drb.impl.sdf.Descriptor.getChildAt() : "
         // + "Index out of list bounds.");
         // this.logger.debug(" index = " + index);
         // this.logger.debug(" list.size = " + children.size());
         return null;
      }

      // Returns the child descriptor
      return (Descriptor) this.children.get(index);
   }

   /**
    * Returns a reference to the previous sibling descriptor.
    * 
    * @return Descriptor
    */
   protected final Descriptor getPreviousSibling()
   {
      return this.previousSibling;
   }

   /**
    * Sets a reference to the previous sibling descriptor.
    * 
    * @param previous_sibling the previous sibling
    */
   protected final void setPreviousSibling(final Descriptor previous_sibling)
   {
      this.previousSibling = previous_sibling;
   }

   /**
    * Returns a reference to the next sibling descriptor.
    * 
    * @return Descriptor
    */
   protected final Descriptor getNextSibling()
   {
      return this.nextSibling;
   }

   /**
    * Sets a reference to the next sibling descriptor.
    * 
    * @param next_sibling the descriptor of the next sibling
    */
   protected final void setNextSibling(final Descriptor next_sibling)
   {
      this.nextSibling = next_sibling;
   }

   /**
    * Add a child descriptor reference to the children list.
    * 
    * @param new_child the new child to add
    */
   protected final void addChild(final Descriptor new_child)
   {
      // Test parameters
      if (new_child == null)
      {
         this.logger.warn("fr.gael.drb.impl.sdf.Descriptor.addChild() : "
               + "Invalid parameter.");
         this.logger.warn("   new_child is null => children list unchanged.");
         return;
      }

      // Add child to children list
      this.children.add(new_child);
   }

   /**
    * Prints descriptor info into a string.
    * 
    * @return String
    */
   public String toString()
   {
      // Local declarations
      String info = "fr.gael.drb.impl.sdf.Descriptor {\n";
      String tmpStr;

      // Create info string
      info = info + "   Name            : " + this.name + "\n";
      info = info + "   FullName        : " + this.fullName + "\n";

      // Encoding type
      switch (this.encoding)
      {
         case ENCODING_BINARY:
            tmpStr = "BINARY";
            break;
         case ENCODING_ASCII:
            tmpStr = "ASCII";
            break;
         case ENCODING_EBCDIC:
            tmpStr = "EBCDIC";
            break;
         default:
            tmpStr = "" + this.encoding;
            break;
      }
      info = info + "   Encoding        : " + tmpStr + "\n";

      // Occurrence count, offset and length
      info =
         info + "   SingleOccurrence: " + this.isSingleOccurrence(null) + "\n";
      info = info + "   OccurrenceCount : " + this.occurrenceCount + "\n";
      info = info + "   Offset (bytes)  : " + this.offset + "\n";
      info = info + "   Length (bytes)  : " + this.length + "\n";
      info = info + "   bitLength       : " + this.bitLength + "\n";
      info =
         info + "   Prev.Sibl.Offset: " + this.offsetFromPreviousSibling + "\n";
      info =
         info + "   Header padding  : " + this.headerPadding + " ["
               + this.headerPaddingContent + "]\n";
      info =
         info + "   Footer padding  : " + this.footerPadding + " ["
               + this.footerPaddingContent + "]\n";

      // Value type
      switch (this.valueType)
      {
         case Value.UNKNOWN_ID:
            tmpStr = "UNKNOWN_ID";
            break;
         case Value.NULL_ID:
            tmpStr = "NULL_ID";
            break;
         case Value.BOOLEAN_ID:
            tmpStr = "BOOLEAN_ID";
            break;
         case Value.BYTE_ID:
            tmpStr = "BYTE_ID";
            break;
         case Value.UNSIGNED_BYTE_ID:
            tmpStr = "BYTE_ID";
            break;
         case Value.SHORT_ID:
            tmpStr = "SHORT_ID";
            break;
         case Value.UNSIGNED_SHORT_ID:
            tmpStr = "SHORT_ID";
            break;
         case Value.INT_ID:
            tmpStr = "INT_ID";
            break;
         case Value.UNSIGNED_INT_ID:
            tmpStr = "INT_ID";
            break;
         case Value.LONG_ID:
            tmpStr = "LONG_ID";
            break;
         case Value.UNSIGNED_LONG_ID:
            tmpStr = "LONG_ID";
            break;
         case Value.FLOAT_ID:
            tmpStr = "FLOAT_ID";
            break;
         case Value.DOUBLE_ID:
            tmpStr = "DOUBLE_ID";
            break;
         case Value.STRING_ID:
            tmpStr = "STRING_ID";
            break;
         case Value.DATE_ID:
            tmpStr = "DATE_ID";
            break;
         case Value.NUMERIC_ID:
            tmpStr = "NUMERIC_ID";
            break;
         case Value.ARRAY_ID:
            tmpStr = "ARRAY_ID (inside type = " + this.arrayValueType + ")";
            break;
         case Value.OTHER_ID:
            tmpStr = "OTHER_ID";
            break;
         default:
            tmpStr = "" + this.valueType;
            break;
      }
      info = info + "   Value type      : " + tmpStr + "\n";

      // References to parent, root, etc.
      info =
         info + "   Root Name       : "
               + ((this.root == null) ? null : this.root.name) + "\n";
      info =
         info + "   Parent Name     : "
               + ((this.parent == null) ? null : this.parent.name) + "\n";
      info =
         info
               + "   Previous Name   : "
               + ((this.previousSibling == null) ? null
                     : this.previousSibling.name) + "\n";
      info =
         info + "   Next Name       : "
               + ((this.nextSibling == null) ? null : this.nextSibling.name)
               + "\n";
      info = info + "   Children        : { ";
      for (int i = 0; i < this.children.size(); i++)
      {
         info = info + "\"" + ((Descriptor) this.children.get(i)).name + "\" ";
      }
      info = info + "}\n";
      info = info + "}\n";

      // Return info string
      return info;
   }

   /**
    * Constraints a string to a specified length. If the input string is too
    * long it will be truncated as follow:<br>
    * getFixedString("Good Morning", 6, ' ') : "Good M"<br>
    * If the input string is too short it will be completed by the fill
    * character as follow:<br>
    * getFixedString("Good Morning", 16, '* ') : "Good Morning****".
    * 
    * @param in_str The input string.
    * @param length The output length (must be positive).
    * @param fill_char The char used to fill the string if needed.
    * @return The resulting string with the specified length or itself if
    *         lengths are equals or "" (empty String) in case of error.
    */
   public static final String getFixedString(String in_str, final int length,
         final char fill_char)
   {
      // Check parameters
      if (length < 0)
      {
         logger
               .error("Descriptor.getFixedString(): " + "Invalid parameter(s).");
         logger.error("   length = " + length);
         return "";
      }

      // Output length is 0, return empty string
      if (length == 0)
      {
         return "";
      }

      // Null input string, change to empty string
      if (in_str == null)
      {
         in_str = "";
      }

      // Lengths are equal, return the string itself
      final int inStrLength = in_str.length();
      if (inStrLength == length)
      {
         return in_str;
      }

      // Input string is too long, return a substring with good length
      if (inStrLength > length)
      {
         return in_str.substring(0, length);
      }

      // At this step the string is too short, append input string with the
      // needed number of fill characters and return it.
      for (int i = 0; i < (length - inStrLength); i++)
      {
         in_str = in_str + fill_char;
      }
      return in_str;
   }
} // Descriptor
