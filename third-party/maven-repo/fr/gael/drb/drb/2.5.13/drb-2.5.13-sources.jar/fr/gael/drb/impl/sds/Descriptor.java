/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbFactory;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.query.Query;
import fr.gael.drb.value.Comparison;
import fr.gael.drb.value.Int;
import fr.gael.drb.value.Value;
import fr.gael.drb.xsd.XsdElement;
import fr.gael.drb.xsd.XsdListType;
import fr.gael.drb.xsd.XsdSimpleType;
import fr.gael.drb.xsd.XsdType;

/**
 * Description of a single or multiple occurrence block.
 */
class Descriptor implements BlockListener
{
   /**
    * Constant : Encoding is "UNKNOWN".
    */
   static protected final int ENCODING_UNKNOWN = -1;

   /**
    * Constant : Encoding is "BINARY".
    */
   static protected final int ENCODING_BINARY = 1;

   /**
    * Constant : Encoding is "ASCII".
    */
   static protected final int ENCODING_TEXT = 2;


   /**
    * Constant : Charset is "ASCII".
    */
   static protected final String CHARSET_ASCII = "ASCII";

   /**
    * Constant : Charset is "US_ASCII".
    */
   static protected final String CHARSET_US_ASCII = "US-ASCII";
   
   /**
    * Constant : Charset is "EBCDIC".
    */
   static protected final String CHARSET_EBCDIC = "cp037";

   /**
    * Constant : Byte order is "Less Significant Byte" first.
    */
   static protected final int BYTE_ORDERING_LSB = 1;

   /**
    * Constant : Byte order is "Most Significant Byte" first.
    */
   static protected final int BYTE_ORDERING_MSB = 2;

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(Descriptor.class);

   /**
    * Inner-class gathering the padding informations.
    */
   class Padding
   {
      /**
       * The padding in bytes. This is the length to skip before to consider the
       * value in the block. Therefore the real offset of the block value is :
       * offset+headerPadding.
       */
      protected int length;

      /**
       * The padding content string. This is the string defining the content of
       * the padding.
       */
      protected String content;

      /**
       * Build a padding.
       */
      protected Padding(final int length, final String content)
      {
         this.length = length;
         this.content = content;
      }
   } // Padding

   /**
    * Inner class gathering signature information.
    */
   static class Signature
   {
      /**
       * optional use.
       */
      final static int OPTIONAL_USE = 1;

      /**
       * required use.
       */
      final static int REQUIRED_USE = 2;

      /**
       * prohibited use.
       */
      final static int PROHIBITED_USE = 3;

      /**
       * Query to process in order to solve signature.
       */
      protected String query;

      /**
       * The target value.
       */
      protected Value value;

      /**
       * Query object to use to process in order to solve signature.
       */
      protected Query queryObject;

      /**
       * The use of this attribute.
       */
      private int use = OPTIONAL_USE;

      /**
       * Build a prohibited signature.
       */
      protected Signature()
      {
         this.use = PROHIBITED_USE;
         this.value = new fr.gael.drb.value.Boolean(true);
      }

      /**
       * Build a signature.
       */
      protected Signature(final String query)
      {
         this.query = query;
         this.queryObject = new Query(query);
         this.use = REQUIRED_USE;
      }

      /**
       * Build a signature.
       */
      protected Signature(final Value value)
      {
         this.value = value;
         this.use = REQUIRED_USE;
      }

      /**
       * Returns the use of this signature.
       * 
       * @return The use
       */
      public final int getUse()
      {
         return this.use;
      } // getUse
   }

   /**
    * Listener of block events from parent.
    */
   private BlockListener parentListener = new ParentBlockListener();

   /**
    * Listener of block events from previous node.
    */
   private BlockListener previousListener = new PreviousBlockListener();

   /**
    * Listener of block events from previous node.
    */
   private BlockListener childListener = new ChildrenBlockListener();

   /**
    * The file containing the structured data. This random access file will be
    * used to access the data. It has to be given to the constructor and will be
    * shared by the root descriptor and all its children.
    */
   private RandomAccessData file;

   /**
    * The file node. This is the base node wich was used to create the root
    * descriptor from. All descriptors have a reference to this one.
    */
   private DrbNode fileNode;

   /**
    * The file location within the base node. This is the path of the file node.
    */
   protected String fileNodePath;

   /**
    * The base node. This is the base node wich was used to create the root
    * descriptor from. All descriptors have a reference to this one.
    */
   private DrbNode baseNode;

   /**
    * The schema node path. This is the path of the schema node. The path string
    * is stored during descriptor creation in factory. Therefore the value will
    * not be updated in case of schema node changes because schema node
    * descriptors are parsed in factory to create block descriptors. Then no
    * further schema change is applied to descriptors.
    */
   private String schemaNodePath;

   /**
    * The root descriptor. This is the top-level descriptor for a specific
    * structured data file. All descriptors have a reference to this one.
    */
   private Descriptor root;

   /**
    * The depth in the tree.
    */
   private int depth;

   /**
    * The index.
    */
   protected int index;

   /**
    * The parent descriptor. This is a reference to the descriptor of the
    * structure containing the current one. The root descriptor has its parent
    * attribute set to null.
    */
   private Descriptor parent;

   /**
    * The children descriptors. This is a list of references to the children
    * descriptors. The number of children is included in the list. This
    * attribute can be null in case of "leaf" descriptor.
    */
   private ArrayList children;

   /**
    * The substitution descriptors. This is a list of references to the
    * substitution descriptors.
    */
   private ArrayList substitution;

   /**
    * The substitution group.
    */
   private Descriptor substitutionGroup;

   /**
    * The previous sibling descriptor. This is a reference to the descriptor
    * just before this one in the children list of the parent.
    */
   private Descriptor previousSibling;

   /**
    * The next sibling descriptor. This is a reference to the descriptor just
    * after this one in the children list of the parent.
    */
   private Descriptor nextSibling;

   /**
    * The name of the described block. This is the short name of the described
    * block. Other descriptors can have the same. Therefore it cannot be
    * considered as an identifier.<br>
    * For instance it can be "MPH".
    */
   protected String name;

   /**
    * The full name of the described block. This is the detailed name of the
    * described block. Other descriptors can have the same. Therefore it cannot
    * be considered as an identifier.<br>
    * For instance it can be "Main Product Header".
    */
   private String fullName;

   /**
    * The description of the block.
    */
   private XsdElement nodeDesc;

   /**
    * The type of the described block. This is the schema type definition and
    * validator.
    */
   private XsdType type;

   /**
    * The value type of the described block. This is the value type identifier
    * as described in fr.gael.drb.value.Value.
    */
   protected int valueType;

   /**
    * The array value type, used if valueType attribute is ARRAY_ID. This is the
    * value type identifier as described in fr.gael.drb.value.Value used to
    * create the array in case of valueType=ARRAY_ID.
    * 
    * @see Descriptor(file,node) constructor.
    */
   protected int arrayValueType;

   /**
    * The size of the array, used if valueType attribute is ARRAY_ID. This is
    * the size used to create the array in case of valueType=ARRAY_ID.
    * 
    * @see Descriptor(file,node) constructor.
    */
   protected PhysicalAttribute itemCount;

   /**
    * The size of the item in the array, used if valueType attribute is
    * ARRAY_ID. This is the item size used to create the array in case of
    * valueType=ARRAY_ID.
    * 
    * @see Descriptor(file,node) constructor.
    */
   protected LengthAttribute itemLength;

   /**
    * True if descriptor has ancestors with only one block occurrence each. Used
    * to compute the result of isSingleOccurrence(). By default value is set to
    * true and changed to false (or unchanged) while solving occurrence counts.
    */
   private boolean singleAncestors;

   /**
    * The offset from neighbour information. When absolute offset is not set
    * yet, it is usefull to keep the relative information given. For instance it
    * can be set that there is an offset of 8 from the end of the previous
    * sibling.
    */
   protected OffsetAttribute blockOffset;

   /**
    * The outer left padding. This is the length to skip before to consider the
    * value in the block. Therefore the real offset of the block value is :
    * offset+headerPadding.
    */
   protected Padding headerPadding;

   /**
    * The inner left padding. This is the length to skip before to consider the
    * value in the block. Therefore the real offset of the block value is :
    * offset+headerPadding.
    */
   protected Padding leading;

   /**
    * The outer right padding. This is the length to skip after the value in the
    * block. Therefore the real length of the block value is :
    * length-footerPadding.
    */
   protected Padding trailing;

   /**
    * The outer right padding. This is the length to skip after the value in the
    * block. Therefore the real length of the block value is :
    * length-footerPadding.
    */
   protected Padding footerPadding;

   /**
    * The delimiter.
    */
   protected String delimiter;

   /**
    * The arrayDelimiter.
    */
   protected String arrayDelimiter;

   /**
    * The name of the described block. This class is used to manage the
    * different types of naming string fixed or not. It permits to retreive the
    * value for any specific block name.
    */
   protected PhysicalAttribute blockName;

   /**
    * A view descriptor.
    */
   protected SdfViewDescriptor viewDesc;

   /**
    * The number of occurrence(s) of the described block. This class is used to
    * manage the different types of occurrence count : fixed or not. It permits
    * to retreive the value for any specific block occurrence.
    */
   protected PhysicalAttribute occurrenceCount;

   /**
    * The number of children of the described block.
    */
   protected PhysicalAttribute childrenCount;

   /**
    * The substitution descriptors map. This is a list of references to the
    * substitution descriptors.
    */
   private PhysicalAttribute substitutionMap;

   /**
    * The offset in bytes from the beginning of the file. This class is used to
    * manage the different types of offset: fixed or not. It permits to retreive
    * the value for any specific block occurrence.
    */
   protected OffsetAttribute offset;

   /**
    * The content length in bytes. This class is used to manage the different
    * types of length: fixed or not. It permits to retreive the value for any
    * specific block occurrence.
    */
   protected LengthAttribute contentLength;

   /**
    * The total length in bytes. This class is used to manage the different
    * types of length: fixed or not. It permits to retreive the value for any
    * specific block occurrence.
    */
   protected LengthAttribute length;

   /**
    * Encoding method. Unless encoding is specified a child block inheritates
    * the value from its parent.
    */
   protected int encoding;

   /**
    * Charset name.
    */
   protected String charsetName;

   /**
    * Text formatter.
    */
   protected ValueFormat textFormat;

   /**
    * Byte ordering method. Unless encoding is specified a child block
    * inheritates the value from its parent.
    */
   protected int byteOrdering;

   /**
    * Context Node to use for query.eval().
    */
   protected DrbNode contextNode;

   /**
    * Query to process in order to solve value.
    */
   protected String valueQuery;

   /**
    * Query object to use to process in order to solve value.
    */
   protected Query valueQueryObject;

   /**
    * The signature.
    */
   protected Signature signature;

   /**
    * Documentation attached to the descriptor.
    */
   protected String documentation;

   /**
    * Invoked when the block has been replaced.
    * 
    * @param e Contains all necessary values for the processing of the block
    *           changes.
    */
   public void blockReplaced(final BlockEvent e)
   {
      /*
       * logger.debug("<" + getPath() + ">" + ".blockReplaced" +
       * IntMap.keyToString(e.getKey()));
       */
      this.blockOffset.clear();
      this.offset.clear();
      this.contentLength.clear();
      this.length.clear();
      this.itemLength.clear();
      this.itemCount.clear();
      this.childrenCount.clear();
      this.substitutionMap.clear();

      if ((this.substitutionGroup == null) && !e.isParent()
            && (this.length.getAccessType() == PhysicalAttribute.READ_WRITE))
      {
         // Send a replace event to parent
         if (this.getParent() != null)
         {
            this.getParent().childListener.blockReplaced(e);
         }
         // Check next sibling
         if (this.getNextSibling() != null)
         {
            this.getNextSibling().previousListener.blockReplaced(e);
         }
      }

      // Send an replace event to each substitution
      for (int i = 0; i < this.substitution.size(); i++)
      {
         this.getSubstitution(i).blockReplaced(e);
      }

      // Send an insert event to each child
      for (int i = 0; i < this.children.size(); i++)
      {
         this.getChildAt(i).parentListener.blockReplaced(e);
      }
      /*
       * logger.debug(toString() + "\n" + "blockReplaced" +
       * IntMap.keyToString(e.getKey()));
       */
   }

   /**
    * Invoked when the block has been inserted.
    * 
    * @param e Contains all necessary values for the processing of the block
    *           changes.
    */
   public void blockInserted(final BlockEvent e)
   {
      /*
       * logger.debug("<" + getName() + ">" + ".blockInserted" +
       * IntMap.keyToString(e.getKey()));
       */
      this.blockOffset.clear();
      this.offset.clear();
      this.contentLength.clear();
      this.length.clear();
      this.itemLength.clear();
      this.itemCount.clear();
      this.childrenCount.clear();
      this.substitutionMap.clear();

      if ((this.substitutionGroup == null) && !e.isParent())
      {
         // Send a insert event to parent
         if (this.getParent() != null)
         {
            this.getParent().childListener.blockInserted(e);
         }
         // Check next sibling
         if (this.getNextSibling() != null)
         {
            this.getNextSibling().previousListener.blockInserted(e);
         }
      }

      // Send an insert event to each substitution
      for (int i = 0; i < this.substitution.size(); i++)
      {
         this.getSubstitution(i).blockInserted(e);
      }

      // Send an insert event to each child
      for (int i = 0; i < this.children.size(); i++)
      {
         this.getChildAt(i).parentListener.blockInserted(e);
      }
      /*
       * logger.debug(toString() + "\n" + "blockInserted" +
       * IntMap.keyToString(e.getKey()));
       */
   }

   /**
    * Invoked when the block has been removed.
    * 
    * @param e Contains all necessary values for the processing of the block
    *           changes.
    */
   public void blockRemoved(final BlockEvent e)
   {
      /*
       * logger.debug("<" + getName() + ">" + ".blockRemoved" +
       * IntMap.keyToString(e.getKey()));
       */
      this.blockOffset.clear();
      this.offset.clear();
      this.contentLength.clear();
      this.length.clear();
      this.itemLength.clear();
      this.itemCount.clear();
      this.childrenCount.clear();
      this.substitutionMap.clear();

      if ((this.substitutionGroup == null) && !e.isParent())
      {
         // Send a remove event to parent
         if (this.getParent() != null)
         {
            this.getParent().childListener.blockRemoved(e);
         }
         // Check next sibling
         if (this.getNextSibling() != null)
         {
            this.getNextSibling().previousListener.blockRemoved(e);
         }
      }

      // Send an remove event to each substitution
      for (int i = 0; i < this.substitution.size(); i++)
      {
         this.getSubstitution(i).blockRemoved(e);
      }

      // Send an remove event to each child
      for (int i = 0; i < this.children.size(); i++)
      {
         this.getChildAt(i).parentListener.blockRemoved(e);
      }
      /*
       * logger.debug(toString() + "\n" + "blockRemoved" +
       * IntMap.keyToString(e.getKey()));
       */
   }

   /**
    * Invoked when the block has been moved.
    * 
    * @param e Contains all necessary values for the processing of the block
    *           changes.
    */
   public void blockMoved(final BlockEvent e)
   {
      /*
       * logger.debug("<" + getName() + ">" + ".blockMoved" +
       * IntMap.keyToString(e.getKey()));
       */
      this.blockOffset.clear();
      this.offset.clear();

      if ((this.substitutionGroup == null) && !e.isParent())
      {
         // Check next sibling
         if (this.getNextSibling() != null)
         {
            this.getNextSibling().previousListener.blockMoved(e);
         }
         // Send a move event to parent
         else if (this.getParent() != null)
         {
            this.getParent().childListener.blockMoved(e);
         }
      }
      final Descriptor instance_desc = e.getDescriptor();
      if (instance_desc != this)
      {
         instance_desc.blockMoved(e);
      }
      else
      {
         for (int i = 0; i < this.children.size(); i++)
         {
            this.getChildAt(i).parentListener.blockMoved(e);
         }
      }
      /*
       * logger.debug(toString() + "\n" + "blockMoved" +
       * IntMap.keyToString(e.getKey()));
       */
   }

   /**
    * Invoked when the block's size changes.
    * 
    * @param e Contains all necessary values for the processing of the result
    *           changes.
    */
   public void blockResized(final BlockEvent e)
   {
      /*
       * logger.debug("<" + getPath() + ">" + ".blockResized" +
       * IntMap.keyToString(e.getKey()));
       */
      final int[] sibling_key = IntMap.getSiblingKey(e.getKey(), 0);
      final int[] key = e.getKey();

      // Throw a move event to target
      if ((key.length > 0)
            && (key[key.length - 1] + 1 < this.getOccurrenceCount(sibling_key)))
      {
         this.blockOffset.clear();
         this.offset.clear();

         key[key.length - 1] += 1;
         this.blockMoved(new BlockEvent(
               BlockEvent.PREVIOUS | BlockEvent.RESIZE, Descriptor.this, key));
      }
      // Throw a resize event to target
      else if (this.getNextSibling() != null)
      {
         this.getNextSibling().previousListener.blockResized(e);
      }
      else if (this.getParent() != null)
      {
         this.getParent().childListener.blockResized(e);
      }
      /*
       * DEBUG logger.debug(toString() + "\n" + "blockResized" +
       * IntMap.keyToString(e.getKey())); DEBUG
       */
   }

   /**
    * The children descriptor listener.
    */
   class ChildrenBlockListener implements BlockListener
   {
      /**
       * Invoked when the block has been replaced.
       * 
       * @param e Contains all necessary values for the processing of the block
       *           changes.
       */
      public void blockReplaced(final BlockEvent e)
      {
         this.blockResized(e);
      }

      /**
       * Invoked when the block has been inserted.
       * 
       * @param e Contains all necessary values for the processing of the block
       *           changes.
       */
      public void blockInserted(final BlockEvent e)
      {
         /*
          * DEBUG logger.debug(getName() +
          * ".ChildrenBlockListener.blockInserted"); DEBUG
          */
         // Compute the key of this descriptor assumig that the event is coming
         // from a child.
         final int[] key = IntMap.getParentKey(e.getKey());
         // Compute the length if any child block has been inserted.
         Descriptor.this.contentLength.clear();
         Descriptor.this.length.clear();
         final BlockEvent resize_event =
            new BlockEvent(BlockEvent.CHILD | BlockEvent.INSERT,
                  Descriptor.this, key);
         Descriptor.this.length.clear();
         Descriptor.this.contentLength.clear();
         Descriptor.this.blockResized(resize_event);
      }

      /**
       * Invoked when the block has been removed.
       * 
       * @param e Contains all necessary values for the processing of the block
       *           changes.
       */
      public void blockRemoved(final BlockEvent e)
      {
         /*
          * DEBUG logger.debug(getName() + ".ChildrenBlockListener<" +
          * e.getDescriptor().getName() + ">.blockRemoved" +
          * IntMap.keyToString(e.getKey())); DEBUG
          */
         // Compute the key of this descriptor assumig that the event is coming
         // from a child.
         final int[] key = IntMap.getParentKey(e.getKey());
         // Compute the length if any child block has been inserted.
         Descriptor.this.contentLength.clear();
         Descriptor.this.length.clear();
         final BlockEvent resize_event =
            new BlockEvent(BlockEvent.CHILD | BlockEvent.REMOVE,
                  Descriptor.this, key);
         Descriptor.this.length.clear();
         Descriptor.this.contentLength.clear();
         Descriptor.this.blockResized(resize_event);
      }

      /**
       * Invoked when the block has been moved.
       * 
       * @param e Contains all necessary values for the processing of the block
       *           changes.
       */
      public void blockMoved(final BlockEvent e)
      {
         /*
          * DEBUG logger.debug(getName() + ".ChildrenBlockListener<" +
          * e.getDescriptor().getName() + ">.blockMoved" +
          * IntMap.keyToString(e.getKey())); DEBUG
          */
         // Compute the key of this descriptor assumig that the event is coming
         // from a child.
         final int[] key = IntMap.getParentKey(e.getKey());
         // Compute the length if any child block has been inserted.
         final BlockEvent resize_event =
            new BlockEvent(BlockEvent.CHILD | BlockEvent.MOVE, Descriptor.this,
                  key);
         Descriptor.this.length.clear();
         Descriptor.this.contentLength.clear();
         Descriptor.this.blockResized(resize_event);
      }

      /**
       * Invoked when the block's size changes.
       * 
       * @param e Contains all necessary values for the processing of the result
       *           changes.
       */
      public void blockResized(final BlockEvent e)
      {
         /*
          * DEBUG logger.debug(getName() + ".ChildrenBlockListener<" +
          * e.getDescriptor().getName() + ">.blockResized" +
          * IntMap.keyToString(e.getKey())); DEBUG
          */
         // Compute the key of this descriptor assumig that the event is coming
         // from a child.
         final int[] key = IntMap.getParentKey(e.getKey());
         // Compute the length if any child block has been resized.
         final BlockEvent resize_event =
            new BlockEvent(BlockEvent.CHILD | BlockEvent.RESIZE,
                  Descriptor.this, key);
         Descriptor.this.length.clear();
         Descriptor.this.contentLength.clear();
         Descriptor.this.blockResized(resize_event);
      }
   }

   /**
    * The parent descriptor listener.
    */
   class ParentBlockListener implements BlockListener
   {
      /**
       * Invoked when the block has been replaced.
       * 
       * @param e Contains all necessary values for the processing of the block
       *           changes.
       */
      public void blockReplaced(final BlockEvent e)
      {
         /*
          * DEBUG logger.debug(getName() + ".ParentBlockListener<" +
          * e.getDescriptor().getPath() + ">.blockReplaced" +
          * IntMap.keyToString(e.getKey())); DEBUG
          */
         final int[] key = IntMap.getChildKey(e.getKey(), -1);

         Descriptor.this.blockReplaced(new BlockEvent(BlockEvent.PARENT
               | BlockEvent.REPLACE, Descriptor.this, key));
      }

      /**
       * Invoked when the block has been inserted.
       * 
       * @param e Contains all necessary values for the processing of the block
       *           changes.
       */
      public void blockInserted(final BlockEvent e)
      {
         /*
          * DEBUG logger.debug(getName() + ".ParentBlockListener<" +
          * e.getDescriptor().getPath() + ">.blockInserted" +
          * IntMap.keyToString(e.getKey())); DEBUG
          */
         final int[] key = IntMap.getChildKey(e.getKey(), -1);

         Descriptor.this.blockInserted(new BlockEvent(BlockEvent.PARENT
               | BlockEvent.INSERT, Descriptor.this, key));
      }

      /**
       * Invoked when the block has been removed.
       * 
       * @param e Contains all necessary values for the processing of the block
       *           changes.
       */
      public void blockRemoved(final BlockEvent e)
      {
         /*
          * DEBUG logger.debug(getName() + ".ParentBlockListener.blockRemoved:" +
          * IntMap.keyToString(e.getKey())); DEBUG
          */
         // Compute the key of this descriptor assumig that the event is coming
         // from the parent
         final int[] key = IntMap.getChildKey(e.getKey(), -1);
         // Compute the offset if the parent block has been removed.
         final BlockEvent remove_event =
            new BlockEvent(BlockEvent.PARENT | BlockEvent.REMOVE,
                  Descriptor.this, key);
         Descriptor.this.blockRemoved(remove_event);
      }

      /**
       * Invoked when the block has been moved.
       * 
       * @param e Contains all necessary values for the processing of the block
       *           changes.
       */
      public void blockMoved(final BlockEvent e)
      {
         /*
          * DEBUG logger.debug(getName() + ".ParentBlockListener<" +
          * e.getDescriptor().getPath() + ">.blockMoved" +
          * IntMap.keyToString(e.getKey())); DEBUG
          */
         // Compute the key of this descriptor assumig that the event is coming
         // from the parent
         final Descriptor previous_desc = e.getDescriptor();
         final int[] key = IntMap.getChildKey(e.getKey(), 0);
         // Compute the offset if the parent block has been moved.
         final BlockEvent move_event =
            new BlockEvent(BlockEvent.PARENT | BlockEvent.MOVE,
                  Descriptor.this, key);
         Descriptor.this.blockMoved(move_event);
      }

      /**
       * Invoked when the block's size changes.
       * 
       * @param e Contains all necessary values for the processing of the result
       *           changes.
       */
      public void blockResized(final BlockEvent e)
      {
         // Nothing to do
         /*
          * DEBUG logger.debug(getName() + ".ParentBlockListener<" +
          * e.getDescriptor().getPath() + ">.blockResized" +
          * IntMap.keyToString(e.getKey())); DEBUG
          */
      }
   }

   /**
    * The previous descriptor listener.
    */
   class PreviousBlockListener implements BlockListener
   {
      /**
       * Invoked when the block has been replaced.
       * 
       * @param e Contains all necessary values for the processing of the block
       *           changes.
       */
      public void blockReplaced(final BlockEvent e)
      {
         this.blockResized(e);
      }

      /**
       * Invoked when the block has been inserted.
       * 
       * @param e Contains all necessary values for the processing of the block
       *           changes.
       */
      public void blockInserted(final BlockEvent e)
      {
         /*
          * DEBUG logger.debug(getName() +
          * ".PreviousBlockListener.blockInserted"); DEBUG
          */
         // Compute the key of this descriptor assumig that the event is coming
         // from a previous sibling.
         final int[] key = IntMap.getSiblingKey(e.getKey(), 0);

         // Compute the offset the previous block has been moved.
         Descriptor.this.blockMoved(new BlockEvent(BlockEvent.PREVIOUS
               | BlockEvent.INSERT, Descriptor.this, key));
      }

      /**
       * Invoked when the block has been removed.
       * 
       * @param e Contains all necessary values for the processing of the block
       *           changes.
       */
      public void blockRemoved(final BlockEvent e)
      {
         /*
          * DEBUG logger.debug(getName() +
          * ".PreviousBlockListener.blockRemoved"); DEBUG
          */
         // Compute the key of this descriptor assumig that the event is coming
         // from a previous sibling.
         final int[] key = IntMap.getSiblingKey(e.getKey(), 0);

         final BlockEvent move_event =
            new BlockEvent(BlockEvent.PREVIOUS | BlockEvent.REMOVE,
                  Descriptor.this, key);
         Descriptor.this.blockMoved(move_event);
      }

      /**
       * Invoked when the block has been moved.
       * 
       * @param e Contains all necessary values for the processing of the block
       *           changes.
       */
      public void blockMoved(final BlockEvent e)
      {
         /*
          * DEBUG logger.debug(getName() + ".PreviousBlockListener.blockMoved");
          * DEBUG
          */
         // Compute the key of this descriptor assumig that the event is coming
         // from a previous sibling.
         final int[] key = IntMap.getSiblingKey(e.getKey(), 0);

         // Compute the offset the previous block has been moved.
         Descriptor.this.blockMoved(new BlockEvent(BlockEvent.PREVIOUS
               | BlockEvent.MOVE, Descriptor.this, key));
      }

      /**
       * Invoked when the block's size changes.
       * 
       * @param e Contains all necessary values for the processing of the result
       *           changes.
       */
      public void blockResized(final BlockEvent e)
      {
         /*
          * DEBUG logger.debug(getName() +
          * ".PreviousBlockListener.blockResized"); DEBUG
          */
         // Compute the key of this descriptor assumig that the event is coming
         // from a child.
         final int[] key = IntMap.getSiblingKey(e.getKey(), 0);

         // Compute the offset if the previous block has been resized.
         Descriptor.this.blockMoved(new BlockEvent(BlockEvent.PREVIOUS
               | BlockEvent.RESIZE, Descriptor.this, key));
      }
   }

   /**
    * Default constructor with name and fullname. Builds a Descriptor instance
    * setting the name and full_name.
    * 
    * @param file The RandomAccessFile containing the data.
    * @param name The short name.
    * @param full_name The detailed name.
    */
   protected Descriptor(final RandomAccessData file, final String name,
         final String full_name)
   {
      // Set default values
      this.name = name;
      this.fullName = full_name;
      this.file = file;
      this.encoding = ENCODING_UNKNOWN;
      this.charsetName = CHARSET_ASCII;
      this.byteOrdering = BYTE_ORDERING_MSB;
      this.valueType = Value.NULL_ID;
      this.arrayValueType = Value.UNKNOWN_ID;
      this.itemCount = new PhysicalAttribute(PhysicalAttribute.READ_WRITE);
      this.itemLength = new LengthAttribute(PhysicalAttribute.READ_WRITE);
      this.itemLength.setUnit(LengthAttribute.UNIT_BYTE);
      this.children = new ArrayList<Descriptor>();
      this.substitution = new ArrayList<Descriptor>();
      this.substitutionMap =
         new PhysicalAttribute(PhysicalAttribute.READ_WRITE);
      this.occurrenceCount = new PhysicalAttribute(PhysicalAttribute.READ_ONLY);
      this.occurrenceCount.setOccurrenceType(PhysicalAttribute.SINGLE);
      this.occurrenceCount.setValue(1);
      this.childrenCount = new PhysicalAttribute(PhysicalAttribute.READ_WRITE);
      this.offset = new OffsetAttribute(PhysicalAttribute.READ_WRITE);
      this.blockOffset = new OffsetAttribute(PhysicalAttribute.READ_ONLY);
      this.blockOffset.setOccurrenceType(PhysicalAttribute.SINGLE);
      this.blockOffset.setValue(0);
      this.contentLength = new LengthAttribute(PhysicalAttribute.READ_WRITE);
      this.length = new LengthAttribute(PhysicalAttribute.READ_WRITE);
      this.headerPadding = new Padding(0, "");
      this.leading = new Padding(0, "");
      this.trailing = new Padding(0, "");
      this.footerPadding = new Padding(0, "");
      this.delimiter = "";
      this.arrayDelimiter = "";
      this.singleAncestors = true;
      this.index = 0;
   }

   /**
    * Create a block descriptor from a NodeDescriptor.
    * 
    * @param file The RandomAccessFile containing the data.
    * @param create_mode Says whether this file must be created.
    * @param node The schema node descriptor.
    * @param depth The depth in the tree.
    */
   protected Descriptor(final RandomAccessData file, final boolean create_mode,
         final XsdElement node, final int depth)
   {
      // Initialize default values
      this(file, (node.getName() != null ? node.getName() : ""), "");
      /*
       * DEBUG logger.debug("New Descriptor \"" + name + "\""); DEBUG
       */
      this.depth = depth;
      // Set node type
      this.setSchema(node);
      final XsdType node_type = node.getType();
      XsdSimpleType value_type = null;

      // Set node value type
      if (node_type == null)
      {
         logger.warn("The element '" + node.getName() + "' has no type.");
      }
      else
      {
         value_type = node_type.getDatatype();
      }
      if (value_type != null)
      {
         this.setValueType(value_type.getTypeId());
         if (value_type.getVariety() == XsdSimpleType.LIST_VARIETY)
         {
            final XsdListType array_type = (XsdListType) value_type;
            this.arrayValueType = array_type.getItemTypeId();
         }
      }
      else
      {
         this.setValueType(Value.NULL_ID);
      }
   }

   /**
    * Returns the documentation associated to the descriptor.
    * 
    * @return String
    */
   protected final String getDocumentation()
   {
      return this.documentation;
   }

   /**
    * Close this descriptor.
    */
   protected final void dispose()
   {
      try
      {
         if (this.file != null)
         {
            this.file.close();
         }
      }
      catch (final java.io.IOException e)
      {
         logger.error("fr.gael.drb.impl.sdf.Descriptor : "
               + "Cannot close the file.");
      }
   }

   /**
    * Returns true if descriptor and all its parents are associated to only one
    * block each.
    * 
    * @param key int[]
    * @return true if descriptor describes only one block.
    */
   protected final boolean isSingleOccurrence(final int[] key)
   {
      /*
       * DEBUG if (logger.isDebugEnabled()) { logger.debug( "<" + getPath() +
       * ">.isSingleOccurrence(" + IntMap.keyToString(key) + ")"); } DEBUG
       */
      // Return true if single occurrence
      return ((this.singleAncestors) && (this.getOccurrenceCount(key) == 1));
   }

   /**
    * Returns the value type identifer. This identifier is described in
    * fr.gael.drb.value.Value.
    * 
    * @return the value type identifer.
    */
   protected final int getValueType()
   {
      return this.valueType;
   }

   /**
    * Returns the array value type identifer. This identifier is described in
    * fr.gael.drb.value.Value.
    * 
    * @return the array value type identifer.
    */
   protected final int getArrayValueType()
   {
      return this.arrayValueType;
   }

   /**
    * Returns the header padding
    * 
    * @return the element delimiter
    */
   protected final Padding getHeaderPadding()
   {
      return this.headerPadding;
   }

   /**
    * Returns the element delimiter
    * 
    * @return the element delimiter
    */
   protected final String getDelimiter()
   {
      return this.delimiter;
   }

   /**
    * Returns the array delimiter
    * 
    * @return the array delimiter
    */
   protected final String getArrayDelimiter()
   {
      return this.arrayDelimiter;
   }

   /**
    * Returns the XML-Schema type .
    * 
    * @return the XML-Schema type.
    */
   protected final XsdType getType()
   {
      return this.type;
   }

   /**
    * Returns the XML-Schema definition .
    * 
    * @return the XML-Schema definition.
    */
   protected final XsdElement getSchema()
   {
      return this.nodeDesc;
   }

   /**
    * Sets the value type identifer. This identifier is described in
    * fr.gael.drb.value.Value. Value is not checked and therefore must be
    * consistent.
    * 
    * @param value_type the value type
    */
   protected final void setValueType(final int value_type)
   {
      this.valueType = value_type;
   }

   /**
    * Sets the XML-Schema definition.
    * 
    * @param node_desc XsdElement
    */
   protected final void setSchema(final XsdElement node_desc)
   {
      this.nodeDesc = node_desc;
      if ((node_desc != null) && (node_desc.getType() != null))
      {
         this.type = node_desc.getType();
      }
   }

   /**
    * Returns the name of the described block.
    * 
    * @return String
    */
   protected final String getName()
   {
      return this.name;
   }

   /**
    * Returns the path of the described block.
    * 
    * @return String
    */
   protected final String getPath()
   {
      if (this.getParent() != null)
      {
         return this.getParent().getPath() + "/" + this.getName();
      }
      else
      {
         return this.getName();
      }
   }

   /**
    * Returns the full name of the described block.
    * 
    * @return String
    */
   protected final String getFullName()
   {
      return this.fullName;
   }

   /**
    * Returns the number of children descriptor(s).
    * 
    * @return The the number of children descriptors.
    */
   protected int getChildrenCount()
   {
      return this.children.size();
   }

   /**
    * Returns the encoding method of the descriptor.
    * 
    * @return The encoding method of the descriptor.
    */
   protected int getEncoding()
   {
      return this.encoding;
   }

   /**
    * Returns the byte ordering method of the descriptor.
    * 
    * @return The byte ordering method of the descriptor.
    */
   protected int getByteOrdering()
   {
      return this.byteOrdering;
   }

   /**
    * Create a block for the given key.
    * 
    * @param key The key of the described block.
    * @return The encoding method of the descriptor.
    */
   protected final AbstractBlock createOptimalBlock(final int[] key)
   {
      return new DefaultBlock(this, key);
   }

   /**
    * Returns the value of the described block with the given key.
    * 
    * @param key The key of the described block.
    * @return The encoding method of the descriptor.
    */
   protected final Value getValue(final int[] key)

   {
      // Check key
      /*
       * if (!isValidKey(key)) { logger.error( "<" + getPath() + ">.getValue(" +
       * IntMap.keyToString(key) + "):" + " invalid key."); throw new
       * DynamicException("Descriptor.getValue: invalid key=" +
       * IntMap.keyToString(key)); }
       */
      final Value value = this.getValue(key, null, null);
      /*
       * DEBUG logger.debug("<" + getPath()+ ">.getValue(" +
       * IntMap.keyToString(key) + ") = " + value); DEBUG
       */
      return value;
   }

   /**
    * Returns the value of the described block with the given key.
    * 
    * @param key The key of the described block.
    * @param start_offset The stop offset in the file.
    * @param stop_offset The stop offset in the file.
    * @return The encoding method of the descriptor.
    */
   protected final Value getValue(final int[] key, Length start_offset,
         Length stop_offset)
   {
      final Descriptor instance_desc = this.getInstance(key);
      if (instance_desc != this)
      {
         return instance_desc.getValue(key);
      }

      if (this.valueType == fr.gael.drb.value.Value.NULL_ID)
      {
         return null;
      }

      if (this.valueQuery != null)
      {
         return this
               .queryEvalValue(key, this.valueQueryObject, this.valueQuery);
      }

      // Local declarations
      Length value_offset; // Offset
      Length value_length; // Length
      Length item_length = null;
      long item_count = -1;
      final int left_padding = this.leading.length;
      final int right_padding = this.trailing.length;

      // Get length
      if ((this.contentLength.getAccessType() != PhysicalAttribute.READ_ONLY)
            && !(this.contentLength.hasQuery()))
      {
         value_length = null; // unbounded
      }
      else if ((value_length = this.getLength(key)) == null)
      {
         logger.info("fr.gael.drb.impl.sdf.Descriptor.getValue() : "
               + "length is UNKNOWN.");
      }
      else
      {
         value_length = this.contentLength.getLength(key);
      }
      // TBC : hanlde leader and trailer padding
      /*
       * if ((key.length == 0) || (occurrenceCount.getValue(key) == 1))
       */
      /*
       * { left_padding = left_padding + headerPadding.length; right_padding =
       * right_padding + footerPadding.length; }
       */
      /*
       * else { if (key[key.length - 1] == 0) left_padding = left_padding +
       * headerPadding.length; if (occurrenceCount.getValue(key) ==
       * key[key.length - 1]) right_padding = right_padding +
       * footerPadding.length; }
       */

      if (value_length != null)
      {
         value_length.setLength(value_length.getLength() - left_padding
               - right_padding, value_length.getBitLength());
      }
      // In case of array, compute array size
      if (this.valueType == fr.gael.drb.value.Value.ARRAY_ID)
      {
         item_length = this.getItemLength(key);
         item_count = this.getItemOccurrenceCount(key);
      }
      if ((this.valueType == fr.gael.drb.value.Value.ARRAY_ID)
            && (value_length != null)
            && ((item_count < 0) || (item_length == null)))
      {
         if (item_count < 0)
         {
            item_count =
               (8 * value_length.getLength() + value_length.getBitLength())
                     / (8 * item_length.getLength() + item_length
                           .getBitLength());
         }
         else if (item_count != 0)
         {
            item_length =
               new Length(0, (8 * value_length.getLength() + value_length
                     .getBitLength())
                     / item_count);
         }
      }

      // Get offset
      if ((value_offset = this.getOffset(key)) == null)
      {
         logger.error("fr.gael.drb.impl.sdf.Descriptor.getValue() : "
               + "offset is UNKNOWN.");
         return null;
      }

      // Get value from file
      try
      {
         BlockTools blockTools = new BlockTools();
         if (start_offset == null)
         {
            start_offset =
               new Length(value_offset.getLength() + this.headerPadding.length,
                     value_offset.getBitLength());
         }
         else
         {
            start_offset.setLength(value_offset.getLength()
                  + this.headerPadding.length, value_offset.getBitLength());
         }

         if (stop_offset == null)
         {
            stop_offset = new Length(-1, -1);
         }

         if (value_length != null)
         {
            stop_offset.setLength(start_offset.getLength()
                  + value_length.getLength(), start_offset.getBitLength()
                  + value_length.getBitLength());
         }

         Value value =
            blockTools.extractValue(this, start_offset, stop_offset,
                  item_count, item_length);
         if ((value != null) && (value.getType() == Value.STRING_ID)
               && "token".equals(this.type.getName()))
         {
            value = new fr.gael.drb.value.String(value.toString().trim());
         }
         blockTools = null;
         if (value_length != null)
         {
            stop_offset.setLength(start_offset.getLength()
                  + value_length.getLength(), start_offset.getBitLength()
                  + value_length.getBitLength());
         }
         return value;
      }
      // Or remove occurrence if EOF is reached
      catch (final EOFException e)
      {
         logger.error(e);
         logger.error("Descriptor.getValue(): Unable to read value "
               + "for node \"" + this.getPath() + "\" (key="
               + IntMap.keyToString(key) + ").");
      }
      catch (final IOException e)
      {
         logger.error(e);
         logger.error("Descriptor.getValue(): Unable to read value "
               + "for node \"" + this.getPath() + "\" (key="
               + IntMap.keyToString(key) + ").");
      }

      return null;
   }

   /**
    * Sets the value of the described block with the given key. TBD
    * 
    * @param value the value
    * @param key The key of the described block.
    * @return The encoding method of the descriptor.
    * @throws UnsupportedOperationException exception
    */
   protected Value setValue(final Value value, final int[] key)
         throws UnsupportedOperationException
   {
      /*
       * DEBUG if (logger.isDebugEnabled()) { logger.debug( "<" + getPath() +
       * ">.setValue([" + value + "], " + IntMap.keyToString(key) + ")"); }
       * logger.debug( "<" + getPath() + ">.setValue([" + value + "], " +
       * IntMap.keyToString(key) + ")"); DEBUG
       */
      // Local declarations
      Length offset; // Offset
      Length old_length; // Total length of the field
      Length value_length = null;

      // Get length
      if ((old_length = this.getLength(key)) == null)
      {
         throw new UnsupportedOperationException("Descriptor.setValue(): "
               + "length is UNKNOWN.");
      }

      // Case of mutable content length
      if (this.contentLength.isMutable() || (this.contentLength.getValue() < 0))
      {
         value_length = null;
      }
      // Case of fixed content length
      else
      {
         value_length = this.contentLength.getLength(key);
      }

      // Get offset
      if ((offset = this.getOffset(key)) == null)
      {
         throw new UnsupportedOperationException("Descriptor.setValue(): "
               + "offset is UNKNOWN.");
      }

      Length new_length = old_length;

      /**
       * Case of variable length. Copy the node to a temporary file.
       */
      // TBC: Handle bits
      try
      {
         if ((value_length == null)
               && (offset.getLength() < this.getFile().length()))
         {
            final File temp_file =
               File.createTempFile("sdf-" + this.getName() + "-", ".tmp");
            final RandomAccessData output_file =
               new RandomAccessFileData(temp_file);
            new_length =
               this.serializeValue(value, output_file, new Length(0), null);
            output_file.close();
            temp_file.delete();

            this.setLength(key, new_length);
            if ((old_length.getLength() != new_length.getLength())
                  || (old_length.getBitLength() != new_length.getBitLength()))
            {
               final Length old_end_offset =
                  new Length(offset.getLength() + old_length.getLength(),
                        offset.getBitLength() + old_length.getBitLength());
               final Length new_end_offset =
                  new Length(offset.getLength() + new_length.getLength(),
                        offset.getBitLength() + new_length.getBitLength());

               this.getFile().move(old_end_offset, new_end_offset);

               // Fire a resized event
               final BlockEvent e =
                  new BlockEvent(BlockEvent.RESIZE, this, key);
               this.blockResized(e);
            }
         }
      }
      catch (final java.io.IOException e)
      {
         throw new UnsupportedOperationException(
               "Descriptor.setValue(): cannot create temporary file."
                     + e.getMessage());
      }
      if (logger.isDebugEnabled())
      {
         logger.debug("Serializing " + value + " at offset " + offset
               + " length=" + value_length);
      }
      this.serializeValue(value, this.getFile(), offset, value_length);
      if (logger.isDebugEnabled())
      {
         logger.debug("Serializing " + value + " at offset " + offset
               + " length=" + value_length + ". OK");
      }
      // Return the value
      return value;
   }

   /**
    * Copies a descriptor to another descriptor.
    * 
    * @param input_key The key of the calling block.
    * @param input_desc The input descriptor.
    * @param ouput_key The key of the ouput block.
    * @param output_desc The output descriptor
    */
   protected static final void copyChildDescriptor(final int[] input_key,
         final Descriptor input_desc, final int[] output_key,
         final Descriptor output_desc)
   {
      // Local declarations
      Descriptor input_childDesc; // reference to a child descriptor
      Descriptor output_childDesc; // reference to a child descriptor
      int[] input_childKey; // Key of the child
      int[] output_childKey; // Key of the child
      // Create child key for first occurrence
      input_childKey = IntMap.getChildKey(input_key, 0);
      output_childKey = IntMap.getChildKey(output_key, 0);
      for (int i = 0; i < output_desc.getChildrenCount(); i++)
      {
         input_childDesc = (Descriptor) input_desc.children.get(i);
         output_childDesc = (Descriptor) output_desc.children.get(i);
         output_childDesc.setOccurrenceCount(output_childKey,
               input_childDesc.occurrenceCount.getValue(input_childKey));
         copyChildDescriptor(input_childKey, input_childDesc, output_childKey,
               output_childDesc);
      }
   }

   /**
    * Set values recursively, using the passed node. The passed node tree will
    * be parsed and compared to the possible tree defined from the current
    * descriptor.
    * 
    * @param node The node to append as child.
    * @param key The key of the calling block (where to append).
    * @param return_node True if the appended node has to be returned else null
    * @param level Recursive depth level (useful for indenting the printouts).
    * @return The encoding method of the descriptor.
    * @throws UnsupportedOperationException exception
    */
   protected DrbNode appendChild(final DrbNode node, final int[] key,
         final boolean return_node, final int level)
         throws UnsupportedOperationException, IOException
   {
      // Debug info
      /*
       * DEBUG if (logger.isDebugEnabled()) { logger.debug( "<" + getPath() +
       * ">.appendChild(node, key=" + IntMap.keyToString(key) + ", return_node=" +
       * return_node + ", level=" + level + ")"); } DEBUG
       */
      // Local declarations
      Descriptor childDesc; // reference to a child descriptor
      int[] childKey; // Key of the child
      boolean found; // True if child desc is found
      final long childLength; // Length of the child
      final int childrenCount; // Number of children in the node

      // Checks the passed node
      if (node == null)
      {
         throw new NullPointerException(
               "Descriptor.appendChild(): The reference to the node to "
                     + "append is null.");
      }

      // Test if node can accept child
      if (this.getChildrenCount() == 0)
      {
         throw new UnsupportedOperationException("Descriptor.appendChild(): "
               + "\"" + this.getPath() + "\" node does not accept any child.");
      }

      // Get the corresponding descriptor
      found = false;
      childDesc = this.getFirstChild();
      while ((!found) && (childDesc != null))
      {
         // Descriptor cur_desc = childDesc.getNamedInstance(node.getName());
         // Check name
         if (childDesc.isSame(node.getName()))
         {
            found = true;
         }
         // Go to next child
         else
         {
            childDesc = childDesc.getNextSibling();
         }
      }

      // Check that a valid child has been found
      if (!found)
      {
         throw new UnsupportedOperationException("Descriptor.appendChild(): "
               + "\"" + this.getName()
               + "\" node does not accept any child named " + "\""
               + node.getName() + "\".");
      }
      // Create child key for first occurrence
      childKey = IntMap.getChildKey(key, 0);

      // Get occurrence count before appending to build the right child key
      int currentOccurrenceCount = childDesc.getOccurrenceCount(childKey);

      // Create child key for current occurrence
      if (currentOccurrenceCount < 0)
      {
         currentOccurrenceCount = 0;
      }
      childKey = IntMap.getChildKey(key, currentOccurrenceCount);

      return childDesc.insert(node, childKey, return_node, level);
   }

   /**
    * Set values recursively, using the passed node. The passed node tree will
    * be parsed and compared to the possible tree defined from the current
    * descriptor.
    * 
    * @param node The node to insert as child.
    * @param key The key of the calling block (where to insert).
    * @param return_node True if the inserted node has to be returned else null
    * @param level Recursive depth level (useful for indenting the printouts).
    * @return The inserted node or null.
    * @throws UnsupportedOperationException exception
    */
   protected DrbNode insert(final DrbNode node, final int[] key,
         boolean return_node, final int level)
         throws UnsupportedOperationException, IOException
   {
      /*
       * DEBUG logger.debug(getPath() + " insert at " +
       * IntMap.keyToString(key)); DEBUG
       */
      if (this.occurrenceCount.getAccessType() == PhysicalAttribute.READ_ONLY)
      {
         logger.error("AbstractBlock.insert(): "
               + "The occurrence is fixed. Cannot add a new occurrence.");
         throw new UnsupportedOperationException(this.getPath()
               + ": The occurrence count is fixed. Cannot insert a node.");
      }
      // Local declarations
      final int childrenCount; // Number of children in the node
      int[] sibling_key = key; // Create sibling key for first occurrence

      if (key[key.length - 1] != 0)
      {
         sibling_key = IntMap.getSiblingKey(key, 0);
      }

      // Get occurrence count before appending to build the right child key
      int currentOccurrenceCount = this.getOccurrenceCount(sibling_key);

      // Create child key for current occurrence
      if (currentOccurrenceCount < 0)
      {
         currentOccurrenceCount = 0;
      }

      // Case of SDF DrbNode to append
      this.occurrenceCount.setValue(sibling_key, currentOccurrenceCount + 1);

      AbstractBlock block = null;
      if ((node instanceof DrbNodeImpl)
            && ((block =
               (AbstractBlock) ((DrbNodeImpl) node)
                     .getImpl(AbstractBlock.class)) != null)
            && (this.schemaNodePath != null)
            && this.schemaNodePath.equals(block.descriptor.schemaNodePath))
      {
         // TBC: Case of unbounded occurs
         Length old_length = null;
         if (key[key.length - 1] < currentOccurrenceCount)
         {
            old_length = this.getLength(key);
         }

         this.setLength(key, block.getLength());

         final Length node_offset = this.getOffset(key);
         final Length node_length = block.getLength();
         final Length end_offset =
            new Length(node_offset.getLength() + node_length.getLength(),
                  node_offset.getBitLength() + node_length.getBitLength());

         try
         {
            /*
             * DEBUG logger.debug( "Descriptor.insert(): " + "Inserted " +
             * node_length + " byte(s) into \"" + getFile() + "\" at offset=" +
             * node_offset + "."); DEBUG
             */
            this.getFile().move(node_offset, end_offset);
         }
         catch (final IOException ex)
         {
            logger.error(ex);
            logger.error("Descriptor.insert(): " + "Unable to insert "
                  + node_length + " byte(s) into \"" + this.getFile()
                  + "\" at offset=" + node_offset + ".");
            throw new DynamicException(this.getPath() + "Unable to insert "
                  + node_length + " byte(s) into \"" + this.getFile()
                  + "\" at offset=" + node_offset + IntMap.keyToString(key));
         }
         // Copy node directly from file
         final long result =
            copyFileSegment(block.descriptor.getFile(), block.getOffset(), this
                  .getFile(), node_offset, node_length);

         if (result < 0)
         {
            throw new DynamicException(this.getPath() + "Unable to copy "
                  + node_length + " byte(s) into \"" + this.getFile()
                  + "\" at offset=" + node_offset + ". "
                  + IntMap.keyToString(key));
         }

         // Fire a blockInserted event
         this.getBase().blockInserted(
               new BlockEvent(BlockEvent.INSERT, this.getNamedInstance(node
                     .getName()), key));

         copyChildDescriptor(block.key, block.descriptor.getBase(), key, this
               .getBase());

         this.setOffset(key, node_offset);
         this.setLength(key, node_length);
      }
      /**
       * Case of another DrbNode implementation or schema.
       */
      else
      {
         File temp_file = null;
         RandomAccessData output_file = this.getFile();
         final Length node_offset = this.getOffset(key);
         Length output_offset = node_offset;
         Length node_length = null;
         long file_len = java.lang.Long.MAX_VALUE;

         /**
          * Case of variable length. Copy the node to a temporary file.
          */
         if ((this.contentLength.getType() != PhysicalAttribute.FIXED)
               && (node_offset.getLength() < (file_len = output_file.length())))
         {
            try
            {
               temp_file =
                  File.createTempFile("sdf-" + this.getName() + "-", ".tmp");
               output_file = new RandomAccessFileData(temp_file);
               output_offset = new Length(0);
               node_length =
                  this.serializeNode(node, key, output_file, output_offset);
            }
            catch (final IOException ex)
            {
               logger.error(ex);
               logger.error("Descriptor.insert(): "
                     + "Unable to copy the node to the temporary file.");
               this.occurrenceCount.setValue(sibling_key,
                     currentOccurrenceCount);
               throw new DynamicException(this.getPath()
                     + "Unable to copy the node to the temporary file."
                     + IntMap.keyToString(key));
            }
         }

         /**
          * Allocates the block size on the file.
          */
         try
         {
            if (node_offset.getLength() < file_len)
            {
               if (node_length == null)
               {
                  node_length = this.getLength(key); // compute the length
                  if (this.delimiter.length() > 0)
                  {
                     node_length = this.contentLength.getLength(key);
                     node_length =
                        new Length(node_length.getLength()
                              + this.headerPadding.length
                              + this.footerPadding.length
                              + this.delimiter.length(), node_length
                              .getBitLength());
                  }
               }
               final Length end_offset =
                  new Length(node_offset.getLength() + node_length.getLength(),
                        node_offset.getBitLength() + node_length.getBitLength());
               /*
                * DEBUG logger.debug( "Descriptor.insert(): " + "Inserted " +
                * node_length + " byte(s) into \"" + getFile() + "\" at offset=" +
                * node_offset + "."); DEBUG
                */
               this.getFile().move(node_offset, end_offset);
            }
         }
         catch (final IOException ex)
         {
            logger.error(ex);
            logger.error("Descriptor.insert(): " + "Unable to insert "
                  + node_length + " byte(s) into \"" + this.getFile()
                  + "\" at offset=" + node_offset + ".");
            throw new DynamicException(this.getPath()
                  + "Unable to insert the node. " + IntMap.keyToString(key));
         }

         /**
          * Copy the node from the temp file.
          */
         if (temp_file != null)
         {
            // Copy node from temp file
            final long result =
               copyFileSegment(output_file, output_offset, this.getFile(),
                     node_offset, node_length);
            output_file.close();
            temp_file.delete();
         }
         /**
          * Copy the node directly in the file.
          */
         else
         {
            node_length =
               this.serializeNode(node, key, this.getFile(), node_offset);
         }

         // Fire a blockInserted event
         this.getBase().blockInserted(
               new BlockEvent(BlockEvent.INSERT, this.getNamedInstance(node
                     .getName()), key));

         this.setOffset(key, node_offset);
         this.setLength(key, node_length);
      }

      // Returns a new instance of the appended node if necessary
      if (!return_node)
      {
         return null;
      }

      return AbstractBlock.createOptimalBlock(this, key,
            currentOccurrenceCount + 1);
   }

   /**
    * Set values recursively, using the passed node. The passed node tree will
    * be parsed and compared to the possible tree defined from the current
    * descriptor.
    * 
    * @param node The node to replace as child.
    * @param key The key of the calling block (where to replace).
    * @param return_node True if the replaced node has to be returned else null
    * @param level Recursive depth level (useful for indenting the printouts).
    * @return The replaced node or null.
    * @throws UnsupportedOperationException exception
    */
   protected DrbNode replace(final DrbNode node, final int[] key,
         boolean return_node, final int level)
         throws UnsupportedOperationException, IOException
   {
      // Debug info
      /*
       * DEBUG if (logger.isDebugEnabled()) { logger.debug( "<" + getPath() +
       * ">.replace(node, key=" + IntMap.keyToString(key) + ", return_node=" +
       * return_node + ", level=" + level + ")"); } DEBUG
       */
      // Checks the passed node
      if (node == null)
      {
         throw new NullPointerException(
               "Descriptor.replace(): The reference to the node to "
                     + "replace is null.");
      }

      // Check that a valid child has been found
      if (!this.isSame(node.getName()))
      {
         throw new UnsupportedOperationException("Descriptor.replace(): "
               + "\"" + this.getName()
               + "\" node does not accept any child named " + "\""
               + node.getName() + "\".");
      }

      AbstractBlock block = null;
      final Length node_offset = this.getOffset(key);
      Length new_length = null;
      final Length old_length = this.getLength(key);
      if ((node instanceof DrbNodeImpl)
            && ((block =
               (AbstractBlock) ((DrbNodeImpl) node)
                     .getImpl(AbstractBlock.class)) != null)
            && (this.schemaNodePath != null)
            && this.schemaNodePath.equals(block.descriptor.schemaNodePath))
      {
         // TBC: Case of unbounded occurs

         this.setLength(key, block.getLength());

         new_length = block.getLength();
         final Length old_end_offset =
            new Length(node_offset.getLength() + old_length.getLength(),
                  node_offset.getBitLength() + old_length.getBitLength());
         final Length new_end_offset =
            new Length(node_offset.getLength() + new_length.getLength(),
                  node_offset.getBitLength() + new_length.getBitLength());
         try
         {
            if (logger.isDebugEnabled())
            {
               logger.debug("Descriptor<" + this.getPath() + ">.replace(): "
                     + "Replaced " + old_length + " byte(s) " + " from "
                     + block.getOffset() + " by " + new_length
                     + " byte(s) into \"" + this.getFile() + "\" at offset="
                     + node_offset + ".");
            }
            this.getFile().move(old_end_offset, new_end_offset);
         }
         catch (final IOException ex)
         {
            logger.error(ex);
            logger.error("Descriptor.blockReplace(): " + "Unable to replace "
                  + old_length + " byte(s) into \"" + this.getFile()
                  + "\" at offset=" + node_offset + ".");
         }
         // Copy node directly from file
         final long result =
            copyFileSegment(block.descriptor.getFile(), block.getOffset(), this
                  .getFile(), node_offset, block.getLength());

         // Fire a blockReplaced event
         this.getBase().blockReplaced(
               new BlockEvent(BlockEvent.REPLACE, this.getNamedInstance(node
                     .getName()), key));

         copyChildDescriptor(block.key, block.descriptor.getBase(), key, this
               .getBase());

      }
      /**
       * Case of another DrbNode implementation or schema.
       */
      else
      {
         File temp_file = null;
         RandomAccessData output_file = this.getFile();

         /**
          * Case of variable length. Copy the node to a temporary file.
          */
         if ((this.contentLength.getType() != PhysicalAttribute.FIXED)
               && (node_offset.getLength() < output_file.length()))
         {
            try
            {
               temp_file =
                  File.createTempFile("sdf-" + this.getName() + "-", ".tmp");
               output_file = new RandomAccessFileData(temp_file);
               final Length output_offset = new Length(0);
               new_length =
                  this.serializeNode(node, key, output_file, output_offset);

               // Allocate block data
               final Length old_end_offset =
                  new Length(node_offset.getLength() + old_length.getLength(),
                        node_offset.getBitLength() + old_length.getBitLength());
               final Length new_end_offset =
                  new Length(node_offset.getLength() + new_length.getLength(),
                        node_offset.getBitLength() + new_length.getBitLength());

               if (logger.isDebugEnabled())
               {
                  logger.debug("Descriptor<" + this.getPath() + ">.replace(): "
                        + "Replaced " + old_length + " byte(s) by "
                        + new_length + " byte(s) into \"" + this.getFile()
                        + "\" at offset=" + node_offset + ".");
               }
               this.getFile().move(old_end_offset, new_end_offset);

               // Copy node from temp file
               final long result =
                  copyFileSegment(output_file, output_offset, this.getFile(),
                        node_offset, new_length);
               output_file.close();
               temp_file.delete();
            }
            catch (final IOException ex)
            {
               logger.error(ex);
               logger.error("Descriptor.replace(): "
                     + "Unable to copy the node to the temporary file.");
               throw new DynamicException(this.getPath()
                     + "Unable to copy the node to the temporary file."
                     + IntMap.keyToString(key));
            }
         }
         /**
          * Copy the node directly in the file.
          */
         else
         {
            this.serializeNode(node, key, this.getFile(), node_offset);
            new_length = old_length;
         }

         // Fire a blockReplaced event
         this.getBase().blockReplaced(
               new BlockEvent(BlockEvent.REPLACE, this.getNamedInstance(node
                     .getName()), key));
      }
      this.setOffset(key, node_offset);
      this.setLength(key, new_length);

      // Returns a new instance of the replaced node if necessary
      if (!return_node)
      {
         return null;
      }

      return AbstractBlock.createOptimalBlock(this, key, -1);
   }

   /**
    * Remove a block.
    * 
    * @param key The key of the calling block (where to removed).
    * @throws UnsupportedOperationException exception
    */
   protected void remove(final int[] key) throws UnsupportedOperationException
   {
      // Debug info
      /*
       * DEBUG if (logger.isDebugEnabled()) { logger.debug( "<" + getPath() +
       * ">.remove(key=" + IntMap.keyToString(key) + ")"); } DEBUG
       */
      if (this.substitutionGroup != null)
      {
         this.getBase().remove(key);
         return;
      }

      if (this.occurrenceCount.getAccessType() == PhysicalAttribute.READ_ONLY)
      {
         logger.error("Descriptor.remove(): " + this.getPath()
               + " has read-only occurrence.");
         throw new DynamicException(this.getPath()
               + "Unable to remove node with fixed occurrence."
               + IntMap.keyToString(key));
      }
      final int[] sibling_key = IntMap.getSiblingKey(key, 0); // sibling key
      final int currentOccurrenceCount = this.getOccurrenceCount(sibling_key);

      /*
       * DEBUG logger.debug(getName() + ":Descriptor.remove(" +
       * IntMap.keyToString(key) + ")"); DEBUG
       */
      if (currentOccurrenceCount <= 0)
      {
         return;
      }

      final Length src_offset = this.getOffset(key);
      final Length src_length = this.getLength(key);

      try
      {
         this.getFile().move(
               new Length(src_offset.getLength() + src_length.getLength(),
                     src_offset.getBitLength() + src_length.getBitLength()),
               src_offset);
      }
      catch (final IOException ex)
      {
         logger.error(ex);
         logger.error("Descriptor.remove(): " + "Unable to remove "
               + src_length + " byte(s) from \"" + this.getFile()
               + "\" at offset=" + src_offset + ").");
      }

      this.occurrenceCount.setValue(IntMap.getSiblingKey(sibling_key, 0),
            currentOccurrenceCount - 1);

      final BlockEvent remove_event =
         new BlockEvent(BlockEvent.REMOVE, this, key);
      this.blockRemoved(remove_event);
   }

   /**
    * Set values recursively, using the passed node. The passed node tree will
    * be parsed and compared to the possible tree defined from the current
    * descriptor.
    * 
    * @param node The node to create as child.
    * @param key The key of the calling block (where to replace).
    * @param return_node True if the created node has to be returned else null
    * @param level Recursive depth level (useful for indenting the printouts).
    * @return The create node or null.
    * @throws UnsupportedOperationException exception
    */
   protected DrbNode create(final DrbNode node, final int[] key,
         boolean return_node, final int level)
         throws UnsupportedOperationException, IOException
   {
      // Debug info
      /*
       * DEBUG if (logger.isDebugEnabled()) { logger.debug( "<" + getPath() +
       * ">.create(node, key=" + IntMap.keyToString(key) + ", return_node=" +
       * return_node + ", level=" + level + ")"); } DEBUG
       */
      // Checks the passed node
      if (node == null)
      {
         throw new NullPointerException(
               "Descriptor.create(): The reference to the node to "
                     + "replace is null.");
      }

      // Check that a valid child has been found
      if (!this.isSame(node.getName()))
      {
         throw new UnsupportedOperationException("Descriptor.create(): " + "\""
               + this.getName() + "\" node does not accept any child named "
               + "\"" + node.getName() + "\".");
      }

      AbstractBlock block = null;
      final Length node_offset = this.getOffset(key);
      Length new_length = null;
      // Length old_length = getLength(key);
      if ((node instanceof DrbNodeImpl)
            && ((block =
               (AbstractBlock) ((DrbNodeImpl) node)
                     .getImpl(AbstractBlock.class)) != null)
            && (this.schemaNodePath != null)
            && this.schemaNodePath.equals(block.descriptor.schemaNodePath))
      {
         // TBC: Case of unbounded occurs

         this.setLength(key, block.getLength());

         new_length = block.getLength();
         // Length old_end_offset = new Length(
         // node_offset.getLength() +
         // old_length.getLength(),
         // node_offset.getBitLength() +
         // old_length.getBitLength());
         final Length new_end_offset =
            new Length(node_offset.getLength() + new_length.getLength(),
                  node_offset.getBitLength() + new_length.getBitLength());
         if (logger.isDebugEnabled())
         {
            logger.debug("Descriptor<" + this.getPath() + ">.create(): "
                  + "Created " + new_length + " byte(s) into \""
                  + this.getFile() + "\" at offset=" + node_offset + ".");
         }
         // Copy node directly from file
         final long result =
            copyFileSegment(block.descriptor.getFile(), block.getOffset(), this
                  .getFile(), node_offset, block.getLength());

         // Fire a blockCreated event
         // getBase().blockCreate(
         // new BlockEvent (BlockEvent.CREATE,
         // getNamedInstance(node.getName()), key));

         copyChildDescriptor(block.key, block.descriptor.getBase(), key, this
               .getBase());

      }
      /**
       * Case of another DrbNode implementation or schema.
       */
      else
      {
         File temp_file = null;
         RandomAccessData output_file = this.getFile();

         /**
          * Case of variable length. Copy the node to a temporary file.
          */
         if ((this.contentLength.getType() != PhysicalAttribute.FIXED)
               && (node_offset.getLength() < output_file.length()))
         {
            try
            {
               temp_file =
                  File.createTempFile("sdf-" + this.getName() + "-", ".tmp");
               output_file = new RandomAccessFileData(temp_file);
               final Length output_offset = new Length(0);
               new_length =
                  this.serializeNode(node, key, output_file, output_offset);

               // Allocate block data
               // Length old_end_offset = new Length(
               // node_offset.getLength() +
               // old_length.getLength(),
               // node_offset.getBitLength() +
               // old_length.getBitLength());
               final Length new_end_offset =
                  new Length(node_offset.getLength() + new_length.getLength(),
                        node_offset.getBitLength() + new_length.getBitLength());

               if (logger.isDebugEnabled())
               {
                  logger.debug("Descriptor<" + this.getPath() + ">.create(): "
                        + "Created " + new_length + " byte(s) into \""
                        + this.getFile() + "\" at offset=" + node_offset + ".");
               }

               // Copy node from temp file
               final long result =
                  copyFileSegment(output_file, output_offset, this.getFile(),
                        node_offset, new_length);
               output_file.close();
               temp_file.delete();
            }
            catch (final IOException ex)
            {
               logger.error(ex);
               logger.error("Descriptor.create(): "
                     + "Unable to copy the node to the temporary file.");
               throw new DynamicException(this.getPath()
                     + "Unable to copy the node to the temporary file."
                     + IntMap.keyToString(key));
            }
         }
         /**
          * Copy the node directly in the file.
          */
         else
         {
            final Length new_end_offset =
               this.serializeNode(node, key, this.getFile(), node_offset);
            new_length =
               new Length(new_end_offset.getLength() - node_offset.getLength(),
                     new_end_offset.getBitLength() - node_offset.getBitLength());
            if (logger.isDebugEnabled())
            {
               logger.debug("Descriptor{" + this.getPath() + "}"
                     + ".create: Direct serialization. node_offset="
                     + node_offset + " new_length=" + new_length
                     + " new_offset=" + new_end_offset);
            }
         }
      }

      if ((key.length != 0)
            && (this.occurrenceCount.getAccessType() != PhysicalAttribute.READ_ONLY))
      {
         this.occurrenceCount.setValue(IntMap.getSiblingKey(key, 0),
               key[key.length - 1] + 1);
         if (logger.isDebugEnabled())
         {
            logger.debug("Descriptor{" + this.getPath() + "}"
                  + ".create: occurrence=" + this.getOccurrenceCount(key));
         }
      }

      // Returns a new instance of the replaced node if necessary
      if (!return_node)
      {
         return null;
      }

      return AbstractBlock.createOptimalBlock(this, key, -1);
   }

   /**
    * Serializes a node into a file.
    * 
    * @param node The node to serialize.
    * @param output_file The file to write the bytes to.
    * @param output_offset The offset in the output file.
    * @return The length of serialized node or null if not solved.
    */
   protected final Length serializeNode(final DrbNode node, final int[] key,
         final RandomAccessData output_file, final Length output_offset)
   {
      /*
       * System.err.println("IN: <" + getPath() + ">.serializeNode: offset=" +
       * output_offset + "node=" + node);
       */
      final Descriptor instance_desc = this.getNamedInstance(node.getName());
      if (instance_desc != this)
      {
         return instance_desc.serializeNode(node, key, output_file,
               output_offset);
      }

      // Case of leaf, set the value if any
      if (this.valueType != Value.NULL_ID)
      {
         // Wrap to Descriptor
         return this.serializeValue(node.getValue(), output_file,
               output_offset, null);
      }
      try
      {
         Length child_offset =
            new Length(output_offset.getLength(), output_offset.getBitLength());
         output_file.seek(output_offset);
         /**
          * Write header padding if any
          */
         if (this.headerPadding.length > 0)
         {
            output_file.writeBytes(getFixedString(this.headerPadding.content,
                  this.headerPadding.length, ' '));
            child_offset.setLength(child_offset.getLength()
                  + this.headerPadding.length, child_offset.getBitLength());
         }
         /**
          * Write children.
          */
         if (this.getChildrenCount() > 0)
         {
            int[] child_key = null;
            final int[] first_child_key = null;
            if (key != null)
            {
               child_key = IntMap.getChildKey(key, 0);
            }
            Length child_length = null;
            Descriptor child_desc = null; // reference to a child descriptor
            long child_occurs = 0; // occurrence of the child instance
            long max_occurs = 0; // maximum child occurrence
            final int children_count = node.getChildrenCount();
            child_desc = this.getFirstChild();
            child_occurs = 0;
            max_occurs = child_desc.getMaxOccurs();

            // Loop on childen
            for (int i = 0; i < children_count; i++)
            {
               final DrbNode child_node = node.getChildAt(i);

               // Search the child descriptor corresponding to the current node
               while (!child_desc.isSame(child_node.getName()))
               {
                  // Case of missing children
                  if ((child_desc.occurrenceCount.getType() == PhysicalAttribute.FIXED)
                        && (child_occurs < child_desc.occurrenceCount
                              .getValue()))
                  {
                     // Case of fixed length
                     if ((child_desc.contentLength.getType() == PhysicalAttribute.FIXED)
                           && (child_desc.contentLength.getValue() >= 0))
                     {
                        final int padd_length = // the length of the padding and
                           // delimiters
                           child_desc.headerPadding.length
                                 + child_desc.footerPadding.length
                                 + child_desc.delimiter.length();
                        child_occurs =
                           child_desc.occurrenceCount.getValue() - child_occurs;
                        child_length = child_desc.contentLength.getLength(null);
                        child_offset.setLength(child_offset.getLength()
                              + child_occurs
                              * (child_length.getLength() + padd_length),
                              child_offset.getBitLength() + child_occurs
                                    * child_length.getBitLength());
                     }
                     // Case of variable length
                     else
                     {
                        logger.error("Descriptor.serializeNode(): "
                              + "Error while writing content " + "at "
                              + this.getPath() + ": "
                              + "Missing children before \""
                              + child_node.getName() + "\"");
                        throw new UnsupportedOperationException(
                              "Error while writing content " + "at "
                                    + this.getPath() + ": "
                                    + "Missing children before \""
                                    + child_node.getName() + "\"");
                     }
                  }
                  else if ((child_key != null)
                        && (child_desc.occurrenceCount.getType() != PhysicalAttribute.FIXED))
                  {
                     child_key[child_key.length - 1] = 0;
                     child_desc.setOccurrenceCount(child_key, child_occurs);
                  }
                  // Go to the next descriptor
                  child_desc = child_desc.getNextSibling();
                  if (child_desc == null)
                  {
                     logger.error("Descriptor.serializeNode():" + " at "
                           + this.getPath()
                           + "Error while writing content for node \""
                           + child_node.getName() + "\"");
                     throw new UnsupportedOperationException("at "
                           + this.getPath() + ": "
                           + "Cannot find description for node \""
                           + child_node.getName() + "\"\n");
                  }
                  child_occurs = 0;
                  max_occurs = child_desc.getMaxOccurs();
               }
               // Check the occurrence count
               if (child_occurs >= max_occurs)
               {
                  logger.error("Descriptor.serializeNode()" + " at "
                        + this.getPath()
                        + ": occurrence count is over the limit =" + max_occurs
                        + " for child \"" + child_node.getName() + "\"");
                  throw new UnsupportedOperationException(
                        "Error while writing content " + "at " + this.getPath()
                              + ": " + "Occurrence count is over the limit ="
                              + max_occurs + " for child \""
                              + child_node.getName() + "\"");
               }
               child_occurs = child_occurs + 1;
               // Add local offset
               Length local_offset = null;
               Length previous_offset = child_offset;

               if ((child_occurs == 1)
                     && (child_desc.blockOffset.getType() == PhysicalAttribute.FIXED))
               {
                  local_offset = child_desc.blockOffset.getLength(null);
               }
               if (child_desc.blockOffset.getOrigin() == OffsetAttribute.PARENT)
               {
                  previous_offset = output_offset;
               }
               if ((local_offset != null)
                     && (local_offset.getLength() + local_offset.getBitLength() > 0))
               {
                  final Length new_child_offset =
                     new Length(previous_offset.getLength()
                           + local_offset.getLength(), previous_offset
                           .getBitLength()
                           + local_offset.getBitLength());
                  // Clear the segment between the theoric and computed offset
                  if ((this.encoding == ENCODING_TEXT)
                        || (child_desc.encoding == ENCODING_TEXT))
                  {
                     output_file.clear(child_offset, new_child_offset,
                           (byte) ' ');
                  }
                  else
                  {
                     output_file
                           .clear(child_offset, new_child_offset, (byte) 0);
                  }
                  child_offset = new_child_offset;
               }
               // Call recursively to serialize current node child
               if (child_key != null)
               {
                  child_key[child_key.length - 1] = (int) child_occurs - 1;
               }
               child_length =
                  child_desc.serializeNode(child_node, child_key, output_file,
                        child_offset);

               child_offset.setLength(child_offset.getLength()
                     + child_length.getLength(), child_offset.getBitLength()
                     + child_length.getBitLength());
            }

            if ((this.contentLength.getType() == PhysicalAttribute.FIXED)
                  && (this.contentLength.getValue() >= 0))
            {
               final Length content_length = this.contentLength.getLength(null);
               child_offset.setLength(output_offset.getLength()
                     + content_length.getLength() + this.headerPadding.length,
                     output_offset.getBitLength()
                           + content_length.getBitLength());
            }
         }

         /**
          * Write footer padding if any
          */
         if (this.footerPadding.length > 0)
         {
            output_file.seek(child_offset);
            output_file.writeBytes(getFixedString(this.footerPadding.content,
                  this.footerPadding.length, ' '));
         }

         /**
          * Write block delimiter if any.
          */
         if (this.delimiter.length() > 0)
         {
            if (this.footerPadding.length == 0)
            {
               output_file.seek(child_offset);
            }
            output_file.writeBytes(this.delimiter);
         }

         return new Length(child_offset.getLength() + this.footerPadding.length
               + this.delimiter.length() - output_offset.getLength(),
               child_offset.getBitLength() - output_offset.getBitLength());
      }
      // Exceptions
      catch (final IOException e)
      {
         logger.error(e);
         e.printStackTrace();
         logger.error("Descriptor.serializeNode(): "
               + "Error while writing content for node \"" + this.getPath());
         throw new UnsupportedOperationException("Descriptor.serializeNode(): "
               + "\"" + this.getPath());
      }
   }

   /**
    * Serializes a value into a file.
    * 
    * @param node The node to serialize.
    * @param output_file The file to write the bytes to.
    * @param output_offset The offset in the output file.
    * @param default_length The default length of the value
    * @return The length of serialized node.
    */
   protected final Length serializeValue(final Value value,
         final RandomAccessData output_file, final Length output_offset,
         final Length default_length)
   {
      /*
       * DEBUG if (logger.isDebugEnabled()) { logger.debug( "<" + getPath() +
       * ">.serializeValue([" + value + "], " + " offset=" + output_offset +
       * ")"); } DEBUG
       */
      // Local declarations
      Length start_offset = output_offset; // Offset of the value in the file
      Length value_length = null; // Length of the value
      Length item_length = null;
      final Length content_length = null;
      long item_count = -1;
      final Value output_value = null; // Output value converted to output type

      /**
       * Compute the encoding parameters.
       */
      if (this.contentLength.getType() == PhysicalAttribute.FIXED)
      {
         value_length = this.contentLength.getLength(null);
      }
      if (value_length == null)
      {
         value_length = default_length;
      }
      // Specific case of array
      if (this.valueType == fr.gael.drb.value.Value.ARRAY_ID)
      {
         if (this.itemCount.getType() == PhysicalAttribute.FIXED)
         {
            item_count = this.itemCount.getValue();
         }

         if (this.itemLength.getType() == PhysicalAttribute.FIXED)
         {
            item_length = this.itemLength.getLength(null);
         }
      }

      try
      {
         // Place file cursor to offset
         output_file.seek(start_offset);

         // Write header padding to file
         if (this.headerPadding.length > 0)
         {
            output_file.writeBytes(getFixedString(this.headerPadding.content,
                  this.headerPadding.length, ' '));
            start_offset =
               new Length(
                     output_offset.getLength() + this.headerPadding.length,
                     output_offset.getBitLength());
         }

         // Write value to file
         final Length compute_length =
            BlockTools.encodeValue(output_file, this, start_offset,
                  value_length, item_count, item_length, value);

         if (compute_length == null)
         {
            logger.warn("<" + this.getPath() + ">.serializeValue:"
                  + " Cannot encode the value at offset " + start_offset);
            logger.debug(this);
         }
         else if (value_length == null)
         {
            value_length = compute_length;
         }
         // Write footer padding to file
         if (this.footerPadding.length > 0)
         {
            output_file.writeBytes(getFixedString(this.footerPadding.content,
                  this.footerPadding.length, ' '));
         }

         // Write delimiter to file
         if (this.delimiter.length() > 0)
         {
            output_file.writeBytes(this.delimiter);
         }

         return new Length(value_length.getLength() + this.headerPadding.length
               + this.footerPadding.length + this.delimiter.length(),
               value_length.getBitLength());
      }
      // Exceptions
      catch (final IOException e)
      {
         logger.error(e);
         e.printStackTrace();
         logger.error("Descriptor.serializeValue(): "
               + "Error while writing value for node \"" + this.getPath());
         return null;
      }
   } // serializeValue

   /**
    * Copies a file segment to another file. Reads the given number of bytes in
    * the input file, starting from the given input offset. Then writes to the
    * output file, starting to the given output offset. A maximum number of 1024
    * bytes is read at a time in order to avoid memory problem with huge
    * segments.<br>
    * This operation doesn't close any of input and output files.
    * 
    * @param input_file The file to read the bytes from.
    * @param input_offset The offset where to start in input file.
    * @param output_file The file to write the bytes to.
    * @param output_offset The offset in the input file.
    * @param length The number of bytes to copy.
    * @return The length of the bytes read.
    */
   protected static final long copyFileSegment(
         final RandomAccessData input_file, final Length input_offset,
         final RandomAccessData output_file, final Length output_offset,
         final Length length)
   {
      // Check parameters
      if ((input_file == null) || (output_file == null)
            || (input_offset == null) || (output_offset == null)
            || (length == null))
      {
         logger.error("Descriptor.copyFileSegment(): "
               + "Invalid parameter(s) :");
         logger.error("   input_file    = " + input_file);
         logger.error("   input_offset  = " + input_offset);
         logger.error("   output_file   = " + output_file);
         logger.error("   output_offset = " + output_offset);
         logger.error("   length       = " + length);
         return -1;
      }

      int curRead = 0;
      int totalRead = 0;
      try
      {
         // Set input and output files positions
         input_file.seek(input_offset.getLength(), input_offset.getBitLength());
         output_file.seek(output_offset.getLength(), output_offset
               .getBitLength());

         int MAX_BUFFER_SIZE = 10240;
         if (length.getLength() < MAX_BUFFER_SIZE)
         {
            MAX_BUFFER_SIZE = (int) length.getLength();
         }

         // Allocate limited read buffer for huge segment
         byte[] buffer = new byte[MAX_BUFFER_SIZE];

         // Compute the number of loop in case of huge segment and the
         // size of the last part (size < MAX_BUFFER_SIZE then integer)
         final long loopNumber = length.getLength() / MAX_BUFFER_SIZE;
         int curLength = MAX_BUFFER_SIZE;
         int curBitLength = 0;
         final int lastLength = (int) (length.getLength() % MAX_BUFFER_SIZE);

         // Loop on limited segment plus one for last part
         for (long i = 0; i <= loopNumber; i++)
         {
            // Reduce the buffer length for last part to read
            if (i == loopNumber)
            {
               curLength = lastLength;
               curBitLength = length.getBitLength();
               if (curBitLength == 0)
               {
                  buffer = new byte[lastLength];
                  logger.debug("Copying block without " + " remaining bits.");
               }
               else
               {
                  buffer = new byte[lastLength + 1];
                  logger.debug("Copying block with " + curBitLength
                        + " remaining bits.");
               }
            }
            logger.debug("Reading block loop=" + i + "/" + loopNumber
                  + " length=(" + curLength + "," + curBitLength + ") "
                  + " buf_len=" + buffer.length + " totalRead=" + totalRead);

            // Read bytes from input file
            curRead = curLength;

            // Case of copy to the the same file.
            if (input_file == output_file)
            {
               input_file.seek(input_offset.getLength() + totalRead,
                     input_offset.getBitLength());
            }
            if (curBitLength == 0)
            {
               input_file.readFully(buffer);
            }
            else
            {
               input_file.readFully(buffer, 0, new Length(curLength,
                     curBitLength));
            }

            // Case of EOF reached
            if (curRead < curLength)
            {
               if (curRead == -1)
               {
                  logger.info("Descriptor.copyFileSegment(): "
                        + "EOF reached in input file");
                  return totalRead;
               }
               // Create new array with the real size and copy usefull bytes
               final byte[] tmpBuffer = new byte[curRead];
               System.arraycopy(buffer, 0, tmpBuffer, 0, curRead);
               buffer = tmpBuffer;

               // Flag as last read loop
               i = loopNumber;
            }

            // Case of copy to the the same file.
            if (input_file == output_file)
            {
               output_file.seek(output_offset.getLength() + totalRead,
                     output_offset.getBitLength());
            }
            logger.debug("Writing block loop=" + i + "/" + loopNumber
                  + " length=(" + curLength + "," + curBitLength + ") "
                  + " buf_len=" + buffer.length + " totalRead=" + totalRead);
            if (curBitLength == 0)
            {
               output_file.write(buffer);
            }
            else
            {
               output_file
                     .write(buffer, 0, new Length(curLength, curBitLength));
            }
            // Add read bytes to total and write bytes to output file
            totalRead += curRead;
         }
         // Return the number of read bytes
         return totalRead;
      }

      // Exceptions
      catch (final IOException e)
      {
         logger.error(e);
         logger.error("Descriptor.copyFileSegment(): " + "Unable to copy "
               + length + " byte(s) from \"" + input_file + "\" (offset="
               + input_offset + ") to \"" + output_file + "\" (offset="
               + output_offset + ").");
         return -1;
      }
   }

   /**
    * Solve the number of occurrence(s) of the described block. If the total
    * occurrence exceed the specified limit, this function returns immediatly.
    * 
    * @param key The key of the described block.
    * @param occurs_limit The occurrence limit.
    * @return The solved occurrence count or -1 if not solved.
    * @return If the occurrence count is below the limit then it is returned.
    *         Otherwise occurs_limit or -1 if not solved.
    */
   protected final long solveOccurrenceCount(final int[] key, long occurs_limit)
   {
      /*
       * DEBUG if (logger.isDebugEnabled()) logger.debug( "<" + getPath() +
       * ">.solveOccurrenceCount(" + IntMap.keyToString(key) + ")"); DEBUG
       */
      // TBC: check key
      // Case of empty query
      if (!this.occurrenceCount.hasQuery())
      {
         // Case of fixed length
         try
         {
            if ((this.getLengthType() <= LengthAttribute.CONSTANT)
                  && (this.signature == null)
                  && (this.substitution.size() == 0))
            {
               this.occurrenceCount.setValue(key, 1); // temporary settings
               final RandomAccessData file = this.getFile();
               final Length block_offset = this.getOffset(key);
               final Length block_length = this.getLength(key);
               final long file_len = file.length();
               final long occurs =
                  (8 * file_len - 8 * block_offset.getLength() - block_offset
                        .getBitLength())
                        / (8 * block_length.getLength() + block_length
                              .getBitLength());
               this.occurrenceCount.setValue(key, occurs);
               return occurs;
            }

            long occurs = -this.occurrenceCount.getValue(key);
            final int[] sibling_key = IntMap.getSiblingKey(key, 0); // sibling
            // key

            // If the occurrence is unknown, starts at 1
            if (occurs < 1)
            {
               occurs = 1;
            }
            final long file_len = this.getFile().length();
            for (; occurs <= occurs_limit; occurs++)
            {
               this.occurrenceCount.setValue(key, occurs); // temporary
               // settings
               // Create sibling key for this occurrence, only the last key
               // item has to be changed (value starts from 0).
               sibling_key[sibling_key.length - 1] = (int) occurs - 1;
               /*
                * DEBUG logger.debug("<" + getPath() + ">.checkOccurrence(" +
                * IntMap.keyToString(sibling_key) + ")"); DEBUG
                */
               // Check signature
               if (!this.checkSignature(sibling_key))
               {
                  break;
               }
               // Check offset
               final Length current_offset = this.getOffset(sibling_key);
               if (current_offset.getLength() >= file_len)
               {
                  break;
               }
               final Length current_length = this.getLength(sibling_key);
               if (current_offset.getLength() + current_length.getLength() > file_len)
               {
                  break;
               }
            }
            if (occurs > occurs_limit)
            {
               this.occurrenceCount.setValue(key, -occurs_limit - 1);
            }
            else
            {
               this.occurrenceCount.setValue(key, occurs - 1);
            }

            return (long) (occurs - 1);
         }
         catch (final Exception e)
         {
            logger.error("fr.gael.drb.impl.sdf.Descriptor.solveOccurrence() : "
                  + "Cannot solve unbounded occurrence (" + e + ")");
            e.printStackTrace();
            return -1;
         }
      }

      return this.occurrenceCount.solveValue(this.createOptimalBlock(key));
   }

   /**
    * Check the validity of the specified key.
    * 
    * @param key The key of the described block.
    * @return true if the key is valid and false otherwise.
    */
   protected final boolean isValidKey(final int[] key)
   {
      // Case of null key of invalid length
      if ((key == null) || (key.length != this.depth))
      {
         return false;
      }
      // Case of root key ==> ok
      if (key.length == 0)
      {
         return true;
      }

      // Case of index out of bounds
      final int index = key[key.length - 1];
      if ((index < 0)
            || (index >= this.getBase().getOccurrenceCount(
                  IntMap.getSiblingKey(key, 0), (long)index + 1)))
      {
         return false;
      }
      // Otherwise
      return true;
   }

   /**
    * Solve the offset of the described block.
    * 
    * @param key The key of the described block.
    * @return The solved offset or -1 if not solved.
    */
   private final Length solveOffset(final int[] key)
   {
      int occurrence; // Occurrence in the current desc
      occurrence = key[key.length - 1];

      Length localOffset = this.blockOffset.getLength(key);
      if (this.blockOffset.hasQuery())
      {
         localOffset =
            this.blockOffset.solveLength(this.createOptimalBlock(key));
         if (localOffset == null)
         {
            throw new DynamicException(this.getPath()
                  + ": cannot evaluate query for key="
                  + IntMap.keyToString(key));
         }
         this.blockOffset.setLength(key, localOffset);
      }

      Length previousOffset; // Offset of the previous block
      Length solvedOffset; // Solved offset value
      Descriptor previousDesc = null; // reference to a previous descriptor
      int[] previousKey = null; // Key of the previous descriptor

      // Case of block with query
      if ((this.fileNodePath != null) && (occurrence == 0))
      {
         solvedOffset = new Length(0);
      }
      // Case of no query, current offset is the offset plus the length of
      // the previous block.
      else if ((localOffset != null)
            && (this.blockOffset.getOrigin() != OffsetAttribute.ORIGIN_PREVIOUS))
      {
         if ((this.blockOffset.getOrigin() == OffsetAttribute.ORIGIN_ROOT)
               || (this.getParent() == null))
         {
            previousDesc = this.getRoot();
            previousKey = new int[] {};
         }
         else if (this.blockOffset.getOrigin() == OffsetAttribute.ORIGIN_PARENT)
         {
            previousDesc = this.getParent();
            previousKey = IntMap.getParentKey(key);
         }
         previousOffset = previousDesc.getOffset(previousKey);
         // Compute absolute offset
         solvedOffset =
            new Length(previousOffset.getLength()
                  + previousDesc.headerPadding.length, previousOffset
                  .getBitLength());
      }
      else if (!this.offset.hasQuery())
      {
         Length previousLength; // Length of the previous block
         boolean previousFound; // True if the prev. valid sibling found
         int previousFactor; // Factor for previous block length
         int descOccurrenceCount; // Occurrence count in the current desc         
         descOccurrenceCount = occurrence; // nb occur-1 => key value
         previousDesc = this;
         previousFound = false;
         previousFactor = 1;
         // Loop on previous descriptors until a block occurrence is found.
         while ((!previousFound) && (previousDesc != null))
         {
            // If an occurrence is found creates key of the previous sibling
            // which is the last occurrence in the previous descriptor
            if (descOccurrenceCount > 0)
            {
               // If previous descriptor has more than 1 occurrence and
               // "fixed" or "constant in parent" length then optimizes access
               // using first occurrence of the previous serie.
               int lengthType = previousDesc.getLengthType();
               if ((descOccurrenceCount == 1)
                     || (lengthType <= PhysicalAttribute.CONSTANT))
               {
                  // Uses the key of the first occurrence and keeps factor
                  // to multiply it by length of one occurrence
                  previousKey = IntMap.getSiblingKey(key, 0);
                  previousFactor = descOccurrenceCount;
                  if (previousDesc == this)
                  {
                     descOccurrenceCount = descOccurrenceCount + 1;
                  }
               }
               // Else uses last occurrence of the previous serie factor set
               // to 1.
               else
               {
                  previousKey =
                     IntMap.getSiblingKey(key, descOccurrenceCount - 1);
               }

               // at this step a valid previous sibling has been found.
               previousFound = true;
            }
            // Else get previous sibling descriptor and occurrence count if
            // not null (using key of the first occurrence because count is
            // unknown yet).
            else
            {
               previousDesc = previousDesc.getPreviousSibling();
               if (previousDesc != null)
               {
                  previousKey = IntMap.getSiblingKey(key, 0);
                  descOccurrenceCount =
                     previousDesc.getOccurrenceCount(previousKey);
               }
            }
         }

         // At this step all previous descriptors have been browsed
         // If no one is valid (has one occurence) uses the parent and
         // does not consider the parent length
         if (!previousFound)
         {
            previousDesc = this.getParent();
            previousKey = IntMap.getParentKey(key);
            previousOffset = previousDesc.getOffset(previousKey);
            // Compute absolute offset
            solvedOffset =
               new Length(previousOffset.getLength()
                     + previousDesc.headerPadding.length, previousOffset
                     .getBitLength());
         }
         // Else uses length of the previous valid descriptor
         else
         {
            // Case of variable length of the previous descriptor, force to
            // compute length in the right order (from occur 0 to n). This will
            // avoid the recursion stack overflow due to getLength using query.
            // Because the query will call getValue which needs the offset.
            if ((previousDesc.getLengthType() == PhysicalAttribute.VARIABLE)
                  && (descOccurrenceCount > 1))
            {
               int start_index = 0;
               if (previousKey[previousKey.length - 1] > 0)
               {
                  final java.util.SortedSet key_set =
                     new java.util.TreeSet(previousDesc.length
                           .getSiblingKeys(previousKey));
                  if ((key_set != null) && !key_set.isEmpty())
                  {
                     start_index = ((Number) key_set.last()).intValue();
                     if (start_index > previousKey[previousKey.length - 1])
                     {
                        start_index = ((Number) key_set.first()).intValue();
                        if (start_index > previousKey[previousKey.length - 1])
                        {
                           start_index = 0;
                        }
                     }
                  }
               }
               int[] sibling_key =
                  IntMap.getSiblingKey(previousKey, start_index);
               previousOffset = previousDesc.getOffset(sibling_key);
               previousLength = previousDesc.getLength(sibling_key);
               long byte_offset = previousOffset.getLength();
               long bit_offset = previousOffset.getBitLength();
               for (int i = start_index + 1; i <= previousKey[previousKey.length - 1]; i++)
               {
                  sibling_key = IntMap.getSiblingKey(previousKey, i);
                  byte_offset = byte_offset + previousLength.getLength();
                  bit_offset = bit_offset + previousLength.getBitLength();
                  previousDesc.setOffset(sibling_key, new Length(byte_offset,
                        bit_offset));
                  previousLength = previousDesc.getLength(sibling_key);
               }
               byte_offset = byte_offset + previousLength.getLength();
               bit_offset = bit_offset + previousLength.getBitLength();
               // Compute absolute offset
               solvedOffset = new Length(byte_offset, bit_offset);
            }
            else
            {
               previousLength = previousDesc.getLength(previousKey);
               previousOffset = previousDesc.getOffset(previousKey);
               // Compute absolute offset
               solvedOffset =
                  new Length(previousOffset.getLength() + previousFactor
                        * previousLength.getLength(), previousOffset
                        .getBitLength()
                        + previousFactor * previousLength.getBitLength());
            }
         }
      }
      // Case of query to be processed
      else
      {
         solvedOffset = this.offset.solveLength(this.createOptimalBlock(key));
      }

      // Case of first occurrence : add offset from previous
      if (occurrence == 0)
      {
         if (localOffset != null)
         {
            solvedOffset.setLength(solvedOffset.getLength()
                  + localOffset.getLength(), solvedOffset.getBitLength()
                  + localOffset.getBitLength());
         }
         else
         // If offset from parent, compute the relative offset
         if (this.blockOffset.getOrigin() == OffsetAttribute.ORIGIN_PARENT)
         {
            previousDesc = this.getParent();
            previousKey = IntMap.getParentKey(key);
            previousOffset = previousDesc.getOffset(previousKey);
            // Compute relative offset
            localOffset =
               new Length(solvedOffset.getLength() - previousOffset.getLength(),
                     solvedOffset.getBitLength() - previousOffset.getBitLength());
            this.blockOffset.setLength(key, localOffset);
         }
      }
      // Return computed value
      return solvedOffset;
   }

   /**
    * Solve the length of the described block. If the query exists then
    * processes it, else loops on children descriptors to sum length of all
    * occurrences (with additional offsets).<br>
    * If descriptor length value type is unknown and all children have a "fixed"
    * or "constant in parent" length value type then desciptor length value type
    * is set to "fixed".<br>
    * For optimisation purpose,if a child descriptor has a "fixed" or "constant
    * in parent" length value type and more than one occurrence, then
    * corresponding length will be get only once from child descriptor and
    * therefore multiplied by occurrence count to get the length of the serie.<br>
    * Once length value solved, it is stored in length attribute for future
    * calls. In case of no query and descriptor with no child, returns -1.
    * 
    * @param key The key of the described block.
    * @return The solved length or -1 if not solved.
    */
   private final Length solveLength(final int[] key)
   {
      // Local declarations
      Length solvedLength; // the solved length
      long totalLength; // Total children length
      long totalBitLength = 0; // remaining bits of the children length

      // Set flag fixed flag to true by default, will be changed to false if
      // one child and/or value has not a fixed length
      // fixedContentLength = true;
      totalLength = 0;

      // Case of query to process
      if (this.contentLength.hasQuery())
      {
         int[] keyToUse;
         // In case of READ_ONLY length, the query will be done only once, for
         // the first occurrence of the serie.
         if (this.getLengthType() <= PhysicalAttribute.CONSTANT)
         {
            // Create key of the first occurrence (contains only 0)
            keyToUse = new int[key.length];
            for (int i = 0; i < key.length; i++)
            {
               keyToUse[i] = 0;
            }
         }
         else
         {
            keyToUse = key;
         }

         // Process the query
         solvedLength =
            this.contentLength.solveLength(this.createOptimalBlock(keyToUse));
      }
      // Case of no query, length is the sum of the children lengths
      else
      {
         // Check substitution if any
         final Descriptor instance_desc = this.getInstance(key);
         if (instance_desc != this)
         {
            solvedLength = instance_desc.getLength(key);
            return solvedLength;
         }

         // Local declarations
         Descriptor childDesc; // Child descriptor
         Length childLength; // Child length
         int childOccurrenceCount; // Child occurrence count
         Length childAdditionalOffset = new Length(0);
         // Additional offset of child desc
         int lengthType; // Length type

         // Case of element with simple content
         if (this.valueType != Value.NULL_ID)
         {
            if ((this.valueType == Value.ARRAY_ID)
                  && ((this.itemCount.getAccessType() == PhysicalAttribute.READ_ONLY) || this.itemCount
                        .hasQuery())
                  && ((this.itemLength.getAccessType() == PhysicalAttribute.READ_ONLY) || this.itemLength
                        .hasQuery()))
            {
               final int item_occurs = this.getItemOccurrenceCount(key);
               final Length item_length = this.getItemLength(key);
               totalLength = item_occurs * item_length.getLength();
               totalBitLength = item_occurs * item_length.getBitLength();
            }
            else if (this.getEncoding() == ENCODING_TEXT)
            {
               final Length start_offset = new Length(-1, -1);
               final Length stop_offset = new Length(-1, -1);
               final Value value =
                  this.getValue(key, start_offset, stop_offset);
               if (value != null)
               {
                  totalLength =
                     stop_offset.getLength() - start_offset.getLength();
                  // fixedContentLength = false;
               }
               else
               {
                  return null;
               }
            }
            else
            {
               return null;
            }
         }

         // Loop on children descriptors
         final int[] first_child_key = IntMap.getChildKey(key, 0);
         for (int iDesc = 0; iDesc < this.children.size(); iDesc++)
         {
            // Get Child descriptor
            childDesc = (Descriptor) this.children.get(iDesc);
            // Get child descriptor occurrence count
            childOccurrenceCount =
               childDesc.getOccurrenceCount(first_child_key);

            // Get child descriptor additional offset
            if ((childDesc.blockOffset.getOrigin() == OffsetAttribute.ORIGIN_PREVIOUS)
                  && (childOccurrenceCount > 0))
            {
               childAdditionalOffset =
                  childDesc.blockOffset.getLength(first_child_key);
               if (childAdditionalOffset != null)
               {
                  totalLength = totalLength + childAdditionalOffset.getLength();
                  totalBitLength =
                     totalBitLength + childAdditionalOffset.getBitLength();
               }
            }
            else if ((childDesc.blockOffset.getOrigin() == OffsetAttribute.ORIGIN_PARENT)
                  && (childDesc.blockOffset.getValue(null) >= 0))
            {
               solvedLength = childDesc.blockOffset.getLength(first_child_key);
               totalLength = solvedLength.getLength();
               totalBitLength = solvedLength.getBitLength();
            }

            // check if child descriptor has fixed or
            // constant in parent length in order to call getLength() only
            // once and then multiply by the occurrence count.
            lengthType = childDesc.getLengthType();
            if (lengthType <= PhysicalAttribute.CONSTANT)
            {
               // Get first occurrence length
               childLength = childDesc.getLength(first_child_key);
               // Check for unknown length
               if (childLength == null)
               {
                  logger
                        .warn("fr.gael.drb.impl.sdf.Descriptor.solveLength() : "
                              + "Unable to get \""
                              + childDesc.getPath()
                              + "\" length.");
                  throw new DynamicException("Unable to get \""
                        + childDesc.getPath() + "\" length.");
               }
               // Add length of all occurrences of the child desc
               totalLength =
                  totalLength
                        + (childLength.getLength() * childOccurrenceCount);
               totalBitLength =
                  totalBitLength
                        + (childLength.getBitLength() * childOccurrenceCount);
            }
            else
            {
               // Loop on occurrences for the current child descriptor
               for (int iOccur = 0; iOccur < childOccurrenceCount; iOccur++)
               {
                  // Get current occurrence length
                  childLength =
                     childDesc.getLength(IntMap.getChildKey(key, iOccur));

                  // Check for unknown length
                  if (childLength == null)
                  {
                     logger
                           .warn("fr.gael.drb.impl.sdf.Descriptor.solveLength() : "
                                 + "Unable to get \""
                                 + childDesc.getName()
                                 + "[" + iOccur + "]" + "\" length.");
                     throw new DynamicException("Unable to get \""
                           + childDesc.getName() + "[" + iOccur + "]"
                           + "\" length.");
                  }
                  totalLength = totalLength + childLength.getLength();
                  totalBitLength = totalBitLength + childLength.getBitLength();
               }
            }
         }
         solvedLength = new Length(totalLength, (long) totalBitLength);
      }
      // Return total length
      return solvedLength;
   }

   /**
    * Eval a query returning a long.
    * 
    * @param key The key of the described block.
    * @param query_obj The query object (initialized or not, will be done).
    * @param query_str The query string (parsed to initialize query_obj if
    *           needed).
    * @return The solved long value or -1 if not solved.
    */
   protected final long queryEval(final int[] key, Query query_obj,
         final String query_str)
   {
      /*
       * DEBUG if (logger.isDebugEnabled()) logger.debug( "<" + getPath() +
       * ">.queryEval(key=" + IntMap.keyToString(key) + ", query_obj,
       * query_str=\"" + query_str + "\")"); DEBUG
       */
      this.contextNode = this.createOptimalBlock(key);

      // Parses the query if not done yet
      if (query_obj == null)
      {
         try
         {
            query_obj = new Query(query_str);
         }
         catch (final Exception e)
         {
            logger.error("fr.gael.drb.impl.sdf.Descriptor.queryEval() : "
                  + "Cannot parse query (" + e + ")");
            return -1;
         }
      }

      // Eval the query
      final DrbSequence item_list = query_obj.evaluate(this.contextNode);

      if ((item_list == null) || (item_list.getLength() <= 0))
      {
         /*
          * DEBUG logger.debug( "fr.gael.drb.impl.sdf.Descriptor.queryEval() : " +
          * "Empty result list. (query='" + query_str + "'"); DEBUG
          */
         return -1;
      }

      final DrbItem result_item = item_list.getItem(0);
      Value result_value = result_item.getValue();

      if (result_value == null)
      {
         /*
          * DEBUG logger.debug( "fr.gael.drb.impl.sdf.Descriptor.queryEval() : " +
          * "Empty result value"); DEBUG
          */
         return -1;
      }

      try
      {
         result_value = result_value.convertTo(Value.INT_ID);
      }
      catch (final ClassCastException e)
      {
         logger.error("fr.gael.drb.impl.sdf.Descriptor.queryEval() : "
               + "Cannot convert value '" + result_value + "' to integer."
               + result_value.getClass() + "\n");
         return -1;
      }
      return ((Int) result_value).intValue();
   }

   /**
    * Eval a query returning a value.
    * 
    * @param key The key of the described block.
    * @param query_obj The query object (initialized or not, will be done).
    * @param query_str The query string (parsed to initialize query_obj if
    *           needed).
    * @return The solved value or -1 if not solved.
    */
   protected final Value queryEvalValue(final int[] key, Query query_obj,
         final String query_str)
   {
      /*
       * DEBUG if (logger.isDebugEnabled()) logger.debug( "<" + getPath() +
       * ">.queryEvalValue(key=" + IntMap.keyToString(key) + ", query_obj,
       * query_str=\"" + query_str + "\")"); DEBUG
       */
      this.contextNode = this.createOptimalBlock(key);

      // Parses the query if not done yet
      if (query_obj == null)
      {
         try
         {
            query_obj = new Query(query_str);
         }
         catch (final Exception e)
         {
            logger.error("fr.gael.drb.impl.sdf.Descriptor.queryEval() : "
                  + "Cannot parse query (" + e + ")");
            return null;
         }
      }

      // Eval the query
      final DrbSequence item_list = query_obj.evaluate(this.contextNode);

      if ((item_list == null) || (item_list.getLength() <= 0))
      {
         logger.error("fr.gael.drb.impl.sdf.Descriptor.queryEval() : "
               + "Empty result list. (query='" + query_str + "'");
         return null;
      }

      final DrbItem result_item = item_list.getItem(0);
      final Value result_value = result_item.getValue();

      return result_value;
   }

   /**
    * Check the signature of the block associated to the key
    * 
    * @param key The key of the described block.
    * @return true if the block is valid and false otherwise
    */
   protected final boolean checkSignature(final int[] key)
   {
      /*
       * DEBUG if (logger.isDebugEnabled()) { logger.debug( "<" + getPath() +
       * ">.checkSignature(" + IntMap.keyToString(key) + ")"); } DEBUG
       */
      // Return signature
      if (this.signature != null)
      {
         if (this.signature.query != null)
         {
            return (this.queryEval(key, this.signature.queryObject,
                  this.signature.query) == 1);
         }
         else
         {
            return ((Comparison) this.signature.value).compareTo(this
                  .getValue(key)) == 0;
         }
      }

      if (!this.type.isComplex() || (this.substitution.size() == 0))
      {
         return true;
      }

      for (int idesc = 0; idesc < this.substitution.size(); idesc++)
      {
         final Descriptor substitution_desc =
            (Descriptor) this.substitution.get(idesc);
         if (substitution_desc.checkSignature(key))
         {
            return true;
         }
      }
      return false;
   }

   /**
    * Returns the base descriptor.
    * 
    * @return the base of this descriptor.
    */
   protected final Descriptor getBase()
   {
      if (this.substitutionGroup == null)
      {
         return this;
      }
      else
      {
         return this.substitutionGroup.getBase();
      }
   }

   /**
    * Returns a concrete instance of the block associated to the key
    * 
    * @param key The key of the described block.
    * @return the concrete instance of the descriptor associated to the key
    */
   protected final Descriptor getInstance(final int[] key)
   {
      /*
       * DEBUG if (logger.isDebugEnabled()) { logger.debug( "<" + getPath() +
       * ">.getInstance(" + IntMap.keyToString(key) + ")"); } DEBUG
       */

      if (this.substitution.size() <= 0)
      {
         return this;
      }

      // Check the substitution map
      int idesc = (int) this.substitutionMap.getValue(key);
      if (idesc != -1)
      {
         return (Descriptor) this.substitution.get(idesc);
      }

      for (idesc = 0; idesc < this.substitution.size(); idesc++)
      {
         final Descriptor substitution_desc =
            (Descriptor) this.substitution.get(idesc);
         if (substitution_desc.checkSignature(key))
         {
            this.substitutionMap.setValue(key, (long) idesc);
            return substitution_desc;
         }
      }
      // Return descriptor
      return this;
   }

   /**
    * Says this descriptor is signed.
    * 
    * @return true if this descriptor has a signature and false otherwise.
    */
   protected final boolean hasSignature()
   {
      return (this.signature != null) || (this.substitution.size() > 0);
   }

   /**
    * Returns a substitution associated to the index
    * 
    * @param index The index of the susbtitution descriptor
    * @return the substitition associated to the index
    */
   protected final Descriptor getSubstitution(final int index)
   {
      return (Descriptor) this.substitution.get(index);
   }

   /**
    * Returns the number of substitution for this descriptor.
    * 
    * @return the number of substitution for this descriptor.
    */
   protected final int getSubstitutionCount()
   {
      return this.substitution.size();
   }

   /**
    * Returns a concrete instance of the block associated to the name
    * 
    * @param name The name of the described block.
    * @return the concrete instance of the descriptor associated to the name or
    *         null if not found.
    */
   protected final Descriptor getNamedInstance(final String name)
   {
      if (this.name.equals(name))
      {
         return this;
      }

      // Check the substitution map
      for (int idesc = 0; idesc < this.substitution.size(); idesc++)
      {
         Descriptor substitution_desc = this.getSubstitution(idesc);
         substitution_desc = substitution_desc.getNamedInstance(name);
         if (substitution_desc != null)
         {
            return substitution_desc;
         }
      }
      // Return descriptor
      return null;
   }

   /**
    * Returns a child descriptor associated to the name
    * 
    * @param name The name of the child block.
    * @return the child descriptor associated to the name or null if not found.
    */
   protected final Descriptor getNamedChild(final String name)
   {
      Descriptor childDesc = this.getFirstChild(); // ref to a child descriptor

      while (childDesc != null)
      {
         // Check name
         if (childDesc.isSame(name))
         {
            return childDesc;
         }
         // Go to next child
         else
         {
            childDesc = childDesc.getNextSibling();
         }
      }
      // Return null
      return null;
   }

   /**
    * Says if this descriptor corresponds to a specified name.
    * 
    * @param name The name of the described block.
    * @return true if the descriptor has the same name and false otherwise.
    */
   protected final boolean isSame(final String name)
   {
      if (this.name.equals(name))
      {
         return true;
      }

      // Check the substitution map
      for (int idesc = 0; idesc < this.substitution.size(); idesc++)
      {
         final Descriptor substitution_desc = this.getSubstitution(idesc);
         if (substitution_desc.isSame(name))
         {
            return true;
         }
      }
      return false;
   }

   /**
    * Tab.
    */
   private static String tab = "";

   /**
    * Returns the maximum occurrence count allowed.
    * 
    * @return the maximum occurrence count
    */
   protected final Long getMaxOccurs()
   {
      if (this.occurrenceCount.getAccessType() == PhysicalAttribute.FIXED)
      {
         return this.occurrenceCount.getValue();
      }
      else
      {
         return java.lang.Long.MAX_VALUE;
      }
   }

   /**
    * Returns the name of the block associated to the key
    * 
    * @param key The key of the described block.
    * @return The name or null if not solved.
    */
   protected final String getNodeName(final int[] key)
   {
      return this.name;
   }

   /**
    * Returns the occurrence count of the block associated to the key.
    * 
    * @param key The key of the described block.
    * @return The occurrence count or -1 if not solved.
    */
   protected final int getOccurrenceCount(final int[] key)
   {
      /*
       * DEBUG if (logger.isDebugEnabled()) { logger.debug( "<" + name +
       * ">.getOccurrenceCount(" + IntMap.keyToString(key) + ")"); } DEBUG
       */
      return this.getOccurrenceCount(key, java.lang.Long.MAX_VALUE);
   }

   /**
    * Returns the children count of the block associated to the key.
    * 
    * @param key The key of the described block.
    * @param occurs_limit The occurrence limit.
    * @return The children count or -1 if not solved.
    */
   protected final int getChildrenCount(final int[] key, final int occurs_limit)
   {
      final Descriptor instance_desc = this.getInstance(key);
      if (instance_desc != this)
      {
         return instance_desc.getChildrenCount(key, occurs_limit);
      }

      // Local declarations
      final long tmpValue = this.childrenCount.getValue(key);

      if (tmpValue >= 0)
      {
         return (int) tmpValue;
      }

      // Local declarations
      Descriptor childDesc; // reference to a child descriptor
      int childrenCount; // number of children

      // Loop on child descriptors.
      childrenCount = 0;
      childDesc = this.getFirstChild();
      while (childDesc != null)
      {
         final int current_count =
            childDesc.getOccurrenceCount(IntMap.getChildKey(key, 0),
                  (long)occurs_limit - childrenCount);
         // Add occurrence number of this child descriptor to the count
         childrenCount += current_count;
         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
         if (childrenCount >= occurs_limit)
         {
            break;
         }
      }

      // Set solved value (fixed or not)
      if (childDesc == null)
      {
         this.childrenCount.setValue(key, (long) childrenCount);
      }

      // All children descriptors have been browsed then returns the
      // children block count.
      return childrenCount;
   }

   /**
    * Returns the occurrence count of the block associated to the key. If the
    * total occurrence exceed the specified limit, this function returns
    * immediatly.
    * 
    * @param key The key of the described block.
    * @param occurs_limit The occurrence limit.
    * @return If the occurrence count or is below the limit then it is returned.
    *         Otherwise occurs_limit or -1 if not solved.
    */
   protected final int getOccurrenceCount(final int[] key,
         final Long occurs_limit)
   {
      // Local declarations
      long tmpValue = -1; // Temporary value

      // Get length value
      tmpValue = this.occurrenceCount.getValue(key);

      // Solve occurrence count if unknown yet
      if (tmpValue < 0)
      {
         /*
          * DEBUG logger.debug(" case of unknown occurrence count value"); DEBUG
          */
         if ((tmpValue = this.solveOccurrenceCount(key, occurs_limit)) == -1)
         {
            logger.debug("Unable to solve occurrence count for node "
                  + this.getPath());

            return 0;
         }

         /*
          * DEBUG if (logger.isDebugEnabled()) { logger.debug("<" + name +
          * ">.solveOccurrence(" + IntMap.keyToString(key) + ") = " + tmpValue); }
          * DEBUG
          */

         // Set solved value (fixed or not)
         if (this.occurrenceCount.hasQuery())
         {
            this.setOccurrenceCount(key, tmpValue);
         }
      }
      // Return value
      return (int) tmpValue;
   }

   /**
    * Returns the occurrence count of the block item item associated to the key.
    * 
    * @param key The key of the described block.
    * @return The occurrence count or -1 if not solved.
    */
   protected final int getItemOccurrenceCount(final int[] key)
   {
      /*
       * DEBUG if (logger.isDebugEnabled()) { logger.debug( "<" + name +
       * ">.getItemOccurrenceCount(" + IntMap.keyToString(key) + ")"); } DEBUG
       */

      // Local declarations
      long tmpValue; // Temporary value

      // Get length value
      tmpValue = this.itemCount.getValue(key);

      // Solve occurrence count if unknown yet
      if ((tmpValue < 0) && this.itemCount.hasQuery())
      {
         /*
          * DEBUG logger.debug(" case of unknown occurrence count value"); DEBUG
          */
         if ((tmpValue =
            this.itemCount.solveValue(this.createOptimalBlock(key))) == -1)
         {
            // if (logger.isEnabledFor(Level.WARN))
            logger.debug("   unable to solve item occurrence count");

            return 0;
         }

         // Set solved value (fixed or not)
         this.itemCount.setValue(key, tmpValue);
      }
      // Return value
      return (int) tmpValue;
   }

   /**
    * Returns the offset of the block associated to the key (from
    * offsetReference).
    * 
    * @param key The key of the described block.
    * @return The offset or -1 if not solved.
    */
   protected final Length getOffset(final int[] key)
   {
      /*
       * DEBUG if (logger.isDebugEnabled()) { logger.debug( "<" + name +
       * ">.getOffset(" + IntMap.keyToString(key) + ")"); } DEBUG
       */

      if (this.substitutionGroup != null)
      {
         return this.getBase().getOffset(key);
      }

      // Local declarations
      Length tmpValue; // Temporary value

      // Get length value
      tmpValue = this.offset.getLength(key);

      // Solve offset if unknown
      if (tmpValue == null)
      {
         // logger.debug("getOffset : Case of unknown value");
         tmpValue = this.solveOffset(key);
         // Store the value
         this.setOffset(key, tmpValue);
      }

      // Return value
      return tmpValue;
   }

   /**
    * Returns the length of the block associated to the key.
    * 
    * @param key The key of the described block.
    * @return The length or -1 if not solved.
    */
   protected final Length getLength(final int[] key)
   {
      // Local declarations
      Length tmpValue; // Temporary value
      final boolean need_update = false;

      // Get length value
      tmpValue = this.length.getLength(key);

      // Solve length if unknown
      if (tmpValue != null)
      {
         return tmpValue;
      }

      tmpValue = this.contentLength.getLength(key);
      // Solve value
      if (tmpValue == null)
      {
         tmpValue = this.solveLength(key);
         if (tmpValue == null)
         {
            logger.error("<" + this.getPath()
                  + ">.getLength: solved length is null. key="
                  + IntMap.keyToString(key));
            throw new DynamicException("<" + this.getPath()
                  + ">.getLength: solved length is null. key="
                  + IntMap.keyToString(key));
         }
         // if (contentLength.getAccessType() == PhysicalAttribute.READ_ONLY)
         this.contentLength.setLength(key, tmpValue);
      }
      // Add padding and store the solved length (fixed or not)
      tmpValue.setLength(tmpValue.getLength() + this.headerPadding.length
            + this.footerPadding.length, tmpValue.getBitLength());
      // Skip delimiter if any
      if (this.delimiter.length() > 0)
      {
         final Length end_offset = this.getOffset(key);
         end_offset.setLength(end_offset.getLength() + tmpValue.getLength(),
               end_offset.getBitLength() + tmpValue.getBitLength());

         try
         {
            final char delimiter_char = this.delimiter.charAt(0);
            final RandomAccessData cur_file = this.getFile();
            cur_file.seek(end_offset.getLength(), end_offset.getBitLength());
            long skipped = 1;
            while (cur_file.available() > 0)
            {
               final char cur_char = (char) cur_file.readByte();
               if (cur_char == delimiter_char)
               {
                  break;
               }
               skipped++;
            }
            tmpValue.setLength(tmpValue.getLength() + skipped, tmpValue
                  .getBitLength());
         }
         catch (final Exception e)
         {
            return null;
         }
      }

      this.setLength(key, tmpValue);

      // Return value
      return tmpValue;
   }

   /**
    * Returns the item length of the block associated to the key.
    * 
    * @param key The key of the described block.
    * @return The item length or null if not solved.
    */
   protected final Length getItemLength(final int[] key)
   {
      /*
       * DEBUG if (logger.isDebugEnabled()) { logger.debug( "<" + name +
       * ">.getItemLength(" + IntMap.keyToString(key) + ")"); } DEBUG
       */

      final Descriptor instance_desc = this.getInstance(key);
      if (instance_desc != this)
      {
         return instance_desc.getItemLength(key);
      }

      // Check that the value is an array
      if (this.valueType != Value.ARRAY_ID)
      {
         return null;
      }

      // Local declarations
      Length tmpValue; // Temporary value

      // Get length value
      tmpValue = this.itemLength.getLength(key);

      // Solve length if unknown
      if ((tmpValue == null) && this.itemLength.hasQuery())
      {
         // logger.debug("getLength : Case of unknown value");
         // Solve value
         tmpValue = this.itemLength.solveLength(this.createOptimalBlock(key));
         /*
          * DEBUG logger.debug(" solveItemLength=" + tmpValue); DEBUG
          */
         this.itemLength.setLength(key, tmpValue);
      }

      // Return value
      return tmpValue;
   }

   /**
    * Sets the occurrence count value type.
    * 
    * @param type the type
    */
   protected final void setOccurrenceCountType(final int type)
   {
      /*
       * DEBUG logger.debug("<" + name + ">.setOccurrenceCountType(" + type +
       * ")"); DEBUG
       */

      // Sets the value type
      this.occurrenceCount.setAccessType(type);
   }

   /**
    * Returns the occurrence count value type.
    * 
    * @return int the occurence count type
    */
   protected final int getOccurrenceCountType()
   {
      // Return the value type
      return this.occurrenceCount.getAccessType();
   }

   /**
    * Sets the offset value type.
    * 
    * @param type the type
    */
   protected final void setOffsetType(final int type)
   {
      // Sets the value type
      this.offset.setAccessType(type);
   }

   /**
    * Returns the offset value type.
    * 
    * @return int
    */
   protected final int getOffsetType()
   {
      // Return the value type
      return this.offset.getType();
   }

   /**
    * Sets the length value type.
    * 
    * @param type the type
    */
   protected final void setLengthType(final int type)
   {
      // Sets the value type
      this.length.setAccessType(type);
   }

   /**
    * Returns the length value type.
    * 
    * @return int
    */
   protected final int getLengthType()
   {
      // Return the value type
      return this.length.getType();
   }

   /**
    * Returns the length value type.
    * 
    * @return int
    */
   protected final int getContentLengthType()
   {
      // Return the value type
      return this.contentLength.getType();
   }

   /**
    * Sets the item length value type.
    * 
    * @param type the type
    */
   private final void setItemLengthType(final int type)
   {
      // Sets the value type
      this.itemLength.setAccessType(type);
   }

   /**
    * Returns the item length value type.
    * 
    * @return int
    */
   protected final int getItemLengthType()
   {
      // Return the value type
      return this.itemLength.getAccessType();
   }

   /**
    * Sets the occurrenceCount for a specific key. Value must be positive or
    * zero, else value will stay unchanged.
    * 
    * @param key The key of the block.
    * @param value The occurrenceCount value to set for this block.
    */
   protected final void setOccurrenceCount(final int[] key, final long value)
   {
      // Sets the value
      this.occurrenceCount.setValue(key, value);
   }

   /**
    * Sets the offset for a specific key (from offsetReference). Value must be
    * positive or zero, else value will stay unchanged.
    * 
    * @param key The key of the block.
    * @param value The offset value to set for this block.
    */
   protected final void setOffset(final int[] key, final Length value)
   {
      // Sets the value
      this.offset.setLength(key, value);
   }

   /**
    * Sets the length for a specific key. Value must be positive or zero, else
    * value will stay unchanged.
    * 
    * @param key The key of the block.
    * @param value The length value to set for this block.
    */
   protected final void setLength(final int[] key, final Length value)
   {
      // Sets the value
      this.length.setLength(key, value);
   }

   /**
    * Sets the item length for a specific key. Value must be positive or zero,
    * else value will stay unchanged.
    * 
    * @param key The key of the block.
    * @param value The item length value to set for this block.
    */
   protected final void setItemLength(final int[] key, final long value)
   {
      // Sets the value
      this.itemLength.setValue(key, value);
   }

   /**
    * Returns the path of the base node.
    * 
    * @return DrbNode
    */
   protected final DrbNode getBaseNode()
   {
      return this.baseNode;
   }

   /**
    * Returns the path of the file node.
    * 
    * @return DrbNode
    */
   protected final DrbNode getFileNode()
   {
      this.getFile();
      return this.fileNode;
   }

   /**
    * Returns the path of the base node.
    * 
    * @return DrbNode
    */
   protected final RandomAccessData getFile()
   {
      if (this.file != null)
      {
         return this.file;
      }

      if (this.fileNodePath == null)
      {
         if (this.getParent() != null)
         {
            return this.getParent().getFile();
         }
         this.fileNode = this.baseNode;
      }
      else
      {
         this.fileNode = null;
         try
         {
            final Query query_obj = new Query(this.fileNodePath);
            // Eval the query
            final DrbSequence item_list =
               query_obj.evaluate(this.getBaseNode());

            if ((item_list == null) || (item_list.getLength() <= 0))
            {
               logger.error("fr.gael.drb.impl.sdf.Descriptor.getFile() : "
                     + "Empty result list. (query='" + this.fileNodePath + "'"
                     + " baseNode='" + this.baseNode.getPath() + "'");
               return null;
            }
            this.fileNode = (DrbNode) item_list.getItem(0);
         }
         catch (final Exception e)
         {
            logger.error("fr.gael.drb.impl.sdf.Descriptor.getFile() : "
                  + "Cannot parse query (" + e + ")");
            return null;
         }
      }

      if (!(this.fileNode instanceof DrbNodeImpl))
      {
         logger.error("fr.gael.drb.impl.sdf.Descriptor.getFile() : "
               + "cannot retrieve a valid implementation."
               + (this.fileNode == null ? null : "\"" + this.fileNode.getName()
                     + "\""));
         return null;
      }

      final DrbNodeImpl baseImpl = (DrbNodeImpl) this.fileNode;

      // Try to get the RandomAccessFile implementation of the base node
      if (this.file == null)
      {
         final RandomAccessFile file_data =
            (RandomAccessFile) baseImpl.getImpl(RandomAccessFile.class);
         if (file_data != null)
         {
            this.file = new RandomAccessFileData(file_data);
         }
      }
      if (this.file == null)
      {
         if (baseImpl.hasImpl(InputStream.class))
         {
            this.file = new RandomAccessStreamData(baseImpl);
         }
      }
      if (this.file == null)
      {
         logger.error("fr.gael.drb.impl.sdf.Descriptor.getFile() : "
               + "Unable to get RandomAccessFile implementation from node \""
               + this.getBaseNodePath() + "\"");
         return null;
      }

      return this.file;
   }

   /**
    * Returns the base URI or null.
    * 
    * @return String
    */
   protected final String getBaseURI()
   {
	   String path = baseNode.getPath();
	   File baseFile = new File(path);
	   //Case of well-formed URI
	   try
	   {
		   if (baseFile.exists())
		   {
			   return baseFile.toURI().toString();
		   }
		   URI base_uri = new URI(path);
		   return base_uri.toString();
	   }
	   //Case of malformed URI
	   catch (URISyntaxException e)
	   {		   		   
		   return null;
	   }
   } //getBaseURI

   /**
    * Returns the path of the base node.
    * 
    * @return String
    */
   protected final String getBaseNodePath()
   {
      return this.baseNode.getPath();
   }

   /**
    * Returns the path of the file node.
    * 
    * @return String
    */
   protected final String getFileNodePath()
   {
      return this.fileNodePath;
   }

   /**
    * Returns the path of the schema node.
    * 
    * @return String
    */
   protected final String getSchemaNodePath()
   {
      return this.schemaNodePath;
   }

   /**
    * Returns a reference to the root descriptor.
    * 
    * @return Descriptor
    */
   protected final Descriptor getRoot()
   {
      if (this.substitutionGroup == null)
      {
         return this.root;
      }
      else
      {
         return this.substitutionGroup.getRoot();
      }
   }

   /**
    * Sets the current descriptor as root descriptor. This operation must be
    * called when all descriptor tree is built-up. This implementation is a
    * wrapper to the setRoot() operation. If baseNode is null do nothing.
    * 
    * @param base_node The base node to keep a reference from.
    * @param schema_node_path The path of the schema node.
    * @param create_mode Says whether this file must be created.
    */
   protected final void setAsRoot(final DrbNode base_node,
         final String schema_node_path)
   {
      // Test parameter
      if (base_node == null)
      {
         logger.error("fr.gael.drb.impl.sdf.Descriptor.setAsRoot() : "
               + "base_node is null.");
         throw new StaticException(
               "fr.gael.drb.impl.sdf.Descriptor.setAsRoot() : "
                     + "base_node is null.");
      }

      // Wrap to setRoot operation with single ancestors property set to true
      this.offset.setUnit(LengthAttribute.UNIT_BYTE);
      this.offset.setAccessType(PhysicalAttribute.READ_ONLY);
      this.offset.setOccurrenceType(PhysicalAttribute.SINGLE);
      this.offset.setValue(0);

      this.index = 0;

      this.setRoot(this, base_node, schema_node_path, true, 0);
   }

   /**
    * Get the default encoding for a simple type.
    * 
    * @param type the value type identifier.
    * @param arrayType the array type identifier
    * @return the default encoding of the given type.
    */
   private static int getDefaultEncoding(final int type, final int arrayType)
   {
      if ((type == Value.STRING_ID) || (arrayType == Value.STRING_ID))
      {
         return Descriptor.ENCODING_TEXT;
      }
      else
      {
         return Descriptor.ENCODING_BINARY;
      }
   }

   /**
    * Get the default length for an atomic type. This length depends on the
    * encoding.
    * 
    * @param type the type indentifier.
    * @return the default of the type or -1 if unknown.
    */
   private int getDefaultLength(final int type)
   {
      if (this.encoding == ENCODING_TEXT)
      {
         switch (type)
         {
            case Value.DATE_ID:
               return 27;
         }
      }
      else
      // BINARY
      {
         switch (type)
         {
            case Value.INT_ID:
            case Value.UNSIGNED_INT_ID:
               return 4;

            case Value.DOUBLE_ID:
               return 8;

            case Value.FLOAT_ID:
               return 4;

            case Value.LONG_ID:
            case Value.UNSIGNED_LONG_ID:
               return 8;

            case Value.SHORT_ID:
            case Value.UNSIGNED_SHORT_ID:
               return 2;

            case Value.BYTE_ID:
            case Value.UNSIGNED_BYTE_ID:
               return 1;

            case Value.BOOLEAN_ID:
               return 1;

            case Value.DATE_ID:
               return 12;
         }
      }
      return -1;
   }

   /**
    * Sets references to the root descriptor and base node. All children
    * desciptors will have the root and the given base node references set up.
    * The singleAncestors property is also set with the given parameter and the
    * operation is called for the children using the current
    * isSingleOccurrence() result. If offset type is unknown, it is set to fixed
    * or variable according to the isSingleOccurrence() result.
    * 
    * @param root The root descriptor to keep the reference.
    * @param base_node The base node to keep the reference.
    * @param schema_node_path The path of the schema node.
    * @param single_ancestors True if descriptor has single ancestors.
    * @param depth Depth in the descriptors tree used for key generation
    */
   private final void setRoot(final Descriptor root, final DrbNode base_node,
         final String schema_node_path, final boolean single_ancestors,
         final int depth)
   {
      // Set root reference
      this.root = root;

      // Set base node reference
      this.baseNode = base_node;

      // Set schema node path reference
      this.schemaNodePath = schema_node_path;

      // Set the singleAncestors property
      this.singleAncestors = single_ancestors;

      // Set the depth property
      this.depth = depth;

      // Set the encoding property
      if (this.encoding == ENCODING_UNKNOWN)
      {
         if (this.substitutionGroup != null)
         {
            this.encoding = this.substitutionGroup.getEncoding();
            this.charsetName = this.substitutionGroup.charsetName;
         }
         else if (this.getParent() != null)
         {
            this.encoding = this.getParent().getEncoding();
            this.charsetName = this.getParent().charsetName;
         }
      }

      if (this.encoding == ENCODING_UNKNOWN)
      {
         this.encoding = getDefaultEncoding(this.valueType,
               this.arrayValueType);
      }
      
      //Set text encoding for string values
      if ((this.valueType == Value.STRING_ID) ||
          (this.arrayValueType == Value.STRING_ID))
      {
         this.encoding = ENCODING_TEXT;
      }

      //Set the default charset
      if ((this.encoding == ENCODING_TEXT) &&
          (this.charsetName == null))
      {
         this.charsetName = CHARSET_ASCII;
      }

      // Create default key (first occurrence) for the current depth
      int[] key = new int[] {};
      for (int i = 0; i < depth; i++)
      {
         key = IntMap.getChildKey(key, 0);
      }

      // Get single occurrence result
      // boolean singleOccurrence = this.isSingleOccurrence(key);
      boolean singleOccurrence =
         this.singleAncestors
               && (this.getOccurrenceCountType() == PhysicalAttribute.READ_ONLY)
               && (this.occurrenceCount.getValue() == 1);

      // Case of single occurrence.
      // All attributes shall be SINGLE
      if (singleOccurrence)
      {
         this.blockOffset.setOccurrenceType(PhysicalAttribute.SINGLE);
         this.offset.setOccurrenceType(PhysicalAttribute.SINGLE);
         this.contentLength.setOccurrenceType(PhysicalAttribute.SINGLE);
         this.length.setOccurrenceType(PhysicalAttribute.SINGLE);
         this.itemLength.setOccurrenceType(PhysicalAttribute.SINGLE);
         this.itemCount.setOccurrenceType(PhysicalAttribute.SINGLE);
         this.childrenCount.setOccurrenceType(PhysicalAttribute.SINGLE);
         this.substitutionMap.setOccurrenceType(PhysicalAttribute.SINGLE);
      }
      // Case of single ancestor.
      // Occurrence attribute shall be SINGLE
      if (this.singleAncestors)
      {
         this.occurrenceCount.setOccurrenceType(PhysicalAttribute.SINGLE);
      }

      short length_unit = LengthAttribute.UNIT_BYTE;
      short offset_unit = LengthAttribute.UNIT_UNKNOWN;

      // Loop on substitution descriptors
      for (int i = 0; i < this.substitution.size(); i++)
      {
         this.getSubstitution(i).index = this.index;
         // Recursive call on substitution descriptors
         this.getSubstitution(i).setRoot(root, base_node, schema_node_path,
               singleOccurrence, depth);
         if (this.getSubstitution(i).length.getUnit() == LengthAttribute.UNIT_BIT)
         {
            length_unit = LengthAttribute.UNIT_BIT;
            if (!singleOccurrence)
            {
               offset_unit = LengthAttribute.UNIT_BIT;
            }
         }
      }

      // Loop on children descriptors
      // TBC
      boolean fixed_children_count = true;
      boolean fixed_content_length = true;
      boolean fixed_previous_offset = true;
      boolean constant_previous_offset = false;

      // If length query is not constant set as variable
      if (this.substitution.size() > 0)
      {
         fixed_content_length = false;
         fixed_children_count = false;
      }

      if (this.getParent() != null)
      {
         fixed_previous_offset =
            singleOccurrence
                  && (this.getParent().getOffsetType() == PhysicalAttribute.FIXED)
                  && (this.getParent().getLengthType() == PhysicalAttribute.FIXED)
                  && (this.getParent().getOccurrenceCountType() == PhysicalAttribute.FIXED);
         constant_previous_offset =
            singleOccurrence
                  && (this.getParent().getOffsetType() <= PhysicalAttribute.CONSTANT)
                  && (this.getParent().getLengthType() <= PhysicalAttribute.CONSTANT)
                  && (this.getParent().getOccurrenceCountType() <= PhysicalAttribute.CONSTANT);
      }

      // Check the children
      for (int i = 0; i < this.children.size(); i++)
      {
         final Descriptor current_child = (Descriptor) this.children.get(i);
         // Set parent, previous and next
         current_child.setParent(this);
         current_child.index = i;
         if (i > 0)
         {
            current_child.setPreviousSibling(this.getChildAt(i - 1));
         }
         if (i + 1 < this.children.size())
         {
            current_child.setNextSibling(this.getChildAt(i + 1));
         }
         // Recursive call on children descriptors
         current_child.setRoot(root, base_node, schema_node_path,
               singleOccurrence, depth + 1);

         if ((current_child.getOffsetType() == PhysicalAttribute.READ_WRITE)
               && !current_child.blockOffset.hasQuery())
         {
            if (fixed_previous_offset
                  && (current_child.length.getType() == PhysicalAttribute.FIXED))
            {
               current_child.setOffsetType(PhysicalAttribute.READ_ONLY);
            }
         }
         if (constant_previous_offset
               && (current_child.occurrenceCount.getValue() == 1))
         {
            // TBC : change the canonical depth
            // If the offset is attached to the previous block,
            // then it is constant in the parent
            if ((this.blockOffset.getOrigin() == OffsetAttribute.ORIGIN_PREVIOUS)
                  && (this.blockOffset.getType() == OffsetAttribute.READ_ONLY)
                  && (this.blockOffset.getValue() == 0))
            {
               this.blockOffset.setAccessType(current_child.getOffsetType());
               this.blockOffset.setUnit(current_child.offset.getUnit());
               this.blockOffset.setOccurrenceType(PhysicalAttribute.SINGLE);
               this.blockOffset.setOrigin(OffsetAttribute.ORIGIN_PARENT);
               this.blockOffset.setValue(-1);
            }
         }
         if (current_child.length.getUnit() == LengthAttribute.UNIT_BIT)
         {
            length_unit = LengthAttribute.UNIT_BIT;
         }
         // logger.debug(current_child);
         fixed_previous_offset =
            fixed_previous_offset
                  && (current_child.length.getType() == PhysicalAttribute.FIXED)
                  && (current_child.occurrenceCount.getType() == PhysicalAttribute.FIXED);
         constant_previous_offset =
            constant_previous_offset
                  && (current_child.length.getType() <= PhysicalAttribute.CONSTANT)
                  && (current_child.occurrenceCount.getType() <= PhysicalAttribute.CONSTANT);
         fixed_content_length =
            fixed_content_length
                  && (current_child.length.getType() == PhysicalAttribute.FIXED)
                  && (current_child.occurrenceCount.getType() == PhysicalAttribute.FIXED);
         fixed_children_count =
            fixed_children_count
                  && (current_child.occurrenceCount.getType() == PhysicalAttribute.FIXED);
      }

      // Set children count attribute type if unknown
      if (fixed_children_count)
      {
         this.childrenCount.setAccessType(PhysicalAttribute.READ_ONLY);
         this.childrenCount.setOccurrenceType(PhysicalAttribute.SINGLE);
      }

      // Set content length attribute type if unknown
      if (this.valueType != Value.NULL_ID)
      {
         final long atomic_length = -1;
         final short atomic_unit = LengthAttribute.UNIT_BYTE;
         // Case of simpleType element
         if (this.valueType == Value.ARRAY_ID)
         {
            // If the encoding is BINARY, the item length must be either
            // fixed or defined by a query.
            if ((this.encoding == ENCODING_BINARY)
                  && !this.itemLength.hasQuery())
            {
               this.itemLength.setAccessType(PhysicalAttribute.READ_ONLY);
               this.itemLength.setOccurrenceType(PhysicalAttribute.SINGLE);
               if (this.itemLength.getValue() < 0)
               {
                  this.itemLength.setUnit(LengthAttribute.UNIT_BYTE);
                  this.itemLength.setValue((long) this
                        .getDefaultLength(this.arrayValueType));
               }
            }

            if ((this.itemLength.getAccessType() == PhysicalAttribute.READ_ONLY)
                  && (this.itemCount.getAccessType() == PhysicalAttribute.READ_ONLY))
            {
               this.contentLength.setAccessType(PhysicalAttribute.READ_ONLY);
            }
            if ((this.itemLength.getOccurrenceType() == PhysicalAttribute.SINGLE)
                  && (this.itemCount.getOccurrenceType() == PhysicalAttribute.SINGLE))
            {
               this.contentLength.setOccurrenceType(PhysicalAttribute.SINGLE);
            }
         }
         else
         // If the encoding is BINARY, the content length must be either
         // fixed or defined by a query.
         if ((this.encoding == ENCODING_BINARY)
               && !this.contentLength.hasQuery())
         {
            this.contentLength.setAccessType(PhysicalAttribute.READ_ONLY);
            this.contentLength.setOccurrenceType(PhysicalAttribute.SINGLE);
            if (this.contentLength.getValue() < 0)
            {
               this.contentLength.setUnit(LengthAttribute.UNIT_BYTE);
               this.contentLength.setValue((long) this
                     .getDefaultLength(this.valueType));
            }
         }
      }
      else
      // Case of complexType element
      if (fixed_content_length)
      {
         this.contentLength.setAccessType(PhysicalAttribute.READ_ONLY);
         this.contentLength.setOccurrenceType(PhysicalAttribute.SINGLE);
      }
      if ((this.contentLength.getType() == PhysicalAttribute.FIXED)
            && (this.encoding == ENCODING_BINARY)
            && (this.valueType != Value.NULL_ID))
      {
         Length value_length = null;
         int atomic_type = 0;
         if (this.valueType == Value.ARRAY_ID)
         {
            atomic_type = this.arrayValueType;
            value_length = this.itemLength.getLength(null);
         }
         else
         {
            atomic_type = this.valueType;
            value_length = this.contentLength.getLength(null);
         }

         // If the datatype is numeric choose the best value type
         // according to the length (1=byte 2=short 4=int 8=long)
         switch (atomic_type)
         {
            case Value.BYTE_ID:
            case Value.SHORT_ID:
            case Value.INT_ID:
            case Value.LONG_ID:
               if (value_length.getLength() * 8 + value_length.getBitLength() <= 8)
               {
                  atomic_type = Value.BYTE_ID;
               }
               else if (value_length.getLength() * 8
                     + value_length.getBitLength() <= 16)
               {
                  atomic_type = Value.SHORT_ID;
               }
               else if (value_length.getLength() * 8
                     + value_length.getBitLength() <= 32)
               {
                  atomic_type = Value.INT_ID;
               }
               else if (value_length.getLength() * 8
                     + value_length.getBitLength() <= 64)
               {
                  atomic_type = Value.LONG_ID;
               }
               break;

            case Value.UNSIGNED_BYTE_ID:
            case Value.UNSIGNED_SHORT_ID:
            case Value.UNSIGNED_INT_ID:
            case Value.UNSIGNED_LONG_ID:
               if (value_length.getLength() * 8 + value_length.getBitLength() <= 8)
               {
                  atomic_type = Value.UNSIGNED_BYTE_ID;
               }
               else if (value_length.getLength() * 8
                     + value_length.getBitLength() <= 16)
               {
                  atomic_type = Value.UNSIGNED_SHORT_ID;
               }
               else if (value_length.getLength() * 8
                     + value_length.getBitLength() <= 32)
               {
                  atomic_type = Value.UNSIGNED_INT_ID;
               }
               else if (value_length.getLength() * 8
                     + value_length.getBitLength() <= 64)
               {
                  atomic_type = Value.UNSIGNED_LONG_ID;
               }
               break;
         }
         if ((this.valueType == Value.ARRAY_ID)
               && (atomic_type != this.arrayValueType))
         {
            logger.warn(this.getPath() + " item type changed to "
                  + new fr.gael.drb.xsd.XsdAtomicType(atomic_type).getName()
                  + ". length=" + value_length);
            this.arrayValueType = atomic_type;
         }
         else if ((this.valueType != Value.ARRAY_ID)
               && (atomic_type != this.valueType))
         {
            logger.warn(this.getPath() + " value type changed to "
                  + new fr.gael.drb.xsd.XsdAtomicType(atomic_type).getName());
            this.valueType = atomic_type;
         }
      }

      // Compute the length of this block
      this.length.setUnit(this.contentLength.getUnit());

      // Set content length attribute type if unknown
      if (this.delimiter.length() == 0)
      {
         this.length.setAccessType(this.contentLength.getAccessType());
      }
      if (this.delimiter.length() == 0)
      {
         this.length.setOccurrenceType(this.contentLength.getOccurrenceType());
      }
   }

   /**
    * Returns a reference to the parent descriptor.
    * 
    * @return Descriptor the parent descriptor
    */
   protected final Descriptor getParent()
   {
      if (this.substitutionGroup == null)
      {
         return this.parent;
      }
      else
      {
         return this.substitutionGroup.getParent();
      }
   }

   /**
    * Sets a reference to the parent descriptor. Parent can be null.
    * 
    * @param parent the descriptor parent
    */
   private final void setParent(final Descriptor parent)
   {
      /**
       * DEBUG if (logger.isDebugEnabled()) { logger.debug( "<" + name +
       * ">.setParent(" + ((parent == null) ? null : parent.name) + ")"); }
       * DEBUG
       */
      // Set reference
      this.parent = parent;
      final Iterator substitution_iterator = this.substitution.iterator();
      while (substitution_iterator.hasNext())
      {
         final Descriptor substitution_descriptor =
            (Descriptor) substitution_iterator.next();
         substitution_descriptor.setParent(parent);
      }
   }

   /**
    * Returns a reference to the first child descriptor.
    * 
    * @return Decriptor the first child descriptor
    */
   protected final Descriptor getFirstChild()
   {
      return this.getChildAt(0);
   }

   /**
    * Returns a reference to the last child descriptor.
    * 
    * @return Decriptor the last child descriptor
    */
   protected final Descriptor getLastChild()
   {
      return this.getChildAt(this.children.size() - 1);
   }

   /**
    * Returns a reference to the "index"th child descriptor.
    * 
    * @param index the "index"th child
    * @return Descriptor the "index"th child descriptor
    */
   protected final Descriptor getChildAt(final int index)
   {
      // Check parameters
      if (index < 0)
      {
         logger.error("fr.gael.drb.impl.sdf.Descriptor.getChildAt() : "
               + "Invalid parameter.");
         logger.error("   index = " + index);
         return null;
      }

      // Check children list
      if ((this.children.size() == 0) || (index >= this.children.size()))
      {
         return null;
      }

      // Returns the child descriptor
      return (Descriptor) this.children.get(index);
   }

   /**
    * Returns a reference to the previous sibling descriptor.
    * 
    * @return Descriptor
    */
   protected final Descriptor getPreviousSibling()
   {
      if (this.substitutionGroup == null)
      {
         return this.previousSibling;
      }
      else
      {
         return this.substitutionGroup.getPreviousSibling();
      }
   }

   /**
    * Sets a reference to the previous sibling descriptor.
    * 
    * @param previous_sibling the previous sibling
    */
   private final void setPreviousSibling(final Descriptor previous_sibling)
   {
      this.previousSibling = previous_sibling;
   }

   /**
    * Returns a reference to the next sibling descriptor.
    * 
    * @return Descriptor
    */
   protected final Descriptor getNextSibling()
   {
      if (this.substitutionGroup == null)
      {
         return this.nextSibling;
      }
      else
      {
         return this.substitutionGroup.getNextSibling();
      }
   }

   /**
    * Sets a reference to the next sibling descriptor.
    * 
    * @param next_sibling the descriptor of the next sibling
    */
   private final void setNextSibling(final Descriptor next_sibling)
   {
      this.nextSibling = next_sibling;
   }

   /**
    * Add a child descriptor reference to the children list.
    * 
    * @param new_child the new child to add
    */
   protected final void addChild(final Descriptor new_child)
   {
      // Test parameters
      if (new_child == null)
      {
         logger.warn("fr.gael.drb.impl.sdf.Descriptor.addChild() : "
               + "Invalid parameter.");
         logger.warn("   new_child is null => children list unchanged.");
         return;
      }

      // Add child to children list
      this.children.add(new_child);
   }

   /**
    * Add a susbtitution descriptor reference to the susbtitution list.
    * 
    * @param new_substitution the new substitution to add
    */
   protected final void addSubstitution(final Descriptor new_substitution)
   {
      // Test parameters
      if (new_substitution == null)
      {
         logger.warn("fr.gael.drb.impl.sdf.Descriptor.addSubstitution() : "
               + "Invalid parameter.");
         logger.warn("   new_substitution is null => list unchanged.");
         return;
      }
      // Add substitution to list
      new_substitution.substitutionGroup = this;
      this.substitution.add(new_substitution);
   }

   /**
    * Prints descriptor info into a string.
    * 
    * @return String
    */
   public String toString()
   {
      // Local declarations
      String info = "fr.gael.drb.impl.sdf.Descriptor {\n";
      String tmpStr;

      // Create info string
      info = info + "   Path            : " + this.getPath() + "\n";
      info = info + "   Name            : " + this.name + "\n";
      info = info + "   FullName        : " + this.fullName + "\n";

      // Encoding type
      switch (this.encoding)
      {
         case ENCODING_BINARY:
            tmpStr = "BINARY";
            break;
         case ENCODING_TEXT:
            tmpStr = this.charsetName;
            break;
         default:
            tmpStr = "" + this.encoding;
            break;
      }
      info = info + "   Encoding        : " + tmpStr + "\n";

      // Occurrence count, offset and length
      info = info + "   SingleAncestor: " + this.singleAncestors + "\n";
      info = info + "   OccurrenceCount : " + this.occurrenceCount + "\n";
      info = info + "   Bl. Offset (bytes) : " + this.blockOffset + "\n";
      info = info + "   Offset (bytes)  : " + this.offset + "\n";
      info = info + "   Length (bytes)  : " + this.length + "\n";
      info = info + "   Content (bytes)  : " + this.contentLength + "\n";
      info = info + "   itemCount : " + this.itemCount + "\n";
      info = info + "   itemLength : " + this.itemLength + "\n";
      if (this.substitution.size() > 0)
      {
         info = info + "   substitutionMap : " + this.substitutionMap + "\n";
      }
      // TODO: bits
      // info = info + " bitLength : " + bitLength + "\n";
      // info = info + " Prev.Sibl.Offset: " + offsetFromPreviousSibling + "\n";
      info =
         info + "   Header padding  : " + this.headerPadding.length + " ["
               + this.headerPadding.content + "]\n";
      info =
         info + "   Footer padding  : " + this.footerPadding.length + " ["
               + this.footerPadding.content + "]\n";

      // Value type
      switch (this.valueType)
      {
         case Value.UNKNOWN_ID:
            tmpStr = "UNKNOWN_ID";
            break;
         case Value.NULL_ID:
            tmpStr = "NULL_ID";
            break;
         case Value.BOOLEAN_ID:
            tmpStr = "BOOLEAN_ID";
            break;
         case Value.BYTE_ID:
            tmpStr = "BYTE_ID";
            break;
         case Value.UNSIGNED_BYTE_ID:
            tmpStr = "UNSIGNED_BYTE_ID";
            break;
         case Value.SHORT_ID:
            tmpStr = "SHORT_ID";
            break;
         case Value.UNSIGNED_SHORT_ID:
            tmpStr = "UNSIGNED_SHORT_ID";
            break;
         case Value.INT_ID:
            tmpStr = "INT_ID";
            break;
         case Value.UNSIGNED_INT_ID:
            tmpStr = "UNSIGNED_INT_ID";
            break;
         case Value.LONG_ID:
            tmpStr = "LONG_ID";
            break;
         case Value.UNSIGNED_LONG_ID:
            tmpStr = "UNSIGNED_LONG_ID";
            break;
         case Value.FLOAT_ID:
            tmpStr = "FLOAT_ID";
            break;
         case Value.DOUBLE_ID:
            tmpStr = "DOUBLE_ID";
            break;
         case Value.STRING_ID:
            tmpStr = "STRING_ID";
            break;
         case Value.DATE_ID:
            tmpStr = "DATE_ID";
            break;
         case Value.NUMERIC_ID:
            tmpStr = "NUMERIC_ID";
            break;
         case Value.ARRAY_ID:
            tmpStr = "ARRAY_ID (inside type = " + this.arrayValueType + ")";
            break;
         case Value.OTHER_ID:
            tmpStr = "OTHER_ID";
            break;
         default:
            tmpStr = "" + this.valueType;
            break;
      }
      info = info + "   Value type      : " + tmpStr + "\n";

      // References to parent, root, etc.
      info =
         info + "   Root Name       : "
               + ((this.root == null) ? null : this.root.name) + "\n";
      info =
         info + "   Parent Name     : "
               + ((this.parent == null) ? null : this.parent.name) + "\n";
      info =
         info
               + "   Previous Name   : "
               + ((this.previousSibling == null) ? null
                     : this.previousSibling.name) + "\n";
      info =
         info + "   Next Name       : "
               + ((this.nextSibling == null) ? null : this.nextSibling.name)
               + "\n";
      info = info + "   Children        : { ";
      for (int i = 0; i < this.children.size(); i++)
      {
         info = info + "\"" + ((Descriptor) this.children.get(i)).name + "\" ";
      }
      info = info + "}\n";
      info = info + "   Substitution    : { ";
      for (int i = 0; i < this.substitution.size(); i++)
      {
         info =
            info + "\"" + ((Descriptor) this.substitution.get(i)).name + "\" ";
      }
      info = info + "}\n";
      info = info + "}\n";

      // Return info string
      return info;
   }

   /**
    * Prints descriptor info into a string.
    * 
    * @return String
    */
   public String toXMLString()
   {
      // Local declarations
      String info =
         "<descriptor xmlns=\"" + AbstractBlock.SDF_NAMESPACE + "\"" + " id=\""
               + this.hashCode() + "\"";
      String tmpStr;

      // Create info string
      info = info + " name=\"" + this.name + "\"\n";
      info = info + " fullName=\"" + this.fullName + "\"\n";

      // Encoding type
      switch (this.encoding)
      {
         case ENCODING_BINARY:
            tmpStr = "BINARY";
            break;
         case ENCODING_TEXT:
            tmpStr = this.charsetName;
            break;
         default:
            tmpStr = "" + this.encoding;
            break;
      }
      info = info + " <encoding>" + tmpStr + "</encoding>\n";

      // Occurrence count, offset and length
      info =
         info + " <singleAncestor>" + this.singleAncestors
               + "</singleAncestor>\n";
      info = info + "   OccurrenceCount : " + this.occurrenceCount + "\n";
      info = info + "   Bl. Offset (bytes) : " + this.blockOffset + "\n";
      info = info + "   Offset (bytes)  : " + this.offset + "\n";
      info = info + "   Length (bytes)  : " + this.length + "\n";
      info = info + "   Content (bytes)  : " + this.contentLength + "\n";
      info = info + "   itemCount : " + this.itemCount + "\n";
      info = info + "   itemLength : " + this.itemLength + "\n";
      // TODO: bits
      // info = info + " bitLength : " + bitLength + "\n";
      // info = info + " Prev.Sibl.Offset: " + offsetFromPreviousSibling + "\n";
      info =
         info + "   Header padding  : " + this.headerPadding.length + " ["
               + this.headerPadding.content + "]\n";
      info =
         info + "   Footer padding  : " + this.footerPadding.length + " ["
               + this.footerPadding.content + "]\n";

      // Value type
      switch (this.valueType)
      {
         case Value.UNKNOWN_ID:
            tmpStr = "UNKNOWN_ID";
            break;
         case Value.NULL_ID:
            tmpStr = "NULL_ID";
            break;
         case Value.BOOLEAN_ID:
            tmpStr = "BOOLEAN_ID";
            break;
         case Value.BYTE_ID:
            tmpStr = "BYTE_ID";
            break;
         case Value.UNSIGNED_BYTE_ID:
            tmpStr = "BYTE_ID";
            break;
         case Value.SHORT_ID:
            tmpStr = "SHORT_ID";
            break;
         case Value.UNSIGNED_SHORT_ID:
            tmpStr = "SHORT_ID";
            break;
         case Value.INT_ID:
            tmpStr = "INT_ID";
            break;
         case Value.UNSIGNED_INT_ID:
            tmpStr = "INT_ID";
            break;
         case Value.LONG_ID:
            tmpStr = "LONG_ID";
            break;
         case Value.UNSIGNED_LONG_ID:
            tmpStr = "LONG_ID";
            break;
         case Value.FLOAT_ID:
            tmpStr = "FLOAT_ID";
            break;
         case Value.DOUBLE_ID:
            tmpStr = "DOUBLE_ID";
            break;
         case Value.STRING_ID:
            tmpStr = "STRING_ID";
            break;
         case Value.DATE_ID:
            tmpStr = "DATE_ID";
            break;
         case Value.NUMERIC_ID:
            tmpStr = "NUMERIC_ID";
            break;
         case Value.ARRAY_ID:
            tmpStr = "ARRAY_ID (inside type = " + this.arrayValueType + ")";
            break;
         case Value.OTHER_ID:
            tmpStr = "OTHER_ID";
            break;
         default:
            tmpStr = "" + this.valueType;
            break;
      }
      info = info + "   Value type      : " + tmpStr + "\n";

      // References to parent, root, etc.
      info =
         info + "   Root Name       : "
               + ((this.root == null) ? null : this.root.name) + "\n";
      info =
         info + "   Parent Name     : "
               + ((this.parent == null) ? null : this.parent.name) + "\n";
      info =
         info
               + "   Previous Name   : "
               + ((this.previousSibling == null) ? null
                     : this.previousSibling.name) + "\n";
      info =
         info + "   Next Name       : "
               + ((this.nextSibling == null) ? null : this.nextSibling.name)
               + "\n";
      info = info + "   Children        : { ";
      for (int i = 0; i < this.children.size(); i++)
      {
         info = info + "\"" + ((Descriptor) this.children.get(i)).name + "\" ";
      }
      info = info + "}\n";
      info = info + "}\n";

      // Return info string
      return info;
   }

   /**
    * Constraints a string to a specified length. If the input string is too
    * long it will be truncated as follow:<br>
    * getFixedString("Good Morning", 6, ' ') : "Good M"<br>
    * If the input string is too short it will be completed by the fill
    * character as follow:<br>
    * getFixedString("Good Morning", 16, '* ') : "Good Morning****".
    * 
    * @param in_str The input string.
    * @param length The output length (must be positive).
    * @param fill_char The char used to fill the string if needed.
    * @return The resulting string with the specified length or itself if
    *         lengths are equals or "" (empty String) in case of error.
    */
   public static final String getFixedString(String in_str, final int length,
         final char fill_char)
   {
      // Output length is 0, return empty string
      if (length == 0)
      {
         return "";
      }

      // Null input string, change to empty string
      if (in_str == null)
      {
         in_str = "";
      }

      // Lengths are equal, return the string itself
      final int inStrLength = in_str.length();
      if ((inStrLength == length) || (length < 0))
      {
         return in_str;
      }

      // Input string is too long, return a substring with good length
      if (inStrLength > length)
      {
         return in_str.substring(0, length);
      }

      // At this step the string is too short, append input string with the
      // needed number of fill characters and return it.
      for (int i = 0; i < (length - inStrLength); i++)
      {
         in_str = in_str + fill_char;
      }
      return in_str;
   }

   /**
    * Main operation used for unitary tests.
    * 
    * @param args String[]
    */
   public static void main(final String[] args) throws Exception
   {
      if ((args.length == 0) || (args[0].equals("--help"))
            || (args[0].equals("-help")))
      {
         System.out.println("Usage: Descriptor [options] file");
         System.out.println("Options are:");
         System.out.println("-schema <schema_file> Set the output XML-Schema.");
         System.out
               .println("-append <xpath> <node> Append a node the specified path.");
         System.out
               .println("-replace <xpath> <node> Replace the node at the specified path.");
         System.out
               .println("-insert <xpath> <node> Insert a node at the specified path.");
         System.out
               .println("-remove <xpath> <node> Remove the node at the specified path.");
         System.out
               .println("-value <xpath> <value> Set the value at the specified path.");
         System.out.println("-xml <output_file> Set the output XML file.");
         System.out.println("-out <output_file> Set the output SDF file.");
      }

      DrbNode product_1 = null;

      // Serialization
      java.io.OutputStream xml_output = null;
      java.io.RandomAccessFile sdf_output = null;

      String xpath = null;
      DrbNode append_node = null;
      DrbNode replace_node = null;
      DrbNode insert_node = null;
      Value value_item = null;
      DrbNode schema_node = null;
      final DrbNode context_node = DrbFactory.open(".");

      for (int i = 0; i < args.length; i++)
      {
         if (args[i].length() == 0)
         {
            continue;
         }
         if (args[i].equals("-schema"))
         {
            schema_node =
               (DrbNode) new Query(args[++i]).evaluate(context_node).getItem(0);
         }
         else if (args[i].equals("-value"))
         {
            xpath = args[++i];
            final fr.gael.drb.DrbSequence values =
               new Query(args[++i]).evaluate(context_node);
            if (values.getLength() > 1)
            {
               value_item = values.atomize();
            }
            else
            {
               value_item = values.getItem(0).getValue();
            }
         }
         else if (args[i].equals("-append"))
         {
            xpath = args[++i];
            append_node =
               (DrbNode) new Query(args[++i]).evaluate(context_node).getItem(0);
         }
         else if (args[i].equals("-replace"))
         {
            xpath = args[++i];
            replace_node =
               (DrbNode) new Query(args[++i]).evaluate(context_node).getItem(0);
         }
         else if (args[i].equals("-insert"))
         {
            xpath = args[++i];
            insert_node =
               (DrbNode) new Query(args[++i]).evaluate(context_node).getItem(0);
         }
         else if (args[i].equals("-remove"))
         {
            xpath = args[++i];
         }
         else if (args[i].equals("-xml"))
         {
            xml_output = new java.io.FileOutputStream(args[++i]);
         }
         else if (args[i].equals("-out"))
         {
            sdf_output = new java.io.RandomAccessFile(args[++i], "rw");
         }
         else
         {
            product_1 = DrbFactory.open(args[i]);
         }
      }

      if (product_1 == null)
      {
         System.err.println("ERROR: No document specified!");
         return;
      }

      fr.gael.drb.xsd.XmlSchema schema = null;
      if (schema_node != null)
      {
         if (schema_node.getName().equals("schema"))
         {
            schema = new fr.gael.drb.xsd.XsdFactory().open(schema_node);
         }
         else
         {
            schema =
               new fr.gael.drb.xsd.XsdFactory().open(schema_node.getParent(),
                     schema_node.getNamedChild("schema", 1));
         }
      }

      if (value_item != null)
      {
         System.err.println("##########Setting value...");
         final DrbNode base =
            (DrbNode) new Query(xpath).evaluate(product_1).getItem(0);
         base.setValue(value_item.getValue());
      }
      else if (append_node != null)
      {
         System.err.println("##########Appending data...");
         final DrbNode base =
            (DrbNode) new Query(xpath).evaluate(product_1).getItem(0);
         base.appendChild(append_node);
      }
      else if (replace_node != null)
      {
         System.err.println("##########Replacing data...");
         final DrbNode base =
            (DrbNode) new Query(xpath).evaluate(product_1).getItem(0);
         final int index = base.getIndex();
         base.getParent().replaceChild(index, replace_node);
      }
      else if (insert_node != null)
      {
         System.err.println("##########Inserting data...");
         final DrbNode base =
            (DrbNode) new Query(xpath).evaluate(product_1).getItem(0);
         final int index = base.getIndex();
         base.getParent().insertChild(insert_node, index);
      }
      else if (xpath != null)
      {
         System.err.println("##########Removing data...");
         final DrbNode base =
            (DrbNode) new Query(xpath).evaluate(product_1).getItem(0);
         final int index = base.getIndex();
         base.getParent().removeChild(index);
      }

      if (xml_output != null)
      {
         final fr.gael.drb.impl.xml.XmlWriter.Context writer_context =
            new fr.gael.drb.impl.xml.XmlWriter.Context();
         writer_context.setFilter(fr.gael.drb.impl.xml.XmlWriter.SHOW_ALL
               ^ fr.gael.drb.impl.xml.XmlWriter.SHOW_ATTRIBUTE);
         writer_context.setPreserveSpace(true);
         fr.gael.drb.impl.xml.XmlWriter.writeXML(product_1, xml_output,
               writer_context, false);
      }
      if (sdf_output != null)
      {
         Descriptor descriptor = null;
         if (schema != null)
         {
            final fr.gael.drb.DrbDefaultMutableNode base_node =
               new fr.gael.drb.DrbDefaultMutableNode("sdf");
            base_node.setUserObject(sdf_output);
            final AbstractBlock sdf_product =
               (AbstractBlock) new SdfFactory().open(base_node, schema,
                     schema_node.getPath());
            descriptor = sdf_product.descriptor;
         }
         else
         {
            final AbstractBlock input_block =
               (AbstractBlock) ((DrbNodeImpl) product_1)
                     .getImpl(fr.gael.drb.impl.sds.AbstractBlock.class);
            descriptor = input_block.descriptor;
         }
         descriptor.serializeNode(product_1, new int[] {},
               new RandomAccessFileData(sdf_output), new Length(0));
      }
   }
} // Descriptor
