/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sdf;

import java.io.DataInput;
import java.io.DataOutput;

/**
 * Random Access Data.
 */
abstract class RandomAccessData implements DataInput, DataOutput
{
   /**
    * Closes this random access file stream and releases any system resources
    * associated with the stream.
    * 
    * @throws java.io.IOException This exception is raised, If the buffer's
    *            current position is not smaller than its limit
    */
   abstract void close() throws java.io.IOException;

   /**
    * Returns the number of bytes that can be read (or skipped over) from this
    * input stream without blocking by the next caller of a method for this
    * input stream. The next caller might be the same thread or or another
    * thread. The available method for class InputStream always returns 0. This
    * method should be overridden by subclasses.
    * 
    * @throws java.io.IOException if an I/O error occurs.
    * @return the number of byte that can be read without blocking.
    */
   public long available() throws java.io.IOException
   {
      return 0;
   }

   /**
    * Sets the data-pointer offset, measured from the beginning of this data, at
    * which the next read or write occurs.
    * 
    * @param pos The new position value; must be non-negative and no larger than
    *           the current limit
    * @throws java.io.IOException This exception is raised, If the buffer's
    *            current position is not smaller than its limit
    */
   abstract void seek(long pos) throws java.io.IOException;

   /**
    * Returns the length of this dta.
    * 
    * @return long The buffer capacity
    * @throws java.io.IOException This exception is raised, If the buffer's
    *            current position is not smaller than its limit
    */
   abstract long length() throws java.io.IOException;
} // RandomAccessData
