/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import org.apache.log4j.Logger;

import fr.gael.drb.impl.DrbFactoryResolver;
import fr.gael.drb.impl.URLNode;
import fr.gael.drb.impl.file.FileFactory;
import fr.gael.drb.impl.spi.DrbNodeSpi;
import fr.gael.drb.query.DynamicException;
import fr.gael.drb.query.Query;
import fr.gael.drb.query.StaticException;

/**
 * Node constructor. This class is a factory of nodes. Its static operations
 * enable to create nodes according to a specific implementation of the "Data
 * Request Broker". Basically all DRB root nodes are created from this class. As
 * an example, the open() operation allows to create a root node of an existing
 * document from a simple "Unified Resource Identifier" (URI) which is in most
 * cases a simple file system path. A further implementation of DrbFactory will
 * load dynamically the implementations from external Jar files and will provide
 * additional functionality such as automatic recognition. Note: the URI accepts
 * several contiguous fragment separators (e.g. "###"). Note : this class is not
 * supposed to be instantiated.
 */
public abstract class DrbFactory
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(DrbFactory.class);

   /**
    * DRB configuration management version. The both following attributes
    * controls the version identifier of the overall DRB package. The major
    * version correspond to the effective major version of DRB. The minor
    * version is not considered here but only the minimal minor version expected
    * in the license file. This is a permissive policy allowing to automatically
    * grant the license to a continuous sequence of minor versions as far as it
    * does not correspond to a significant improvement of the software.
    * 
    * @deprecated caller shall now use {@link #getImplementationVersion()}
    */
   public final static String DRB_IDENTIFIER = "drb";

   /**
    * MAJOR_VERSION
    * 
    * @deprecated caller shall now use {@link #getImplementationVersion()}
    */
   public final static int MAJOR_VERSION = 2;

   /**
    * MINIMAL_MINOR_VERSION
    * 
    * @deprecated caller shall now use {@link #getImplementationVersion()}
    */
   public final static int MINIMAL_MINOR_VERSION = 3;

   /**
    * The available factory.
    */
   static private java.util.Hashtable<String, DrbFactoryImpl> factoryHash =
      new java.util.Hashtable<String, DrbFactoryImpl>();

   /**
    * Returns the implementation version identifier.
    * <p>
    * This identification string is extracted from the Manifest of the "drb"
    * artifact Jar archive. The identifier format has the following pattern:
    * </p>
    * <p>
    * <center><b><code>drb-[M]-[m]-[class]-[#]</code></b></center> Where:
    * <i>
    * <ul>
    * <li><b>[M]:</b> stands for the major version number</li>
    * <li><b>[m]:</b> stands for the minor version number</li>
    * <li><b>[class]:</b> is a sub-version classifier among:
    * <ul>
    * <li><b>release:</b> for stable releases</li>
    * <li><b>patch:</b> for updates of stable releases</li>
    * <li><b>rc:</b> for release candidates</li>
    * <li><b>beta:</b> for beta version that </li>
    * </ul>
    * </li>
    * <li><b><code>[#]</code>:</b> incremental number identifying the
    * following version among this class.
    * </ul>
    * </i>
    * </p>
    * <p>
    * Example: <code>drb-1-3-release</code>, <code>drb-2-3-beta-3</code>
    * </p>
    * 
    * @return the identification version from the Jar archive.
    */
   public static String getImplementationVersion()
   {
      return DrbFactory.class.getPackage().getImplementationVersion();
   }

   /**
    * Opens a root node from an XQuery. The result of the XQuery is analyzed and
    * the first item in the sequence is returned if it is a node. Else null is
    * returned.
    * 
    * @param xquery the XQuery script to consider.
    * @return the root node.
    * @deprecated caller shall now use {@link fr.gael.drb.query.Query} directly
    *             for creating nodes from an XQuery script.
    * @see fr.gael.drb.query.Query
    */
   public static DrbNode open(final String xquery)
   {
      try
      {
         final Query query = new Query(xquery);

         final DrbNode dot = openURI(".");

         final DrbSequence sequence = query.evaluate(dot);

         if ((sequence != null) && (sequence.getLength() > 0)
               && (sequence.getItem(0) != null)
               && (sequence.getItem(0).getItemType() == DrbItem.NODE_ITEM))
         {
            return (DrbNode) sequence.getItem(0);
         }
         else
         {
            final DrbNode node = openURI(xquery);
            if (node != null)
            {
               return node;
            }
         }
      }
      catch (final DynamicException e1)
      {
         return openURI(xquery);
      }
      catch (final StaticException e2)
      {
         return openURI(xquery);
      }
      catch (final Exception e3)
      {
         logger.warn("Cannot parse or evaluate the XQuery \"" + xquery + "\"");
         logger.warn(e3.getMessage());
         e3.printStackTrace();
         return null;
      }
      return null;
   }

   /**
    * Opens a root node from an URI using a specific implementation.
    * 
    * @param uri the location of the node to be opened.
    * @param format the implementation used to open the node.
    * @return the opened node or null otherwise.
    */
   public static DrbNode openAs(final String uri, final String format)
   {
      final DrbNode base_node = openURI(uri);
      if (base_node == null)
      {
         return null;
      }

      // Try to load the implementation from the Factory register
      DrbFactoryImpl impl = factoryHash.get(format);
      if (impl == null)
      {
         impl = fr.gael.drb.impl.DrbFactoryResolver.resolveImpl(format);
         // TODO: verify the call to this resolver
      }

      // Try to load the implementation from the classpath
      if (impl == null)
      {
         try
         {
            final Object obj = Class.forName(format).newInstance();
            if (!(obj instanceof DrbFactoryImpl))
            {
               return null;
            }
            impl = (DrbFactoryImpl) obj;
         }
         catch (final Exception e)
         {
            return null;
         }
      }

      return impl.open(base_node);
   }

   /**
    * Opens the root node of a given URI. If the node has been successfully
    * opened, it is enveloped with a DrbNodeSpi that will automatically handle
    * resolutions from an implementation to another e.g. automatically switch
    * from File to XML implementation when a given file has an ".xml" extension.
    * 
    * @param uri The "Unified Resource Identifier" (URI) to be openned. This
    *           parameter shall not be null.
    * @return A root node of the matching implementation or null if an error
    *         occurred or if no implementation has matched.
    * @see fr.gael.drb.impl.spi.DrbNodeSpi
    */
   public static DrbNode openURI(final String uri)
   {
      return openURI(uri, true);
   }

   /**
    * Opens the root node of a given URI.
    * 
    * @param uri_string The "Unified Resource Identifier" (URI) to be openned.
    *           This parameter shall not be null.
    * @return A root node of the matching implementation or null if an error
    *         occurred or if no implementation has matched.
    */
   public static DrbNode openURI(final String uri_string,
         final boolean spi_envelope)
   {
      /**
       * Opens the requested node as an URL if possible. The default behavior of
       * the factory is to open nodes considering the URI provided in parameter
       * as regular URL.
       */
      DrbNode base_node = null;

      if (logger.isDebugEnabled())
      {
         logger.debug("DrbFactory.openURI(" + uri_string + ")");
      }

      /**
       * Opens the requested node as a regular file.
       */
      try
      {
         base_node = new FileFactory().open(uri_string);
      }
      catch (final Exception e)
      {
         // do nothing
      }
      logger.debug("URI(" + uri_string + ") opened as a file.");

      if (base_node == null)
      {
         try
         {
            final java.net.URL url = new java.net.URL(uri_string);
            logger.debug("DrbFactory.openURI(" + uri_string + "): protocol="
                  + url.getProtocol() + " path=" + url.getPath());
            final DrbFactoryImpl factory =
               DrbFactoryResolver.resolveImpl(url.getProtocol());

            if (factory == null)
            {
               base_node = new URLNode(url);
            }
            else
            {
               base_node = factory.open(url);
            }
         }
         catch (final Exception e)
         {
            // do nothing
         }
      }
      
      if ( spi_envelope &&(base_node != null) &&
           !(base_node instanceof DrbNodeSpi))
      {
         base_node = new DrbNodeSpi(base_node);
      }

      return base_node;
   } // open()

   /**
    * Opens a given base node. If the node has been successfully
    * opened, it is enveloped with a DrbNodeSpi that will automatically handle
    * resolutions from an implementation to another e.g. automatically switch
    * from File to XML implementation when a given file has an ".xml" extension.
    * 
    * @param node The base node be openned. This parameter shall not be null.
    * @return A root node of the matching implementation or null if an error
    *         occurred or if no implementation has matched.
    * @see fr.gael.drb.impl.spi.DrbNodeSpi
    */
   public static DrbNodeList open(final DrbNode node)
   {
      if (node == null)
      {
         return null;
      }

   /**
    * Sub-implementation children. This variable is dedicated to hold a
    * reference to the children built from another implementation. At the end of
    * the construction of a DrbNodeSpi node, the current implementation tries to
    * build children based on itself. The DrbFactory is used to perform this
    * creation. This useful functionality enables to switch automatically to an
    * implementation that is able to break down this node into several nodes.
    * For instance, a file wrapped by the current node may be an XML document
    * and could be broken down using an XML implementation.
    */
      DrbNodeList subImplChildren = null;

   // Get sub-implementation factory matching the this node, if any
       DrbFactoryImpl impl = DrbFactoryResolver.resolveImpl(node);       

       if (logger.isDebugEnabled())
       {
          logger.debug("Sub-implementation factory = \""
                + ((impl != null) ? impl.getName() : null) + "\"");
       }

       if (impl == null)
       {
          if (logger.isDebugEnabled())
          {
             logger.debug("No sub-implementation for node \""
                   + node.getName() + "\" (no matching factory found).");
          }

          return null;
       }

       // Open the sub-implementation child node
       final DrbNode subimpl_child = impl.open(node);

       if (logger.isDebugEnabled())
       {
          if (subimpl_child != null)
          {
             logger
                .debug("Sub-implementation \"" + impl.getName()
                      + "\" of node \"" + node.getName()
                      + "\" found a child node \"" + subimpl_child.getName()
                      + "\".");
          }
          else
          {
             logger.debug("Sub-implementation \"" + impl.getName()
                   + "\" of node \"" + node.getName()
                   + "\" did not found any child node.");
          }
       }

       // Case of archive. Retrieves the children of the root node.
       if ("jar".equals(impl.getIdentifier())
             || "zip".equals(impl.getIdentifier())
             || "tar".equals(impl.getIdentifier()))
       {
          if (subimpl_child != null)
          {
             subImplChildren = subimpl_child.getChildren();
          }
       }

       // Case of single child. Creates a list containing the
       // sub-implementation node.
       if ((subImplChildren == null) && (subimpl_child != null))
       {
          subImplChildren = new DrbDefaultNodeList();
          ((DrbDefaultNodeList) subImplChildren).add(subimpl_child);
       }

       // Return the sub-implementation children
       if (logger.isDebugEnabled())
       {
          if (subImplChildren != null)
          {
             logger.debug("Sub-implementation of node \""
                   + node.getName() + "\" resolved (children count = "
                   + subImplChildren.getLength() + ")");
          }
          else
          {
             logger.debug("No sub-implementation for node \""
                   + node.getName()
                   + "\" (matching factory found but resulted in no child).");
          }
       }

       return subImplChildren;
   }

   /**
    * Register an implementation that handle the specified format.
    * 
    * @param factory the input factory
    * @param format the input format
    * @return the factory name.
    */
   public static synchronized void registerImplementation(
         final DrbFactoryImpl factory, final String format)
   {
      factoryHash.put(format, factory);
   }

   /**
    * Command line that returns the implementation version of the software.
    */
   public static void main(final String[] args)
   {
      // Arguments processing
      int iarg;
      boolean argument_error = false;
      boolean display_usage = false;

      // A first loop on arguments to identify help parameter that
      // overrides any others.
      for (iarg = 0; iarg < args.length; iarg++)
      {
         /**
          * Case of help parameter. Prints the usage message and exit the
          * application.
          */
         if (args[iarg].equals("-help") || args[iarg].equals("--help")
               || args[iarg].equals("-h"))
         {
            System.out.println("Usage: java fr.gael.drb.DrbFactory [OPTIONS]\n"
                  + "\n" + "[--help | -h]: prints out the present usage\n"
                  + "\n" + "[--version]: prints out the current implementation "
                  + "version.");
            return;
         }
      }

      // A first loop on arguments to identify version parameter that
      // overrides any others but the help message.
      for (iarg = 0; iarg < args.length; iarg++)
      {
         /**
          * Case of Version request.
          */
         if (args[iarg].equals("-v") || args[iarg].equals("--version"))
         {
            System.out.println(DrbFactory.class.getPackage()
                  .getImplementationTitle()
                  + " - "
                  + getImplementationVersion()
                  + " ("
                  + DrbFactory.class.getPackage().getImplementationVendor()
                  + ")");
            return;
         }
      }

      // A last loop on other parameters. Because the present implementation
      // does not provide yet any other parameter, this loop prints a warning
      // message for all found parameters.
      for (iarg = 0; iarg < args.length; iarg++)
      {
         display_usage = true;
         argument_error = true;

         logger.warn("Unsupported argument \"" + args[iarg] + "\" (skipped).");
      }

      // Display usage if requested
      if (display_usage)
      {
         logger.warn("Use --help option to display proper usage.");
      }

      // Display fatal error message is no argument could be processed (in the
      // current implementation, any case that did not fall into help or version
      // request)
      if (argument_error)
      {
         logger.fatal("Error while processing command line parameters.");
         Runtime.getRuntime().exit(1);
      }

   } // End main()

} // DrbFactory
