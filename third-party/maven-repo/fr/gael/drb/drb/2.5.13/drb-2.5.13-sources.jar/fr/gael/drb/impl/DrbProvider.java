/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl;

/**
 * DrbNode provider.
 */
public abstract class DrbProvider
{
   /**
    * The name of this provider.
    * 
    * @return The name of this provider.
    */
   public abstract String getName();

   /**
    * The identifier of this provider.
    * 
    * @return The identifier of this provider.
    */
   public abstract String getIdentifier();

   /**
    * Says whether this provider has a specific feature given its name.
    * 
    * @param name the name of the feature
    * @return true if the provider has the named feature and false otherwise
    */
   public boolean hasFeature(final String name)
   {
      return false;
   }

   /**
    * Set a property.
    * 
    * @param name the name of the property
    * @param value the value of the property
    * @throws IllegalArgumentException if this provider does not support this
    *            property
    */
   public void setProperty(final String name, final Object value)
         throws IllegalArgumentException
   {
      throw new IllegalArgumentException("DrbProvider.setProperty() : "
            + "The property '" + name + "' is not supported.");
   }

   /**
    * Get a property given its name.
    * 
    * @param name the name of the property
    * @return the property corresponding to the specified name.
    */
   public Object getProperty(final String name)
   {
      return null;
   }

   /**
    * Commit any pending change.
    */
   public abstract void commit();
} // DrbProvider
