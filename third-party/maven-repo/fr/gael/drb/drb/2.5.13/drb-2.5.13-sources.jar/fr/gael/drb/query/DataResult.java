/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbSequence;
import fr.gael.drb.value.AbstractValueArray;
import fr.gael.drb.value.Value;
import fr.gael.drb.value.ValueArray;

/**
 * Performs an incremental atomization of an XQuery sequence. Ref:
 * http://www.w3.org/TR/xquery/#dt-atomization This class provides an optimized
 * evaluation of the fn:data() function. The atomized items are delivered in
 * pull access mode.
 */
final class DataResult extends AbstractValueArray
{
   /**
    * Logger
    */
   final static private Logger logger = Logger.getLogger(DataResult.class);
   
   /**
    * Maximum FIFO size.
    */
   final static private int MAX_FIFO_SIZE = 1 << 16;

   /**
    * The sequence to be atomized.
    */
   private DrbSequence sequence;

   /**
    * Current position within source items
    */
   private int cursor = 0;

   /**
    * Number of atomized items
    */
   private int itemCount = 0;

   /**
    * Last position in the source item starting at one.
    */
   private int lastPosition = 0;

   /**
    * Computed index of each item.
    */
   private int[] valueIndex;

   /**
    * Number of values in each item.
    */
   private int[] itemSize;

   /**
    * Value cache.
    */
   private Value[] valueCache;
   
   /**
    * Value FIFO.
    */
   private int[] fifo;

   /**
    * FIFO first index.
    */
   private int fifoFirstIndex;
   
   /**
    * FIFO last index.
    */
   private int fifoLastIndex;
   
   /**
    * Number of element in FIFO.
    */
   private int fifoSize;

   /**
    * Computed length
    */
   private int valueCount = 0;

   /**
    * Constructor of the data result.
    * 
    * @param sequence the sequence to be atomized.
    */
   DataResult(final DrbSequence sequence)
   {
      this.sequence = sequence;
      this.lastPosition = sequence.getLength();
      this.valueIndex = new int[this.lastPosition];
      this.itemSize = new int[this.lastPosition];
      this.valueCache = new Value[this.lastPosition];
      this.fifo = new int[this.lastPosition];
      this.fifoFirstIndex = 0;
      this.fifoLastIndex = 0;
      this.fifoSize = 0;
   } // DataResult

   /**
    * The number of values in the atomized sequence.
    * 
    * @return length of the atomized sequence.
    */
   public final int length()
   {
      /*
       * if (logger.isDebugEnabled()) { logger.debug("Computing atomized
       * sequence length:" + " itemCount=" + itemCount + ", last=" +
       * lastPosition); }
       */
      /**
       * Computes atomized sequence length
       */
      for (/* empty */; this.itemCount < this.lastPosition; this.itemCount++)
      {
         final Value current_value =
            this.sequence.getItem(this.itemCount).getValue();
         this.valueIndex[this.itemCount] = this.valueCount;

         /**
          * If item value is not null, increment atomized sequence length
          */
         if (current_value != null)
         {
            // Case of array
            if (current_value.getType() == Value.ARRAY_ID)
            {
               final int size = ((ValueArray) current_value).length();
               if (size < 0)
               {
                  throw new NegativeArraySizeException("The source item at"
                     + " index " + this.itemCount + " has a negative array size"
                     + " (" + size + ")");
               }
               this.itemSize[this.itemCount] = size;
               this.valueCount += size;
               putCache(current_value, this.itemCount, size);
            }
            // Case of atomic values
            else
            {
               this.itemSize[this.itemCount] = 1;
               this.valueCount++;
               putCache(current_value, this.itemCount, 1);
            }
         }
         else
         {
            this.itemSize[this.itemCount] = 0;
         }
      }

      return this.valueCount;
   } // length

   /**
    * Returns the DataResult priority
    * 
    * @return the DataResult priority (0)
    */
   public final int getPriority()
   {
      return 0;
   }

   /**
    * Returns the Array type
    * 
    * @return the array type as an int (UNKNOWN_ID)
    */
   public final int getArrayType()
   {
      return Value.UNKNOWN_ID;
   } // getArrayType

   /**
    * Put a value in the cache
    * @param value the value to store in the cache.
    * @param index the index of the value.
    * @param size the size of the value.
    */
   private void putCache(Value value, int index, int size)
   {
      this.valueCache[index] = value;
      int newFifoSize = this.fifoSize + size;
      //Case of FIFO overflow
      //Remove the first value from the FIFO                  
      if (newFifoSize > DataResult.MAX_FIFO_SIZE)
      {        
         newFifoSize -= this.itemSize[this.fifoFirstIndex];
         this.valueCache[this.fifo[this.fifoFirstIndex]] = null;
         this.fifoFirstIndex ++;
         if (this.fifoFirstIndex >= this.lastPosition)
         {
            this.fifoFirstIndex = 0;
         }         
      }
      //Add the new value in the FIFO
      this.fifo[this.fifoLastIndex] = index;
      this.fifoLastIndex ++;
      if (this.fifoLastIndex >= this.lastPosition)
      {
         this.fifoLastIndex = 0;
      }
      this.fifoSize = newFifoSize;
      /*System.out.println("Value " + index + " added in cache. Size="
            + size);*/
   }

   /**
    * Return the specified value in the atomized sequence
    */
   public final Value getElement(final int indice)
   {
      // Check parameter
      if (indice < 0)
      {
         throw new IllegalArgumentException("Value indice is out of bounds");
      }

      /**
       * Case of indice within atomized part Search the target item value using
       * computed indexes.
       */
      if (indice < this.valueCount)
      {
         int current = this.cursor; // current index in the sequence of items
         int first = 0; // index of first item in the sequence
         int last = this.itemCount; // position of last item in the sequence
         int array_indice; // indice in the item value array
         int count = 0;
         int first_indice = 0;
         int last_indice = this.valueCount;

         /*
          * if (logger.isDebugEnabled()) { logger.debug("Inside atomized
          * sub-sequence: " + "[" + first + " to " + last + "]" + ",
          * valueCount=" + valueCount + ", itemCount=" + itemCount); }
          */

         // Iterates over items until expected index
         // Pre-conditions:
         // P1: 0 <= indice < valueCount
         // P2: 0 <= cursor < itemCount
         // P3: index[0] = 0
         // P4: index[k+1] = index[k] + size[k], for all k in [first..last[
         // P5: size[k] >= 0, for all k in [first..last[
         // Invariants:
         // I1: 0 <= first <= current < last <= itemCount
         // I2: 0 <= index[first] <= indice < index[last]
         // I3: index[first] <= index[current] < index[last]
         // I4: index[current+1] = index[current] + size[current]
         // Post-conditions:
         // O1: 0 <= indice - index[current] < size[current]
         while (first < last)
         {
            count++;
            final int current_indice = this.valueIndex[current];
            array_indice = indice - current_indice;

            // Case of index preceding the current item
            // .. indice - index[current] < 0
            // .. indice < index[current] <= index[last]
            // Conclusion: the expected item index is lower than current
            if (array_indice < 0)
            {
               last = current; // //search restricted to [first .. current [
               last_indice = this.valueIndex[last];
            }
            else
            // Case of index matching the current item (post-condition OK)
            // 0 <= indice - index[current] < size[current]
            if (array_indice < this.itemSize[current])
            {
               this.cursor = current;
               /*
                * if (logger.isDebugEnabled()) { logger.debug("Index " + indice + "
                * found at cursor " + cursor + ", start=" + valueIndex[current] + ",
                * size=" + itemSize[current] + ", indice=" + array_indice + ",
                * trial=" + count); }
                */

               /**
                * Atomizes current item
                */
               Value value = this.valueCache[current];
               if (value == null)
               {
                  value = this.sequence.getItem(current).getValue();
                  putCache(value, current, this.itemSize[current]);
               }

               if (value == null)
               {
                  throw new NullPointerException(
                        "Unexpected null item value at index " + current);
               }

               // Case of array
               if (value.getType() == Value.ARRAY_ID)
               {
                  final ValueArray array = (ValueArray) value;
                  return array.getElement(array_indice);
               }
               else
               // Case of atomic value
               {
                  return value;
               }
            }
            else
            // Case of index following the current item
            // .. indice - index[current] >= size[current]
            // .. index[current] + size[current] <= indice
            // .. index[current+1] <= indice < index[last] (see P4 and P2)
            // Conclusion: the expected item index is greater than current + 1
            {
               first = current + 1; // search restricted to [current+1 .. last]
               first_indice = current_indice + this.itemSize[current];
            }

            // Search another item using a linear prediction
            if (first_indice < last_indice)
            {
               final long xrange = last_indice - first_indice;
               final long yrange = last - first;
               final long xdelta = indice - first_indice;
               current = (int) ((yrange * xdelta + xrange * first) / xrange);

               if ((current < first) || (current >= last))
               {
                  logger.error("Internal error during atomisation: "
                        + " trials=" + count + " valueCount=" + this.valueCount
                        + " first=<" + first + ", " + first_indice + ">"
                        + " last=<" + last + ", " + last_indice + ">"
                        + " current=<" + current + ", " + current_indice + ">");
                  break;
               }
            }
            else
            {
               logger.error("Internal error during atomisation: " + " trials="
                     + count + " valueCount=" + this.valueCount + " first=<"
                     + first + ", " + first_indice + ">" + " last=<" + last
                     + ", " + last_indice + ">" + " current=<" + current + ", "
                     + current_indice + ">");
               break;
            }
         } // End while loop on atomized items

         throw new UnsupportedOperationException(
               "Internal error while searching the value at indice " + indice);
      } // end if: array indice within atomized part

      // Performs a partial atomization of the remaining sequence.
      // We iterate over item while the value count is less than the target
      // index.
      // Pre-condition:
      // .. 0 <= indice <= valueCount
      // Loop invariants:
      // .. 0 <= indice <= valueCount
      // .. 0 <= index[cursor] <= indice
      // array_indice = indice - index[cursor] >= 0
      // Post-conditions: one of the following
      // 1) Inside an item value
      // .. 0 <= indice - index[cursor] < size[cursor]
      // .. 0 <= array_indice < size[cursor]
      // 2) Index out of bounds
      // .. index[last] < indice
      while (this.itemCount < this.lastPosition)
      {
         /**
          * Atomizes current item.
          */
         this.cursor = this.itemCount++;
         final Value current_value =
            this.sequence.getItem(this.cursor).getValue();
         this.valueIndex[this.cursor] = this.valueCount;

         /**
          * If item value is not null, increment atomized sequence length
          */
         if (current_value != null)
         {
            final int array_indice = indice - this.valueCount;
            // Case of array
            if (current_value.getType() == Value.ARRAY_ID)
            {
               final ValueArray array = (ValueArray) current_value;
               final int len = array.length();
               this.itemSize[this.cursor] = len;
               this.valueCount += len;

               putCache(current_value, this.cursor, len);
               /**
                * Case of index inside current item
                */
               if (array_indice < len)
               {
                  // Returns immediately if the output index has been found
                  return array.getElement(array_indice);
               }
               if (len < 0)
               {
                  throw new NegativeArraySizeException("Cannot read the value "
                     + " at indice " + indice + ". The source item at index "
                     + this.cursor + " has a negative array size"
                     + " (" + len + ")");
               }
            }
            // Case of atomic values
            else
            {
               this.itemSize[this.cursor] = 1;
               this.valueCount++;
               putCache(current_value, this.cursor, 1);

               if (array_indice == 0)
               {
                  // Returns immediately if the output index has been found
                  return current_value;
               }
            }
         }
         else
         {
            this.itemSize[this.cursor] = 0;
         }
      }

      // Value not found: index is out of bound
      return null;
   } // getElement

   /**
    * Assign a value to an index This method always throw an
    * UnsupportedOperationException
    * 
    * @param index position where to insert the value.
    * @param element value to assign.
    */
   public final void assign(final int index, final Value element)
   {
      throw new UnsupportedOperationException(
            "Atomized sequences are not mutable");
   } // assign

   /**
    * Assign a new Value. This method always throw an
    * UnsupportedOperationException
    * 
    * @param v the value to be assigned.
    * @throws ClassCastException an exception
    */
   public final void assign(final Value v) throws ClassCastException
   {
      throw new UnsupportedOperationException(
            "Atomoized sequences are not mutable");
   }
} // DataResult
