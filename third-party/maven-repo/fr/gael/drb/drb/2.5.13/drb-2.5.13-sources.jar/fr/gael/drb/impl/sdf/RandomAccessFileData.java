/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sdf;

import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * Random Access Data.
 */
class RandomAccessFileData extends RandomAccessData
{
   /**
    * The wrapped random access file.
    */
   RandomAccessFile file;

   /**
    * Creates a RandomAccessFileData from the specified file.
    * 
    * @param file The ramdomAccessFile
    */
   public RandomAccessFileData(final RandomAccessFile file)
   {
      this.file = file;
   }

   /**
    * Finalize.
    * 
    * @throws Throwable the Exception raised by this method
    */
   protected void finalize() throws Throwable
   {
      this.file.close();
   }

   // ---
   // DataInput implementation.
   // ---

   /**
    * Reads one input byte and returns true if that byte is nonzero, false if
    * that byte is zero.
    * 
    * @return true if the buffer's current position is superior than 0, else
    *         return false
    * @throws IOException if an I/O error occurs.
    */
   public boolean readBoolean() throws IOException
   {
      return this.file.readBoolean();
   }

   /**
    * Reads and returns one input byte.
    * 
    * @return The byte at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public byte readByte() throws IOException
   {
      return this.file.readByte();
   }

   /**
    * Reads an input char and returns the char value.
    * 
    * @return The char value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public char readChar() throws IOException
   {
      return this.file.readChar();
   }

   /**
    * Reads eight input bytes and returns a double value.
    * 
    * @return The double value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public double readDouble() throws IOException
   {
      return this.file.readDouble();
   }

   /**
    * Reads four input bytes and returns a float value.
    * 
    * @return The float the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public float readFloat() throws IOException
   {
      return this.file.readFloat();
   }

   /**
    * Reads some bytes from an input stream and stores them into the buffer
    * array b.
    * 
    * @param b The array into which bytes are to be read
    * @throws IOException if an I/O error occurs.
    */
   public void readFully(final byte[] b) throws IOException
   {
      this.file.readFully(b);
   }

   /**
    * Reads len bytes from an input stream.
    * 
    * @param b The array into which bytes are to be read
    * @param off The offset within the array of the first byte to be read; must
    *           be non-negative and no larger than <tt>b.len</tt>
    * @param len The maximum number of bytes to be read to the given array; must
    *           be non-negative and no larger than <tt>b.len - off</tt>
    * @throws IOException if an I/O error occurs.
    */
   public void readFully(final byte[] b, final int off, final int len)
         throws IOException
   {
      this.file.readFully(b, off, len);
   }

   /**
    * Reads four input bytes and returns an int value.
    * 
    * @return The int value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public int readInt() throws IOException
   {
      return this.file.readInt();
   }

   /**
    * Reads the next line of text from the input stream.
    * 
    * @return The string value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public String readLine() throws IOException
   {
      return this.file.readLine();
   }

   /**
    * Reads eight input bytes and returns a long value.
    * 
    * @return The long value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public long readLong() throws IOException
   {
      return this.file.readLong();
   }

   /**
    * Reads two input bytes and returns a short value.
    * 
    * @return The short value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public short readShort() throws IOException
   {
      return this.file.readShort();
   }

   /**
    * Reads one input byte, zero-extends it to type int, and returns the result,
    * which is therefore in the range 0 through 255.
    * 
    * @return The input byte
    * @throws IOException if an I/O error occurs.
    */
   public int readUnsignedByte() throws IOException
   {
      return this.file.readUnsignedByte();
   }

   /**
    * Reads one input byte, zero-extends it to type int, and returns the result,
    * which is therefore in the range 0 through 255.
    * 
    * @return The input byte
    * @throws IOException if an I/O error occurs.
    */
   public int readUnsignedShort() throws IOException
   {
      return this.file.readUnsignedShort();
   }

   /**
    * Makes an attempt to skip over n bytes of data from the input stream,
    * discarding the skipped bytes.
    * 
    * @param n bytes to skip
    * @return The input byte
    * @throws IOException if an I/O error occurs.
    */
   public int skipBytes(final int n) throws IOException
   {
      return this.file.skipBytes(n);
   }

   /**
    * Reads in a string that has been encoded using a modified UTF-8 format.
    * 
    * @return The string
    * @throws IOException if an I/O error occurs.
    */
   public String readUTF() throws IOException
   {
      return this.file.readUTF();
   }

   // ---
   // DataOuput implementation.
   // ---

   /**
    * Writes a boolean value to this output stream.
    * 
    * @param v The boolean to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeBoolean(final boolean v) throws IOException
   {
      this.file.writeBoolean(v);
   }

   /**
    * Writes to the output stream the eight low- order bits of the argument v.
    * 
    * @param v The int to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeByte(final int v) throws IOException
   {
      this.file.writeByte(v);
   }

   /**
    * Writes a char value, wich is comprised of two bytes, to the output stream.
    * 
    * @param v The char to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeChar(final int v) throws IOException
   {
      this.file.writeChar(v);
   }

   /**
    * Writes every character in the string s, to the output stream, in order,
    * two bytes per character.
    * 
    * @param s The string to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeChars(final String s) throws IOException
   {
      this.file.writeChars(s);
   }

   /**
    * Writes a string to the output stream.
    * 
    * @param s The string to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeBytes(final String s) throws IOException
   {
      this.file.writeBytes(s);
   }

   /**
    * Writes a double value, which is comprised of eight bytes, to the output
    * stream.
    * 
    * @param v The double to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeDouble(final double v) throws IOException
   {
      this.file.writeDouble(v);
   }

   /**
    * Writes a float value, which is comprised of four bytes, to the output
    * stream.
    * 
    * @param v The float to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeFloat(final float v) throws IOException
   {
      this.file.writeFloat(v);
   }

   /**
    * Writes to the output stream all the bytes in array b.
    * 
    * @param b The byte[] to write
    * @throws IOException if an I/O error occurs.
    */
   public void write(final byte[] b) throws IOException
   {
      this.file.write(b);
   }

   /**
    * Writes len bytes from array b, in order, to the output stream.
    * 
    * @param b The array from which bytes are to be read
    * @param off The offset within the array of the first byte to be read; must
    *           be non-negative and no larger than <tt>array.length</tt>
    * @param len The number of bytes to be read from the given array; must be
    *           non-negative and no larger than <tt>array.length - offset</tt>
    * @throws IOException if an I/O error occurs.
    */
   public void write(final byte[] b, final int off, final int len)
         throws IOException
   {
      this.file.write(b, off, len);
   }

   /**
    * Writes an int value, which is comprised of four bytes, to the output
    * stream.
    * 
    * @param v The int to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeInt(final int v) throws IOException
   {
      this.file.writeInt(v);
   }

   /**
    * Writes to the output stream the eight low-order bits of the argument b.
    * 
    * @param v The int to write
    * @throws IOException if an I/O error occurs.
    */
   public void write(final int v) throws IOException
   {
      this.file.write(v);
   }

   /**
    * Writes a long value, which is comprised of eight bytes, to the output
    * stream.
    * 
    * @param v The long to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeLong(final long v) throws IOException
   {
      this.file.writeLong(v);
   }

   /**
    * Writes two bytes to the output stream to represent the value of the
    * argument.
    * 
    * @param v The int to write into short
    * @throws IOException if an I/O error occurs.
    */
   public void writeShort(final int v) throws IOException
   {
      this.file.writeShort(v);
   }

   /**
    * Writes two bytes of length information to the output stream, followed by
    * the Java modified UTF representation of every character in the string s
    * 
    * @param str The string to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeUTF(final String str) throws IOException
   {
      this.file.writeUTF(str);
   }

   /**
    * Closes this random access file stream and releases any system resources
    * associated with the stream.
    * 
    * @throws IOException if an I/O error occurs.
    */
   void close() throws java.io.IOException
   {
      this.file.close();
   }

   /**
    * Returns the number of bytes that can be read (or skipped over) from this
    * input stream without blocking by the next caller of a method for this
    * input stream. The next caller might be the same thread or or another
    * thread.
    * 
    * @throws java.io.IOException if an I/O error occurs.
    * @return the number of byte that can be read without blocking.
    */
   public long available() throws java.io.IOException
   {
      return this.file.length() - this.file.getFilePointer();
   }

   /**
    * Sets the data-pointer offset, measured from the beginning of this data, at
    * which the next read or write occurs.
    * 
    * @param pos The new position value; must be non-negative and no larger than
    *           the current limit
    * @throws IOException if an I/O error occurs.
    */
   void seek(final long pos) throws IOException
   {
      this.file.seek(pos);
   }

   /**
    * Returns the length of this dta.
    * 
    * @return long The buffer capacity
    * @throws IOException if an I/O error occurs.
    */
   long length() throws java.io.IOException
   {
      return this.file.length();
   }
} // RandomAccessFileData
