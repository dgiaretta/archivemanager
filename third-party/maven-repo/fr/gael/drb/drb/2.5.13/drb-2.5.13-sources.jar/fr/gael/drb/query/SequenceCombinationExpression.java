/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbSequence;

/**
 * Wraps the sequence combination, "union", "intersect" and "except" of the
 * XQuery language.
 */
class SequenceCombinationExpression extends AbstractExpression
{
   /**
    * UNION indicator.
    */
   protected static int UNION = 0;

   /**
    * INTERSECT indicator.
    */
   protected static int INTERSECT = 1;

   /**
    * EXCEPT indicator.
    */
   protected static int EXCEPT = 2;

   /**
    * Expression wrapping the left operand.
    */
   protected Expression leftOperand;

   /**
    * Expression wrapping the right operand.
    */
   protected Expression rightOperand;

   /**
    * Type of the operation of the current instance.
    */
   protected int combination;

   /**
    * Builds a sequence combination expression.
    * 
    * @param token the token related to the current expression.
    * @param left_operand the left oprand expression.
    * @param combination indicator of the type of combination expression.
    * @param right_operand the right oprand expression.
    */
   public SequenceCombinationExpression(final Token token,
         final Expression left_operand, final int combination,
         final Expression right_operand)
   {
      super("Sequence combination", token);
      this.leftOperand = left_operand;
      this.combination = combination;
      this.rightOperand = right_operand;
   }

   /**
    * Returns a the sequence combination expression as a convenient string.
    * 
    * @return the string detailing the sequence combination operation.
    */
   public String toString()
   {
      String combination_string;

      switch (this.combination)
      {
         case 0:
            combination_string = "union";
            break;
         case 1:
            combination_string = "intersect";
            break;
         case 2:
            combination_string = "except";
            break;
         default:
            combination_string =
               "(unkown combination #" + this.combination + ")";
      }

      return this.leftOperand + " " + combination_string + " "
            + this.rightOperand;
   }

   /**
    * Applies the comibnation considering a given dynamic context.
    * 
    * @param context the outer-focus of the evalutation.
    * @return the sequence resulting from the dynamic evaluation.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {
      /**
       * Prepare output result.
       */
      final DrbDefaultNodeList outputSequence = new DrbDefaultNodeList();

      /**
       * Evaluate the left operand.
       */
      final DrbSequence leftSequence = this.leftOperand.evaluate(context);

      /**
       * Evaluate the right operand.
       */
      final DrbSequence rightSequence = this.rightOperand.evaluate(context);

      /**
       * Performs the union combination.
       */
      if (this.combination == this.UNION)
      {
         /**
          * Inserts the nodes of the left operand in the output sequence,
          * verifying they are not duplicated.
          */
         for (int ileft = 0; ileft < leftSequence.getLength(); ileft++)
         {
            /**
             * Extracts current left node.
             */
            final DrbItem leftItem = leftSequence.getItem(ileft);

            if (leftItem.getItemType() != DrbItem.NODE_ITEM)
            {
               throw new TypeException(this, "The item #" + (ileft + 1)
                     + " of the left operand is not a node.");
            }

            final DrbNode leftNode = (DrbNode) leftItem;

            /**
             * The node should not have already been inserted. This rule
             * derivate from the XQuery specifications: "All of these operators
             * return their result sequences in document order without
             * duplicates".
             */
            boolean already_insterted = false;

            for (int iout = 0; iout < outputSequence.getLength(); iout++)
            {
               if (leftNode.equals(outputSequence.item(iout)))
               {
                  already_insterted = true;
                  break;
               }
            }

            /**
             * insert the node if not already done.
             */
            if (already_insterted == false)
            {
               outputSequence.addItem(leftNode);
            }
         }

         /**
          * Do more or less the same thing but for right operand.
          */
         for (int iright = 0; iright < rightSequence.getLength(); iright++)
         {
            /**
             * Extracts current right node.
             */
            final DrbItem rightItem = rightSequence.getItem(iright);

            if (rightItem.getItemType() != DrbItem.NODE_ITEM)
            {
               throw new TypeException(this, "The item #" + (iright + 1)
                     + " of the right operand is not a node.");
            }

            final DrbNode rightNode = (DrbNode) rightItem;

            /**
             * The node should not have already been inserted. This rule
             * derivate from the XQuery specifications: "All of these operators
             * return their result sequences in document order without
             * duplicates".
             */
            boolean already_insterted = false;

            for (int iout = 0; iout < outputSequence.getLength(); iout++)
            {
               if (rightNode.equals(outputSequence.item(iout)))
               {
                  already_insterted = true;
                  break;
               }
            }

            /**
             * insert the node if not already done.
             */
            if (already_insterted == false)
            {
               outputSequence.addItem(rightNode);
            }
         }
      }

      /**
       * Performs the intersect or except combination.
       */
      if ((this.combination == this.INTERSECT)
            || (this.combination == this.EXCEPT))
      {
         /**
          * Loop on the nodes of the left operands.
          */
         for (int ileft = 0; ileft < leftSequence.getLength(); ileft++)
         {
            /**
             * Extracts current left node.
             */
            final DrbItem leftItem = leftSequence.getItem(ileft);

            if (leftItem.getItemType() != DrbItem.NODE_ITEM)
            {
               throw new TypeException(this, "The item #" + (ileft + 1)
                     + " of the left operand is not a node.");
            }

            final DrbNode leftNode = (DrbNode) leftItem;

            /**
             * Should the node not already inserted. This rule derivate from the
             * XQuery specifications: "All of these operators return their
             * result sequences in document order without duplicates".
             */
            boolean already_insterted = false;

            for (int iout = 0; iout < outputSequence.getLength(); iout++)
            {
               if (leftNode.equals(outputSequence.item(iout)))
               {
                  already_insterted = true;
                  break;
               }
            }

            /**
             * Assess the existence of the node in the right operand.
             */
            boolean exists_in_righ_operand = false;

            for (int iright = 0; iright < rightSequence.getLength(); iright++)
            {
               /**
                * Extract the current right operand.
                */
               final DrbItem rightItem = rightSequence.getItem(iright);

               if (rightItem.getItemType() != DrbItem.NODE_ITEM)
               {
                  throw new TypeException(this, "The item #" + (iright + 1)
                        + " of the right operand is not a node.");
               }

               final DrbNode rightNode = (DrbNode) rightItem;

               /**
                * Compare nodes.
                */

               if (leftNode.equals(rightNode))
               {
                  exists_in_righ_operand = true;
                  break;
               }
            }

            /**
             * Insert or node according to the seclected type of combination.
             */
            if ((already_insterted == false)
                  && (((this.combination == this.INTERSECT) && (exists_in_righ_operand == true)) || ((this.combination == this.EXCEPT) && (exists_in_righ_operand == false))))
            {
               outputSequence.addItem(leftNode);
            }
         }
      }
      /**
       * Return the output sequence.
       */
      return outputSequence;
   }

   /**
    * Checks if this comma expression can modify the state of an existing node.
    * A comma expression is updating if any operand is updating.
    * 
    * @return true if this expression performs updating operations and false
    *         otherwise
    */
   public boolean isUpdating()
   {
      return (this.leftOperand.isUpdating() || this.rightOperand.isUpdating());
   }
}
