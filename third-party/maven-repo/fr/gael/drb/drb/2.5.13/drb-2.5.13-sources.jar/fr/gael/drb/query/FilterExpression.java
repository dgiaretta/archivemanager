/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbSequence;

/**
 * Provides convenient/common implementation for Filter Expressions.
 */
class FilterExpression extends AbstractExpression
{

   /**
    * The primary expression representing this filter expression
    */
   private Expression expression;

   /**
    * The list of predicats to filter
    */
   private Expression predicatsList;

   /**
    * Construct a new Filter Expression
    * 
    * @param token the token related to the variable reference.
    * @param expression The primary expression encapsulated inside the filter
    *           expression
    * @param predicats The list of predicats
    */
   public FilterExpression(final Token token, final Expression expression,
         final Expression predicats)
   {
      super("Filter", token);
      this.expression = expression;
      this.predicatsList = predicats;

   }

   /**
    * Evaluate a filter expression, meaning evaluating first the primary
    * expression. T Then filtering the resulting sequence with the predicats
    * 
    * @param context dynamic evaluation context.
    * @return the evaluated and filtered sequence.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {
      DrbSequence sequence;

      /**
       * Evaluation of the primary expression
       */
      sequence = this.expression.evaluate(context);

      /**
       * Filtering the sequence
       */
      return this.filterSequence(context, sequence);
   }

   /**
    * A expression which is constant means that it need no context item to be
    * evaluate. The returned sequence from its evaluation will always be the
    * same along the query script
    * 
    * @return true if this expression is constant
    */
   public boolean isConstant()
   {

      return (this.expression.isConstant() && this.predicatsList.isConstant());
   }

   /**
    * @param context context
    * @param sequence sequence
    * @return sequence
    */
   private DrbSequence filterSequence(final DynamicContext context,
         final DrbSequence sequence)
   {

      if ((this.predicatsList == null) || (sequence == null))
      {
         return sequence;
      }

      final DynamicContext innerContext = new DynamicContext(context);
      DrbSequence sequence_output;
      DrbItem current_item;

      // new empty sequence
      sequence_output = new DrbDefaultSequence();

      // position limits for browsing the sequence
      final int[] positions = new int[2];
      // if positions are irrelevant , return an empty sequence
      if (!((PredicatsListExpression) this.predicatsList).getEvaluationLimit(
            context, positions))
      {
         return sequence_output;
      }

      int min_position = positions[0];
      int max_position = positions[1];

      // rearrange limits if they are out of bound
      if (max_position > sequence.getLength())
      {
         max_position = sequence.getLength();
      }
      if (min_position < 1)
      {
         min_position = 1;
      }

      // System.out.println("-->"+ min_position+ " "+max_position);
      /**
       * tests each item of the sequence with the predicats
       */
      for (int pos = min_position - 1; pos < max_position/* sequence.getLength() */; pos++)
      {

         // getting the item of the sequence
         current_item = sequence.getItem(pos);

         /**
          * IMPORTANT: Test if the item is null , because max_position can be
          * out of bound of the size of the sequence
          */
         if (current_item == null)
         {
            break;
         }

         innerContext.focus.setContextItem(current_item);
         innerContext.focus.setContextPosition(pos + 1);
         innerContext.focus.setContextSize(sequence.getLength());

         /**
          * Test the predicates on this item, if true, add the item to the
          * output sequence
          */
         if (Query.getEffectiveBooleanValue(this.predicatsList
               .evaluate(innerContext)))
         {
            ((DrbDefaultSequence) sequence_output).addItem(current_item);
         }

      }

      return sequence_output;
   }

} // FilterExpression
