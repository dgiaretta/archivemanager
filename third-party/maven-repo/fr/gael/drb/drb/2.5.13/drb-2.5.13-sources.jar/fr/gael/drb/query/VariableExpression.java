/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbSequence;

/**
 * Wraps a variable reference of XQuery language.
 */
class VariableExpression extends AbstractExpression
{
   /**
    * Logger
    */
   Logger logger = Logger.getLogger(VariableExpression.class);

   /**
    * Variable qualified name.
    */
   QName name;

   /**
    * Builds a variable reference.
    * 
    * @param token the token related to the variable reference.
    * @param name name string form of the variable qualified name.
    */
   public VariableExpression(final Token token, final QName name)
   {
      super("Variable reference", token);
      this.name = new QName(name);
   }

   /**
    * Returns the description of the variable reference. The format is : "$"
    * <qualified_name>
    * 
    * @return the description of the variable reference.
    */
   public String toString()
   {
      return "$" + this.name;
   }

   /**
    * Evaluates the variable reference. The principle of this evaluation is to
    * evaluate the variables from the dynamic context provided, should be an
    * external variable.
    * 
    * @param context dynamic evaluation context.
    * @return the evaluated sequence.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {
      /**
       * Get the variable definition from the context.
       */
      final Variable variable = context.getInScopeVariable(this.name);

      if (variable == null)
      {
         throw new DynamicException(this, "The variable " + variable
               + " is not defined in the dynamic context");
      }

      /**
       * Returns the variable value.
       */
      return variable.getValue();
   }

   /**
    * A expression which is constant means that it need no context item to be
    * evaluate. The returned sequence from its evaluation will always be the
    * same along the query script
    * 
    * @return true if this expression is constant
    */
   public boolean isConstant()
   {
      return true;
   }
}
