/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

import java.math.BigDecimal;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

import org.apache.log4j.Logger;

/**
 * The DateTime class is a generic wrapper for Date values.
 */
public class DateTime extends AbstractValue implements Value, Arithmetic,
      Comparison, ValueFormat
{
   // ==========================================================================
   // Attributes part.
   // ==========================================================================

   /**
    * The time of MJD2000.
    */
   private static final long MJD2000_TIME = 946684800000L;

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(DateTime.class);

   /**
    * The DateTime priority.
    */
   final static int PRIORITY = 7;

   /**
    * The DateTime value.
    */
   protected java.sql.Timestamp dateTime;

   // ==========================================================================
   // Methods part.
   // ==========================================================================
   /**
    * Constructs an DateTime object initialized to the current system time.
    */
   public DateTime()
   {
      final TimeZone timeZone = TimeZone.getDefault();
      final long currentTime = System.currentTimeMillis();
      this.dateTime =
         new java.sql.Timestamp(currentTime + timeZone.getOffset(currentTime));
   }

   /**
    * Allocates a Date object and initializes it to represent the specified
    * number of milliseconds since the standard base time known as "the epoch",
    * namely January 1, 1970, 00:00:00 GMT.
    * 
    * @param dt the value of the Double.
    * @see java.util.Date
    */
   public DateTime(final long dt)
   {
      this.dateTime = new java.sql.Timestamp(dt);
   }

   /**
    * Attempts to interpret the string s as a representation of a date and time.
    * The representation is assumed as "UTC" time (27 bytes) with format :
    * "DD-MMM-YYYY HH:mm:ss.tttttt".
    * 
    * @param s string to be parsed as a date.
    * @see java.util.Date
    */
   public DateTime(final java.lang.String s)
   {
      // Call constructor of the superclass
      this.dateTime = new java.sql.Timestamp(0);

      // Local declaration
      long nanos = 0; // Get nanoseconds
      SimpleDateFormat pds_formatter; // PDS/Date formatter
      SimpleDateFormat iso_formatter; // ISO/Date formatter
      ParsePosition pos; // Parse position used by formatter
      java.util.Date date; // Extracted date

      // Create formatter
      pds_formatter =
         new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss", java.util.Locale.ENGLISH);
      pds_formatter.setTimeZone(TimeZone.getTimeZone("GMT"));

      iso_formatter =
         new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.ENGLISH);
      iso_formatter.setTimeZone(TimeZone.getTimeZone("GMT"));

      // Parse date
      pos = new ParsePosition(0);
      date = pds_formatter.parse(s, pos);
      if (date == null)
      {
         pos = new ParsePosition(0);
         date = iso_formatter.parse(s, pos);
      }

      if (s.indexOf(".") > 0)
      {
         final BigDecimal frac =
            new BigDecimal("0." + s.substring(s.indexOf(".") + 1));
         nanos = frac.multiply(BigDecimal.valueOf(1000000000L)).longValue();
      }

      // Make date
      this.setTime(date.getTime() + nanos / 1000000);
      this.setNanos((int) nanos);
   }

   /**
    * Attempts to interpret the binary buffer as a representation of a date and
    * time (MJD format). It assumes that buffer.length is 12. 946684800000L is
    * the offset of 01/01/2000 00:00:00.000000 (MJD origin). It is added to MJD
    * values for setTime() operation.
    * 
    * @param buffer buffer to be parsed as a date.
    * @see java.util.Date
    */
   public DateTime(final byte[] buffer)
   {
      // Call constructor of the superclass
      this.dateTime = new java.sql.Timestamp(0);

      // The representation is assumed as "mjd" (3 * 4 bytes) :
      // int numDays : nb of days since Jan 1, 2000
      // unsigned int seconds : nb of seconds since the last day
      // unsigned int microseconds : nb of microseconds since the
      // last second
      int days; // number of days
      long seconds; // number of seconds
      long microseconds; // number of microseconds
      byte[] mjdBuffer; // Buffer to use if length is invalid

      // By default use passed buffer (length=12)
      mjdBuffer = buffer;

      // Check buffer length, Case of smaller buffer
      if (buffer.length < 12)
      {
         this.logger.error("fr.gael.drb.value.DateTime(buffer[]) : "
               + "Buffer length is lower than 12, append with zero values.");
         mjdBuffer = new byte[12];
         System.arraycopy(buffer, 0, mjdBuffer, 0, buffer.length);
      }
      // Case of larger buffer, just print warning
      else if (buffer.length > 12)
      {
         this.logger.error("fr.gael.drb.value.DateTime(buffer[]) : "
               + "Buffer length is greater than 12, ignore extra values.");
      }

      // Get number of days
      days =
         ((buffer[0] & 0xff) << 24) + ((buffer[1] & 0xff) << 16)
               + ((buffer[2] & 0xff) << 8) + (buffer[3] & 0xff);
      // Get number of seconds
      seconds =
         ((buffer[4] & 0xff) << 24) + ((buffer[5] & 0xff) << 16)
               + ((buffer[6] & 0xff) << 8) + (buffer[7] & 0xff);
      // Get number of microseconds
      microseconds =
         ((buffer[8] & 0xff) << 24) + ((buffer[9] & 0xff) << 16)
               + ((buffer[10] & 0xff) << 8) + (buffer[11] & 0xff);

      // Make date
      this.setTime(this.MJD2000_TIME + 1000 * (86400 * days + seconds));
      this.setNanos((int) (microseconds * 1000));
   }

   /**
    * Returns the number of milliseconds since January 1, 1970, 00:00:00 GMT
    * represented by this DateTime object.
    * 
    * @return the number of milliseconds since January 1, 1970, 00:00:00 GMT
    *         represented by this date.
    */
   public long getTime()
   {
      return this.dateTime.getTime();
   }

   /**
    * Gets this DateTime object's nanos value.
    * 
    * @return this DateTime object's fractional seconds component
    */
   public int getNanos()
   {
      return this.dateTime.getNanos();
   }

   /**
    * Sets this Timestamp object to represent a point in time that is time
    * milliseconds after January 1, 1970 00:00:00 GMT.
    * 
    * @param time the number of milliseconds.
    */
   public void setTime(final long time)
   {
      this.dateTime.setTime(time);
   }

   /**
    * Sets this DateTime object's nanos field to the given value.
    * 
    * @param nanos the new fractional seconds component
    */
   public void setNanos(final int nanos)
   {
      this.dateTime.setNanos(nanos);
   }

   // --------------------------------------------------------------------------
   // Value interface implementation
   // --------------------------------------------------------------------------

   /**
    * The type identifier of this DateTime value.
    * 
    * @return an identifier of the DateTime type.
    */
   public final int getType()
   {
      return Value.DATE_ID;
   }

   /**
    * Returns the DateTime priority
    * 
    * @return the DateTime priority
    */
   public final int getPriority()
   {
      return this.PRIORITY;
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself is returned. If the conversion is not allowed a
    * ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException the conversion is impossible
    */
   public final Value convertTo(final int type) throws ClassCastException
   {
      switch (type)
      {
         // DateTime -> DateTime conversion
         case Value.DATE_ID:
            return this;

            // DateTime -> Long consersion
         case Value.LONG_ID:
         case Value.NUMERIC_ID:
            return new Long(this.getTime());

            // DateTime -> String conversion
         case Value.STRING_ID:
            return new String(this.toString());

            // DateTime -> Unknown conversion
         default:
            throw new ClassCastException();
      }
   }

   /**
    * Assign a new Value. An implicit conversion may be performed to make the
    * assignment.
    * 
    * @param v the value to be assigned.
    */
   public void assign(final Value v)
   {
      final DateTime vd = (DateTime) v.convertTo(Value.DATE_ID);
      this.setTime(vd.getTime());
      this.setNanos(vd.getNanos());
   }

   // --------------------------------------------------------------------------
   // Sumable interface implementation
   // --------------------------------------------------------------------------

   /**
    * Compute an addition.
    * 
    * @param x another value.
    * @return the sum of this date/time with a duration.
    */
   public Value add(final Value x)
   {
      final DayTimeDuration vd =
         (DayTimeDuration) (x.convertTo(Value.DAY_TIME_DURATION_ID));
      final double sum = this.getFullTime() + vd.getDayTime() * 1e+3;
      final DateTime date = new DateTime((long) sum);
      date.setFullTime(sum);
      return date;
   }

   // --------------------------------------------------------------------------
   // Arithmetic interface implementation
   // --------------------------------------------------------------------------
   /**
    * Compute an unary minus (not supported).
    * 
    * @return always null
    */
   public Value unaryMinus()
   {
      return null;
   }

   /**
    * Compute a substraction.
    * 
    * @param x a date/time or a duration.
    * @return the difference between the two values.
    */
   public Value sub(final Value x)
   {
      if (x instanceof DateTime)
      {
         final DateTime date = (DateTime) (x.convertTo(Value.DATE_ID));
         return new DayTimeDuration(
               (this.getFullTime() - date.getFullTime()) * 1e-3);
      }
      else
      // DayTimeDuration
      {
         final DayTimeDuration dur =
            (DayTimeDuration) (x.convertTo(Value.DAY_TIME_DURATION_ID));
         final double diff = this.getFullTime() - dur.getDayTime() * 1e+3;
         final DateTime date = new DateTime((long) diff);
         date.setFullTime(diff);
         return date;
      }
   }

   /**
    * Compute a multiplication.
    * 
    * @param x another value.
    * @return always null.
    */
   public Value multiply(final Value x)
   {
      return null;
   }

   /**
    * Compute a division (not supported).
    * 
    * @param x another value.
    * @return always null.
    */
   public Value divide(final Value x)
   {
      return null;
   }

   /**
    * Compute a modulus (not supported).
    * 
    * @param x another value.
    * @return always null.
    */
   public Value modulus(final Value x)
   {
      return null;
   }

   // --------------------------------------------------------------------------
   // Comparison interface implementation
   // --------------------------------------------------------------------------

   /**
    * Returns The full precision time
    * 
    * @return the full precision time in milliseconds
    */
   final double getFullTime()
   {
      return 1000 * (this.getTime() / 1000) + 1e-6 * this.getNanos();
   }

   /**
    * Set the full precision time
    * 
    * @param full_time the full precision time in milliseconds
    */
   final void setFullTime(final double full_time)
   {
      final long time = 1000 * ((long) full_time / 1000);
      int nanos = (int) ((full_time - time) * 1000000.);
      if (nanos < 0)
      {
         nanos = -nanos;
      }
      this.setTime(time);
      this.setNanos(nanos);
   }

   /**
    * Compare this value with another value.
    * 
    * @param x another value.
    * @return The returned value is :
    *         <ul>
    *         <li>negative if this value is lower than another value</li>
    *         <li>zero if the two values are equal</li>
    *         <li>positive if this value is greater than another value</li>
    *         </ul>
    */
   public final int compareTo(final Value x)
   {
      final DateTime date = (DateTime) (x.convertTo(Value.DATE_ID));
      return this.dateTime.compareTo(date.dateTime);
   }

   // --------------------------------------------------------------------------
   // ValueFormat interface implementation
   // --------------------------------------------------------------------------
   // see interface ValueFormat for more information.

   /**
    * Return a string containing the value with a fixed format. The
    * representation is assumed as "UTC" time (27 bytes) with format :
    * "DD-MMM-YYYY HH:mm:ss.tttttt".
    * 
    * @param length The expected length of the output string
    * @return The formatted string.
    */
   public java.lang.String getFormattedString(final int length)
   {
      // Wrap to the same operation using pattern
      return this.getFormattedString("dd-MMM-yyyy HH:mm:ss", true);
   }

   /**
    * Return a byte buffer containing the value in a fixed format. 946684800000L
    * is the offset of the MJD origin : 01/01/2000 00:00:00.000000 (MJD origin).<br>
    * The representation is assumed as "mjd" (3 * 4 bytes) :<br>
    * int numDays : nb of days since Jan 1, 2000<br>
    * unsigned int seconds : nb of seconds since the last day<br>
    * unsigned int microseconds : nb of microseconds since the last second<br>
    * 
    * @return The formatted buffer.
    */
   public byte[] getFormattedBuffer()
   {
      long milliseconds; // time representing the date in msec.
      int days; // number of days
      long seconds; // number of seconds
      long microseconds; // number of microseconds
      final byte[] buffer = new byte[12]; // output buffer

      final long currentTime =
      // Get time, shifted to 1st Jan 2002
         milliseconds = (this.getTime() - this.MJD2000_TIME);

      // Get days, if the date is anterior to 1st Jan 2002 remove 1 day
      days = (int) (milliseconds / 86400000L);
      if (milliseconds < 0)
      {
         days--;
      }

      // Get seconds and microseconds
      seconds = (milliseconds - (86400000L * days)) / 1000;
      microseconds = this.getNanos() / 1000L;

      // Set "days" part of the buffer
      buffer[0] = (byte) (days >>> 24);
      buffer[1] = (byte) (days >>> 16);
      buffer[2] = (byte) (days >>> 8);
      buffer[3] = (byte) (days);

      // Set "seconds" part of the buffer
      buffer[4] = (byte) (seconds >>> 24);
      buffer[5] = (byte) (seconds >>> 16);
      buffer[6] = (byte) (seconds >>> 8);
      buffer[7] = (byte) (seconds);

      // Set "microseconds" part of the buffer
      buffer[8] = (byte) (microseconds >>> 24);
      buffer[9] = (byte) (microseconds >>> 16);
      buffer[10] = (byte) (microseconds >>> 8);
      buffer[11] = (byte) (microseconds);

      // return the formatted buffer
      return buffer;
   }

   /**
    * Return the date in a formatted string. The string is formatted with the
    * given pattern (up to seconds) and the microseconds are added at the end if
    * the given flag is true. For instance if the given pattern is "DD-MMM-YYYY
    * HH:mm:ss" the output string will have this format : "DD-MMM-YYYY
    * HH:mm:ss.tttttt".
    * 
    * @param pattern The pattern to use (up to seconds).
    * @param with_microsecond True if microseconds must be added to output
    *           string.
    * @return The formatted string.
    */
   private java.lang.String getFormattedString(final java.lang.String pattern,
         final boolean with_microsecond)
   {
      // Local declaration
      int microseconds; // number of microseconds
      java.lang.String microsecondsStr; // microseconds string
      int microsecondsLen; // microseconds string length
      SimpleDateFormat formatter; // Date formatter
      java.lang.String dateStr; // Output string

      // Create formatter
      formatter = new SimpleDateFormat(pattern, java.util.Locale.ENGLISH);
      formatter.setTimeZone(TimeZone.getTimeZone("GMT"));

      // Create string
      dateStr = formatter.format(this.dateTime);

      // Change month to upper case (not available in formatter)
      dateStr = dateStr.toUpperCase();

      // Case of microseconds to be added
      if (with_microsecond)
      {
         // Create microseconds string
         microseconds = this.getNanos() / 1000;
         microsecondsStr = "" + microseconds;

         // Append possible missing 0
         microsecondsLen = microsecondsStr.length();
         for (int i = 0; i < (6 - microsecondsLen); i++)
         {
            microsecondsStr = "0" + microsecondsStr;
         }

         // Add microseconds at the end
         dateStr = dateStr + "." + microsecondsStr;
      }

      // Return the string
      return dateStr;
   }

   /**
    * Return the date in a string. This operation return a string with the
    * following pattern : "dd-MMM-yyyy HH:mm:ss.tttttt".
    * 
    * @return The formatted string.
    */
   public java.lang.String toString()
   {
      // return getFormattedString("yyyy-MM-dd HH:mm:ss", true);
      return this.getFormattedString(12);
   }

   /**
    * Unitary tests operation.
    * 
    * @param args the string array argument
    */
   public static void main(java.lang.String[] args)
   {
      DateTime date1, date2;
      date1 = new DateTime();
      System.out.println("Default DateTime() = " + date1);
      date1 = new DateTime(946684800000L);
      System.out.println("MJD origin DateTime(946684800000L) = " + date1);
      System.out.println("MJD origin getFormattedString: ["
            + date1.getFormattedString(12) + "]");

      final java.lang.String[] dates =
         new java.lang.String[] { "17-JAN-2005 00:00:00.000000",
               "29-MAR-1999 16:47:19.625468", "29-MAR-1999 16:47:19.876543",
               "29-MAR-1999 16:47:19.004321", "01-JAN-2000 16:47:19.625468",
               "29-JAN-2000 16:47:19.625468", "1970-09-08T21:09:47",
               "1997-01-26T13:30:30", "2005-05-13T17:33:47",
               "2029-09-17T03:28:03", "2008-12-05T15:31:29",
         /*
          * "01-JAN-2002 10:30:50.876543", "01-JUL-1973 15:15:00.000937",
          * "31-DEC-1999 04:00:00.004321", "01-JAN-2000 00:00:00.000000"
          */};

      for (int iDate = 0; iDate < dates.length; iDate++)
      {
         date1 = new DateTime(dates[iDate]);
         System.out.println("========================================");
         System.out.println("DateTime(" + dates[iDate] + ") = " + date1);
         System.out.println("  time  = " + date1.getTime());
         System.out.println("  nanos = " + date1.getNanos());
         System.out.println("  getFormattedString: ["
               + date1.getFormattedString(12) + "]");

         // Check binary format from date2
         final byte[] buftmp = date1.getFormattedBuffer();
         final int[] buffer = new int[3];
         for (int i = 0; i < 3; i++)
         {
            buffer[i] =
               ((buftmp[4 * i] & 0xff) << 24)
                     + ((buftmp[4 * i + 1] & 0xff) << 16)
                     + ((buftmp[4 * i + 2] & 0xff) << 8)
                     + (buftmp[4 * i + 3] & 0xff);
         }
         System.out.println("date mjd = " + buffer[0] + " "
               + (buffer[1] & 0xffffffffL) + " " + (buffer[2] & 0xffffffffL));
         final DateTime date3 = new DateTime(buftmp);
         System.out.println("  new DateTime(buffer mjd) = ["
               + date3.getFormattedString(12) + "]");
         System.out.println(" *time  = " + date3.getTime());
         System.out.println(" *nanos = " + date3.getNanos());
      }

      args = dates;
      if (true)
      {
         return;
      }
      // Check date difference
      if (args.length >= 2)
      {
         System.out.println("");
         System.out
               .println("############# Difference and comparison ######################");
         System.out.println("");
         for (int iDate = 0; iDate < args.length; iDate++)
         {
            System.out.println("========================================");
            System.out.println("args[" + iDate + "] = " + args[iDate]);
            date1 = new DateTime(args[iDate]);
            System.out.println("DateTime(" + args[iDate] + ") = " + date1);
            System.out.println("  time  = " + date1.getTime());
            System.out.println("  micro = " + date1.getNanos() / 1000);
            System.out.println("  full  = "
                  + (long) (date1.getFullTime() * 1e+6));
            System.out.println("  getFormattedString: ["
                  + date1.getFormattedString(12) + "]");
         }
         date1 = new DateTime(args[0]);
         date2 = new DateTime(args[1]);
         System.out.println("-- DIFFERENCE --");
         System.out.println("'" + date1 + "' - '" + date2 + " = "
               + date1.sub(date2));
         System.out.println("dayTime = "
               + ((DayTimeDuration) date1.sub(date2)).getDayTime());
         System.out.println("-- COMPARISON --");
         System.out.println("'" + date1 + "' compareTo '" + date2 + "' = "
               + date1.compareTo(date2));
         System.out.println("'" + date2 + "' compareTo '" + date1 + "' = "
               + date2.compareTo(date1));
         System.out.println("'" + date1 + "' compareTo '" + date1 + "' = "
               + date1.compareTo(date1));
      }
      // System.out.println("should be: 784 76054 543219");
   }
}
