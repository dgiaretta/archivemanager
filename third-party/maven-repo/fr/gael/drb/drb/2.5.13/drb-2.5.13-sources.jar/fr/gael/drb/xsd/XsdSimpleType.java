/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultMutableNode;
import fr.gael.drb.DrbNode;
import fr.gael.drb.value.Value;

/**
 * Declaration of an XML-Schema simple type.
 */
public abstract class XsdSimpleType extends XsdType implements ValueValidator,
      XsdValueSpace
{

   // =================================================
   // Static part.
   // =================================================
   /**
    * simpleType tag.
    */
   final static String TAG = "simpleType";

   /**
    * Union variety
    */
   public final static int UNION_VARIETY = 1;

   /**
    * Atomic variety
    */
   public final static int ATOMIC_VARIETY = 2;

   /**
    * List variety
    */
   public final static int LIST_VARIETY = 3;

   /**
    * All final derivation.
    */
   public final static int ALL_FINAL = 0xffff; // 11111111

   /**
    * Empty final derivation.
    */
   public final static int EMPTY_FINAL = 0x0000; // 00000000

   /**
    * Final property for derivation by restriction.
    */
   public final static int RESTRICTION_FINAL = 0x0001; // 00000001

   /**
    * Final property for derivation by list.
    */
   public final static int LIST_FINAL = 0x0004; // 00000100

   /**
    * Final property for derivation by union.
    */
   public final static int UNION_FINAL = 0x0008; // 00001000

   // ================================================
   // Attributes part.
   // ================================================
   /**
    * final properties.
    */
   protected int finals = EMPTY_FINAL;

   /**
    * facets
    */
   protected XsdFacet[] facets = null;

   /**
    * Build a default type definition
    */
   protected XsdSimpleType()
   {
      this(null, null);
   } // XsdSimpleType

   /**
    * Build a default type definition
    * 
    * @param name String name
    * @param base XsdSimpleType
    */
   protected XsdSimpleType(final String name, final XsdSimpleType base)
   {
      super(name, base);
      this.facets = new XsdFacet[] {};
      this.derivationMethod = RESTRICTION_METHOD;
   } // XsdSimpleType

   // ====================================================
   // Methods part.
   // ====================================================
   /**
    * Returns a set of final properties.
    * 
    * @return int
    */
   public final int getFinals()
   {
      return this.finals;
   }

   /**
    * Returns the variety of this simple type.
    * 
    * @return int
    */
   public abstract int getVariety();

   /**
    * Returns the identifier of this simple type.
    * 
    * @see fr.gael.drb.value.Value
    * @return int
    */
   public int getTypeId()
   {
      return Value.UNKNOWN_ID;
   } // getTypeId

   /**
    * Returns the facets applied to this simple type.
    * 
    * @return XsdFacet[]
    */
   public final XsdFacet[] getFacets()
   {
      return this.facets;
   }

   /**
    * Create a value from a string.
    * 
    * @param text the string representation of the value.
    * @return the text converted to this value type.
    */
   public abstract Value getValue(String text);

   // --------------------------------------------------------
   // XsdComponent class overloading
   // -------------------------------------------------------
   /**
    * Format this component into a string.
    * 
    * @return The node
    */
   DrbNode toNode()
   {
      final DrbNode type_node = new DrbDefaultMutableNode(TAG);
      type_node.setNamespaceURI(Namespace.XML_SCHEMA_NAMESPACE);
      if (this.getName() != null)
      {
         final DrbDefaultAttributeList attributes =
            new DrbDefaultAttributeList();
         attributes.add(new DrbDefaultAttribute(NAME_TAG,
               new fr.gael.drb.value.String(this.getName()), type_node));
         type_node.setAttributes(attributes);
      }
      if (this.getBase() != null)
      {
         // restriction
         final XsdSimpleType base = (XsdSimpleType) this.getBase();
         final DrbNode restriction_node =
            new DrbDefaultMutableNode(RESTRICTION_TAG);
         restriction_node.setNamespaceURI(Namespace.XML_SCHEMA_NAMESPACE);
         final DrbDefaultAttributeList attributes =
            new DrbDefaultAttributeList();

         final XmlSchema base_schema = base.schema;
         if ((base_schema != null) && (base.getName() != null))
         {
            String base_name = base.getName();
            if (base_schema != null)
            {
               String prefix =
                  base_schema.namespaces.resolvePrefix(base
                        .getTargetNamespace());

               if ((prefix == null)
                     && (Namespace.XML_SCHEMA_NAMESPACE.equals(base
                           .getTargetNamespace())))
               {
                  prefix = "xs";
               }

               if (prefix != null)
               {
                  base_name = prefix + ":" + base.getName();
               }
            }
            attributes.add(new DrbDefaultAttribute(DERIVATION_BASE_TAG,
                  new fr.gael.drb.value.String(base_name), restriction_node));
            restriction_node.setAttributes(attributes);
         }
         else
         {
            final DrbNode base_node = base.toNode();
            if (base_node != null)
            {
               restriction_node.appendChild(base_node);
            }
         }

         type_node.appendChild(restriction_node);
         // facets
         for (int i = 0; i < this.getFacets().length; i++)
         {
            final DrbNode facet_node = this.getFacets()[i].toNode();
            if (facet_node != null)
            {
               restriction_node.appendChild(facet_node);
            }
         }
      }

      return type_node;
   } // toNode

   // ----------------------------------------------
   // XsdType class overloading
   // ----------------------------------------------
   /**
    * Check if this type is complex.
    * 
    * @return true or false
    */
   public final boolean isComplex()
   {
      return false;
   }

   /**
    * Returns the content of this type.
    * 
    * @return XsdSimpleType
    */
   public final XsdSimpleType getDatatype()
   {
      return this;
   } // getDatatype

   /**
    * Returns the structure of this type.
    * 
    * @return XsdComplexType
    */
   public final XsdComplexType getStructure()
   {
      return null;
   } // getStructure

   // -------------------------------------------------------
   // ValueValidator interface implementation
   // --------------------------------------------------------
   /**
    * Validates the present value.
    * 
    * @param value the value
    * @return true if this value satifies the type definition, else false
    */
   public boolean isValid(final Value value)
   {
      if (value == null)
      {
         return false;
      }

      final XsdFacet[] facets = this.getFacets();
      if (facets != null)
      {
         for (int i = 0; i < facets.length; i++)
         {
            if (!facets[i].isValid(value))
            {
               return false;
            }
         }
      }
      return true;
   }

   /**
    * Validates the type of the present value.
    * 
    * @param value the value
    * @return true if this value satifies the type definition, else false
    */
   protected boolean isValidType(final Value value)
   {
      if (value == null)
      {
         return false;
      }

      return true;
   }

   /**
    * Validates the present value.
    * 
    * @param value the value
    * @return an error report or null.
    */
   public XsdInvalid validate(final Value value)
   {
      if ((value == null) || !this.isValidType(value))
      {
         return new XsdInvalidSimpleType(null, this, value);
      }

      // Check facets
      final XsdFacet[] facets = this.getFacets();
      if (facets != null)
      {
         for (int i = 0; i < facets.length; i++)
         {
            if (!facets[i].isValid(value))
            {
               return new XsdInvalidFacet(facets[i], value);
            }
         }
      }
      return null;
   }

   // -------------------------------------------------------
   // NodeValidator interface implementation
   // -------------------------------------------------------
   /**
    * Validates this node.
    * 
    * @param node the DrbNode
    * @return XsdInvalid
    */
   public XsdInvalid isValid(final DrbNode node)
   {
      if (node == null)
      {
         return new XsdInvalidType(node, this);
      }
      else
      {
         return this.validate(node.getValue());
      }
   } // isValid

} // XsdSimpleType
