/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds.schema;

import org.apache.log4j.Logger;

import fr.gael.drb.query.Query;
import fr.gael.drb.value.Long;

/**
 * Physical attribute in descriptor. This class is used to manage a physical
 * attribute such as offset, length or occurrence count. It contains the type of
 * value (fixed, constant in parent or variable). Depending of the type the
 * value can be unique or not. If there are several values for the descriptor
 * they are stored in a map.
 */
public class SdfAttribute
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(SdfAttribute.class);

   /**
    * Constant for "value is unknown".
    */
   private static final int UNKNOWN = -1;

   /**
    * Constant for "value is fixed e.g. SINGLE and READ_ONLY".
    */
   public static final int FIXED = 1;

   /**
    * Constant for "value is constant e.g. SINGLE and READ_WRITE".
    */
   public static final int CONSTANT = 2;

   /**
    * Constant for "value is variable e.g. MULTIPLE".
    */
   public static final int VARIABLE = 3;

   /**
    * Constant for "value is readable only".
    */
   public static final int READ_ONLY = 1;

   /**
    * Constant for "value is writable only".
    */
   public static final int WRITE_ONCE = 1;

   /**
    * Constant for "value is mutable".
    */
   public static final int READ_WRITE = 3;

   /**
    * Constant for "single occurrence".
    */
   public static final int SINGLE = 1;

   /**
    * Constant for "multiple occurrences".
    */
   public static final int MULTIPLE = 2;

   /**
    * Constant : Context is "Root".
    */
   static protected final short ROOT = 1;

   /**
    * Constant : Context is "Parent".
    */
   static protected final short PARENT = 2;

   /**
    * Constant : Context is "Self".
    */
   static protected final short SELF = 3;

   /**
    * Query to process in order to solve the dynamic value. This value is used
    * only in case of FIXED physical attribute. In the other cases there are
    * several values stored in the map.
    */
   protected String query;

   /**
    * The query context.
    */
   protected short queryContext = SELF;

   /**
    * Query object to use to process in order to solve the dynamic value.
    */
   protected Query queryObject;

   /**
    * The access type of value. It describes if the value iss fixed or not.
    */
   protected int accessType = UNKNOWN;

   /**
    * The type of value. It describes if the value if fixed (single) or not
    * (multiple).
    */
   protected int occurrenceType = UNKNOWN;

   /**
    * Map of the values. This map is used in case of non FIXED physical
    * attribute.
    */
   protected Long map;

   /**
    * Builds a SdfAttribute instance with UNKNOWN access type.
    */
   protected SdfAttribute()
   {
      // Set default values
      this(READ_WRITE, MULTIPLE);
   }

   /**
    * Builds a SdfAttribute instance with the given access type and MULTIPLE
    * occurs. In case of non fixed value type the map will be created.
    * 
    * @param access_type The access type of the physical attribute value. It
    *           shall be UNKNOWN, READ_ONLY or READ_WRITE.
    */
   protected SdfAttribute(final int access_type)
   {
      // Set the type
      this(access_type, MULTIPLE);
   }

   /**
    * Builds a SdfAttribute instance with the given access and occurs type. In
    * case of non fixed value type the map will be created.
    * 
    * @param access_type The access type of the physical attribute value. It
    *           shall be UNKNOWN, READ_ONLY or READ_WRITE.
    * @param occurs_type The occurrence type of the physical attribute value. It
    *           shall be UNKNOWN, SINGLE or MULTIPLE.
    */
   protected SdfAttribute(final int access_type, final int occurs_type)
   {
      // Set the type
      this.setAccessType(access_type);
      this.setOccurrenceType(occurs_type);
   }

   /**
    * Returns the value type.
    * 
    * @return The type of the physical attribute value. It shall be UNKNOWN,
    *         FIXED, CONSTANT or VARIABLE.
    */
   protected final int getType()
   {
      if (this.occurrenceType == MULTIPLE)
      {
         return VARIABLE;
      }
      if (this.occurrenceType == SINGLE)
      {
         if (this.accessType == READ_WRITE)
         {
            return CONSTANT;
         }
         else
         {
            return FIXED;
         }
      }
      return UNKNOWN;
   }

   /**
    * Returns the acess type.
    * 
    * @return The type of the physical attribute value. It shall be UNKNOWN,
    *         READ_ONLY or READ_WRITE.
    */
   protected final int getAccessType()
   {
      return this.accessType;
   }

   /**
    * Returns the value type.
    * 
    * @return The type of the physical attribute value. It shall be UNKNOWN,
    *         SINGLE or MULTIPLE.
    */
   protected final int getOccurrenceType()
   {
      return this.occurrenceType;
   }

   /**
    * Says wether this value is mutable or not.
    * 
    * @return true if the values are mutable and false otherwise
    */
   protected final boolean isMutable()
   {
      return (this.accessType == READ_WRITE);
   }

   /**
    * Says wether this value is single or not.
    * 
    * @return true if the value is single and false otherwise.
    */
   protected final boolean isSingle()
   {
      return (this.occurrenceType == SINGLE);
   }

   /**
    * Says wether this value has a query or not.
    * 
    * @return true if the value has a query and false otherwise
    */
   protected final boolean hasQuery()
   {
      return (this.query != null);
   }

   /**
    * Sets the value query.
    * 
    * @param query the query definition
    */
   protected final void setQuery(final String query)
   {
      this.queryObject = null;
      this.query = query;
   }

   /**
    * Sets the context of the query.
    * 
    * @param query_context the context type for the query
    */
   protected final void setQueryContext(final short query_context)
   {
      this.queryContext = query_context;
   }

   /**
    * Sya whether this value is dynamic or not.
    * 
    * @param occurrence_type The type of occurrence. It shall be SINGLE or
    *           VARIABLE.
    */
   protected final void setOccurrenceType(final int occurrence_type)
   {
      if (occurrence_type != this.occurrenceType)
      {
         this.occurrenceType = occurrence_type;
         this.map = new Long(0);
      }
   }

   /**
    * Sets the value type. All existing map values will be lost because the map
    * reference is set to null, or a new instance is created for non fixed value
    * type.
    * 
    * @param access_type The access type of the physical attribute value. It
    *           shall be UNKNOWN, READ_ONLY or READ_WRITE.
    */
   protected final void setAccessType(final int access_type)
   {
      // Store the given type
      this.accessType = access_type;
   }

   /**
    * Returns the single value if any.
    * 
    * @return The value of the physical attribute or -1
    */
   protected final long getValue()
   {
      final Object map_value = this.map;
      if (map_value == null)
      {
         return -1;
      }
      else
      {
         return ((Long) map_value).longValue();
      }
   }

   /**
    * Returns the value associated to the key. If the value type is fixed then
    * returns the unique value, else get the value associated to the key from
    * the map .
    * 
    * @param key The key to use if needed to get the value from map.
    * @return The value of the physical attribute or -1
    */
   protected final long getValue(final int[] key)
   {
      // Local variables
      Object mapValue; // the value from the map

      // Case of UNKNOWN value type, returns -1
      if (this.occurrenceType == UNKNOWN)
      {
         return -1;
      }

      // At this step the value has to be read from map because it is not
      // fixed for all blocks.
      if ((mapValue = this.map) == null)
      {
         // Display warning info
         // logger.warn("SdfAttribute.getValue() : " +
         // "No map value for key = " + IntMap.keyToString(keyToUse));
         // Return "no value"
         return -1;
      }

      // Return the value from the map
      return ((Long) mapValue).longValue();
   }

   /**
    * Sets the value according to the current value type. If the value type is
    * unknown the value stays unchanged. If the value type is fixed the value is
    * unique and set directly. If the value type is non fixed the given value is
    * stored in the map using the given key. If the key is null the value is not
    * added to the map.
    * 
    * @param key The key
    * @param value the value
    */
   protected void setValue(final int[] key, final long value)
   {
      // Case of UNKNOWN occurrence type, this is an error
      if (this.occurrenceType == UNKNOWN)
      {
         logger.error("SdfAttribute.setValue() ERROR: "
               + "Value type is unknown => value not updated.");
         return;
      }

      // At this step the value has to be stored into the map because it is not
      // fixed for all blocks.
      // Add the value in the map
      this.map = new Long(value);
   }

   /**
    * Sets the single value. If the occurs type is not SINGLE the value stays
    * unchanged.
    * 
    * @param value the value
    */
   protected void setValue(final long value)
   {
      // Case of UNKNOWN occurrence type, this is an error
      if (this.occurrenceType != SINGLE)
      {
         logger.error("SdfAttribute.setValue() ERROR: "
               + "Value type is invalid => value not updated.");
         return;
      }

      this.map = new Long(value);
   }

   protected final void clear()
   {
      // Check if map is used and wrap to the map operation
      if (this.accessType == READ_WRITE)
      {
         this.map = null;
      }
   }

   /**
    * Prints info into a string.
    * 
    * @return String
    */
   public String toString()
   {
      // Local declarations
      String tmpStr;

      switch (this.accessType)
      {
         case FIXED:
            tmpStr = "access=READ_ONLY";
            break;
         case VARIABLE:
            tmpStr = "access=READ_WRITE";
            break;
         default:
            tmpStr = "access=INVALID";
            break;
      }

      switch (this.occurrenceType)
      {
         case SINGLE:
            tmpStr += " occurs=SINGLE " + this.map;
            break;
         case MULTIPLE:
            tmpStr += " occurs=MULTIPLE " + this.map;
            break;
         default:
            tmpStr += " occurs=INVALID";
            break;
      }
      // Return info string
      return "{" + tmpStr + "}";
   }
} // SdfAttribute
