/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;

/**
 * Declaration of a general XML-Schema component.
 */
abstract class XsdComponent
{

   // ===================================================
   // Attributes part.
   // ===================================================
   /**
    * Annotation of this component.
    */
   private XsdAnnotation annotation = null;

   /**
    * External nodes of this component.
    */
   private DrbNodeList externalNodes = null;

   /**
    * External attributes of this component.
    */
   private DrbAttributeList externalAttributes = null;

   /**
    * The target namespace of this type.
    */
   protected String targetNamespace = null;

   // ==============================================
   // Methods part.
   // ==============================================
   /**
    * Returns annotation of this component.
    * 
    * @return The annotation of this component
    */
   public final XsdAnnotation getAnnotation()
   {
      if (this.annotation == null)
      {
         this.annotation = new XsdAnnotation(null, null);
      }
      return this.annotation;
   } // getAnnotation

   /**
    * Set annotation of this component.
    * 
    * @param annotation The annotation of this component
    */
   public final void setAnnotation(final XsdAnnotation annotation)
   {
      this.annotation = annotation;
   } // setAnnotation

   /**
    * Returns the external nodes of this component.
    * 
    * @return The list of the node
    */
   public final DrbNodeList getExternalNodes()
   {
      return this.externalNodes;
   } // getExternalNodes

   /**
    * Set the external nodes of this component.
    * 
    * @param external_nodes The list of the node
    */
   public final void setExternalNodes(final DrbNodeList external_nodes)
   {
      this.externalNodes = external_nodes;
   } // setExternalNodes

   /**
    * Returns the external attributes of this component.
    * 
    * @return The list of attributes
    */
   public final DrbAttributeList getExternalAttributes()
   {
      return this.externalAttributes;
   } // getExternalAttributes

   /**
    * Set the external attributes of this component.
    * 
    * @param external_attributes The list of the attributes
    */
   public final void setExternalAttributes(
         final DrbAttributeList external_attributes)
   {
      this.externalAttributes = external_attributes;
   } // setExternalAttributes

   /**
    * Returns the target namespace of this type.
    * 
    * @return the target namespace of this type.
    */
   public final String getTargetNamespace()
   {
      return this.targetNamespace;
   } // getTargetNamespace

   /**
    * Set the target namespace of this type.
    * 
    * @param target_namespace the target namespace of this type.
    */
   public final void setTargetNamespace(final String target_namespace)
   {
      this.targetNamespace = target_namespace;
   } // setTargetNamespace

   /**
    * Format this component into a node.
    * 
    * @return the node
    */
   DrbNode toNode()
   {
      return null;
   }
} // XsdComponent
