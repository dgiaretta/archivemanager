/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import java.util.EventListener;

/**
 * Common interface of block listeners. All the block listener dedicated to
 * report block changes must adopt this common interface. It is composed of a
 * single operation that is called at each change of result status. Generally
 * this interface is implemented as an inner class that is passed to a result
 * producer.
 */
interface BlockListener extends EventListener
{
   /**
    * Invoked when the block has been inserted.
    * 
    * @param e Contains all necessary values for the processing of the block
    *           changes.
    */
   void blockInserted(BlockEvent e);

   /**
    * Invoked when the block has been removed.
    * 
    * @param e Contains all necessary values for the processing of the block
    *           changes.
    */
   void blockRemoved(BlockEvent e);

   /**
    * Invoked when the block has been replaced.
    * 
    * @param e Contains all necessary values for the processing of the block
    *           changes.
    */
   void blockReplaced(BlockEvent e);

   /**
    * Invoked when the block has been moved.
    * 
    * @param e Contains all necessary values for the processing of the block
    *           changes.
    */
   void blockMoved(BlockEvent e);

   /**
    * Invoked when the block's size changes.
    * 
    * @param e Contains all necessary values for the processing of the result
    *           changes.
    */
   void blockResized(BlockEvent e);
}
