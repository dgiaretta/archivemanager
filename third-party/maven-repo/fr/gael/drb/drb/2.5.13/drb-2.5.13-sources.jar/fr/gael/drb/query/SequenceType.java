/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.value.Value;
import fr.gael.drb.value.ValueArray;
import fr.gael.drb.xsd.XmlSchema;
import fr.gael.drb.xsd.XsdSimpleType;
import fr.gael.drb.xsd.XsdType;

/**
 * Static type of a sequence. When it is necessary to refer to a type in an
 * XQuery expression, the SequenceType syntax is used. The name SequenceType
 * suggests that this syntax is used to describe the type of an XQuery value,
 * which is always a sequence. Note: in the current implementation, only atomic
 * types are supported.
 */
class SequenceType
{
   /**
    * Logger
    */
   private Logger logger = Logger.getLogger(SequenceType.class);

   /**
    * "One" occurrence indicator. This correspond to the default value of a
    * type.
    */
   public final static int ONE_OCCURRENCE = 0;

   /**
    * "Zero or one" occurrence indicator. This correspond to the "?" in most of
    * the grammar syntaxes.
    */
   public final static int ZERO_OR_ONE_OCCURRENCE = 1;

   /**
    * "Zero or more" occurrence indicator. This correspond to the "*" in most of
    * the grammar syntaxes.
    */
   public final static int ZERO_OR_MORE_OCCURRENCE = 2;

   /**
    * "One or more" occurrence indicator. This correspond to the "+" in most of
    * the grammar syntaxes.
    */
   public final static int ONE_OR_MORE_OCCURRENCE = 3;

   /**
    * The schema type name
    */
   private QName typeName;

   /**
    * The fr.gael.drb.Value corresponding type id.
    */
   private int valueTypeId = Value.UNKNOWN_ID;

   /**
    * Occurrence indicator.
    */
   private int occurrenceIndicator = ONE_OCCURRENCE;

   /**
    * Builds a default SequenceType based with a wildcard type.
    */
   public SequenceType()
   {
      this(DrbItem.UNDEFINED_ITEM, Value.UNKNOWN_ID, ZERO_OR_MORE_OCCURRENCE);
   }

   /**
    * Builds a SequenceType based on the abbreviated string form. The type name
    * follows the syntax: Name OccurrenceIndicator?
    * 
    * @param type_name the string form of the sequence type.
    */
   public SequenceType(String type_name)
   {
      this(type_name.replace("[?+*]", ""), getOccurrenceIndicator(type_name));
   }

   /**
    * Builds a SequenceType based on the item kind and an occurrence indicator.
    * The item kind is provided as an integer corresponding to the static
    * integer attributes in the DrbItem interface (e.g. NODE_ITEM). The
    * occurrence indicator is provided as an integer corresponding to the static
    * integer attributes of the present class (e.g. ONE_OCCURRENCE).
    * 
    * @param item_kind the item kind as an integer.
    * @param value_type the value type as an integer.
    * @param occurrence the occurrence indicator as an integer.
    */
   public SequenceType(final int item_kind, final int value_type,
         final int occurrence)
   {
      this.valueTypeId = value_type;
      this.typeName = new QName("xs:anyType");
      this.occurrenceIndicator = occurrence;
   }

   /**
    * Builds a SequenceType based on the qualified type name. The type is
    * provided in the string form of a qualified name. The occurrence is
    * considered "one".
    * 
    * @param schema_type the schema type name.
    */
   public SequenceType(final QName schema_type)
   {
      this(schema_type, ONE_OCCURRENCE);
   }

   /**
    * Builds a SequenceType based on the qualified type name and an occurrence
    * indicator. The type is provided in the string form of a qualified name.
    * The occurrence indicator is provided as an integer corresponding to the
    * static integer attributes of the present class (e.g. ONE_OCCURRENCE).
    * 
    * @param type_name the string form of the qualified type name.
    * @param occurrence the occurrence indicator as an integer.
    */
   public SequenceType(final String type_name, final int occurrence)
   {
      this(new QName(type_name), occurrence);
   }

   /**
    * Builds a SequenceType based on the qualified type name and an occurrence
    * indicator. The occurrence indicator is provided as an integer
    * corresponding to the static integer attributes of the present class (e.g.
    * ONE_OCCURRENCE).
    * 
    * @param type_name the qualified type name.
    * @param occurrence the occurrence indicator as an integer.
    */
   public SequenceType(final QName type_name, final int occurrence)
   {
      this.typeName = type_name;
      this.occurrenceIndicator = occurrence;
      if (type_name.getName().equals("item()"))
      {
         this.valueTypeId = Value.UNKNOWN_ID;
      }
      else if (type_name.getName().equals("node()"))
      {
         this.valueTypeId = Value.UNKNOWN_ID;
      }
      else
      {
         XsdType schema_type = getSchemaType(type_name);
         if (schema_type == null)
         {
            this.logger.error("The schema type " + type_name
                  + " is not declared.");
            this.valueTypeId = Value.UNKNOWN_ID;
         }
         else
         {
            this.valueTypeId = getValueTypeId(schema_type);
         }
      }
   }

   /**
    * Returns the occurrence indicator of the sequence type. The occurrence
    * indicator is provided as an integer corresponding to the static integer
    * attributes of the present class (e.g. ONE_OCCURRENCE).
    * 
    * @param type_name the string form of the sequence type
    * @return the occurrence indicator of the type.
    */
   static int getOccurrenceIndicator(final String type_name)
   {
      if (type_name.endsWith("?"))
      {
         return SequenceType.ZERO_OR_ONE_OCCURRENCE;
      }
      else if (type_name.endsWith("+"))
      {
         return SequenceType.ONE_OR_MORE_OCCURRENCE;
      }
      else if (type_name.endsWith("*"))
      {
         return SequenceType.ZERO_OR_MORE_OCCURRENCE;
      }
      else
      {
         return SequenceType.ONE_OCCURRENCE;
      }
   }

   /**
    * Returns the schema type from a qualified name.
    * 
    * @param type_name the qualified name of the schema type
    */
   static XsdType getSchemaType(final QName type_name)
   {
      return XmlSchema.getDefaultSchema().getType(type_name.getName());
   }

   /**
    * Returns the primitive id of the schema type.
    * 
    * @param schema_type the schema type
    */
   static int getValueTypeId(final XsdType schema_type)
   {
      if (schema_type != null)
      {
         final XsdSimpleType simple_type = schema_type.getDatatype();
         if (simple_type != null)
         {
            return simple_type.getTypeId();
         }
      }

      return Value.UNKNOWN_ID;
   } // getValueTypeId

   /**
    * Returns the primitive id of the schema type.
    * 
    * @param type_name the qualified name of the schema type
    */
   static int getValueTypeId(final QName type_name)
   {
      return getValueTypeId(getSchemaType(type_name));
   } // getValueTypeId

   /**
    * Returns the string form of the qualified type name.
    * 
    * @return the name of the type.
    */
   public String getName()
   {
      return this.typeName.getName();
   }

   /**
    * Returns the occurrence indicator of the type. The occurrence indicator is
    * provided as an integer corresponding to the static integer attributes of
    * the present class (e.g. ONE_OCCURRENCE).
    * 
    * @return the name of the type.
    */
   public int getOccurrenceIndicator()
   {
      return this.occurrenceIndicator;
   }

   /**
    * Check a sequence against current occurrence indicator.
    * 
    * @param sequence the sequence to be assessed.
    * @return true if the sequence respects the occurrence indicator and false
    *         otherwise.
    */
   public boolean matchesOccurrencesOf(final DrbSequence sequence)
   {
      boolean occurrence_matches = true;

      if ((this.occurrenceIndicator == SequenceType.ONE_OCCURRENCE)
            && (sequence.getLength() != 1))
      {
         occurrence_matches = false;
      }
      else if ((this.occurrenceIndicator == SequenceType.ONE_OR_MORE_OCCURRENCE)
            && (sequence.getLength() < 1))
      {
         occurrence_matches = false;
      }
      else if ((this.occurrenceIndicator == SequenceType.ZERO_OR_MORE_OCCURRENCE)
            && (sequence.getLength() < 0))
      {
         occurrence_matches = false;
      }
      else if ((this.occurrenceIndicator == SequenceType.ZERO_OR_ONE_OCCURRENCE)
            && ((sequence.getLength() < 0) || (sequence.getLength() > 1)))
      {
         occurrence_matches = false;
      }

      return occurrence_matches;
   }

   /**
    * Converts a given sequence to the current sequence type. In case of atomic
    * type, the value is converted according to the fr.gael.drb.value package.
    * If the current sequence type matches another type (eg. element, etc.) the
    * item is output unchanged.
    * 
    * @param sequence the sequence to be converted.
    * @return the converted sequence (may be the input one if no conversion was
    *         necessary).
    * @throws TypeCastException if the number of items in the input sequence
    *            does not match the occurrence indicator of the current sequence
    *            type.
    */
   public DrbSequence convert(final DrbSequence sequence)
      throws TypeCastException
   {
      // Checks that the number of items in the input sequence matches the
      // occurrence indicator of the current sequence type.
      if (!this.matchesOccurrencesOf(sequence))
      {
         throw new TypeCastException("Sequence of " + sequence.getLength()
               + " occurrence(s) does not match the "
               + "sequence type occurrence indicator \"" + this + "\".");
      }

      // If the current sequence type differs from an atomic type
      // no conversion is to be performed. The input sequence is returned
      // unchanged.
      if (this.valueTypeId == Value.UNKNOWN_ID)
      {
         return sequence;
      }

      // Loop on input sequence items for checking types and convert them,
      // should their type differ from the current sequence type.
      ValueArray array = sequence.atomize();
      DrbDefaultSequence output_sequence = null;
      for (int iitem = 0; iitem < array.getLength(); iitem++)
      {
         Value value = array.getElement(iitem);

         // Case of different type
         if (value.getType() != this.valueTypeId)
         {
            try
            {
               value = value.convertTo(this.valueTypeId);
            }
            catch (ClassCastException e)
            {
               throw new TypeCastException(e.getMessage());
            }

            if (output_sequence == null)
            {
               output_sequence = new DrbDefaultSequence();

               for (int jitem = 0; jitem < iitem; jitem++)
               {
                  output_sequence.add(sequence.getItem(jitem).getValue());
               }
            }

            output_sequence.add(value);
         }
      }

      if (output_sequence != null)
      {
         return output_sequence;
      }

      return array;
   }

   /**
    * Return the type as a string. The output string is the concatenation of the
    * string form of the qualified type name with the occurrence indicator "+",
    * "?" or "*", as in the following example.
    * 
    * <pre>
    * xs:integer?
    * </pre>
    * 
    * @return the sequence type as a string.
    */
   @Override
   public String toString()
   {
      if (this.occurrenceIndicator == ONE_OR_MORE_OCCURRENCE)
      {
         return this.typeName.getName() + "+";
      }
      else if (this.occurrenceIndicator == ZERO_OR_MORE_OCCURRENCE)
      {
         return this.typeName.getName() + "*";
      }
      else if (this.occurrenceIndicator == ZERO_OR_ONE_OCCURRENCE)
      {
         return this.typeName.getName() + "?";
      }

      return this.typeName.getName();
   }
}
