/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.meta;

import java.util.HashMap;

import fr.gael.drb.value.Value;

/**
 * Generic metadata interface.
 */
public class DrbDefaultMetadata implements DrbMetadata
{
   /**
    * Human description of the pointed ressource.
    */
   private String description;

   /**
    * The media type of the pointed ressource.
    */
   private String mediaType;

   /**
    * The typename of the pointed ressource.
    */
   private String typename;

   /**
    * The property map.
    */
   private HashMap propertyMap;

   /**
    * Build a metadata with the specified description.
    * 
    * @param description the String
    * @param mediatype the String
    */
   public DrbDefaultMetadata(final String description, final String mediatype)
   {
      this.description = description;
      this.mediaType = mediatype;
      this.propertyMap = new HashMap();
   }

   /**
    * Human description of the pointed ressource.
    * 
    * @return String the description
    */
   public String getDescription()
   {
      return this.description;
   }

   /**
    * Get the media type of the pointed ressource. The media type is usually
    * expressed as a MIME identifier containing two parts.
    * 
    * @return The media type or null if unspecified.
    */
   public String getMediaType()
   {
      return this.mediaType;
   }

   /**
    * Get the typename of the pointed ressource.
    * 
    * @return The type name or null if unspecified.
    */
   public String getTypename()
   {
      return this.typename;
   }

   /**
    * Get the value of a named property. The value is expressed according to one
    * of the types supported by the fr.gael.drb.value package. Generally these
    * types correspond to primitive types (e.g. integer, floating points, etc.)
    * or very low level types (e.g. string, date, etc.). On the contrary to DOM
    * implementation all the types are allowed even the arrays, date etc. Only
    * the Value.NULL_ID type is forbidden.
    * 
    * @param name the name of the string
    * @return The value of the property.
    */
   public Value getProperty(final String name)
   {
      return (Value) this.propertyMap.get(name);
   }

   /**
    * Set the value of a named property.
    * 
    * @param name the name string
    * @param value The value
    * @return The previous value of the property.
    */
   public Value setProperty(final String name, final Value value)
   {
      return (Value) this.propertyMap.put(name, value);
   }
} // DrbDefaultMetadata
