/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.io.ByteArrayOutputStream;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbDefaultMutableNode;
import fr.gael.drb.DrbNode;
import fr.gael.drb.impl.xml.XmlFactory;
import fr.gael.drb.xsd.Namespace;

/**
 * Simple mutable node implementation. This class is a simple means to build a
 * DrbNode. It extends the DrbMutableNode interface instead of the DrbNode
 * because it natively requires to be modifiable. This also enables to reduce
 * the signature of the constructors are delay the settings to further calls.
 * This class accepts attributes as well as value and namespace identifier. The
 * class is also a node change producer so its possible to monitor the changed
 * performed on each instance.
 * <p>
 * <b>Important note:</b> The ConstructorNode has no physical representation.
 * Its children and attributes are therefore not stored in a physical media that
 * may imply an important memory footprint.
 * </p>
 */
class ConstructorNode extends DrbDefaultMutableNode
{

   /**
    * Declared namespaces.
    */
   private Namespace declaredNamespaces = new Namespace();

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(ConstructorNode.class);

   /**
    * Builds a new instance of ConstructorNode. In order to reduce the
    * constructor signature only the name of the node is passed to this
    * operation. this name shall never be null. The reference to the name is not
    * duplicated. The name string shall never be modified without using the
    * current class accessors.
    * 
    * @param name A reference to the name of the node to be instancied.
    */
   public ConstructorNode(final String name)
   {
      super(name);

   }

   /**
    * Builds a new instance of ConstructorNode with a specified parent. This
    * constructor enables to build a new instance specifying more parameters.
    * Because in many cases it is not possible to create a node specifying both
    * the previous and the next sibling, their corresponding parameters may be
    * null references. The reference to the parent as well as to the parent may
    * be references to any node implementations (e.g. XmlNodes).
    * 
    * @param name A reference to the name of the node to be instancied.
    * @param parent A reference to the parent of the node to be instanciated.
    * @param index The index of the node in is parent children list.
    * @param previous_sibling A reference to the previous_sibling or null.
    * @param next_sibling A reference to the next_sibling or null.
    */
   public ConstructorNode(final String name, final DrbNode parent,
         final int index, final DrbNode previous_sibling,
         final DrbNode next_sibling)
   {
      super(name, parent, index, previous_sibling, next_sibling);
   }

   /**
    * Get the namespace bindings.
    * 
    * @return The namespace bindings.
    */
   public Namespace getNamespaceBindings()
   {
      return this.declaredNamespaces;
   }

   /**
    * Set the namespace bindings.
    * 
    * @param bindings The namespace bindings.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested namespace change
    *            for any reason (e.g. by definition or in the specific case).
    */
   public void setNamespaceBindings(Namespace bindings)
         throws UnsupportedOperationException
   {
      if (bindings != null)
      {
         this.declaredNamespaces = bindings.cloneNamespace();
      }
      else
      {
         bindings = null;
      }

   }

   /**
    * Checks if child any child exists. Returns wheter the current node has at
    * least a child. This check is performed on the list set previously (if
    * any). The list reference as well as the effective number of children are
    * checked.
    * 
    * @return true if this node has any children, false otherwise.
    */
   public boolean hasChild()
   {
      if ((this.children != null) && (this.children.getLength() > 0))
      {
         return true;
      }
      else
      {
         return false;
      }
   }

   /**
    * Returns an occurence of the node matching the specified name.
    * 
    * @param name The string name of the node
    * @param occurence The occurence of the node
    * @return DrbNode The child node
    */
   public DrbNode getNamedChild(final String name, final int occurence)
   {
      /**
       * Checks parameters.
       */
      if ((name == null) || (occurence <= 0))
      {
         logger.error("ConstructorNode.getNamedChild(): "
               + "Invalid parameter (name=\"" + name + "\", occurence="
               + occurence);
         return null;
      }

      /**
       * Return immediately if the current has no child.
       */
      if (this.children == null)
      {
         return null;
      }

      /**
       * Search the matching node.
       */
      int currentOccurence = 0;

      for (int inode = 0; inode < this.children.size(); inode++)
      {
         final DrbNode child = this.children.item(inode);

         if (child == null)
         {
            logger.warn("Child #" + (inode + 1) + " is null "
                  + "(index starts from 1).");
            continue;
         }

         final String currentName = child.getName();

         if ((currentName != null) && (currentName.equals(name)))
         {
            currentOccurence = currentOccurence + 1;
         }

         if (currentOccurence == occurence)
         {
            return child;
         }
      }

      /**
       * Child not found.
       */
      return null;
   }

   /**
    * Reference to the first child of the current node. The reference to the
    * first child is retreived from the children list previously set.
    * 
    * @return A reference to the first child or null if no such node.
    */
   public DrbNode getFirstChild()
   {
      if (this.children != null)
      {
         return this.children.item(0);
      }
      else
      {
         return null;
      }
   }

   /**
    * Reference to the last child of the current node. The reference to the last
    * child is retreived from the children list previously set.
    * 
    * @return A reference to the last child or null if no such node.
    */
   public DrbNode getLastChild()
   {
      if (this.children != null)
      {
         return this.children.item(this.children.getLength() - 1);
      }
      else
      {
         return null;
      }
   }

   /**
    * Reference to a specific child. The child is extracted from the children
    * list previously set.
    * 
    * @param index The position of the node to retreive starting from 0 and not
    *           greater or equal to the number of children.
    * @return A reference to specified child or null if no such node.
    */
   public DrbNode getChildAt(final int index)
   {
      if (this.children != null)
      {
         return this.children.item(index);
      }
      else
      {
         return null;
      }
   }

   /**
    * Number of children. The number of children is retreived from the children
    * list previously set If the children list has not already been set, 0 is
    * returned.
    * 
    * @return The number of children of the current node.
    */
   public int getChildrenCount()
   {
      if (this.children != null)
      {
         return this.children.getLength();
      }
      else
      {
         return 0;
      }
   }

   /**
    * Returns the node as a string. This operation only prints the node name.
    * 
    * @return The string descibing the current node.
    */
   public String toString()
   {
      final ByteArrayOutputStream stream = new ByteArrayOutputStream();

      XmlFactory.writeXML(this, stream);

      return stream.toString();
   }
}// ConstructorNode
