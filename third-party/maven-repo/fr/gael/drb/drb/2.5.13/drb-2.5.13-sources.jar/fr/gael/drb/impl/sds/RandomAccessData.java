/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.log4j.Logger;

import fr.gael.drb.value.Numeric;
import fr.gael.drb.value.Value;

/**
 * Random Access Data.
 */
abstract class RandomAccessData implements DataInput, DataOutput
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(RandomAccessData.class);

   /**
    * Closes this random access file stream and releases any system resources
    * associated with the stream.
    * 
    * @throws java.io.IOException This exception is raised, If the buffer's
    *            current position is not smaller than its limit
    */
   abstract void close() throws java.io.IOException;

   /**
    * Returns the number of bytes that can be read (or skipped over) from this
    * input stream without blocking by the next caller of a method for this
    * input stream. The next caller might be the same thread or another thread.
    * The available method for class InputStream always returns 0. This method
    * should be overridden by subclasses.
    * 
    * @throws java.io.IOException if an I/O error occurs.
    * @return the number of byte that can be read without blocking.
    */
   public long available() throws java.io.IOException
   {
      return 0;
   }

   /**
    * Sets the data-pointer offset, measured from the beginning of this data, at
    * which the next read or write occurs.
    * 
    * @param pos The new position value; must be non-negative and no larger than
    *           the current limit
    * @throws java.io.IOException This exception is raised, If the buffer's
    *            current position is not smaller than its limit
    */
   abstract void seek(long pos) throws java.io.IOException;

   /**
    * Sets the data-pointer offset, measured from the beginning of this data, at
    * which the next read or write occurs.
    * 
    * @param pos The new position value; must be non-negative and no larger than
    *           the current limit
    * @throws java.io.IOException This exception is raised, If the buffer's
    *            current position is not smaller than its limit
    */
   final void seek(final Length pos) throws java.io.IOException
   {
      this.seek(pos.getLength(), pos.getBitLength());
   }

   /**
    * Sets the data-pointer offset, measured from the beginning of this data, at
    * which the next read or write occurs.
    * 
    * @param pos The new position value; must be non-negative and no larger than
    *           the current limit
    * @param bit_pos The new position value; must be non-negative and no larger
    *           than the current limit
    * @throws java.io.IOException This exception is raised, If the buffer's
    *            current position is not smaller than its limit
    */
   void seek(final long pos, final int bit_pos) throws java.io.IOException
   {
      this.seek(pos);
   }

   /**
    * Returns the length of this data.
    * 
    * @return long The buffer capacity
    * @throws java.io.IOException This exception is raised, If the buffer's
    *            current position is not smaller than its limit
    */
   abstract long length() throws java.io.IOException;

   /**
    * Set the length of this data.
    * 
    * @param len Lenght of this data
    * @return long The buffer capacity
    * @throws java.io.IOException This exception is raised, If the buffer's
    *            current position is not smaller than its limit
    */
   void setLength(final long len) throws java.io.IOException
   {
      throw new java.io.IOException("RandomAccessData.setLength not supported");
   }

   /**
    * Insert into the output stream all the bytes in array b.
    * 
    * @param b The byte[] to write
    * @throws IOException if an I/O error occurs.
    */
   void insert(final byte[] b) throws java.io.IOException
   {
      throw new java.io.IOException("Insert not supported");
   }

   /**
    * Clear a file segment.
    * 
    * @param src_offset The source offset.
    * @param dst_offset The destination offset.
    * @param val The clear value.
    * @throws java.io.IOException
    */
   protected void clear(final Length src_offset, final Length dst_offset,
         final byte val) throws java.io.IOException
   {
      /**
       * Constant : Maximum block size for file segment copy. Set to 10240 bytes
       * (10 KB).
       */
      int MAX_BUFFER_SIZE = 10240;

      // TBC : File copy at bit level.
      final long curSrcOffset = src_offset.getLength();
      long curLen = dst_offset.getLength() - src_offset.getLength();

      if (curLen < MAX_BUFFER_SIZE)
      {
         MAX_BUFFER_SIZE = (int) curLen;
      }

      final byte[] buffer = new byte[MAX_BUFFER_SIZE];
      // Allocate limited read buffer for huge segment
      java.util.Arrays.fill(buffer, val);

      this.seek(curSrcOffset);
      while (curLen > 0)
      {
         if (curLen >= MAX_BUFFER_SIZE)
         {
            this.write(buffer, 0, MAX_BUFFER_SIZE);
         }
         else
         {
            this.write(buffer, 0, (int) curLen);
         }
         curLen = curLen - MAX_BUFFER_SIZE;
      }
   }

   /**
    * Move a file segment.
    * 
    * @param src_offset The source offset.
    * @param dst_offset The destination offset.
    * @param length The number of bytes to copy.
    * @return The length of the bytes read.
    */
   protected long move(final Length src_offset, final Length dst_offset)
         throws java.io.IOException
   {
      /**
       * Constant : Maximum block size for file segment copy. Set to 10240 bytes
       * (10 KB).
       */
      final int MAX_BUFFER_SIZE = 10240;

      // TBC : File copy at bit level.
      long curSrcOffset = src_offset.getLength();
      long cur_dst_offset = dst_offset.getLength();
      // long curLen = Math.abs(cur_dst_offset - curSrcOffset);
      long curLen = this.length() - curSrcOffset;
      final long fileLen = this.length() + cur_dst_offset - curSrcOffset;

      // Allocate limited read buffer for huge segment
      final byte[] buffer = new byte[MAX_BUFFER_SIZE];

      if (curSrcOffset < cur_dst_offset)
      {
         curSrcOffset = curSrcOffset + curLen;
         cur_dst_offset = cur_dst_offset + curLen;
         while (curLen > 0)
         {
            if (curLen >= MAX_BUFFER_SIZE)
            {
               curSrcOffset = curSrcOffset - MAX_BUFFER_SIZE;
               cur_dst_offset = cur_dst_offset - MAX_BUFFER_SIZE;
               curLen = curLen - MAX_BUFFER_SIZE;
               this.seek(curSrcOffset);
               this.readFully(buffer, 0, MAX_BUFFER_SIZE);
               this.seek(cur_dst_offset);
               this.write(buffer, 0, MAX_BUFFER_SIZE);
            }
            else
            {
               curSrcOffset = curSrcOffset - curLen;
               cur_dst_offset = cur_dst_offset - curLen;
               this.seek(curSrcOffset);
               this.readFully(buffer, 0, (int) curLen);
               this.seek(cur_dst_offset);
               this.write(buffer, 0, (int) curLen);
               curLen = 0;
            }
         }
      }
      else
      {
         while (curLen > 0)
         {
            if (curLen >= MAX_BUFFER_SIZE)
            {
               this.seek(curSrcOffset);
               this.readFully(buffer, 0, MAX_BUFFER_SIZE);
               this.seek(cur_dst_offset);
               this.write(buffer, 0, MAX_BUFFER_SIZE);
               curSrcOffset = curSrcOffset + MAX_BUFFER_SIZE;
               cur_dst_offset = cur_dst_offset + MAX_BUFFER_SIZE;
               curLen = curLen - MAX_BUFFER_SIZE;
            }
            else
            {
               this.seek(curSrcOffset);
               this.readFully(buffer, 0, (int) curLen);
               this.seek(cur_dst_offset);
               this.write(buffer, 0, (int) curLen);
               curLen = 0;
            }
         }
         this.setLength(fileLen);
      }

      return curLen;
   } // move

   /**
    * Reads len bytes from an input stream.
    * 
    * @param b The array into which bytes are to be read
    * @param off The offset within the array of the first byte to be read; must
    *           be non-negative and no larger than <tt>b.len</tt>
    * @param len The number of bits to be read from the given array; must be
    *           non-negative and no larger than <tt>array.length - offset</tt>
    * @throws IOException if an I/O error occurs.
    */
   public void readFully(final byte[] b, final int off, final Length len)
         throws java.io.IOException
   {
      this.readFully(b, off, (int) len.getLength());
   }

   /**
    * Writes len bits from array b, in order, to the output stream.
    * 
    * @param b The array from which bytes are to be read
    * @param off The offset within the array of the first byte to be read; must
    *           be non-negative and no larger than <tt>array.length</tt>
    * @param len The number of bits to be read from the given array; must be
    *           non-negative and no larger than <tt>array.length - offset</tt>
    * @throws IOException if an I/O error occurs.
    */
   public void write(final byte[] b, final int off, final Length len)
         throws java.io.IOException
   {
      final int byteLen = (int) len.getLength();
      final int bitLen = len.getBitLength();
      if (bitLen == 0)
      {
         this.write(b, off, byteLen);
      }
      else
      {
         throw new java.io.IOException("writeBits");
      }
   }

   /**
    * Writes to the output stream the the len low-order bits of the argument v.
    * 
    * @param v The int to write
    * @param bit_len The number of bit to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeBits(final int v, final int bit_len)
         throws java.io.IOException
   {
      if (bit_len == 8)
      {
         this.writeByte(v);
      }
      else if (bit_len == 16)
      {
         this.writeShort(v);
      }
      else if (bit_len == 32)
      {
         this.writeInt(v);
      }
   }

   /**
    * Reads an integer
    * 
    * @param len the length of the integer value
    * @param is_signed
    * @return The integer value at the buffer's current position
    * @throws IOException if an I/O error occurs.
    */
   public java.math.BigInteger readInteger(final Length len,
         final boolean is_signed) throws java.io.IOException
   {
      final int byteLen = (int) len.getLength();
      final int bitLen = len.getBitLength();
      final byte[] buffer = new byte[byteLen + (bitLen + 7) / 8];
      this.readFully(buffer, 0, len);
      if (bitLen > 0)
      {
         final int compBitLen = 8 - bitLen;
         for (int i = byteLen; i > 0; i--)
         {
            buffer[i] =
               (byte) (((buffer[i] & 0xff) >>> compBitLen) | ((buffer[i - 1] & 0xff) << bitLen));
         }
         buffer[0] = (byte) ((buffer[0] & 0xff) >>> compBitLen);
         if (is_signed)
         {
            buffer[0] = (byte) ((buffer[0] & 0xff) | (0xff << bitLen));
         }
      }
      return new java.math.BigInteger(buffer);
   }

   /**
    * Write an integer
    * 
    * @param num a numeric value
    * @param len the length of the integer value
    * @param is_signed
    * @throws IOException if an I/O error occurs.
    */
   public void writeInteger(final Numeric num, final Length len,
         final boolean is_signed) throws java.io.IOException
   {
      final int byteLen = (int) len.getLength();
      final int bitLen = len.getBitLength();
      final byte[] intBuf =
         ((fr.gael.drb.value.Integer) ((Value) num).convertTo(Value.INTEGER_ID))
               .integerValue().toByteArray();

      final byte[] buffer = new byte[byteLen + (7 + bitLen) / 8];
      final int intOff = buffer.length - intBuf.length;

      byte pad = 0;

      if (is_signed && ((intBuf[0] & 0x80) != 0))
      {
         pad = (byte) 0xff;
      }

      if (bitLen > 0)
      {
         final int compBitLen = 8 - bitLen;
         for (int i = 0; i < buffer.length; i++)
         {
            if (i < intOff - 1)
            {
               buffer[i] = pad;
            }
            else if (i < intOff)
            {
               buffer[i] = (byte) ((intBuf[i + 1 - intOff] & 0xff) >>> bitLen);
            }
            else if (i + 1 - intOff == intBuf.length)
            {
               buffer[i] = (byte) ((intBuf[i - intOff] & 0xff) << compBitLen);
            }
            else
            {
               buffer[i] =
                  (byte) (((intBuf[i - intOff] & 0xff) << compBitLen) | ((intBuf[i
                        + 1 - intOff] & 0xff) >>> bitLen));
            }
         }
      }
      else
      {
         for (int i = 0; i < buffer.length; i++)
         {
            if (i >= intOff)
            {
               buffer[i] = intBuf[i - intOff];
            }
            else
            {
               buffer[i] = pad;
            }
         }
      }
      this.write(buffer, 0, len);
   }

   /**
    * Writes a float value, which is comprised of four bytes (LSB), to the
    * output stream.
    * 
    * @param v The float to write
    * @throws IOException if an I/O error occurs.
    */
   public final void writeFloatLSB(final float v) throws java.io.IOException
   {
      this.writeIntLSB(Float.floatToRawIntBits(v));
   }

   /**
    * Writes an int value, which is comprised of four bytes (LSB), to the output
    * stream.
    * 
    * @param v The int to write
    * @throws IOException if an I/O error occurs.
    */
   public final void writeIntLSB(int v) throws java.io.IOException
   {
      v =
         (((v & 0xff000000) >>> 24) | ((v & 0x00ff0000) >>> 8)
               | ((v & 0x0000ff00) << 8) | ((v & 0x000000ff) << 24));
      this.writeInt(v);
   }

   /**
    * Writes a long value, which is comprised of eight bytes, to the output
    * stream.
    * 
    * @param long_value The long to write
    * @throws IOException if an I/O error occurs.
    */
   public final void writeLongLSB(long long_value) throws java.io.IOException
   {
      long_value =
         (((long_value & 0xFF00000000000000L) >>> 56)
               | ((long_value & 0x00FF000000000000L) >>> 40)
               | ((long_value & 0x0000FF0000000000L) >>> 24)
               | ((long_value & 0x000000FF00000000L) >>> 8)
               | ((long_value & 0x00000000FF000000L) << 8)
               | ((long_value & 0x0000000000FF0000L) << 24)
               | ((long_value & 0x000000000000FF00L) << 40) | ((long_value & 0x00000000000000FFL) << 56));
      this.writeLong(long_value);
   }

   /**
    * Writes a double value, which is comprised of eight bytes, to the output
    * stream.
    * 
    * @param v The double to write
    * @throws IOException if an I/O error occurs.
    */
   public void writeDoubleLSB(final double v) throws java.io.IOException
   {
      this.writeLongLSB(Double.doubleToRawLongBits(v));
   }
} // RandomAccessData
