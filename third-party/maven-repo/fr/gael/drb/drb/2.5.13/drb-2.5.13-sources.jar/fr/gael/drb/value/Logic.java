/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * Generic logical operator.
 */
public interface Logic extends Comparison
{
   /**
    * Compute a logical AND.
    * 
    * @param x another value.
    * @return logical AND of the two values.
    */
   boolean and(Value x);

   /**
    * Compute a logical OR.
    * 
    * @param x another value.
    * @return logical OR of the two values.
    */
   boolean or(Value x);

   /**
    * Convert into a boolean value.
    * 
    * @return the equivalent boolean value.
    */
   boolean booleanValue();
}
