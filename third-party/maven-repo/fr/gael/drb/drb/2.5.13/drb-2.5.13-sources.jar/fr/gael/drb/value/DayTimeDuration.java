/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * The DayTimeDuration class is a generic wrapper for day/time duration.
 */
public class DayTimeDuration extends AbstractValue implements Arithmetic,
      Comparison
{
   // ===========================================================================
   // Attributes part.
   // ===========================================================================
   /**
    * The DayTimeDuration priority.
    */
   final static int PRIORITY = 7;

   /**
    * Definition of the number of seconds in one minute.
    */
   final static int SECONDS_PER_MINUTE = 60;

   /**
    * Definition of the number of seconds in one hour.
    */
   final static int SECONDS_PER_HOUR = 3600;

   /**
    * Definition of the number of seconds in one day.
    */
   final static int SECONDS_PER_DAY = 86400;

   /**
    * The day-time part of this duration (in second).
    */
   protected double dayTime;

   // ===========================================================================
   // Methods part.
   // ===========================================================================

   /**
    * Attempts to interpret the string s as a representation of an ISO duration.
    * The pattern is currently PnnDnnHnnMnn.ttttttS or - PnnDnnHnnMnn.ttttttS if
    * the duration is negative.
    * 
    * @param a string to be parsed as a day/time duration.
    */
   public DayTimeDuration(java.lang.String s)
   {
      // Call constructor of the superclass
      final boolean have_sign = s.startsWith("-");
      if (have_sign)
      {
         s = s.substring(1); // remove '-'
      }
      if ((s.length() < 3) || !s.startsWith("P"))
      {
         return;
      }

      s = s.substring(1); // remove 'P'
      final long years = 0;
      final long months = 0;
      long days = 0;
      long hours = 0;
      long minutes = 0;
      double seconds = 0.0;

      // Read duration
      int index = -1;
      // Days
      if ((index = s.indexOf('D')) > 0)
      {
         days = java.lang.Long.parseLong(s.substring(0, index));
         s = s.substring(index + 1, s.length());
      }
      // Time separators
      if (s.startsWith("T"))
      {
         s = s.substring(1);
      }
      // Hours
      if ((index = s.indexOf('H')) > 0)
      {
         hours = java.lang.Long.parseLong(s.substring(0, index));
         s = s.substring(index + 1, s.length());
      }
      // Minutes
      if ((index = s.indexOf('M')) > 0)
      {
         minutes = java.lang.Long.parseLong(s.substring(0, index));
         s = s.substring(index + 1, s.length());
      }
      // Seconds
      if ((index = s.indexOf('S')) > 0)
      {
         seconds = java.lang.Double.parseDouble(s.substring(0, index));
         s = s.substring(index + 1, s.length());
      }
      double day_time =
         days * SECONDS_PER_DAY + hours * SECONDS_PER_HOUR + minutes
               * SECONDS_PER_MINUTE + seconds;
      if (have_sign)
      {
         day_time = -day_time;
      }
      this.dayTime = day_time;
   }

   /**
    * Build a duration from a number of month and a time.
    * 
    * @param day_time number of second in this duration
    * @see java.util.Date
    */
   public DayTimeDuration(final double day_time)
   {
      this.dayTime = day_time;
   }

   /**
    * Returns the day/time part of this duration in seconds.
    * 
    * @return the day/time part of this duration in seconds.
    */
   public double getDayTime()
   {
      return this.dayTime;
   }

   /**
    * Returns the days part of this duration.
    * 
    * @return the days part of this duration.
    */
   long getDays()
   {
      return (long) (Math.abs(this.dayTime) / SECONDS_PER_DAY);
   }

   /**
    * Returns the hours part of this duration.
    * 
    * @return the hours part of this duration.
    */
   int getHours()
   {
      return (int) (Math.abs(this.dayTime) - SECONDS_PER_DAY * this.getDays())
            / SECONDS_PER_HOUR;
   }

   /**
    * Returns the minutes part of this duration.
    * 
    * @return the minutes part of this duration.
    */
   int getMinutes()
   {
      final double minutes =
         Math.abs(this.dayTime) - SECONDS_PER_HOUR * this.getHours()
               - SECONDS_PER_DAY * this.getDays();
      return (int) (minutes / SECONDS_PER_MINUTE);
   }

   /**
    * Returns the seconds of this duration.
    * 
    * @return the seconds of this duration.
    */
   double getSeconds()
   {
      final double seconds =
         Math.abs(this.dayTime) - SECONDS_PER_MINUTE * this.getMinutes()
               - SECONDS_PER_HOUR * this.getHours() - SECONDS_PER_DAY
               * this.getDays();
      return seconds;
   }

   /**
    * Return the duration in a string.
    * 
    * @return The formatted string.
    */
   public java.lang.String toString()
   {
      final int hours = this.getHours();
      final int minutes = this.getMinutes();
      final double seconds = this.getSeconds();
      java.lang.String str = "P" + this.getDays() + "D";
      if (this.dayTime < 0.0)
      {
         str = "-" + str;
      }
      if ((hours == 0) && (minutes == 0) && (seconds == 0.0))
      {
         return str;
      }
      else
      {
         return str + "T" + this.getHours() + "H" + this.getMinutes() + "M"
               + this.getSeconds() + "S";
      }
   }

   // --------------------------------------------------------------------------
   // Value interface implementation
   // ---------------------------------------------------------------------------
   /**
    * The type identifier of the value.
    * 
    * @return an identifier of the value type.
    */
   public int getType()
   {
      return Value.DAY_TIME_DURATION_ID;
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself should be returned. If the conversion is not allowed a
    * ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws java.lang.ClassCastException if the conversion is impossible.
    */
   public Value convertTo(final int type) throws java.lang.ClassCastException
   {
      switch (type)
      {
         // DayTimeDuration -> DayTimeDuration conversion
         case Value.DAY_TIME_DURATION_ID:
            return this;

            // DayTimeDuration -> Duration conversion
         case Value.DURATION_ID:
            return new Duration(0, this.dayTime);

            // DayTimeDuration -> YearMonthDuration conversion
         case Value.YEAR_MONTH_DURATION_ID:
            return new YearMonthDuration(
                  (long) (this.dayTime / Duration.SECONDS_PER_MONTH));

            // DayTimeDuration -> String conversion
         case Value.STRING_ID:
            return new String(this.toString());

            // DayTimeDuration -> Unknown conversion
         default:
            return new Double(this.getDayTime()).convertTo(type);
      }
   } // convertTo

   /**
    * Assign a new Value. An implicit conversion may be performed to make the
    * assignment.
    * 
    * @param v the value to be assigned.
    */
   public void assign(final Value v)
   {
      final DayTimeDuration vd =
         (DayTimeDuration) v.convertTo(Value.DAY_TIME_DURATION_ID);
      this.dayTime = vd.getDayTime();
   }

   /**
    * The absolute priority of the value.
    * 
    * @return The value priority.
    */
   public int getPriority()
   {
      return PRIORITY;
   }

   // ---------------------------------------------------------------------------
   // Sumable interface implementation
   // ---------------------------------------------------------------------------
   /**
    * Compute an addition.
    * 
    * @param x another value.
    * @return the sum of the two values.
    */
   public Value add(final Value x)
   {
      if (x instanceof DateTime)
      {
         return ((DateTime) x).add(this);
      }
      else
      {
         final DayTimeDuration vd =
            (DayTimeDuration) (x.convertTo(Value.DAY_TIME_DURATION_ID));
         return new DayTimeDuration(this.getDayTime() + vd.getDayTime());
      }
   }

   // --------------------------------------------------------------------------
   // Arithmetic interface implementation
   // ---------------------------------------------------------------------------
   /**
    * Compute an unary minus.
    * 
    * @return The unary minus of this duration.
    */
   public Value unaryMinus()
   {
      return new DayTimeDuration(-this.getDayTime());
   } // unaryMinus

   /**
    * Compute a substraction.
    * 
    * @param x another value.
    * @return the difference between the two duration.
    */
   public Value sub(final Value x)
   {
      final DayTimeDuration vd =
         (DayTimeDuration) (x.convertTo(Value.DAY_TIME_DURATION_ID));
      return new DayTimeDuration(this.getDayTime() - vd.getDayTime());
   } // sub

   /**
    * Compute a multiplication.
    * 
    * @param x another value.
    * @return the product of this duration by a number.
    */
   public Value multiply(final Value x)
   {
      final Numeric num = (Numeric) (x.convertTo(NUMERIC_ID));
      return new DayTimeDuration(this.getDayTime() * num.doubleValue());
   } // multiply

   /**
    * Compute a division.
    * 
    * @param x another value.
    * @return the ratio of this duration by a number.
    */
   public Value divide(final Value x)
   {
      final Numeric num = (Numeric) (x.convertTo(NUMERIC_ID));
      return new DayTimeDuration(this.getDayTime() / num.doubleValue());
   } // divide

   /**
    * Compute a modulus.
    * 
    * @param x another value.
    * @return the modulus of this duration by a number.
    */
   public Value modulus(final Value x)
   {
      final Numeric num = (Numeric) (x.convertTo(NUMERIC_ID));
      return new DayTimeDuration(this.getDayTime() % num.doubleValue());
   } // modulus

   // --------------------------------------------------------------------------
   // Comparison interface implementation
   // --------------------------------------------------------------------------
   /**
    * Compare this value with another value.
    * 
    * @param v another value.
    * @return The returned value is :
    *         <ul>
    *         <li> negative if this value is lower than another value
    *         <li> zero if the two values are equal
    *         <li> positive if this value is greater than another value
    *         </ul>
    */
   public int compareTo(final Value v)
   {
      final DayTimeDuration vd =
         (DayTimeDuration) (v.convertTo(Value.DAY_TIME_DURATION_ID));
      final double diff = this.getDayTime() - vd.getDayTime();
      if (diff < 0.0)
      {
         return -1;
      }
      else if (diff > 0.0)
      {
         return +1;
      }
      else
      {
         return 0;
      }
   } // compareTo

   // ==========================================================================
   // Unitary test part.
   // ==========================================================================
   /**
    * Makes this class runnable for testing.
    * 
    * @param args the given arguments in the command line.
    */
   public static void main(final java.lang.String[] args)
   {
      final fr.gael.drb.value.DayTimeDuration dur =
         new fr.gael.drb.value.DayTimeDuration(java.lang.Double
               .parseDouble(args[0]));
      System.out.println("Test :  convert a dayTimeDuration(" + args[0] + ")");
      System.out.println("toString : " + dur.convertTo(Value.STRING_ID));
      System.out.println("toDouble : " + dur.convertTo(Value.DOUBLE_ID));
      System.out.println("toLong : " + dur.convertTo(Value.LONG_ID));

      if (args.length > 1)
      {
         System.out.println("-- CMP --");
         final fr.gael.drb.value.DayTimeDuration dur2 =
            new fr.gael.drb.value.DayTimeDuration(java.lang.Double
                  .parseDouble(args[1]));
         System.out.println("'" + dur + "' compareTo '" + dur2 + " = "
               + dur.compareTo(dur2));
      }
      final java.lang.String[] dates =
         new java.lang.String[] { "01-JAN-2000 00:00:00.000000",
               "31-DEC-1999 04:00:00.004321", "01-JUL-1973 15:15:00.000937",
               "01-JAN-2002 10:30:50.876543" };

      System.out.println("-- SUM --");
      DateTime date_time1 = null, date_time2 = null;
      for (int iDate = 0; iDate < dates.length; iDate++)
      {
         date_time1 = new DateTime(dates[iDate]);
         date_time2 = (DateTime) date_time1.add(dur).convertTo(Value.DATE_ID);
         System.out.println("'" + date_time1 + "' full="
               + (long) (date_time1.getFullTime() * 1e+9) + " time="
               + date_time1.getTime() + " nanos=" + date_time1.getNanos());
         System.out.println("'" + date_time1 + "' + '" + dur + " = "
               + date_time1.add(dur).convertTo(Value.DATE_ID));
         System.out.println("'" + date_time2 + "' full="
               + (long) (date_time2.getFullTime() * 1e+9) + " time="
               + date_time2.getTime() + " nanos=" + date_time2.getNanos());
      }
      System.out.println("-- DIF --");
      for (int iDate = 0; iDate < dates.length; iDate++)
      {
         System.out.println("'" + date_time1 + "' - '" + dur + " = "
               + date_time1.sub(dur).convertTo(Value.DATE_ID));
      }
   } // main

}
