/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * The DateTime class is a generic wrapper for Date values. WARNING : In this
 * implementation, a year is fixed to 365.25 sideral days.
 */
public class Duration extends DayTimeDuration
{
   // ==========================================================================
   // Attributes part.
   // ==========================================================================
   /**
    * The Duration priority.
    */
   final static int PRIORITY = 7;

   /**
    * Definition of the number of days in one year (sideral time).
    */
   final static double DAYS_PER_YEAR = 365.25;

   /**
    * Definition of the number of seconds in one month (sideral time).
    */
   final static long SECONDS_PER_MONTH = 2629800;

   /**
    * The year/month part of this duration (in months).
    */
   protected long yearMonth;

   // ==========================================================================
   // Methods part.
   // ==========================================================================

   /**
    * Attempts to interpret the string s as a representation of an ISO 8601
    * duration. The pattern is [-]PnYnMTnHnMnS where the number of seconds can
    * be fractionnal.
    * 
    * @param s string to be parsed as a duration.
    * @return the interpreted Duration.
    * @see java.util.Date
    */
   public static Duration parseDuration(java.lang.String s)
   {
      if ((s == null) || (s.length() < 2))
      {
         return null;
      }
      // Call constructor of the superclass
      final boolean haveSign = s.startsWith("-");
      if (haveSign)
      {
         s = s.substring(1); // remove '-'
      }
      if ((s.length() < 3) || !s.startsWith("P"))
      {
         return null;
      }

      s = s.substring(1); // remove 'P'
      long years = 0;
      long months = 0;
      long days = 0;
      long hours = 0;
      long minutes = 0;
      double seconds = 0.0;

      // Read duration
      int index = -1;
      // Years
      if ((index = s.indexOf('Y')) > 0)
      {
         years = java.lang.Long.parseLong(s.substring(0, index));
         s = s.substring(index + 1, s.length());
      }
      // Month
      if (((index = s.indexOf('M')) > 0)
            && ((s.indexOf('T') < 0) || (index < s.indexOf('T'))))
      {
         months = java.lang.Long.parseLong(s.substring(0, index));
         s = s.substring(index + 1, s.length());
      }
      // Days
      if ((index = s.indexOf('D')) > 0)
      {
         days = java.lang.Long.parseLong(s.substring(0, index));
         s = s.substring(index + 1, s.length());
      }
      // Time separators
      if (s.startsWith("T"))
      {
         s = s.substring(1);
      }
      // Hours
      if ((index = s.indexOf('H')) > 0)
      {
         hours = java.lang.Long.parseLong(s.substring(0, index));
         s = s.substring(index + 1, s.length());
      }
      // Minutes
      if ((index = s.indexOf('M')) > 0)
      {
         minutes = java.lang.Long.parseLong(s.substring(0, index));
         s = s.substring(index + 1, s.length());
      }
      // Seconds
      if ((index = s.indexOf('S')) > 0)
      {
         seconds = java.lang.Double.parseDouble(s.substring(0, index));
         s = s.substring(index + 1, s.length());
      }
      if (s.length() != 0)
      {
         return null;
      }
      // Build a new duration
      long year_month = years * 12 + months;
      double day_time =
         days * SECONDS_PER_DAY + hours * SECONDS_PER_HOUR + minutes
               * SECONDS_PER_MINUTE + seconds;
      if (haveSign)
      {
         year_month = -year_month;
         day_time = -day_time;
      }
      return new Duration(year_month, day_time);
   }

   /**
    * Build a duration from a number of month and a time. The year and month
    * part of this duration is given separely from the day and time. We advised
    * not to mix months and days in order to avoid inconsistencies while
    * computing arithmetic operations. Thus, when the number of month is
    * specified, the leading number of seconds should be zero.
    * 
    * @param year_month number of month in this duration
    * @param day_time number of second in this duration
    * @see java.util.Date
    */
   public Duration(final long year_month, final double day_time)
   {
      super(day_time);
      this.setDuration(year_month, day_time);
   }

   /**
    * Replace this duration with the new specified values.
    * 
    * @param year_month the new number of month in this duration.
    * @param day_time the new number of second in this duration.
    */
   void setDuration(long year_month, double day_time)
   {
      if ((day_time < 0.0) && (year_month > 0))
      {
         final long carry_month =
            1 + (long) (Math.abs(day_time) / this.SECONDS_PER_MONTH);
         year_month = year_month - carry_month;
         day_time += carry_month * this.SECONDS_PER_MONTH;
      }
      else if ((day_time > 0.0) && (year_month < 0))
      {
         final long carry_month =
            1 + (long) (Math.abs(day_time) / this.SECONDS_PER_MONTH);
         year_month = year_month + carry_month;
         day_time -= carry_month * this.SECONDS_PER_MONTH;
      }

      if (Math.abs(day_time) >= this.SECONDS_PER_MONTH)
      {
         if (day_time < 0.0)
         {
            year_month += (long) (day_time / this.SECONDS_PER_MONTH);
            day_time = -Math.abs(day_time) % this.SECONDS_PER_MONTH;
         }
         else
         {
            year_month += (long) (day_time / this.SECONDS_PER_MONTH);
            day_time = day_time % this.SECONDS_PER_MONTH;
         }
      }
      this.dayTime = day_time;
      this.yearMonth = year_month;
   }

   /**
    * Returns the year/month part of this duration in months.
    * 
    * @return the year/month part of this duration in months.
    */
   long getYearMonth()
   {
      return this.yearMonth;
   }

   /**
    * Returns the number of years in this duration.
    * 
    * @return the number of years in this duration.
    */
   long getYears()
   {
      return (Math.abs(this.yearMonth) / 12);
   }

   /**
    * Returns the number of months in this duration.
    * 
    * @return the number of months in this duration.
    */
   int getMonths()
   {
      return (int) (Math.abs(this.yearMonth) % 12);
   }

   /**
    * Return the duration in a string.
    * 
    * @return The formatted string.
    */
   public java.lang.String toString()
   {
      final long years = this.getYears();
      final int months = this.getMonths();
      final int hours = this.getHours();
      final int minutes = this.getMinutes();
      final double seconds = this.getSeconds();
      java.lang.String str =
         "P" + this.getYears() + "Y" + this.getMonths() + "M" + this.getDays()
               + "D";
      if ((this.dayTime < 0.0) || (this.yearMonth < 0))
      {
         str = "-" + str;
      }
      if ((hours == 0) && (minutes == 0) && (seconds == 0.0))
      {
         return str;
      }
      else
      {
         return str + "T" + this.getHours() + "H" + this.getMinutes() + "M"
               + this.getSeconds() + "S";
      }
   }

   // ---------------------------------------------------------------------------
   // Value interface implementation
   // ---------------------------------------------------------------------------
   /**
    * The type identifier of the value.
    * 
    * @return an identifier of the value type.
    */
   public int getType()
   {
      return Value.DURATION_ID;
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself should be returned. If the conversion is not allowed a
    * ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws java.lang.ClassCastException if the conversion is impossible.
    */
   public Value convertTo(final int type) throws java.lang.ClassCastException
   {
      switch (type)
      {
         // Duration -> Duration conversion
         case Value.DURATION_ID:
            return this;

            // Duration -> DayTimeDuration conversion
         case Value.DAY_TIME_DURATION_ID:
            return new DayTimeDuration(this.dayTime + this.yearMonth
                  * this.SECONDS_PER_MONTH);

            // Duration -> YearMonthDuration conversion
         case Value.YEAR_MONTH_DURATION_ID:
            return new YearMonthDuration(this.yearMonth);

            // Duration -> String conversion
         case Value.STRING_ID:
            return new String(this.toString());

            // Duration-> Numeric conversion (in seconds)
         default:
            return new Double(this.dayTime + this.yearMonth
                  * this.SECONDS_PER_MONTH).convertTo(type);
      }
   } // convertTo

   /**
    * Assign a new Value. An implicit conversion may be performed to make the
    * assignment.
    * 
    * @param v the value to be assigned.
    */
   public void assign(final Value v)
   {
      final Duration vd = (Duration) v.convertTo(Value.DURATION_ID);
      this.yearMonth = vd.getYearMonth();
      this.dayTime = vd.getDayTime();
   }

   /**
    * The absolute priority of the value.
    * 
    * @return The value priority.
    */
   public int getPriority()
   {
      return PRIORITY;
   }

   // --------------------------------------------------------------------------
   // Summable interface implementation
   // ---------------------------------------------------------------------------
   /**
    * Compute an addition.
    * 
    * @param x another value.
    * @return the sum of the two values.
    */
   public Value add(final Value x)
   {
      final Duration vd = (Duration) (x.convertTo(Value.DURATION_ID));
      return new Duration(this.getYearMonth() + vd.getYearMonth(), this
            .getDayTime()
            + vd.getDayTime());
   }

   // --------------------------------------------------------------------------
   // Arithmetic interface implementation
   // --------------------------------------------------------------------------
   /**
    * Compute an unary minus.
    * 
    * @return The unary minus of the value.
    */
   public Value unaryMinus()
   {
      return new Duration(-this.getYearMonth(), -this.getDayTime());
   }

   /**
    * Compute a substraction.
    * 
    * @param x another value.
    * @return the difference between the two values.
    */
   public Value sub(final Value x)
   {
      final Duration vd = (Duration) (x.convertTo(Value.DURATION_ID));
      return new Duration(this.getYearMonth() - vd.getYearMonth(), this
            .getDayTime()
            - vd.getDayTime());
   }

   /**
    * Compute a multiplication.
    * 
    * @param x another value.
    * @return the product of the two values.
    */
   public Value multiply(final Value x)
   {
      final Numeric num = (Numeric) (x.convertTo(NUMERIC_ID));
      final double year_month = this.yearMonth * num.doubleValue();
      double day_time = this.dayTime * num.doubleValue();
      day_time += year_month - (long) year_month;
      return new Duration((long) year_month, day_time);
   }

   /**
    * Compute a division.
    * 
    * @param x another value.
    * @return the ratio of the two values.
    */
   public Value divide(final Value x)
   {
      final Numeric num = (Numeric) (x.convertTo(NUMERIC_ID));
      final double year_month = this.yearMonth / num.doubleValue();
      double day_time = this.dayTime / num.doubleValue();
      day_time += year_month - (long) year_month;
      return new Duration((long) year_month, day_time);
   }

   /**
    * Compute a modulus.
    * 
    * @param x another value.
    * @return the modulus of the values.
    */
   public Value modulus(final Value x)
   {
      return null;
   }

   // ---------------------------------------------------------------------------
   // Comparison interface implementation
   // ---------------------------------------------------------------------------
   /**
    * Compare this value with another value.
    * 
    * @param v another value.
    * @return The returned value is :
    *         <ul>
    *         <li> negative if this value is lower than another value
    *         <li> zero if the two values are equal
    *         <li> positive if this value is greater than another value
    *         </ul>
    */
   public int compareTo(final Value v)
   {
      final Duration vd = (Duration) (v.convertTo(Value.DURATION_ID));
      // Year/Month comparison
      double diff = this.getYearMonth() - vd.getYearMonth();
      if (diff < 0.0)
      {
         return -1;
      }
      else if (diff > 0.0)
      {
         return +1;
      }

      // Day/Time comparison
      diff = this.getDayTime() - vd.getDayTime();
      if (diff < 0.0)
      {
         return -1;
      }
      else if (diff > 0.0)
      {
         return +1;
      }
      else
      {
         return 0;
      }
   } // compareTo

   // ==========================================================================
   // Unitary test part.
   // ==========================================================================
   /**
    * Makes this class runnable for testing.
    * 
    * @param args the given arguments in command line.
    */
   public static void main(final java.lang.String[] args)
   {
      final fr.gael.drb.value.Duration dur =
         new fr.gael.drb.value.Duration(java.lang.Long.parseLong(args[0]),
               java.lang.Double.parseDouble(args[1]));
      System.out.println("Test :  convert a Duration(" + args[0] + ","
            + args[1] + ")");
      System.out.println("toString : " + dur.convertTo(Value.STRING_ID));
      System.out.println("toDouble : " + dur.convertTo(Value.DOUBLE_ID));
      System.out.println("toLong : " + dur.convertTo(Value.LONG_ID));

      if (args.length > 3)
      {
         System.out.println("-- CMP --");
         final fr.gael.drb.value.Duration dur2 =
            new fr.gael.drb.value.Duration(java.lang.Long.parseLong(args[2]),
                  java.lang.Double.parseDouble(args[3]));
         System.out.println("'" + dur + "' compareTo '" + dur2 + " = "
               + dur.compareTo(dur2));
      }

      final java.lang.String[] dates =
         new java.lang.String[] { "01-JAN-2000 00:00:00.000000",
               "31-DEC-1999 04:00:00.004321", "01-JUL-1973 15:15:00.000937",
               "01-JAN-2002 10:30:50.876543" };

      System.out.println("-- SUM --");
      DateTime date_time1 = null;
      for (int iDate = 0; iDate < dates.length; iDate++)
      {
         date_time1 = new DateTime(dates[iDate]);
         System.out.println("'" + date_time1 + "' + '" + dur + " = "
               + date_time1.add(dur).convertTo(Value.DATE_ID));
      }
      System.out.println("-- DIF --");
      for (int iDate = 0; iDate < dates.length; iDate++)
      {
         date_time1 = new DateTime(dates[iDate]);
         System.out.println("'" + date_time1 + "' - '" + dur + " = "
               + date_time1.sub(dur).convertTo(Value.DATE_ID));
      }
   } // main

} // Duration
