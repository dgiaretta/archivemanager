/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * Abstract value class. This class represents an atomic value or list of
 * values. The datatypes are derived from the XML-Schema recommendation.
 */
abstract class AbstractValue implements Value, java.io.Serializable
{
   /**
    * A code that identifies the value items.
    * 
    * @return The code of value items.
    */
   public int getItemType()
   {
      return VALUE_ITEM;
   }

   /**
    * Name of the item. This method always returns null.
    * 
    * @return null
    */
   public java.lang.String getName()
   {
      return null;
   }

   /**
    * Changes the name of the item. This method always throw an
    * UnsupportedOperationException.
    * 
    * @param name Reference to the new name.
    * @throws UnsupportedOperationException This exception always raised because
    *            the name property is not defined for values.
    * @throws NullPointerException This exception is overriden by an
    *            UnsupportedOperationException.
    */
   public void rename(final java.lang.String name) throws NullPointerException,
         UnsupportedOperationException
   {
      throw new UnsupportedOperationException("Cannot rename a value");
   }

   /**
    * Get namespace URI. This method always returns null.
    * 
    * @return null.
    */
   public java.lang.String getNamespaceURI()
   {
      return null;
   }

   /**
    * Sets a namespace resource identifier. This method always throw an
    * UnsupportedOperationException.
    * 
    * @param namespace_uri A reference to the new namespace identifier.
    * @throws UnsupportedOperationException This exception always raised because
    *            the name property is not defined for values.
    * @throws NullPointerException This exception is overriden by an
    *            UnsupportedOperationException.
    */
   public void setNamespaceURI(final java.lang.String namespace_uri)
         throws NullPointerException, UnsupportedOperationException
   {
      throw new UnsupportedOperationException("Cannot rename a value");
   }

   /**
    * The value of the item. The value is expressed according to one of the
    * types supported by the fr.gael.drb.value package. Generally these types
    * correspond to primitive types (e.g. integer, floatting points, etc.) or
    * very low level types (e.g. string, date, etc.). On the contrary to DOM
    * implementation all the types are allowed even the arrays, date etc. Only
    * the Value.NULL_ID type is forbidden.
    * 
    * @return The value of the attribute.
    */
   public Value getValue()
   {
      return this;
   }

   /**
    * Changes the value of the item. This operation sets a new value of the
    * current item.The value type of the item shall be compatible with the item
    * implementation. If the type does not match exactly it is casted to a
    * compatible one based on the the fr.gael.drb.value capabilities. A
    * reference to the effectivelly assigned value is returned by the operation
    * so it is possible to check if a cast has been performed and therefore
    * assess the accuracy of the assignement. If the cast is not possible the
    * operation raises an UnsupportedOperationException. If the assignment is
    * possible and the item implementation has a physical representation the
    * value is updated in the physical source in order to persist among
    * sessions. It therefore possible that this operation consumses an variable
    * time.
    * 
    * @param value The new value of the node. This value shall not be null.
    * @return The effectivelly assigned value. The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested assignment for
    *            any reason.
    */
   public Value setValue(final Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      this.assign(value);
      return this;
   }

   /**
    * The type identifier of the value.
    * 
    * @return an identifier of the value type.
    */
   public int getType()
   {
      return UNKNOWN_ID;
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself should be returned. If the conversion is not allowed a
    * ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws java.lang.ClassCastException is the convertion is impossible
    */
   public Value convertTo(final int type) throws java.lang.ClassCastException
   {
      throw new ClassCastException(this.getClass().getName()
            + ": cannot cast to " + type);
   }

   /**
    * Convert the value into the numeric type. In case of identity conversion
    * the value itself should be returned. If the conversion is not allowed a
    * ClassCastException is thrown.
    * 
    * @return The converted value.
    * @throws java.lang.ClassCastException is the convertion is impossible
    */
   public Numeric toNumeric() throws java.lang.ClassCastException
   {
      return (Numeric) this;
   }
} // AbstractValue
