/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

/**
 * Dynamic error of an XQuery dynamic evalutation phase. A dynamic error is an
 * error that must be detected during the evaluation phase and may be detected
 * during the analysis phase. Numeric overflow is an example of a dynamic error.
 */
public class DynamicException extends RuntimeException
{
   /**
    * Keeps the expression associated to the error. The expression will provide
    * information regarding the location of the error in the input source.
    */
   private Expression expression;

   /**
    * Builds a dynamic exception with a contextual message.
    * 
    * @param expression the expression associated to the error.
    * @param message the contextual message that should fit <error> in the
    *           sentence "<error> at line l, column c.". It shall therefore, be
    *           a single line message whith no trailing sign or symbol (e.g. no
    *           trailing point, comma or question mark).
    */
   protected DynamicException(final Expression expression, final String message)
   {
      super(message);

      this.expression = expression;
   }
   
   protected DynamicException(final Expression expression, final String message, Exception e)
   {
      super(message, e);

      this.expression = expression;
   }

   /**
    * Returns the line number where the dynamic error has stared.
    * 
    * @return line the error started.
    */
   public int getBeginLine()
   {
      if ((this.expression != null) && (this.expression.getToken() != null))
      {
         return this.expression.getToken().beginLine;
      }
      return -1;
   }

   /**
    * Returns the line number where the dynamic error has ended.
    * 
    * @return line the error ended.
    */
   public int getEndLine()
   {
      if ((this.expression != null) && (this.expression.getToken() != null))
      {
         return this.expression.getToken().endLine;
      }
      return -1;
   }

   /**
    * Returns the column number where the dynamic error has started.
    * 
    * @return column the error started.
    */
   public int getBeginColumn()
   {
      if ((this.expression != null) && (this.expression.getToken() != null))
      {
         return this.expression.getToken().beginColumn;
      }
      return -1;
   }

   /**
    * Returns the column number where the dynamic error has ended.
    * 
    * @return line the error ended.
    */
   public int getEndColumn()
   {
      if ((this.expression != null) && (this.expression.getToken() != null))
      {
         return this.expression.getToken().endColumn;
      }
      return -1;
   }

   /**
    * Returns the exception message. An example of output message would be:
    * 
    * <pre>
    * Dynamic error in FLWOR expression at line 1, column 26.
    * The $a variable has already been declared.
    * </pre>
    * 
    * It is a committment that the output message ends with a trailing ".".
    * 
    * @return the exception message.
    */
   public String getMessage()
   {
      if (this.expression != null)
      {
         return super.getMessage() + " at line " + this.getBeginLine()
               + ", column " + this.getBeginColumn() + ".";
      }
      else
      {
         return super.getMessage() + ".";
      }
   }
}
