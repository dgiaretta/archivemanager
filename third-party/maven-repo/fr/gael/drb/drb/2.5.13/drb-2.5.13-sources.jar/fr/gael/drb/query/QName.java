/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

/**
 * Qualified name. The qualified names are couples of a local name of an element
 * and a prefix identifying the associated namespace. The complemedefinition of
 * qualified names is provided by the W3C in its recommendation that may
 * downloaded at <a
 * href="http://www.w3.org/TR/xml-names11">http://www.w3.org/TR/xml-names11
 * </a>.
 */
class QName
{
   /**
    * Local name. The local name is the unprefixed par of the qualified name
    * (e.g. "node" of the qualified name "local:node".
    */
   private String localName;

   /**
    * Prefix. Prefix of the qualified name (e.g. "local" of the qualified name
    * "local:node". The prefix part of the qualified name is optionnal.
    */
   private String prefix;

   /**
    * Namespace
    */
   private String namespaceURI;

   /**
    * Copy constructor. This constructor creates an exact copy of the passed
    * argument.
    * 
    * @param qname a qualified name.
    */
   public QName(final QName qname)
   {
      this.localName = qname.localName;
      this.namespaceURI = qname.namespaceURI;
      this.prefix = qname.prefix;
   }

   /**
    * QName from a string. The basic way to create a QName is to build it from
    * the string representation of the name (i.e. Prefix ':' LocalPart). For
    * performance reasons the parsing may throw runtime exception if an invalid
    * name as been provided in input.
    * 
    * @param qname_string string form of the qualified name.
    */
   public QName(final String qname_string)
   {
      this(qname_string, null);
   }

   /**
    * QName from a string. The basic way to create a QName is to build it from
    * the string representation of the name (i.e. Prefix ':' LocalPart). For
    * performance reasons the parsing may throw runtime exception if an invalid
    * name as been provided in input.
    * 
    * @param qname_string string form of the qualified name.
    * @param namespace_uri string form of namespace
    */
   public QName(final String qname_string, final String namespace_uri)
   {
      /**
       * Retreive the index of the ':' delimiter
       */
      final int delimiterIndex = qname_string.indexOf(':');

      /**
       * Extract the parts of the qualidifed name
       */
      if (delimiterIndex > 0)
      {
         this.setPrefix(qname_string.substring(0, delimiterIndex));
         this.setLocalName(qname_string.substring(delimiterIndex + 1));
      }
      else
      {
         this.setLocalName(qname_string);
      }

      if (this.getLocalName() == null)
      {
         throw new NullPointerException(
               "Unable to extract local part of the qualified name.");
      }

      this.namespaceURI = namespace_uri;
   }

   /**
    * Set the prefix part of the qualified name.
    * 
    * @param prefix the prefix part of the qualified name.
    */
   public void setPrefix(final String prefix)
   {
      this.prefix = prefix;
   }

   /**
    * Returns the prefix part of the qualified name.
    * 
    * @return the prefix string if exists or null otherwise.
    */
   public String getPrefix()
   {
      return this.prefix;
   }

   /**
    * Set local part.
    * 
    * @param localname the local name of the qualified name.
    */
   public void setLocalName(final String localname)
   {
      this.localName = localname;
   }

   /**
    * Returns the local part of the qualified name.
    * 
    * @return the local part of the qualified name. The value shall never be
    *         null.
    */
   public String getLocalName()
   {
      return this.localName;
   }

   /**
    * Returns the string form of the qualified name. The string form is the
    * concatenation of the prefix and the local parts of the qualified name,
    * separated by a column ":" character.
    * 
    * @return the string form of the qualifed name. The string shall at least
    *         contain the local part if no prefix has been set.
    */
   public String getName()
   {
      final String prefix = this.getPrefix();

      if (prefix != null)
      {
         return prefix + ":" + this.getLocalName();
      }
      else
      {
         return this.getLocalName();
      }
   }

   /**
    * Return the namespace URI of the variable
    * 
    * @return the namespace URI of the variable
    */
   public String getNamespaceURI()
   {
      return this.namespaceURI;
   }

   /**
    * Return the namespace URI of the variable
    * 
    * @param ns The namespace URI of the variable
    */
   public void setNamespaceURI(final String ns)
   {
      this.namespaceURI = ns;
   }

   /**
    * Returns the string form of the qualified name. This operation overrides
    * the standard toString() and returns the same output than the getName()
    * operation of the present class.
    * 
    * @return the string form of the qualifed name. The string shall at least
    *         contain the local part if no prefix has been set.
    */
   public String toString()
   {
      return this.getName();
   }

   /**
    * @param o object
    * @return true false
    */
   public boolean equals(final Object o)
   {
      if (o == null)
      {
         return false;
      }

      if (!(o instanceof QName))
      {
         return false;
      }

      final QName name = (QName) o;

      if (!(name.getLocalName().equals(this.getLocalName())))
      {
         return false;
      }

      if ((name.getNamespaceURI() == null) && (this.getNamespaceURI() == null))
      {
         return true;
      }

      if ((name.getNamespaceURI() != null)
            && (name.getNamespaceURI().equals(this.getNamespaceURI())))
      {
         return true;
      }

      return false;

   }

   /**
    * @return name + namespace URI
    */
   public int hashCode()
   {
      return ((this.localName + this.namespaceURI).hashCode());
   }
}
