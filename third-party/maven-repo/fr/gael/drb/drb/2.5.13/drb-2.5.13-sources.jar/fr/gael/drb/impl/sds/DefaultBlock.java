/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import java.lang.ref.SoftReference;

import org.apache.log4j.Logger;

import fr.gael.drb.value.Value;

/**
 * Default block. This class provides the default implementation of
 * AbstractBlock.<br>
 * There is a first level of optimization where AbstractBlock operations are
 * called only once for getIndex(), hasChild(), getChildrenCount() and related
 * values stored into private attributes..
 */
class DefaultBlock extends AbstractBlock
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(DefaultBlock.class);

   /**
    * Flag to know if hasChild() was called before or not. True if hasChild()
    * operation was called, else false. Used for performance purpose jointly to
    * hasChildValue attribute.
    */
   private boolean hasChildDone;

   /**
    * hasChild() return value, used for performance purpose. Used to store the
    * result after the first hasChild() call.
    */
   private boolean hasChildValue;

   /**
    * getIndex() return value, used for performance purpose. Used to store the
    * result after the first getIndex() call.
    */
   private int indexValue;

   /**
    * Value of the block, used for performance purpose. Used to store the result
    * after the first getValue() call.
    */
   protected SoftReference<Value> blockValue;

   /**
    * Creates a new instance of DefaultBlock with descriptor and key. The
    * descriptor ans the key must not be null. The descriptor is used to get
    * information about the block such as name, offset, number of occurrences,
    * etc. The key is the path of the block in the descriptors tree.
    * 
    * @param descriptor The descriptor of the block.
    * @param key The key of the block.
    */
   protected DefaultBlock(final Descriptor descriptor, final int[] key)
   {
      // Call superclass operation
      super(descriptor, key);
      // logger.debug("++ Constructor("+((descriptor==null)?
      // null:descriptor.getName())+ ", "+IntMap.keyToString(key)+")");

      // Set default values
      this.hasChildValue = false;
      this.hasChildDone = false;
      this.indexValue = -1;
      this.blockValue = new SoftReference<Value>(null);
   }

   /**
    * Returns the index of the block. In this implementation the superclass
    * operation is called only during the first call and the returned value is
    * stored in the indexValue attribute which enables better performance for
    * future calls.
    * 
    * @return The index of the block or a negative value.
    */
   public int getIndex()
   {
      // Check if operation was not called before
      if (this.indexValue < 0)
      {
         // Call superclass operation
         this.indexValue = super.getIndex();
      }

      // Returns the value
      return this.indexValue;
   }

   /**
    * Returns true if at least one child exists for the current block. In this
    * implementation the superclass operation is called only during the first
    * call and the returned value is stored in the hasChildValue attribute which
    * enables better performance for future calls.
    * 
    * @return true if at least one child exists, false otherwise.
    */
   public boolean hasChild()
   {
      // Check if operation was not called before
      if (!this.hasChildDone)
      {
         // Call superclass operation and flag as done.
         this.hasChildValue = super.hasChild();
         this.hasChildDone = true;
      }

      // Returns the value
      return this.hasChildValue;
   }

   /**
    * Returns the number of children for the current block. In this
    * implementation the superclass operation is called only during the first
    * call and the returned value is stored in the childrenCountValue attribute
    * which enables better performance for future calls.
    * 
    * @return The number of children for the current block.
    */
   /*
    * public int getChildrenCount() { // Check if operation was not called
    * before if (childrenCountValue < 0) { // Call superclass operation
    * childrenCountValue = super.getChildrenCount(); } // Returns the value
    * return childrenCountValue; }
    */

   /**
    * Returns the value of the block. In this implementation the value is read
    * from the file only once. Any further call will return the cached value. If
    * the block is not a leaf (i.e. a node having at least one child), no value
    * is returned.
    * 
    * @return The block value or a null reference.
    */
   public Value getValue()
   {
      // If node has child, no value is returned.
      if ((this.descriptor != null)
            && (this.descriptor.getValueType() == Value.NULL_ID))
      {
         return null;
      }

      // If value has not been read yet, do it.
      Value desc_value = this.blockValue.get();
      if (desc_value == null)
      {
         desc_value = this.descriptor.getValue(this.key);
         //this.blockValue = new SoftReference<Value>(desc_value);
      }

      // Return value
      return desc_value;
   }

   /**
    * Returns the value type of the block. This implementation wraps the
    * getValueType() operation from the descriptor.
    * 
    * @return The block value type.
    */
   public int getValueType()
   {
      return this.descriptor.getValueType();
   }

   /**
    * Changes the value of the node. This implementation simply wrap the
    * AbstractBlock to use the cache.
    * <p>
    * <b>Events:</b> No particular event is fired in this implementation.
    * </p>
    * 
    * @param value The new value of the node. This value shall not be null.
    * @return The effectively assigned value. The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be
    *            overridden by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            offset or the length used to write is unknown.
    */
   public Value setValue(Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      value = super.setValue(value);
      this.blockValue = new SoftReference<Value>(value);
      return value;
   } // setValue
} // DefaultBlock
