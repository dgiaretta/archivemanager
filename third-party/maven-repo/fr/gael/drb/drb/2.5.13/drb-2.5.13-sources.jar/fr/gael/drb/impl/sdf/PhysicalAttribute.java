/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sdf;

import java.util.Iterator;

import org.apache.log4j.Logger;

/**
 * Physical attribute in descriptor. This class is used to manage a physical
 * attribute such as offset, length or occurrence count. It contains the type of
 * value (fixed, constant in parent or variable). Depending of the type the
 * value can be unique or not. If there are several values for the descriptor
 * they are stored in a map.
 */
final class PhysicalAttribute
{
   /**
    * Constant for "value is unknown".
    */
   protected static final int UNKNOWN = -1;

   /**
    * Constant for "value is fixed".
    */
   protected static final int FIXED = 1;

   /**
    * Constant for "value is constant in the parent".
    */
   protected static final int CONSTANT_IN_PARENT = 2;

   /**
    * Constant for "value is variable for all occurrences".
    */
   protected static final int VARIABLE = 3;

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(PhysicalAttribute.class);

   /**
    * The value of the physical attribute. This value is used only in case of
    * FIXED physical attribute. In the other cases there are several values
    * stored in the map.
    */
   protected long value;

   /**
    * The type of value. It describes if the value if fixed (single) or not
    * (multiple).
    */
   protected int type;

   /**
    * Map of the values. This map is used in case of non FIXED physical
    * attribute.
    */
   protected KeyTreeMap map;

   /**
    * Builds a PhysicalAttribute instance with UNKNOWN value type.
    */
   protected PhysicalAttribute()
   {
      // Set default values
      this.type = this.UNKNOWN;
      this.value = -1;
   }

   /**
    * Builds a PhysicalAttribute instance with the given value type. In case of
    * non fixed value type the map will be created.
    * 
    * @param type The type of the physical attribute value. It shall be
    *           this.UNKNOWN, FIXED, this.CONSTANT_IN_PARENT or this.VARIABLE.
    */
   protected PhysicalAttribute(final int type)
   {
      // Call default constructor
      this();

      // Set the type
      this.setType(type);
   }

   /**
    * Returns the value type.
    * 
    * @return The type of the physical attribute value. It shall be
    *         this.UNKNOWN, FIXED, this.CONSTANT_IN_PARENT or this.VARIABLE.
    */
   protected final int getType()
   {
      return this.type;
   }

   /**
    * Sets the value type. All existing map values will be lost because the map
    * reference is set to null, or a new instance is created for non fixed value
    * type.
    * 
    * @param type The type of the physical attribute value. It shall be
    *           this.UNKNOWN, FIXED, this.CONSTANT_IN_PARENT or this.VARIABLE.
    */
   protected final void setType(final int type)
   {
      // Check parameter
      // Case of this.UNKNOWN or fixed value type, no map is needed
      if ((type == this.UNKNOWN) || (type == this.FIXED))
      {
         // Reset map reference
         this.map = null;
      }

      // Case of non this.FIXED type, the map has to be created
      else if ((type == this.CONSTANT_IN_PARENT) || (type == this.VARIABLE))
      {
         // Creates the map
         this.map = new KeyTreeMap();
      }

      // Case of invalid type
      else
      {
         this.logger.error("PhysicalAttribute.setType() ERROR: "
               + "Invalid parameter.");
         this.logger.error("   type = " + type + " => set to this.UNKNOWN.");
         return;
      }

      // Store the given type
      this.type = type;
   }

   /**
    * Returns the value associated to the key. If the value type is this.FIXED
    * then returns the unique value, else get the value associated to the key
    * from the map .
    * 
    * @param key The key to use if needed to get the value from map.
    * @return The value of the physical attribute or -1
    */
   protected long getValue(final int[] key)
   {
      // Local this.VARIABLEs
      int[] keyToUse = null; // the key to use for the map
      long mapValue; // the value from the map

      // Check value type
      switch (this.type)
      {
         // Case of this.UNKNOWN value type, returns -1
         case UNKNOWN:
            return -1;

            // Case of this.FIXED value type, returns the unique value.
         case FIXED:
            return this.value;

            // Case of this.CONSTANT_IN_PARENT value type, creates and uses
            // the parent key
         case CONSTANT_IN_PARENT:
            keyToUse = IntMap.getParentKey(key);
            break;

         // Case of this.VARIABLE value type, uses the key itself
         case VARIABLE:
            keyToUse = key;
            break;

         default:
            return -1;
      }

      // At this step the value has to be read from map because it is not
      // this.FIXED for all blocks.
      if ((mapValue = this.map.get(keyToUse)) < 0)
      {
         // Display warning info
         // logger.warn("PhysicalAttribute.getValue() : " +
         // "No map value for key = " + IntMap.keyToString(keyToUse));
         // Return "no value"
         return -1;
      }

      // Return the value from the map
      return mapValue;
   }

   /**
    * Sets the value according to the current value type. If the value type is
    * this.UNKNOWN the value stays unchanged. If the value type is this.FIXED
    * the value is unique and set directly. If the value type is non this.FIXED
    * the given value is stored in the map using the given key. If the key is
    * null the value is not added to the map.
    * 
    * @param key The key
    * @param value the value
    */
   protected void setValue(final int[] key, final long value)
   {
      // Local this.VARIABLEs
      int[] keyToUse = null; // the key to use for the map

      // Check value type
      switch (this.type)
      {
         // Case of this.UNKNOWN value type, this is an error
         case UNKNOWN:
            logger.error("PhysicalAttribute.setValue() ERROR: "
                  + "Value type is this.UNKNOWN => value not updated.");
            return;

            // Case of this.FIXED value type, sets the unique value
         case FIXED:
            this.value = value;
            return;

            // Case of this.CONSTANT_IN_PARENT value type, creates the parent
            // key
            // which will be used to store the value into the map
         case CONSTANT_IN_PARENT:
            keyToUse = IntMap.getParentKey(key);
            break;

         // Case of this.VARIABLE value type
         case VARIABLE:
            // The key itself will be used to store the value into the map
            keyToUse = key;
            break;
      }

      // At this step the value has to be stored into the map because it is not
      // this.FIXED for all blocks.
      if (keyToUse != null)
      {
         // Check map size and remove one value on two to preserve memory
         if (this.map.getSize() >= 2000)
         {
            // long finalTime = System.currentTimeMillis();
            int i = 0;
            final Iterator iterator = this.map.iterator();
            while (iterator.hasNext())
            {
               iterator.next();
               iterator.remove();
               i++;
               if (i >= 1000)
               {
                  break;
               }
            }
            // logger.error("at "+IntMap.keyToString(keyToUse)+", remove(): "
            // +(System.currentTimeMillis()-finalTime));
         }

         // Add the value in the map
         this.map.add(keyToUse, value);
      }
   }

   /**
    * Clear the content of the map. If the map is used this operation calls the
    * clear() operation from the map, else does nothing.
    */
   protected final void clear()
   {
      // Check if map is used and wrap to the map operation
      if ((this.type == this.CONSTANT_IN_PARENT)
            || (this.type == this.VARIABLE))
      {
         this.map.clear();
      }
   }

   /**
    * Prints info into a string.
    * 
    * @return String
    */
   public String toString()
   {
      // Local declarations
      String tmpStr;

      switch (this.type)
      {
         case UNKNOWN:
            tmpStr = "this.UNKNOWN";
            break;
         case FIXED:
            tmpStr = "this.FIXED " + this.value;
            break;
         case CONSTANT_IN_PARENT:
            // tmpStr = "this.CONSTANT_IN_PARENT " + map;
            tmpStr = "this.CONSTANT_IN_PARENT size=" + this.map.getSize();
            break;
         case VARIABLE:
            tmpStr = "this.VARIABLE " + this.map;
            // tmpStr = "this.VARIABLE size=" + map.getSize();
            break;
         default:
            tmpStr = "INVALID";
            break;
      }

      // Return info string
      return "{" + tmpStr + "}";
   }
} // PhysicalAttribute
