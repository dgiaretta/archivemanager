/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import java.net.URL;

/**
 * Common interface for Node factory implementations. All the classes
 * implementing this interface can be used by the DrbFactory class. As a
 * summary, the "Data Request Broker" (DRB) implementations are packages that
 * break down a specific data resource (e.g. an XML document, an HTML file, a
 * Zip archive, a database, etc.) into a tree of DrbNode instances.
 * <p>
 * As an example, an implementation may handle file systems, breaking down the
 * hard disk devices into directories and regular files. Another one may provide
 * nodes corresponding to the tables and records of a database.
 * </p>
 * <b>The factory implementations are supposed to be used by the DrbFactory
 * class and not outside.</b> It may however be useful to create DrbNodes
 * directly from a specific implementation disregarding the DrbFactory abstract
 * level. It is therefore recommended to be careful in such situation.
 * </p>
 * <p>
 * Here are some examples of direct use of this interface to open DrbNodes from
 * a path, maybe with an existing context. The following examples are not
 * supposed to work with existing implementations but intends to provides an
 * overview of the DrbFactoryImpl interface. Report to the implementations
 * specific documentations for an accurate description of their use:
 * </p>
 */
public interface DrbUpdateImpl extends DrbFactoryImpl
{
   /**
    * Put a node at the given path. This operation creates and returns a DrbNode
    * corresponding to the given "Uniform Resource Identifier" (URI). Because
    * URL class provided by java.net package supports the URI specifications, it
    * has been used has URI parameter. The implementation is supposed to be able
    * to handle the URI with a default or absolute context.
    */
   public void put(DrbNode input, URL uri);

   /**
    * Opens the node from an existing node. This operation creates and returns a
    * DrbNode using an existing node as base or context. The input DrbNode has
    * to be used as base of the creation. If the implementation is not able to
    * handle any input node, it shall always return null. The reference to the
    * input shall not be null.
    * 
    * @param input An input node
    * @param base_node The input node to be used as context or base. This
    *           parameter shall not be null.
    * @return A root node or null if an error occured or if the implementation
    *         does not supports the input node.
    */
   public void put(DrbNode input, DrbNode base_node);

   /**
    * Opens the node matching a given URI from an existing node. This operation
    * creates and returns a DrbNode corresponding to the given "Uniform Resource
    * Identifier" (URI) using an existing node as base or context. Because URL
    * class provided by java.net package supports the URI specifications, it has
    * been used has URI parameter. The input DrbNode has to be used as base of
    * the creation. If the implementation is not able to handle any input node,
    * it shall always return null even if it is able to use the passed URI
    * standalone. If the reference to the URI is null the operation works as the
    * open(DrbNode baseNode). Similary, if the URI reference is null, the
    * operation works as the open(URL uri).
    * <dl>
    * <dt><b>Important note</b>
    * <dd> The implementation shall return a reference to a DrbNode
    * corresponding to the entire URI <b>AND</b> using the input node. They
    * shall return a null reference in any other case. </dd>
    * </dl>
    * 
    * @param input An input node
    * @param uri The "Uniform Resource Identifier" (URI) to be handled.
    * @param base_node The input node to be used as context or base.
    */
   public void put(DrbNode input, URL uri, DrbNode base_node);

}// DrbUpdateImpl
