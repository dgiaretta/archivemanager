/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import org.apache.log4j.Logger;

/**
 * Generic implementation of DrbNodeList. This default implementation of
 * DrbNodeList extends a ArrayList provided by Java API. It is a generic mean to
 * create a list of nodes. If no specific operations are required to implement
 * the DrbNodeList (e.g. filters, caching, hashing, etc.) this class is a simple
 * mean to represent a collection of nodes. Note : the add() or equivalent
 * operations of the ArrayList class have not been overrided to insure they
 * insert DrbNode intances. Some inconsistency may appear if no care is taken
 * while calling add() or equivalent operations.
 */
public class DrbDefaultNodeList extends DrbDefaultSequence implements
      DrbNodeList
{

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(DrbDefaultNodeList.class);

   /**
    * Returns a specific item of the list. This operation wraps the
    * ArrayList.get() operation. The exception that ArrayList.get() can raise is
    * however traped and not propagated. In such case a message is written to
    * the error output and the operation returns null without throwing any
    * exception.
    * 
    * @param index The position of the item starting from 0 and not greater or
    *           equal to the item count in the list.
    * @return A reference to specified item or null if no such node.
    */
   public DrbNode item(final int index)
   {
      return (DrbNode) this.getItem(index);
   }

   /**
    * Returns an occurence of item matching a specific name. The occurence
    * number starts from 1. The name is a local name without any prefix.A null
    * reference is returned if the provided occurrence is outside the list
    * bounds.
    * 
    * @param name The name to match.
    * @param occurence The occurence number of the desired child.
    * @return A reference to specified item or null if no such node.
    */
   public DrbNode getNamedItem(final String name, final int occurence)
   {
      /**
       * Checks parameters.
       */
      if ((name == null) || (occurence <= 0))
      {
         logger.error("DrbDefaultNodeList.item(): "
               + "Invalid parameter (name=\"" + name + "\", occurence="
               + occurence);
         return null;
      }

      /**
       * Search the matching node.
       */
      int current_occurence = 0;
      String current_name = null;

      for (int inode = 0; inode < this.getLength(); inode++)
      {
         final DrbNode current_node = this.item(inode);
         if (current_node == null)
         {
            continue;
         }
         current_name = current_node.getName();

         if ((current_name != null) && (current_name.equals(name)))
         {
            current_occurence = current_occurence + 1;
         }

         if (current_occurence == occurence)
         {
            return current_node;
         }
      }
      return null;
   }

   /**
    * Inserts a item at a given position. The passed item is inserted in the
    * list of children at the given position The position is the expected index
    * of the item after insertion. All the previous item from the aimed position
    * to the end of the list are shift to the end of the new sequence (i.e.
    * their indices are shifted up of 1). If the given index is out of the
    * sequence bounds and therefore less than zero and greater or equal to the
    * current number of items,the operation raises an exception. An index equal
    * to the current number of item is allowed and the operation is therefore
    * equivalent to an append.
    * 
    * @param index The expected index of the item after the insertion.
    * @param item A reference to the item to be inserted.
    * @return A reference to the a sequence containing the inserted node.
    * @throws NullPointerException This exception is raised when the passed item
    *            a null reference. This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passe
    *            index is less than zero or if it is greater or equal to the
    *            number of item in the sequence prior the call
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested insertion for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbSequence addItem(final int index, final DrbItem item)
         throws NullPointerException, UnsupportedOperationException,
         IndexOutOfBoundsException
   {
      // Assuming that the specified item is a node, insert it into the list
      try
      {
         super.addItem(index, item);
         return this;
      }
      // Otherwise we insert it into a default sequence
      catch (final ClassCastException e)
      {
         final DrbSequence new_sequence = new DrbDefaultSequence(this);
         new_sequence.addItem(index, item);
         return new_sequence;
      }
   } // addItem

   /**
    * Prints the node list contents. The items of the list are printed on a line
    * by line basis.
    * 
    * @return The list as a String or an emtpy string if the list contains no
    *         item.
    */
   public String toString()
   {
      String string = "";

      for (int index = 0; index < this.getLength(); index++)
      {
         if (index != 0)
         {
            string = string + ", ";
         }

         string += this.item(index);
      }

      return string;
   }
} // DrbDefaultNodeList
