/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;


/**
 * Function declaration of XQuery language.
 */
abstract class Function implements FunctionBody
{
   /**
    * Function signature.
    */
   private FunctionSignature signature;
  
   /**
    * Complete constructor of a function.
    * 
    * @param name string form of the function qualified name.
    * @param return_type the return type.
    */
   protected Function(FunctionSignature signature)
   {
      this.signature = signature;
   }

   /**
    * Returns the signature of this function.
    * @return the declared function signature. 
    */
   FunctionSignature getSignature()
   {
      return this.signature;
   }

   /**
    * Returns the qualified name of the function. Any function shall return a
    * qualified name, even if it is not prefixed.
    * 
    * @return the qualified name of the function.
    */
   protected QName getQName()
   {
      return this.signature.getQName();
   }

   /**
    * Returns the string form of the qualified name of the function.
    * 
    * @return the string form of the qualified name.
    */
   public String getName()
   {
      return this.signature.getName();
   }

   /**
    * Returns the return type of the function.
    * 
    * @return the return type of the function.
    */
   protected SequenceType getReturnType()
   {
      return this.signature.getReturnType();
   }
   
   /**
    * Set the return type of the function.
    * 
    * @param return_type the return type of the function.
    */
   protected void setReturnType(SequenceType return_type)
   {
      this.signature.setReturnType(return_type);
   }

   /**
    * Assigns a new name to the function. The provided name shall be the
    * qualified name of the function such as the one provided at construction.
    * The operation replaces the old name with the new one although the prefix
    * part has changed or not. The operation raises a NullPointerException if
    * the provided name is null.
    * 
    * @param name the new qualified name of the function.
    */
   protected void setName(final String name)
   {
      this.signature.setName(name);
   }

   /**
    * Returns the string form of the qualified name of the sequence type of the
    * function. The name of the sequence type does not include the occurrence
    * indicator.
    * 
    * @return the string form of the qualified name of the sequence type.
    */
   public String getSequenceTypeName()
   {
      return this.signature.getSequenceTypeName();
   }

   /**
    * Declare a new parameter to the function.
    * 
    * @param parameter_name string form of the qualified name of the parameter.
    */
   public void addParameter(final QName parameter_name)
   {
      this.signature.addParameter(parameter_name);
   }
   
   /**
    * Declare a new parameter to the function.
    * 
    * @param parameter_name string form of the qualified name of the parameter.
    */
   public void addParameter(final QName parameter_name,
                            final SequenceType parameter_type)
   {
      this.signature.addParameter(parameter_name, parameter_type);
   }

   /**
    * Returns the arity of the function signature.
    * 
    * @return the number of declared parameters.
    */
   public int getArity()
   {
      return this.signature.getArity();
   }

   /**
    * Returns a declared parameter of the function.
    * 
    * @param parameter_index index of the parameter starting at zero.
    * @return declared parameter of the function
    */
   public QName getParameter(final int parameter_index)
   {
      return this.signature.getParameter(parameter_index);
   }
   
   /**
    * Returns a declared parameter type of the function.
    * 
    * @param parameter_index index of the parameter starting at zero.
    * @return declared parameter type of the function
    */
   public SequenceType getParameterType(final int parameter_index)
   {
      return this.signature.getParameterType(parameter_index);
   }

   /**
    * Identifies function that can modify the state of an existing node. An
    * updating function can use the updating operations provided by the "XQuery
    * Update Facility" : insert, delete, replace, rename and transform.
    * 
    * @return true if this function performs updating operations and false
    *         otherwise
    */
   public boolean isUpdating()
   {
      return signature.isUpdating();
   }

   /**
    * Returns a detailed description of the function.
    * 
    * @return the description of the function.
    */
   public String toString()
   {
      return this.signature.toString();
   }
}
