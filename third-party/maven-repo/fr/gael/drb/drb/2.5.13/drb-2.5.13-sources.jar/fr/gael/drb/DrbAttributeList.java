/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

/**
 * Collection of attributes. This interface provides primary operations to
 * handle collections of DrbAttribute.
 */
public interface DrbAttributeList extends DrbSequence
{

   /**
    * Returns a specific item of the list. The item is identified by its
    * position (i.e. index or sequence number) in th list of attributes. The
    * order depends on the implementation as well as from the operation that
    * created the list. The index starts from 0 and shall not be greater or
    * equal to the item count of the list. A null reference is returned if the
    * provided index is outside the list bounds.
    * 
    * @param index The position of the item starting from 0 and not greater or
    *           equal to the item count in the list.
    * @return A reference to specified item or null if no such attribute.
    */
   public DrbAttribute item(int index);

   /**
    * Returns the item matching a specific name. The name is a local name
    * without any prefix.
    * 
    * @param name The name to match.
    * @return A reference to specified items or null if no such attribute.
    */
   public DrbAttribute getNamedItem(String name);

   /**
    * The number of items in the list. This number can be 0 if the list is empty
    * but shall never be negative.
    * 
    * @return The number of attributes is the list.
    */
   public int getLength();
}
