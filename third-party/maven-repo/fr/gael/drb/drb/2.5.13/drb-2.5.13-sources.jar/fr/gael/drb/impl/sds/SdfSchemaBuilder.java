/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultMutableNode;
import fr.gael.drb.DrbNode;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.value.Value;
import fr.gael.drb.xsd.XmlSchema;
import fr.gael.drb.xsd.XsdAnnotation;
import fr.gael.drb.xsd.XsdAppinfo;
import fr.gael.drb.xsd.XsdDocumentation;
import fr.gael.drb.xsd.XsdElement;
import fr.gael.drb.xsd.builder.XmlSchemaBuilder;

/**
 * Factory for SDF/XML-Schema.
 */
public final class SdfSchemaBuilder extends XmlSchemaBuilder
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(SdfSchemaBuilder.class);

   /**
    * Create an SDF/XML-Schema generator with default parameters.
    */
   public SdfSchemaBuilder()
   {
      super();
      this.staticNamespace.bind("sdf", AbstractBlock.SDF_NAMESPACE);
   }

   /**
    * Builds a SDF Schema from an input node.
    * 
    * @param node the input node.
    * @return
    */
   public XmlSchema createSchema(final DrbNode node)
   {
      final XmlSchema schema = super.createSchema(node);
      return schema;
   }

   /**
    * Refine a XML Element.
    * 
    * @param element the element
    * @param node the input node.
    * @param occurs the actual occurrence of the node
    * @return an XSD element
    */
   protected XsdElement refineElement(final XsdElement element,
         final DrbNode node, final int occurs)
   {
      final XsdElement sdf_element = super.refineElement(element, node, occurs);

      try
      {
         final AbstractBlock block =
            (AbstractBlock) ((DrbNodeImpl) node).getImpl(AbstractBlock.class);
         if (block == null)
         {
            return sdf_element;
         }

         final Descriptor desc = block.descriptor;
         // Check element consistency
         if (desc.occurrenceCount.getType() != PhysicalAttribute.FIXED)
         {
            element.setOccurs(0, XsdElement.UNBOUNDED_OCCURS);
         }

         final DrbNode block_node = this.createBlock(desc, occurs);

         // Add annotation
         XsdDocumentation[] documentations = null;
         if (desc.documentation != null)
         {
            documentations =
               new XsdDocumentation[] { new XsdDocumentation(
                     new fr.gael.drb.value.String(desc.documentation)) };
         }
         XsdAppinfo[] appinfos = null;
         if ((block_node.getAttributes() != null)
               || ((block_node.getChildren() != null) && (block_node
                     .getChildren().getLength() > 0)))
         {
            appinfos = new XsdAppinfo[] { new XsdAppinfo(block_node) };
         }
         if ((documentations != null) || (appinfos != null))
         {
            final XsdAnnotation annotation =
               new XsdAnnotation(appinfos, documentations);
            element.setAnnotation(annotation);
         }
      }
      catch (final ClassCastException e)
      {
      }
      return sdf_element;
   }

   /**
    * Create a block node.
    * 
    * @param desc a block descriptor.
    * @param occurs the block occurrence
    * @return a sdf:block node.
    */
   private DrbNode createBlock(final Descriptor desc, final int occurs)
   {
      final DrbNode block_node = new DrbDefaultMutableNode("block");
      block_node.setNamespaceURI(AbstractBlock.SDF_NAMESPACE);

      // Build block attributes

      if (desc.fileNodePath != null)
      {
         final DrbDefaultAttributeList block_attribs =
            new DrbDefaultAttributeList();
         block_attribs.add(new DrbDefaultAttribute("query",
               new fr.gael.drb.value.String(desc.fileNodePath), block_node));
         block_node.setAttributes(block_attribs);
      }
      // Build block children

      // Create occurrence property node.
      if ((desc.occurrenceCount.getType() != PhysicalAttribute.FIXED)
            || (occurs != desc.occurrenceCount.getValue()))
      {
         final DrbNode occurs_node =
            this.createOccurrence(desc.occurrenceCount);
         if (occurs_node != null)
         {
            block_node.appendChild(occurs_node);
         }
      }

      // Create offset property node.
      if (desc.blockOffset.specified)
      {
         final DrbNode offset_node = this.createOffset(desc.blockOffset);
         if (offset_node != null)
         {
            block_node.appendChild(offset_node);
         }
      }

      // Create encoding property node.
      final DrbNode encoding_node = this.createEncoding(desc);
      if (encoding_node != null)
      {
         block_node.appendChild(encoding_node);
      }

      // Create header padding property node.
      final DrbNode header_node = this.createHeaderPadding(desc);
      if (header_node != null)
      {
         block_node.appendChild(header_node);
      }
      // Create footer padding property node.
      final DrbNode footer_node = this.createFooterPadding(desc);
      if (footer_node != null)
      {
         block_node.appendChild(footer_node);
      }
      // Create length property node.
      if (desc.contentLength.specified)
      {
         final DrbNode length_node = this.createLength(desc.contentLength);
         if (length_node != null)
         {
            block_node.appendChild(length_node);
         }
      }
      // Create delimiter property node.
      final DrbNode delim_node = this.createDelimiter(desc.delimiter);
      if (delim_node != null)
      {
         block_node.appendChild(delim_node);
      }

      // Create array property node.
      if (desc.valueType == Value.ARRAY_ID)
      {
         final DrbNode array_node = this.createArray(desc);
         if (array_node != null)
         {
            block_node.appendChild(array_node);
         }
      }

      return block_node;
   }

   /**
    * Create a array node.
    * 
    * @param desc a block descriptor.
    * @return a sdf:block node.
    */
   private DrbNode createArray(final Descriptor desc)
   {
      final DrbNode array_node = new DrbDefaultMutableNode("array");
      array_node.setNamespaceURI(AbstractBlock.SDF_NAMESPACE);

      // Create occurrence property node.
      final DrbNode occurs_node = this.createOccurrence(desc.itemCount);
      if (occurs_node != null)
      {
         array_node.appendChild(occurs_node);
      }

      // Create length property node.
      final DrbNode length_node = this.createLength(desc.itemLength);
      if (length_node != null)
      {
         array_node.appendChild(length_node);
      }

      // Create delimiter property node.
      final DrbNode delim_node = this.createDelimiter(desc.arrayDelimiter);
      if (delim_node != null)
      {
         array_node.appendChild(delim_node);
      }

      return array_node;
   }

   /**
    * Create a length attribute.
    * 
    * @param length the sdf:length attribute
    * @return a sdf:length node.
    */
   private DrbNode createLength(final LengthAttribute length)
   {
      final DrbNode length_node = new DrbDefaultMutableNode("length");
      length_node.setNamespaceURI(AbstractBlock.SDF_NAMESPACE);
      final DrbDefaultAttributeList length_attribs =
         new DrbDefaultAttributeList();

      int length_unit = length.getUnit();
      boolean unbounded = false;
      // Length value or query
      if (length.query != null)
      {
         length_attribs.add(new DrbDefaultAttribute("query",
               new fr.gael.drb.value.String(length.query), length_node));
         if (length.getOccurrenceType() == PhysicalAttribute.SINGLE)
         {
            length_attribs.add(new DrbDefaultAttribute("constant",
                  new fr.gael.drb.value.Boolean(true), length_node));
         }
         else
         {
            length_attribs.add(new DrbDefaultAttribute("constant",
                  new fr.gael.drb.value.Boolean(false), length_node));
         }
      }
      else if (length.getType() == PhysicalAttribute.FIXED)
      {
         long len = length.getValue(null);
         if ((length_unit == LengthAttribute.UNIT_BIT) && (len % 8 == 0))
         {
            len = len / 8;
            length_unit = LengthAttribute.UNIT_BYTE;
         }
         length_node.setValue(new fr.gael.drb.value.Long(len));
      }
      else
      {
         length_node.setValue(new fr.gael.drb.value.String("unbounded"));
         unbounded = true;
         return null;
      }

      // Length unit
      if ((length_unit == LengthAttribute.UNIT_BIT) && (unbounded == false))
      {
         length_attribs.add(new DrbDefaultAttribute("unit",
               new fr.gael.drb.value.String("bit"), length_node));
      }
      length_node.setAttributes(length_attribs);

      return length_node;
   }

   /**
    * Create an offset attribute.
    * 
    * @param offset the sdf:offset attribute
    * @return a sdf:offset node.
    */
   private DrbNode createOffset(final OffsetAttribute offset)
   {
      final DrbNode offset_node = new DrbDefaultMutableNode("offset");
      offset_node.setNamespaceURI(AbstractBlock.SDF_NAMESPACE);
      final DrbDefaultAttributeList offset_attribs =
         new DrbDefaultAttributeList();

      int offset_unit = offset.getUnit();

      // Length value or query
      if (offset.query != null)
      {
         offset_attribs.add(new DrbDefaultAttribute("query",
               new fr.gael.drb.value.String(offset.query), offset_node));
         if (offset.getOccurrenceType() == PhysicalAttribute.SINGLE)
         {
            offset_attribs.add(new DrbDefaultAttribute("constant",
                  new fr.gael.drb.value.Boolean(true), offset_node));
         }
         else
         {
            offset_attribs.add(new DrbDefaultAttribute("constant",
                  new fr.gael.drb.value.Boolean(false), offset_node));
         }
      }
      else if (offset.getType() == PhysicalAttribute.FIXED)
      {
         long len = offset.getValue(null);
         if ((offset_unit == LengthAttribute.UNIT_BIT) && (len % 8 == 0))
         {
            len = len / 8;
            offset_unit = LengthAttribute.UNIT_BYTE;
         }
         offset_node.setValue(new fr.gael.drb.value.Long(len));
      }

      // Offset origin
      switch (offset.getOrigin())
      {
         case OffsetAttribute.ORIGIN_ROOT:
            offset_attribs.add(new DrbDefaultAttribute("origin",
                  new fr.gael.drb.value.String("root"), offset_node));
            break;
         case OffsetAttribute.ORIGIN_PARENT:
            offset_attribs.add(new DrbDefaultAttribute("origin",
                  new fr.gael.drb.value.String("parent"), offset_node));
            break;
      }
      offset_node.setAttributes(offset_attribs);

      // Length unit
      if (offset_unit == LengthAttribute.UNIT_BIT)
      {
         offset_attribs.add(new DrbDefaultAttribute("unit",
               new fr.gael.drb.value.String("bit"), offset_node));
      }
      offset_node.setAttributes(offset_attribs);

      return offset_node;
   }

   /**
    * Create a occurrence attribute.
    * 
    * @param occurs_count the occurrence count attribute
    * @return a sdf:occurrence node or null.
    */
   private DrbNode createOccurrence(final PhysicalAttribute occurs_count)
   {
      final DrbNode occurs_node = new DrbDefaultMutableNode("occurrence");
      occurs_node.setNamespaceURI(AbstractBlock.SDF_NAMESPACE);
      final DrbDefaultAttributeList occurs_attribs =
         new DrbDefaultAttributeList();

      // Length value or query
      if (occurs_count.query != null)
      {
         occurs_attribs.add(new DrbDefaultAttribute("query",
               new fr.gael.drb.value.String(occurs_count.query), occurs_node));
         if (occurs_count.getOccurrenceType() == PhysicalAttribute.SINGLE)
         {
            occurs_attribs.add(new DrbDefaultAttribute("constant",
                  new fr.gael.drb.value.Boolean(true), occurs_node));
         }
         else
         {
            occurs_attribs.add(new DrbDefaultAttribute("constant",
                  new fr.gael.drb.value.Boolean(false), occurs_node));
         }
      }
      else if (occurs_count.getType() == PhysicalAttribute.FIXED)
      {
         final long occurs = occurs_count.getValue(null);
         occurs_node.setValue(new fr.gael.drb.value.Long(occurs));
      }
      else
      {
         occurs_node.setValue(new fr.gael.drb.value.String("unbounded"));
      }

      occurs_node.setAttributes(occurs_attribs);

      return occurs_node;
   }

   /**
    * Create a header padding attribute.
    * 
    * @param delimiter the delimiter
    * @return a sdf:delimiter node or null.
    */
   private DrbNode createDelimiter(final String delimiter)
   {
      if (delimiter.length() == 0)
      {
         return null;
      }

      final DrbNode delim_node = new DrbDefaultMutableNode("delimiter");
      delim_node.setNamespaceURI(AbstractBlock.SDF_NAMESPACE);
      final DrbDefaultAttributeList delim_attribs =
         new DrbDefaultAttributeList();

      delim_attribs.add(new DrbDefaultAttribute("value",
            new fr.gael.drb.value.String(delimiter), delim_node));
      delim_node.setAttributes(delim_attribs);

      return delim_node;
   }

   /**
    * Create a header padding attribute.
    * 
    * @param desc a block descriptor.
    * @return a sdf:length node or null.
    */
   private DrbNode createHeaderPadding(final Descriptor desc)
   {
      if (desc.headerPadding.length == 0)
      {
         return null;
      }

      final DrbNode padding_node = new DrbDefaultMutableNode("padding");
      padding_node.setNamespaceURI(AbstractBlock.SDF_NAMESPACE);
      final DrbDefaultAttributeList padding_attribs =
         new DrbDefaultAttributeList();

      padding_attribs.add(new DrbDefaultAttribute("type",
            new fr.gael.drb.value.String("header"), padding_node));

      // Header content
      if (desc.headerPadding.content.length() > 0)
      {
         padding_attribs.add(new DrbDefaultAttribute("content",
               new fr.gael.drb.value.String(desc.headerPadding.content),
               padding_node));
      }

      // Header length
      padding_node
            .setValue(new fr.gael.drb.value.Int(desc.headerPadding.length));
      padding_node.setAttributes(padding_attribs);

      return padding_node;
   }

   /**
    * Create an encoding attribute.
    * 
    * @param desc a block descriptor.
    * @return a sdf:encoding node or null.
    */
   private DrbNode createEncoding(final Descriptor desc)
   {
      if (desc.valueType == Value.NULL_ID)
      {
         return null;
      }

      final DrbNode encoding_node = new DrbDefaultMutableNode("encoding");
      encoding_node.setNamespaceURI(AbstractBlock.SDF_NAMESPACE);

      if (desc.getEncoding() == Descriptor.ENCODING_TEXT)
      {
         encoding_node.setValue(new fr.gael.drb.value.String("ASCII"));
      }
      else if (desc.getEncoding() == Descriptor.ENCODING_BINARY)
      {
         encoding_node.setValue(new fr.gael.drb.value.String("BINARY"));
      }
      else
      {
         return null;
      }

      return encoding_node;
   }

   /**
    * Create a footer padding attribute.
    * 
    * @param desc a block descriptor.
    * @return a sdf:length node or null.
    */
   private DrbNode createFooterPadding(final Descriptor desc)
   {
      if (desc.footerPadding.length == 0)
      {
         return null;
      }

      final DrbNode padding_node = new DrbDefaultMutableNode("padding");
      padding_node.setNamespaceURI(AbstractBlock.SDF_NAMESPACE);
      final DrbDefaultAttributeList padding_attribs =
         new DrbDefaultAttributeList();

      padding_attribs.add(new DrbDefaultAttribute("type",
            new fr.gael.drb.value.String("footer"), padding_node));

      // Footer content
      if (desc.footerPadding.content.length() > 0)
      {
         padding_attribs.add(new DrbDefaultAttribute("content",
               new fr.gael.drb.value.String(desc.footerPadding.content),
               padding_node));
      }

      // Footer length
      padding_node
            .setValue(new fr.gael.drb.value.Int(desc.footerPadding.length));
      padding_node.setAttributes(padding_attribs);

      return padding_node;
   }

   /**
    * Makes the class runnable for testing.
    * 
    * @param args main arguments
    */
   public static void main(final String[] args)
   {
      final DrbNode input_node = fr.gael.drb.DrbFactory.open(args[0]);
      final XmlSchemaBuilder xsd_builder = new SdfSchemaBuilder();
      final XmlSchema xml_schema = xsd_builder.createSchema(input_node);

      fr.gael.drb.impl.xml.XmlWriter.writeXML(xml_schema.toNode(), System.out);
   }
} // SdfSchemaBuilder
