/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.value.Int;
import fr.gael.drb.value.Value;

/**
 * Declaration of an XML-Schema maxLength Facet.
 */
public class XsdMaxLengthFacet extends XsdFacet
{

   /**
    * maxLength facet name.
    */
   final static String TAG = "maxLength";

   /**
    * The maxLength value.
    */
   private int value;

   /**
    * Build a maxLength facet.
    * 
    * @param value the value
    */
   XsdMaxLengthFacet(final Value value)
   {
      this.value =
         ((fr.gael.drb.value.Int) value.convertTo(Value.INT_ID)).intValue();
   } // XsdMaxLengthFacet

   /**
    * Identifier of this facet.
    * 
    * @return Identifier of this facet.
    */
   public final int getId()
   {
      return MAX_LENGTH_ID;
   } // getId

   /**
    * The maxLength value
    * 
    * @return The maxLength value
    */
   public final Value getValue()
   {
      return new Int(this.value);
   } // getValue

   /**
    * The name of this facet.
    * 
    * @return The name of this facet.
    */
   public final String getName()
   {
      return TAG;
   } // getName

   // --------------------------------------------------------
   // ValueValidator interface implementation
   // --------------------------------------------------------
   /**
    * Validates the present value.
    * 
    * @param v The value
    * @return true if this value satifies the type definition, else false
    */
   public boolean isValid(final Value v)
   {
      if (v == null)
      {
         return true;
      }
      else if (v.getType() == Value.ARRAY_ID)
      {
         return ((fr.gael.drb.value.ValueArray) v).length() <= this.value;
      }
      else if (v.getType() == Value.STRING_ID)
      {
         return v.toString().length() <= this.value;
      }
      return false;
   }

} // XsdMaxLengthFacet class
