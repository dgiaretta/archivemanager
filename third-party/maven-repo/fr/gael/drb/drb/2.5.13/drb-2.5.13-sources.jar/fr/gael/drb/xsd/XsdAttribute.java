/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbNode;
import fr.gael.drb.value.Value;

/**
 * Declaration of a general XML-Schema attribute.
 */
public class XsdAttribute extends XsdComponent
{

   // =====================================================
   // Static part.
   // =====================================================
   /**
    * attribute tag.
    */
   final static String TAG = "attribute";

   /**
    * name tag.
    */
   final static String NAME_TAG = "name";

   /**
    * ref tag.
    */
   final static String REF_TAG = "ref";

   /**
    * type tag.
    */
   final static String TYPE_TAG = "type";

   /**
    * use tag.
    */
   final static String USE_TAG = "use";

   /**
    * default tag.
    */
   final static String DEFAULT_TAG = "default";

   /**
    * fixed tag.
    */
   final static String FIXED_TAG = "fixed";

   /**
    * optional use tag.
    */
   final static String OPTIONAL_USE_TAG = "optional";

   /**
    * required use tag.
    */
   final static String REQUIRED_USE_TAG = "required";

   /**
    * prohibited use tag.
    */
   final static String PROHIBITED_USE_TAG = "prohibited";

   /**
    * default use (optional).
    */
   final static int DEFAULT_USE = 1;

   /**
    * optional use.
    */
   final static int OPTIONAL_USE = 1;

   /**
    * required use.
    */
   final static int REQUIRED_USE = 2;

   /**
    * prohibited use.
    */
   final static int PROHIBITED_USE = 3;

   // ====================================================
   // Attributes part.
   // ====================================================
   /**
    * The name of this attribute.
    */
   private String name = null;

   /**
    * The type of this attribute.
    */
   private XsdSimpleType type = null;

   /**
    * The use of this attribute.
    */
   private int use = this.DEFAULT_USE;

   /**
    * The constraint value of this attribute.
    */
   private Value value = null;

   // ====================================================
   // Methods part.
   // ====================================================
   /**
    * Build an XML-Schema attribute.
    * 
    * @param name The attribut name
    * @param type The type
    */
   XsdAttribute(final String name, final XsdSimpleType type)
   {
      this(name, type, null, DEFAULT_USE);
   } // XsdAttribute

   /**
    * Build an XML-Schema attribute.
    * 
    * @param name The attribut name
    * @param type The type
    * @param value The value
    * @param use int
    */
   XsdAttribute(final String name, final XsdSimpleType type, final Value value,
         final int use)
   {
      this.name = name;
      this.type = type;
      this.value = value;
      this.use = use;
   } // XsdAttribute

   /**
    * Returns the name of this attribute.
    * 
    * @return The name
    */
   public final String getName()
   {
      return this.name;
   } // getName

   /**
    * Returns the type of this attribute.
    * 
    * @return The type
    */
   public final XsdSimpleType getType()
   {
      return this.type;
   } // getType

   /**
    * Returns the use of this attribute.
    * 
    * @return The use
    */
   public final int getUse()
   {
      return this.use;
   } // getUse

   /**
    * Returns the value constraint of this attribute.
    * 
    * @return The value
    */
   public final Value getValueConstraint()
   {
      return this.value;
   } // getValueConstraint

   // -------------------------------------------------------
   // XsdComponent class overloading
   // -------------------------------------------------------
   /**
    * Format this component into a string.
    * 
    * @return The node
    */
   DrbNode toNode()
   {
      return null;
   } // toNode

   // =======================================================
   // Unitary test part.
   // =======================================================
   /**
    * Makes this class runnable for testing.
    * 
    * @param args String[]
    */
   public static void main(final String[] args)
   {
      final XsdAtomicType floatType = new XsdAtomicType(Value.FLOAT_ID, null);
   } // main

} // XsdAttribute
