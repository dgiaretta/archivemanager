/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import fr.gael.drb.value.ValueArray;

/**
 * Generic implementation of DrbSequence. This default implementation extends an
 * ArrayList provided by Java API. It is a generic mean to create a list of
 * items. If no specific operations are required to implement the DrbSequence
 * (e.g. filtering, caching, hashing, etc.). This class is a simple way to
 * handle a collection of items. Note : the add() or equivalent operations of
 * the ArrayList class have not been overrided to insure they insert DrbItem
 * intances. Some inconsistency may appear * if no care is taken while calling
 * add() or equivalent operations.
 */
public class DrbDefaultSequence extends ArrayList<DrbItem> implements
      DrbSequence
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(DrbDefaultSequence.class);

   /**
    * The sequence of items
    */
   private List<DrbItem> itemList = this;

   /**
    * Builds an empty sequence.
    */
   public DrbDefaultSequence()
   {
      // this.itemList = new ArrayList();
      super();
   }

   /**
    * Build a singleton from a item.
    * 
    * @param item A reference to the singleton item.
    */
   public DrbDefaultSequence(final DrbItem item)
   {
      // this.itemList = new ArrayList(1);
      super(1);
      this.add(0, item);
   }

   /**
    * Duplicate an existing sequence
    * 
    * @param sequence A reference to the sequence to be duplicated.
    */
   public DrbDefaultSequence(final DrbSequence sequence)
   {
      // this.itemList = new ArrayList(sequence.itemList);
      super((sequence == null) ? 0 : sequence.getLength());
      if (sequence != null)
      {
         for (int index = 0; index < sequence.getLength(); index++)
         {
            this.add(index, sequence.getItem(index));
         }
      }
   }

   /**
    * Duplicate an existing sequence
    * 
    * @param sequence A reference to the sequence to be duplicated.
    */
   protected DrbDefaultSequence(final DrbDefaultSequence sequence)
   {
      // this.itemList = new ArrayList(sequence.itemList);
      super(sequence.itemList);
   }

   /**
    * The atomic values of this sequence. The value of the node means its
    * content. The value is expressed accoring to one of the types supported by
    * the fr.gael.drb.value package. Generally these types correspond to
    * primitive types (e.g. integer, floatting points etc.) or very low level
    * types (e.g. string, date, etc.).
    * 
    * @return A reference to the values of the sequence.
    */
   public ValueArray atomize()
   {
      return DrbAbstractSequence.atomize(this);
   }

   /**
    * Returns a specific item of the list. This operation wraps the
    * ArrayList.get() operation. The exception that ArrayList.get() can raise is
    * however traped and not propagated. In such case a message is written to
    * the error output and the operation returns null without throwing any
    * exception.
    * 
    * @param index The position of the item starting from 0 and not greater or
    *           equal to the item count in the list.
    * @return A reference to specified item or null if no such item.
    */
   public final DrbItem getItem(final int index)
   {
      if ((index < 0) || (index >= this.size()))
      {
         return null;
      }
      return this.get(index);
   } // getItem

   /**
    * The number of items in the list.
    * 
    * @return The number of items in the list.
    */
   public final int getLength()
   {
      return this.size();
   }

   /**
    * Inserts a item at a given position. The passed item is inserted in the
    * list of children at the given position The position is the expected index
    * of the item after insertion. All the previous item from the aimed position
    * to the end of the list are shift to the end of the new sequence (i.e.
    * their indices are shifted up of 1). If the given index is out of the
    * sequence bounds and therefore less than zero and greater or equal to the
    * current number of items,the operation raises an exception. An index equal
    * to the current number of item is allowed and the operation is therefore
    * equivalent to an append.
    * 
    * @param index The expected index of the item after the insertion.
    * @param item A reference to the item to be inserted.
    * @return A reference to the a sequence containing the inserted node.
    * @throws NullPointerException This exception is raised when the passed item
    *            a null reference. This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passe
    *            index is less than zero or if it is greater or equal to the
    *            number of item in the sequence prior the call
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested insertion for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbSequence addItem(final int index, final DrbItem item)
         throws NullPointerException, UnsupportedOperationException,
         IndexOutOfBoundsException
   {
      /**
       * Check parameters
       */
      if (item == null)
      {
         throw new NullPointerException(
               "DrbDefaultSequence.addItem() : cannot add a null item");
      }
      /**
       * Insert the item at the specified index.
       */
      this.itemList.add(index, item);

      return this;
   } // addItem

   /**
    * Appends an item at the end of the item list.
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to append a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Case of unordered or specifically ordered implementations:</b> If the
    * implementation does not support ordered children or has specific ordering
    * rules, the node may not be appended but only inserted according to these
    * rules. For instance it may not be possible to impose the file order in a
    * directory:it generally depends on the lexicographical order of the node
    * names or their creation date.
    * </p>
    * 
    * @param item A reference to the item to be appended.
    * @return A reference to the a sequence containing the appended node.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference.This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested append for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbSequence addItem(final DrbItem item) throws NullPointerException,
         UnsupportedOperationException
   {
      return this.addItem(this.getLength(), item);
   } // addItem

   /**
    * Removes an existing item. The item at the given index is removed from the
    * sequence of the current item. The item is not modified by this operation.
    * The index of the item to be removed has to correspond to an existing item
    * index. If the index is less than zero or greater or equal to the current
    * number of items, an exception is thrown.
    * 
    * @param index Index of the item to be removed.
    * @return A reference to the a sequence after the removal of the item.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested removal for any
    *            reason.
    */
   public DrbSequence removeItem(final int index)
         throws IndexOutOfBoundsException, UnsupportedOperationException
   {
      /**
       * Remove the item at the specified index.
       */
      this.itemList.remove(index);

      return this;
   }

   /**
    * Returns the string representation of this sequence
    * 
    * @return the sequence as a string
    */
   public java.lang.String toString()
   {
      java.lang.String str = "";

      for (int i = 0; i < this.getLength(); i++)
      {
         if (i != 0)
         {
            str += ", ";
         }

         str += this.getItem(i);
      }
      return str;
   }

   /**
    * Make this class runnable for testing.
    * 
    * @param args the arguments.
    */
   public static void main(final String[] args)
   {
      final fr.gael.drb.value.Float val = new fr.gael.drb.value.Float(2.0f);
      final DrbSequence singleton = new DrbDefaultSequence(val);
      System.out.println("$singleton=" + singleton);
      System.out.println("data($singleton)=" + singleton.atomize());

      final DrbDefaultSequence sequence = new DrbDefaultSequence();
      for (int i = 0; i < 3; i++)
      {
         sequence.addItem(new fr.gael.drb.value.Int(i));
      }
      System.out.println("$sequence=" + sequence);
      System.out.println("data($sequence)=" + sequence.atomize());

      final DrbSequence copy = new DrbDefaultSequence(sequence);
      System.out.println("$copy=" + copy);

   } // main

} // DrbDefaultSequence
