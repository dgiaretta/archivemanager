/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds.schema;

import fr.gael.drb.query.Query;
import fr.gael.drb.xsd.XsdElement;
import fr.gael.drb.xsd.XsdModelGroup;
import fr.gael.drb.xsd.XsdParticle;

/**
 * Declaration of an SDF particle.
 */
public abstract class SdfParticle
{
   // =========================================================================
   // Attributes part.
   // =========================================================================

   /**
    * The number of occurrence(s) of the described block. This class is used to
    * manage the different types of occurrence count : fixed or not. It permits
    * to retreive the value for any specific block occurrence.
    */
   protected SdfAttribute occurrenceCount;

   /**
    * The content length in bytes. This class is used to manage the different
    * types of length: fixed or not. It permits to retreive the value for any
    * specific block occurrence.
    */
   protected SdfLength contentLength;

   /**
    * Query to process in order to solve signature.
    */
   protected String signatureQuery;

   /**
    * Query object to use to process in order to solve signature.
    */
   protected Query signatureQueryObject;

   /**
    * The particle declaration.
    */
   protected XsdParticle particle;

   // =========================================================================
   // Methods part.
   // =========================================================================
   /**
    * Build a particle.
    * 
    * @param particle the particle declaration
    */
   protected SdfParticle(final XsdParticle particle)
   {
      this.particle = particle;
      if (particle.getMinOccurs() == particle.getMaxOccurs())
      {
         // this.occurrenceCount = new SdfAttribute(SdfAttribute.FIXED);
         // this.occurrenceCount.setValue(null, particle.getMinOccurs());
      }
      else
      {
         // this.occurrenceCount = new SdfAttribute(
         // SdfAttribute.VARIABLE);
      }
   }

   /**
    * Create an instance of SDF particle from a XSD component.
    * 
    * @param particle the particle declaration
    * @return a concrete instance of SDF particle.
    */
   protected static SdfParticle getInstance(final XsdParticle particle)
   {
      switch (particle.getTerm())
      {
         case XsdParticle.ELEMENT_TERM:
            return new SdfElement((XsdElement) particle);
         case XsdParticle.MODEL_GROUP_TERM:
            return new SdfModelGroup((XsdModelGroup) particle);
         default:
            return null;
      }
   }
} // SdfParticle
