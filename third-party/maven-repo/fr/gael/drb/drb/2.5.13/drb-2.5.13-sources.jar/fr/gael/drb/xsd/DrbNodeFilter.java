/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAbstractNode;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.value.Value;

/**
 * Generic node filtering interface. This interface represents a single node of
 * a tree of data. Any node can have no, one or several children. This interface
 * provides the primarily operations to browse an entire data structure. All
 * implementations of the "Data Request Broker" shall be able to produce shuch
 * nodes.
 */
class DrbNodeFilter extends DrbNodeImpl
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(DrbNodeFilter.class);

   /**
    * The baseNode node.
    */
   protected DrbNode baseNode;

   /**
    * Build an DrbNodeFilter instance.
    * 
    * @param baseNode The DrbNode
    */
   protected DrbNodeFilter(final DrbNode baseNode)
   {
      this.baseNode = baseNode;
   } // DrbNodeFilter

   /**
    * Returns the DrbNode baseNode.
    * 
    * @return DrbNode
    */
   public DrbNode getBase()
   {
      return this.baseNode;
   }

   /**
    * Closes this node and releases any system resources associated with the
    * pointed file. A closed node cannot perform input or output operations and
    * cannot be reopened.
    * 
    * @param deep if this flag is disabled,the implementation shall not release
    *           the ressources shared with the descendants.
    */
   public void close(final boolean deep)
   {
      // Only the root can be closed.
      // If the deep flag is not activated, we do not close the children
      if (this.baseNode instanceof DrbNodeImpl)
      {
         ((DrbNodeImpl) this.baseNode).close(deep);
      }
   }

   /**
    * Builds a getInstance from a base node. TODO : this operation shall raise
    * an exception in case of null parameter.
    * 
    * @param base_node The node to be wrapped. This parameter shall never be
    *           null.
    * @return DrbNodeFilter
    */
   protected DrbNodeFilter getInstance(final DrbNode base_node)
   {
      if (base_node == null)
      {
         return null;
      }
      return new DrbNodeFilter(base_node);
   }

   /**
    * Name of the node. Returns the name of the node.This name is the canonical
    * name of the node. It does not contains any prefix, path and location
    * part.This name clearly identifies the node in its parent depending only
    * from its occurence number and its index. All nodes provided by an
    * implementation is named. Therefore this operation never returns null
    * value. An empty string is however allowed if the node is unique (e.g. non
    * named root node).
    * 
    * @return The name of the node.
    */
   public String getName()
   {
      return this.baseNode.getName();
   }

   /**
    * Name of the node. Returns the name of the node.This name is the canonical
    * name of the node. It does not contains any prefix, path and location
    * part.This name clearly identifies the node in its parent depending only
    * from its occurence number and its index. All nodes provided by an
    * implementation is named. Therefore this operation never returns null
    * value. An empty string is however allowed if the node is unique (e.g. non
    * named root node).
    * 
    * @return The name of the node.
    */
   protected String getXPathName()
   {
      try
      {
         return this.getXPathName((DrbAbstractNode) this.baseNode);
      }
      catch (final ClassCastException e)
      {
         return super.getXPathName();
      }
   }

   /**
    * The full path of the node. The full path is the full path of the parent
    * node to witch is appended the name of the current node.
    * <p>
    * <b>Warning:</b> Because the occurence number of the current node is not
    * known in the parent, the occurence qualifier is not support by the current
    * implementation.A possible algorithm shall be to search a reference to the
    * current node in the list of children of the parent.
    * </p>
    * If no parent have already been set no absolute path is considered. A path
    * considering the current node has a root node is not valid for the factory
    * and is therefore not significant in the current implementation.
    * 
    * @return The absolute path of the current node.
    */
   public String getPath()
   {
      return this.baseNode.getPath();
   }

   /**
    * Index of the node. Returns the index of the node in its parent children
    * list. This index starts from 0 and takes into account all occurences of
    * nodes disregrading the type of nodes. If the node has not parent the index
    * may not be available: the operation returns therefore a negative value.
    * 
    * @return The index of the node or negative value.
    */
   public int getIndex()
   {
      return this.baseNode.getIndex();
   } // getIndex

   /**
    * Get namespace URI. The namespace URI of this node, or null if it is
    * unspecified. This is not a computed value that is the result of a
    * namespace lookup based on an examination of the namespace declarations in
    * scope. It is merely the namespace URI given at creation time. The
    * Namespaces on an attribute does not inherit its namespace from the element
    * it is attached to. If an attribute is not explicitly given a namespace, it
    * simply has no namespace.
    * 
    * @return The namspace URI or null if unspecified.
    */
   public String getNamespaceURI()
   {
      return this.baseNode.getNamespaceURI();
   }

   /**
    * Get the namespace bindings.
    * 
    * @return The namespace bindings.
    */
   public Namespace getNamespaceBindings()
   {
      try
      {
         return ((DrbAbstractNode) this.baseNode).getNamespaceBindings();
      }
      catch (final ClassCastException e)
      {
         return null;
      }
   }

   /**
    * The value type of the node. The value type is determined from the value
    * previously assigned to the node. If no speficic value has been previsouly
    * set, fr.gael.drb.value.Value.NULL_ID type is returned.
    * 
    * @return NULL_ID if the node does not provide value or any other valid type
    *         identifier otherwise.
    */
   public int getValueType()
   {
      return this.baseNode.getValueType();
   }

   /**
    * The value of the node. The value is the one previously set.
    * 
    * @return A reference to the value of the node or null if no value has
    *         already been set.
    */
   public Value getValue()
   {
      return this.baseNode.getValue();
   }

   /**
    * The attributes of the nodes. This operation returns a list of attribute
    * previously set (if any).
    * 
    * @return The list attributes of the current node or null if none.
    */
   public DrbAttributeList getAttributes()
   {
      return this.baseNode.getAttributes();
   }

   /**
    * The parent of this node. Returns a reference to the parent node of the
    * current node according to the current implementation. Most of the nodes
    * have a parent exept root nodes or if they have just been removed, etc. If
    * the node has no parent the operation returns null.
    * 
    * @return The parent of this node or null.
    */
   public DrbNode getParent()
   {
      return this.getInstance(this.baseNode.getParent());
   }

   /**
    * Checks if any child exists. Returns wheter the current node has at least a
    * child.
    * 
    * @return true if this node has any children, false otherwise.
    */
   public final boolean hasChild()
   {
      return this.baseNode.hasChild();
   }

   /**
    * Returns an occurence of child matching a specific name. The occurence
    * number starts from 1.
    * 
    * @param name The name to match.
    * @param occurence The occurence number of the desired child.
    * @return A reference to the child or null is not found.
    */
   public DrbNode getNamedChild(final String name, final int occurence)
   {
      /**
       * Checks parameters.
       */
      if ((name == null) || (occurence <= 0))
      {
         logger.error("DrbNodeFilter.getNamedChild(): Invalid parameters.");
         return null;
      }

      /**
       * General case.
       */
      return this.getInstance(this.baseNode.getNamedChild(name, occurence));
   }

   /**
    * Reference to the first child of the current node (directory). If the
    * current node has no child a null reference is returned.
    * 
    * @return A reference to the first child or null if no such node.
    */
   public final DrbNode getFirstChild()
   {
      /**
       * Returns the child at position 0. The created node benefit by the
       * children list as parent children list.
       */
      return this.getInstance(this.baseNode.getFirstChild());
   }

   /**
    * Reference to the last child of the current node (directory). If the
    * current node has no child a null reference if returned.
    * 
    * @return A reference to the last child or null if no such node.
    */
   public final DrbNode getLastChild()
   {
      /**
       * Returns the last element of the children list. The created node benefit
       * by the children list as parent children list.
       */
      return this.getInstance(this.baseNode.getLastChild());
   }

   /**
    * Reference to a specific child of the current node (directory). The child
    * is identified by its position (i.e. index or sequence number) in the
    * children list of this node.
    * 
    * @param index The position of the node to retreive starting from 0 and not
    *           greater or equal to the number of children.
    * @return A reference to specified child or null if no such node.
    */
   public final DrbNode getChildAt(final int index)
   {
      /**
       * Returns the "index"th element of the children list. The created node
       * benefit by the children list as parent children list.
       */
      return this.getInstance(this.baseNode.getChildAt(index));
   }

   /**
    * The list of children of the current node. Returns a list of references to
    * the children of the current node. The current node may have no child and
    * the operation returns therefore a null reference.
    * 
    * @return The list of children if any null otherwise.
    */
   public DrbNodeList getChildren()
   {
      /**
       * Retrieve the base children.
       */
      DrbNodeList children = this.baseNode.getChildren();
      if (children == null)
      {
         children = this.baseNode.getChildren();
      }
      if ((children == null) || (children.getLength() == 0))
      {
         return null;
      }

      final DrbDefaultNodeList list = new DrbDefaultNodeList();

      /**
       * Initialize the output node list. The nodes are created benefiting from
       * the children list as parent children list of the created nodes.
       */
      for (int inode = 0; inode < children.getLength(); inode++)
      {
         list.add(this.getInstance(children.item(inode)));
      }

      return list;
   }

   /**
    * The content of the current node. Returns a sequence of nodes and atomic
    * values.
    * 
    * @return The content of this node.
    */
   public DrbSequence getContent()
   {
      /**
       * Retrieve the base content.
       */
      DrbSequence content = null;
      if (this.baseNode instanceof DrbAbstractNode)
      {
         content = ((DrbAbstractNode) this.baseNode).getContent();
      }
      else
      {
         return super.getContent();
      }
      if ((content == null) || (content.getLength() == 0))
      {
         return null;
      }

      final DrbDefaultSequence list = new DrbDefaultSequence();

      /**
       * Initialize the output node list. The nodes are created benefiting from
       * the children list as parent children list of the created nodes.
       */
      for (int inode = 0; inode < content.getLength(); inode++)
      {
         final DrbItem item = content.getItem(inode);
         if (item.getItemType() == DrbItem.NODE_ITEM)
         {
            list.addItem(this.getInstance((DrbNode) item));
         }
         else
         {
            list.addItem(item);
         }
      }

      return list;
   }

   /**
    * Number of files or directory hold by the current node (directory). Returns
    * the number of children belonging to the current node.
    * 
    * @return The number of children of the current node (directory).
    */
   public final int getChildrenCount()
   {
      return this.baseNode.getChildrenCount();
   }

   /**
    * Previous sibling of the current file or directory. The sibling is
    * retreived from the parent children list. The previous sibling may not
    * exist if the current node is the root or if it is the first file or
    * directory.
    * 
    * @return A reference to the previous sibling or null if no such node.
    */
   public DrbNode getPreviousSibling()
   {
      return this.getInstance(this.baseNode.getPreviousSibling());
   }

   /**
    * Next sibling of the current file or directory. The sibling is retreived
    * from the parent children list. The next sibling may not exist if the
    * current node is the root or if it is the last file or directory.
    * 
    * @return A reference to the next sibling or null if no such node.
    */
   public DrbNode getNextSibling()
   {
      return this.getInstance(this.baseNode.getNextSibling());
   }

   // -------------------------------------------------------------------------
   // Mutable methods
   // -------------------------------------------------------------------------
   /**
    * Changes the name of the node. The passed name may be an empty string but
    * never a null reference. The change is persistant such as further instance
    * of a same node (even in different sessions) will have this new name. If
    * the implementation does not suppot the rename operation it is supposerd to
    * throw a UnsupportedOperationException.
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current standing also as the source of the event. The called
    * opetation is the nodesChanged() of the listeners.
    * </p>
    * 
    * @param name Reference to the new name.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested rename for any
    *            reason (e.g. specific case or general incapability).
    * @throws NullPointerException This exception is raised when the passed name
    *            is a null reference. This exception may be overriden by an
    *            UnsupportedOperationException.
    */
   public void rename(final String name) throws NullPointerException,
         UnsupportedOperationException
   {
      this.baseNode.rename(name);
   }

   /**
    * Changes the value of the node. This operation sets a new value of the
    * current node.The value type of the node shall be compatible with the node
    * implementation. If the type does not match exactly it is casted to a
    * compatible one based on the the fr.gael.drb.value capabilities. A
    * reference to the effectivelly assigned value is returned by the operation
    * so it is possible to check if a cast has been performed and therefore
    * assess the accuracy of the assignement. If the cast is not possible the
    * operation raises an UnsupportedOperationException. If the assignment is
    * possible and the node implementation has a physical representation the
    * value is updated in the physical source in order to persist among
    * sessions. It therefore possible that this operation consumses an variable
    * time.
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept value changes. For instance it may not be possible to change the
    * value of a file directory that has no immediate signification.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node changed event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node. The called operation is
    * the nodesChanged() of the listeners.
    * </p>
    * 
    * @param value The new value of the node. This value shall not be null.
    * @return The effectivelly assigned value. The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested assignment for
    *            any reason.
    */
   public Value setValue(final Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      return this.baseNode.setValue(value);
   }

   /**
    * Set the attribute list of a node. If some attributes are already attached
    * to the current node they are first removed and then replaced by the new
    * ones. However the operation checks the compatibility of the passed
    * attribute according to the current implementation. The operation does
    * nothing if the compatibility check fails.
    * <p>
    * <b>Warning:</b> The input attributes may be duplicated or re-instanciated
    * according to the targetted implementation. References to the effectively
    * inserted attributes can be reteived from the getAttributes() operation of
    * the DrbNode. It is highly recommended to discard the references to the
    * input attribuets if not mandatory.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept attribute changes. For instance it may not be possible to change
    * the size attribute of a file through this operation with would meant a
    * effective file resize that is not really relevant without additional data.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node. The called operation is
    * the nodesChanged() of the listeners.
    * </p>
    * 
    * @param attributes A reference to the new attribute list.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the attribute list is null. This exception may be
    *            overriden by an UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested attribute changes
    *            for any reason.
    */
   public void setAttributes(final DrbAttributeList attributes)
         throws NullPointerException, UnsupportedOperationException
   {
      this.baseNode.setAttributes(attributes);
   }

   /**
    * Sets a namespace resource identifier. The new namespace identifier shall
    * not be null.
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept namespace changes. For instance it may not be possible to change
    * the namespace of a file that is basically fixed.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node.The called operation is the
    * nodesChanged() of the listeners.
    * </p>
    * 
    * @param namespace_uri A reference to the new namespace identifier.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the new namespace identifier is null.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested namespace change
    *            for any reason (e.g. by definition or in the specific case).
    */
   public void setNamespaceURI(final String namespace_uri)
         throws NullPointerException, UnsupportedOperationException
   {
      this.baseNode.setNamespaceURI(namespace_uri);
   }

   /**
    * Inserts a child at a given position. The passed node is inserted in the
    * list of children at the given position The position is the expected index
    * of the node after insertion. All the previous children from the aimed
    * position to the end of the list are shift to the end of the new children
    * list (i.e. their indices are shifted up of 1). If the given index is out
    * of the children bounds and therefore less than zero and greater or equal
    * to the current number of children,the operation raises an exception. An
    * index equal to the current number of children is allowed and the operation
    * is therefore equivalent to appendChild().
    * <p>
    * If the node has been inserted within the children list, the next sibling
    * indicies are increased of one. In addition the assiociations between the
    * inserted node and it previous and next siblings are updated (if any).
    * </p>
    * <p>
    * <b>Warning:</b> The inserted node may be duplicated or re-instanciated
    * according to the targetted implementation. A reference to the effectively
    * inserted node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned node.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to insert a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Case of unordered or specifically ordered implementations:</b> If the
    * implementation does not support ordered children or has specific ordering
    * rules, the node is inserted without taking into account the requested
    * index passed in parameter. For instance it may not be possible to impose
    * the file order in a directory: it generally depends on the lexicographical
    * order of the node names or their creation date.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the inserted node and the source is the current node. The called
    * operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param node A reference to the node to be inserted.
    * @param index The expected index of the node after the insertion.
    * @return A reference to the effectively inserted node. This reference may
    *         differ from the input one.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference. This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or if it is greater or equal to the
    *            number of children in the number of children prior the call.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested insertion for any
    *            reason(e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbNode insertChild(final DrbNode node, final int index)
         throws NullPointerException, UnsupportedOperationException,
         IndexOutOfBoundsException
   {
      return this.getInstance(this.baseNode.insertChild(node, index));
   } // insertChild

   /**
    * Appends a child at the end of the children list. The passed node is
    * inserted in the list of children at the end of the current list.
    * <p>
    * <b>Warning:</b> The appended node may be duplicated or re-instanciated
    * according to the targetted implementation. A reference to the effectively
    * appended node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned node.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to append a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Case of unordered or specifically ordered implementations:</b> If the
    * implementation does not support ordered children or has specific ordering
    * rules, the node may not be appended but only inserted according to these
    * rules. For instance it may not be possible to impose the file order in a
    * directory:it generally depends on the lexicographical order of the node
    * names or their creation date.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the appended node and the source is the current node. The called
    * operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param node A reference to the node to be appended.
    * @return A reference to the effectivelly appended node. This reference may
    *         differ from the input one.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference.This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested append for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbNode appendChild(final DrbNode node) throws NullPointerException,
         UnsupportedOperationException
   {
      return this.getInstance(this.baseNode.appendChild(node));
   } // appendChild

   /**
    * Replaces a child of the current node. This operation replaces a child in
    * the current children list by a new one The operation aborts when the index
    * is out of bound (index < 0 || index > size). In case of error, the
    * implementation has to restore the initial situation. It is therefore
    * recommended for any implementation to check the consistency prior to
    * perform the replacement.
    * <p>
    * <b>Warning:</b> The replacing node may be duplicated or re-instanciated
    * according to the targetted implementation.A reference to the effectively
    * replacing node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned one.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to insert a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the new node and the source is the current node.The called operation is
    * the structureChanged() of the listeners.
    * </p>
    * 
    * @param index Index of the node to be replaced. This index starts at 0 and
    *           shall be less than the number of children.
    * @param new_node A reference to the node that replaces the old one.
    * @return A reference to the effectivelly replacing node.This reference may
    *         differ from the new_node parameter.
    * @throws NullPointerException This exception is raised when the reference
    *            to the new node is null. This exception may be overriden by a
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested replace for any
    *            reason. In addition if the old_node is not retreived in the
    *            current children list, this exception is also raised.
    */
   public DrbNode replaceChild(final int index, final DrbNode new_node)
         throws NullPointerException, IndexOutOfBoundsException,
         UnsupportedOperationException
   {
      return this.getInstance(this.baseNode.replaceChild(index, new_node));
   }

   /**
    * Removes an existing child. The child at the given index is removed from
    * the children list of the current node. The child is not modified by this
    * operation. At the child point of view it keeps the same parent or any
    * common association depending on the implementation. However at the parent
    * (i.e. the current node) point of view the removed node is completely
    * dismissed and will never be re-instaciated from constructor operations
    * (e.g. getFirstChild(), etc. ). The index of the child to be removed has to
    * correspond to an existing children index. If the index is less than zero
    * or greater or equal to the current number of children, an exception is
    * thrown.
    * <p>
    * This operation takes into account the removal by updating the sibling
    * associations of the children nodes prior and next to the removed one. The
    * indicies of the nodes next to the removed one are decresed of one. Their
    * parents as well as their contents are left unchanged.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the removed node and the source is the current node.The called
    * operation is the nodesRemoved() of the listeners.
    * </p>
    * 
    * @param index Index of the child to be removed.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested removal for any
    *            reason.
    */
   public void removeChild(final int index) throws IndexOutOfBoundsException,
         UnsupportedOperationException
   {
      this.baseNode.removeChild(index);
   }

   /**
    * Tests if a specific interface can be provided. This operations tests with
    * a minimum of time and memory consumption if the current implementation can
    * provide a specific interface. It important to consider that hasImpl()
    * provides information about the ability to provide such interface in
    * general cases but not focused on the current instance. It may therefore be
    * impossible to get a specific implementation from a node whereas hasImpl()
    * operation returns true.
    * 
    * @param api The class type to test.
    * @return true if an implementation of the interface can be provided and
    *         false otherwise.
    */
   public boolean hasImpl(final Class api)
   {
      if (this.baseNode instanceof DrbNodeImpl)
      {
         return ((DrbNodeImpl) this.baseNode).hasImpl(api);
      }
      else
      {
         return super.hasImpl(api);
      }
   }

   /**
    * Returns a specific implementation. This operation returns a reference to
    * an object implementing a specific interface. This mean is useful to
    * benefit by a specific and direct API instead of using the DrbNode
    * interface. The provided object shall represent the current node such as it
    * is possible after a call to this operation, to dismiss the reference to
    * the node. For instance, a file is usually wrapped as a drb.imple.file.File
    * class and thanks to this operation can be seen as a InputStream anabling
    * direct access to the handled file.
    * 
    * @param api The interface (or class) to be provided.
    * @return A reference to the object implementing the interface or a null
    *         reference otherwise.
    */
   public Object getImpl(final Class api)
   {
      if (this.baseNode instanceof DrbNodeImpl)
      {
         return ((DrbNodeImpl) this.baseNode).getImpl(api);
      }
      else
      {
         return super.getImpl(api);
      }
   }

}// DrbNodeFilter
