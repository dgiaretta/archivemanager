/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import java.util.ArrayList;

/**
 * Output of the XML-Schema validator.
 */
abstract class XsdAbstractInvalid implements XsdInvalid
{
   /**
    * The invalid status.
    */
   int status = XsdInvalid.NONE;

   // =======================================================================
   // Attributes part.
   // =======================================================================
   /**
    * The invalid children list.
    */
   private ArrayList children = new ArrayList();

   // =====================================================================
   // Methods
   // ======================================================================
   /**
    * Add a sub-message.
    * 
    * @param child The child to be added
    */
   void add(final XsdInvalid child)
   {
      if (child != null)
      {
         this.children.add(child);
      }
   } // add

   /**
    * Remove a sub-message.
    * 
    * @param child The child to be removed
    */
   void remove(final XsdInvalid child)
   {
      if (child != null)
      {
         this.children.remove(child);
      }
   } // remove

   /**
    * Replace the status describing this validation result.
    * 
    * @param status The status
    */
   public void setStatus(final int status)
   {
      this.status = status;
   } // setStatus

   /**
    * Make this result printable.
    * 
    * @return The string message
    */
   public String toString()
   {
      return this.getMessage();
   }

   // ------------------------------------------------------------------------
   // XsdInvalid interface implementation
   // ------------------------------------------------------------------------
   /**
    * Returns a message describing the validation result.
    * 
    * @return The string message describing the validation result.
    */
   abstract public String getMessage();

   /**
    * Returns a status describing the validation result.
    * 
    * @return The status
    */
   public int getStatus()
   {
      return this.status;
   } // getStatus

   /**
    * Returns the children message.
    * 
    * @return The children message
    */
   public XsdInvalid[] getChildren()
   {
      final XsdInvalid[] childList = new XsdInvalid[this.children.size()];
      this.children.toArray(childList);
      return childList;
   } // getChildren

} // XsdAbstractInvalid
