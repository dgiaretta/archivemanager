/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import org.apache.log4j.Logger;

/**
 * A map entry used as element of IntMap. This entry is a key-value pair. The
 * key is an array of int and the value is an int. For instance it is used to
 * store a value such as an offset for a specific path in a tree. In this case
 * the key represents the path in the tree.
 */
final class IntMapEntry
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(IntMapEntry.class);

   /**
    * Key of the map entry. It is an array containing the occurrence indexes of
    * the block and all its ancestors up to the root block of the structured
    * file. Root index is omitted because it's always 0. Values start from 0 for
    * the first index. The number of indexes corresponds to the depth in the
    * tree, having depth=0 for the root block.
    */
   private int[] key;

   /**
    * Value of the map entry. Int value correponding to the key.
    */
   private int value;

   /**
    * Create a IntMapEntry instance with a key and a value. The key must be not
    * null.
    * 
    * @param key The key of the map entry.
    * @param value The value of the map entry.
    */
   protected IntMapEntry(final int[] key, final int value)
   {
      // Check parameters
      if (key == null)
      {
         this.logger.error("IntMapEntry.IntMapEntry() ERROR: "
               + "Invalid parameter.");
         this.logger.error("   key = null");
      }

      // Set the values
      this.key = key;
      this.value = value;
   }

   /**
    * Returns the key of the map entry.
    * 
    * @return The key of the map entry.
    */
   protected final int[] getKey()
   {
      return this.key;
   }

   /**
    * Returns the value of the map entry.
    * 
    * @return The value of the map entry.
    */
   protected final int getValue()
   {
      return this.value;
   }

   /**
    * Print the key-value pair info into a string. For instance it can returns
    * "[{3 41 6} 50]" if key={3,41,6} and value=50.
    * 
    * @return The string containing key-value pair info.
    */
   public final String toString()
   {
      // Test parameter
      if (this.key == null)
      {
         return null;
      }

      // Print the key content
      String info = "[" + IntMap.keyToString(this.key) + " ";

      // Print the value and return info string
      info = info + this.value + "]";
      return info;
   }

   /**
    * Main operation used for unitary tests.
    * 
    * @param args String[]
    */
   public static void main(final String[] args)
   {
      final IntMapEntry e1 = new IntMapEntry(new int[] {}, 12);
      final IntMapEntry e2 = new IntMapEntry(new int[] { 1, 4 }, 33);
      final IntMapEntry e3 = new IntMapEntry(new int[] { 1, 4, 2 }, 7);

      System.out.println("e1 = " + e1);
      System.out.println("e2 = " + e2);
      System.out.println("e3 = " + e3);
      System.out.println("e3.getKey().length = " + e3.getKey().length);
      System.out.println("e3.getValue() = " + e3.getValue());
      System.out.println("e1.getValue() = " + e1.getValue());
      System.out.println("e2.getValue() = " + e2.getValue());
   }
}
