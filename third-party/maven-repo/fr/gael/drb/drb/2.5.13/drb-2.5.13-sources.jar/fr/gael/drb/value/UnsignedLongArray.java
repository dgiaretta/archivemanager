/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

// TODO: The comments of the opreation shall be separated from the javadoc
// attributes (e.g. @param) with an empty line.
// TODO: All operation are not commented. This class is public and therefore,
// the documentation is essential.
/**
 * The UnsignedLongArray class is a generic wrapper for unsigned long array
 * values.
 */
public class UnsignedLongArray extends AbstractNumericArray implements
      ValueFormat
{
   // ==========================================================================
   // Attributes part.
   // ==========================================================================
   /**
    * The unsigned long priority.
    */
   final static int PRIORITY = 4;

   /**
    * The unsigned long value.
    */
   private long[] value;

   /**
    * Constructs a UnsignedLongArray object initialized to the specified long[]
    * value.
    * 
    * @param v the value of the UnsignedLongArray.
    */
   public UnsignedLongArray(final long[] v)
   {
      this.value = new long[v.length];
      System.arraycopy(v, 0, this.value, 0, v.length);
   }

   /**
    * Constructs an UnsignedLongArray object with the specified length.
    * 
    * @param size the length of the LongArray.
    */
   public UnsignedLongArray(final int size)
   {
      this.value = new long[size];
   }

   /**
    * Returns the underlying object for optimization.    
    * @return a backing array.
    */
   public final long[] getData()
   {
      return this.value;
   }

   /**
    * Return a string containing the value with a fixed format.
    * 
    * @param length The expected length of the output string
    * @return The formatted string.
    */
   public java.lang.String getFormattedString(final int length)
   {
      java.lang.String str = "";
      for (int i = 0; i < this.length(); i++)
      {
         str = str + new Long(this.value[i]).getFormattedString(8);
      }
      return str;
   }

   /**
    * Return a byte buffer containing the value in a fixed format.
    * 
    * @return The formatted buffer.
    */
   public final byte[] getFormattedBuffer()
   {
      final byte[] buffer = new byte[8 * this.length()];
      for (int i = 0; i < this.length(); i++)
      {
         final long long_value = this.value[i];
         buffer[8 * i + 0] = (byte) (long_value >>> 56);
         buffer[8 * i + 1] = (byte) (long_value >>> 48);
         buffer[8 * i + 2] = (byte) (long_value >>> 40);
         buffer[8 * i + 3] = (byte) (long_value >>> 32);
         buffer[8 * i + 4] = (byte) (long_value >>> 24);
         buffer[8 * i + 5] = (byte) (long_value >>> 16);
         buffer[8 * i + 6] = (byte) (long_value >>> 8);
         buffer[8 * i + 7] = (byte) (long_value);
      }
      return buffer;
   }

   /**
    * The type identifier of this UnsignedLongArray value.
    * 
    * @return an identifier of the array type, namely ARRAY_ID
    */
   public final int getType()
   {
      return Value.ARRAY_ID;
   }

   /**
    * Returns the UnsignedLongArray priority
    * 
    * @return the UnsignedLongArray priority
    */
   public final int getPriority()
   {
      return PRIORITY;
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself is returned. If the conversion is not allowed a
    * ClassCastException is thrown. The types supported are ARRAY_ID and
    * STRING_ID.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException the conversion is impossible.
    */
   public final Value convertTo(final int type) throws ClassCastException
   {
      if (type == ARRAY_ID)
      {
         return this;
      }

      if (type == STRING_ID)
      {
         return new String(this.toString());
      }

      throw new ClassCastException();
   }

   /**
    * Assign a new Value. An implicit conversion may be performed to make the
    * assignment. The value must be a NumericArray otherwise a
    * ClassCastException is thrown. This assignment may result in a loss of
    * precision (ex : float[] to long[]).
    * 
    * @param v the value to be assigned.
    * @throws ClassCastException the conversion is impossible.
    */
   public final void assign(final Value v) throws ClassCastException
   {
      final NumericArray b = (NumericArray) v;
      this.value = new long[b.length()];
      for (int i = 0; i < this.length(); i++)
      {
         this.value[i] = b.longValue(i);
      }
   }

   // --------------------------------------------------------------------------
   // ValueArray interface implementation
   // --------------------------------------------------------------------------
   /**
    * The type of the values embedded in the array.
    * 
    * @return an identifier of the element type.
    */
   public final int getArrayType()
   {
      return Value.UNSIGNED_LONG_ID;
   }

   /**
    * The value of the element located at the specified index.
    * ArrayIndexOutOfBoundException is thrown if the index is out of bound.
    * 
    * @param index position where to retrieve the value.
    * @return The element located at the index.
    */
   public final Value getElement(final int index)
   {
      return new UnsignedLong(this.value[index]);
   }

   /**
    * Replace the element at the specified position in the array with the
    * specified element.
    * 
    * @param index index of element to replace.
    * @param element element to be stored at the specified position.
    */
   public final void assign(final int index, Value element)
   {
      element = element.convertTo(Value.NUMERIC_ID);
      this.value[index] = ((Numeric) element).longValue();
   }

   /**
    * Returns the number of elements in this array.
    * 
    * @return the number of elements in this array.
    */
   public final int length()
   {
      return this.value.length;
   }

   // --------------------------------------------------------------------------
   // NumericArray interface implementation
   // --------------------------------------------------------------------------

   /**
    * Returns this value as a boolean.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type boolean.
    */
   public final boolean booleanValue(final int index)
   {
      return this.value[index] != 0;
   }

   /**
    * Returns this value as a byte (signed 8 bits).
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type byte.
    */
   public final byte byteValue(final int index)
   {
      return (byte) (this.value[index]);
   }

   /**
    * Returns this value as an integer (signed 32 bits). The conversion may
    * result in a loss of precision.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type int.
    */
   public final int intValue(final int index)
   {
      return (int) (this.value[index]);
   }

   /**
    * Returns this value as a long integer (signed 64 bits). The conversion may
    * result in a loss of precision.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type long.
    */
   public final long longValue(final int index)
   {
      return (this.value[index]);
   }

   /**
    * Returns this value as a short integer (signed 16 bits). The conversion may
    * result in a loss of precision.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type short.
    */
   public final short shortValue(final int index)
   {
      return (short) (this.value[index]);
   }

   /**
    * Returns this value as a float (signed 32 bits IEEE 754).
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type float.
    */
   public final float floatValue(final int index)
   {
      return (this.value[index]);
   }

   /**
    * Returns this value as a double
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type double.
    */
   public final double doubleValue(final int index)
   {
      return (this.value[index]);
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a boolean.
    */
   public final void assign(final int index, final boolean value)
   {
      this.value[index] = (value ? 1 : 0);
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a double.
    */
   public final void assign(final int index, final byte value)
   {
      this.value[index] = value;
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a int.
    */
   public final void assign(final int index, final int value)
   {
      this.value[index] = value;
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a short.
    */
   public final void assign(final int index, final short value)
   {
      this.value[index] = value;
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a long.
    */
   public final void assign(final int index, final long value)
   {
      this.value[index] = value;
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a float.
    */
   public final void assign(final int index, final float value)
   {
      this.value[index] = (long) value;
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param value value to assign as a doubl..
    */
   public final void assign(final int index, final double value)
   {
      this.value[index] = (long) value;
   }

   /**
    * Returns the String representation of this object
    * 
    * @return the String representation of this object
    */
   public java.lang.String toString()
   {
      final StringBuffer strbuf = new StringBuffer(this.value.length * 3);
      for (int i = 0; i < this.value.length; i++)
      {
         if (i != 0)
         {
            strbuf.append(" ");
         }
         strbuf.append(UnsignedLong.toString(this.value[i]));
      }
      return strbuf.toString();
   }
}
