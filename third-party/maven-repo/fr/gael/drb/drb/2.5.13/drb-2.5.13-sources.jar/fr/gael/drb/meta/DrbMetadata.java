/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.meta;

import fr.gael.drb.value.Value;

/**
 * Generic metadata interface.
 */
public interface DrbMetadata
{
   /**
    * Human description of the pointed ressource.
    * 
    * @return String the description
    */
   public String getDescription();

   /**
    * Get the media type of the pointed ressource. The media type is usually
    * expressed as a MIME identifier containing two parts.
    * 
    * @return The media type or null if unspecified.
    */
   public String getMediaType();

   /**
    * Get the typename of the pointed ressource.
    * 
    * @return The type name or null if unspecified.
    */
   public String getTypename();

   /**
    * Get the value of a named property. The value is expressed according to one
    * of the types supported by the fr.gael.drb.value package. Generally these
    * types correspond to primitive types (e.g. integer, floating points, etc.)
    * or very low level types (e.g. string, date, etc.). On the contrary to DOM
    * implementation all the types are allowed even the arrays, date etc. Only
    * the Value.NULL_ID type is forbidden.
    * 
    * @param name the string
    * @return The value of the property.
    */
   public Value getProperty(String name);
} // DrbMetadata
