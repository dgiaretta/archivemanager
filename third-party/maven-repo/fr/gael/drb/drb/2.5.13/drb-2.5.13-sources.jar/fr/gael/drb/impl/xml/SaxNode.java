/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.xml;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.xml.sax.InputSource;

import fr.gael.drb.DrbAbstractNode;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.DrbNodesChangeEvent;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.value.Value;
import fr.gael.drb.xsd.Namespace;

/**
 * SAX node implementation. It allows to browse the XML documents with the Data
 * Request Broker API.
 */
class SaxNode extends DrbNodeImpl
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(SaxNode.class);

   /**
    * The document.
    */
   private SaxDocument document;

   /**
    * parent
    */
   protected SaxNode parent;

   /**
    * The XML tag.
    */
   protected SaxElementTag tag;

   /**
    * The node depth.
    */
   protected int depth;

   /**
    * The value.
    */
   protected Value value;

   /**
    * The attributes.
    */
   protected DrbAttributeList attributes;

   /**
    * The child nodes.
    */
   protected ArrayList children;

   /**
    * The namespace bindings.
    */
   protected Namespace namespace;

   /**
    * Flag.
    */
   protected boolean loaded = false;

   /**
    * Builds the root element.
    * 
    * @param document the XML document.
    */
   protected SaxNode(final SaxDocument document)
   {
      this.document = document;
      this.depth = 0;
      this.tag = new SaxElementTag();
      this.tag.index = 0;
      this.parent = null;
      this.load();
   }

   /**
    * Builds a child element.
    * 
    * @param parent A reference to the parent node.
    * @param index the index of this node.
    */
   protected SaxNode(final SaxNode parent, final int index)
   {
      this.document = parent.document;
      this.parent = parent;
      this.depth = parent.depth + 1;
      this.tag = parent.getTagAt(index);
      this.loaded = false;
   }

   /**
    * Returns a children tag.
    * 
    * @param index The position of the child block to retreive starting from 0
    *           and not greater or equal to the number of children.
    */
   protected SaxElementTag getTagAt(final int index)
   {
      return (SaxElementTag) this.children.get(index);
   }

   /**
    * Returns the number of child tags.
    */
   protected int getTagCount()
   {
      if (this.loaded)
      {
         return this.children.size();
      }
      else
      {
         return 0;
      }
   }

   /**
    * Indicates whether this node is "equal to" to another node. See
    * Object.equals() for the general contract of this method.
    * 
    * @param obj another value.
    * @return true if this object is the same as the obj argument
    */
   public boolean equals(final Object obj)
   {
      // Check reference equality
      if (this == obj)
      {
         return true;
      }

      // Check I/O
      if (obj instanceof SaxNode)
      {
         final SaxNode sax_node = (SaxNode) obj;
         if ((this.document != sax_node.document)
               || (this.depth != sax_node.depth))
         {
            return false;
         }
         SaxNode self_ancestor = this;
         SaxNode other_ancestor = sax_node;

         while (self_ancestor != other_ancestor)
         {
            if (self_ancestor.tag.index != other_ancestor.tag.index)
            {
               return false;
            }
            self_ancestor = self_ancestor.parent;
            other_ancestor = other_ancestor.parent;
         }
         return true;
      }

      // Otherwise the object is different
      return false;
   } // equals

   /**
    * Load this node.
    */
   private boolean load()
   {
      if (this.loaded)
      {
         return true;
      }

      final InputStream input_stream =
         (InputStream) this.document.getImpl(InputStream.class);

      if (input_stream == null)
      {
         return false;
      }

      final SaxInputStream sax_stream = new SaxInputStream(input_stream, this);

      /**
       * Parse the input stream as an XML file.
       */
      try
      {
         final SAXParserFactory builder_factory =
            SAXParserFactory.newInstance();
         builder_factory.setNamespaceAware(true);
         final SAXParser sax_parser = builder_factory.newSAXParser();

         final InputSource source = new InputSource(sax_stream);
         
         // Assign system identifier of the input source
         final String system_identifier = this.document.getPath();
         if (system_identifier != null)
         {
            source.setSystemId(system_identifier);
         }
         
         final SaxHandler handler = new SaxHandler(this, sax_stream);
         sax_parser.setProperty(
               "http://xml.org/sax/properties/lexical-handler", handler);
         sax_parser.getXMLReader().setFeature(
               "http://xml.org/sax/features/namespace-prefixes", true);
         sax_parser.parse(source, handler);
         input_stream.close();
         this.loaded = true;
      }
      catch (final IOException e)
      {
         logger.error("fr.gael.drb.impl.xml.SaxNode(input_stream) : Warning : "
               + "Document cannot be parsed.");
         logger.error("fr.gael.drb.impl.xml.SaxNode(input_stream) : Warning : "
               + e.getMessage());
         return false;
      }
      catch (final javax.xml.parsers.ParserConfigurationException e)
      {
         logger.error("fr.gael.drb.impl.xml.SaxNode(input_stream) : Warning : "
               + "Document cannot be parsed.");
         logger.error("fr.gael.drb.impl.xml.SaxNode(input_stream) : Warning : "
               + e.getMessage());
         return false;
      }
      catch (final org.xml.sax.SAXException e)
      {
         logger.error("fr.gael.drb.impl.xml.SaxNode(input_stream) : Warning : "
               + "Document cannot be parsed.");
         logger.error("fr.gael.drb.impl.xml.SaxNode(input_stream) : Warning : "
               + e.getMessage());
         return false;
      }
      return this.loaded;
   }

   /**
    * Name of the node. Read accessor to the previously set node name. The name
    * is never null but may be an empty string.
    * 
    * @return The name of the node.
    */
   public String getName()
   {
      return this.tag.name;
   } // getName

   /**
    * Get namespace URI.
    * 
    * @return The namspace URI previsouly set or null if unspecified.
    */
   public String getNamespaceURI()
   {
      if ("".equals(this.tag.namespaceURI))
      {
         return null;
      }
      return this.tag.namespaceURI;
   } // getNamespaceURI

   /**
    * Get the namespace bindings.
    * 
    * @return The namespace bindings.
    */
   public Namespace getNamespaceBindings()
   {
      this.load();
      return this.namespace;
   }

   /**
    * Returns the index of the node. The index is the sequential position of the
    * current node in its parent children list.
    * 
    * @return The index of the current node in its parent children list.
    */
   public int getIndex()
   {
      return this.tag.index;
   } // getIndex

   /**
    * The value type of the node. The value type is determined from the value
    * previously assigned to the node. If no speficic value has been previsouly
    * set, fr.gael.drb.value.Value.NULL_ID type is returned.
    * 
    * @return NULL_ID if the node does not provide value or any other valid type
    *         identifier otherwise.
    */
   public int getValueType()
   {
      return Value.STRING_ID;
   } // getValueType

   /**
    * The value of the node. The value is the one previously set.
    * 
    * @return A reference to the value of the node or null if no value has
    *         already been set.
    */
   public Value getValue()
   {
      if (!this.loaded)
      {
         this.load();
      }
      return this.value;
   } // getValue

   /**
    * The attributes of the nodes. This operation returns a list of attribute
    * previously set (if any).
    * 
    * @return The list attributes of the current node or null if none.
    */
   public DrbAttributeList getAttributes()
   {
      if (!this.loaded)
      {
         this.load();
      }

      return this.attributes;
   } // getAttributes

   /**
    * The parent of this node. Returns a reference to the parent node set
    * previously.
    * 
    * @return The parent of this node or null.
    */
   public DrbNode getParent()
   {
      if (this.parent == null)
      {
         return this.document;
      }
      else
      {
         return this.parent;
      }
   } // getParent

   /**
    * Returns a new instance of the "index"th child of the current block.
    * Browses the children descriptors, counts block occurrences until the
    * "index"th and returns it.<br>
    * If the current descriptor has no child then returns null.<br>
    * If index is outside the range of children count then returns null.
    * 
    * @param index The position of the child block to retreive starting from 0
    *           and not greater or equal to the number of children.
    * @return A new instance of the "index"th child block or null.
    */
   public DrbNode getChildAt(final int index)
   {
      if ((index < 0) || (index >= this.getChildrenCount()))
      {
         return null;
      }

      this.load();

      // Try to get the node from the cache
      SaxNode child = this.getTagAt(index).getNodeReference();
      if (child == null)
      {
         child = new SaxNode(this, index);
         this.getTagAt(index).setNodeReference(child);
      }
      else
      {
         /*
          * logger.debug("Retrieving existing child '" + child.getName() + "' at " +
          * index + "/" + (tag.childrenCount-1) + ". loaded=" + child.loaded + "
          * count=" + child.tag.childrenCount);
          */
      }

      return child;
   }

   /**
    * Number of children. The number of children is retreived from the children
    * list previously set If the children list has not already been set, 0 is
    * returned.
    * 
    * @return The number of children of the current node.
    */
   public int getChildrenCount()
   {
      return this.tag.childrenCount;
   } // getChildrenCount

   /**
    * The list of children of the current node. Returns a list of references to
    * the children of the current node. The current node may have no child and
    * the operation returns therefore a null reference.
    * 
    * @return The list of children if any null otherwise.
    */
   public DrbNodeList getChildren()
   {

      if (this.tag.childrenCount == 0)
      {
         return null;
      }

      this.load();

      final DrbDefaultNodeList children = new DrbDefaultNodeList();
      for (int i = 0; i < this.tag.childrenCount; i++)
      {
         children.add(this.getChildAt(i));
      }
      return children;
   }

   /**
    * Returns an occurence of the node matching the specified name.
    * 
    * @param name the String
    * @param occurrence int
    * @return DrbNode
    */
   public DrbNode getNamedChild(final String name, final int occurrence)
   {
      /**
       * Checks parameters.
       */
      if ((name == null) || (occurrence <= 0))
      {
         logger.error("SaxNode.getNamedChild(): "
               + "Invalid parameter (name=\"" + name + "\", occurrence="
               + occurrence);
         return null;
      }

      if (occurrence > this.tag.childrenCount)
      {
         return null;
      }

      this.load();

      /**
       * Search the matching node.
       */
      int current_occurence = 0;

      for (int itag = 0; itag < this.tag.childrenCount; itag++)
      {
         final SaxElementTag current_tag = this.getTagAt(itag);

         if (name.equals(current_tag.name))
         {
            current_occurence = current_occurence + 1;
         }

         if (current_occurence == occurrence)
         {
            return this.getChildAt(itag);
         }
      }
      return null;
   }

   /**
    * String representqtion of the object. This operation overrides the default
    * one to set the string representation to the name of the node.
    * 
    * @return The name of the node.
    */
   public String toString()
   {
      final ByteArrayOutputStream stream = new ByteArrayOutputStream();

      XmlFactory.writeXML(this, stream);

      return stream.toString();
   }

   // Mutable part

   /**
    * Move a segment of the stream.
    */
   private boolean move(long src_offset, long len, long dst_offset)
   {
      try
      {
         final java.io.RandomAccessFile file =
            (java.io.RandomAccessFile) this.document
                  .getImpl(java.io.RandomAccessFile.class);

         final byte[] buf = new byte[1024];
         final int off = 0;

         if (len == -1)
         {
            len = file.length() - src_offset;
         }
         final long old_file_len = file.length();
         final long file_len = old_file_len + dst_offset - src_offset;

         if (src_offset < dst_offset)
         {
            src_offset = src_offset + len;
            dst_offset = dst_offset + len;
            while (len > 0)
            {
               if (len >= 1024)
               {
                  src_offset = src_offset - 1024;
                  dst_offset = dst_offset - 1024;
                  len = len - 1024;
                  file.seek(src_offset);
                  file.readFully(buf, 0, 1024);
                  file.seek(dst_offset);
                  file.write(buf, 0, 1024);
               }
               else
               {
                  logger.debug("Moving " + len + " bytes from " + src_offset
                        + " to " + dst_offset);
                  src_offset = src_offset - len;
                  dst_offset = dst_offset - len;
                  file.seek(src_offset);
                  file.readFully(buf, 0, (int) len);
                  file.seek(dst_offset);
                  file.write(buf, 0, (int) len);
                  len = 0;
               }
            }
            logger.debug("File resized from " + old_file_len + " to "
                  + file.length());
         }
         else
         {
            while (len > 0)
            {
               file.seek(src_offset);
               if (len >= 1024)
               {
                  file.readFully(buf, off, 1024);
                  len = len - 1024;
                  file.seek(dst_offset);
                  file.write(buf, off, 1024);
                  src_offset = src_offset + 1024;
                  dst_offset = dst_offset + 1024;
               }
               else
               {
                  file.readFully(buf, off, (int) len);
                  file.seek(dst_offset);
                  file.write(buf, off, (int) len);
                  len = 0;
               }
            }
            file.setLength(file_len);
         }
         file.close();
      }
      catch (final java.io.IOException e)
      {
         return false;
      }
      return true;
   }

   /**
    * Changes the value of the node. This operation sets a new value of the
    * current node.The value type of the node shall be compatible with the node
    * implementation. If the type does not match exactly it is casted to a
    * compatible one based on the the fr.gael.drb.value capabilities. A
    * reference to the effectivelly assigned value is returned by the operation
    * so it is possible to check if a cast has been performed and therefore
    * assess the accuracy of the assignement. If the cast is not possible the
    * operation raises an UnsupportedOperationException. If the assignment is
    * possible and the node implementation has a physical representation the
    * value is updated in the physical source in order to persist among
    * sessions. It therefore possible that this operation consumses an variable
    * time.
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept value changes. For instance it may not be possible to change the
    * value of a file directory that has no immediate signification.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node changed event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node. The called operation is
    * the structureChanged() of the listeners.
    * </p>
    * 
    * @param value The new value of the node. This value shall not be null.
    * @return The effectivelly assigned value.The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested assignment for
    *            any reason.
    */
   public Value setValue(final Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      final DrbDefaultSequence content =
         new DrbDefaultSequence(this.getChildren());
      if (value != null)
      {
         content.addItem(0, value);
      }
      final long old_end_offset = this.tag.endOffset;
      this.tag.endOffset =
         this.writeNode(this.tag.startOffset, this.tag.endOffset, this
               .getName(), this.getNamespaceURI(), this.getNamespaceBindings(),
               this.getAttributes(), content);

      this.loaded = false;
      if (old_end_offset != this.tag.endOffset)
      {
         this.structureChanged(new DrbNodesChangeEvent(this.document
               .getFirstChild()));
      }
      else if (this.tag.childrenCount == 0)
      {
         this.nodesChanged(new DrbNodesChangeEvent(this));
      }
      else
      {
         this.structureChanged(new DrbNodesChangeEvent(this));
      }

      if (value == null)
      {
         return null;
      }
      else
      {
         return value.convertTo(Value.STRING_ID);
      }
   }

   /**
    * Set the attribute list of a node. If some attributes are already attached
    * to the current node they are first removed and then replaced by the new
    * ones. However the operation checks the compatibility of the passed
    * attribute according to the current implementation. The operation does
    * nothing if the compatibility check fails.
    * <p>
    * <b>Warning:</b> The input attributes may be duplicated or re-instanciated
    * according to the targetted implementation. References to the effectively
    * inserted attributes can be reteived from the getAttributes() operation of
    * the DrbNode. It is highly recommended to discard the references to the
    * input attribuets if not mandatory.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept attribute changes. For instance it may not be possible to change
    * the size attribute of a file through this operation with would meant a
    * effective file resize that is not really relevant without additional data.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node.The called operation is the
    * structureChanged() of the listeners.
    * </p>
    * 
    * @param attributes A reference to the new attribute list.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the attribute list is null. This exception may be
    *            overriden by an UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested attribute changes
    *            for any reason.
    */
   public void setAttributes(final DrbAttributeList attributes)
         throws NullPointerException, UnsupportedOperationException
   {
      this.load();

      this.tag.endOffset =
         this.writeNode(this.tag.startOffset, this.tag.endOffset, this
               .getName(), this.getNamespaceURI(), this.getNamespaceBindings(),
               attributes, this.getContent());

      this.loaded = false;
      this.structureChanged(new DrbNodesChangeEvent(this));
   }

   /**
    * Changes the name of the node. The passed name may be an empty string but
    * never a null reference. The change is persistant such as further instance
    * of a same node (even in different sessions) will have this new name. If
    * the implementation does not suppot the rename operation it is supposerd to
    * throw a UnsupportedOperationException.
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current standing also as the source of the event. The called
    * opetation is the structureChanged() of the listeners.
    * </p>
    * 
    * @param name Reference to the new name.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested rename for any
    *            reason (e.g. specific case or general incapability).
    * @throws NullPointerException This exception is raised when the passed name
    *            is a null reference.This exception may be overriden by an
    *            UnsupportedOperationException.
    */
   public void rename(final String name) throws NullPointerException,
         UnsupportedOperationException
   {

      /**
       * Checks the reference to the input name
       */
      if (name == null)
      {
         throw new NullPointerException("SaxNode.rename() : "
               + "The reference to the new name is null.");
      }

      this.load();
      final long old_end_offset = this.tag.endOffset;
      this.tag.endOffset =
         this.writeNode(this.tag.startOffset, this.tag.endOffset, name, this
               .getNamespaceURI(), this.getNamespaceBindings(), this
               .getAttributes(), this.getContent());
      this.tag.name = name;

      this.loaded = false;
      if (old_end_offset != this.tag.endOffset)
      {
         this.structureChanged(new DrbNodesChangeEvent(this.document
               .getFirstChild()));
      }
      else if (this.tag.childrenCount == 0)
      {
         this.nodesChanged(new DrbNodesChangeEvent(this));
      }
      else
      {
         this.structureChanged(new DrbNodesChangeEvent(this));
      }
   }

   /**
    * Replaces a child of the current node. This operation replaces a child in
    * the current children list by a new one The operation aborts when the index
    * is out of bound (index < 0 || index > size). In case of error, the
    * implementation has to restore the initial situation. It is therefore
    * recommended for any implementation to check the consistency prior to
    * perform the replacement.
    * <p>
    * <b>Warning:</b> The replacing node may be duplicated or re-instanciated
    * according to the targetted implementation.A reference to the effectively
    * replacing node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned one.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to insert a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the new node and the source is the current node. The called operation
    * is the structureChanged() of the listeners.
    * </p>
    * 
    * @param index Index of the node to be replaced. This index starts at 0 and
    *           shall be less than the number of children.
    * @param new_node A reference to the node that replaces the old one.
    * @return A reference to the effectivelly replacing node.This reference may
    *         differ from the new_node parameter.
    * @throws NullPointerException This exception is raised when the reference
    *            to the new node is null. This exception may be overriden by a
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested replace for any
    *            reason. In addition if the old_node is not retreived in the
    *            current children list, this exception is also raised.
    */
   public DrbNode replaceChild(final int index, final DrbNode new_node)
         throws NullPointerException, IndexOutOfBoundsException,
         UnsupportedOperationException
   {

      if (new_node == null)
      {
         throw new NullPointerException("XmlNode.replaceChild() :"
               + " Reference to the node is null.");
      }
      logger.debug("replaceChild at index " + index + " node="
            + new_node.getName());

      /**
       * Checks the index is in bound.
       */
      if ((index < 0) || (index >= this.getChildrenCount()))
      {
         throw new IndexOutOfBoundsException("XmlNode.replaceChild() : "
               + "Index #" + index);
      }

      this.load();

      /**
       * Replace tag.
       */
      final SaxElementTag replace_tag = this.getTagAt(index);
      replace_tag.childrenCount = new_node.getChildrenCount();
      replace_tag.name = new_node.getName();
      replace_tag.namespaceURI = new_node.getNamespaceURI();
      replace_tag.setNodeReference(null); // remove old reference
      final long new_end_offset =
         this.writeNode(replace_tag.startOffset, replace_tag.endOffset,
               replace_tag.name, replace_tag.namespaceURI,
               ((DrbAbstractNode) new_node).getNamespaceBindings(), new_node
                     .getAttributes(), ((DrbAbstractNode) new_node)
                     .getContent());
      final long diff_offset = new_end_offset - replace_tag.endOffset;
      replace_tag.endOffset = new_end_offset;

      /**
       * Update next-sibling ancestors and descendants offsets.
       */
      if (diff_offset != 0)
      {
         SaxNode ancestor = this;
         int descendant_index = index;
         while (ancestor != null)
         {
            ancestor.tag.startCloseOffset += diff_offset;
            ancestor.tag.endOffset += diff_offset;
            for (int i = descendant_index + 1; i < ancestor.tag.childrenCount; i++)
            {
               final SaxElementTag descendant_tag = ancestor.getTagAt(i);
               descendant_tag.moveTo(descendant_tag.startOffset + diff_offset);
            }
            descendant_index = ancestor.tag.index;
            ancestor = ancestor.parent;
         }
      }

      this.nodesRemoved(new DrbNodesChangeEvent(this));

      /**
       * Returns the replacing node.
       */
      return this.getChildAt(index);
   }

   /**
    * Removes an existing child. The child at the given index is removed from
    * the children list of the current node. The child is not modified by this
    * operation. At the child point of view it keeps the same parent or any
    * common association depending on the implementation. However at the parent
    * (i.e. the current node) point of view the removed node is completely
    * dismissed and will never be re-instaciated from constructor operations
    * (e.g. getFirstChild(), etc. ). The index of the child to be removed has to
    * correspond to an existing children index. If the index is less than zero
    * or greater or equal to the current number of children, an exception is
    * thrown.
    * <p>
    * This operation takes into account the removal by updating the sibling
    * associations of the children nodes prior and next to the removed one. The
    * indicies of the nodes next to the removed one are decresed of one. Their
    * parents as well as their contents are left unchanged.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the removed node and the source is the current node.The called
    * operation is the nodesRemoved() of the listeners.
    * </p>
    * 
    * @param index Index of the child to be removed.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested removal for any
    *            reason.
    */
   public void removeChild(final int index) throws IndexOutOfBoundsException,
         UnsupportedOperationException
   {
      final int children_count = this.getChildrenCount();

      /**
       * Checks the index is in bound.
       */
      if ((index < 0) || (index >= children_count))
      {
         throw new IndexOutOfBoundsException("SaxNode.removeChild(" + index
               + ") : " + "Index #" + index + " out of bound (children count ="
               + children_count + ")");
      }

      this.load();

      /**
       * Remove the file segment corresponding to the node.
       */
      final SaxElementTag removed_tag = this.getTagAt(index);
      final long start_offset = removed_tag.startOffset;
      final long stop_offset = removed_tag.endOffset;
      this.move(stop_offset, -1, start_offset);
      removed_tag.setNodeReference(null);
      this.children.remove(index);
      this.tag.childrenCount = this.tag.childrenCount - 1;

      /**
       * Update next-sibling index.
       */
      for (int ichild = index; ichild < this.tag.childrenCount; ichild++)
      {
         final SaxElementTag child_tag = this.getTagAt(ichild);
         child_tag.index = child_tag.index - 1;
      }

      /**
       * Update next-sibling ancestors and descendants offsets.
       */
      final long removed_len = stop_offset - start_offset;
      if (removed_len != 0)
      {
         SaxNode ancestor = this;
         int descendant_index = index - 1;
         while (ancestor != null)
         {
            ancestor.tag.startCloseOffset -= removed_len;
            ancestor.tag.endOffset -= removed_len;
            for (int i = descendant_index + 1; i < ancestor.tag.childrenCount; i++)
            {
               final SaxElementTag descendant_tag = ancestor.getTagAt(i);
               descendant_tag.moveTo(descendant_tag.startOffset - removed_len);
            }
            descendant_index = ancestor.tag.index;
            ancestor = ancestor.parent;
         }
      }

      this.nodesRemoved(new DrbNodesChangeEvent(this));
   }

   /**
    * Inserts a child at a given position. The passed node is inserted in the
    * list of children at the given position The position is the expected index
    * of the node after insertion. All the previous children from the aimed
    * position to the end of the list are shift to the end of the new children
    * list (i.e. their indices are shifted up of 1). If the given index is out
    * of the children bounds and therefore less than zero and greater or equal
    * to the current number of children,the operation raises an exception. An
    * index equal to the current number of children is allowed and the operation
    * is therefore equivalent to appendChild().
    * <p>
    * If the node has been inserted within the children list, the next sibling
    * indicies are increased of one. In addition the assiociations between the
    * inserted node and it previous and next siblings are updated (if any).
    * </p>
    * <p>
    * <b>Warning:</b> The inserted node may be duplicated or re-instanciated
    * according to the targetted implementation. A reference to the effectively
    * inserted node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned node.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to insert a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the inserted node and the source is the current node. The called
    * operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param new_node A reference to the node to be inserted.
    * @param index The expected index of the node after the insertion.
    * @return A reference to the effectively inserted node. This reference may
    *         differ from the input one.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference. This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passe
    *            index is less than zero or if it is greater or equal to the
    *            number of children in the number of children prior the call
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested insertion for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbNode insertChild(final DrbNode new_node, final int index)
         throws NullPointerException, UnsupportedOperationException,
         IndexOutOfBoundsException
   {
      /**
       * Checks the node is not null and that the index is in bound.
       */
      final int children_count = this.getChildrenCount();
      if ((new_node == null) || (index < 0) || (index > children_count))
      {
         throw new IndexOutOfBoundsException("SaxNode.insertChild() : "
               + "Index #" + index);
      }

      this.load();

      long inserted_len = 0;
      // Case of empty node
      if (children_count == 0)
      {
         final DrbSequence content = new DrbDefaultSequence(new_node);
         final long new_end_offset =
            this.writeNode(this.tag.startOffset, this.tag.endOffset, this
                  .getName(), this.getNamespaceURI(), this
                  .getNamespaceBindings(), this.getAttributes(), content);
         this.loaded = false;
         inserted_len = new_end_offset - this.tag.endOffset;
      }
      else
      {
         long child_start_offset;
         if (index < children_count)
         {
            child_start_offset = this.getTagAt(index).startOffset;
         }
         else
         {
            child_start_offset = this.tag.startCloseOffset;
         }
         final long child_end_offset =
            this.writeNode(child_start_offset, child_start_offset, new_node
                  .getName(), new_node.getNamespaceURI(),
                  ((DrbAbstractNode) new_node).getNamespaceBindings(), new_node
                        .getAttributes(), ((DrbAbstractNode) new_node)
                        .getContent());
         inserted_len = child_end_offset - child_start_offset;

         /**
          * Insert tag.
          */
         final SaxElementTag inserted_tag = new SaxElementTag();
         inserted_tag.index = index;
         inserted_tag.name = new_node.getName();
         inserted_tag.namespaceURI = new_node.getNamespaceURI();
         inserted_tag.startOffset = child_start_offset;
         inserted_tag.endOffset = child_end_offset;
         inserted_tag.childrenCount = new_node.getChildrenCount();
         this.children.add(index, inserted_tag);

         /**
          * Update next-sibling index.
          */
         for (int ichild = index + 1; ichild <= children_count; ichild++)
         {
            this.getTagAt(ichild).index++;
         }
      }
      this.tag.childrenCount++;

      /**
       * Update next-sibling ancestors and descendants offsets.
       */
      if (inserted_len != 0)
      {
         SaxNode ancestor = this;
         int descendant_index = index;
         while (ancestor != null)
         {
            ancestor.tag.startCloseOffset += inserted_len;
            ancestor.tag.endOffset += inserted_len;
            for (int i = descendant_index + 1; i < ancestor.tag.childrenCount; i++)
            {
               final SaxElementTag descendant_tag = ancestor.getTagAt(i);
               descendant_tag.moveTo(descendant_tag.startOffset + inserted_len);
            }
            descendant_index = ancestor.tag.index;
            ancestor = ancestor.parent;
         }
      }

      /**
       * Create the node.
       */
      final DrbNode child = this.getChildAt(index);

      this.nodesInserted(new DrbNodesChangeEvent(this));

      return child;
   }

   /**
    * Appends a child at the end of the children list. The passed node is
    * inserted in the list of children at the end of the current list.
    * <p>
    * <b>Warning:</b> The appended node may be duplicated or re-instanciated
    * according to the targetted implementation. A reference to the effectively
    * appended node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned node.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the appended node and the source is the current node. The called
    * operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param node A reference to the node to be appended.
    * @return A reference to the effectivelly appended node. This reference may
    *         differ from the input one.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference.This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested append for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbNode appendChild(final DrbNode node) throws NullPointerException,
         UnsupportedOperationException
   {
      final int child_count = this.getChildrenCount();
      return this.insertChild(node, child_count);
   } // appendChild

   /**
    * Write a node into the XML document.
    * 
    * @param start_offset The start offset in the document.
    * @param end_offset The end offset in the document or -1.
    * @param qname Overrides the qualified name of the output node.
    * @param namespace_uri Overrides the namespace URI of the output node.
    * @param ns_bindings The namespace bindings
    * @param attributes Overrides the attributes of the output node.
    * @param content Overrides the content of the node. This sequence may
    *           contains atomic values and nodes.
    * @return The end offset of the serialized node.
    */
   private long writeNode(final long start_offset, final long end_offset,
         String qname, final String namespace_uri, Namespace ns_bindings,
         final DrbAttributeList attributes, final DrbSequence content)
   {
      logger.debug("Write node start=" + start_offset + ", end=" + end_offset);
      try
      {
         long inserted_len = 0;
         String header = "";
         String footer = "";
         String prefix = null;

         // Create start and close tags
         if (ns_bindings == null)
         {
            ns_bindings = new Namespace();
            ns_bindings.bind(XmlNode.XML_PREFIX, XmlNode.XML_NAMESPACE);
            ns_bindings.bind(XmlNode.XMLNS_PREFIX, XmlNode.XMLNS_NAMESPACE);
         }

         prefix = ns_bindings.resolvePrefix(namespace_uri);
         if ((prefix != null) && (!"".equals(prefix)))
         {
            qname = prefix + ":" + qname;
         }
         else
         {
            prefix = null;
         }

         header = "<" + qname;
         if (attributes != null)
         {
            for (int i = 0; i < attributes.getLength(); i++)
            {
               String attr_name = attributes.item(i).getName();
               final String attr_uri = attributes.item(i).getNamespaceURI();
               if ((attr_uri != null) && (attr_uri.length() > 0))
               {
                  String attr_prefix = ns_bindings.resolvePrefix(attr_uri);
                  if (XmlNode.XML_NAMESPACE.equals(attr_uri))
                  {
                     attr_prefix = "xml";
                  }

                  // Generate a new prefix, if necessary
                  if ((attr_prefix == null) || (attr_prefix.length() == 0))
                  {
                     attr_prefix = ns_bindings.createPrefix("ns", attr_uri);
                  }

                  attr_name = attr_prefix + ":" + attr_name;
               }
               final Value attr_value = attributes.item(i).getValue();
               header = header + " " + attr_name + "=\"";
               if (attr_value != null)
               {
                  header = header + attr_value.toString();
               }
               header = header + "\"";
            }
         }
         // Add namespace bindings
         // TBC : Should check redeclaraction of prefixes
         if (ns_bindings != null)
         {
            final String[] prefixes = ns_bindings.getDeclaredPrefixes();
            for (int i = 0; i < prefixes.length; i++)
            {
               String ns_uri = ns_bindings.resolveNamespace(prefixes[i]);
               if (ns_uri == null)
               {
                  ns_uri = "";
               }
               ns_uri = XmlNode.toXML(ns_uri);
               if (!"".equals(prefixes[i])
                     && !"xml".equalsIgnoreCase(prefixes[i])
                     && !"xmlns".equalsIgnoreCase(prefixes[i])
                     && !XmlNode.XML_NAMESPACE.equals(ns_uri)
                     && !XmlNode.XMLNS_NAMESPACE.equals(ns_uri))
               {
                  header =
                     header + " xmlns:" + prefixes[i] + "=\"" + ns_uri + "\"";
               }
            }
         }
         // Add default namespace declaration
         if ((prefix == null) && (namespace_uri != null))
         {
            header = header + " xmlns=\"" + XmlNode.toXML(namespace_uri) + "\"";
         }
         header = header + ">";
         footer = "</" + qname + ">";

         /**
          * Copy the node to a temporary file.
          */
         final java.io.File tmp_file =
            java.io.File.createTempFile("drb", "xml");
         tmp_file.deleteOnExit();
         final java.io.FileWriter tmp_output = new java.io.FileWriter(tmp_file);

         // Write Start Tag
         tmp_output.write(header); // TBC: charset

         // Write node content
         if (content != null)
         {
            String default_ns_uri = null;
            if (ns_bindings != null)
            {
               default_ns_uri = ns_bindings.getDefaultNamespaceURI();
            }
            final XmlWriter.Context context =
               new XmlWriter.Context(ns_bindings, default_ns_uri);
            final XmlWriter xml_writer = new XmlWriter(tmp_output, "UTF-8"); // TBC
            for (int i = 0; i < content.getLength(); i++)
            {
               final DrbItem item = content.getItem(i);
               if (item.getItemType() == NODE_ITEM)
               {
                  xml_writer.save((DrbNode) item, context, false);
               }
               else if (item.getValue() != null)
               {
                  tmp_output.write(XmlNode.toXML(item.getValue().toString()));
               }
            }
         }

         // Write Close Tag
         tmp_output.write(footer);
         tmp_output.close();

         inserted_len = tmp_file.length();
         logger.debug("Write node start=" + start_offset + ", end="
               + end_offset + " inserted_len=" + inserted_len);
         this.move(end_offset, -1, start_offset + inserted_len);

         final java.io.RandomAccessFile file =
            (java.io.RandomAccessFile) this.document
                  .getImpl(java.io.RandomAccessFile.class);

         final java.io.FileInputStream tmp_stream =
            new java.io.FileInputStream(tmp_file);

         final byte[] buf = new byte[1024];
         file.seek(start_offset);
         while (tmp_stream.available() > 0)
         {
            final int len = tmp_stream.read(buf);
            file.write(buf, 0, len);
         }
         file.close();
         tmp_stream.close();
         tmp_file.delete();

         return start_offset + inserted_len;
      }
      catch (final java.io.IOException e)
      {
         throw new UnsupportedOperationException(e.getMessage());
      }
   }

   /**
    * Main
    * 
    * @param args l
    */
   public static void main(final String[] args)
   {
      final DrbNode context_node = fr.gael.drb.DrbFactory.open(".");
      final DrbNode input =
         (DrbNode) new fr.gael.drb.query.Query(args[0]).evaluate(context_node)
               .getItem(0);
      final DrbNode xml = new SaxDocument(input).getNamedChild("root", 1);
      /*
       * DrbNode node = (DrbNode) new fr.gael.drb.query.Query("<child>toto</child>").
       * evaluate(context_node). getItem(0); for (int i=0; i<1; i++) {
       * xml.appendChild(node); }
       */
      xml.setValue(new fr.gael.drb.value.String("toto"));
      // XmlFactory.writeXML(xml, System.out);
   }

} // SaxNode
