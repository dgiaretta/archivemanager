/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * The UnsignedByteArray class is a generic wrapper for unsigned byte array
 * values.
 */
public class UnsignedByteArray extends AbstractNumericArray implements
      ValueFormat
{
   /*
    * TODO: the meaning, value domain of a unsigned byte array shall be
    * described in the header of this file. Reference to UnsignedByte and Array
    * may be used to minimize the documentation.
    */
   // ==========================================================================
   // Attributes part.
   // ==========================================================================
   /**
    * The UnsignedByteArray priority.
    */
   final static int PRIORITY = 1;

   /**
    * The UnsignedByteArray value.
    */
   private byte[] value;

   /**
    * Builds an UnsignedByteArray value from an array of bytes.
    * 
    * @param src the unsigned byte array source.
    */
   public UnsignedByteArray(final byte[] src)
   {
      if (src != null)
      {
         this.value = new byte[src.length];
         System.arraycopy(src, 0, this.value, 0, src.length);
      }
      else
      {
         this.value = new byte[] {}; // empty array
      }
   } // UnsignedByteArray

   /**
    * Builds an empty UnsignedByteArray value with a specific size.
    * 
    * @param size the size of the array to be created. This size shall never be
    *           negative or equal to 0.
    */
   public UnsignedByteArray(final int size)
   {
      // size not checked ->
      // a NegativeArraySize exception will be trown by Java RunTime
      this.value = new byte[size];
   } // UnsignedByteArray

   /**
    * Returns the underlying object for optimization.    
    * @return a backing array.
    */
   public final byte[] getData()
   {
      return this.value;
   }

   /**
    * Returns a string containing the value with a fixed format.
    * 
    * @param length the expected length of the output string
    * @return the formatted string. If the array is empty, an empty string is
    *         returned.
    * @see fr.gael.drb.ValueFormat
    */
   public java.lang.String getFormattedString(final int length)
   {
      /*
       * TODO: the length parameter is not used !!! Shall be removed or
       * implemented
       */
      java.lang.String str = "";

      for (int i = 0; i < this.length(); i++)
      {
         str = str + Byte.getFormattedString(1, this.value[i], false);
      }

      return str;
   }

   /**
    * Returns a byte buffer containing the value in a fixed format. This
    * implementation is optimised to return directly the array because it
    * contains already the bytes.
    * 
    * @return The buffer which is the byte array of the value.
    */
   public byte[] getFormattedBuffer()
   {
      return this.value;
   }

   /**
    * The type identifier of this BooleanArray value.
    * 
    * @return an identifier of the array type, namely ARRAY_ID.
    */
   public final int getType()
   {
      return Value.ARRAY_ID;
   }

   /**
    * Returns the UnsignedByteArray priority
    * 
    * @return the UnsignedByteArray priority
    */
   public final int getPriority()
   {
      return PRIORITY;
   }

   /**
    * Convert the value into the specified type.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException if the target type is not ARRAY_ID or STRING_ID
    */
   public final Value convertTo(final int type)
   {
      if (type == ARRAY_ID)
      {
         return this;
      }

      if (type == STRING_ID)
      {
         return new String(this.toString());
      }

      throw new ClassCastException();
   }

   /**
    * Assign a value. An implicit conversion may be performed to make the
    * assignment. This assignment may result in a loss of precision (ex: float[]
    * to byte[]).
    * 
    * @param value the value to be assigned.
    * @throws ClassCastException if the value is not an instance of NumericArray
    */
   public final void assign(final Value value)
   {
      if (value == null)
      {
         this.value = new byte[] {};
      }
      else
      {
         final NumericArray b = (NumericArray) value;
         this.value = new byte[b.length()];

         for (int i = 0; i < this.length(); i++)
         {
            this.value[i] = b.byteValue(i);
         }
      }
   }

   /**
    * The type of the values embedded in the array.
    * 
    * @return an identifier of the element type.
    */
   public final int getArrayType()
   {
      return Value.UNSIGNED_BYTE_ID;
   }

   /**
    * The value of the element located at the specified index.
    * 
    * @param index position where to retrieve the value.
    * @return The element located at the index.
    */
   public final Value getElement(final int index)
   {
      return new UnsignedByte(this.value[index]);
   }

   /**
    * Replace the element at the specified position in the array with the
    * specified element.
    * 
    * @param index index of element to replace.
    * @param element element to be stored at the specified position.
    */
   public final void assign(final int index, Value element)
   {
      element = element.convertTo(Value.NUMERIC_ID);
      this.value[index] = ((Numeric) element).byteValue();
   }

   /**
    * Returns the number of elements in this array.
    * 
    * @return the number of elements in this array.
    */
   public final int length()
   {
      return this.value.length;
   }

   // --------------------------------------------------------------------------
   // NumericArray interface implementation
   // --------------------------------------------------------------------------
   /**
    * Returns this value as a boolean.
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type byte.
    */
   public final boolean booleanValue(final int index)
   {
      return this.value[index] != 0;
   }

   /**
    * Returns this value as a byte (signed 8 bits).
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type byte.
    */
   public final byte byteValue(final int index)
   {
      return (this.value[index]);
   }

   /**
    * Returns this value as an integer (signed 32 bits).
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type int.
    */
   public final int intValue(final int index)
   {
      return (this.value[index] & 0xff);
   }

   /**
    * Returns this value as a long integer (signed 64 bits).
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type long.
    */
   public final long longValue(final int index)
   {
      return (this.value[index] & (long) 0xff);
   }

   /**
    * Returns this value as a short integer (signed 16 bits).
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type short.
    */
   public final short shortValue(final int index)
   {
      return (short) (this.value[index] & (short) 0xff);
   }

   /**
    * Returns this value as a float (signed 32 bits IEEE 754).
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type float.
    */
   public final float floatValue(final int index)
   {
      return (this.value[index] & 0xff);
   }

   /**
    * Returns this value as a double (signed 64 bits IEEE 754).
    * 
    * @param index position where to retrieve the value.
    * @return the numeric value represented by this object after conversion to
    *         type double.
    */
   public final double doubleValue(final int index)
   {
      return (this.value[index] & 0xff);
   }

   /**
    * Assign a boolean value.
    * 
    * @param index index of element to replace.
    * @param value another value.
    */
   public final void assign(final int index, final boolean value)
   {
      this.value[index] = (byte) (value ? 1 : 0);
   }

   /**
    * Assign a byte value.
    * 
    * @param index index of element to replace.
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final int index, final byte value)
   {
      this.value[index] = value;
   }

   /**
    * Assign an int value.
    * 
    * @param index index of element to replace.
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final int index, final int value)
   {
      this.value[index] = (byte) value;
   }

   /**
    * Assign short value.
    * 
    * @param index index of element to replace.
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final int index, final short value)
   {
      this.value[index] = (byte) value;
   }

   /**
    * Assign a long value.
    * 
    * @param index index of element to replace.
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final int index, final long value)
   {
      this.value[index] = (byte) value;
   }

   /**
    * Assign a float value.
    * 
    * @param index index of element to replace.
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final int index, final float value)
   {
      this.value[index] = (byte) value;
   }

   /**
    * Assign a double value.
    * 
    * @param index index of element to replace.
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final int index, final double value)
   {
      this.value[index] = (byte) value;
   }

   /**
    * Returns a new String object representing this UnsignedByteArray.
    * 
    * @return a string representation of the object.
    */
   public java.lang.String toString()
   {
      final StringBuffer strbuf = new StringBuffer(this.value.length * 3);
      for (int i = 0; i < this.value.length; i++)
      {
         if (i != 0)
         {
            strbuf.append(" ");
         }
         strbuf.append(this.value[i] & 0xff);
      }
      return strbuf.toString();
   }

   /*
    * TODO: The main operation for testing will be removed because they are
    * dedicated to an internal use and shall not be accessed outside GAEL
    * Consultant.
    */
   /**
    * Unitary tests operation.
    */
   /*
    * public static void main(java.lang.String[] args) { NumericArray uba = new
    * UnsignedByteArray(3); uba.assign(0, (int)250); uba.assign(1, (short)156);
    * uba.assign(2, (float)217); System.out.println(uba);
    * System.out.println(uba.intValue(0) + " " + uba.shortValue(1) + " " +
    * uba.floatValue(2)); }
    */
}
