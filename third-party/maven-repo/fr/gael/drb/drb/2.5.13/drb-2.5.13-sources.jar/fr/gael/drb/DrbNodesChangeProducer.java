/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

/**
 * Interface identifying any node change procucer. This interface unifies the
 * adds and removals of node change listeners. Is is dedicated to DRB
 * implementations that trigger node change events and in particular the one
 * that are mutable. It is important to keep in mind that NOT ALL node
 * implementations implements this interface mainly because they are not mutable
 * (i.e. no change to manage).
 */
public interface DrbNodesChangeProducer
{
   /**
    * Adds a listener to the producer. This operation enables to add a nodes
    * change listener to the implementing class. Any change performed by the
    * implementing class will be notified by a DrbNodesChangeEvent fired
    * throught the specific triggers (i.e. operations) of the listeners. In case
    * of problem, no error as well as exception is raised.
    * 
    * @param listener The listener to be added in the list of the impelemting
    *           class.
    */
   public void addNodesChangeListener(DrbNodesChangeListener listener);

   /**
    * Removes a listener to the producer. This operation enables to remove a
    * nodes change listener to the implementing class. This listener is supposer
    * to habe been previously inserted with the addNodesChangeListener()
    * operation. In case of null parameter or unsuccessful retreival, no error
    * as well as eception is raised.
    * 
    * @param listener The listener to be removed in the list of the impelemting
    *           class.
    */
   public void removeNodesChangeListener(DrbNodesChangeListener listener);
}// DrbNodesChangeProducer
