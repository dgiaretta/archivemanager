/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd.builder;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAbstractNode;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.value.Value;
import fr.gael.drb.value.ValueArray;
import fr.gael.drb.xsd.Namespace;
import fr.gael.drb.xsd.XmlSchema;
import fr.gael.drb.xsd.XsdAtomicType;
import fr.gael.drb.xsd.XsdAttributeGroup;
import fr.gael.drb.xsd.XsdComplexType;
import fr.gael.drb.xsd.XsdElement;
import fr.gael.drb.xsd.XsdListType;
import fr.gael.drb.xsd.XsdModelGroup;
import fr.gael.drb.xsd.XsdParticle;
import fr.gael.drb.xsd.XsdSimpleType;
import fr.gael.drb.xsd.XsdType;

/**
 * XML-Schema generator.
 */
public class XmlSchemaBuilder
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(XmlSchemaBuilder.class);

   /**
    * The target namespace of the schema.
    */
   private String targetNamespace = null;

   /**
    * The current type prefix.
    */
   private String typePrefix = "";

   /**
    * The global type list.
    */
   private ArrayList global_type_list = null;

   /**
    * Static xs:double pattern.
    */
   private Pattern doublePattern = null;

   /**
    * Static xs:integer pattern.
    */
   private Pattern integerPattern = null;

   /**
    * Static xs:dateTime pattern.
    */
   private Pattern dateTimePattern = null;

   /**
    * The static namespace bindings.
    */
   protected Namespace staticNamespace = new Namespace();

   /**
    * Create an XML-Schema generator with default parameters.
    */
   public XmlSchemaBuilder()
   {
      this.integerPattern = Pattern.compile("(\\+|\\-)?[0-9]+");
      this.doublePattern =
         Pattern.compile("(\\+|\\-)?[0-9]*\\.?[0-9]*"
               + "((d|D|e|E)(\\+|\\-)?[0-9]+)?");
      this.dateTimePattern = Pattern.compile("..-...-.... ..:..:..\\.......");

      this.global_type_list = new ArrayList();
      this.typePrefix = "";

      this.staticNamespace = new Namespace();
      this.staticNamespace.bind("xs", "http://www.w3.org/2001/XMLSchema");
   }

   /**
    * Builds a XML Schema from an input node.
    * 
    * @param node the input node.
    * @return the XML-Schema component.
    */
   public XmlSchema createSchema(final DrbNode node)
   {
      /**
       * Checks the provided base node. The base node shall be a non null and
       * have an impl.
       */
      if (node == null)
      {
         return null;
      }

      this.targetNamespace = node.getNamespaceURI();
      final XsdElement[] root_elements = new XsdElement[1];
      root_elements[0] = this.createElement(node, 1, 1);
      root_elements[0] = this.refineElement(root_elements[0], node, 1);

      final XsdType[] global_types = new XsdType[this.global_type_list.size()];
      this.global_type_list.toArray(global_types);

      final Namespace namespace = new Namespace();
      namespace.addNamespaces(this.staticNamespace);
      namespace.setDefaultNamespaceURI(this.targetNamespace);

      if (node instanceof DrbAbstractNode)
      {
         final Namespace node_namespace =
            ((DrbAbstractNode) node).getNamespaceBindings();
         String prefix = null;
         if (node_namespace != null)
         {
            prefix = node_namespace.resolvePrefix(this.targetNamespace);
         }
         if ((prefix != null) && (this.targetNamespace != null))
         {
            namespace.bind(prefix, this.targetNamespace);
         }
      }

      final XmlSchema schema =
         new XmlSchema(root_elements, global_types, namespace);
      schema.setTargetNamespace(this.targetNamespace);

      return schema;
   }

   /**
    * Builds a XML Element from an input node.
    * 
    * @param node the input node.
    * @param min_occurs the minimum if the occurence
    * @param max_occurs the maximum of the occurence
    * @return an XSD element
    */
   private XsdElement createElement(final DrbNode node, final int min_occurs,
         final int max_occurs)
   {
      final XsdType type = this.createType(node);
      final XsdElement element =
         new XsdElement(min_occurs, max_occurs, node.getName(), type);
      element.setTargetNamespace(this.targetNamespace);
      return element;
   }

   /**
    * Refine an XML Element.
    * 
    * @param element the element
    * @param node the input node.
    * @param occurs the actual occurrence of the node
    * @return an XSD element
    */
   protected XsdElement refineElement(final XsdElement element,
         final DrbNode node, final int occurs)
   {
      return element;
   }

   /**
    * Builds a XML Type from an input node.
    * 
    * @param node the input node.
    * @return
    */
   private XsdType createType(final DrbNode node)
   {
      XsdSimpleType datatype = null;
      final Value value = node.getValue();
      if (value != null)
      {
         datatype = this.createSimpleType(value);
      }
      final DrbNodeList children = node.getChildren();
      final DrbAttributeList attributes = node.getAttributes();

      if ((value == null) || ((children != null) && (children.getLength() > 0))) // ||
      // ((attributes != null) && (attributes.getLength() > 0)))
      {
         final int index = this.global_type_list.size();
         final String old_type_prefix = this.typePrefix;
         this.typePrefix = this.typePrefix + node.getName() + "_";
         final XsdModelGroup model_group = this.createModelGroup(children);
         this.typePrefix = old_type_prefix;

         final XsdAttributeGroup attribute_group =
            this.createAttributeGroup(attributes);
         final XsdComplexType complex_type =
            new XsdComplexType(this.typePrefix + node.getName(),
                  attribute_group, model_group, datatype,
                  XsdComplexType.EXTENSION_METHOD);
         complex_type.setTargetNamespace(this.targetNamespace);
         this.global_type_list.add(index, complex_type);
         logger.debug("Schema Builder: Added " + complex_type.getName() + ".");
         return complex_type;
      }
      else
      {
         if ((this.targetNamespace != datatype.getTargetNamespace())
               && !(Namespace.XML_SCHEMA_NAMESPACE.equals(datatype
                     .getTargetNamespace())))
         {
            this.global_type_list.add(datatype);
         }
         return datatype;
      }
   }

   /**
    * Builds a XML Model Group from an input node list.
    * 
    * @param list the input node list.
    * @return
    */
   private XsdModelGroup createModelGroup(final DrbNodeList list)
   {
      // Case of empty list
      if (list == null)
      {
         return new XsdModelGroup(1, 1, new XsdParticle[0],
               XsdModelGroup.SEQUENCE_MODEL);
      }
      // The list of particle in the model group (element only)
      final ArrayList particle_list = new ArrayList();
      int occurs = 1;
      // An hashtable to cope with the unique particle attribution
      // construction e.g. 'element name' <--> 'element type'
      final Hashtable type_hash = new Hashtable();

      for (int i = 0; i < list.getLength(); i += occurs)
      {
         final DrbNode node = list.item(i);
         // Compute the occurrence count of the element
         final String name = node.getName();
         occurs = 1;
         for (int j = i + 1; j < list.getLength(); j++)
         {
            if (!name.equals(list.item(j).getName()))
            {
               break;
            }
            occurs++;
         }

         // Unique identity constraint: get the type from the element name
         XsdType type = (XsdType) type_hash.get(node.getName());
         // If this is a new element, create a new type
         if (type == null)
         {
            type = this.createType(node);
            type_hash.put(node.getName(), type);
         }
         XsdElement element =
            new XsdElement(occurs, occurs, node.getName(), type);
         element = this.refineElement(element, node, occurs);
         particle_list.add(element);
      }

      // Create a sequence particle
      final XsdParticle[] content = new XsdParticle[particle_list.size()];
      particle_list.toArray(content);

      final XsdModelGroup model_group =
         new XsdModelGroup(1, 1, content, XsdModelGroup.SEQUENCE_MODEL);

      return model_group;
   }

   /**
    * Builds a XML Attribute Group from an input node.
    * 
    * @param attributes the input attributes.
    * @return
    */
   private XsdAttributeGroup createAttributeGroup(
         final DrbAttributeList attributes)
   {
      return null;
   }

   /**
    * Builds a XML Type from an input value.
    * 
    * @param value the input value.
    * @return the simple type definition.
    */
   private XsdSimpleType createSimpleType(final Value value)
   {
      // Case of NULL value
      if (value == null)
      {
         return new XsdAtomicType(Value.UNKNOWN_ID);
      }
      XsdSimpleType type = null;
      if (value.getType() == Value.ARRAY_ID)
      {
         XsdSimpleType item_type =
            new XsdAtomicType(((ValueArray) value).getArrayType());
         item_type =
            (XsdSimpleType) XmlSchema.getDefaultSchema().getType(
                  item_type.getName());
         type = new XsdListType(item_type, null);
         type.setTargetNamespace(this.targetNamespace);
      }
      else
      {
         if (value.getType() == Value.STRING_ID)
         {
            // Integer
            try
            {
               final Value integer = value.convertTo(Value.INTEGER_ID);
               type =
                  (XsdSimpleType) XmlSchema.getDefaultSchema().getType(
                        "integer");
            }
            catch (final ClassCastException e1)
            {
            }
            ;
            // Decimal
            if (type == null)
            {
               try
               {
                  final Value decimal = value.convertTo(Value.DECIMAL_ID);
                  type =
                     (XsdSimpleType) XmlSchema.getDefaultSchema().getType(
                           "decimal");
               }
               catch (final ClassCastException e2)
               {
               }
               ;
            }
            // DateTime
            if (type == null)
            {
               try
               {
                  final Value date_time = value.convertTo(Value.DATE_ID);
                  type =
                     (XsdSimpleType) XmlSchema.getDefaultSchema().getType(
                           "dateTime");
               }
               catch (final ClassCastException e3)
               {
               }
               ;
            }
         }
         if (type == null)
         {
            type = new XsdAtomicType(value.getType());
            type.setTargetNamespace(Namespace.XML_SCHEMA_NAMESPACE);
            type =
               (XsdSimpleType) XmlSchema.getDefaultSchema().getType(
                     type.getName());
         }
      }
      return type;
   }

   /**
    * Makes the class runnable for testing.
    * 
    * @param args main arguments
    */
   public static void main(final String[] args)
   {
      final DrbNode input_node = fr.gael.drb.DrbFactory.open(args[0]);
      final XmlSchemaBuilder xsd_builder = new XmlSchemaBuilder();
      final XmlSchema xml_schema = xsd_builder.createSchema(input_node);

      fr.gael.drb.impl.xml.XmlWriter.writeXML(xml_schema.toNode(), System.out);
   }
} // XmlSchemaBuilder
