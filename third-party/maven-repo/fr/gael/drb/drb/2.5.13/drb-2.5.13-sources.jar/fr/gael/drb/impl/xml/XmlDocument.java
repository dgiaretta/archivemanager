/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.xml;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.value.Value;

/**
 * DOM Document
 */
public class XmlDocument extends DrbNodeImpl
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(XmlDocument.class);

   /**
    * The Document node.
    */
   protected Document document;

   /**
    * baseNode
    */
   protected DrbNode baseNode;

   /**
    * Builds a new XmlDocument from a string. This constructor initialises a
    * node based on the XML document encoded in the passed string.
    * 
    * @param xml_string The XML string. This parameter shall never be null.
    */
   public XmlDocument(final String xml_string)
   {

      if (xml_string != null)
      {
         this.load(new InputSource(new StringReader(xml_string)));
      }
      else
      {
         throw new NullPointerException("The XML string shall not be null.");
      }
   } // XmlDocument

   /**
    * Builds a new XmlDocument from a standard reader . This constructor
    * initialises a node based on the XML document encoded in the passed Reader.
    * 
    * @param reader The reader to build the document.
    */
   public XmlDocument(final Reader reader)
   {

      if (reader != null)
      {
         this.load(new InputSource(reader));
      }
      else
      {
         throw new NullPointerException("The XML reader shall not be null.");
      }
   } // XmlDocument

   /**
    * Builds a new XmlDocument from an input stream. This constructor
    * initialises a node based on the XML document encoded in the passed
    * InputStream.
    * 
    * @param input_stream The input stream to build the document.
    */
   public XmlDocument(final InputStream input_stream)
   {

      if (input_stream != null)
      {
         this.load(new InputSource(input_stream));
      }
      else
      {
         throw new NullPointerException("The XML stream shall not be null.");
      }
   } // XmlDocument

   /**
    * Builds a new XmlDocument from a file node. This constructor initialises a
    * node based on the XML document encoded in the underlying InputStream.
    * 
    * @param base_node A reference to a the base node of an external
    *           implementation.
    */
   protected XmlDocument(final DrbNode base_node)
   {
      super();

      if (base_node == null)
      {
         throw new NullPointerException("The base node shall not be null.");
      }

      this.baseNode = base_node;

      /**
       * Try to get InputStream implementation from the provided node.
       */
      InputStream stream;

      if ((stream = (InputStream) this.getImpl(InputStream.class)) != null)
      {
         // Create an input source from the input stream
         InputSource input_source = new InputSource(stream);

         // Set the source system identifier
         String system_id = this.getPath();

         if (system_id != null)
         {
            input_source.setSystemId(system_id);
         }

         // Load the input source
         this.load(input_source);
      }
      else
      {
         throw new IllegalArgumentException();
      }

   } // XmlDocument

   /**
    * Builds a new XmlDocument from a InputSource
    * 
    * @param input_source The input source to build the DOM node.
    */
   protected XmlDocument(final InputSource input_source)
   {
      this.baseNode = null;
      this.load(input_source);
   }

   /**
    * Builds a new XmlDocument from a Document node
    * 
    * @param document The DOM document.
    */
   protected XmlDocument(final Document document)
   {
      this.baseNode = null;
      this.document = document;
   }

   /**
    * Load the XML document from an InputSource.
    * 
    * @param input_source The input source to build the DOM node.
    */
   private void load(final InputSource input_source)
   {
      /**
       * Checks the InputSource.
       */
      if (input_source == null)
      {
         throw new IllegalArgumentException();
      }

      /**
       * Parse the input stream as an XML file.
       */
      try
      {
         final DocumentBuilderFactory builderFactory =
            DocumentBuilderFactory.newInstance();

         builderFactory.setNamespaceAware(true);
         final DocumentBuilder builder = builderFactory.newDocumentBuilder();

         // The entity resolution raises an exception if referenced dtd doesn't
         // exists. This new resolver overrides the default one to manages
         // the case of wrong entity definition.
         builder.setEntityResolver(new EntityResolver() {
            public InputSource resolveEntity(String publicId, String systemId)
                   throws SAXException, java.io.IOException
            {
               logger.debug ("Resolving \"" + publicId + "\" - \"" + 
                  systemId + "\"");
               
               if (systemId != null)
               {
                  URL url = new URL (systemId);
                  try
                  {
                     return new InputSource(url.openStream ());
                  }
                  catch (Exception e)
                  {
                     logger.warn ("Cannot access entity \"" + systemId + 
                        "\" - Continuing without ...");
                     logger.debug ("Error accessing entity.", e);
                     return new InputSource(
                        new ByteArrayInputStream(
                           "<?xml version='1.0' encoding='UTF-8'?>".getBytes()));
                  }
               }
               return null;
            }
         });

         this.document = builder.parse(input_source);
      }
      catch (final javax.xml.parsers.ParserConfigurationException e)
      {
         logger.error("fr.gael.drb.impl.xml.XmlDocument(input_stream) : "+
            "Warning : Document cannot be parsed: " + e.getMessage ());
         logger.debug (
            "fr.gael.drb.impl.xml.XmlDocument(input_stream) parsing error.", e);
         throw new IllegalArgumentException(e);
      }
      catch (final IOException e)
      {
         logger
               .error("fr.gael.drb.impl.xml.XmlDocument(input_stream) : Warning : "
                     + "Document cannot be parsed.");
         logger
               .error("fr.gael.drb.impl.xml.XmlDocument(input_stream) : Warning : "
                     + e.getMessage());
         throw new IllegalArgumentException();
      }
      catch (final org.xml.sax.SAXException e)
      {
         logger
               .error("fr.gael.drb.impl.xml.XmlDocument(input_stream) : Warning : "
                     + "Document cannot be parsed.", e);
         logger
               .error("fr.gael.drb.impl.xml.XmlDocument(input_stream) : Warning : "
                     + e.getMessage());
         throw new IllegalArgumentException();
      }
   }

   /**
    * Indicates whether this node is "equal to" to another node. See
    * Object.equals() for the general contract of this method.
    * 
    * @param obj another value.
    * @return true if this object is the same as the obj argument
    */
   public boolean equals(final Object obj)
   {
      // Check reference equality
      if (this == obj)
      {
         return true;
      }

      // Check I/O
      if (obj instanceof XmlDocument)
      {
         final XmlDocument dom_doc = (XmlDocument) obj;
         return (this.document == dom_doc.document);
      }

      // Otherwise the object is different
      return false;
   } // equals

   /**
    * Name of the node. Read accessor to the previously set node name. The name
    * is never null but may be an empty string.
    * 
    * @return The name of the node.
    */
   public String getName()
   {
      if (this.baseNode == null)
      {
         return "";
      }
      else
      {
         return this.baseNode.getName();
      }
   } // getName

   /**
    * Get namespace URI.
    * 
    * @return The namespace URI previsouly set or null if unspecified.
    */
   public String getNamespaceURI()
   {
      if (this.baseNode == null)
      {
         return null;
      }
      else
      {
         return this.baseNode.getNamespaceURI();
      }
   } // getNamespaceURI

   /**
    * The full path of the node. The full path is the path of the parent node to
    * which is appended the name of the current node. If no parent have already
    * been set no absolute path is considered. A path considering the current
    * node has a root node is not valid for the factory and is therefore not
    * significant in the current implementation.
    * 
    * @return The absolute path of the current node.
    */
   public String getPath()
   {
      if (this.baseNode == null)
      {
         return "";
      }
      else
      {
         return this.baseNode.getPath();
      }
   }

   /**
    * Returns the index of the node. The index is the sequential position of the
    * current node in its parent children list.
    * 
    * @return The index of the current node in its parent children list.
    */
   public int getIndex()
   {
      if (this.baseNode == null)
      {
         return -1;
      }
      else
      {
         return this.baseNode.getIndex();
      }
   } // getIndex

   /**
    * The value type of the node. The value type is determined from the value
    * previously assigned to the node. If no speficic value has been previsouly
    * set, fr.gael.drb.value.Value.NULL_ID type is returned.
    * 
    * @return NULL_ID if the node does not provide value or any other valid type
    *         identifier otherwise.
    */
   public int getValueType()
   {
      return Value.NULL_ID;
   } // getValueType

   /**
    * The value of the node. The value is the one previously set.
    * 
    * @return A reference to the value of the node or null if no value has
    *         already been set.
    */
   public Value getValue()
   {
      return null;
   } // getValue

   /**
    * The attributes of the nodes. This operation returns a list of attribute
    * previously set (if any).
    * 
    * @return The list attributes of the current node or null if none.
    */
   public DrbAttributeList getAttributes()
   {
      /**
       * If the document has no base, returns null.
       */
      if (this.baseNode == null)
      {
         return null;
      }
      final DrbAttributeList attributes = this.baseNode.getAttributes();
      if ((attributes == null) || (attributes.getLength() == 0))
      {
         return null;
      }

      final DrbDefaultAttributeList list = new DrbDefaultAttributeList();
      /**
       * Initialize the output attribute list.
       */
      for (int i = 0; i < attributes.getLength(); i++)
      {
         final DrbAttribute attrib = attributes.item(i);
         if (attrib != null)
         {
            list.add(new DrbDefaultAttribute(attrib.getName(),
                  attrib.getValue(), this));
         }
      }
      return list;
   }

   /**
    * Root node. The root node retrieval is delegated to the parent node if any.
    * If no parent has been declared for this node, the operation returns a
    * reference to itself.
    * 
    * @return A reference to the root node or null.
    * @see fr.gael.drb.DrbSimpleNode#getRoot()
    */
   public DrbNode getRoot()
   {
      if (this.baseNode != null)
      {
         return this.baseNode.getRoot();
      }
      else
      {
         return this;
      }
   }

   /**
    * The parent of this node. Returns a reference to the parent node of the
    * current node according to the current implementation. Most of the nodes
    * have a parent except root nodes or if they have just been removed, etc. If
    * the node has no parent the operation returns null.
    * 
    * @return The parent of this node or null.
    */
   public DrbNode getParent()
   {
      if (this.baseNode == null)
      {
         return null;
      }
      else
      {
         return this.baseNode.getParent();
      }
   }

   /**
    * The list of children of the XML document. Returns the root XML Element of
    * the document as defined by the W3C. The document may have an empty content
    * and the operation returns therefore a null reference.
    * 
    * @return The list of children if any null otherwise.
    */
   public DrbNodeList getChildren()
   {
      final Node doc_element = this.document.getDocumentElement();
      if (doc_element == null)
      {
         return null;
      }

      final DrbDefaultNodeList list = new DrbDefaultNodeList();
      list.add(new XmlNode(doc_element, this));
      return list;
   }

   /**
    * The root content of the XML document. Returns the content of the document
    * at root level. According to the XML 1.0 specification, the Document node
    * contains the root element (if any), comments and processing instructions.
    * 
    * @return The content of the document at root level.
    */
   public DrbSequence getContent()
   {
      final DrbDefaultSequence list = new DrbDefaultSequence();

      Node child = this.document.getFirstChild();

      while (child != null)
      {
         if (child.getNodeType() == Node.ELEMENT_NODE)
         {
            list.addItem(new XmlNode(child, this));
         }
         else
         {
            list.addItem(new XmlItem(child));
         }
         child = child.getNextSibling();
      }

      if (list.getLength() == 0)
      {
         return null;
      }
      else
      {
         return list;
      }
   }

   /**
    * Tests if a specific interface can be provided. This operations tests with
    * a minimum of time and memory consumption if the current implementation can
    * provide a specific interface. It important to consider that hasImpl()
    * provides information about the ability to provide such interface in
    * general cases but not focused on the current instance. It may therefore be
    * impossible to get a specific implementation from a node whereas hasImpl()
    * operation returns true.
    * 
    * @param api The class type to test.
    * @return true if an implementation of the interface can be provided and
    *         false otherwise.
    */
   @SuppressWarnings ("rawtypes")
   public boolean hasImpl(final Class api)
   {
      if ((this.baseNode != null) && (this.baseNode instanceof DrbNodeImpl))
      {
         return ((DrbNodeImpl) this.baseNode).hasImpl(api);
      }
      else
      {
         return super.hasImpl(api);
      }
   }

   /**
    * Returns a specific implementation. This operation returns a reference to
    * an object implementing a specific interface. This mean is useful to
    * benefit by a specific and direct API instead of using the DrbNode
    * interface. The provided object shall represent the current node such as it
    * is possible after a call to this operation, to dismiss the reference to
    * the node. For instance, a file is usually wrapped as a drb.impl.file.File
    * class and thanks to this operation can be seen as a InputStream enabling
    * direct access to the handled file.
    * 
    * @param api The interface (or class) to be provided.
    * @return A reference to the object implementing the interface or a null
    *         reference otherwise.
    */
   @SuppressWarnings ("rawtypes")
   public Object getImpl(final Class api)
   {
      if ((this.baseNode != null) && (this.baseNode instanceof DrbNodeImpl))
      {
         return ((DrbNodeImpl) this.baseNode).getImpl(api);
      }
      else
      {
         return super.getImpl(api);
      }
   }
}
