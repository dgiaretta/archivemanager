/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.util.ArrayList;
import java.util.List;

import fr.gael.drb.DrbAbstractSequence;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbSequence;

/**
 * Wraps zero or more results of XQuery language.
 */
final class SequenceResult extends DrbAbstractSequence
{
   /**
    * The sequence of partial results.
    */
   private List<DrbSequence> subResults;

   /**
    * The total length of the sequence of results. Initialized to a negative
    * value until first computation.
    */
   private int totalLength = -1;

   /**
    * Constructor of the literal result.
    */
   SequenceResult()
   {
      this.subResults = new ArrayList<DrbSequence>();
   } // SequenceResult

   /**
    * The number of items in the sequence.
    * 
    * @return totalLength
    */
   public int getLength()
   {
      // Compute the sequence length for the first time
      if (this.totalLength < 0)
      {
         this.totalLength = 0;
         for (final DrbSequence result : this.subResults)
         {
            this.totalLength += result.getLength();
         }
      }

      return this.totalLength;
   } // getLength

   /**
    * Append a sub-result in the sequence.
    * 
    * @param sub_result sub_result
    * @throws NullPointerException
    */
   void append(final DrbSequence sub_result)
   {
      // Check argument
      if (sub_result == null)
      {
         throw new NullPointerException("The sub-result cannot be null");
      }

      // Add the sub-result in the list
      this.subResults.add(sub_result);
      this.totalLength = -1; // force computation of length
   } // append

   /**
    * Returns an item at the specified index.
    * 
    * @param index index
    * @return position, index
    * @throws IllegalArgumentException
    */
   public DrbItem getItem(final int index)
   {
      // Case of illegal index:
      if (index < 0)
      {
         throw new IllegalArgumentException("Item index cannot be negative");
      }
      if ((index >= this.totalLength) && (this.totalLength >= 0))
      {
         return null;
      }

      int position = 0;
      /**
       * We iterate over sub-results while the absolute position is less than
       * the target index. Loop invariants: 0 <= position <= index
       * Pre-conditions (unchecked): result.length >= 0 Post-conditions: one of
       * the following 1) Inside a sub-result 2) Index out of bounds
       */
      for (final DrbSequence result : this.subResults)
      {
         final int resultLen = result.getLength();
         /**
          * (1) Case of position inside current sub-result position <= index <
          * position + len 0 <= index - position < len
          */
         if (index < position + resultLen)
         {
            return result.getItem(index - position);
         }
         /**
          * Post-condition 1 is not reached We keep iterating on the sub-results
          */
         else
         {
            position += resultLen;
         }
      }
      this.totalLength = position;
      // (2) Index out of bounds
      return null;
   } // getItem
} // SequenceResult
