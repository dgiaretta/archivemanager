/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

import java.util.logging.Logger;

import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbSequence;

/**
 * Generic array value wrapper.
 */
public abstract class AbstractValueArray extends AbstractValue implements
      ValueArray, Comparison
{
   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself is returned. If the conversion is not allowed a
    * ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException the conversion is impossible
    */
   public Value convertTo(final int type) throws ClassCastException
   {
      if (type == ARRAY_ID)
      {
         return this;
      }

      if (type == STRING_ID)
      {
         return new String(this.toString());
      }

      // Implicit conversion to singleton
      if (this.getLength() == 1)
      {
         return this.getElement(0).convertTo(type);
      }

      throw new ClassCastException();
   }

   /**
    * Convert the array values into the specified type.
    * 
    * @param array_type The target element type.
    * @return The converted value.
    * @throws ClassCastException if the conversion is impossible.
    */
   public ValueArray convertArrayTo(final int array_type)
         throws ClassCastException
   {
      if (array_type == this.getArrayType())
      {
         return this;
      }

      ValueArray target_array = null;
      switch (array_type)
      {
         // Int conversion
         case Value.INT_ID:
            target_array = new IntArray(new int[this.length()]);
            break;

         // Double conversion
         case Value.DOUBLE_ID:
            target_array = new DoubleArray(new double[this.length()]);
            break;

         // Float conversion
         case Value.FLOAT_ID:
            target_array = new FloatArray(new float[this.length()]);
            break;

         // Long conversion
         case Value.LONG_ID:
            target_array = new LongArray(new long[this.length()]);
            break;

         // Short conversion
         case Value.SHORT_ID:
            target_array = new ShortArray(new short[this.length()]);
            break;

         // Byte conversion
         case Value.BYTE_ID:
            target_array = new ByteArray(new byte[this.length()]);
            break;

         // Boolean conversion
         case Value.BOOLEAN_ID:
            target_array = new BooleanArray(new boolean[this.length()]);
            break;

         // UnsignedLong conversion
         case Value.UNSIGNED_LONG_ID:
            target_array = new UnsignedLongArray(new long[this.length()]);
            break;

         // UnsignedInteger conversion
         case Value.UNSIGNED_INT_ID:
            target_array = new UnsignedIntArray(new int[this.length()]);
            break;

         // UnsignedShort conversion
         case Value.UNSIGNED_SHORT_ID:
            target_array = new UnsignedShortArray(new short[this.length()]);
            break;

         // Numeric -> UnsignedByte conversion
         case Value.UNSIGNED_BYTE_ID:
            target_array = new UnsignedByteArray(new byte[this.length()]);
            break;

         default:
            throw new ClassCastException(this.getClass().getName()
                  + ": cannot cast to " + array_type);
      }

      for (int i = 0; i < this.length(); i++)
      {
         target_array.assign(i, this.getElement(i).convertTo(array_type));
      }
      return target_array;
   }

   /**
    * Compare this array with another array.
    * 
    * @param value another array.
    * @return The returned value is :
    *         <ul>
    *         <li> negative if the values of this array are lower than another
    *         the array.
    *         <li> zero if the two array are equal and have the same size
    *         <li> positive if the values of this array are greater than another
    *         the array
    *         </ul>
    *         <p>
    *         The values are compared by increasing rank.
    *         </p>
    *         <p>
    *         A specific case occurs when the two arrays have not the same size.
    *         In that case the result is negative if this array is the smallest
    *         and positive otherwise.
    *         </p>
    */
   public int compareTo(final Value value)
   {
      // TODO : Parameter shall be controlled
      /**
       * Case of strict identity
       */
      if (this == value)
      {
         return 0;
      }
      /**
       * Case of empty array
       */
      if (value == null)
      {
         return this.length();
      }

      final ValueArray value_array =
         (ValueArray) value.convertTo(Value.ARRAY_ID);
      // TODO : access to value_array is not checked before use
      // [DF] a CastException is always thrown when a cast has failed.The value
      // shall never be null.
      final int minLength = Math.min(this.length(), value_array.length());

      for (int i = 0; i < minLength; i++)
      {
         // TODO : the returned values of getElement() operation are not
         // checked before use
         // [DF] The post-condition of getElement() never allow null
         // element if the index is inside the array bounds.
         final int cmp =
            ((Comparison) this.getElement(i)).compareTo(value_array
                  .getElement(i));

         if (cmp != 0)
         {
            return cmp;
         }
      }

      /**
       * Case of array which have not the same size.
       */
      return this.length() - value_array.length();
   }

   /**
    * Returns a specific item of the list. The item is identified by its
    * position (i.e. index or sequence number) in the list of items. The order
    * depends on the implementation as well as from the operation that created
    * the list. The index starts from 0 and shall not be greater or equal to the
    * item count of the list. A null reference is returned if the provided index
    * is outside the list bounds.
    * 
    * TODO: this operation should propagate the IndexOutOfBoundsException
    * instead of masking with a null reference.
    * 
    * @param index The position of the item starting from and not greater or
    *           equal to the item count in the list.
    * @return A reference to specified item or null if no such attribute.
    */
   public DrbItem getItem(final int index)
   {
      try
      {
         return this.getElement(index);
      }
      catch (IndexOutOfBoundsException exception)
      {
         return null;
      }
   }

   /**
    * The atomic values of this sequence. The value of the node means its
    * content. The value is expressed accoring to one of the types supported by
    * the fr.gael.drb.value package. Generally these types correspond to
    * primitive types (e.g. integer, floatting points etc.) or very low level
    * types (e.g. string, date, etc.).
    * 
    * @return A reference to the values of the sequence.
    */
   public ValueArray atomize()
   {
      return this;
   }

   /**
    * The number of items in the list. This number can be 0 if the list is empty
    * but shall never be negative.
    * 
    * @return The number of items is the list.
    */
   public int getLength()
   {
      return this.length();
   }

   /**
    * Inserts a item at a given position. The passed item is inserted in the
    * list of children at the given position The position is the expected index
    * of the item after insertion. All the previous item from the aimed position
    * to the end of the list are shift to the end of the new sequence (i.e.
    * their indices are shifted up of 1). If the given index is out of the
    * sequence bounds and therefore less than zero and greater or equal to the
    * current number of items,the operation raises an exception. An index equal
    * to the current number of item is allowed and the operation is therefore
    * equivalent to an append.
    * 
    * @param index The expected index of the item after the insertion.
    * @param item A reference to the item to be inserted.
    * @return A reference to the a sequence containing the inserted node.
    * @throws NullPointerException This exception is raised when the passed item
    *            a null reference. This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passe
    *            index is less than zero or if it is greater or equal to the
    *            number of item in the sequence prior the call
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested insertion for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbSequence addItem(final int index, final DrbItem item)
         throws NullPointerException, UnsupportedOperationException,
         IndexOutOfBoundsException
   {
      throw new UnsupportedOperationException("AbstractValueArray."
            + "addItem: operation not yet support.");
   }

   /**
    * Removes an existing item. The item at the given index is removed from the
    * sequence of the current item. The item is not modified by this operation.
    * The index of the item to be removed has to correspond to an existing item
    * index. If the index is less than zero or greater or equal to the current
    * number of items, an exception is thrown.
    * 
    * @param index Index of the item to be removed.
    * @return A reference to the a sequence after the removal of the item.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested removal for any
    *            reason.
    */
   public DrbSequence removeItem(final int index)
         throws IndexOutOfBoundsException, UnsupportedOperationException
   {
      throw new UnsupportedOperationException("AbstractValueArray."
            + "removeItem: operation not yet support.");
   }

   /**
    * Main.
    */
   public static void main(final java.lang.String[] args)
   {
      final DefaultValueArray array = new DefaultValueArray(args.length);
      for (int i = 0; i < args.length; i++)
      {
         array.assign(i, new fr.gael.drb.value.String(args[i]));
      }

      final ValueArray array_2 = array.convertArrayTo(Value.INT_ID);
      System.out.println("Converted Array: " + array_2);

   }
} // AbstractValueArray
