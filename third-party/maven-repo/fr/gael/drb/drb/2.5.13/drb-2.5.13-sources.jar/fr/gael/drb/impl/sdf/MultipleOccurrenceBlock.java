/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sdf;

import java.io.EOFException;
import java.io.IOException;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbNode;
import fr.gael.drb.value.Value;

/**
 * Multiple occurrence block. This class provides the implementation of a
 * multiple occurrence block.<br>
 * This is used when a block is part of a multiple occurrence set. Such blocks
 * have the same descriptor reference and are able to give their previous and
 * next sibling with a certain level of optimization (without using superclass
 * and descriptors while possible).
 */
public class MultipleOccurrenceBlock extends DefaultBlock
{
   /**
    * Logger.
    */
   static private Logger logger =
      Logger.getLogger(MultipleOccurrenceBlock.class);

   /**
    * Value of the block, used for performance purpose. Used to store the result
    * after the first getValue() call.
    */
   // private Value value;
   /**
    * The occurrence in the multiple occurrences set. For instance is the block
    * is the 3 of 10 in a set,occurrence is 2 because value starts from 0.
    */
   protected int occurrence;

   /**
    * The number of occurrence(s) in the set.
    */
   protected int occurrenceCount;

   /**
    * The offset of block. Used to make direct access in the file and to compute
    * previous or next sibling offset immediately.
    */
   protected long offset;

   /**
    * The length of block. Used to make direct access in the file and to compute
    * previous or next sibling offset immediately.
    */
   protected long length;

   /**
    * Creates a new instance of MultipleOccurrenceBlock. The descriptor and the
    * key must not be null. The descriptor is used to get information about the
    * block such as name, offset, number of occurrences, etc. The key is the
    * path of the block in the descriptors tree.
    * 
    * @param descriptor The descriptor of the block.
    * @param key The key of the block.
    * @param occurrence_count The number of block occurrence(s) in the set.
    * @param offset The absolute offset of the block.
    * @param length The length of the block.
    */
   protected MultipleOccurrenceBlock(final Descriptor descriptor,
         final int[] key, final int occurrence_count, final long offset,
         final long length)
   {
      // Call superclass operation
      super(descriptor, key);
      // logger.debug("++ Constructor("+((descriptor==null)
      // ?null:descriptor.getName())+ ", "+
      // IntMap.keyToString(key)+", "+occurrence_count+", "+
      // offset+ ", "+length+")");

      // Checks parameters
      // The root block should not be instanciated as MultipleOccurrenceBlock
      // but here we filter this case. The occurrence count must be greater
      // or equal to the last element of the key (the occurrence).
      if ((key.length == 0) || (occurrence_count < 0)
            || (occurrence_count <= key[key.length - 1]))
      {
         logger
               .error("MultipleOccurrenceBlock.MultipleOccurrenceBlock() ERROR: "
                     + "Invalid parameter(s).");
         logger.error("   descriptor name = "
               + ((descriptor == null) ? null : descriptor.getName()));
         logger.error("   key.length      = " + key.length);
         if (key.length == 0)
         {
            logger.error("      The root block should not be instanciated as "
                  + "MultipleOccurrenceBlock !");
         }
         logger.error("   key             = " + IntMap.keyToString(key));
         logger.error("   occurrence_count = " + occurrence_count);
      }

      // Store the values, the occurrence of the block is the last element
      // in its key.
      this.occurrence = key[key.length - 1];
      this.occurrenceCount = occurrence_count;
      this.offset = offset;
      this.length = length;
   }

   /**
    * Returns the value of the block. This implementation uses directly offset
    * and length without getting them from descriptor. The value is read from
    * the file only once. Any further call will return the cached value. If the
    * block is not a leaf (i.e. a node having at least one child), no value is
    * returned.<br>
    * ARRAY_ID type is not supported.<br>
    * Paddings are not supported.
    * 
    * @return The block value.
    */
   public Value getValue()
   {
      // If node has child, no value is returned.
      if (this.hasChild())
      {
         return null;
      }

      // If value has not been read yet, do it.
      if (this.value == null)
      {
         // Get value from file (no ARRAY_ID supported with multiple blocks).
         try
         {
            BlockTools blockTools = new BlockTools();
            this.value =
               blockTools.extractValue(this.descriptor.getFile(), this.offset,
                     0, (int) this.length, 0, this.descriptor.getEncoding(),
                     this.descriptor.getValueType(), 0, 0);
            blockTools = null;
         }
         // Or remove occurrence if EOF is reached
         catch (final EOFException e)
         {
            logger.error(e);
            logger.error("MultipleOccurrenceBlock.getValue(): "
                  + "Unable to read value for node \"" + this.getName()
                  + "\" (key=" + IntMap.keyToString(this.key) + ").");
         }
         catch (final IOException e)
         {
            logger.error(e);
            logger.error("MultipleOccurrenceBlock.getValue(): "
                  + "Unable to read value for node \"" + this.getName()
                  + "\" (key=" + IntMap.keyToString(this.key) + ").");
         }
      }
      return this.value;
   }

   /**
    * Returns the attributes. Attributes can be "encoding", "occurrence",
    * "offset", "length" and "documentation".
    * 
    * @return The list of block attributes.
    */
   public DrbAttributeList getAttributes()
   {
      // Local declarations
      DrbDefaultAttributeList attr_list; // Output attribute list
      DrbDefaultAttribute attr; // Attribute to add in attribute list
      String strTmp; // Temporary string
      fr.gael.drb.value.String str_value; // Attribute string
      fr.gael.drb.value.Long long_value; // Attribute long

      // Creates attribute list
      attr_list = new DrbDefaultAttributeList();

      // Creates encoding attribute
      switch (this.descriptor.getEncoding())
      {
         case Descriptor.ENCODING_BINARY:
            strTmp = "Binary";
            break;
         case Descriptor.ENCODING_ASCII:
            strTmp = "Ascii";
            break;
         case Descriptor.ENCODING_EBCDIC:
            strTmp = "Ebcdic";
            break;
         default:
            strTmp = "Unknown (" + this.descriptor.getEncoding() + ")";
            break;
      }
      str_value = new fr.gael.drb.value.String(strTmp);
      attr = new DrbDefaultAttribute("encoding", str_value, false, this);
      attr_list.add(attr);

      // Creates occurrence attribute
      str_value =
         new fr.gael.drb.value.String((this.occurrence + 1) + "/"
               + this.occurrenceCount);
      attr = new DrbDefaultAttribute("occurrence", str_value, false, this);
      attr_list.add(attr);

      // Creates offset attribute
      long_value = new fr.gael.drb.value.Long(this.offset);
      attr = new DrbDefaultAttribute("offset", long_value, false, this);
      attr_list.add(attr);

      // Creates length attribute
      long_value = new fr.gael.drb.value.Long(this.length);
      attr = new DrbDefaultAttribute("length", long_value, false, this);
      attr_list.add(attr);

      // Creates documentation attribute
      strTmp = this.descriptor.getDocumentation();
      if (strTmp != null)
      {
         str_value = new fr.gael.drb.value.String(strTmp);
         attr =
            new DrbDefaultAttribute("documentation", str_value, false, this);
         attr_list.add(attr);
      }

      // Returns the attribute list if not empty
      if (attr_list.getLength() > 0)
      {
         return attr_list;
      }
      else
      {
         return null;
      }
   }

   /**
    * Returns a new instance of the previous sibling block. In this
    * implementation an optimisation is made for block occurrences having the
    * same block descriptor.
    * 
    * @return A new instance of the previous sibling block or null.
    */
   public DrbNode getPreviousSibling()
   {
      // Local declarations
      Descriptor previousDesc; // reference to a previous descriptor
      int[] previousKey; // Key of the previous sibling
      int descOccurrenceCount; // Occurrence count in the current desc

      // Case of previous sibling in the set
      if (this.occurrence > 0)
      {
         // Create key of the previous sibling
         previousKey = IntMap.getSiblingKey(this.key, this.occurrence - 1);

         // Return a new block with the same descriptor
         return new MultipleOccurrenceBlock(this.descriptor, previousKey,
               this.occurrenceCount, this.offset - this.length, this.length);
      }

      // Loop on previous descriptors until a block occurrence is found.
      previousDesc = this.descriptor;
      while ((previousDesc = previousDesc.getPreviousSibling()) != null)
      {
         // Gets occurrence count of the previous
         previousKey = IntMap.getSiblingKey(this.key, 0);
         descOccurrenceCount = previousDesc.getOccurrenceCount(previousKey);

         // If an occurrence is found, returns the block with the previous desc.
         if (descOccurrenceCount > 0)
         {
            // Creates key of the previous sibling which is the last occurrence
            // in the previous descriptor
            previousKey =
               IntMap.getSiblingKey(this.key, descOccurrenceCount - 1);

            // returns the previous block
            return createOptimalBlock(previousDesc, previousKey,
                  descOccurrenceCount);
         }
      }

      // At this step all previous descriptors have been browsed then no
      // previous sibling exists
      return null;
   }

   /**
    * Returns a new instance of the next sibling block. In this implementation
    * an optimisation is made for block occurrences having the same block
    * descriptor.
    * 
    * @return A new instance of the next sibling block or null.
    */
   public DrbNode getNextSibling()
   {
      // Local declarations
      Descriptor nextDesc; // reference to a next descriptor
      int[] nextKey; // Key of the next sibling
      int descOccurrenceCount; // Occurrence count in the current desc

      // Case of next sibling in the set
      if (this.occurrence < this.occurrenceCount - 1)
      {
         // Create key of the next sibling
         nextKey = IntMap.getSiblingKey(this.key, this.occurrence + 1);

         // Return a new block with the same descriptor
         return new MultipleOccurrenceBlock(this.descriptor, nextKey,
               this.occurrenceCount, this.offset + this.length, this.length);
      }

      // Loop on next descriptors until a block occurrence is found.
      nextDesc = this.descriptor;
      while ((nextDesc = nextDesc.getNextSibling()) != null)
      {
         // Create key of the next sibling
         nextKey = IntMap.getSiblingKey(this.key, 0);

         // If an occurrence is found, returns the block with the next desc.
         if ((descOccurrenceCount = nextDesc.getOccurrenceCount(nextKey)) > 0)
         {
            return createOptimalBlock(nextDesc, nextKey, descOccurrenceCount);
         }
      }

      // At this step all next descriptors have been browsed then no next
      // sibling exists
      return null;
   }

} // MultipleOccurenceBlock
