/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import fr.gael.drb.value.Value;
import fr.gael.drb.xsd.XsdAttribute;

/**
 * Default attribute implementation. This class is a convenient class that
 * implements the DrbAttribute class. It is useful if no specific operations are
 * required for an attribute. It holds a name, a value and enable to configute
 * the specification level (i.e. default value).
 */
public class DrbDefaultAttribute extends DrbAbstractAttribute
{
   /**
    * Name of the attribute.
    */
   private String name;

   /**
    * Attribute namespace identifier. This attribute may be null if no namespace
    * identifier has already been set.
    */
   private String namespaceURI;

   /**
    * Owner of the attribute.
    */
   private DrbNode owner;

   /**
    * Value of the attribute. The value of the attribute is set by the
    * constructor.
    */
   private Value value;

   /**
    * Defaulted value flag.
    */
   private boolean specified;

   /**
    * Schema constructor of an attribute. This operation creates a default
    * attribute from the specified schema
    * 
    * @param decl attribute declaration
    * @param owner The owner node of the attribute.
    */
   public DrbDefaultAttribute(final XsdAttribute decl, final DrbNode owner)
   {
      this.name = decl.getName();
      this.value = decl.getValueConstraint();
      this.owner = owner;
      this.specified = false;
   }

   /**
    * Simple constructor of an attribute. This operation creates an attribute
    * witn a name and its corresponding value but without owner. The value is
    * considered as specified. Both parameters shall never be null.
    * 
    * @param name Name of the attribute.
    * @param value Value of the attribute.
    */
   public DrbDefaultAttribute(final String name, final Value value)
   {
      this(name, value, false, null);

      return;
   }

   /**
    * Constructor of an attribute with an owner. This operation creates an
    * attribute witn a name and its corresponding value with an owner. The value
    * is considered as specified. All parameters shall never be null.
    * 
    * @param name Name of the attribute.
    * @param value Value of the attribute.
    * @param owner The owner node of the attribute.
    */
   public DrbDefaultAttribute(final String name, final Value value,
         final DrbNode owner)
   {
      this(name, value, false, owner);

      return;
   }

   /**
    * Constructor of a defaulted attribute. This operation creates a defaulted
    * attribute witn a name and its corresponding value without owner. The value
    * is considered as specified according to the speicifed parameter. All other
    * parameters shall never be null.
    * 
    * @param name Name of the attribute.
    * @param value Value of the attribute.
    * @param specified True if the attribute is specified and false otherwise.
    */
   public DrbDefaultAttribute(final String name, final Value value,
         final boolean specified)
   {
      this(name, value, specified, null);

      return;
   }

   /**
    * Constructor of a defaulted attribute with an owner. This operation creates
    * a defaulted attribute witn a name and its corresponding nvalue witha
    * specific owner. The value is considered as specified according to the
    * speicifed parameter. All other parameters shall never be null.
    * 
    * @param name Name of the attribute.
    * @param value Value of the attribute.
    * @param specified True if the attribute is specified and false otherwise.
    * @param owner The owner node of the attribute.
    */
   public DrbDefaultAttribute(final String name, final Value value,
         final boolean specified, final DrbNode owner)
   {
      this.name = name;
      this.value = value;
      this.specified = specified;
      this.owner = owner;

      return;
   }

   /**
    * Name of the attribute. Returns the name of the attribute set at
    * construction.
    * 
    * @return The name of the attribute.
    */
   public final String getName()
   {
      return this.name;
   }

   /**
    * Changes the name of the item. This method always throw an
    * UnsupportedOperationException.
    * 
    * @param name Reference to the new name.
    * @throws UnsupportedOperationException This exception always raised because
    *            the name property is not defined for values.
    * @throws NullPointerException This exception is overriden by an
    *            UnsupportedOperationException.
    */
   public final void rename(final java.lang.String name)
         throws NullPointerException, UnsupportedOperationException
   {
      if (name == null)
      {
         throw new NullPointerException("Attribute name shall not be null");
      }

      if (name.equals(""))
      {
         throw new UnsupportedOperationException(
               "Attribute name must not be empty");
      }

      this.name = name;
   }

   /**
    * The node the owning the current attribute. Returns the owner node set at
    * construction. The returned reference may be null.
    * 
    * @return The owner of the attribute.
    */
   public DrbNode getOwner()
   {
      return this.owner;
   }

   /**
    * The value type of the attribute. The returned type is the one of the value
    * passed at construction. The type has not been checked from the
    * construction.
    * 
    * @return The type of the attribute.
    */
   public int getValueType()
   {
      return this.value.getType();
   }

   /**
    * Get namespace URI. The namespace URI of this attribute, or null if it is
    * unspecified. This is not a computed value that is the result of a
    * namespace lookup based on a examination of the namespace declarations in
    * scope. It is merely the namespace URI given at creation time. The
    * Namespaces on an attribute does not inherit its namespace from the element
    * it is attached to. If an attribute is not explicitly given a namespace, it
    * simply has no namespace.
    * 
    * @return The namspace URI or null if unspecified.
    */
   public String getNamespaceURI()
   {
      return this.namespaceURI;
   }

   /**
    * The value of the attribute. The returned value is the one passed at
    * construction.
    * 
    * @return The value of the attribute.
    */
   public Value getValue()
   {
      if (this.value == null)
      {
         return new fr.gael.drb.value.String("");
      }
      else
      {
         return this.value;
      }
   }

   /**
    * The attribute was explicitly given a value. The returned value is the one
    * passed at construction or the default one (i.e. true).
    * 
    * @return false is a defaulted value or true otherwise.
    */
   public boolean isSpecified()
   {
      return this.specified;
   }

   /**
    * Sets the namespace URI. Any previous namespace URI is discarded.
    * 
    * @param namespace_uri A reference to the new namespace identifier.
    * @throws UnsupportedOperationException This exception is never raised
    *            because the operation is fully implemented and accept any
    *            namespace.
    */
   public void setNamespaceURI(final String namespace_uri)
         throws UnsupportedOperationException
   {
      this.namespaceURI = namespace_uri;
   }

   /**
    * Changes the value of the item. This operation sets a new value of the
    * current item.The value type of the item shall be compatible with the item
    * implementation. If the type does not match exactly it is casted to a
    * compatible one based on the the fr.gael.drb.value capabilities. A
    * reference to the effectivelly assigned value is returned by the operation
    * so it is possible to check if a cast has been performed and therefore
    * assess the accuracy of the assignement. If the cast is not possible the
    * operation raises an UnsupportedOperationException. If the assignment is
    * possible and the item implementation has a physical representation the
    * value is updated in the physical source in order to persist among
    * sessions. It therefore possible that this operation consumses an variable
    * time.
    * 
    * @param value The new value of the attribute. This value shall not be null
    * @return The effectivelly assigned value.The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested assignment for
    *            any reason.
    */
   public Value setValue(final Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      // TODO: check value consistency and raise exception as appropriate
      final Value oldValue = this.value;
      this.value = value;
      return oldValue;
   }

   /**
    * Returns a description of the current attribute. The output format is : "@"
    * <name> "=" <value> .
    * 
    * @return the description of the attribute.
    */
   public String toString()
   {
      return "@" + this.getName() + "=" + this.getValue();
   }
}// DrbDefaultAttribute
