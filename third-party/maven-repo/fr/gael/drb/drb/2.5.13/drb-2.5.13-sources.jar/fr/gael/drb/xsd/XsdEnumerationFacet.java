/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.value.Comparison;
import fr.gael.drb.value.DefaultValueArray;
import fr.gael.drb.value.Value;

/**
 * Declaration of an XML-Schema enumeration Facet.
 */
public class XsdEnumerationFacet extends XsdFacet
{

   /**
    * enumeration facet name.
    */
   final static String TAG = "enumeration";

   // ===============================================================
   // Attributes part.
   // ===============================================================
   /**
    * The enumeration values.
    */
   private Value[] values;

   // ===============================================================
   // Methods part.
   // ===============================================================
   /**
    * Build a enumeration facet.
    * 
    * @param values The values
    */
   XsdEnumerationFacet(final Value[] values)
   {
      this.values = values;
   } // XsdEnumerationFacet

   /**
    * Identifier of this facet.
    * 
    * @return The Identifier of this facet.
    */
   public final int getId()
   {
      return ENUMERATION_ID;
   } // getId

   /**
    * The value of this facet.
    * 
    * @return the value
    */
   public Value getValue()
   {
      final DefaultValueArray valueArray =
         new DefaultValueArray(this.values.length);
      for (int i = 0; i < this.values.length; i++)
      {
         valueArray.assign(i, this.values[i]);
      }
      return valueArray;
   }

   /**
    * The enumeration value
    * 
    * @return the enumeration value
    */
   public final Value[] getValues()
   {
      return this.values;
   } // getValues

   /**
    * The name of this facet.
    * 
    * @return The name of this facet
    */
   public final String getName()
   {
      return this.TAG;
   } // getName

   /**
    * Return the enumeration values
    * 
    * @return the enumeration values
    */
   public String toString()
   {
      String str = "{";
      for (int k = 0; k < this.values.length; k++)
      {
         if (k > 0)
         {
            str = str + "; ";
         }
         str = str + this.values[k];
      }
      return str + "}";
   }

   // ------------------------------------------------------------------------
   // ValueValidator interface implementation
   // -----------------------------------------------------------------------
   /**
    * Validates the present value.
    * 
    * @param v the value
    * @return true if the value is valid, else false
    */
   public boolean isValid(final Value v)
   {
      if (v == null)
      {
         return false;
      }
      for (int i = 0; i < this.values.length; i++)
      {
         try
         {
            final Value v2 = v.convertTo(this.values[i].getType());
            if (((Comparison) this.values[i]).compareTo(v2) == 0)
            {
               return true;
            }
         }
         catch (final Exception e)
         {
            // vide
         }
      }
      return false;
   }

   // ========================================================
   // Unitary test part.
   // ========================================================
   /**
    * Makes this class runnable for testing.
    * 
    * @param args string[]
    */
   public static void main(final String[] args)
   {
      System.out.println("Test 1 : <xsd:simpleType name='listOfFloat'>");
      System.out.println("           <xsd:restriction>");
      System.out.println("             <xsd:enumeration value='1 2 3'/>");
      System.out.println("             <xsd:enumeration value='5 6'/>");
      System.out.println("             <xsd:simpleType>");
      System.out.println("               <xsd:list itemType='xsd:float'/>");
      System.out.println("             </xsd:simpleType>");
      System.out.println("           </xsd:restriction>");
      System.out.println("         </xsd:simpleType>\n");

      final XsdFacet[] facets =
         new XsdFacet[] { new XsdEnumerationFacet(new Value[] {
               new fr.gael.drb.value.FloatArray(new float[] { 1, 2, 3 }),
               new fr.gael.drb.value.FloatArray(new float[] { 5, 6 }) }) };
      final XsdAtomicType atomic = new XsdAtomicType(Value.FLOAT_ID, null);
      final XsdListType list = new XsdListType(atomic, facets);

      final Value floatList1 =
         new fr.gael.drb.value.FloatArray(new float[] { 1, 2, 3 });
      final Value floatList2 =
         new fr.gael.drb.value.FloatArray(new float[] { 7, 2, 9 });
      final Value floatList3 =
         new fr.gael.drb.value.FloatArray(new float[] { 5, 6 });

      System.out.println("Checking floatList1 (" + floatList1 + ") -> "
            + list.isValid(floatList1));
      System.out.println("Checking floatList2 (" + floatList2 + ") -> "
            + list.isValid(floatList2));
      System.out.println("Checking floatList3 (" + floatList3 + ") -> "
            + list.isValid(floatList3));
   }

} // XsdEnumerationFacet class
