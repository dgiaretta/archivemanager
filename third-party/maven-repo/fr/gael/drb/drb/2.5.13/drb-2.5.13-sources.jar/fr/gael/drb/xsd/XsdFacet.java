/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultMutableNode;
import fr.gael.drb.DrbNode;
import fr.gael.drb.value.Value;

/**
 * Declaration of an XML-Schema Facet.
 */
public abstract class XsdFacet extends XsdComponent implements ValueValidator
{

   // ===============================================
   // Static part.
   // ===============================================
   /**
    * value tag.
    */
   public final static String VALUE_TAG = "value";

   /**
    * xs:minInclusive facet identifier.
    */
   public final static int MIN_INCLUSIVE_ID = 1;

   /**
    * xs:maxInclusive facet identifier.
    */
   public final static int MAX_INCLUSIVE_ID = 2;

   /**
    * xs:pattern facet identifier.
    */
   public final static int PATTERN_ID = 3;

   /**
    * xs:enumeration facet identifier.
    */
   public final static int ENUMERATION_ID = 4;

   /**
    * xs:minLength facet identifier.
    */
   public final static int MIN_LENGTH_ID = 5;

   /**
    * xs:maxLength facet identifier.
    */
   public final static int MAX_LENGTH_ID = 6;

   /**
    * xs:length facet identifier.
    */
   public final static int LENGTH_ID = 7;

   /**
    * xs:minExclusive facet identifier.
    */
   public final static int MIN_EXCLUSIVE_ID = 8;

   /**
    * xs:maxExclusive facet identifier.
    */
   public final static int MAX_EXCLUSIVE_ID = 9;

   /**
    * xs:whiteSpace facet identifier.
    */
   public final static int WHITE_SPACE_ID = 10;

   /**
    * xs:totalDigits facet identifier.
    */
   public final static int TOTAL_DIGITS_ID = 11;

   /**
    * xs:fractionDigits facet identifier.
    */
   public final static int FRACTION_DIGITS_ID = 12;

   // ==================================================
   // Methods part.
   // ==================================================
   /**
    * Identifier of this facet.
    * 
    * @return the identifier of this facet.
    */
   abstract public int getId();

   /**
    * The name of this facet.
    * 
    * @return the name
    */
   abstract public String getName();

   /**
    * The value of this facet.
    * 
    * @return the value
    */
   public Value getValue()
   {
      return null;
   }

   // --------------------------------------------------------
   // XsdComponent class overloading
   // -------------------------------------------------------
   /**
    * Format this component into a string.
    * 
    * @return The node
    */
   DrbNode toNode()
   {
      Value value = this.getValue();
      if (value == null)
      {
         value = new fr.gael.drb.value.String("");
      }
      final DrbNode node = new DrbDefaultMutableNode(this.getName());
      node.setNamespaceURI(Namespace.XML_SCHEMA_NAMESPACE);
      final DrbAttribute value_attrib =
         new DrbDefaultAttribute("value", value, true, node);
      final DrbDefaultAttributeList attrib_list = new DrbDefaultAttributeList();
      attrib_list.add(value_attrib);
      node.setAttributes(attrib_list);
      return node;
   } // toNode

} // XsdFacet class
