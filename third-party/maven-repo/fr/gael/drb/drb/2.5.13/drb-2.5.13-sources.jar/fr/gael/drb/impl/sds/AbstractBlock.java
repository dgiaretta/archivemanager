/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import java.util.Arrays;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.DrbNodesChangeEvent;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.value.Value;
import fr.gael.drb.xsd.XsdInvalid;
import fr.gael.drb.xsd.XsdNode;

/**
 * Abstract block. This class provides the abstract implementation of DrbNode
 * for the Structured Data File block. Most of the operations are implemented
 * here but as a block always getting information from its descriptor. Therefore
 * a set of subclasses should store such information into cache to improve
 * performance.
 */
abstract class AbstractBlock extends DrbNodeImpl implements XsdNode
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(AbstractBlock.class);

   /**
    * The SDF namespace URI.
    */
   public static String SDF_NAMESPACE = "http://www.gael.fr/2005/04/drb/sdf";

   /**
    * Descriptor of the block. Reference to the block descriptor. The descriptor
    * is used to access the file and information about the block
    */
   protected Descriptor descriptor;

   /**
    * Descriptor of the block. Reference to the block descriptor. The descriptor
    * is used to access the file and information about the block
    */
   protected Descriptor baseDescriptor;

   /**
    * Key of the block in the Structured Data File tree. This is an array
    * containing the occurrence indexes of the block and all its ancestors up to
    * the root block of the structured file. Root index is omitted because is
    * always 0. Values start from 0 for the first index. The number of indexes
    * corresponds to the depth in the tree, having depth=0 for the root block.
    */
   protected int[] key;

   /**
    * Initializes the class attributes. As the class is abstract, this
    * operations can only be called by subclasses as super(descriptor,key).<br>
    * The descriptor and the key must not be null.
    * 
    * @param descriptor The descriptor of the block.
    * @param key The key of the block.
    */
   protected AbstractBlock(final Descriptor descriptor, final int[] key)
   {
      // Check parameters
      if ((descriptor == null) || (key == null))
      {
         this.logger.error("AbstractBlock.AbstractBlock() ERROR: "
               + "Invalid parameter(s).");
         if (descriptor == null)
         {
            this.logger.error("   descriptor       = null");
         }
         else
         {
            this.logger.error("   descriptor.name  = " + descriptor.getName());
         }
         this.logger.error("   key              = " + IntMap.keyToString(key));
      }

      // Set the values
      this.descriptor = descriptor.getInstance(key);
      this.baseDescriptor = descriptor.getBase();
      this.key = key;
   }

   /**
    * Name of the block. This name is the canonical name of the block and is
    * directly extracted from the descriptor.
    * 
    * @return The name of the block.
    */
   public final String getName()
   {
      return this.descriptor.getName();
   }

   /**
    * The namespace URI of this node.
    * 
    * @return the target namespace specified in the schema element.
    */
   public final String getNamespaceURI()
   {
      if (this.descriptor.getSchema() == null)
      {
         return null;
      }
      else
      {
         return this.descriptor.getSchema().getTargetNamespace();
      }
   }

   /**
    * Offset of the block. Returns the offset of the block in the underlying
    * RandomAccessFile.
    * 
    * @return The offset in bytes.
    */
   protected Length getOffset()
   {
      return this.descriptor.getOffset(this.key);
   }

   /**
    * Length of the block. Returns the length of the block (children included).
    * 
    * @return The length in bytes.
    */
   protected Length getLength()
   {
      return this.descriptor.getLength(this.key);
   }

   /**
    * Name of the node. Returns the name of the node. This name is the canonical
    * name of the node It does not contains any prefix, path and location
    * part.This name clearly identifies the node in its parent depending only
    * from its occurence number and its index. All nodes provided by an
    * implementation is named. Therefore this operation never returns null
    * value. An empty string is however allowed if the node is unique (e.g. non
    * named root node).
    * 
    * @return The name of the node.
    */
   public String getXPathName()
   {
      // Get occurrence at the current sdf tree depth
      if (this.key.length == 0)
      {
         /**
          * TODO: the former code was including the schema location with the
          * special syntax created by GAEL for this purpose i.e. non standard
          * path: return "(" + this.descriptor.getSchemaNodePath() + ")" +
          * this.descriptor.getRoot().getName(); It has been removed since a
          * metadata resolver has been made available and, in particular, since
          * that DRB Cortex Extension is available i.e. the use of this special
          * syntax should almost disappear. However, in the case of user defined
          * schema different from the one provided by the metadata resolver, the
          * path to this specific schema should be provided: to be implemented.
          */
         return this.descriptor.getRoot().getName();
      }

      // Case of single occurrence, do not print the occurrence
      final String desc_name = this.descriptor.getName();

      // Local declarations
      Descriptor childDesc = null; // reference to a child descriptor
      int occurrence = 0; // Current occurrence

      // Loop on children descriptors of the parent until to find the same as
      // the current descriptor.
      if (this.descriptor.getParent() != null)
      {
         childDesc = this.descriptor.getParent().getFirstChild();
      }

      while (childDesc != null)
      {
         // Add occurrence number of this child descriptor to the count.
         if (childDesc.isSame(desc_name))
         {
            int child_occurs;

            // If block descriptor is the same as the current child
            // descriptor, returns the count of previous blocks plus the
            // corresponding block occurrence (the last element of the key).
            if (this.baseDescriptor == childDesc)
            {
               child_occurs = this.key[this.key.length - 1] + 1;
            }
            else
            // As block occurrence number can only be fixed or constant in the
            // parent, the value can be retreived with a key having the same
            // "parent key" prefix. Then the current block key can be used.
            {
               child_occurs = childDesc.getOccurrenceCount(this.key);
            }

            // If block descriptor is a substitution group, we must
            // evaluate the name of each occurrence.
            if (childDesc.getSubstitutionCount() > 0)
            {
               final int[] child_key = IntMap.getSiblingKey(this.key, 0);
               Descriptor child_instance_desc = null;
               for (int i = 0; i < child_occurs; i++)
               {
                  child_key[child_key.length - 1] = i;
                  child_instance_desc = childDesc.getInstance(child_key);
                  if (desc_name.equals(child_instance_desc.getName()))
                  {
                     occurrence++;
                  }
               }
            }
            else
            {
               occurrence += child_occurs;
            }

            // If block descriptor is the same as the current child
            // then we have already count every occurrence of this name.
            if (this.baseDescriptor == childDesc)
            {
               break;
            }
         }

         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
      }

      if (occurrence <= 1)
      {
         return desc_name;
      }
      // Else print the occurrence (e.g. "/mds[1]")
      else
      {
         return desc_name + "[" + occurrence + "]";
      }
   }

   /**
    * Returns an attribute matching a specific name.
    * 
    * @param name The name to match.
    * @return A reference to the attribute or null is not found.
    */
   public DrbAttribute getAttribute(final String name)
   {
      if (name == null)
      {
         return null;
      }

      String strTmp;
      // Creates documentation attribute
      if (name.equals("documentation"))
      {
         strTmp = this.descriptor.getDocumentation();
         if (strTmp == null)
         {
            return null;
         }
         final Value str_value = new fr.gael.drb.value.String(strTmp);
         final DrbDefaultAttribute attr =
            new DrbDefaultAttribute("documentation", str_value, false, this);
         attr.setNamespaceURI(SDF_NAMESPACE);
         return attr;
      }
      else
      // xpath
      if (name.equals("xpath"))
      {
         final String file_path = this.descriptor.getFileNodePath();
         if (file_path != null)
         {
            final Value str_value = new fr.gael.drb.value.String(file_path);
            final DrbDefaultAttribute attr =
               new DrbDefaultAttribute("xpath", str_value, false, this);
            attr.setNamespaceURI(SDF_NAMESPACE);
            return attr;
         }
         return null;
      }
      else if (name.equals("encoding"))
      {
         if (this.getValueType() == Value.NULL_ID)
         {
            return null;
         }
         // Creates encoding attribute
         switch (this.descriptor.getEncoding())
         {
            case Descriptor.ENCODING_BINARY:
               strTmp = "Binary";
               break;
            case Descriptor.ENCODING_TEXT:
               strTmp = this.descriptor.charsetName;
               break;
            default:
               strTmp = "Unknown (" + this.descriptor.getEncoding() + ")";
               break;
         }
         final Value str_value = new fr.gael.drb.value.String(strTmp);
         final DrbDefaultAttribute attr =
            new DrbDefaultAttribute("encoding", str_value, false, this);
         attr.setNamespaceURI(SDF_NAMESPACE);
         return attr;
      }
      else
      // Creates byteOrder attribute
      if (name.equals("byteOrder"))
      {
         if (this.getValueType() == Value.NULL_ID)
         {
            return null;
         }
         switch (this.descriptor.getByteOrdering())
         {
            case Descriptor.BYTE_ORDERING_LSB:
               strTmp = "LSB";
               break;
            case Descriptor.BYTE_ORDERING_MSB:
               strTmp = "MSB";
               break;
            default:
               strTmp = "(" + this.descriptor.getByteOrdering() + ")";
               break;
         }
         final Value str_value = new fr.gael.drb.value.String(strTmp);
         final DrbDefaultAttribute attr =
            new DrbDefaultAttribute("byteOrder", str_value, false, this);
         attr.setNamespaceURI(SDF_NAMESPACE);
         return attr;
      }
      else
      // Creates occurrence attribute
      if (name.equals("occurrence"))
      {
         final int occurrence =
            (this.key.length > 0) ? this.key[this.key.length - 1] : 1;
         final Value long_value = new fr.gael.drb.value.Long(occurrence + 1);
         final DrbDefaultAttribute attr =
            new DrbDefaultAttribute("occurrence", long_value, false, this);
         attr.setNamespaceURI(SDF_NAMESPACE);
         return attr;
      }
      else
      // Creates offset attribute
      if (name.equals("offset"))
      {
         // Creates offset attribute
         final Value long_value =
            new fr.gael.drb.value.Long(this.getOffset().getLength());
         final DrbDefaultAttribute attr =
            new DrbDefaultAttribute("offset", long_value, false, this);
         attr.setNamespaceURI(SDF_NAMESPACE);
         return attr;
      }
      else
      // Creates bit-offset attribute
      if (name.equals("bitOffset"))
      {
         // Creates offset attribute
         final Value long_value =
            new fr.gael.drb.value.Long(this.getOffset().getBitLength());
         final DrbDefaultAttribute attr =
            new DrbDefaultAttribute("bitOffset", long_value, false, this);
         attr.setNamespaceURI(SDF_NAMESPACE);
         return attr;
      }
      else
      // Creates length attribute
      if (name.equals("length"))
      {
         // Creates offset attribute
         final Value long_value =
            new fr.gael.drb.value.Long(this.getLength().getLength());
         final DrbDefaultAttribute attr =
            new DrbDefaultAttribute("length", long_value, false, this);
         attr.setNamespaceURI(SDF_NAMESPACE);
         return attr;
      }
      else
      // Creates bit-length attribute
      if (name.equals("bitLength"))
      {
         // Creates offset attribute
         final Value long_value =
            new fr.gael.drb.value.Long(this.getLength().getBitLength());
         final DrbDefaultAttribute attr =
            new DrbDefaultAttribute("bitLength", long_value, false, this);
         attr.setNamespaceURI(SDF_NAMESPACE);
         return attr;
      }
      return null;
   }

   /**
    * Returns always null.
    * 
    * @return null.
    */
   public DrbAttributeList getAttributes()
   {
      return null;
   } // End getAttributes()

   /**
    * Returns the value of the block. This operation is left as abstract here.
    * According to the block type, several optimisation levels can be provided.
    * Therefore implementation must be decided by sub-classes.
    * 
    * @return The block value.
    */
   public abstract Value getValue();

   /**
    * Returns the value type of the block. This operation is left as abstract
    * here. According to the block type, several optimisation levels can be
    * provided. Therefore implementation must be decided by sub-classes.
    * 
    * @return The block value type.
    */
   public abstract int getValueType();

   /**
    * Index of the block. Returns the index of the block in its parent block.
    * This implementation uses the parent descriptor to parse all children and
    * count blocks until the current one.<br>
    * No cache is performed, descriptors are used on each call.
    * 
    * @return The index of the block or a negative value.
    */
   public int getIndex()
   {
      // Local declarations
      Descriptor childDesc; // reference to a child descriptor
      int curIndex; // Current index
      // Case of root block
      if (this.key.length == 0)
      {
         return 0;
      }

      // Loop on children descriptors of the parent until to find the same as
      // the current descriptor.
      curIndex = 0;
      childDesc = this.descriptor.getParent().getFirstChild();
      while (childDesc != null)
      {
         // If block descriptor is the same as the current child
         // descriptor, returns the count of previous blocks plus the
         // corresponding block occurrence (the last element of the key).
         if (this.baseDescriptor == childDesc)
         {
            return (curIndex + this.key[this.key.length - 1]);
         }

         // Add occurrence number of this child descriptor to the count.
         // As block occurrence number can only be fixed or constant in the
         // parent, the value can be retreived with a key having the same
         // "parent key" prefix. Then the current block key can be used.
         curIndex += childDesc.getOccurrenceCount(this.key);

         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
      }

      // At this step all children descriptors have been browsed then this
      // case cannot exists
      this.logger.error("AbstractBlock.getIndex() ERROR: "
            + "This message should never appear !");
      this.logger.error("   No descriptor in the parent matches the "
            + "current one = " + this.descriptor);
      return -1;
   }

   /**
    * Returns a new instance of the root block. If the current block is the root
    * block then return the block itself.<br>
    * Uses the current descriptor and the root descriptor to create a new
    * instance of the root block.
    * 
    * @return A new instance of the root block.
    */
   public DrbNode getRoot()
   {
      // Check if current block is already the root.
      if (this.key.length == 0)
      {
         return this;
      }

      // The root block has an empty array key.
      return new DefaultBlock(this.baseDescriptor.getRoot(), new int[] {});

   }

   /**
    * Returns a new instance of the root block. If the current block is the root
    * block then return the block itself.<br>
    * Uses the current descriptor and the root descriptor to create a new
    * instance of the root block.
    * 
    * @return A new instance of the root block.
    */
   protected AbstractBlock getRootBlock()
   {
      // Check if current block is already the root.
      if (this.key.length == 0)
      {
         return this;
      }

      // The root block has an empty array key.
      return new DefaultBlock(this.baseDescriptor.getRoot(), new int[] {});
   }

   /**
    * Returns a new instance of the parent block. If the current block is the
    * root block returns null.<br>
    * Uses the current descriptor and its parent to create the parent block.
    * 
    * @return A new instance of the parent block or null.
    */
   public DrbNode getParent()
   {
      // Local declarations
      Descriptor parentDesc; // Parent descriptor
      int[] parentKey; // Parent key

      // Case of "root" block : it has no parent then returns null
      if (this.key.length == 0)
      {
         return this.baseDescriptor.getBaseNode();
      }
      /*
       * if (parentRef != null) { DrbNode parent = (DrbNode)parentRef.get(); if
       * (parent != null) return parent; }
       */
      // Get parent related information
      parentDesc = this.baseDescriptor.getParent();
      parentKey = IntMap.getParentKey(this.key);

      final DrbNode block = createOptimalBlock(parentDesc, parentKey, -1);
      // parentDesc.getOccurrenceCount(parentKey));

      return block;
   }

   /**
    * Returns a new instance of the list of children blocks. If the block has no
    * child returns null.<br>
    * This implementation uses the descriptor to parse all its children and
    * create a new instance of each corresponding block. These blocks are then
    * added to the list.<br>
    * 
    * @return A new list of children if any, null otherwise.
    */
   public DrbNodeList getChildren()
   {
      // Local declarations
      DrbDefaultNodeList children; // List of children
      Descriptor childDesc; // reference to a child descriptor
      int childDescOccurrenceCount; // occurrence count of child desc

      // Create the children list
      children = new DrbDefaultNodeList();

      // Loop on child descriptors
      childDesc = this.descriptor.getFirstChild();
      while (childDesc != null)
      {
         // Loops on block occurrences of the current child descriptor.
         childDescOccurrenceCount =
            childDesc.getOccurrenceCount(IntMap.getChildKey(this.key, 0));
         for (int i = 0; i < childDescOccurrenceCount; i++)
         {
            children.add(createOptimalBlock(childDesc, IntMap.getChildKey(
                  this.key, i), childDescOccurrenceCount));
         }

         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
      }

      // If no child returns null
      if (children.size() == 0)
      {
         return null;
      }

      // Returns the children list
      return children;
   }

   /**
    * Returns true if at least one child exists for the current block. Browses
    * the children descriptors until one block occurrence exists.<br>
    * If the current descriptor has no child then returns false.<br>
    * If all the children descriptors have no block occurrence then returns
    * false.<br>
    * No cache is performed, descriptors are used on each call.
    * 
    * @return true if this block has at least one child, false otherwise.
    */
   public boolean hasChild()
   {
      // Local declarations
      Descriptor childDesc; // reference to a child descriptor

      // Loop on child descriptors until one occurrence is found.
      childDesc = this.descriptor.getFirstChild();
      while (childDesc != null)
      {
         // If an occurrence is found, return true
         if (childDesc.getOccurrenceCount(IntMap.getChildKey(this.key, 0), 1L) > 0)
         {
            return true;
         }

         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
      }

      // At this step all children descriptors have been browsed but no
      // block occurrence found.
      return false;
   }

   /**
    * Returns a new instance of the first child of the current block. Browses
    * the children descriptors until one block occurrence exists and returns it.<br>
    * If the current descriptor has no child then returns null.<br>
    * If all the children descriptors have no block occurrence then returns
    * null.
    * 
    * @return A new instance of the first child block or null.
    */
   public DrbNode getFirstChild()
   {
      // Local declarations
      Descriptor childDesc; // reference to a child descriptor
      int[] childKey; // Key of the child
      int childDescOccurrenceCount; // occurrence count of child desc

      // Loop on child descriptors until one occurrence is found.
      childDesc = this.descriptor.getFirstChild();
      while (childDesc != null)
      {
         // Create child key
         childKey = IntMap.getChildKey(this.key, 0);

         // If an occurrence is found, returns the corresponding block.
         if ((childDescOccurrenceCount =
            childDesc.getOccurrenceCount(childKey, 1L)) > 0)
         {
            return createOptimalBlock(childDesc, childKey,
                  childDescOccurrenceCount);
         }

         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
      }

      // At this step all children descriptors have been browsed but no
      // block occurrence found.
      return null;
   }

   /**
    * Returns a new instance of the last child of the current block. This
    * implementation calls getChildAt(getChildrenCount()-1).<br>
    * Therefore performance is low because descriptors are used 2 times at each
    * call.
    * 
    * @return A new instance of the last child block or null.
    */
   public DrbNode getLastChild()
   {
      return this.getChildAt(this.getChildrenCount() - 1);
   }

   /**
    * Returns a new instance of the "index"th child of the current block.
    * Browses the children descriptors, counts block occurrences until the
    * "index"th and returns it.<br>
    * If the current descriptor has no child then returns null.<br>
    * If index is outside the range of children count then returns null.
    * 
    * @param index The position of the child block to retreive starting from 0
    *           and not greater or equal to the number of children.
    * @return A new instance of the "index"th child block or null.
    */
   public DrbNode getChildAt(final int index)
   {
      // Local declarations
      Descriptor childDesc; // reference to a child descriptor
      int[] childKey; // Key of the child
      int childrenCount; // total number of children
      int descOccurrenceCount; // occurrence number in current desc

      // Check parameter
      if (index < 0)
      {
         return null;
      }

      // Loop on child descriptors until one occurrence is found.
      childrenCount = 0;
      childDesc = this.descriptor.getFirstChild();
      while (childDesc != null)
      {
         // Create child key
         childKey = IntMap.getChildKey(this.key, index - childrenCount);

         // If index corresponds to the occurrences of the current child
         // descriptor, returns the corresponding block.
         if ((descOccurrenceCount =
            childDesc.getOccurrenceCount(IntMap.getChildKey(this.key, 0), 
            		(long)index - childrenCount + 1)) > index - childrenCount)
         {
            DrbNode child_block = null; // getChildBlock(desc_index,
            // child_occurs);
            // Create a new child reference, if necessary
            if (child_block == null)
            {
               child_block =
                  createOptimalBlock(childDesc, childKey, descOccurrenceCount);
               // putChildBlock(child_block);
            }
            // Remove useless child references
            return child_block;
         }

         // Add occurrence number of this child descriptor to the count
         childrenCount += descOccurrenceCount;

         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
      }

      // At this step all children descriptors have been browsed but no
      // block occurrence found.
      // this.logger.warn("<" + descriptor.getPath() + ">.getChildAt("+index+"):
      // Out
      // of bounds !");
      return null;
   }

   /**
    * Returns a new instance of the child block having the given name and the
    * given occurrence. This implementation browses the children descriptors
    * until to match the given name, then get the associated block occurrence if
    * exists.<br>
    * If the current descriptor has no child then returns null.<br>
    * If no block having this occurrence exists then returns null.
    * 
    * @param name The name of the child block to retreive.
    * @param occurrence The occurrence of the child block to retreive, value
    *           starting from 1.
    * @return A new instance of the child block having the given name and
    *         occurrence.
    */
   public DrbNode getNamedChild(final String name, int occurrence)
   {
      // Local declarations
      Descriptor childDesc; // reference to a child descriptor
      int[] childKey; // Key of the child
      int descOccurrenceCount; // occurrence number in current desc

      // Check parameter
      if (occurrence < 1)
      {
         this.logger.error("getNamedChild() Error : " + "Invalid occurrence ("
               + occurrence + ").");
         return null;
      }

      // Loop on child descriptors until name is found.
      childDesc = this.descriptor.getFirstChild();
      boolean found = false;
      while (childDesc != null)
      {
         // If the descriptor name matches the given name
         if (childDesc.getName().equals(name))
         {
            // Create first named child key
            childKey = IntMap.getChildKey(this.key, 0);
            found = true;
            // If occurrence is in range of the current occurrence count then
            // returns the corresponding block.
            if ((descOccurrenceCount =
               childDesc.getOccurrenceCount(childKey, (long)occurrence)) >= occurrence)
            {
               // Create child key for this occurrence, only the last key
               // item has to be changed (value starts from 0).
               childKey[childKey.length - 1] = occurrence - 1;

               // Return the created block
               final DrbNode block =
                  createOptimalBlock(childDesc, childKey, descOccurrenceCount);

               return block;
            }

            // At this step the name was matched but occurrence was bigger than
            // occurrence count then the current occurrence count is
            // substracted in case another node has the same name
            occurrence = occurrence - descOccurrenceCount;
         }

         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
      }

      // At this step all children descriptors have been browsed but none
      // with the given name then perform a full search.

      if (!found)
      {
         int occurs = 0;
         for (int i = 0;; i++)
         {
            final DrbNode child = this.getChildAt(i);
            if (child == null)
            {
               return null;
            }
            if (child.getName().equals(name))
            {
               occurs++;
               if (occurs == occurrence)
               {
                  return child;
               }
            }
         }
      }
      return null;
   }

   /**
    * Returns the number of children of the current block. Browses the children
    * descriptors to count all children occurrences for the current block.<br>
    * If the current descriptor has no child then returns 0.<br>
    * If all children descriptors have no block occurrence then returns 0.<br>
    * No cache is performed, descriptors are used on each call.
    * 
    * @return The number of children for the current block.
    */
   public int getChildrenCount()
   {
      // Local declarations
      Descriptor childDesc; // reference to a child descriptor
      int childrenCount; // number of children

      // Loop on child descriptors.
      childrenCount = 0;
      childDesc = this.descriptor.getFirstChild();
      while (childDesc != null)
      {
         // Add occurrence number of this child descriptor to the count
         childrenCount +=
            childDesc.getOccurrenceCount(IntMap.getChildKey(this.key, 0));

         // Go to the next child descriptor
         childDesc = childDesc.getNextSibling();
      }

      // All children descriptors have been browsed then returns the
      // children block count.
      return childrenCount;
   }

   /**
    * Returns a new instance of the previous sibling block. This implementation
    * uses getParent().getChildAt(getIndex()-1).<br>
    * Therefore performance is low because descriptors are parsed 2 times at
    * each call.
    * 
    * @return A new instance of the previous sibling block or null.
    */
   public DrbNode getPreviousSibling()
   {
      return ((AbstractBlock) this.getParent()).getChildAt(this.getIndex() - 1);
   }

   /**
    * Returns a new instance of the next sibling block. Uses the current
    * descriptors and its next sibling if needed, because the next sibling block
    * can have the same descriptor (in case of multiple occurrences) or another
    * next sibling descriptor (having at least one block occurrence).
    * 
    * @return A new instance of the next sibling block or null.
    */
   public DrbNode getNextSibling()
   {
      // Local declarations
      Descriptor nextDesc; // reference to a next descriptor
      int[] nextKey; // Key of the next sibling
      int curOccurrence; // Occurrence of the block in its desc
      int descOccurrenceCount; // Occurrence count in the current desc

      // Case of root block
      if (this.key.length == 0)
      {
         return null;
      }

      // If the descriptor has multiple occurrences and the current occurrence
      // is lower, then returns the next sibling with the same descriptor
      curOccurrence = this.key[this.key.length - 1] + 1;
      descOccurrenceCount =
         this.baseDescriptor.getOccurrenceCount(IntMap
               .getSiblingKey(this.key, 0), (long)curOccurrence + 1);
      if (curOccurrence < descOccurrenceCount)
      {
         return createOptimalBlock(this.baseDescriptor, IntMap.getSiblingKey(
               this.key, curOccurrence), descOccurrenceCount);
      }

      // Loop on next descriptors until a block occurrence is found.
      nextDesc = this.baseDescriptor;
      while ((nextDesc = nextDesc.getNextSibling()) != null)
      {
         // Create key of the next sibling
         nextKey = IntMap.getSiblingKey(this.key, 0);

         // If an occurrence is found, returns the block with the next desc.
         if ((descOccurrenceCount = nextDesc.getOccurrenceCount(nextKey, 1L)) > 0)
         {
            return createOptimalBlock(nextDesc, nextKey, descOccurrenceCount);
         }
      }

      // At this step all next descriptors have been browsed then no next
      // sibling exists
      return null;
   }

   /**
    * Creates a new instance of AbstractBlock with the best implementation.
    * Depending of the passed values the optimal sub-class is selected.
    * 
    * @param descriptor The descriptor of the block.
    * @param key The key of the block.
    * @param occurrence_count The number of block occurrence(s) in the set.
    * @return AbstractBlock
    */
   protected static final DrbNode createOptimalBlock(
         final Descriptor descriptor, final int[] key, final int occurrence_count)
   {
      final AbstractBlock new_block = descriptor.createOptimalBlock(key);
      if (descriptor.viewDesc != null)
      {
         final DrbNode view_node =
            new SdfNodeView(descriptor.viewDesc, new_block);
         return view_node;
      }
      else
      {
         return new_block;
      }
   }

   /**
    * Indicates whether this node is "equal to" to another node. See
    * Object.equals() for the general contract of this method.
    * 
    * @param obj another value.
    * @return true if this object is the same as the obj argument
    */
   public boolean equals(final Object obj)
   {
      // Check reference equality
      if (this == obj)
      {
         return true;
      }

      // Check equality of key and descriptor
      if (obj instanceof AbstractBlock)
      {
         final AbstractBlock block = (AbstractBlock) obj;
         return (this.descriptor == block.descriptor)
               && (Arrays.equals(this.key, block.key));
      }

      // Otherwise the object is different
      return false;
   } // equals

   /*-----------------------------------------------------------------------*/
   /* DrbNodeImpl Interface */
   /*-----------------------------------------------------------------------*/
   /**
    * Closes this node and releases any system resources associated with the
    * pointed file. A closed node cannot perform input or output operations and
    * cannot be reopened.
    * 
    * @param deep if this flag is disabled,the implementation shall not release
    *           the ressources shared with the descendants.
    */
   public void close(final boolean deep)
   {
      // Only the root can be closed.
      // If the deep flag is not activated, we do not close the children
      if (deep && (this.descriptor != null) && (this.key.length == 0))
      {
         this.descriptor.dispose();
      }
   }

   /*---------------------------------------------------------------------*/
   /* XsdNode Interface */
   /*---------------------------------------------------------------------*/
   /**
    * Check the conformance of a node to its type.
    * 
    * @return an object describing the errors encoutered or null if there are no
    *         errors.
    */
   public XsdInvalid isValid()
   {
      if (this.descriptor.getType() == null)
      {
         return null;
      }
      else
      {
         return this.descriptor.getType().isValid(this);
      }
   } // isValid

   /*------------------------------------------------------------------------*/
   /* DrbMutableNode Interface */
   /*------------------------------------------------------------------------*/
   /**
    * Changes the name of the node. In this implementation the operation is not
    * supported because a node name depends on the underlying associated schema.
    * <p>
    * <b>Events:</b> No particular event is fired in this implementation.
    * </p>
    * 
    * @param name Reference to the new name (unused).
    * @throws UnsupportedOperationException This exception is always raised in
    *            this implementation.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    */
   public void rename(final String name) throws NullPointerException,
         UnsupportedOperationException
   {
      if (!this.descriptor.getName().equals(name))
      {
         throw new UnsupportedOperationException(
               "AbstractBlock.rename(): This operation is not supported. "
                     + "SDF node name is defined by the underlying schema.");
      }
   }

   /**
    * Changes the value of the node. This implementation wraps the setValue()
    * operation from the descriptor. The value is written in the file using
    * offset and length declared or computed through the block descriptor and
    * corresponding to the current block occurrence.
    * <p>
    * <b>Events:</b> No particular event is fired in this implementation.
    * </p>
    * 
    * @param value The new value of the node. This value shall not be null.
    * @return The effectivelly assigned value. The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            offset or the length used to write is unknown.
    */
   public Value setValue(final Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      // Check passed value
      if (value == null)
      {
         throw new NullPointerException("AbstractBlock.setValue(): "
               + "The reference to the new value is null.");
      }
      // Wrap to Descriptor
      return this.descriptor.setValue(value, this.key);
   }

   /**
    * Set the attribute list of a node. In this implementation the operation is
    * not supported because node attributes are computed according to the file
    * instance and the underlying schema.
    * <p>
    * <b>Events:</b> No particular event is fired in this implementation.
    * </p>
    * 
    * @param attributes A reference to the new attribute list (unused).
    * @throws UnsupportedOperationException This exception is always raised in
    *            this implementation.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the node is null.
    */
   public void setAttributes(final DrbAttributeList attributes)
         throws NullPointerException, UnsupportedOperationException
   {
      throw new UnsupportedOperationException(
            "AbstractBlock.setAttributes(): This operation is not supported. "
                  + "SDF node attributes are computed according to the"
                  + " file instance " + "and the underlying schema.");
   }

   /**
    * Sets a namespace resource identifier. In this implementation the operation
    * is not supported because the SDF namespace is already defined and
    * constant.
    * <p>
    * <b>Events:</b> No particular event is fired in this implementation.
    * </p>
    * 
    * @param namespace_uri A reference to the new namespace identifier (unused)
    * @throws UnsupportedOperationException This exception is always raised in
    *            this implementation.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the node is null.
    */
   public void setNamespaceURI(final String namespace_uri)
         throws NullPointerException, UnsupportedOperationException
   {
      final String target_namespace =
         this.descriptor.getSchema().getTargetNamespace();
      if ((target_namespace != namespace_uri)
            && ((target_namespace == null) || !target_namespace
                  .equals(namespace_uri)))
      {
         throw new UnsupportedOperationException(
               "AbstractBlock.setNamespaceURI(): This operation is not supported. "
                     + "SDF namespace is defined and constant.");
      }
   }

   /**
    * Inserts a child at a given position. In this implementation the operation
    * is wrapped to the appendChild() because the order is fixed by the
    * underlying schema.
    * <p>
    * <b>Events:</b> No particular event is fired yet in this implementation.
    * </p>
    * 
    * @param node A reference to the node to be inserted.
    * @param index The expected index of the node after the insertion (unused).
    * @return A reference to the effectively inserted node. This reference
    *         always differs from the input one in this implementation.
    * @throws UnsupportedOperationException This exception is always raised in
    *            this implementation.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the node is null.
    * @throws IndexOutOfBoundsException This exception is raised when the list
    *            of child is too long.
    */
   public DrbNode insertChild(final DrbNode node, final int index)
         throws NullPointerException, UnsupportedOperationException,
         IndexOutOfBoundsException
   {
      // Checks the passed node
      if (node == null)
      {
         throw new NullPointerException("AbstractBlock.insertChild(): "
               + "The reference to the node to append is null.");
      }

      // Search the child node
      final int children_count = this.getChildrenCount();
      if ((index < 0) || (index > children_count))
      {
         throw new IndexOutOfBoundsException("AbstractBlock.insertChild(): "
               + "The child index is not valid (" + index + ").");
      }
      if (index == children_count)
      {
         return this.appendChild(node);
      }

      try
      {
         final AbstractBlock child = (AbstractBlock) this.getChildAt(index);
         // Case of same node found at index
         // Add a new occurrence
         if (child.baseDescriptor.isSame(node.getName()))
         {
            final DrbNode insert_child =
               child.baseDescriptor.insert(node, child.key, true, 1);

            /**
             * Fires structure change event.
             */
            final DrbDefaultNodeList node_list = new DrbDefaultNodeList();
            node_list.add(this);
            this.structureChanged(new DrbNodesChangeEvent(this, node_list));
            return insert_child;
         }

         // Otherwise, search the node in the previous child
         Descriptor childDesc; // reference to a child descriptor
         int[] childKey; // Key of the child
         int descOccurrenceCount; // occurrence number in current desc

         // Case of node found at index - 1
         if (index == 0)
         {
            childDesc = this.descriptor.getFirstChild();
         }
         else
         {
            childDesc =
               ((AbstractBlock) this.getChildAt(index - 1)).baseDescriptor;
         }
         while ((childDesc != null) && (childDesc != child.baseDescriptor))
         {
            // Case of descriptor : add a new occurrence
            if (childDesc.isSame(node.getName()))
            {
               // Create first named child key
               childKey = IntMap.getChildKey(this.key, 0);
               descOccurrenceCount = childDesc.getOccurrenceCount(childKey);
               // Create child key for this occurrence, only the last key
               // item has to be changed (value starts from 0).
               childKey[childKey.length - 1] = descOccurrenceCount;
               final DrbNode insert_child =
                  childDesc.insert(node, childKey, true, 1);

               /**
                * Fires structure change event.
                */
               final DrbDefaultNodeList node_list = new DrbDefaultNodeList();
               node_list.add(this);
               this.structureChanged(new DrbNodesChangeEvent(this, node_list));

               return insert_child;
            }
            // Go to the next child descriptor
            childDesc = childDesc.getNextSibling();
         }
      }
      catch (final java.io.IOException e)
      {
         this.logger.error("AbstractBlock.insertChild(): I/O error ("
               + e.getMessage() + ")");
         throw new UnsupportedOperationException(this.descriptor.getPath()
               + ": insertChild at index " + index
               + " failed due to an I/O error (" + e.getMessage() + ")");
      }

      throw new UnsupportedOperationException(
            "AbstractBlock.insertChild(): This operation is not supported. ");
   }

   /**
    * Appends a child at the end of the children list. This implementation wraps
    * the appendChild() operation from the descriptor All values are recursively
    * written using the offsets and lengths corresponding to each block
    * descriptor and block occurrence. The order depends on the underlying
    * descriptor.
    * <p>
    * <b>Events:</b> No particular event is fired yet in this implementation.
    * </p>
    * 
    * @param node A reference to the node to be appended.
    * @return A reference to the node passed in parameter.
    * @throws NullPointerException This exception is raised when the passed node
    *            is a null reference.
    * @throws UnsupportedOperationException This exception is raised when the
    *            current block cannot accept any child or if the child name does
    *            not match any valid children name from the descriptor.
    */
   public DrbNode appendChild(final DrbNode node) throws NullPointerException,
         UnsupportedOperationException
   {
      // Checks the passed node
      if (node == null)
      {
         throw new NullPointerException("AbstractBlock.appendChild(): "
               + "The reference to the node to append is null.");
      }

      try
      {
         // Wrap to Descriptor
         return this.descriptor.appendChild(node, this.key, true, 1);
      }
      catch (final java.io.IOException e)
      {
         this.logger.error("AbstractBlock.appendChild(): I/O error ("
               + e.getMessage() + ")");
         throw new UnsupportedOperationException(this.descriptor.getPath()
               + ": appendChild failed due to an I/O error (" + e.getMessage()
               + ")");
      }
   }

   /**
    * Replaces a child of the current node. In this implementation the operation
    * is not supported yet.
    * 
    * @param index Index of the node to be replaced. This index starts at 0 and
    *           shall be less than the number of children (unused).
    * @param new_node A reference to the node that replaces the old one(unused)
    * @return null.
    * @throws UnsupportedOperationException This exception is always raised in
    *            this implementation.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the node is null.
    * @throws IndexOutOfBoundsException This exception is raised when the list
    *            of child is too long.
    */
   public DrbNode replaceChild(final int index, final DrbNode new_node)
         throws NullPointerException, IndexOutOfBoundsException,
         UnsupportedOperationException
   {
      final AbstractBlock child = (AbstractBlock) this.getChildAt(index);
      if ((index < 0) || (child == null))
      {
         throw new IndexOutOfBoundsException("AbstractBlock.replaceChild(): "
               + "The child index is not valid (" + index + ").");
      }
      if (child.baseDescriptor.isSame(new_node.getName()))
      {
         try
         {
            final DrbNode replace_child =
               child.baseDescriptor.replace(new_node, child.key, true, 0);
            /**
             * Fires structure change event.
             */
            final DrbDefaultNodeList node_list = new DrbDefaultNodeList();
            node_list.add(replace_child);
            this.structureChanged(new DrbNodesChangeEvent(this, node_list));

            return replace_child;
         }
         catch (final java.io.IOException e)
         {
            this.logger.error("AbstractBlock.replaceChild(): I/O error ("
                  + e.getMessage() + ")");
            throw new UnsupportedOperationException(this.descriptor.getPath()
                  + ": replaceChild failed due to an I/O error ("
                  + e.getMessage() + ")");
         }
         catch (final NullPointerException e)
         {
            e.printStackTrace();
            throw new UnsupportedOperationException(this.descriptor.getPath()
                  + ": replaceChild failed");
         }
      }
      else
      {
         this.removeChild(index);
         return this.insertChild(new_node, index);
      }
   }

   /**
    * Removes an existing child. In this implementation the operation is not
    * supported yet. In the future it will probably remove the reference to the
    * child block using the specified index and removing one occurrence in the
    * related Descriptor.
    * <p>
    * <b>Events:</b> No particular event is fired in this implementation.
    * </p>
    * 
    * @param index Index of the child to be removed (unused).
    * @throws UnsupportedOperationException This exception is always raised in
    *            this implementation.
    * @throws IndexOutOfBoundsException This exception is raised when the list
    *            of child is too long.
    */
   public void removeChild(final int index) throws IndexOutOfBoundsException,
         UnsupportedOperationException
   {
      final AbstractBlock child = (AbstractBlock) this.getChildAt(index);
      if (child != null)
      {
         child.descriptor.remove(child.key);
         /**
          * Fires structure change event.
          */
         final DrbDefaultNodeList node_list = new DrbDefaultNodeList();
         node_list.add(this);
         this.structureChanged(new DrbNodesChangeEvent(this, node_list));
      }
      else
      {
         this.logger.error(this.getName() + ":AbstractBlock.removeChild("
               + index + ") - child not found");
      }
   }

   /*------------------------------------------------------------------------*/
   /* End of DrbMutableNode Interface */
   /*------------------------------------------------------------------------*/

   /**
    * Print the AbstractBlock info into a string. For instance string can have
    * the following format : "{ "MER_RR__1P/MDS/MDSR" {0 1} }". Where the first
    * element is the descriptor name tree and the {0 1} list the key of the
    * block.
    * 
    * @return The string containing key info.
    */
   public String toString()
   {
      // Print the descriptors tree names
      String info = this.descriptor.getName();
      Descriptor tmp = this.descriptor;
      while ((tmp = tmp.getParent()) != null)
      {
         info = tmp.getName() + "/" + info;
      }
      info = "{ \"" + info + "\" ";

      // Print the key and return info string
      info = info + IntMap.keyToString(this.key) + " }";
      return info;
   }

} // AbstractBlock
