/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Vector;

import fr.gael.drb.DrbSequence;

/**
 * Wraps a sequence of comma separated single expressions.
 */
class SequenceExpression extends AbstractExpression
{
   /**
    * Collection of expressions
    */
   private Vector<Expression> expression = new Vector<Expression>();

   /**
    * Builds the sequence expression with a token.
    * 
    * @param token the token related to the declaration of the expression.
    */
   public SequenceExpression(final Token token)
   {
      /**
       * Call the constructor of the abstract superclass.
       */
      super("Sequence", token);
   }

   /**
    * Builds the sequence expression with a token and a first expression.
    * 
    * @param token the token related to the declaration of the expression.
    * @param expression first expression to be inserted in the collection.
    */
   public SequenceExpression(final Token token, final Expression expression)
   {
      /**
       * Call the constructor of the abstract superclass.
       */
      this(token);

      /**
       * Add the first expression in the collection.
       */
      this.addExpression(expression);
   }

   /**
    * Add an expression in the collection.
    * 
    * @param expression expression to be inserted.
    */
   public void addExpression(final Expression expression)
   {
      this.expression.add(expression);
   }

   /**
    * Evaluates the collection.
    * <p>
    * Each member of the collection is evaluated and the results of the
    * evaluation are aggregated in an output default sequence. TODO: The class
    * shall implement DrbSequence and return this.
    * </p>
    * <p>
    * Between the processing of each evaluated sequence, the cancellation
    * request is checked and processed shoud the occasion arise.
    * </p>
    * 
    * @param context context the outer-focus of the evaluation.
    * @return the sequence resulting from the dynamic evaluation.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {
      final SequenceResult sequence = new SequenceResult();

      /**
       * Loops on the input expressions, evaluate it and collect the results in
       * the output default sequence.
       */
      for (int iexpr = 0; iexpr < this.expression.size(); iexpr++)
      {
         /**
          * Check the cancellation request.
          */
         if (this.isCancellationRequested() == true)
         {
            this.throwCancelException();
         }

         /**
          * Evaluates the current sub-expression.
          */
         final DrbSequence expressionSequence =
            (this.expression.get(iexpr)).evaluate(context);

         /**
          * Concatenate the resulting sequence in the output sequence.
          */
         sequence.append(expressionSequence);
      }

      return sequence;

   }

   /**
    * Propagate cancellation request to the sub-expressions. The processing of
    * the cancellation for the current expression is left to the abstract super
    * class.
    * 
    * @param reason a explicit message describing the origin or reason of the
    *           cancellation request. This reason will be reported in the
    *           message of the cancel exception.
    */
   public void cancel(final String reason)
   {
      /**
       * Call the super class implementation.
       */
      super.cancel(reason);

      /**
       * Propagate the cancellation request to the sub-expressions.
       */
      for (int iexpr = 0; iexpr < this.expression.size(); iexpr++)
      {
         (this.expression.get(iexpr)).cancel(reason);
      }
   }

   /**
    * Returns the sequence expression as a string.
    * 
    * @return the string reporting the syntax of a sequence of expression.
    */
   public String toString()
   {
      String s = "(";
      for (final Iterator it = this.iterator(); it.hasNext();)
      {
         s += it.next().toString();
         if (it.hasNext())
         {
            s += ", ";
         }
      }
      s += ")";

      return s;
   }

   /**
    * A expression which is constant means that it need no context item to be
    * evaluate. The returned sequence from its evaluation will always be the
    * same along the query script
    * 
    * @return true if this expression is constant
    */
   public boolean isConstant()
   {

      boolean bool = true;

      for (final Iterator it = this.iterator(); it.hasNext();)
      {
         bool = bool && (((Expression) it.next()).isConstant());
      }
      return bool;
   }

   /**
    * Checks if this comma expression can modify the state of an existing node.
    * A comma expression is updating if any operand is updating.
    * 
    * @return true if this expression performs updating operations and false
    *         otherwise
    */
   public boolean isUpdating()
   {
      boolean bool = false;

      for (final Iterator it = this.iterator(); it.hasNext();)
      {
         bool = bool || (((Expression) it.next()).isUpdating());
      }
      return bool;
   }

   /**
    * Return a new iterator of sequence of expressions
    * 
    * @return The iterator of the sequence of expressions
    */
   public Iterator iterator()
   {
      return new SequenceExpressionIterator();
   }

   /**
    * SequenceExpressionIterator allow user to browse a sequence of expressions
    * 
    * @return The iterator of the sequence of expressions
    */
   public class SequenceExpressionIterator implements Iterator
   {

      private Iterator iterator;

      /**
       * Construction of a new iterator
       */
      public SequenceExpressionIterator()
      {
         this.iterator = SequenceExpression.this.expression.iterator();
      }

      /**
       * This method is not supported by this iterator
       * 
       * @exception UnsupportedOperationException
       */
      public void remove()
      {
         throw new UnsupportedOperationException(
               "Removing an expression from a sequenceExpression is not supported");
      }

      /**
       * Returns true if the iteration has more elements. (In other words,
       * returns true if next would return an element rather than throwing an
       * exception.)
       * 
       * @return true if the iterator has more elements.
       */
      public boolean hasNext()
      {
         return this.iterator.hasNext();
      }

      /**
       * Returns the next element in the iteration.
       * 
       * @return the next element in the iteration.
       * @exception NoSuchElementException iteration has no more elements.
       */
      public Object next()
      {
         return this.iterator.next();
      }

   }
}
