/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

/**
 * Static exception of an XQuery static analysis phase.
 * <p>
 * A static error is an error that must be detected during the analysis phase. A
 * syntax error is an example of a static error.
 * </p>
 * <p>
 * In addition to the detailed error message, this exception provides the
 * co-oordinates of the static error in the original script: begin to end lines
 * or column where the static occurred.
 * </p>
 */
public class StaticException extends RuntimeException
{
   /**
    * The potential original parse exception. If the static exception is
    * originating from the token manager, the original exception is kept as
    * attribute.
    */
   private ParseException parseException = null;

   /**
    * Keeps the token class associated to the error. The token will provide
    * information regarding the location of the error in the input source.
    */
   private Token token;

   /**
    * Builds a static exception with a message.
    * 
    * @param message the exception message should fit <error> in the sentence "<error>
    *           at line l, column c.". It shall therefore be a single line
    *           message whith no trailing sign or symbol (e.g. no trailing
    *           point, comma or question mark).
    * @param token token involved in the error or null detected outside parsing.
    */
   protected StaticException(final String message, final Token token)
   {
      super(message);

      this.token = token;
   }

   /**
    * Builds a static exception from a parse exception of the token manager.
    * 
    * @param exception the originated parse exception.
    */
   protected StaticException(final ParseException exception)
   {
      this.parseException = exception;
      this.token = exception.currentToken;
   }

   /**
    * Accessor of the encapsulated parse exception.
    * 
    * @return the parse exception.
    */
   protected ParseException getParseException()
   {
      return this.parseException;
   }

   /**
    * Returns the line number where the static error has stared.
    * 
    * @return line the error started or -1 if not available.
    */
   public int getBeginLine()
   {
      if (this.token != null)
      {
         return this.token.beginLine;
      }
      else
      {
         return -1;
      }
   }

   /**
    * Returns the line number where the static error has ended.
    * 
    * @return line the error ended or -1 if not available.
    */
   public int getEndLine()
   {
      if (this.token != null)
      {
         return this.token.endLine;
      }
      else
      {
         return -1;
      }
   }

   /**
    * Returns the column number where the static error has started.
    * 
    * @return column the error started or -1 if not available.
    */
   public int getBeginColumn()
   {
      if (this.token != null)
      {
         return this.token.beginColumn;
      }
      else
      {
         return -1;
      }
   }

   /**
    * Returns the column number where the static error has ended.
    * 
    * @return line the error ended or -1 if not available.
    */
   public int getEndColumn()
   {
      if (this.token != null)
      {
         return this.token.endColumn;
      }
      else
      {
         return -1;
      }
   }

   /**
    * Returns a short exception message. An example of output message would be:
    * 
    * <pre>
    * Static error at line 1, column 26.
    * XQ0053 - The URI of namespace prefix &quot;ns&quot; cannot be a zero-length string.
    * </pre>
    * 
    * It is a committment that the output message ends with a trailing ".".
    * 
    * @return the exception message.
    */
   public String getMessage()
   {
      if (this.parseException != null)
      {
         int max_size = 0;
         for (int i = 0; i < this.parseException.expectedTokenSequences.length; i++)
         {
            if (max_size < this.parseException.expectedTokenSequences[i].length)
            {
               max_size = this.parseException.expectedTokenSequences[i].length;
            }
         }

         String output_message = "Unexpected \"";

         Token token = this.parseException.currentToken.next;

         for (int i = 0; i < max_size; i++)
         {
            if (i != 0)
            {
               output_message += " ";
            }

            if (token.kind == 0)
            {
               output_message += this.parseException.tokenImage[0];
               break;
            }

            output_message += this.parseException.add_escapes(token.image);
            token = token.next;
         }

         output_message +=
            "\" at line " + this.parseException.currentToken.next.beginLine
                  + ", column "
                  + this.parseException.currentToken.next.beginColumn + ".";

         return output_message;
      }
      else
      {
         return super.getMessage() + " at line " + this.getBeginLine()
               + ", column " + this.getBeginColumn() + ".";
      }
   }

   /**
    * Returns a detailed exception message. When the static error is a syntax
    * error raised by the token manager, the detailed exception message reports
    * the list of expected token in lieu of the encoutered one.
    * 
    * @return the exception message.
    */
   public String getDetailedMessage()
   {
      if (this.parseException != null)
      {
         return this.parseException.getMessage() + ".";
      }
      else
      {
         return super.getMessage() + " at line " + this.getBeginLine()
               + ", column " + this.getBeginColumn() + ".";
      }
   }
}
