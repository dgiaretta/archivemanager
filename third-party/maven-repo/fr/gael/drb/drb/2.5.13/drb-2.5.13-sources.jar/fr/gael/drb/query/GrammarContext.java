/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.awt.Color;
import java.awt.Font;
import java.util.Hashtable;

import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;

import org.apache.log4j.Logger;

/**
 * A collection of styles used to render xquery script. This class also acts as
 * a factory for the views used to represent the grammarized documents. Since
 * the rendering styles are based upon view preferences, the views need a way to
 * gain access to the style settings which is facilitated by implementing the
 * factory in the style storage. Both functionalities can be widely shared
 * across grammarized document views.
 */
public class GrammarContext extends StyleContext
{
   /**
    * Logger of this class.
    */
   private Logger logger = Logger.getLogger(GrammarContext.class);

   /**
    * TokenElements style and values to be used.
    */
   private TokenElement[] tokens = null;

   /**
    * Hash table to access tokens.
    */
   private Hashtable hashTokens = null;

   /**
    * Comment color.
    */
   public Color commentColor = new Color(0, 115, 0);

   /**
    * Default font.
    */
   public Font defaultFont = new Font("Monospaced", 0, 14);

   // /////////////////
   // TODO The TokenElement shall be inserted into a hash map to increase the
   // access speed.
   // /////////////////

   /**
    * Constructs a set of styles to represent java lexical tokens. By default
    * there are no colors or fonts specified.
    */
   public GrammarContext()
   {
      super();

      this.initialize();
   }

   /**
    * Sets the default font size.
    * 
    * @param font_size the default font size to be used.
    */
   public void setDefaultFontSize(final float font_size)
   {
      this.defaultFont = this.defaultFont.deriveFont(font_size);

      final Style root = this.getStyle(DEFAULT_STYLE);
      final int n = this.tokens.length;

      for (int i = 0; i < n; i++)
      {
         final TokenElement current_token = this.tokens[i];
         Style parent = this.getStyle(current_token.getCategory());

         if (parent == null)
         {
            parent = this.addStyle(current_token.getCategory(), root);
         }

         final Style current_style = this.addStyle(null, parent);

         current_token.setFont(current_token.getFont().deriveFont(font_size));

         current_style
               .addAttribute(TokenElement.TOKEN_ATTRIBUTE, current_token);
         current_token.setStyle(current_style);
         StyleConstants.setFontFamily(current_style, current_token.getFont()
               .getFamily());
         StyleConstants.setFontSize(current_style, current_token.getFont()
               .getSize());
         StyleConstants
               .setBold(current_style, current_token.getFont().isBold());
         StyleConstants.setItalic(current_style, current_token.getFont()
               .isItalic());
         StyleConstants.setForeground(current_style, current_token.getColor());
      }

      this.rehash();
   }

   /**
    * Initializes the tokens and the style.
    */
   private void initialize()
   {
      final Color darkBlue = new Color(0, 0, 139);
      final Color darkGreen = new Color(0, 115, 0);
      final Color darkRed = new Color(139, 0, 0);

      this.tokens =
         new TokenElement[] {
               // keyWord
               new TokenElement("\"xquery\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"version\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"module\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"declare\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"namespace\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"default\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"element\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"function\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"collation\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"xmlspace\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"preserve\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"strip\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"base-uri\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"variable\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"external\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"as\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"union\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"except\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"intersect\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"or\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"and\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"div\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"mod\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"in\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"return\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"then\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"else\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"to\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"where\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"for\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"let\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"if\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"at\"", this.defaultFont
                     .deriveFont(Font.BOLD), darkBlue),
               new TokenElement("\"@\"",
                     this.defaultFont.deriveFont(Font.BOLD), darkBlue),

               // stringStyle
               new TokenElement("<StringLiteral>", Color.blue),
               new TokenElement("<AposAttContentChar>", Color.blue),
               new TokenElement("<QuotAttContentChar>", Color.blue),
               new TokenElement("<ElementContentChar>", Color.blue),
               // numericStyle
               new TokenElement("<Digits>", Color.blue),
               new TokenElement("<Digit>", Color.blue),
               new TokenElement("<IntegerLiteral>", Color.blue),
               new TokenElement("\"e\"", Color.blue),
               new TokenElement("\"E\"", Color.blue),

               // commentStyle
               new TokenElement("\":)\"", darkGreen),
               new TokenElement("\"(:\"", darkGreen),
               new TokenElement("\":)\"", darkGreen),
               new TokenElement("\"--}\"", darkGreen),
               new TokenElement("\"{--\"", darkGreen),
               new TokenElement("\"--}\"", darkGreen),
               // functionStyle
               // variableStyle
               new TokenElement("<Variable>", darkRed),
               // pathStyle
               // xmlStyle
               new TokenElement("<EndTag>", darkRed),
               new TokenElement("<StartTagOpen>", darkRed),
               new TokenElement("\"/>\"", darkRed),
               new TokenElement("\">\"", darkRed),
               new TokenElement("\"<\"", darkRed),
               new TokenElement("<NCName>", darkRed),
               new TokenElement("<NCNameChar>", darkRed),
               new TokenElement("<Nmstart>", darkRed),
               new TokenElement("<URIPrefix>", darkRed),
               // other
               new TokenElement("<QName>", Color.black),
               new TokenElement("\"?\"", Color.black),
               new TokenElement("\"|\"", Color.black),
               new TokenElement("\"}\"", Color.black),
               new TokenElement("\"\\\"\"", Color.black),
               new TokenElement("\"\\\'\"", Color.black),
               new TokenElement("\"=\"", Color.black),
               new TokenElement("\"\\\"\"", Color.black),
               new TokenElement("\"\\\'\"", Color.black),
               new TokenElement("\"{\"", Color.black),
               new TokenElement("\"*\"", Color.black),
               new TokenElement("<Slash>", Color.black),
               new TokenElement("\"!=\"", Color.black),
               new TokenElement("\"<=\"", Color.black),
               new TokenElement("\">=\"", Color.black),
               new TokenElement("\":=\"", Color.black),
               new TokenElement("\">\"", Color.black),
               new TokenElement("\"-\"", Color.black),
               new TokenElement("\"+\"", Color.black),
               new TokenElement("\"(\"", Color.black),
               new TokenElement("\"[\"", Color.black),
               new TokenElement("\")\"", Color.black),
               new TokenElement("\"]\"", Color.black),
               new TokenElement("\",\"", Color.black),
               new TokenElement("\":\"", Color.black),
               new TokenElement("\";\"", Color.black),
               new TokenElement("\".\"", Color.black),
               new TokenElement("\"..\"", Color.black),
               new TokenElement("<Char>", Color.black),
               new TokenElement("<Letter>", Color.black),
               new TokenElement("<BaseChar>", Color.black),
               new TokenElement("<BaseCharSpec>", Color.black),
               new TokenElement("<Ideographic>", Color.black),
               new TokenElement("<CombiningChar>", Color.black),
               new TokenElement("<Extender>", Color.black), };

      final Style root = this.getStyle(DEFAULT_STYLE);
      final int n = this.tokens.length;

      for (int i = 0; i < n; i++)
      {
         final TokenElement current_token = this.tokens[i];
         Style parent = this.getStyle(current_token.getCategory());

         if (parent == null)
         {
            parent = this.addStyle(current_token.getCategory(), root);
         }

         final Style current_style = this.addStyle(null, parent);
         current_style
               .addAttribute(TokenElement.TOKEN_ATTRIBUTE, current_token);
         current_token.setStyle(current_style);
         StyleConstants.setFontFamily(current_style, current_token.getFont()
               .getFamily());
         StyleConstants.setFontSize(current_style, current_token.getFont()
               .getSize());
         StyleConstants
               .setBold(current_style, current_token.getFont().isBold());
         StyleConstants.setItalic(current_style, current_token.getFont()
               .isItalic());
         StyleConstants.setForeground(current_style, current_token.getColor());
      }

      this.rehash();
   }

   /**
    * Put the token elements into the hash table.
    */
   private void rehash()
   {
      if (this.tokens == null)
      {
         return;
      }

      final int n = this.tokens.length;

      if (n <= 0)
      {
         return;
      }

      this.hashTokens = new Hashtable();

      for (int i = 0; i < n; i++)
      {
         final TokenElement current_token = this.tokens[i];
         this.hashTokens.put(new Integer(current_token.hashCode()),
               current_token);
      }
   }

   /**
    * Retrieve the token with the specified scan value.
    * 
    * @param code the token scan value.
    * @return the token or null.
    */
   private TokenElement getTokenElement(final int code)
   {
      final Integer hash_code = new Integer(code);

      if (this.hashTokens.containsKey(hash_code))
      {
         return (TokenElement) (this.hashTokens.get(hash_code));
      }

      return null;
      /*
       * // TODO The token shall be inserted into a HasMap if (tokens == null)
       * return null; int n = tokens.length; for (int i = 0; i < n; i++) {
       * TokenElement current_token = tokens[i]; if ((current_token != null) &&
       * (current_token.getScanValue() == code)) { return current_token; } }
       * return null;
       */
   }

   /**
    * Fetch the foreground color to use for a lexical token with the given
    * value.
    * 
    * @param code the token code.
    * @return the associated foreground color.
    */
   public Color getForeground(final int code)
   {
      final TokenElement current_token = this.getTokenElement(code);

      if (current_token != null)
      {
         return current_token.getColor();
      }

      return Color.black;
   }

   /**
    * Returns the default font.
    * 
    * @return the associated font.
    */
   public Font getDefaultFont()
   {
      return this.defaultFont;
   }

   /**
    * Fetch the font to use for a lexical token with the given scan value.
    * 
    * @param code the token code.
    * @return the associated font.
    */
   public Font getFont(final int code)
   {
      final TokenElement current_token = this.getTokenElement(code);

      if (current_token != null)
      {
         return current_token.getFont();
      }

      return this.getDefaultFont();
   }

   /**
    * Fetches the attribute set to use for the given scan code. The set is
    * stored in a table to facilitate relatively fast access to use in
    * conjunction with the scanner.
    * 
    * @param code the token code.
    * @return the associated style.
    */
   public Style getStyleForScanValue(final int code)
   {
      final TokenElement current_token = this.getTokenElement(code);

      if (current_token != null)
      {
         return current_token.getStyle();
      }

      return null;
   }
}
