/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import java.util.HashMap;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultMutableNode;
import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbNode;
import fr.gael.drb.value.Value;

/**
 * Declaration of an XML-Schema complex type.
 */
public class XsdComplexType extends XsdType implements NodeValidator,
      ValueValidator
{

   // ====================================================================
   // Static part.
   // ====================================================================
   /**
    * complexType tag.
    */
   final static String TAG = "complexType";

   /**
    * complexContent tag.
    */
   final static String COMPLEX_CONTENT_TAG = "complexContent";

   /**
    * simpleContent tag.
    */
   final static String SIMPLE_CONTENT_TAG = "simpleContent";

   // ===================================================
   // Attributes part.
   // ===================================================
   /**
    * The simple content type.
    */
   XsdSimpleType simpleContent = null;

   /**
    * The complex content type.
    */
   XsdModelGroup complexContent = null;

   /**
    * The attribute group.
    */
   XsdAttributeGroup attribute = null;

   /**
    * Map of type definition.
    */
   private HashMap typeMap = new HashMap();

   /**
    * Map of attribute definition.
    */
   private HashMap attributeMap = new HashMap();

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(XsdComplexType.class);

   // =====================================================
   // Methods part.
   // =====================================================
   /**
    * Build a complex type with a complex content.
    * 
    * @param name The name type
    * @param complex_content The model group
    * @param base_type The type
    */
   public XsdComplexType(final String name,
         final XsdModelGroup complex_content, final XsdType base_type)
   {
      this(name, null, complex_content, base_type, EXTENSION_METHOD);
   }

   /**
    * Build a complex type with a complex content.
    * 
    * @param name The name type
    * @param complex_content The model group
    * @param base_type The type
    * @param derivation_method The derivation method
    */
   XsdComplexType(final String name, final XsdModelGroup complex_content,
         final XsdType base_type, final int derivation_method)
   {
      this(name, null, complex_content, base_type, derivation_method);
   }

   /**
    * Build a complex type with a complex content.
    * 
    * @param name The name type
    * @param complex_content The model group
    * @param base_type The type
    * @param derivation_method The derivation method
    * @param attrib_group The attribute group
    */
   public XsdComplexType(final String name, XsdAttributeGroup attrib_group,
         XsdModelGroup complex_content, final XsdType base_type,
         final int derivation_method)
   {
      super(name, base_type);

      this.derivationMethod = derivation_method;

      // Check attribute group
      if (attrib_group == null)
      {
         attrib_group = new XsdAttributeGroup(null, new XsdAttribute[] {});
      }
      // Check complex content
      if (complex_content == null)
      {
         complex_content =
            new XsdModelGroup(1, 1, new XsdElement[] {},
                  XsdModelGroup.SEQUENCE_MODEL);
      }
      // Performs derivation either by extension or restriction
      if (base_type != null)
      {
         final DrbDefaultNodeList node_list = new DrbDefaultNodeList();
         if (base_type.getExternalNodes() != null)
         {
            for (int k = 0; k < base_type.getExternalNodes().getLength(); k++)
            {
               node_list.add(base_type.getExternalNodes().item(k));
            }
            if (this.getExternalNodes() != null)
            {
               for (int k = 0; k < this.getExternalNodes().getLength(); k++)
               {
                  node_list.add(this.getExternalNodes().item(k));
               }
            }
            this.setExternalNodes(node_list);
         }
      }
      if ((base_type != null) && base_type.isComplex())
      {
         final XsdModelGroup base_content =
            ((XsdComplexType) base_type).getComplexContent();
         if (base_content != null)
         {
            if (derivation_method == EXTENSION_METHOD)
            {
               complex_content =
                  base_content.deriveByExtension(complex_content);
            }
            else if (derivation_method == RESTRICTION_METHOD)
            {
               complex_content =
                  base_content.deriveByRestriction(complex_content);
            }
         }
         final XsdAttributeGroup base_attribs =
            ((XsdComplexType) base_type).getAttributeGroup();
         // TBC : derivation by restriction
         if (base_attribs != null)
         {
            attrib_group = base_attribs.deriveByExtension(attrib_group);
         }
      }
      if (base_type != null)
      {
         this.simpleContent = base_type.getDatatype();
      }
      this.complexContent = complex_content;
      this.mapType(complex_content);
      this.attribute = attrib_group;
      this.mapAttribute(attrib_group);
   } // XsdComplexType

   /**
    * Build a complex type with a simple content.
    * 
    * @param name The name type
    * @param base_type The type
    * @param derivation_method The derivation method
    * @param attrib_group The attribute group
    * @param facets The facets
    */
   XsdComplexType(final String name, XsdAttributeGroup attrib_group,
         XsdFacet[] facets, final XsdType base_type, final int derivation_method)
   {
      super(name, base_type);

      this.derivationMethod = derivation_method;

      // Check attribute group
      if (attrib_group == null)
      {
         attrib_group = new XsdAttributeGroup(null, new XsdAttribute[] {});
      }
      // Check facets
      if (facets == null)
      {
         facets = new XsdFacet[] {};
      }
      // Build external nodes
      if (base_type != null)
      {
         final DrbDefaultNodeList node_list = new DrbDefaultNodeList();
         if (base_type.getExternalNodes() != null)
         {
            for (int k = 0; k < base_type.getExternalNodes().getLength(); k++)
            {
               node_list.add(base_type.getExternalNodes().item(k));
            }
            if (this.getExternalNodes() != null)
            {
               for (int k = 0; k < this.getExternalNodes().getLength(); k++)
               {
                  node_list.add(this.getExternalNodes().item(k));
               }
            }
            this.setExternalNodes(node_list);
         }
      }
      // Build simple content
      if ((base_type != null) && (base_type.getDatatype() != null))
      {
         this.simpleContent = base_type.getDatatype();
         switch (this.simpleContent.getVariety())
         {
            case XsdSimpleType.ATOMIC_VARIETY:
               this.simpleContent =
                  new XsdAtomicType(null, this.simpleContent.getTypeId(),
                        facets);
               break;
            case XsdSimpleType.LIST_VARIETY:
               this.simpleContent =
                  new XsdListType(null, ((XsdListType) this.simpleContent)
                        .getItemType(), facets);
               break;
         }
      }
      // Build complex content
      if ((base_type != null) && base_type.isComplex())
      {
         this.complexContent = ((XsdComplexType) base_type).getComplexContent();
         final XsdAttributeGroup base_attribs =
            ((XsdComplexType) base_type).getAttributeGroup();
         // TBC : derivation by restriction
         if (base_attribs != null)
         {
            attrib_group = base_attribs.deriveByExtension(attrib_group);
         }
      }
      this.attribute = attrib_group;
      this.mapAttribute(attrib_group);
   } // XsdComplexType

   /**
    * Performs the name to type mapping from a model group.
    * 
    * @param model_group The model group
    */
   private void mapType(final XsdModelGroup model_group)
   {
      final XsdParticle[] particles = model_group.getContent();
      if (particles != null)
      {
         for (int i = 0; i < particles.length; i++)
         {
            switch (particles[i].getTerm())
            {
               case XsdParticle.ELEMENT_TERM:
                  final XsdElement elt = (XsdElement) particles[i];
                  this.typeMap.put(elt.getName(), elt.getType());
                  break;
               case XsdParticle.MODEL_GROUP_TERM:
                  this.mapType((XsdModelGroup) particles[i]);
                  break;
            }
         }
      }
   } // mapType

   /**
    * Performs the name to attribute mapping from an attribute group.
    * 
    * @param attrib_group The attribute group
    */
   private void mapAttribute(final XsdAttributeGroup attrib_group)
   {
      final XsdAttribute[] attributes = attrib_group.getContent();
      if (attributes != null)
      {
         for (int i = 0; i < attributes.length; i++)
         {
            final XsdAttribute attrib = attributes[i];
            if ((attrib != null) && (attrib.getName() != null))
            {
               this.attributeMap.put(new XsdName(attrib.getName(), attrib
                     .getTargetNamespace()), attrib);
            }
         }
      }
      // Add xsi attributes.
      // nil
      final XsdAttribute xsi_nil =
         new XsdAttribute("nil", new XsdAtomicType(Value.BOOLEAN_ID), null,
               XsdAttribute.OPTIONAL_USE);
      xsi_nil.setTargetNamespace(Namespace.XML_SCHEMA_INSTANCE);
      this.attributeMap.put(new XsdName(xsi_nil.getName(), xsi_nil
            .getTargetNamespace()), xsi_nil);

      // type
      final XsdAttribute xsi_type =
         new XsdAttribute("type", new XsdAtomicType(Value.STRING_ID), null,
               XsdAttribute.OPTIONAL_USE);
      xsi_type.setTargetNamespace(Namespace.XML_SCHEMA_INSTANCE);
      this.attributeMap.put(new XsdName(xsi_type.getName(), xsi_type
            .getTargetNamespace()), xsi_type);
      // schemaLocation
      final XsdAttribute xsi_schemaLocation =
         new XsdAttribute("schemaLocation", new XsdListType(null,
               new XsdAtomicType(XsdAtomicType.ANY_URI_TAG, Value.STRING_ID,
                     null), null), null, XsdAttribute.OPTIONAL_USE);
      xsi_schemaLocation.setTargetNamespace(Namespace.XML_SCHEMA_INSTANCE);
      this.attributeMap.put(new XsdName(xsi_schemaLocation.getName(),
            xsi_schemaLocation.getTargetNamespace()), xsi_schemaLocation);

      // noNamespaceSchemaLocation
      final XsdAttribute xsi_noNamespace =
         new XsdAttribute("noNamespaceSchemaLocation", new XsdAtomicType(
               XsdAtomicType.ANY_URI_TAG, Value.STRING_ID, null), null,
               XsdAttribute.OPTIONAL_USE);
      xsi_noNamespace.setTargetNamespace(Namespace.XML_SCHEMA_INSTANCE);
      this.attributeMap.put(new XsdName(xsi_noNamespace.getName(),
            xsi_noNamespace.getTargetNamespace()), xsi_noNamespace);
   } // mapAttribute

   /**
    * Returns the type of an element.
    * 
    * @param element_name The element name
    * @return The type of the element name
    */
   XsdType getElementType(final String element_name)
   {
      return (XsdType) this.typeMap.get(element_name);
   } // getElementType

   /**
    * Returns an attribute from its name.
    * 
    * @param attrib_name The attribute name
    * @return The Attribute
    */
   XsdAttribute getAttribute(final String attrib_name)
   {
      return (XsdAttribute) this.attributeMap.get(attrib_name);
   } // getAttribute

   /**
    * Returns an attribute from its name.
    * 
    * @param attrib_name The attribute name
    * @return The Attribute
    */
   XsdAttribute getAttribute(final XsdName attrib_name)
   {
      return (XsdAttribute) this.attributeMap.get(attrib_name);
   } // getAttribute

   /**
    * Returns the attribute group of this type.
    * 
    * @return The attribute group
    */
   public XsdAttributeGroup getAttributeGroup()
   {
      return this.attribute;
   } // getAttributeGroup

   /**
    * Set the attributes of this complex type.
    * 
    * @param attrib_group The attribute group
    */
   void setAttributeGroup(XsdAttributeGroup attrib_group)
   {
      this.attributeMap = new HashMap();
      if (attrib_group == null)
      {
         attrib_group = new XsdAttributeGroup(null, new XsdAttribute[] {});
      }
      this.attribute = attrib_group;
      this.mapAttribute(attrib_group);
   } // getAttribute

   /**
    * Returns the complex content of this type.
    * 
    * @return The model group
    */
   public XsdModelGroup getComplexContent()
   {
      return this.complexContent;
   } // getComplexContent

   /**
    * Set the simple content of this type.
    * 
    * @param simple_content the simple content of this type
    */
   void setSimpleContent(final XsdSimpleType simple_content)
   {
      this.simpleContent = simple_content;
   } // setSimpleContent

   /**
    * Set the complex content of this type.
    * 
    * @param complex_content The model group
    */
   void setComplexContent(XsdModelGroup complex_content)
   {
      if (complex_content == null)
      {
         complex_content =
            new XsdModelGroup(0, 0, new XsdElement[] {},
                  XsdModelGroup.SEQUENCE_MODEL);
      }
      this.complexContent = complex_content;
      this.mapType(complex_content);
   } // getComplexContent

   // --------------------------------------------------------
   // XsdComponent class overloading
   // -------------------------------------------------------
   /**
    * Format this component into a string.
    * 
    * @return The node
    */
   DrbNode toNode()
   {
      final DrbNode type_node = new DrbDefaultMutableNode(TAG);
      type_node.setNamespaceURI(Namespace.XML_SCHEMA_NAMESPACE);
      final DrbDefaultAttributeList attributes = new DrbDefaultAttributeList();

      // Case of global type
      // We must specify the type name
      if ((this.schema != null) && (this.getName() != null))
      {
         attributes.add(new DrbDefaultAttribute(NAME_TAG,
               new fr.gael.drb.value.String(this.getName()), type_node));
      }
      type_node.setAttributes(attributes);

      DrbNode content_node = type_node;

      if ((this.getBase() != null)
            && !"anyType".equals(this.getBase().getName()))
      {
         content_node = new DrbDefaultMutableNode(COMPLEX_CONTENT_TAG);
         DrbNode derivation_node = null;

         if (this.derivationMethod == EXTENSION_METHOD)
         {
            derivation_node = new DrbDefaultMutableNode(EXTENSION_TAG);

         }
         else
         {
            derivation_node = new DrbDefaultMutableNode(RESTRICTION_TAG);
         }

         final DrbDefaultAttributeList derivation_attributes =
            new DrbDefaultAttributeList();

         final String base_local_name = this.getBase().getName();
         String base_name = base_local_name;
         final XmlSchema base_schema = this.getBase().schema;

         if ((base_schema != null) && (base_schema.namespaces != null))
         {
            final String prefix =
               this.schema.namespaces.resolvePrefix(this.getBase()
                     .getTargetNamespace());
            if (prefix != null)
            {
               base_name = prefix + ":" + base_local_name;
            }
         }

         derivation_attributes.add(new DrbDefaultAttribute(DERIVATION_BASE_TAG,
               new fr.gael.drb.value.String(base_name), type_node));
         derivation_node.setAttributes(derivation_attributes);
      }

      if ((this.complexContent != null)
            && (this.complexContent.getLength() > 0))
      {
         final DrbNode complex_node = this.complexContent.toNode();
         if (complex_node != null)
         {
            content_node.appendChild(complex_node);
         }
      }
      /*
       * if (getExternalNodes() != null) { for (int i=0; i<getExternalNodes().getLength();
       * i++) type_node.appendChild(getExternalNodes().item(i)); }
       */

      return type_node;
   } // toNode

   // ----------------------------------------------------
   // XsdType class overloading
   // ----------------------------------------------------
   /**
    * Check if this type is complex.
    * 
    * @return true
    */
   public final boolean isComplex()
   {
      return true;
   } // isComplex

   /**
    * Returns the simple content of this type.
    * 
    * @return The simple type
    */
   public final XsdSimpleType getDatatype()
   {
      return this.simpleContent;
   } // getDatatype

   /**
    * Returns the structure of this type.
    * 
    * @return The complex type
    */
   public final XsdComplexType getStructure()
   {
      return this;
   } // getStructure

   // -------------------------------------------------------------
   // ValueValidator interface implementation
   // -------------------------------------------------------------
   /**
    * Validates the present value.
    * 
    * @param value The value
    * @return true if the value is valid , else false
    */
   public boolean isValid(final Value value)
   {
      if (this.getDatatype() != null)
      {
         return this.getDatatype().isValid(value);
      }
      return (value == null);
   } // isValid

   // --------------------------------------------------------------
   // NodeValidator interface implementation
   // --------------------------------------------------------------
   /**
    * Validates this node.
    * 
    * @param node The node
    * @return XsdInvalid
    */
   public XsdInvalid isValid(final DrbNode node)
   {
      final XsdInvalidComplexType invalid =
         new XsdInvalidComplexType(node, this);
      // Node must not be null
      if (node == null)
      {
         return invalid;
      }
      // ------------------------------------------------
      // Check value
      // ------------------------------------------------
      if (this.getDatatype() != null)
      {
         final XsdInvalid invalid_data = this.getDatatype().isValid(node);
         invalid.setSimpleContent(invalid_data);
         if (invalid_data != null)
         {
            return invalid_data;
         }
      }
      else
      {
         Value value = null;
         if ((node.getValueType() != Value.NULL_ID)
               && ((value = node.getValue()) != null))
         {
            invalid
                  .setSimpleContent(new XsdInvalidSimpleType(node, null, value));
            return invalid;
         }
      }
      // ---------------------------------------------------
      // Check attributes
      // ---------------------------------------------------
      final DrbAttributeList attrib_list = node.getAttributes();
      XsdAttribute attrib_decl = null;
      final HashMap attrib_map = new HashMap();
      if (attrib_list != null)
      {
         int i;
         XsdInvalid invalid_attrib_value = null;
         /* check all attributes of the node */
         for (i = 0; i < attrib_list.getLength(); i++)
         {
            final DrbAttribute node_attrib = attrib_list.item(i);
            attrib_decl = null;
            if ((node_attrib == null) || (node_attrib.getName() == null))
            {
               break;
            }
            String attrib_uri = node_attrib.getNamespaceURI();
            if (attrib_uri == null)
            {
               attrib_uri = node.getNamespaceURI();
            }
            attrib_decl =
               this
                     .getAttribute(new XsdName(node_attrib.getName(),
                           attrib_uri));
            if (attrib_decl == null)
            {
               // Do not check SDF attributes
               if (fr.gael.drb.impl.sds.SdfFactory.SDF_2005_04_NAMESPACE
                     .equals(attrib_uri)
                     || fr.gael.drb.impl.sds.SdfFactory.SDF_2004_12_NAMESPACE
                           .equals(attrib_uri)
                     || fr.gael.drb.impl.sds.SdfFactory.SDF_2002_02_NAMESPACE
                           .equals(attrib_uri))
               {
                  continue;
               }
               else
               {
                  break;
               }
            }
            // Check for prohibited
            if (attrib_decl.getUse() == XsdAttribute.PROHIBITED_USE)
            {
               break;
            }
            // Check for invalid type
            final XsdSimpleType attrib_type = attrib_decl.getType();
            if (attrib_type != null)
            {
               final DrbNode attrib_node =
                  new DrbDefaultMutableNode(node_attrib.getName());
               attrib_node.setValue(node_attrib.getValue());
               invalid_attrib_value = attrib_type.isValid(attrib_node);
               if (invalid_attrib_value != null)
               {
                  break;
               }
            }
            attrib_map.put(node_attrib.getName(), node_attrib);
         }
         /* Case of unknown attribute */
         if (i < attrib_list.getLength())
         {
            final XsdInvalidAttributeGroup invalid_attrib =
               new XsdInvalidAttributeGroup(attrib_list, attrib_decl, i);
            invalid_attrib.setSimpleType(invalid_attrib_value);
            invalid.setAttributeGroup(invalid_attrib);
            return invalid;
         }
      }
      /* check that all required attributes are declared */
      attrib_decl = null;
      for (int k = 0; k < this.getAttributeGroup().getContent().length; k++)
      {
         attrib_decl = this.getAttributeGroup().getContent()[k];
         // This attribute is not declared
         if ((attrib_decl.getUse() == XsdAttribute.REQUIRED_USE)
               && (attrib_map.get(attrib_decl.getName()) == null))
         {
            break;
         }
         else
         {
            attrib_decl = null;
         }
      }
      /* Case of missing attribute */
      if (attrib_decl != null)
      {
         invalid
               .setAttributeGroup(new XsdInvalidAttributeGroup(attrib_list,
                     attrib_decl, (attrib_list == null) ? 0 : attrib_list
                           .getLength()));
         return invalid;
      }

      // ---------------------------------------------------------
      // Check children
      // --------------------------------------------------------
      final XsdModelGroup content = this.getComplexContent();
      if (content == null)
      {
         return (node.hasChild() ? invalid : null);
      }
      final XsdInvalid invalid_content = content.isValid(node.getChildren());
      if (invalid_content != null)
      {
         invalid.setComplexContent(invalid_content);
         return invalid;
      }
      return null;
   } // isValid

   // ===============================================
   // Unitary test part.
   // ===============================================
   /**
    * Makes this class runnable for testing.
    * 
    * @param args String[]
    */
   public static void main(final String[] args)
   {
      final XsdAtomicType float_type = new XsdAtomicType(Value.FLOAT_ID, null);
      final XsdListType list_type = new XsdListType(float_type, null);
      final XsdElement x_elt = new XsdElement(1, 1, "x", float_type);
      final XsdElement y_elt = new XsdElement(1, 1, "y", float_type);
      final XsdElement z_elt = new XsdElement(1, 1, "z", list_type);
      final XsdModelGroup group =
         new XsdModelGroup(1, 1, new XsdParticle[] { x_elt, y_elt, z_elt },
               XsdModelGroup.SEQUENCE_MODEL);
      logger.error("Derivation by extention");
      final XsdComplexType point_type =
         new XsdComplexType("point", group, null);
      System.out.println(point_type.getElementType("z").toNode());
   } // main

} // XsdComplexType
