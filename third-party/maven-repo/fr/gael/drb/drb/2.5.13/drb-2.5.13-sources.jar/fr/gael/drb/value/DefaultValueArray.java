/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

import java.util.ArrayList;

/**
 * Generic array value wrapper.
 */
public class DefaultValueArray extends AbstractValueArray
{
   // ==========================================================================
   // Attributes part.
   // ==========================================================================

   /**
    * PRIORITY
    */
   final static int PRIORITY = 0;

   /**
    * value
    */
   private ArrayList value = new ArrayList();

   // ==========================================================================
   // Methods part.
   // ==========================================================================
   /**
    * Build an BooleanArray value with the specified size.
    * 
    * @param size the size of the array.
    */
   public DefaultValueArray(final int size)
   {
      this.value = new ArrayList(size);
   }

   /**
    * Returns the string representation of this array
    * 
    * @return the sequence as a string
    */
   public java.lang.String toString()
   {
      java.lang.String str = "";
      for (int i = 0; i < this.getLength(); i++)
      {
         if (i != 0)
         {
            str += " ";
         }

         str += this.getElement(i);
      }
      return str;
   }

   // --------------------------------------------------------------------------
   // Value interface implementation
   // --------------------------------------------------------------------------

   /**
    * The type identifier of this BooleanArray value.
    * 
    * @return an identifier of the array type, namely ARRAY_ID
    */
   public final int getType()
   {
      return Value.ARRAY_ID;
   }

   /**
    * Returns the BooleanArray priority
    * 
    * @return the BooleanArray priority
    */
   public final int getPriority()
   {
      return PRIORITY;
   }

   /**
    * Convert the value into the specified type. The type must be ARRAY_ID or
    * STRING_ID otherwise a ClassCastException is thrown
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException the conversion is impossible
    */
   public final Value convertTo(final int type) throws ClassCastException
   {
      if (type == ARRAY_ID)
      {
         return this;
      }

      if (type == STRING_ID)
      {
         return new String(this.toString());
      }

      // Implicit conversion to singleton
      if (this.getLength() == 1)
      {
         return this.getElement(0).convertTo(type);
      }

      throw new ClassCastException();
   }

   /**
    * Assign a value. This value must be a NumericArray otherwise a
    * ClassCastException is thrown.
    * 
    * @param v the value to be assigned.
    * @throws ClassCastException the conversion is impossible
    */
   public final void assign(final Value v) throws ClassCastException
   {
      final ValueArray v_arr = (ValueArray) v;
      this.value = new ArrayList();
      for (int i = 0; i < v_arr.length(); i++)
      {
         this.value.set(i, v_arr.getElement(i));
      }
   }

   // --------------------------------------------------------------------------
   // ValueArray interface implementation
   // --------------------------------------------------------------------------

   /**
    * Returns the Array type
    * 
    * @return the array type as an int
    */
   public final int getArrayType()
   {
      return Value.UNKNOWN_ID;
   }

   /**
    * Returns the Element value at the specified index
    * 
    * @param index the index position
    * @return the value at this index
    */
   public final Value getElement(final int index)
   {
      return (Value) (this.value.get(index));
   }

   /**
    * Assign a value to an index
    * 
    * @param index position where to insert the value.
    * @param element value to assign as a double.
    */
   public final void assign(final int index, final Value element)
   {
      if (index < this.value.size()) // TBC
      {
         this.getElement(index).assign(element);
      }
      else
      {
         this.value.add(index, element);
      }
   } // assign

   /**
    * Returns the number of elements in this array.
    * 
    * @return the number of elements in this array.
    */
   public final int length()
   {
      return this.value.size();
   }

}
