/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.value.Comparison;
import fr.gael.drb.value.Value;

/**
 * Declaration of an XML-Schema maxInclusive Facet.
 */
public class XsdMaxInclusiveFacet extends XsdFacet
{

   /**
    * maxInclusive facet name.
    */
   final static String TAG = "maxInclusive";

   // =============================================================
   // Attributes part.
   // =============================================================
   /**
    * The maxInclusive value.
    */
   private Value value;

   /**
    * Build a maxInclusive facet.
    * 
    * @param value the value
    */
   XsdMaxInclusiveFacet(final Value value)
   {
      this.value = value;
   } // XsdMaxInclusiveFacet

   /**
    * Identifier of this facet.
    * 
    * @return Identifier of this facet.
    */
   public final int getId()
   {
      return MAX_INCLUSIVE_ID;
   } // getId

   /**
    * The maxInclusive value
    * 
    * @return the maxInclusive value
    */
   public final Value getValue()
   {
      return this.value;
   } // getValue

   /**
    * The name of this facet.
    * 
    * @return The name of this facet.
    */
   public final String getName()
   {
      return this.TAG;
   } // getName

   // --------------------------------------------------------
   // ValueValidator interface implementation
   // --------------------------------------------------------
   /**
    * Validates the present value.
    * 
    * @param v the value
    * @return true if this value satifies the type definition, else false
    */
   public boolean isValid(Value v)
   {
      if (v == null)
      {
         return false;
      }
      try
      {
         v = v.convertTo(this.value.getType());
         return ((Comparison) this.value).compareTo(v) >= 0;
      }
      catch (final ClassCastException e)
      {
         return false;
      }

   }

} // XsdMaxInclusiveFacet class
