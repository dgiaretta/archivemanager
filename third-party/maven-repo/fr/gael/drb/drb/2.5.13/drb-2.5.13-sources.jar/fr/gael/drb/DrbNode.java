/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import fr.gael.drb.value.Value;

/**
 * Node interface. This interface represents a single node of a tree of data.
 * Any node can have no, one or several children.This interface provides the
 * primarily operations to browse an entire data structure. All implementations
 * of the "Data Request Broker" shall be able to produce such nodes. Nodes are
 * considered mutable when they provide an interface that enables to change
 * their content or structure (i.e. attribute, name, children, etc.). All the
 * following operations are supposed to fire the most accurate events according
 * to their business. DrbNode interface has been designed on the basis of the
 * MutableTreeNode provided by the Java API and by the DOM Event specifications
 * of the W3C.
 * <p>
 * <b>Important note: </b> If the node has a physical representation (e.g. a
 * file, an XML document) the any call of the operations defined in
 * DrbMutableNode interface changes this physical representation. For instance
 * renaming a node wrapping a file will effectively rename the file in the file
 * system. The operations does not already support transactions supposed to
 * store the changes until a commit. The changes may therefore take a variable
 * amount of time according to the underlying implementation. For instance the
 * insertion of a node as first child may require to copy a huge file even if
 * the node value has small footprint in the final file.
 */
public interface DrbNode extends DrbSimpleNode
{

   /**
    * Changes the value of the node. This operation sets a new value of the
    * current node.The value type of the node shall be compatible with the node
    * implementation. If the type does not match exactly it is casted to a
    * compatible one based on the the fr.gael.drb.value capabilities. A
    * reference to the effectively assigned value is returned by the operation
    * so it is possible to check if a cast has been performed and therefore
    * assess the accuracy of the assignment. If the cast is not possible the
    * operation raises an UnsupportedOperationException. If the assignment is
    * possible and the node implementation has a physical representation the
    * value is updated in the physical source in order to persist among
    * sessions. It therefore possible that this operation consumes an variable
    * time.
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept value changes. For instance it may not be possible to change the
    * value of a file directory that has no immediate signification.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node changed event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node. The called operation is
    * the nodesChanged() of the listeners.
    * </p>
    * 
    * @param value The new value of the node. This value shall not be null.
    * @return The effectively assigned value.The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be
    *            overridden by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested assignment for
    *            any reason.
    */
   public Value setValue(Value value) throws NullPointerException,
      ClassCastException, UnsupportedOperationException;

   /**
    * Set the attribute list of a node. If some attributes are already attached
    * to the current node they are first removed and then replaced by the new
    * ones. However the operation checks the compatibility of the passed
    * attribute according to the current implementation. The operation does
    * nothing if the compatibility check fails.
    * <p>
    * <b>Warning:</b> The input attributes may be duplicated or re-instanciated
    * according to the targeted implementation. References to the effectively
    * inserted attributes can be retrieved from the getAttributes() operation of
    * the DrbNode. It is highly recommended to discard the references to the
    * input attributes if not mandatory.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept attribute changes. For instance it may not be possible to change
    * the size attribute of a file through this operation with would meant a
    * effective file resize that is not really relevant without additional data.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node.The called operation is the
    * nodesChanged() of the listeners.
    * </p>
    * 
    * @param attributes A reference to the new attribute list.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the attribute list is null. This exception may be
    *            overridden by an UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested attribute changes
    *            for any reason.
    */
   public void setAttributes(DrbAttributeList attributes)
      throws NullPointerException, UnsupportedOperationException;

   /**
    * Sets a namespace resource identifier. The new namespace identifier shall
    * not be null.
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept namespace changes. For instance it may not be possible to change
    * the namespace of a file that is basically fixed.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node.The called operation is the
    * nodesChanged() of the listeners.
    * </p>
    * 
    * @param namespace_uri A reference to the new namespace identifier.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the new namespace identifier is null.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested namespace change
    *            for any reason (e.g. by definition or in the specific case).
    */
   public void setNamespaceURI(String namespace_uri)
      throws NullPointerException, UnsupportedOperationException;

   /**
    * Inserts a child at a given position. The passed node is inserted in the
    * list of children at the given position The position is the expected index
    * of the node after insertion. All the previous children from the aimed
    * position to the end of the list are shift to the end of the new children
    * list (i.e. their indices are shifted up of 1). If the given index is out
    * of the children bounds and therefore less than zero and greater or equal
    * to the current number of children,the operation raises an exception. An
    * index equal to the current number of children is allowed and the operation
    * is therefore equivalent to appendChild().
    * <p>
    * If the node has been inserted within the children list, the next sibling
    * indices are increased of one. In addition the associations between the
    * inserted node and it previous and next siblings are updated (if any).
    * </p>
    * <p>
    * <b>Warning:</b> The inserted node may be duplicated or re-instanciated
    * according to the targeted implementation. A reference to the effectively
    * inserted node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned node.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to insert a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Case of unordered or specifically ordered implementations:</b> If the
    * implementation does not support ordered children or has specific ordering
    * rules, the node is inserted without taking into account the requested
    * index passed in parameter. For instance it may not be possible to impose
    * the file order in a directory: it generally depends on the lexicographical
    * order of the node names or their creation date.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the inserted node and the source is the current node. The called
    * operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param node A reference to the node to be inserted.
    * @param index The expected index of the node after the insertion.
    * @return A reference to the effectively inserted node. This reference may
    *         differ from the input one.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference. This exception may be overridden by an
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passe
    *            index is less than zero or if it is greater or equal to the
    *            number of children in the number of children prior the call
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested insertion for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbNode insertChild(DrbNode node, int index)
      throws NullPointerException, UnsupportedOperationException,
      IndexOutOfBoundsException;

   /**
    * Appends a child at the end of the children list. The passed node is
    * inserted in the list of children at the end of the current list.
    * <p>
    * <b>Warning:</b> The appended node may be duplicated or re-instanciated
    * according to the targeted implementation. A reference to the effectively
    * appended node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned node.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to append a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Case of unordered or specifically ordered implementations:</b> If the
    * implementation does not support ordered children or has specific ordering
    * rules, the node may not be appended but only inserted according to these
    * rules. For instance it may not be possible to impose the file order in a
    * directory:it generally depends on the lexicographical order of the node
    * names or their creation date.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the appended node and the source is the current node. The called
    * operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param node A reference to the node to be appended.
    * @return A reference to the effectively appended node. This reference may
    *         differ from the input one.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference.This exception may be overridden by an
    *            UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested append for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbNode appendChild(DrbNode node) throws NullPointerException,
      UnsupportedOperationException;

   /**
    * Replaces a child of the current node. This operation replaces a child in
    * the current children list by a new one The operation aborts when the index
    * is out of bound (index < 0 || index > size). In case of error, the
    * implementation has to restore the initial situation. It is therefore
    * recommended for any implementation to check the consistency prior to
    * perform the replacement.
    * <p>
    * <b>Warning:</b> The replacing node may be duplicated or re-instanciated
    * according to the targeted implementation.A reference to the effectively
    * replacing node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned one.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to insert a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the new node and the source is the current node. The called operation
    * is the structureChanged() of the listeners.
    * </p>
    * 
    * @param index Index of the node to be replaced. This index starts at 0 and
    *           shall be less than the number of children.
    * @param new_node A reference to the node that replaces the old one.
    * @return A reference to the effectively replacing node.This reference may
    *         differ from the new_node parameter.
    * @throws NullPointerException This exception is raised when the reference
    *            to the new node is null. This exception may be overridden by a
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested replace for any
    *            reason. In addition if the old_node is not retrieved in the
    *            current children list, this exception is also raised.
    */
   public DrbNode replaceChild(int index, DrbNode new_node)
      throws NullPointerException, IndexOutOfBoundsException,
      UnsupportedOperationException;

   /**
    * Removes an existing child. The child at the given index is removed from
    * the children list of the current node. The child is not modified by this
    * operation. At the child point of view it keeps the same parent or any
    * common association depending on the implementation. However at the parent
    * (i.e. the current node) point of view the removed node is completely
    * dismissed and will never be re-instaciated from constructor operations
    * (e.g. getFirstChild(), etc. ). The index of the child to be removed has to
    * correspond to an existing children index. If the index is less than zero
    * or greater or equal to the current number of children, an exception is
    * thrown.
    * <p>
    * This operation takes into account the removal by updating the sibling
    * associations of the children nodes prior and next to the removed one. The
    * indices of the nodes next to the removed one are decreased of one. Their
    * parents as well as their contents are left unchanged.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the removed node and the source is the current node.The called
    * operation is the nodesRemoved() of the listeners.
    * </p>
    * 
    * @param index Index of the child to be removed.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested removal for any
    *            reason.
    */
   public void removeChild(int index) throws IndexOutOfBoundsException,
      UnsupportedOperationException;

}// DrbNode
