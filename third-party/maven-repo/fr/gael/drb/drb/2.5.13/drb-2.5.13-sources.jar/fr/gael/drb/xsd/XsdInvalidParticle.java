/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbNodeList;

/**
 * Output of the XML-Schema particle validator.
 */
class XsdInvalidParticle implements XsdInvalid
{

   /**
    * The particle.
    */
   XsdParticle particle;

   /**
    * The validated node list.
    */
   DrbNodeList nodeList;

   /**
    * Index of the first child in the model group
    */
   int startIndex;

   /**
    * Index of the last child in the model group
    */
   int stopIndex;

   /**
    * The invalid status.
    */
   int status = XsdInvalid.NONE;

   /**
    * Build an XsdInvalidParticle
    * 
    * @param node_list the node list
    * @param particle the particle
    * @param start_index the beginning of the node list
    * @param stop_index the end of the node list
    */
   XsdInvalidParticle(final DrbNodeList node_list, final XsdParticle particle,
         final int start_index, final int stop_index)
   {
      this.nodeList = node_list;
      this.particle = particle;
      this.startIndex = start_index;
      this.stopIndex = stop_index;
   } // XsdInvalidParticle

   /**
    * Set the index of the first child int the model group.
    * 
    * @param start_index the index of the first child int the model group
    */
   void setStartIndex(final int start_index)
   {
      this.startIndex = start_index;
   } // setStartIndex

   /**
    * Set the index (+1) of the last child in the model group.
    * 
    * @param stop_index the index (+1) of the last child in the model group.
    */
   void setStopIndex(final int stop_index)
   {
      this.stopIndex = stop_index;
   } // setStopIndex

   /**
    * Returns a message describing the validation result.
    * 
    * @return a message describing the validation result.
    */
   public String getMessage()
   {
      String msg = "Invalid particle at index " + this.stopIndex + " : \" ";
      for (int i = this.stopIndex - 2; i < this.stopIndex + 2; i++)
      {
         if (i == this.stopIndex)
         {
            msg = msg + "^";
         }
         if ((this.nodeList != null) && (i >= 0)
               && (i < this.nodeList.getLength()))
         {
            msg = msg + this.nodeList.item(i).getName() + " ";
         }
      }
      msg = msg + "\"";
      return msg;
   } // getMessage

   /**
    * Make this result printable.
    * 
    * @return this result printable.
    */
   public String toString()
   {
      return this.getMessage();
   }

   /**
    * Returns a status describing the validation result.
    * 
    * @return the status
    */
   public int getStatus()
   {
      return this.status;
   } // getStatus

   /**
    * Returns the component.
    * 
    * @return the component.
    */
   public XsdComponent getComponent()
   {
      return this.particle;
   } // getComponent

   /**
    * Returns the children message.
    * 
    * @return the children message.
    */
   public XsdInvalid[] getChildren()
   {
      return null;
   } // getChildren

} // XsdInvalidParticle
