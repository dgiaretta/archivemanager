/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import org.apache.log4j.Logger;

/**
 * This class provides a skeletal implementation of the DrbNodeList interface,
 * to minimize the effort required to implement this interface.
 */
public abstract class DrbAbstractNodeList extends DrbAbstractSequence implements
      DrbNodeList
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(DrbAbstractNodeList.class);

   /**
    * Returns a specific item of the list.
    * 
    * @param index The position of the item starting from 0 and not greater or
    *           equal to the item count in the list.
    * @return A reference to specified item or null if no such item.
    */
   public DrbItem getItem(final int index)
   {
      return this.item(index);
   }

   /**
    * Returns an occurence of item matching a specific name. The occurence
    * number starts from 1. The name is a local name without any prefix.A null
    * reference is returned if the provided occurrence is outside the list
    * bounds.
    * 
    * @param name The name to match.
    * @param occurence The occurence number of the desired child.
    * @return A reference to specified item or null if no such node.
    */
   public DrbNode getNamedItem(final String name, final int occurence)
   {
      /**
       * Checks parameters.
       */
      if ((name == null) || (occurence <= 0))
      {
         this.logger.error("DrbAbstractNodeList.item(): "
               + "Invalid parameter (name=\"" + name + "\", occurence="
               + occurence);
         return null;
      }

      /**
       * Search the matching node.
       */
      int current_occurence = 0;
      String current_name = null;

      for (int inode = 0; inode < this.getLength(); inode++)
      {
         final DrbNode currentNode = this.item(inode);
         if (currentNode == null)
         {
            continue;
         }
         current_name = currentNode.getName();

         if ((current_name != null) && (current_name.equals(name)))
         {
            current_occurence = current_occurence + 1;
         }

         if (current_occurence == occurence)
         {
            return currentNode;
         }
      }
      return null;
   }
}// DrbAbstractNodeList
