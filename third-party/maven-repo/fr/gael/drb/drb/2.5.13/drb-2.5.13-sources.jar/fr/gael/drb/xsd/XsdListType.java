/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultMutableNode;
import fr.gael.drb.DrbNode;
import fr.gael.drb.value.Value;
import fr.gael.drb.value.ValueArray;

/**
 * Declaration of an XML-Schema list type.
 */
public class XsdListType extends XsdSimpleType
{
   // ============================================
   // Attributes part.
   // ============================================
   /**
    * Item type of this list.
    */
   private XsdSimpleType itemType;

   // ================================================
   // Static part.
   // ================================================
   /**
    * list tag name.
    */
   final static String TAG = "list";

   /**
    * itemType tag.
    */
   final static String ITEM_TYPE_TAG = "itemType";

   /**
    * List derivation method.
    */
   public final static int LIST_METHOD = 3;

   // ===========================================
   // Methods part.
   // ===========================================
   /**
    * Build an XsdListType.
    * 
    * @param name the name
    * @param base_type the base type
    * @param facets the facets
    */
   public XsdListType(final String name, final XsdSimpleType base_type,
         XsdFacet[] facets)
   {
      super(name, base_type);
      if (facets == null)
      {
         facets = new XsdFacet[] {};
      }
      this.facets = facets;

      // Case of derivation by restriction
      if ((base_type == null)
            || (base_type.getVariety() == XsdSimpleType.LIST_VARIETY))
      {
         this.itemType = ((XsdListType) base_type).getItemType();
         this.derivationMethod = RESTRICTION_METHOD;
      }
      else
      {
         this.itemType = base_type;
         this.derivationMethod = this.LIST_METHOD;
      }
      this.finals = XsdSimpleType.LIST_FINAL;
   } // XsdListType

   /**
    * Build an XsdListType.
    * 
    * @param item_type the item type
    * @param facets the facets
    */
   public XsdListType(final XsdSimpleType item_type, final XsdFacet[] facets)
   {
      this(null, item_type, facets);
   } // XsdListType

   // --------------------------------------------------------
   // XsdComponent class overloading
   // -------------------------------------------------------
   /**
    * Format this component into a string.
    * 
    * @return The node
    */
   DrbNode toNode()
   {
      // derivation by restriction
      if (this.getBase() != this.getItemType())
      {
         return super.toNode();
      }

      // derivation by list
      final DrbNode typeNode = new DrbDefaultMutableNode(XsdSimpleType.TAG);
      typeNode.setNamespaceURI(Namespace.XML_SCHEMA_NAMESPACE);
      if (this.getName() != null)
      {
         final DrbDefaultAttributeList attributes =
            new DrbDefaultAttributeList();
         attributes.add(new DrbDefaultAttribute(NAME_TAG,
               new fr.gael.drb.value.String(this.getName()), typeNode));
         typeNode.setAttributes(attributes);
      }

      if (this.getItemType() != null)
      {
         final DrbNode listNode = new DrbDefaultMutableNode(this.TAG);
         listNode.setNamespaceURI(Namespace.XML_SCHEMA_NAMESPACE);
         final DrbDefaultAttributeList attributes =
            new DrbDefaultAttributeList();

         final XmlSchema itemSchema = this.itemType.schema;
         if ((itemSchema != null) && (this.itemType.getName() != null))
         {
            String item_name = this.itemType.getName();
            if (itemSchema != null)
            {
               String prefix =
                  itemSchema.namespaces.resolvePrefix(this.itemType
                        .getTargetNamespace());

               if ((prefix == null)
                     && (Namespace.XML_SCHEMA_NAMESPACE.equals(this.itemType
                           .getTargetNamespace())))
               {
                  prefix = "xs";
               }

               if (prefix != null)
               {
                  item_name = prefix + ":" + this.itemType.getName();
               }
            }
            attributes.add(new DrbDefaultAttribute(this.ITEM_TYPE_TAG,
                  new fr.gael.drb.value.String(item_name), listNode));
            listNode.setAttributes(attributes);
         }
         else
         {
            final DrbNode itemNode = this.itemType.toNode();
            if (itemNode != null)
            {
               listNode.appendChild(itemNode);
            }
         }

         typeNode.appendChild(listNode);
         // facets
         for (int i = 0; i < this.getFacets().length; i++)
         {
            final DrbNode facetNode = this.getFacets()[i].toNode();
            if (facetNode != null)
            {
               listNode.appendChild(facetNode);
            }
         }
      }

      return typeNode;
   } // toNode

   /**
    * Returns the variety of this simple type.
    * 
    * @return the variety of this simple type.
    */
   public final int getVariety()
   {
      return XsdSimpleType.LIST_VARIETY;
   } // getVariety

   /**
    * Returns the item type of this list.
    * 
    * @return the item type of this list.
    */
   public final XsdSimpleType getItemType()
   {
      return this.itemType;
   } // getItemType

   /**
    * Returns the identifier of this simple type.
    * 
    * @return the identifier of this simple type.
    */
   public final int getTypeId()
   {
      return Value.ARRAY_ID;
   } // getTypeId

   /**
    * Returns the Value identifier of the items.
    * 
    * @return the Value identifier of the items.
    */
   public int getItemTypeId()
   {
      if (this.itemType != null)
      {
         return this.itemType.getTypeId();
      }
      return Value.UNKNOWN_ID;
   } // getItemTypeId

   /**
    * Create a value from a string.
    * 
    * @param text the string representation of the value.
    * @return the text converted to this value type.
    */
   public Value getValue(final String text)
   {
      return new fr.gael.drb.value.String(text).convertTo(Value.ARRAY_ID);
   }

   // ----------------------------------------------
   // XsdValueSpace interface implementation
   // ----------------------------------------------
   /**
    * A value space, is said to be ordered if there exists an order-relation
    * defined for that value space.
    * 
    * @return true if this value space is ordered and false otherwise.
    */
   public boolean isOrdered()
   {
      return false;
   }

   /**
    * Returns the order-relation of this value space. An order relation on a
    * value space is a mathematical relation that imposes a total order or a
    * partial order on the members of the value space
    * 
    * @see PARTIAL
    * @see TOTAL
    * @return the order-relation defined on that value space
    */
   public int getOrderRelation()
   {
      return XsdValueSpace.UNDEFINED;
   }

   /**
    * A datatype is bounded if its value space has either an inclusive upper
    * bound or an exclusive upper bound and either an inclusive lower bound and
    * an exclusive lower bound.
    * 
    * @return true if this value space is bounded and false otherwise.
    */
   public boolean isBounded()
   {
      // Check facet
      return false;
   }

   /**
    * Returns the inclusive lower bound.
    * 
    * @return The inclusive lower bound or null if not defined.
    */
   public Value getInclusiveLowerBound()
   {
      return null;
   }

   /**
    * Returns the inclusive upper bound.
    * 
    * @return The inclusive upper bound or null if not defined.
    */
   public Value getInclusiveUpperBound()
   {
      return null;
   }

   /**
    * Returns the exclusive lower bound.
    * 
    * @return The exclusive lower bound or null if not defined.
    */
   public Value getExclusiveLowerBound()
   {
      return null;
   }

   /**
    * Returns the exclusive upper bound.
    * 
    * @return The exclusive upper bound or null if not defined.
    */
   public Value getExclusiveUpperBound()
   {
      return null;
   }

   /**
    * Returns the cardinality of this value space. Every value space has
    * associated with it the concept of cardinality. Some value spaces are
    * finite, some are countably infinite while still others could conceivably
    * be uncountably infinite (although no value space defined by the XML-Schema
    * specification is uncountable infinite). A datatype is said to have the
    * cardinality of its value space.
    * 
    * @return The cardinality of this value space.
    */
   public int getCardinality()
   {
      // TBC
      return XsdValueSpace.UNCOUNTABLY_INFINITE;
   }

   /**
    * A datatype is said to be numeric if its values are conceptually quantities
    * (in some mathematical number system).
    * 
    * @return true if the datatype is numeric and false otherwise
    */
   public boolean isNumeric()
   {
      return false;
   }

   /**
    * Validates the type of the present value.
    * 
    * @param value the value
    * @return true if this value satifies the type definition, else false
    */
   protected boolean isValidType(final Value value)
   {
      if (value == null)
      {
         return false;
      }
      try
      {
         final ValueArray array = (ValueArray) value.convertTo(Value.ARRAY_ID);
         if ((array.getArrayType() == Value.UNKNOWN_ID)
               || (array.getArrayType() == Value.NULL_ID))
         {
            for (int i = 0; i < array.length(); i++)
            {
               if (!this.getItemType().isValidType(array.getElement(i)))
               {
                  return false;
               }
            }
         }
         else
         // Check the first element
         if (array.length() > 0)
         {
            return this.getItemType().isValidType(array.getElement(0));
         }
      }
      catch (final ClassCastException e)
      {
         return false;
      }
      return true;
   }

   /**
    * Validates the present value.
    * 
    * @param value the value
    * @return an error report or null.
    */
   public XsdInvalid validate(final Value value)
   {
      XsdInvalid invalid = super.validate(value);
      if (invalid == null)
      {
         final ValueArray array = (ValueArray) value.convertTo(Value.ARRAY_ID);
         for (int i = 0; i < array.length(); i++)
         {
            invalid = this.getItemType().validate(array.getElement(i));
            if (invalid != null)
            {
               break;
            }
         }
      }
      return invalid;
   }

   // ===========================================
   // Unitary test part.
   // ===========================================
   /**
    * Makes this class runnable for testing.
    * 
    * @param args strimg[]
    */
   public static void main(final String[] args)
   {
      System.out.println("Test 1 : <xsd:simpleType name='listOfFloat'>");
      System.out.println("           <xsd:list>");
      System.out.println("             <xsd:simpleType>");
      System.out.println("               <xsd:restriction base='xsd:float'>");
      System.out.println("                 <xsd:minInclusive value='10'/>");
      System.out.println("                 <xsd:maxInclusive value='40'/>");
      System.out.println("               </xsd:restriction>");
      System.out.println("             <xsd:simpleType>");
      System.out.println("           </xsd:list>");
      System.out.println("         </xsd:simpleType>");
      final XsdFacet[] facets =
         new XsdFacet[] {
               new XsdMinInclusiveFacet(new fr.gael.drb.value.Float(10.0f)),
               new XsdMaxInclusiveFacet(new fr.gael.drb.value.Float(40.f)) };
      final XsdAtomicType atomic = new XsdAtomicType(Value.FLOAT_ID, facets);
      final XsdListType list = new XsdListType("listOfFloat", atomic, null);
      final Value floatList =
         new fr.gael.drb.value.FloatArray(new float[] { 10.0f, 20.0f, 30.0f });
      final Value floatList2 =
         new fr.gael.drb.value.FloatArray(new float[] { 10.0f, 50.0f, 30.0f });
      final Value stringList1 =
         new fr.gael.drb.value.String("10.0 20.0 30.0")
               .convertTo(Value.ARRAY_ID);

      final Value stringList2 =
         new fr.gael.drb.value.String("10.0 20.0 300.0")
               .convertTo(Value.ARRAY_ID);

      final Value byteList =
         new fr.gael.drb.value.ByteArray(new byte[] { 10, 20, 30 });
      final Value booleanValue = new fr.gael.drb.value.Boolean(true);

      System.out.println("Checking floatList (" + floatList + ") -> "
            + list.validate(floatList));
      System.out.println("Checking floatList (" + floatList2 + ") -> "
            + list.validate(floatList2));
      System.out.println("Checking stringList1 (" + stringList1 + ") -> "
            + list.validate(stringList1));
      System.out.println("Checking stringList2 (" + stringList2 + ") -> "
            + list.validate(stringList2));
      System.out.println("Checking byteList (" + byteList + ") -> "
            + list.validate(byteList));
      System.out.println("Checking booleanValue (" + booleanValue + ") -> "
            + list.validate(booleanValue));
   }

} // XsdListType
