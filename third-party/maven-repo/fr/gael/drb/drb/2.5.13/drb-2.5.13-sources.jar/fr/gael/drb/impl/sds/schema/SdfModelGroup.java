/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds.schema;

import fr.gael.drb.xsd.XsdModelGroup;

/**
 * Declaration of an SDF model group.
 */
public class SdfModelGroup extends SdfParticle
{
   // ============================================
   // Attributes part.
   // ======================================
   /**
    * Content of this model group.
    */
   private SdfParticle[] content;

   // =============================================
   // Methods part.
   // =============================================
   /**
    * Build a model group
    * 
    * @param model_group the model group declaration
    */
   protected SdfModelGroup(final XsdModelGroup model_group)
   {
      super(model_group);
   }

   /**
    * Returns a particle of this model group.
    * 
    * @param index index
    * @return SdfParticle
    */
   public final SdfParticle getParticle(final int index)
   {
      if ((index < 0) || (index >= this.content.length))
      {
         return null;
      }
      else
      {
         return this.content[index];
      }
   } // getParticle

   /**
    * Returns the length of this model group.
    * 
    * @return int
    */
   public final int getParticuleCount()
   {
      return this.content.length;
   } // getLength

} // SdfModelGroup
