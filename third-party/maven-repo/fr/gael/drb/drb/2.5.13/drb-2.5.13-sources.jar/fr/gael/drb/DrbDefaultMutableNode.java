/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import org.apache.log4j.Logger;

import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.value.Value;
import fr.gael.drb.xsd.Namespace;

/**
 * Simple mutable node implementation. This class is a simple means to build a
 * DrbNode. It extends the DrbMutableNode interface instead of the DrbNode
 * because it natively requires to be modifiable. This also enables to reduce
 * the signature of the constructors are delay the settings to further calls.
 * This class accepts attributes as well as value and namespace identifier. The
 * class is also a node change producer so its possible to monitor the changed
 * performed on each instance.
 * <p>
 * <b>Important note:</b> The DrbDefaultMutableNode has no physical
 * representation. Its children and attributes are therefore not stored in a
 * physical media that may imply an important memory footprint.
 * </p>
 */
public class DrbDefaultMutableNode extends DrbNodeImpl
{
   /**
    * Node reference. This reference may be null.
    */
   protected DrbNode referenceNode;

   /**
    * Node name. This attribute is never null but may be an empty string.
    */
   protected String name;

   /**
    * Node namespace identifier. This attribute may be null if no namespace
    * identifier has already been set.
    */
   protected String namespaceURI;

   /**
    * Parent of the current node. This reference may be null if not parent has
    * already been set.
    */
   protected DrbNode parent;

   /**
    * Node attributes. The attribute list may be a null reference.
    */
   protected DrbAttributeList attributes;

   /**
    * Node avlue. The value of the node may be a null reference.
    */
   protected Value value;

   /**
    * Index of the node in its parent children list. Because a node may have no
    * parent, this index is defaulted to 0.
    */
   protected int index;

   /**
    * Chldren of the current node. The children list is DrbDefaultNodeList in
    * order to benefit by the insertion and removal operations inherited from
    * the ArrayList.
    */
   protected DrbDefaultNodeList children;

   /**
    * Previous sibling of the current node.
    */
   protected DrbNode previousSibling;

   /**
    * Next sibling of the current node.
    */
   protected DrbNode nextSibling;

   /**
    * User object.
    */
   protected Object userObject;

   /**
    * The root node path.
    */
   protected String rootPath = "";

   /**
    * Node namespace bindings. This attribute may be null if no namespace
    * bindings has already been set.
    */
   private Namespace namespaceBindings;

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(DrbDefaultMutableNode.class);

   /**
    * Builds a new instance of DrbDefaultMutableNode. In order to reduce the
    * constructor signature only the name of the node is passed to this
    * operation. this name shall never be null. The reference to the name is not
    * duplicated. The name string shall never be modified without using the
    * current class accessors.
    * 
    * @param name A reference to the name of the node to be instancied.
    * @param reference_node A reference to a node.
    */
   private DrbDefaultMutableNode(final DrbNode reference_node)
   {
      this(reference_node.getName());
      this.namespaceURI = reference_node.getNamespaceURI();
      this.referenceNode = reference_node;
   }

   /**
    * Builds a new instance of DrbDefaultMutableNode. In order to reduce the
    * constructor signature only the name of the node is passed to this
    * operation. this name shall never be null. The reference to the name is not
    * duplicated. The name string shall never be modified without using the
    * current class accessors.
    * 
    * @param name A reference to the name of the node to be instancied.
    */
   public DrbDefaultMutableNode(final String name)
   {
      this.name = name;
      this.index = 0;
   }

   /**
    * Builds a new instance of DrbDefaultMutableNode with a specified parent.
    * This constructor enables to build a new instance specifying more
    * parameters. Because in many cases it is not possible to create a node
    * specifying both the previous and the next sibling, their corresponding
    * parameters may be null references. The reference to the parent as well as
    * to the parent may be references to any node implementations (e.g.
    * XmlNodes).
    * 
    * @param name A reference to the name of the node to be instancied.
    * @param parent A reference to the parent of the node to be instanciated.
    * @param index The index of the node in is parent children list.
    * @param previous_sibling A reference to the previous_sibling or null.
    * @param next_sibling A reference to the next_sibling or null.
    */
   public DrbDefaultMutableNode(final String name, final DrbNode parent,
         final int index, final DrbNode previous_sibling,
         final DrbNode next_sibling)
   {
      this.name = name;
      this.index = index;

      this.parent = parent;

      this.previousSibling = previous_sibling;
      this.nextSibling = next_sibling;
   }

   /**
    * Name of the node. Read accessor to the previously set node name. The name
    * is never null but may be an empty string.
    * 
    * @return The name of the node.
    */
   public String getName()
   {
      return this.name;
   }

   /**
    * Name of the node. Returns the name of the node. This name is the canonical
    * name of the node It does not contains any prefix, path and location part.
    * This name clearly identifies the node in its parent depending only from
    * its occurence number and its index. All nodes provided by an
    * implementation is named. Therefore this operation never returns null
    * value. An empty string is however allowed if the node is unique (e.g. non
    * named root node).
    * 
    * @return The name of the node.
    */
   public String getXPathName()
   {
      if (this.parent == null)
      {
         return this.rootPath + "/" + super.getXPathName();
      }
      else
      {
         return super.getXPathName();
      }
   }

   /**
    * Changes the name of the node. Sets the passed name to the current node.
    * After modification, a node change event is fired to the listeners as
    * specified in the interface documentation.
    * 
    * @param name A reference to the new name to assign.
    * @throws UnsupportedOperationException This exception is never raised by
    *            the current implementation.
    * @throws NullPointerException This exception is raised when the passed name
    *            is a null reference.
    */
   public void rename(final String name) throws NullPointerException,
         UnsupportedOperationException
   {
      // Checks the reference to the input name

      if (name == null)
      {
         throw new NullPointerException("DrbDefaultMutableNode.rename() : "
               + "The reference to the new name is null.");
      }
      else
      {
         this.name = name;
      }

      // Fires the node changed event.

      this.nodesChanged(new DrbNodesChangeEvent(this));
   }

   /**
    * Set the content of the node. The content of the node is a sequence of
    * nodes, either text nodes (represented by string) either element nodes.
    * 
    * @param sequence The sequence to be set
    */
   public void setContent(final DrbSequence sequence)
   {
   }

   /**
    * Returns the root node. The root node retreival is delegated to the parent
    * node if any. If no parent has been declared for this node, the opreation
    * returns therefore null.
    * 
    * @return A reference to the root node or null.
    */
   public DrbNode getRoot()
   {
      if (this.parent != null)
      {
         return this.parent.getRoot();
      }
      else
      {
         return null;
      }
   }

   /**
    * Returns the index of the node. The index is the sequential position of the
    * current node in its parent children list.
    * 
    * @return The index of the current node in its parent children list.
    */
   public int getIndex()
   {
      return this.index;
   }

   /**
    * Sets the index of the node. Simple accessor to the index attribute.
    * 
    * @param index the index to be set.
    */
   public void setIndex(final int index)
   {
      this.index = index;
   }

   /**
    * Get namespace URI.
    * 
    * @return The namspace URI previsouly set or null if unspecified.
    */
   public String getNamespaceURI()
   {
      return this.namespaceURI;
   }

   /**
    * Sets the namespace URI. This operation fires a node changed event on
    * success as specified in the interface documentation. Any previous
    * namespace URI is discarded.
    * 
    * @param namespace_uri A reference to the new namespace identifier.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the new namespace identifier is null.
    * @throws UnsupportedOperationException This exception is never raised
    *            because the operation is fully implemented and accept any
    *            namespace.
    */
   public void setNamespaceURI(final String namespace_uri)
         throws NullPointerException, UnsupportedOperationException
   {
      // Checks the reference to the input identifier

      if (namespace_uri == null)
      {
         throw new NullPointerException(
               "DrbDefaultMutableNode.setNamespaceURI()"
                     + " : The reference to the nameapce URI is null.");
      }

      // Set the input input attribute list

      this.namespaceURI = namespace_uri;

      // Fires the node changed event

      this.nodesChanged(new DrbNodesChangeEvent(this));
   }

   /**
    * Get the namespace bindings.
    * 
    * @return The namespace bindings.
    */
   public Namespace getNamespaceBindings()
   {
      return this.namespaceBindings;
   }

   /**
    * Sets the namespace bindings.
    * 
    * @param namespaces A reference to the new namespace bindings.
    */
   public void setNamespaceBindings(final Namespace namespaces)
   {
      if (namespaces != null)
      {
         this.namespaceBindings = namespaces.cloneNamespace();
      }
      else
      {
         this.namespaceBindings = null;
      }
   }

   /**
    * The value type of the node. The value type is determined from the value
    * previously assigned to the node. If no speficic value has been previsouly
    * set, fr.gael.drb.value.Value.NULL_ID type is returned.
    * 
    * @return NULL_ID if the node does not provide value or any other valid type
    *         identifier otherwise.
    */
   public int getValueType()
   {
      if (this.referenceNode != null)
      {
         return this.referenceNode.getValueType();
      }

      if (this.value != null)
      {
         return this.value.getType();
      }
      else
      {
         return Value.NULL_ID;
      }
   }

   /**
    * The value of the node. The value is the one previously set.
    * 
    * @return A reference to the value of the node or null if no value has
    *         already been set.
    */
   public Value getValue()
   {
      if (this.referenceNode != null)
      {
         return this.referenceNode.getValue();
      }
      else
      {
         return this.value;
      }
   }

   /**
    * Changes the value of the node. This operation supports any king of value
    * due to the current implementation.The previous value (if any) is
    * completely discraded by the change. A node changed event is fired to the
    * listeners has specified in the interface documentation.
    * 
    * @param value The new value of the node. This value shall not be null.
    * @return The value paremeter because it is the effectivelly assigned value
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null.
    * @throws ClassCastException This exception is never raised because the
    *            value is immediatly adopted without cast.
    * @throws UnsupportedOperationException This exception is never raised
    *            because the operation is fully implemented and accept any value
    *            types.
    */
   public Value setValue(final Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      // Checks the reference to the input value

      if (value == null)
      {
         throw new NullPointerException("DrbDefaultMutableNode.setValue() : "
               + "The reference to the value to assign is null.");
      }

      // Set the input value

      this.value = value;

      // Fires the node changed event.

      this.nodesChanged(new DrbNodesChangeEvent(this));

      // Returns the input parameter that has not changed.

      return value;
   }

   /**
    * The attributes of the nodes. This operation returns a list of attribute
    * previously set (if any).
    * 
    * @return The list attributes of the current node or null if none.
    */
   public DrbAttributeList getAttributes()
   {
      if (this.referenceNode != null)
      {
         return this.referenceNode.getAttributes();
      }
      else
      {
         return this.attributes;
      }
   }

   /**
    * Sets the attribute list to the node. This operation fires a node changed
    * event on success as specified in the interface documentation. Any previous
    * attribute list is discarded.
    * <p>
    * <b>Warning:</b> The attribute list is not duplicated and shall therefore
    * not be modified by another means than the accessors provided by the
    * current node.
    * </p>
    * 
    * @param attributes A reference to the new attribute list.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the attribute list is null.
    * @throws UnsupportedOperationException This exception is never raised
    *            because the operation is fully implemented and accept any
    *            attribute.
    */
   public void setAttributes(final DrbAttributeList attributes)
         throws NullPointerException, UnsupportedOperationException
   {
      // Checks the reference to the input attribute list

      if (attributes == null)
      {
         throw new NullPointerException(
               "DrbDefaultMutableNode.setAttributes() : "
                     + "The reference to the attributes is null.");
      }

      // Set the input input attribute list

      this.attributes = attributes;

      // Fires the node changed event

      this.nodesChanged(new DrbNodesChangeEvent(this));
   }

   /**
    * The parent of this node. Returns a reference to the parent node set
    * previously.
    * 
    * @return The parent of this node or null.
    */
   public DrbNode getParent()
   {
      return this.parent;
   }

   /**
    * Sets the parent of this node. This passed reference can be of any DrbNode
    * type but the operation does not attaches the current node the parent (i.e.
    * in order to become one of its children), does not check the parent is able
    * to have any child and moreover does not try to attach any sibling. It is
    * an simple accessor the the parent reference.
    * 
    * @param parent the parent node
    */
   public void setParent(final DrbNode parent)
   {
      this.parent = parent;
   }

   /**
    * The list of children of the current node. Returns a list of references to
    * the children of the current node. The current node may have no child and
    * the operation returns therefore a null reference.
    * 
    * @return The list of children if any null otherwise.
    */
   public DrbNodeList getChildren()
   {
      if (this.referenceNode == null)
      {
         return this.children;
      }
      else
      {
         return this.referenceNode.getChildren();
      }
   }
   
   /**
    * Sets the list of children of the current node.
    * The passed children is never modified to set this node as the parent.
    * @param children list to be set. Can be null if no children is expected.  
    */
   public void setChildren(DrbNodeList children)
   {
      if (this.referenceNode == null)
      {
         this.children=(DrbDefaultNodeList)children;
      }
      else
      {
         throw new UnsupportedOperationException("Children cannot be changed.");
      }
   }

   /**
    * Duplicates deeply the given tree. The output tree is an homogeneous tree
    * of DrbDefaultMutableNodes. The input may not be of DrbDefaultMutableNode
    * class.The relations between the resulting nodes matches exactly the one of
    * the input one. During the duplication of a node the following attributes
    * are conveyed :
    * <p>
    * <ul>
    * name
    * </ul>
    * <ul>
    * index
    * </ul>
    * <ul>
    * attributes
    * </ul>
    * <ul>
    * namespace URI
    * </ul>
    * <ul>
    * value
    * </ul>
    * <ul>
    * children (new instances DrbDefaultMutableNode are created)
    * </ul>
    * </p>
    * All other information are discarded during the duplication. In particular
    * the physical representation (if any) is completely lost.
    * <p>
    * <b>Warning:</b> This operation may have an important or non-applicable
    * memory footprint. It shall therefore be used with caution.
    * </p>
    * 
    * @param in_node A reference to the sub-tree root node to be duplicated.
    * @return The root node of the duplicated tree or null is an error occured.
    */
   private DrbDefaultMutableNode duplicateTree(final DrbNode in_node)
   {
      // Checks the input node.

      if (in_node == null)
      {
         logger.error("DrbDefaultMutableNode.duplicateTree() : "
               + "Invalid parameter.");
         return null;
      }

      // Extract the input node name and return if null.

      final String name = in_node.getName();

      if (name == null)
      {
         logger.error("DrbDefaultMutableNode.duplicateTree() : "
               + "Input node has no name.");
         return null;
      }

      // Allocates a new node with the extreacted name

      final DrbDefaultMutableNode outNode = new DrbDefaultMutableNode(name);

      // Duplicates properties

      try
      {
         // Duplicate attributes list (if any)

         final DrbAttributeList attrib = in_node.getAttributes();

         if (attrib != null)
         {
            outNode.setAttributes(attrib);
         }

         // Duplicate index

         outNode.setIndex(in_node.getIndex());

         // Duplicate NS URI (if any)

         final String namespaceURI = in_node.getNamespaceURI();

         if (namespaceURI != null)
         {
            outNode.setNamespaceURI(namespaceURI);
         }

         // Duplicate value (if any)

         final Value outValue = in_node.getValue();

         if (outValue != null)
         {
            outNode.setValue(outValue);
         }

         // Duplicate children (recursive)

         final DrbNodeList nodeList = in_node.getChildren();
         if (nodeList != null)
         {
            final int nodeCount = nodeList.getLength();

            for (int inode = 0; inode < nodeCount; inode++)
            {
               final DrbDefaultMutableNode childNode =
                  this.duplicateTree(nodeList.item(inode));

               if (childNode != null)
               {
                  outNode.appendChild(childNode);
               }
            }
         }
      }
      catch (final Exception e)
      {
         return null;
      }

      return outNode;
   }

   /**
    * Appends a child to the node. This operation depends on the class of the
    * node to be appended:
    * <p>
    * <ul>
    * <b>Case of DrbDefaultMutableNode:</b> The node is appended in the
    * children list, the previous sibling of the passed node is set to the
    * previous child and the next sibling to null.The parent of the appended
    * node is set to the current node and the index fixed to the length of the
    * children count minus 1.
    * </ul>
    * <ul>
    * <b>Other cases:</b> The input tree is entirely duplicated to become an
    * homogeneous tree of DrbDefaultMutableNodes. After this operation, the
    * resulting root node is appended to the children list of the current node
    * as in the previous case The tree duplication is preformed with the
    * duplicateTree() operation of the present class.
    * </ul>
    * </p>
    * <p>
    * <b>Warning:</b> The duplication may have an important or non-applicable
    * memory footprint. This operation shall therefore be used with caution.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * operation succeeded.The called operation is nodesInserted() of the
    * Listeners.
    * 
    * @see Listeners fr.gael.drb.DrbNodesChangeListener
    *      </p>
    * @param node A reference to the child to append.
    * @return The input node if instance of DrbDefaultMutableNode or a new
    *         instance of DrbDefaultMutableNode.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null.
    * @throws UnsupportedOperationException This exception is thrown when the
    *            node to append is not a instance of DrbDefaultMutableNode and
    *            the duplication operation has failed.
    */
   public DrbNode appendChild(final DrbNode node) throws NullPointerException,
         UnsupportedOperationException
   {
      /**
       * Checks the reference to the input node.
       */
      if (node == null)
      {
         throw new NullPointerException(
               "DrbDefaultMutableNode.appendChild() : "
                     + "The reference to the node to append is null.");
      }

      if (this.referenceNode != null)
      {
         return this.referenceNode.appendChild(node);
      }

      /**
       * Case of non DrbDefaultMutableNode. In such case, the input tree has to
       * be duplicated first in order to convert the input node to a
       * DrbDefaultMutableNode interface.
       */
      DrbDefaultMutableNode newNode;

      if (!(node instanceof DrbDefaultMutableNode))
      {
         newNode = this.duplicateTree(node);

         if (newNode == null)
         {
            throw new UnsupportedOperationException(
                  "DrbDefaultMutableNode.appendChild() :"
                        + "Cannot duplicate input tree.");
         }
      }
      else
      {
         newNode = (DrbDefaultMutableNode) node;
      }

      /**
       * Appends the node to the children list. The children list is created is
       * not alredy done.
       */
      if (this.children == null)
      {
         this.children = new DrbDefaultNodeList();
      }

      if (newNode.referenceNode != null)
      {
         this.children.add(newNode.referenceNode);
      }
      else
      {
         this.children.add(newNode);
      }

      /**
       * Links the node to its new neighborhood. In this section, the parent,
       * the index as well as the siblings of the appended node are fixed.
       */
      newNode.setParent(this);
      final int nodeIndex = this.children.getLength() - 1;

      newNode.setIndex(nodeIndex);

      if (nodeIndex > 0)
      {
         newNode.setPreviousSibling(this.children.item(nodeIndex - 1));
      }
      else
      {
         newNode.setPreviousSibling(null);
      }

      newNode.setNextSibling(null);

      /**
       * Links the previous sibling. The link is perform only if a previous
       * sibling exists and if it is a default mutable node.
       */
      if ((this.children.getLength() > 1)
            && (this.children.item(this.children.getLength() - 2) instanceof DrbDefaultMutableNode))
      {
         ((DrbDefaultMutableNode) this.children
               .item(this.children.getLength() - 2)).setNextSibling(newNode);
      }

      /**
       * Fires nodes change event. The appended node is placed in a new node
       * list which is aggregated to a new event instance. The event instance is
       * fired to the listeners through the nodesInserted() operation.
       */
      final DrbDefaultNodeList nodeList = new DrbDefaultNodeList();

      if (newNode.referenceNode != null)
      {
         nodeList.add(newNode.referenceNode);
      }
      else
      {
         nodeList.add(newNode);
      }

      this.nodesInserted(new DrbNodesChangeEvent(this, nodeList));

      // Returns the effectively inserted node.
      return this.children.item(this.children.getLength() - 1);
   }

   /**
    * Inserts a child to the node children list. Inserts a child at a given
    * position. The passed node is inserted in the list of children at the given
    * position.The position is the expected index of the node after insertion.
    * All the previous children from the aimed position to the end of the list
    * are shift to the end of the new children list (i.e. their indices are
    * shifted up of 1). If the given index is out of the children bounds and
    * therefore less than zero and greater to the current number of children,
    * the operation raises an exception. An index equal to the current number of
    * children is allowed and the operation is therefore equivalent to
    * appendChild(). This operation depends on the class of the node to be
    * inserted:
    * <p>
    * <ul>
    * <b>Case of DrbDefaultMutableNode:</b> The node is inserted in the
    * children list, the previous sibling of the passed node is set to the
    * previous child as well as the next sibling. The parent of the appended
    * node is set to the current node and the index fixed to the requested one.
    * </ul>
    * <ul>
    * <b>Other cases:</b> The input tree is entirely duplicated to become an
    * homogeneous tree of DrbDefaultMutableNodes. After this operation, the
    * resulting root node is inserted to the children list of the current node
    * as in the previous case The tree duplication is preformed with the
    * duplicateTree() operation of the present class.
    * </ul>
    * </p>
    * <p>
    * <b>Warning:</b> The duplication may have an important or non-applicable
    * memory footprint. This operation shall therefore be used with caution.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * operation succeeded.The called operation is nodesInserted() of the
    * Listeners.
    * 
    * @see Listeners fr.gael.drb.DrbNodesChangeListener
    *      </p>
    * @param node A reference to the child to be inserted.
    * @param index the index of the nodo to insert
    * @return The input node if instance of DrbDefaultMutableNode or a new
    *         instance of DrbDefaultMutableNode.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null.
    * @throws UnsupportedOperationException This exception is thrown when the
    *            node to append is not a instance of DrbDefaultMutableNode and
    *            the duplication operation has failed.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    */
   public DrbNode insertChild(final DrbNode node, final int index)
         throws NullPointerException, UnsupportedOperationException,
         IndexOutOfBoundsException
   {
      /**
       * Checks the reference to the input node.
       */
      if (node == null)
      {
         throw new NullPointerException(
               "DrbDefaultMutableNode.insertChild() : "
                     + "The reference to the node to append is null.");
      }

      if (this.referenceNode != null)
      {
         return this.referenceNode.insertChild(node, index);
      }

      /**
       * Checks the expected index. The expected index has to be greater or
       * equal than zero and less or equal than the current nu;ber of children.
       * The index is checked first in order to avoid unnecessary duplication of
       * node before adding the child.
       */
      if ((index < 0) || // Case of invalid index

            ((this.children == null) && // Case of empty children list and
            (index != 0)) || // requested not equal to 0

            ((this.children != null) && // Case of oversized requested index
            (index > this.children.size())))
      {
         throw new IndexOutOfBoundsException(
               "DrbDefaultMutableNode.insertChild() : "
                     + "Invalid requested index " + "(children count="
                     + ((this.children != null) ? this.children.size() : 0)
                     + ", index=" + index);
      }

      /**
       * Case of non DrbDefaultMutableNode. In such case, the input tree has to
       * be duplicated first in order to convert the input node to a
       * DrbDefaultMutableNode interface.
       */
      DrbDefaultMutableNode newNode;

      if (!(node instanceof DrbDefaultMutableNode))
      {
         newNode = this.duplicateTree(node);

         if (newNode == null)
         {
            throw new UnsupportedOperationException(
                  "DrbDefaultMutableNode.insertChild() :"
                        + "Cannot duplicate input tree.");
         }
      }
      else
      {
         newNode = (DrbDefaultMutableNode) node;
      }

      /**
       * Inserts the node to the children list. The children list is created is
       * not alredy done. The exception is tryed but no exception shall be
       * thrown because the index has already been checked.
       */
      if (this.children == null)
      {
         this.children = new DrbDefaultNodeList();
      }

      try
      {
         this.children.add(index, newNode);
      }
      catch (final IndexOutOfBoundsException e)
      {
         throw new IndexOutOfBoundsException(
               "DrbDefaultMutableNode.insertChild() : " + e + "\n"
                     + "The index had however already been checked !?");
      }

      /**
       * Links the node to its new neighborhood. In this section, the parent,
       * the index as well as the siblings of the inserted node are fixed.
       */
      newNode.setParent(this);

      newNode.setIndex(index);

      if (index > 0)
      {
         newNode.setPreviousSibling(this.children.item(index - 1));
         ((DrbDefaultMutableNode) (this.children.item(index - 1)))
               .setNextSibling(newNode);
      }
      else
      {
         newNode.setPreviousSibling(null);
      }

      if (index < (this.children.size() - 2))
      {
         newNode.setNextSibling(this.children.item(index + 1));
         ((DrbDefaultMutableNode) (this.children.item(index + 1)))
               .setPreviousSibling(newNode);
      }
      else
      {
         newNode.setNextSibling(null);
      }

      /**
       * Updates the indicies of the next siblings.
       */
      DrbDefaultMutableNode nextSibling;

      for (int ichild = index + 1; ichild < this.children.size(); ichild++)
      {
         nextSibling = (DrbDefaultMutableNode) this.children.get(ichild);

         if (nextSibling != null)
         {
            nextSibling.setIndex(ichild);
         }
         else
         {
            logger
                  .error("DrbDefaultMutableNode.insertChild() : "
                        + "Warning : Cannot set index of the next sibling #"
                        + ichild);
         }
      }

      /**
       * Fires nodes change event. The inserted node is placed in a new node
       * list which is aggregated to a new event instance. The event instance is
       * fired to the listeners through the nodesInserted() operation.
       */
      final DrbDefaultNodeList nodeList = new DrbDefaultNodeList();

      nodeList.add(newNode);

      this.nodesInserted(new DrbNodesChangeEvent(this, nodeList));

      // Returns the effectively inserted node.

      return newNode;
   }

   /**
    * Removes an existing child. The child at the given index is removed from
    * the children list of the current node. The child is not modified by this
    * operation. At the child point of view it keeps the same parent,
    * associtation, value, etc. However at the parent (i.e. the current node)
    * point of view the removed node is completely dismissed and will never be
    * re-instaciated from constructor operations (e.g. getFirstChild(), etc. ).
    * The index of the child to be removed has to correspond to an existing
    * children index. If the index is less than zero or greater or equal to the
    * current number of children, an exception is thrown.
    * <p>
    * This operation takes into account the removal by updating the sibling
    * associations of the children nodes prior and next to the removed one. The
    * indicies of the nodes next to the removed one are decresed of one. Their
    * parents as well as their contents are left unchanged.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event on successful
    * removal. The node affected by the change is the removed node and the
    * source is the current node. The called operation is the nodesRemoved() of
    * the listeners.
    * </p>
    * 
    * @param index Index of the child to be removed.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception never raised.
    */
   public void removeChild(final int index) throws IndexOutOfBoundsException,
         UnsupportedOperationException
   {
      if (this.referenceNode != null)
      {
         this.referenceNode.removeChild(index);
         return;
      }

      DrbDefaultMutableNode removedChild; // Potentially removed node

      /**
       * Removes the child from the children list. The checking of the passed
       * index is left to the ArrayList. The out of bound exception is however
       * raised automatically when the current node has no child.
       */
      try
      {
         if (this.children == null)
         {
            throw new IndexOutOfBoundsException(
                  "DrbDefaultMutableNode.removeChild() : "
                        + "No child to removed (index = " + index + ").");
         }

         removedChild = (DrbDefaultMutableNode) this.children.remove(index);
      }
      catch (final IndexOutOfBoundsException e)
      {
         throw new UnsupportedOperationException(
               "DrbDefaultMutableNode.removeChild() : " + e);
      }

      /**
       * Updates the sibling associations. The sibling associations of the nodes
       * prior to and next to the removed one have to be updated.
       */
      final DrbDefaultMutableNode previousSibling =
         (DrbDefaultMutableNode) removedChild.getPreviousSibling();

      final DrbDefaultMutableNode nextSibling =
         (DrbDefaultMutableNode) removedChild.getNextSibling();

      if (previousSibling != null)
      {
         previousSibling.setNextSibling(nextSibling); // May be null
      }

      if (nextSibling != null)
      {
         nextSibling.setPreviousSibling(previousSibling); // May also be null
      }

      /**
       * Updates the indicies of the next siblings.
       */
      DrbDefaultMutableNode child = nextSibling;

      while (child != null)
      {
         child.setIndex(child.getIndex() - 1);

         child = (DrbDefaultMutableNode) child.getNextSibling();
      }

      /**
       * Fires node changed event.
       */
      final DrbDefaultNodeList nodeList = new DrbDefaultNodeList();

      nodeList.add(removedChild);

      this.nodesRemoved(new DrbNodesChangeEvent(this, nodeList));
   }

   /**
    * Replaces a child of the current node. This operation replaces a child in
    * the current children list by a new one The operation aborts when the index
    * is out of bound (index < 0 || index > size). This operation first removes
    * the children at the given index and then inserts the new node at the same
    * index. These actions are delegated to the removeChild() and insertChild()
    * operations. Please refer to the documentation of these operations for a
    * best understanding of what actions are effectively performed.
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the new node and the source is the current node.The called operation is
    * the structureChanged() of the listeners.
    * </p>
    * 
    * @param index Index of the node to be replaced. This index starts at 0 and
    *           shall be less than the number of children.
    * @param node A reference to the node that replaces the old one.
    * @return A reference to the effectivelly replacing node.This reference may
    *         differ from the node parameter.
    * @throws NullPointerException This exception is raised when the reference
    *            to the new node is null.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index does not correspond to any effective child.
    * @throws UnsupportedOperationException This exception is raised if one of
    *            the calls to removeChild() and insertChild() operations has
    *            raised it. This case shall never appear because the children
    *            list is supposed to be a consistent collection of
    *            DrbDefaultMutableNodes.
    */
   public DrbNode replaceChild(final int index, final DrbNode node)
         throws NullPointerException, IndexOutOfBoundsException,
         UnsupportedOperationException
   {
      /**
       * Check the reference to the replacing node.
       */
      if (node == null)
      {
         throw new NullPointerException(
               "DrbDefaultMutableNode.replaceChild() : "
                     + "Reference to the node is null.");
      }

      if (this.referenceNode != null)
      {
         return this.referenceNode.replaceChild(index, node);
      }

      /**
       * Declaration of the potentially replacing node.
       */
      DrbDefaultMutableNode replacingNode = null;

      /**
       * Removes the child at the given index. If an exception is raised, it is
       * propagated with the same type.
       */
      try
      {
         this.removeChild(index);
      }
      catch (final IndexOutOfBoundsException e)
      {
         throw new IndexOutOfBoundsException(
               "DrbDefaultMutableNode.replaceChild() : "
                     + e
                     + "\n"
                     + "   Unable to remove node because the index is outside range.");
      }
      catch (final UnsupportedOperationException e)
      {
         throw new UnsupportedOperationException(
               "DrbDefaultMutableNode.replaceChild() : " + e + "\n"
                     + "   This exception should never be thrown !!!\n"
                     + "   The children list may be inconsistent.");
      }

      /**
       * Inserts the node at the same index position.
       */
      try
      {
         replacingNode = (DrbDefaultMutableNode) this.insertChild(node, index);
      }
      catch (final NullPointerException e)
      {
         throw new NullPointerException(
               "DrbDefaultMutableNode.replaceChild() : " + e + "\n"
                     + "   Unable to insert a null child.\n"
                     + "   This exception should never be thrown !!!");
      }
      catch (final IndexOutOfBoundsException e)
      {
         throw new IndexOutOfBoundsException(
               "DrbDefaultMutableNode.replaceChild() : " + e + "\n"
                     + "   Unable to insert the child at the position #"
                     + index + ".\n"
                     + "   This exception should never be thrown !!!");
      }
      catch (final UnsupportedOperationException e)
      {
         throw new IndexOutOfBoundsException(
               "DrbDefaultMutableNode.replaceChild() : " + e + "\n"
                     + "   Unable to insert the child for unknown reason.\n"
                     + "   This exception should never be thrown !!!");
      }

      /**
       * Fires node changed event.
       */
      final DrbDefaultNodeList nodeList = new DrbDefaultNodeList();

      nodeList.add(replacingNode);

      this.structureChanged(new DrbNodesChangeEvent(this, nodeList));

      /**
       * Returns the replacing node.
       */
      return replacingNode;
   }

   /**
    * Adopt a child at the end of the children list. The passed node is inserted
    * in the list of children at the end of the current list.
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to append a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Case of unordered or specifically ordered implementations:</b> If the
    * implementation does not support ordered children or has specific ordering
    * rules, the node may not be appended but only inserted according to these
    * rules. For instance it may not be possible to impose the file order in a
    * directory: it generally depends on the lexicographical order of the node
    * names or their creation date.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the appended node and the source is the current node. The called
    * operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param node A reference to the node to be adopted.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference.This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested append for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbNode appendReference(final DrbNode node)
         throws NullPointerException, UnsupportedOperationException
   {
      return this.appendChild(new DrbDefaultMutableNode(node));
   } // appendReference

   /**
    * Previous sibling of the current node.
    * 
    * @return A reference to the previous sibling or null if no such node.
    */
   public DrbNode getPreviousSibling()
   {
      return this.previousSibling;
   }

   /**
    * Sets previous sibling of the current node. The association to the previous
    * sibling can be cancelled by passing a null parameter. This operation is a
    * simpl accessor.
    * <p>
    * <b>Warning:</b> This operation is dedicated to the creation and
    * maintenance of node. It does not detach the node from its parent or
    * siblings (from their point of view) and does not fire any event.
    * </p>
    * 
    * @param previous_sibling A reference to the new previous sibling to be set.
    */
   public void setPreviousSibling(final DrbNode previous_sibling)
   {
      this.previousSibling = previous_sibling;
   }

   /**
    * Next sibling of the current node.
    * 
    * @return A reference to the next sibling or null if no such node.
    */
   public DrbNode getNextSibling()
   {
      return this.nextSibling;
   }

   /**
    * Sets next sibling of the current node. The association to the next sibling
    * can be cancelled by passing a null parameter. This operation is a simple
    * accessor.
    * <p>
    * <b>Warning:</b> This operation is dedicated to the creation and
    * maintenance of node. It does not detach the node from its parent or
    * siblings (from their point of view) and does not fire any event.
    * </p>
    * 
    * @param next_sibling A reference to the new next sibling to be set.
    */
   public void setNextSibling(final DrbNode next_sibling)
   {
      this.nextSibling = next_sibling;
   }

   /**
    * Checks nodes sameness. In the current implementation only the Java
    * reference can be use to determine the sameness of the node. Actually the
    * parent node provides an interesting isSame() operation but it is
    * impossible to check the current nodes deals with the same object (in the
    * general sense) that the passed one.
    * 
    * @param node The node to test against to the current one.
    * @return true if the node references the same object as the current node
    *         and false otherwise (i.e. including null reference to node).
    */
   public boolean isSame(final DrbNode node)
   {
      if (node == this)
      {
         return true;
      }
      else
      {
         return false;
      }
   }

   /**
    * Returns the user object node.
    * 
    * @return the user object previously set.
    */
   public Object getUserObject()
   {
      return this.userObject;
   }

   /**
    * Returns the root path.
    * 
    * @return the root path if any or an empty string
    */
   public String getRootPath()
   {
      return this.rootPath;
   }

   /**
    * Set the user object node.
    * 
    * @param user_object The new user object.
    */
   public void setUserObject(final Object user_object)
   {
      this.userObject = user_object;
   }

   /**
    * Set the path of the root node.
    * 
    * @param root_path The path of the root node.
    */
   public void setRootPath(String root_path)
   {
      if (root_path == null)
      {
         this.rootPath = "";
      }
      else
      {
         if (root_path.endsWith("/"))
         {
            root_path = root_path.substring(0, root_path.length() - 1);
         }
         this.rootPath = root_path;
      }
   }

   /**
    * Tests if a specific interface can be provided. This operations tests with
    * a minimum of time and memory consumption if the current implementation can
    * provide a specific interface. It important to consider that hasImpl()
    * provides information about the ability to provide such interface in
    * general cases but not focused on the current instance. It may therefore be
    * impossible to get a specific implementation from a node whereas hasImpl()
    * operation returns true.
    * 
    * @param api The class type to test.
    * @return true if an implementation of the interface can be provided and
    *         false otherwise.
    */
   public boolean hasImpl(final Class api)
   {
      if (api == null)
      {
         return false;
      }
      if (api.isInstance(this.getUserObject()))
      {
         return true;
      }
      return super.hasImpl(api);
   }

   /**
    * Returns a specific implementation. This operation returns a reference to
    * an object implementing a specific interface. This mean is useful to
    * benefit by a specific and direct API instead of using the DrbNode
    * interface. The provided object shall represent the current node such as it
    * is possible after a call to this operation, to dismiss the reference to
    * the node. For instance, a file is usually wrapped as a drb.imple.file.File
    * class and thanks to this operation can be seen as a InputStream anabling
    * direct access to the handled file.
    * 
    * @param api The interface (or class) to be provided.
    * @return A reference to the object implementing the interface or a null
    *         reference otherwise.
    */
   public Object getImpl(final Class api)
   {
      if (api == null)
      {
         return null;
      }
      if (api.isInstance(this.getUserObject()))
      {
         return this.getUserObject();
      }
      return super.getImpl(api);
   }

   /**
    * Returns the node as a string. This operation only prints the node name.
    * 
    * @return The string descibing the current node.
    */
   public String toString()
   {
      String outputString = "<" + this.getName() + ">\n";

      if (this.getValue() != null)
      {
         outputString = outputString + "   " + this.getValue() + "\n";
      }

      if (this.children != null)
      {
         for (int ichild = 0; ichild < this.children.getLength(); ichild++)
         {
            outputString = outputString + this.children.item(ichild);
         }
      }

      outputString = outputString + "</" + this.getName() + ">\n";

      return outputString;
   }

   /**
    * Makes this class runnable for testing.
    * 
    * @param args the main arguments
    */
   public static void main(final String[] args)
   {
      final DrbDefaultMutableNode root = new DrbDefaultMutableNode("root");
      DrbDefaultMutableNode child_1 = null;
      DrbDefaultMutableNode child_2 = null;
      root.appendChild(new DrbDefaultMutableNode("toto"));
      root.appendChild(child_1 = new DrbDefaultMutableNode("multi"));
      root.appendChild(child_2 = new DrbDefaultMutableNode("multi"));
      root.appendChild(new DrbDefaultMutableNode("tutu"));
      fr.gael.drb.impl.xml.XmlFactory.writeXML(root, System.out);
      System.out.println("root.getPath=" + root.getPath());
      System.out.println("child_1.getPath=" + child_1.getPath());
      System.out.println("child_1.getPreviousSibling="
            + child_1.getPreviousSibling().getPath());
      System.out.println("child_1.getNextSibling="
            + child_1.getNextSibling().getPath());
      System.out.println("child_2.getPath=" + child_2.getPath());
      System.out.println("child_2.getPreviousSibling="
            + child_2.getPreviousSibling().getPath());
      System.out.println("child_2.getNextSibling="
            + child_2.getNextSibling().getPath());
   }
}// DrbDefaultMutableNode
