/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

/**
 * Output of the XML-Schema validator.
 */
public interface XsdInvalid
{

   /**
    * ALL
    */
   public final int ALL = 0xffff;

   /**
    * NONE
    */
   public final int NONE = 0x0000;

   /**
    * Schema-Validity assessment (Attribute).
    */
   public final int CVC_ASSESS_ATTR = 0x0001;

   /**
    * Schema-Validity assessment (Element).
    */
   public final int CVC_ASSESS_ELT = 0x0002;

   /**
    * Attribute Locally Valid
    */
   public final int CVC_ATTRIBUTE = 0x0004;

   /**
    * Attribute Locally Valid (Use)
    */
   public final int CVC_AU = 0x0008;

   /**
    * Element Locally Valid (Complex Type)
    */
   public final int CVC_COMPLEX_TYPE = 0x0010;

   /**
    * Datatype Valid
    */
   public final int CVC_DATATYPE_VALID = 0x0020;

   /**
    * Element Locally Valid
    */
   public final int CVC_ELT = 0x0040;

   /**
    * Enumeration valid
    */
   public final int CVC_ENUMERATION_VALID = 0x0080;

   /**
    * GROUP_MODEL
    */
   public final int GROUP_MODEL = 0x0100;

   /**
    * Returns a message describing the validation result.
    * 
    * @return the message describing the validation result.
    */
   public String getMessage();

   /**
    * Returns a status describing the validation result.
    * 
    * @return the status describing the validation result.
    */
   public int getStatus();

   /**
    * Returns the component.
    * 
    * @return the component.
    */
   public XsdComponent getComponent();

   /**
    * Returns the children message.
    * 
    * @return the children invalid.
    */
   public XsdInvalid[] getChildren();

} // XsdInvalid
