/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds.schema;

import org.apache.log4j.Logger;

import fr.gael.drb.impl.sds.Length;

/**
 * Length attribute in descriptor. This class is used to manage a length
 * attribute
 */
public class SdfLength extends SdfAttribute
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(SdfLength.class);

   /**
    * Constant : Unit is "Bit".
    */
   static protected final short UNIT_BIT = 1;

   /**
    * Constant : Unit is "Byte".
    */
   static protected final short UNIT_BYTE = 2;

   /**
    * Constant : Unit is "Unknown".
    */
   static protected final short UNIT_UNKNOWN = -1;

   /**
    * The unit of the length attribute.
    */
   protected short unit;

   /**
    * Builds a SdfLength instance.
    */
   protected SdfLength()
   {
      this(VARIABLE);
   }

   /**
    * Builds a SdfLength instance with the given value type. In case of non
    * fixed value type the map will be created.
    * 
    * @param type The type of the physical attribute value. It shall be
    *           READ_ONLY or READ_WRITE.
    */
   protected SdfLength(final int type)
   {
      // Call parent constructor
      super(type);
      this.unit = this.UNIT_BIT;
   }

   /**
    * Returns the value unit.
    * 
    * @return The type of the length attribute value. It shall be UNKNOWN, BYTE,
    *         BIT.
    */
   protected final short getUnit()
   {
      return this.unit;
   }

   /**
    * Sets the value unit.
    * 
    * @param unit the unit
    */
   protected final void setUnit(final short unit)
   {
      this.unit = unit;
   }

   /**
    * Returns the length value associated to the key. If the value type is fixed
    * then returns the unique value, else get the value associated to the key
    * from the map .
    * 
    * @param key The key to use if needed to get the value from map.
    * @return The value of the physical attribute or -1
    */
   protected final Length getLength(final int[] key)
   {
      final long val = this.getValue(key);
      if (val == -1)
      {
         return null;
      }
      if (this.unit == this.UNIT_BYTE)
      {
         return new Length(val);
      }
      else
      {
         return new Length(0, val);
      }
   }

   /**
    * Sets the value according to the current value type. If the value type is
    * unknown the value stays unchanged. If the value type is fixed the value is
    * unique and set directly. If the value type is non fixed the given value is
    * stored in the map using the given key. If the key is null the value is not
    * added to the map.
    * 
    * @param key The key
    * @param value the value
    */
   protected final void setLength(final int[] key, final Length value)
   {
      if (value == null)
      {
         this.setValue(key, -1);
      }
      else if (this.unit == this.UNIT_BYTE)
      {
         this.setValue(key, value.getLength());
      }
      else
      {
         this.setValue(key, value.getLength() * 8 + value.getBitLength());
      }
   }

   /**
    * Prints info into a string.
    * 
    * @return String
    */
   public String toString()
   {
      // Local declarations
      String tmpStr;

      switch (this.accessType)
      {
         case FIXED:
            tmpStr = "access=READ_ONLY";
            break;
         case VARIABLE:
            tmpStr = "access=READ_WRITE";
            break;
         default:
            tmpStr = "access=INVALID";
            break;
      }

      if (this.unit == this.UNIT_BIT)
      {
         tmpStr = tmpStr + " unit=bit";
      }
      else if (this.unit == this.UNIT_BYTE)
      {
         tmpStr = tmpStr + " unit=byte";
      }

      switch (this.occurrenceType)
      {
         case SINGLE:
            tmpStr += " occurs=SINGLE " + this.map;
            break;
         case MULTIPLE:
            tmpStr += " occurs=MULTIPLE " + this.map;
            break;
         default:
            tmpStr += " occurs=INVALID";
            break;
      }
      // Return info string
      return "{" + tmpStr + "}";
   }
} // SdfLength
