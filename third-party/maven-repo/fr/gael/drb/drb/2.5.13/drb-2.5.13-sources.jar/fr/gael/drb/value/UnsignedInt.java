/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * The UnsignedInt class is a wrapper for unsigned integer values. For all
 * arithmetics operations it is handled as a simple Int.
 */
public class UnsignedInt extends AbstractNumeric implements ValueFormat
{
   // ==============================================
   // Attributes part.
   // ==============================================
   /**
    * The UnsignedInt priority.
    */
   public final static int PRIORITY = 3;

   /**
    * The Int value.
    */
   protected int value;

   // =================================================
   // Methods part.
   // ================================================
   /**
    * Constructs a UnsignedInt initialized to the specified int value.
    * 
    * @param v the value of the UnsignedInt.
    */
   public UnsignedInt(final int v)
   {
      this.value = v;
   }

   /**
    * Returns a new String object representing this BinaryInt. The String is a
    * sequence of bits value.
    * 
    * @return a string representation of the object.
    */
   public java.lang.String toString()
   {
      return java.lang.Long.toString(this.value & 0xffffffffL);
   }

   /**
    * Returns a new String object representing this BinaryInt. The String is a
    * sequence of bits value.
    * 
    * @param v the int object
    * @return a string representation of the object.
    */
   public static java.lang.String toString(final int v)
   {
      return java.lang.Long.toString(v & 0xffffffffL);
   }

   // ----------------------------------------------------------
   // ValueFormat interface implementation
   // -----------------------------------------------------------
   // see interface ValueFormat for more information.

   /**
    * Return a string containing the value with a fixed format.
    * 
    * @param length The expected length of the output string
    * @return The formatted string.
    */
   public java.lang.String getFormattedString(final int length)
   {
      return new java.lang.String(new java.text.DecimalFormat(
            "+0000000000;-0000000000").format(this.value & 0xffffffffL));
   }

   /**
    * Return a byte buffer containing the value in a fixed format.
    * 
    * @return The formatted buffer.
    */
   public byte[] getFormattedBuffer()
   {
      final byte[] buffer = new byte[4];
      buffer[0] = (byte) (this.value >>> 24);
      buffer[1] = (byte) (this.value >>> 16);
      buffer[2] = (byte) (this.value >>> 8);
      buffer[3] = (byte) (this.value);
      return buffer;
   }

   // --------------------------------------------------------
   // Value interface implementation
   // -------------------------------------------------------
   /**
    * The type identifier of this Int value .
    * 
    * @return an identifier of the Int type.
    */
   public final int getType()
   {
      return UNSIGNED_INT_ID;
   }

   /**
    * Returns the UnsignedInt priority
    * 
    * @return the UnsignedInt priority
    */
   public final int getPriority()
   {
      return this.PRIORITY;
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself is returned. If the conversion is not allowed a
    * ClassCastException is thrown. The type must be a number (BOOLEAN_ID to
    * DOUBLE_ID) or an array.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException exception
    */
   public final Value convertTo(final int type) throws ClassCastException
   {
      switch (type)
      {
         // UnsignedInt -> UnsignedInt conversion
         case UNSIGNED_INT_ID:
         case NUMERIC_ID:
            return this;

            // UnsignedInt -> UnsignedIntArray conversion
         case ARRAY_ID:
            final UnsignedIntArray uintArray = new UnsignedIntArray(1);
            uintArray.assign(0, this.intValue());
            return uintArray;

            // UnsignedInt -> Unknown conversion
         default:
            return super.convertTo(type);
      }
   }

   /**
    * Assign a new Value. An implicit conversion may be performed to make the
    * assignment. This assignment may result in a loss of precision (ex : float
    * to int).
    * 
    * @param v the value to be assigned.
    */
   public void assign(final Value v)
   {
      final Numeric vi = (Numeric) v.convertTo(NUMERIC_ID);
      this.value = vi.intValue();
   }

   // --------------------------------------------------------
   // Arithmetic interface implementation
   // --------------------------------------------------------
   /**
    * Compute the unary minus of this value.
    * 
    * @return The unary minus of this value.
    */
   public Value unaryMinus()
   {
      return new Int(-this.value);
   }

   /**
    * Compute an addition.
    * 
    * @param x another value.
    * @return the sum of the two values.
    */
   public final Value add(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).add(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final long sum = num.longValue() + this.longValue();
      // Check the integrity of the result
      if ((sum < -0x80000000L) || (sum > 0xffffffffL))
      {
         return new Long(sum);
      }
      else if (sum < 0x80000000L)
      {
         return new Int((int) sum);
      }
      else
      {
         // unsigned int range
         return new UnsignedInt((int) sum);
      }
   }

   /**
    * Compute a substraction.
    * 
    * @param x another value.
    * @return the difference between the two values.
    */
   public Value sub(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).sub(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final long dif = this.longValue() - num.longValue();
      // Check the integrity of the result
      if ((dif < -0x80000000L) || (dif > 0xffffffffL))
      {
         return new Long(dif);
      }
      else if (dif < 0x80000000L)
      {
         return new Int((int) dif);
      }
      else
      {
         // unsigned int range
         return new UnsignedInt((int) dif);
      }
   }

   /**
    * Compute a multiplication.
    * 
    * @param x another value.
    * @return the product of the two values.
    */
   public Value multiply(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).multiply(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final long prod = (this.longValue() * num.longValue());
      // Check the integrety of the result
      if ((prod < -0x80000000L) || (prod > 0xffffffffL))
      {
         return new Long(prod);
      }
      else if (prod < 0x80000000L)
      {
         return new Int((int) prod);
      }
      else
      {
         return new UnsignedInt((int) prod);
      }
   }

   /**
    * Compute a division.
    * 
    * @param x another value.
    * @return the ratio of the two values.
    */
   public final Value divide(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).divide(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final long div = (this.longValue() / num.longValue());
      // Check the integrety of the result
      if ((div < -0x80000000L) || (div > 0xffffffffL))
      {
         return new Long(div);
      }
      else if (div < 0x80000000L)
      {
         return new Int((int) div);
      }
      else
      {
         return new UnsignedInt((int) div);
      }
   }

   /**
    * Compute a modulus.
    * 
    * @param x another value.
    * @return the modulus of the values.
    */
   public Value modulus(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).modulus(x);
      }
      final Numeric num = (Numeric) x.convertTo(Value.NUMERIC_ID);
      final long mod = (this.longValue() % num.longValue());
      // Check the integrety of the result
      if ((mod < -0x80000000L) || (mod > 0xffffffffL))
      {
         return new Long(mod);
      }
      else if (mod < 0x80000000L)
      {
         return new Int((int) mod);
      }
      else
      {
         return new UnsignedInt((int) mod);
      }
   }

   // -------------------------------------------------------
   // Comparison interface implementation
   // -----------------------------------------------------
   /**
    * Compare this value with another value.
    * 
    * @param x another value.
    * @return The returned value is :
    *         <ul>
    *         <li>negative if this value is lower than another value</li>
    *         <li>zero if the two values are equal</li>
    *         <li>positive if this value is greater than another value</li>
    *         </ul>
    */
   public int compareTo(final Value x)
   {
      if (this.getPriority() >= x.getPriority())
      {
         final long cmp = (this.longValue() - ((Numeric) x).longValue());
         if (cmp < 0)
         {
            return -1;
         }
         else if (cmp > 0)
         {
            return 1;
         }
         else
         {
            return 0;
         }
      }
      return -((Comparison) x).compareTo(this);
   }

   // -----------------------------------------------
   // Logic interface implementation
   // ----------------------------------------------
   /**
    * Returns this value as a boolean
    * 
    * @return the numeric value represented by this object after conversion to
    *         type boolean.
    */
   public final boolean booleanValue()
   {
      return (this.value != 0);
   }

   // ---------------------------------------------------
   // Numeric interface implementation
   // ----------------------------------------------------
   /**
    * Returns this value as a byte (signed 8 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type byte.
    */
   public final byte byteValue()
   {
      return (byte) (this.value & 0xff);
   }

   /**
    * Returns this value as a short integer (signed 16 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type short.
    */
   public final short shortValue()
   {
      return (short) (this.value & 0xffff);
   }

   /**
    * Returns this value as an integer (signed 32 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type int.
    */
   public final int intValue()
   {
      return this.value;
   }

   /**
    * Returns this value as a long integer (signed 64 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type long.
    */
   public final long longValue()
   {
      return (this.value & 0xffffffffL);
   }

   /**
    * Returns this value as a float (signed 32 bits IEEE 754). The conversion
    * may result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type float.
    */
   public final float floatValue()
   {
      return this.longValue();
   }

   /**
    * Returns this value as a double (signed 64 bits IEEE 754). The conversion
    * may result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type double.
    */
   public final double doubleValue()
   {
      return this.longValue();
   }

   /**
    * Assign a boolean value.
    * 
    * @param value another value.
    */
   public final void assign(final boolean value)
   {
      this.value = (value ? 1 : 0);
   }

   /**
    * Assign a byte value.
    * 
    * @param value another value.
    */
   public final void assign(final byte value)
   {
      this.value = value & 0xff;
   }

   /**
    * Assign short value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final short value)
   {
      this.value = value & 0xffff;
   }

   /**
    * Assign an int value.
    * 
    * @param value another value.
    */
   public final void assign(final int value)
   {
      this.value = value;
   }

   /**
    * Assign a long value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final long value)
   {

      this.value = (int) (value & 0xffffffffL);
   }

   /**
    * Assign a float value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final float value)
   {
      this.value = (int) value;
   }

   /**
    * Assign a double value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final double value)
   {
      this.value = (int) value;
   }

   /**
    * main
    * 
    * @param args string[]
    */
   public static void main(final java.lang.String[] args)
   {
      System.out.println(java.lang.Long.toBinaryString(+0x80000000L));
      System.out.println(java.lang.Long.toBinaryString(-0x80000000L));
      UnsignedInt uint = new UnsignedInt(-1);
      System.out.println(uint + " / " + uint.byteValue());
      uint.assign(4123456789L);
      System.out.println(uint + " / " + uint.longValue());
      uint =
         new UnsignedInt(((Numeric) uint.sub(new Int(2000000000))).intValue());
      System.out.println(uint);
      uint.assign((short) -1);
      System.out.println("(short)-1 : " + uint);
      uint.assign((byte) -1);
      System.out.println("(byte)-1 : " + uint);
      System.out.println((long) java.lang.Integer.MAX_VALUE
            - (long) java.lang.Integer.MIN_VALUE);
   }
}
