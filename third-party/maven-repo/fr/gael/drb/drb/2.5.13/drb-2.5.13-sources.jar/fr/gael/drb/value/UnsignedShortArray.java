/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

/**
 * The UnsignedShortArray class is a generic wrapper for unsigned short array
 * values.
 */
public class UnsignedShortArray extends AbstractNumericArray implements
      ValueFormat
{
   // ===================================================
   // Attributes part.
   // ===================================================
   /**
    * PRIORITY
    */
   final static int PRIORITY = 2;

   /**
    * value
    */
   private short[] value;

   // ===================================================
   // Methods part.
   // ===================================================
   /**
    * Build an UnsignedShortArray value.
    * 
    * @param v a short array.
    */
   public UnsignedShortArray(final short[] v)
   {
      this.value = new short[v.length];
      System.arraycopy(v, 0, this.value, 0, v.length);
   }
   
   /**
    * Build an UnsignedShortArray value.
    * 
    * @param v a short array.
    */
   private UnsignedShortArray(final short[] v, boolean shallowCopy)
   {
      if (shallowCopy)
      {
          this.value = new short[v.length];
          System.arraycopy(v, 0, this.value, 0, v.length);
      }
      else
      {
         this.value = v;
      }
   }

   /**
    * Build a ShortArray value.
    * 
    * @param size The size
    */
   public UnsignedShortArray(final int size)
   {
      this.value = new short[size];
   }

   /**
    * Wrap the given array
    * @param v
    * @return
    */
   public static UnsignedShortArray wrap(final short[] v)
   {
      return new UnsignedShortArray(v, true);  
   }

   /**
    * Returns the underlying object for optimization.
    * @return the underlying short array.
    * @override
    */
   public final short[] getData()
   {
      return this.value;
   }

   /**
    * Returns this value as a short integer (signed 16 bits). The conversion may
    * result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type short.
    */
   public short[] shortValues()
   {
      final short[] v = new short[this.value.length];
      System.arraycopy(this.value, 0, v, 0, v.length);
      return v;
   }

   // ------------------------------------------------------------
   // ValueFormat interface implementation
   // -----------------------------------------------------------
   // see interface ValueFormat for more information.

   /**
    * Return a string containing the value with a fixed format.
    * 
    * @param length The expected length of the output string
    * @return The formatted string.
    */
   public java.lang.String getFormattedString(final int length)
   {
      java.lang.String str = "";
      for (int i = 0; i < this.length(); i++)
      {
         str = str + Short.getFormattedString(2, this.value[i], false);
      }
      return str;
   }

   /**
    * Return a byte buffer containing the value in a fixed format.
    * 
    * @return The formatted buffer.
    */
   public final byte[] getFormattedBuffer()
   {
      final byte[] buffer = new byte[2 * this.length()];
      for (int i = 0; i < this.length(); i++)
      {
         buffer[2 * i + 0] = (byte) (this.value[i] >> 8);
         buffer[2 * i + 1] = (byte) (this.value[i]);
      }
      return buffer;
   }

   // --------------------------------------------------
   // Value interface implementation
   // --------------------------------------------------

   /**
    * The type identifier of this BooleanArray value.
    * 
    * @return an identifier of the array type, namely ARRAY_ID
    */
   public final int getType()
   {
      return Value.ARRAY_ID;
   }

   /**
    * Returns the ShortArray priority The type must be ARRAY_ID or STRING_ID
    * otherwise a ClassCastException is thrown.
    * 
    * @return the ShortArray priority
    */
   public final int getPriority()
   {
      return this.PRIORITY;
   }

   /**
    * Convert the value into the specified type.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException exception
    */
   public final Value convertTo(final int type) throws ClassCastException
   {
      if (type == ARRAY_ID)
      {
         return this;
      }

      if (type == STRING_ID)
      {
         return new String(this.toString());
      }

      throw new ClassCastException();
   }

   /**
    * Assign a value. This value must be a NumericArray otherwise a
    * ClassCastException is thrown.
    * 
    * @param v the value to be assigned.
    * @throws ClassCastException exception
    */
   public final void assign(final Value v) throws ClassCastException
   {
      final NumericArray b = (NumericArray) v;
      this.value = new short[b.length()];
      for (int i = 0; i < this.length(); i++)
      {
         this.value[i] = b.shortValue(i);
      }
   }

   // ------------------------------------------------------------
   // ValueArray interface implementation
   // -------------------------------------------------------------
   // ValueArray convertToArray(int type)
   // {
   // throw new ClassCastException();
   // }

   /**
    * getArrayType
    * 
    * @return the type
    */
   public final int getArrayType()
   {
      return Value.UNSIGNED_SHORT_ID;
   }

   /**
    * get the element
    * 
    * @param index the index
    * @return the value
    */
   public final Value getElement(final int index)
   {
      return new UnsignedShort(this.value[index]);
   }

   /**
    * assign
    * 
    * @param index the index
    * @param element the element
    */
   public final void assign(final int index, Value element)
   {
      element = element.convertTo(Value.NUMERIC_ID);
      this.value[index] = ((Numeric) element).shortValue();
   }

   /**
    * Return the length
    * 
    * @return the length
    */
   public final int length()
   {
      return this.value.length;
   }

   // -----------------------------------------------------------
   // NumericArray interface implementation
   // -----------------------------------------------------------

   /**
    * booleanValue
    * 
    * @param index the index
    * @return true or false
    */
   public final boolean booleanValue(final int index)
   {
      return this.value[index] != 0;
   }

   /**
    * byteValue
    * 
    * @param index the index
    * @return the byte
    */
   public final byte byteValue(final int index)
   {
      return (byte) (this.value[index]);
   }

   /**
    * intValue
    * 
    * @param index the index
    * @return the int value
    */
   public final int intValue(final int index)
   {
      return (this.value[index] & 0xffff);
   }

   /**
    * longValue
    * 
    * @param index the index
    * @return the long value
    */
   public final long longValue(final int index)
   {
      return (this.value[index] & 0xffffL);
   }

   /**
    * shortValue
    * 
    * @param index the index
    * @return the short value
    */
   public final short shortValue(final int index)
   {
      return (this.value[index]);
   }

   /**
    * floatValue
    * 
    * @param index the index
    * @return the float value
    */
   public final float floatValue(final int index)
   {
      return (this.value[index] & 0xffff);
   }

   /**
    * doubleValue
    * 
    * @param index the index
    * @return the doublevalue
    */
   public final double doubleValue(final int index)
   {
      return (this.value[index] & 0xffff);
   }

   /**
    * assign
    * 
    * @param index the index
    * @param value the boolean value
    */
   public final void assign(final int index, final boolean value)
   {
      this.value[index] = (short) (value ? 1 : 0);
   }

   /**
    * assign
    * 
    * @param index the index
    * @param value the byte value
    */
   public final void assign(final int index, final byte value)
   {
      this.value[index] = value;
   }

   /**
    * assign
    * 
    * @param index the index
    * @param value the int value
    */
   public final void assign(final int index, final int value)
   {
      this.value[index] = (short) value;
   }

   /**
    * assign
    * 
    * @param index the index
    * @param value the short value
    */
   public final void assign(final int index, final short value)
   {
      this.value[index] = value;
   }

   /**
    * assign
    * 
    * @param index the index
    * @param value the long value
    */
   public final void assign(final int index, final long value)
   {
      this.value[index] = (short) value;
   }

   /**
    * assign
    * 
    * @param index the index
    * @param value the float value
    */
   public final void assign(final int index, final float value)
   {
      this.value[index] = (short) value;
   }

   /**
    * assign
    * 
    * @param index the index
    * @param value the double value
    */
   public final void assign(final int index, final double value)
   {
      this.value[index] = (short) value;
   }

   /**
    * toString
    * 
    * @return the string
    */
   public java.lang.String toString()
   {
      final StringBuffer strbuf = new StringBuffer(this.value.length * 3);
      for (int i = 0; i < this.value.length; i++)
      {
         if (i != 0)
         {
            strbuf.append(" ");
         }
         strbuf.append(this.value[i] & 0xffff);
      }
      return strbuf.toString();
   }

   /**
    * mian
    * 
    * @param args string[]
    */
   public static void main(final java.lang.String[] args)
   {
      final UnsignedShortArray array =
         new UnsignedShortArray(new short[] { -1, -1, -1 });
      System.out.println(array.toString());
   }
}
