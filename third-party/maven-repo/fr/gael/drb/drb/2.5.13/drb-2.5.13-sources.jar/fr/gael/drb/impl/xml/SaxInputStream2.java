/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.xml;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * SAX input stream.
 */
class SaxInputStream2 extends InputStream
{
   /**
    * The offset of each line.
    */
   ArrayList lineOffset = new ArrayList();

   /**
    * The encapsulated input stream.
    */
   InputStream input;

   /**
    * The start offset of the hole.
    */
   Long startHole;

   /**
    * The stop offset of the hole.
    */
   Long stopHole;

   /**
    * The absolute offset
    */
   long offset = 0;

   /**
    * The SAX node.
    */
   SaxNode node;

   /**
    * Builds a SaxInputStream.
    * 
    * @param input the raw input stream.
    * @param node the SAX node
    */
   SaxInputStream2(final InputStream input, final SaxNode node)
   {
      this.input = input;
      this.node = node;
      this.startHole = Long.MAX_VALUE;
      this.stopHole = Long.MAX_VALUE;
      this.offset = 0L;
      this.update();
      if (this.stopHole != Long.MAX_VALUE)
      {
         this.lineOffset.add(new Long(this.stopHole));
      }
      else
      {
         this.lineOffset.add(new Integer(0));
      }
   }

   /**
    * Returns the offset of the specified line.
    * 
    * @param line_number the line number.
    * @param column_number the column number.
    * @return the offset of the specified line.
    */
   public long getOffset(final int line_number, final int column_number)
   {
      if ((line_number < 1) || (line_number > this.lineOffset.size()))
      {
         return -1;
      }
      return ((Number) this.lineOffset.get(line_number - 1)).longValue()
            + column_number - 1;
   }

   /**
    * Update the hole boundaries.
    */
   private void update()
   {
      if (this.node.depth > 0)
      {
         if (this.startHole == Long.MAX_VALUE)
         {
            this.startHole = 0L;
            this.stopHole = this.node.tag.startOffset;
            // System.err.println("SAXStream: BEFORE offset=" + offset +
            // ", node=" + node.getName() +
            // ", startHole=" + startHole + ", stopHole=" + stopHole);
         }
         else
         {
            this.startHole = this.node.tag.endOffset;
            this.stopHole = Long.MAX_VALUE;
            // System.err.println("SAXStream: AFTER offset=" + offset +
            // ", node=" + node.getName() +
            // " startHole=" + startHole + ", stopHole=" + stopHole);
         }
      }
   }

   /**
    * Reads the next byte of data from the input stream.
    * 
    * @return he next byte of data, or -1 if the end of the stream is reached.
    * @throws IOException if an I/O error occurs.
    */
   public int read() throws IOException
   {
      if (this.offset == this.startHole)
      {
         if (this.stopHole == Long.MAX_VALUE)
         {
            return -1;
         }
         final long size = this.stopHole - this.startHole;
         this.input.skip(size);
         this.update();
         this.offset += size;
         return this.read();
      }
      final int ch = this.input.read();
      if (ch == '\n')
      {
         this.lineOffset.add(new Long(this.offset + 1));
      }
      if (ch != -1)
      {
         this.offset = this.offset + 1;
      }
      return ch;
   }

   /**
    * Reads some number of bytes from the input stream and stores them into the
    * buffer array b.
    * 
    * @param b the buffer into which the data is read.
    * @return the total number of bytes read into the buffer, or -1 is there is
    *         no more data because the end of the stream has been reached.
    * @throws IOException if an I/O error occurs.
    */
   public int read(final byte[] b) throws IOException
   {
      return this.read(b, 0, b.length);
   }

   /**
    * Reads up to len bytes of data from the input stream into an array of
    * bytes. An attempt is made to read as many as len bytes, but a smaller
    * number may be read, possibly zero. The number of bytes actually read* is
    * returned as an integer.
    * 
    * @param b the buffer into which the data is read.
    * @param off the start offset in array b at which the data is written.
    * @param len the maximum number of bytes to read.
    * @return the total number of bytes read into the buffer, or -1 is there is
    *         no more data because the end of the stream has been reached.
    * @throws IOException if an I/O error occurs.
    */
   public int read(final byte[] b, final int off, final int len)
         throws IOException
   {
      if (this.offset == this.startHole)
      {
         if (this.stopHole == Long.MAX_VALUE)
         {
            return -1;
         }
         final long size = this.stopHole - this.startHole;
         this.input.skip(size);
         this.update();
         this.offset += size;
         return this.read(b, off, len);
      }
      if (this.offset >= this.stopHole)
      {
         final int lenRead = this.input.read(b, off, len);
         if (lenRead == -1)
         {
            return -1;
         }
         for (int i = 0; i < lenRead; i++)
         {
            if (b[off + i] == '\n')
            {
               this.lineOffset.add(new Long(this.offset + i + 1));
            }
         }
         this.offset = this.offset + lenRead;
         return lenRead;
      }
      if (this.offset < this.startHole)
      {
         final long left = this.startHole - this.offset;
         if (len <= left)
         {
            final int lenRead = this.input.read(b, off, len);
            if (lenRead == -1)
            {
               return -1;
            }
            for (int i = 0; i < lenRead; i++)
            {
               if (b[off + i] == '\n')
               {
                  this.lineOffset.add(new Long(this.offset + i + 1));
               }
            }
            this.offset = this.offset + lenRead;
            return lenRead;
         }
         final int len1 = this.input.read(b, off, (int) left);
         if (len1 == -1)
         {
            return -1;
         }
         for (int i = 0; i < len1; i++)
         {
            if (b[off + i] == '\n')
            {
               this.lineOffset.add(new Long(this.offset + i + 1));
            }
         }
         this.offset = this.offset + len1;
         if (this.stopHole == Long.MAX_VALUE)
         {
            return len1;
         }
         final long size = this.stopHole - this.startHole;
         this.input.skip(size);
         this.update();
         this.offset += size;
         final int len2 = this.read(b, off + len1, len - len1);
         if (len2 == -1)
         {
            return len1;
         }
         return len1 + len2;
      }
      return -1;
   }

   /**
    * Returns the number of bytes that can be read (or skipped over) from this
    * input stream without blocking by the next caller of a method for this
    * input stream. The next caller might be the same thread or or another
    * thread.
    * 
    * @return the number of bytes that can be read from this input stream
    *         without blocking.
    * @throws IOException if an I/O error occurs.
    */
   public int available() throws IOException
   {
      if (this.offset == this.startHole)
      {
         if (this.stopHole == Long.MAX_VALUE)
         {
            return 0;
         }
         final long size = this.stopHole - this.startHole;
         this.input.skip(size);
         this.offset += size;
         this.update();
         // TODO: warning
         return this.available();
      }
      if (this.offset >= this.stopHole)
      {
         return this.input.available();
      }
      if (this.offset < this.startHole)
      {
         final int left = this.input.available();
         if (left < this.startHole - this.offset)
         {
            return left;
         }
         return (int) (this.startHole - this.offset);
      }
      return 0;
   }

   /**
    * Closes this input stream and releases any system resources associated with
    * the stream.
    * 
    * @throws IOException if an I/O error occurs.
    */
   public void close() throws IOException
   {
      this.input.close();
   }

   /**
    * Marks the current position in this input stream.
    * 
    * @param readlimit the maximum limit of bytes that can be read before the
    *           mark position becomes invalid.
    */
   public void mark(final int readlimit)
   {
   }

   /**
    * Repositions this stream to the position at the time the mark method was
    * last called on this input stream.
    * 
    * @throws IOException if an I/O error occurs.
    */
   public void reset() throws IOException
   {
      throw new IOException("Mark not supported");
   }

   /**
    * Tests if this input stream supports the mark and reset methods.
    * 
    * @return true if this stream instance supports the mark and reset methods;
    *         false otherwise.
    */
   public boolean markSupported()
   {
      return false;
   }

}
