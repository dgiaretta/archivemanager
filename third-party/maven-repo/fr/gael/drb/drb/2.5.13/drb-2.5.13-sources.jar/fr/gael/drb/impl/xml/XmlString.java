/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.xml;

import java.util.HashMap;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Process character conversion on string. Convert character reference in a xml
 * style into unicode character and vice versa.
 */
public class XmlString
{

   // Map of predefined entities reference
   static HashMap predefined_entities_decode;
   static HashMap predefined_entities_encode;
   static
   {

      predefined_entities_decode = new HashMap();
      predefined_entities_decode.put("&gt;", ">");
      predefined_entities_decode.put("&lt;", "<");
      predefined_entities_decode.put("&amp;", "&");
      predefined_entities_decode.put("&quot;", "\"");
      predefined_entities_decode.put("&apos;", "'");
      // predefined_entities_decode.put("\"\"", "\"");

      predefined_entities_encode = new HashMap();
      predefined_entities_encode.put(">", "&gt;");
      predefined_entities_encode.put("<", "&lt;");
      predefined_entities_encode.put("&", "&amp;");
      predefined_entities_encode.put("\"", "&quot;");
      predefined_entities_encode.put("'", "&apos;");
   }

   /**
    * Decode character references or predefined entity reference found inside
    * the input string into unicode character
    * 
    * @param input The input string to process
    * @return The string with only unicode character inside
    */
   public static String decode(final String input)
   {

      // processing the predefined references
      final String output1 = decodePredefinedRef(input);
      // processing the character references
      final String output2 = decodeCharRef(output1);

      return output2;

   }

   /**
    * Format an XML string. All specific characters will be despecialized by
    * adding the specified notation.
    * 
    * @param str the string to format
    * @return a string suitable for XML queries.
    */
   public static String encode(final String str)
   {
      if (str == null)
      {
         return null;
      }

      final char[] str_array = str.toCharArray();

      String xml_str = "";
      for (int index = 0; index < str_array.length; index++)
      {

         if ((str_array[index] == '&'))
         {
            xml_str = xml_str + "&amp;";
         }
         else if ((str_array[index] == '"'))
         {
            xml_str = xml_str + "&quot;";
         }
         else if ((str_array[index] == '\''))
         {
            xml_str = xml_str + "&apos;";
         }
         else if ((str_array[index] == '<'))
         {
            xml_str = xml_str + "&lt;";
         }
         else if ((str_array[index] == '>'))
         {
            xml_str = xml_str + "&gt;";
         }
         else if ((str_array[index] == '\n'))
         {
            xml_str = xml_str + "&#10;";
         }
         else
         {
            xml_str = xml_str + String.valueOf(str_array[index]);
         }

      }

      return xml_str;
   }

   private static String decodePredefinedRef(final String input)
   {
      // the string processed
      String output = input;

      // Creation of pattern for predefined entities ref
      String regexp = "";
      for (final Iterator it = predefined_entities_decode.keySet().iterator(); it
            .hasNext();)
      {
         regexp += (String) it.next();
         if (it.hasNext())
         {
            regexp += "|";
         }
      }

      // creation of pattern
      final Pattern pattern = Pattern.compile(regexp);
      final Matcher matcher = pattern.matcher(input);

      // replacement of pattern
      while (matcher.find())
      {
         final String group = matcher.group();
         output =
            matcher
                  .replaceFirst((String) predefined_entities_decode.get(group));
         matcher.reset(output);
      }

      return output;
   }

   private static String decodeCharRef(final String input)
   {

      // the string processed
      String output = input;

      // Creation of pattern for predefined entities ref
      final String regexp = "(&#[0-9]+;)|(&#x[0-9a-fA-F]+;)";

      // creation of pattern
      final Pattern pattern = Pattern.compile(regexp);
      final Matcher matcher = pattern.matcher(input);

      // replacement of pattern
      while (matcher.find())
      {
         final String group = matcher.group();
         char replacement;

         // distinguishing btw hex and decimal character
         if (group.indexOf('x') == -1)
         {
            final String part =
               group.substring(group.indexOf('#') + 1, group.length() - 1);
            replacement = (char) Integer.parseInt(part, 10);
         }
         else
         {
            final String part =
               group.substring(group.indexOf('x') + 1, group.length() - 1);
            replacement = (char) Integer.parseInt(part, 16);
         }

         output = matcher.replaceFirst(new String(new char[] { replacement }));
         matcher.reset(output);
      }

      return output;
   }
}
