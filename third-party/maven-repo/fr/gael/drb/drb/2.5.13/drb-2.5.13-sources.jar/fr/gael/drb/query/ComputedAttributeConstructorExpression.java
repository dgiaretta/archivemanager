/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.value.Value;
import fr.gael.drb.value.ValueArray;
import fr.gael.drb.xsd.Namespace;

/**
 * Wraps a computed attribute constructor expression of XQuery language.
 */
class ComputedAttributeConstructorExpression extends AbstractExpression
{

   /**
    * Logger.
    */
   static private Logger logger =
      Logger.getLogger(ComputedAttributeConstructorExpression.class);

   private QName name;

   private Expression name_expression;

   private Expression content_expression;

   /**
    * Builds an Computed attribute constructor expression.
    * 
    * @param token the token related to the current expression.
    * @param name string form of the element qualified name.
    */
   public ComputedAttributeConstructorExpression(final Token token,
         final String name)
   {
      super("Computed Attribute constructor", token);
      this.name = new QName(name);
      this.name_expression = null;
   }

   /**
    * Builds an Computed attribute constructor expression.
    * 
    * @param token the token related to the current expression.
    * @param name_expression expression whose evaluation gives the element
    *           qualified name.
    */
   public ComputedAttributeConstructorExpression(final Token token,
         final Expression name_expression)
   {
      super("Computed Attribute constructor", token);
      this.name_expression = name_expression;
      this.name = null;

   }

   /**
    * Set the expression content of the attribute being constructed
    * 
    * @param expression The content expression. Can be null
    */
   public void setContentExpression(final Expression expression)
   {
      this.content_expression = expression;
   }

   /**
    * Evaluates the computed attribute contructor expression.
    * 
    * @param outer_context the dynamic evaluation context to consider.
    * @return the evaluated sequence.
    */
   public DrbSequence evaluate(final DynamicContext outer_context)
   {

      /**
       * Create an inner context.
       */
      final DynamicContext context = new DynamicContext(outer_context);

      DrbDefaultAttribute attribute = null;

      /**
       * Evaluation if required of the qname.
       */

      final QName name = this.processAttributeName(context);

      /**
       * Creating the output node
       */
      attribute = new DrbDefaultAttribute(name.getLocalName(), null);

      /**
       * Check the prefix has been bound to an URI, if any.
       */
      this.setAttributeURI(context, attribute, name);

      /**
       * If the main expression is not null, evaluation of it
       */
      if (this.content_expression == null)
      {
         return new DrbDefaultSequence(attribute);
      }
      else
      {
         this.processContentExpression(context, this.content_expression,
               attribute);
      }

      return new DrbDefaultSequence(attribute);
   }

   /**
    * Check the prefix has been bound to an URI, if any. Check also if its not a
    * namespace declaration attribute. If any, set this namespaceURI to this
    * attribute.
    * 
    * @param context The dynamic context of evaluation
    * @param attribute The attribute being constructed
    * @param name The name of the attribute (may be provided by a name
    *           expression)
    */
   private void setAttributeURI(final DynamicContext context,
         final DrbDefaultAttribute attribute, final QName name)
   {

      final Namespace namespace = context.getNamespace();

      if (name.getPrefix() == null)
      {
         // xmlns="..." not allowed
         if (name.getLocalName().equals(
               fr.gael.drb.impl.xml.XmlNode.XMLNS_PREFIX))
         {
            throw new DynamicException(
                  this,
                  "XQDY0044 - The local name \"xmlns"
                        + "\" to declare a default namespace is not allowed for a "
                        + "computed attribute constructor.");
         }

         attribute.setNamespaceURI(null);
      }

      else if (name.getPrefix() != null)
      {
         // xmlns:foo="..." not allowed
         if (name.getPrefix().equals(fr.gael.drb.impl.xml.XmlNode.XMLNS_PREFIX))
         {
            throw new DynamicException(this, "XQDY0044 - The prefix \"xmlns"
                  + "\" is not allowed for a "
                  + "computed attribute constructor.");
         }

         final String nURI = namespace.resolveNamespace(name.getPrefix());
         if (nURI == null)
         {
            throw new DynamicException(this, "XQDY0074 - The prefix \""
                  + name.getPrefix() + "\" has not been bound.");
         }
         else
         {
            if (nURI.equals(fr.gael.drb.impl.xml.XmlNode.XMLNS_NAMESPACE))
            {
               throw new DynamicException(this,
                     "XQDY0044 - The namespace linked "
                           + " to the xmlns prefix is not allowed inside \""
                           + "computed attribute constructor.");
            }

            attribute.setNamespaceURI(nURI);
         }
      }
   }

   /**
    * If the name has been provided as an expression, this method evaluate it
    * and set the result value as the name of the node
    * 
    * @param context The dynamic context of evaluation
    * @return The QName being evaluated
    */
   private QName processAttributeName(final DynamicContext context)
   {

      if (this.name != null)
      {
         return this.name;
      }

      if (this.name_expression == null)
      {
         throw new DynamicException(this,
               "The name or the name expression of the element constructor "
                     + "cannot be null");
      }

      final DrbSequence sequence = this.name_expression.evaluate(context);

      if (sequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the name expression");
      }

      final ValueArray array = sequence.atomize();

      if (array.length() != 1)
      {
         throw new TypeException(this,
               "XPTY0004 - The sequence length of the name expression must be one");
      }

      final Value value = array.getElement(0);

      if (!(value instanceof fr.gael.drb.value.String))
      {
         throw new TypeException(
               this,
               "XPTY0004 - Result of the evaluation of the name expression"
                     + " must be a singleton containing either a String or a QName");
      }

      return new QName(value.toString());

   }

   /**
    * Evaluate the content expression of the attribute
    * 
    * @param context The dynamic Context for evaluation
    * @param content_expression The content expression to be evaluated
    * @param attribute The attribute whose content is being evaluated
    */
   private void processContentExpression(final DynamicContext context,
         final Expression content_expression,
         final DrbDefaultAttribute attribute)
   {

      DrbSequence sequence = content_expression.evaluate(context);

      if (sequence != null)
      {
         sequence = sequence.atomize();
      }

      if (sequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating content-expression for attribut "
                     + attribute.getName());
      }

      /**
       * Processes the attribute value.
       */
      boolean value_initialized = false;
      boolean concatenation_performed = false;
      String attribute_string = "";

      for (int iitem = 0; iitem < sequence.getLength(); iitem++)
      {
         /**
          * Extract current value.
          */
         final DrbItem item = sequence.getItem(iitem);

         if (item == null)
         {
            throw new DynamicException(this,
                  "Null item resulting from evaluation of attribute "
                        + attribute.getName());
         }

         final Value attribute_value = (Value) item;

         if (attribute_value == null)
         {
            throw new DynamicException(this,
                  "Null value resulting from evaluation of attribute "
                        + attribute.getName());
         }

         /**
          * If the attribute value has not already been assigned, do it with the
          * current item. This operation intends to keep the value type of the
          * current expression as far as it is the unique non_null item of the
          * attribute sequence. It does not conform the W3C specification but
          * cope the DRB policy.
          */
         if (value_initialized == false)
         {
            attribute.setValue(attribute_value);
            value_initialized = true;
         }

         /**
          * Concatenate the current value to the output attribute value.
          */
         else
         {
            try
            {
               if (concatenation_performed == false)
               {
                  attribute_string =
                     ((fr.gael.drb.value.String) attribute.getValue()
                           .convertTo(Value.STRING_ID)).toString();
               }

               if (iitem >= 1)
               {
                  attribute_string += " ";
               }

               attribute_string +=
                  ((fr.gael.drb.value.String) attribute_value
                        .convertTo(Value.STRING_ID)).toString();

            }
            catch (final ClassCastException e)
            {
               throw new DynamicException(this,
                     "XQ0052 - Unable to cast item #" + (iitem + 1)
                           + " to string (attribute " + attribute.getName()
                           + ")");
            }

            concatenation_performed = true;
         }
      }

      /**
       * Set the output value of the attribute.
       */
      if (!((value_initialized == true) && (concatenation_performed == false)))
      {
         attribute.setValue(new fr.gael.drb.value.String(attribute_string));
      }

   }

}
