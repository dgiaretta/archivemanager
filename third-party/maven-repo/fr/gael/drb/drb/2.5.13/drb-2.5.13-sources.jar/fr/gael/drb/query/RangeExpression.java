/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbSequence;
import fr.gael.drb.value.Integer;
import fr.gael.drb.value.Numeric;
import fr.gael.drb.value.Value;
import fr.gael.drb.value.ValueArray;

/**
 * Wraps a Range expression of XQuery language. e.g. in "/mds/mdsr[ 123 to $b
 * ]", "123 to $b" is a range expression.
 */
class RangeExpression extends AbstractExpression
{
   /**
    * Logger
    */
   static private Logger logger = Logger.getLogger(RangeExpression.class);

   /**
    * Expression of the minimum value.
    */
   private Expression minimum;

   /**
    * Indicator of constant minimal value of the range.
    */
   private boolean constantMinimum = false;

   /**
    * Constant value of the minimum if constantMinimum = true.
    */
   private long minimumValue;

   /**
    * Expression of the maximum value.
    */
   private Expression maximum;

   /**
    * Indicator of constant maximal value of the range.
    */
   private boolean constantMaximum = false;

   /**
    * Constant value of the maximum if constantMinimum = true.
    */
   private long maximumValue;

   /**
    * Builds a range expression. In the specific case of range minimum or
    * maximum expressed as literal, the integer value is extracted.
    * 
    * @param token the token related to the current range expression.
    * @param minimum the expression wrapping the minimum of the range.
    * @param maximum the expression wrapping the maximum of the range.
    */
   public RangeExpression(final Token token, final Expression minimum,
         final Expression maximum)
   {
      super("Range", token);

      /**
       * Minimum value and optimizers.
       */
      this.minimum = minimum;

      if (minimum instanceof LiteralExpression)
      {
         try
         {
            final Value minimumValue =
               ((LiteralExpression) minimum).getValue().convertTo(
                     Value.NUMERIC_ID);
            this.minimumValue = ((Numeric) minimumValue).longValue();

            this.constantMinimum = true;
         }
         catch (final ClassCastException e)
         {
            this.logger
                  .warn("Cannot extract range minimum value from literal \""
                        + minimum + "\": skipped.");
         }
      }

      /**
       * Maximum value and optimizers.
       */
      this.maximum = maximum;

      if (maximum instanceof LiteralExpression)
      {
         Value maximum_value = ((LiteralExpression) maximum).getValue();

         try
         {
            maximum_value = maximum_value.convertTo(Value.INTEGER_ID);

            this.maximumValue = ((Integer) maximum_value).intValue();

            this.constantMaximum = true;
         }
         catch (final ClassCastException e)
         {
            this.logger
                  .warn("Cannot extract range maximum value from literal \""
                        + maximum + "\": skipped.");
         }
      }
   }

   /**
    * A range expression is constant if its bounds are not context-dependent.
    * The result sequence will be the same for each evaluation.
    * 
    * @return true if this expression is constant
    */
   public boolean isConstant()
   {
      return (this.minimum.isConstant()) && (this.maximum.isConstant());
   }

   /**
    * Constant minimum indicator.
    * 
    * @return true if the minimum is constant and false otherwise.
    */
   public boolean isMinimumConstant()
   {
      return this.constantMinimum;
   }

   /**
    * Returns the minimum. Warning: the returned value shall be considered only
    * if the isMinimumConstant() returns true. Otherwise, the default value is
    * -1 that is obviously not applicable.
    * 
    * @return the minimum value or -1 if undefined.
    */
   public long getMinimumValue()
   {
      return this.minimumValue;
   }

   /**
    * Constant maximum indicator.
    * 
    * @return true if the maximum is constant and false otherwise.
    */
   public boolean isMaximumConstant()
   {
      return this.constantMaximum;
   }

   /**
    * Returns the maximum. Warning: the returned value shall be considered only
    * if the isMaximumConstant() returns true. Otherwise, the default value is
    * -1 that is obviously not applicable.
    * 
    * @return the maximum value or -1 if undefined.
    */
   public long getMaximumValue()
   {
      return this.maximumValue;
   }

   /**
    * Evaluate the minimum of the range position
    * 
    * @param context the outer-focus of the evaluation
    * @return The minimum value of the range position
    */
   public Long getMinimumValue(final DynamicContext context)
   {
      /**
       * Evaluate the minimum range extent.
       */
      final DrbSequence minSequence = this.minimum.evaluate(context);

      if (minSequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the minimim expression of the range");
      }

      final ValueArray minArray = minSequence.atomize();

      /**
       * Case of empty sequence.
       */
      if (minArray.length() == 0)
      {
         return Long.MAX_VALUE;
      }
      else
      /**
       * Error case: the min bound SHALL be a singleton castable to xs:integer
       */
      if (minArray.length() != 1)
      {
         throw new DynamicException(this,
               "The minimum of the range shall match a single xs:integer");
      }

      try
      {
         final Numeric minValue =
            (Numeric) minArray.getElement(0).convertTo(Value.NUMERIC_ID);
         return minValue.longValue();
      }
      catch (final ClassCastException e)
      {
         throw new TypeException(this,
               "The minimum of the range has not an xs:integer type");
      }
   }

   /**
    * Evaluate the maximum of the range position
    * 
    * @param context the outer-focus of the evaluation
    * @return The maximum value of the range position
    */
   public Long getMaximumValue(final DynamicContext context)
   {
      /**
       * Evaluate the maximum range extent.
       */
      final DrbSequence maxSequence = this.maximum.evaluate(context);

      if (maxSequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the maximum expression of the range");
      }

      final ValueArray maxArray = maxSequence.atomize();

      /**
       * Case of empty sequence.
       */
      if (maxArray.length() == 0)
      {
         return Long.MIN_VALUE;
      }
      else
      /**
       * Error case: the max bound SHALL be a singleton castable to xs:integer
       */
      if (maxArray.length() > 1)
      {
         throw new DynamicException(this,
               "The maximum of the range shall match a single xs:integer");
      }

      try
      {
         final Numeric maxValue =
            (Numeric) maxArray.getElement(0).convertTo(Value.NUMERIC_ID);
         return maxValue.longValue();
      }
      catch (final ClassCastException e)
      {
         throw new TypeException(this,
               "The maximum of the range has not an xs:integer type");
      }
   }

   /**
    * Returns a string describing the range.
    * 
    * @return the description of the range.
    */
   public String toString()
   {
      return this.minimum + " to " + this.maximum;
   } // toString()

   /**
    * Evaluate the range expression. The principle is return a Range sequence
    * (i.e. inner class of the present one) that evaluate a sequence, creating
    * the items on demand.
    * 
    * @param context the outer-focus of the evaluation.
    * @return the sequence resulting from the dynamic evaluation.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {
      /**
       * Evaluate the minimum range extent.
       */
      this.minimumValue = this.getMinimumValue(context);

      /**
       * Evaluate the maximum range extent.
       */
      this.maximumValue = this.getMaximumValue(context);

      return new RangeResult(this.minimumValue, this.maximumValue);
   } // evaluate()
}
