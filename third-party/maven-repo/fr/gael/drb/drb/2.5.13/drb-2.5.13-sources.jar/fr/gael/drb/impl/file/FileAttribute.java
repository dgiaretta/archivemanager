/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.file;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAbstractAttribute;
import fr.gael.drb.DrbNode;
import fr.gael.drb.value.DateTime;
import fr.gael.drb.value.Long;
import fr.gael.drb.value.Value;

/**
 * File or Directory attributes of a local file system.
 */
class FileAttribute extends DrbAbstractAttribute
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(FileAttribute.class);

   /**
    * The name of this attribute.
    */
   String name;

   /**
    * The owner file.
    */
   protected FileNode owner;

   /**
    * Builds a getInstance from a base attribute. TODO : this operation shall
    * raise an exception in case of null parameter.
    * 
    * @param name The name of the file attribute.
    * @param owner The owner of this attribute
    */
   protected FileAttribute(final String name, final FileNode owner)
   {
      this.name = name;
      this.owner = owner;
   }

   /**
    * Name of the attribute. Returns the name of the attribute. This name does
    * not contain any prefix, path nor any other location or identification
    * part. This name clearly identfies the attibute in the set of attribute of
    * the same node. This name is unique is this set. The attribute name is
    * never an empty string and always exists.
    * 
    * @return The name of the attribute.
    */
   public String getName()
   {
      return this.name;
   }

   /**
    * Changes the name of the attribute. This method always throw an
    * UnsupportedOperationException.
    * 
    * @param name Reference to the new name.
    * @throws UnsupportedOperationException This exception always raised because
    *            the name property is not defined for values.
    * @throws NullPointerException This exception is overriden by an
    *            UnsupportedOperationException.
    */
   public void rename(final java.lang.String name) throws NullPointerException,
         UnsupportedOperationException
   {
      throw new UnsupportedOperationException("Cannot rename a file attribute");
   }

   /**
    * The node the owning the current attribute. Returns a reference to the node
    * to which belongs this attribute. Because the attribute may have just been
    * created it may have no owner. This operation is similar to a getParent().
    * 
    * @return The owner of the attribute.
    */
   public DrbNode getOwner()
   {
      return this.owner;
   }

   /**
    * The value type of the attribute. All node have a value according to the
    * fr.gael.drb.value package. This operation returns the type identifier of
    * the content of the current attribute. The value of the attribute depends
    * on the implementation as well as on the attribute itself. This operation
    * never returns a fr.gael.drb.value.Value.NULL_ID identifier.
    * 
    * @return The type of the attribute.
    */
   public int getValueType()
   {
      if (this.name.equals("size"))
      {
         return Value.LONG_ID;
      }

      if (this.name.equals("modified"))
      {
         return Value.DATE_ID;
      }

      if (this.name.equals("readable"))
      {
         return Value.BOOLEAN_ID;
      }

      if (this.name.equals("writable"))
      {
         return Value.BOOLEAN_ID;
      }

      if (this.name.equals("hidden"))
      {
         return Value.BOOLEAN_ID;
      }

      if (this.name.equals("directory"))
      {
         return Value.BOOLEAN_ID;
      }

      return Value.NULL_ID;
   }

   /**
    * The namespace of the file attribute. File attributes have no namespace.
    * This method always returns null.
    * 
    * @return null.
    */
   public String getNamespaceURI()
   {
      return null;
   }

   /**
    * Sets a namespace resource identifier. This method always throw an
    * UnsupportedOperationException.
    * 
    * @param namespace_uri A reference to the new namespace identifier.
    * @throws UnsupportedOperationException This exception always raised because
    *            the name property is not defined for values.
    * @throws NullPointerException This exception is overriden by an
    *            UnsupportedOperationException.
    */
   public void setNamespaceURI(final java.lang.String namespace_uri)
         throws NullPointerException, UnsupportedOperationException
   {
      if (namespace_uri != null)
      {
         throw new UnsupportedOperationException(
               "Cannot rename a file attribute");
      }
   }

   /**
    * The value of the attribute. The value is expressed accoring to one of the
    * types supported by the fr.gael.drb.value package. Generally these types
    * correspond to primitive types (e.g. integer, floatting points, etc.) or
    * very low level types (e.g. string, date, etc.). On the contrary to DOM
    * implementation all the types are allowed even the arrays, date etc.
    * 
    * @return The value of the attribute.
    */
   public Value getValue()
   {
      if (this.name.equals("size"))
      {
         return new Long(this.owner.file.length());
      }

      if (this.name.equals("modified"))
      {
         return new DateTime(this.owner.file.lastModified());
      }

      if (this.name.equals("readable"))
      {
         return new fr.gael.drb.value.Boolean(this.owner.file.canRead());
      }

      if (this.name.equals("writable"))
      {
         return new fr.gael.drb.value.Boolean(this.owner.file.canWrite());
      }

      if (this.name.equals("hidden"))
      {
         return new fr.gael.drb.value.Boolean(this.owner.file.isHidden());
      }

      if (this.name.equals("directory"))
      {
         return new fr.gael.drb.value.Boolean(this.owner.file.isDirectory());
      }

      return null;
   }

   /**
    * The attribute was explicitly given a value. This operation returns true
    * since file attributes are specified.
    * 
    * @return always returns true.
    */
   public boolean isSpecified()
   {
      return true;
   }

   /**
    * Changes the value of the item. This operation sets a new value of the
    * current item.The value type of the item shall be compatible with the item
    * implementation. If the type does not match exactly it is casted to a
    * compatible one based on the the fr.gael.drb.value capabilities. A
    * reference to the effectivelly assigned value is returned by the operation
    * so it is possible to check if a cast has been performed and therefore
    * assess the accuracy of the assignement. If the cast is not possible the
    * operation raises an UnsupportedOperationException. If the assignment is
    * possible and the item implementation has a physical representation the
    * value is updated in the physical source in order to persist among
    * sessions. It therefore possible that this operation consumses an variable
    * time.
    * 
    * @param value The new value of the node. This value shall not be null.
    * @return The effectivelly assigned value. The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested assignment for
    *            any reason.
    */
   public Value setValue(final Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      if (this.name.equals("modified"))
      {
         final DateTime last_modified =
            (DateTime) value.convertTo(Value.DATE_ID);
         if (this.owner.file.setLastModified(last_modified.getTime()))
         {
            return new DateTime(this.owner.file.lastModified());
         }
         throw new UnsupportedOperationException(
               "Cannot change the last modified time.");
      }
      throw new UnsupportedOperationException("Cannot change the '" + this.name
            + "' attribute.");
   }
}
