/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * The Integer class is a generic wrapper for decimal values.
 */
public class Integer extends AbstractNumeric
{

   // ============================================
   // Attributes part.
   // ============================================
   /**
    * The Integer priority.
    */
   public final static int PRIORITY = 5;

   /**
    * The Integer value.
    */
   protected BigInteger value;

   // ==========================================
   // Methods part.
   // ==========================================
   /**
    * Constructs a Integer object initialized to the specified integer value.
    * 
    * @param val the value of the Integer.
    */
   public Integer(java.lang.String val)
   {
      if (val.startsWith("+"))
      {
         val = val.substring(1);
      }
      this.value = new BigInteger(val);
   }

   /**
    * Constructs a Integer object initialized to the specified integer buffer.
    * 
    * @param val big-endian two's-complement binary representation of BigInteger
    */
   public Integer(final byte[] val)
   {
      this.value = new BigInteger(val);
   }

   /**
    * Constructs a Integer object initialized to the specified long value.
    * 
    * @param val the value of the Integer.
    */
   public Integer(final long val)
   {
      this.value = BigInteger.valueOf(val);
   }

   /**
    * Constructs a Integer object initialized to the specified int value.
    * 
    * @param val the value of the Integer.
    */
   public Integer(final int val)
   {
      this.value = BigInteger.valueOf(val);
   }

   /**
    * Constructs a Integer object initialized to the specified decimal value.
    * 
    * @param val the value of the Integer.
    */
   public Integer(final BigInteger val)
   {
      this.value = val;
   }

   /**
    * Returns a new String object representing this Integer.
    * 
    * @return a string representation of the object.
    */
   public java.lang.String toString()
   {
      return this.value.toString();
   }

   // -----------------------------------------------
   // Value interface implementation
   // -----------------------------------------------
   /**
    * The type identifier of this Integer value.
    * 
    * @return an identifier of the Integer type.
    */
   public int getType()
   {
      return INTEGER_ID;
   }

   /**
    * Returns the Integer priority
    * 
    * @return the Integer priority
    */
   public final int getPriority()
   {
      return PRIORITY;
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself is returned. If the conversion is not allowed a
    * ClassCastException is thrown. The type must be a number (BOOLEAN_ID to
    * DOUBLE_ID) or an array.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException an exception
    */
   public Value convertTo(final int type) throws ClassCastException
   {
      switch (type)
      {
         // Integer -> Integer conversion
         case INTEGER_ID:
            return this;

            // Integer -> Decimal conversion
         case DECIMAL_ID:
            return new Decimal(new BigDecimal(this.value));

         default:
            return super.convertTo(type);
      }
   }

   /**
    * Assign a new Value. An implicit conversion may be performed to make the
    * assignment. This assignment may result in a loss of precision (ex : float
    * to int).
    * 
    * @param v the value to be assigned.
    */
   public void assign(final Value v)
   {
      this.value = new BigInteger(v.toString());
   }

   // ----------------------------------------------------
   // Arithmetic interface implementation
   // ----------------------------------------------------
   /**
    * Compute the unary minus of this value.
    * 
    * @return The unary minus of this value.
    */
   public Value unaryMinus()
   {
      return new Integer(this.value.negate());
   }

   /**
    * Compute an addition.
    * 
    * @param x another value.
    * @return the sum of the two values.
    */
   public final Value add(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).add(x);
      }
      final Integer num = (Integer) x.convertTo(INTEGER_ID);
      return new Integer(this.value.add(num.value));
   }

   /**
    * Compute a substraction.
    * 
    * @param x another value.
    * @return the difference between the two values.
    */
   public Value sub(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).sub(x);
      }
      final Integer num = (Integer) x.convertTo(INTEGER_ID);
      return new Integer(this.value.subtract(num.value));
   }

   /**
    * Compute a multiplication.
    * 
    * @param x another value.
    * @return the product of the two values.
    */
   public Value multiply(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).multiply(x);
      }
      final Integer num = (Integer) x.convertTo(INTEGER_ID);
      return new Integer(this.value.multiply(num.value));
   }

   /**
    * Compute a division.
    * 
    * @param x another value.
    * @return the ratio of the two values.
    */
   public final Value divide(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).divide(x);
      }
      final Integer num = (Integer) x.convertTo(INTEGER_ID);
      return new Integer(this.value.divide(num.value));
   }

   /**
    * Compute a modulus.
    * 
    * @param x another value.
    * @return the modulus of the values.
    */
   public Value modulus(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).modulus(x);
      }
      final Integer num = (Integer) x.convertTo(INTEGER_ID);
      return new Integer(this.value.mod(num.value));
   }

   // -------------------------------------------------------
   // Comparison interface implementation
   // -------------------------------------------------------
   /**
    * Compare this value with another value.
    * 
    * @param x another value.
    * @return The returned value is :
    *         <ul>
    *         <li>negative if this value is lower than another value</li>
    *         <li>zero if the two values are equal</li>
    *         <li>positive if this value is greater than another value</li>
    *         </ul>
    */
   public int compareTo(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).compareTo(x);
      }
      final Integer num = (Integer) x.convertTo(INTEGER_ID);
      return this.value.compareTo(num.value);
   }

   // ----------------------------------------------
   // Logic interface implementation
   // -----------------------------------------------
   /**
    * Returns this value as a boolean
    * 
    * @return the numeric value represented by this object after conversion to
    *         type boolean.
    */
   public final boolean booleanValue()
   {
      return (this.value.signum() != 0);
   }

   // ------------------------------------------------
   // Numeric interface implementation
   // ------------------------------------------------
   /**
    * Returns this value as a byte (signed 8 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type byte.
    */
   public final byte byteValue()
   {
      return this.value.byteValue();
   }

   /**
    * Returns this value as a short integer (signed 16 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type short.
    */
   public final short shortValue()
   {
      return this.value.shortValue();
   }

   /**
    * Returns this value as an integer (signed 32 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type int.
    */
   public final int intValue()
   {
      return this.value.intValue();
   }

   /**
    * Returns this value as a long integer (signed 64 bits).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type long.
    */
   public final long longValue()
   {
      return this.value.longValue();
   }

   /**
    * Returns this value as a float (signed 32 bits IEEE 754). The conversion
    * may result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type float.
    */
   public final float floatValue()
   {
      return this.value.floatValue();
   }

   /**
    * Returns this value as a double (signed 64 bits IEEE 754). The conversion
    * may result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type double.
    */
   public final double doubleValue()
   {
      return this.value.doubleValue();
   }

   /**
    * Returns this value as a BigInteger. The conversion may result in a loss of
    * precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type BigInteger.
    */
   public final BigInteger integerValue()
   {
      return new BigInteger(this.value.toByteArray());
   }

   /**
    * Returns this value as a BigDecimal. The conversion may result in a loss of
    * precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type BigDecimal.
    */
   protected final BigDecimal decimalValue()
   {
      return new BigDecimal(this.toString());
   }

   /**
    * Assign a boolean value.
    * 
    * @param value another value.
    */
   public final void assign(final boolean value)
   {
      this.value = BigInteger.valueOf(value ? 1L : 0L);
   }

   /**
    * Assign a byte value.
    * 
    * @param value another value.
    */
   public final void assign(final byte value)
   {
      this.value = BigInteger.valueOf(value);
   }

   /**
    * Assign short value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final short value)
   {
      this.value = BigInteger.valueOf(value);
   }

   /**
    * Assign an int value.
    * 
    * @param value another value.
    */
   public final void assign(final int value)
   {
      this.value = BigInteger.valueOf(value);
   }

   /**
    * Assign a long value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final long value)
   {
      this.value = BigInteger.valueOf(value);
   }

   /**
    * Assign a float value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final float value)
   {
      this.value =
         new BigDecimal(java.lang.Float.toString(value)).toBigInteger();
   }

   /**
    * Assign a double value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final double value)
   {
      this.value =
         new BigDecimal(java.lang.Double.toString(value)).toBigInteger();
   }
}
