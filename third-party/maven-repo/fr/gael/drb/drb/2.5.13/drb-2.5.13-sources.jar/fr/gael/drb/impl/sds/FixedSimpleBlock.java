/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.value.Value;

/**
 * Fixed block. This class provides the fixed implementation of AbstractBlock.<br>
 */
class FixedSimpleBlock extends AbstractBlock
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(FixedSimpleBlock.class);

   /**
    * getIndex() return value, used for performance purpose. Used to store the
    * result after the first getIndex() call.
    */
   private int indexValue;

   /**
    * Value of the block, used for performance purpose. Used to store the result
    * after the first getValue() call.
    */
   protected Value value;

   /**
    * The parent block.
    */
   protected DrbNode parent;

   /**
    * Creates a new instance of DefaultBlock with descriptor and key. The
    * descriptor ans the key must not be null. The descriptor is used to get
    * information about the block such as name, offset, number of occurrences,
    * etc. The key is the path of the block in the descriptors tree.
    * 
    * @param descriptor The descriptor of the block.
    * @param key The key of the block.
    */
   protected FixedSimpleBlock(final Descriptor descriptor, final int[] key)

   {
      // Call superclass operation
      super(descriptor, key);

      // Set default values
      this.indexValue = -1;
      this.value = null;
   }

   /**
    * Returns the index of the block. In this implementation the superclass
    * operation is called only during the first call and the returned value is
    * stored in the indexValue attribute which enables better performance for
    * future calls.
    * 
    * @return The index of the block or a negative value.
    */
   public int getIndex()
   {
      // Check if operation was not called before
      if (this.indexValue < 0)
      {
         // Call superclass operation
         this.indexValue = super.getIndex();
      }

      // Returns the value
      return this.indexValue;
   }

   /**
    * Returns a new instance of the parent block. If the current block is the
    * root block returns null.<br>
    * Uses the current descriptor and its parent to create the parent block.
    * 
    * @return A new instance of the parent block or null.
    */
   public final DrbNode getParent()
   {
      if (this.parent == null)
      {
         this.parent = super.getParent();
      }
      return this.parent;
   }

   /**
    * Returns a new instance of the list of children blocks.
    * 
    * @return always returns null.
    */
   public final DrbNodeList getChildren()
   {
      return null;
   }

   /**
    * Returns true if at least one child exists for the current block. In this
    * implementation the superclass operation is called only during the first
    * call and the returned value is stored in the hasChildValue attribute which
    * enables better performance for future calls.
    * 
    * @return true if at least one child exists, false otherwise.
    */
   public final boolean hasChild()
   {
      return false;
   }

   /**
    * Returns the number of children for the current block. In this
    * implementation the superclass operation is called only during the first
    * call and the returned value is stored in the childrenCountValue attribute
    * which enables better performance for future calls.
    * 
    * @return The number of children for the current block.
    */
   public final int getChildrenCount()
   {
      return 0;
   }

   /**
    * Returns a new instance of the first child of the current block.
    * 
    * @return always returns null.
    */
   public final DrbNode getFirstChild()
   {
      return null;
   }

   /**
    * Returns a new instance of the last child of the current block.
    * 
    * @return always returns null.
    */
   public final DrbNode getLastChild()
   {
      return null;
   }

   /**
    * Returns a new instance of the "index"th child of the current block.
    * 
    * @param index The position of the child block to retreive starting from 0
    *           and not greater or equal to the number of children.
    * @return Always returns null.
    */
   public final DrbNode getChildAt(final int index)
   {
      return null;
   }

   /**
    * Returns a new instance of the child block having the given name and the
    * given occurrence.
    * 
    * @param name The name of the child block to retreive.
    * @param occurrence The occurrence of the child block to retreive, value
    *           starting from 1.
    * @return Always returns null.
    */
   public final DrbNode getNamedChild(final String name, final int occurrence)
   {
      return null;
   }

   /**
    * Tests if a specific interface can be provided. In this implementation no
    * other implementation is provided.
    * 
    * @param api The class type to test.
    * @return always false.
    */
   public boolean hasImpl(final Class api)
   {
      if (api == java.io.InputStream.class)
      {
         return true;
      }
      return super.hasImpl(api);
   }

   /**
    * Returns a specific implementation. In this implementation no other
    * implementation is provided.
    * 
    * @param api The interface (or class) to be provided.
    * @return always a null reference.
    */
   public Object getImpl(final Class api)
   {
      if (api == java.io.InputStream.class)
      {
         final Value value = this.getValue();
         if (value == null)
         {
            return null;
         }
         switch (value.getType())
         {
            case Value.STRING_ID:
               return new java.io.ByteArrayInputStream(value.toString()
                     .getBytes());
         }
         return null;
      }
      return super.getImpl(api);
   }

   /**
    * Returns the value of the block. In this implementation the value is read
    * from the file only once. Any further call will return the cached value. If
    * the block is not a leaf (i.e. a node having at least one child), no value
    * is returned.
    * 
    * @return The block value or a null reference.
    */
   public Value getValue()
   {
      // If node has child, no value is returned.
      if ((this.descriptor != null)
            && (this.descriptor.getValueType() == Value.NULL_ID))
      {
         return null;
      }

      // If value has not been read yet, do it.
      if (this.value == null)
      {
         this.value = this.descriptor.getValue(this.key);
      }

      // Return value
      return this.value;
   }

   /**
    * Returns the value type of the block. This implementation wraps the
    * getValueType() operation from the descriptor.
    * 
    * @return The block value type.
    */
   public int getValueType()
   {
      return this.descriptor.getValueType();
   }

   /**
    * Changes the value of the node. This implementation simply wrap the
    * AbstractBlock to use the cache.
    * <p>
    * <b>Events:</b> No particular event is fired in this implementation.
    * </p>
    * 
    * @param value The new value of the node. This value shall not be null.
    * @return The effectivelly assigned value. The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            offset or the length used to write is unknown.
    */
   public Value setValue(final Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      this.value = super.setValue(value);
      return this.value;
   } // setValue

   /**
    * Inserts a child at a given position. In this implementation the operation
    * is wrapped to the appendChild() because the order is fixed by the
    * underlying schema.
    * <p>
    * <b>Events:</b> No particular event is fired yet in this implementation.
    * </p>
    * 
    * @param node A reference to the node to be inserted.
    * @param index The expected index of the node after the insertion (unused).
    * @return A reference to the effectively inserted node. This reference
    *         always differs from the input one in this implementation.
    * @throws UnsupportedOperationException This exception is always raised in
    *            this implementation.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the node is null.
    * @throws IndexOutOfBoundsException This exception is raised when the list
    *            of child is too long.
    */
   public DrbNode insertChild(final DrbNode node, final int index)
         throws NullPointerException, UnsupportedOperationException,
         IndexOutOfBoundsException
   {
      throw new UnsupportedOperationException(
            "SimpleBlock.insertChild(): This operation is not supported ");
   }

   /**
    * Appends a child at the end of the children list. This implementation wraps
    * the appendChild() operation from the descriptor All values are recursively
    * written using the offsets and lengths corresponding to each block
    * descriptor and block occurrence. The order depends on the underlying
    * descriptor.
    * <p>
    * <b>Events:</b> No particular event is fired yet in this implementation.
    * </p>
    * 
    * @param node A reference to the node to be appended.
    * @return A reference to the node passed in parameter.
    * @throws NullPointerException This exception is raised when the passed node
    *            is a null reference.
    * @throws UnsupportedOperationException This exception is raised when the
    *            current block cannot accept any child or if the child name does
    *            not match any valid children name from the descriptor.
    */
   public DrbNode appendChild(final DrbNode node) throws NullPointerException,
         UnsupportedOperationException
   {
      throw new UnsupportedOperationException(
            "SimpleBlock.appendChild(): This operation is not supported ");
   }

   /**
    * Replaces a child of the current node. In this implementation the operation
    * is not supported yet.
    * 
    * @param index Index of the node to be replaced. This index starts at 0 and
    *           shall be less than the number of children (unused).
    * @param new_node A reference to the node that replaces the old one(unused)
    * @return null.
    * @throws UnsupportedOperationException This exception is always raised in
    *            this implementation.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the node is null.
    * @throws IndexOutOfBoundsException This exception is raised when the list
    *            of child is too long.
    */
   public DrbNode replaceChild(final int index, final DrbNode new_node)
         throws NullPointerException, IndexOutOfBoundsException,
         UnsupportedOperationException
   {
      throw new UnsupportedOperationException(
            "SimpleBlock.replaceChild(): This operation is not supported ");
   }

   /**
    * Removes an existing child. In this implementation the operation is not
    * supported yet. In the future it will probably remove the reference to the
    * child block using the specified index and removing one occurrence in the
    * related Descriptor.
    * <p>
    * <b>Events:</b> No particular event is fired in this implementation.
    * </p>
    * 
    * @param index Index of the child to be removed (unused).
    * @throws UnsupportedOperationException This exception is always raised in
    *            this implementation.
    * @throws IndexOutOfBoundsException This exception is raised when the list
    *            of child is too long.
    */
   public void removeChild(final int index) throws IndexOutOfBoundsException,
         UnsupportedOperationException
   {
      throw new UnsupportedOperationException("SimpleBlock.removeChild(): "
            + "This operation is not supported.");
   }
}
