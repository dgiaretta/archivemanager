/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

import org.apache.log4j.Logger;

/**
 * A length.
 */
public final class Length
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(Length.class);

   /**
    * The length in bytes.
    */
   public long length;

   /**
    * The length in bits to add to length in bytes in case of non 8-bits aligned
    * structure.
    */
   public byte bitLength;

   /**
    * Create a Length instance.
    * 
    * @param length The byte length
    * @param bit_length The bit length
    */
   public Length(final long length, final long bit_length)
   {
      this.setLength(length, bit_length);
   } // Length

   /**
    * Create a Length instance.
    * 
    * @param length The byte length
    */
   public Length(final long length)
   {
      this.length = length;
   } // Length

   /**
    * Returns the byte length
    * 
    * @return The byte length
    */
   public final long getLength()
   {
      return this.length;
   }

   /**
    * Returns the bit length
    * 
    * @return The bit length
    */
   public final byte getBitLength()
   {
      return this.bitLength;
   }

   /**
    * Set the length
    * 
    * @param length The byte length
    * @param bit_length The bit length
    */
   public void setLength(long length, long bit_length)
   {
      if (bit_length > 7)
      {
         length += bit_length >> 3;
         bit_length = bit_length & 0x7;
      }
      else if (bit_length < 0)
      {
         length += (bit_length / 8) - 1;
         bit_length = 8 - (-bit_length & 0x7);
      }
      this.length = length;
      this.bitLength = (byte) bit_length;
   }

   /**
    * Set the length
    * 
    * @param length The byte length
    */
   public void setLength(final long length)
   {
      this.length = length;
      this.bitLength = 0;
   }

   /**
    * toString
    * 
    * @return the string representation.
    */
   public java.lang.String toString()
   {
      if (this.bitLength > 0)
      {
         if (this.length == 0)
         {
            return this.bitLength + "b";
         }
         return this.length + "B " + this.bitLength + "b";
      }
      return this.length + "B";
   }
}
