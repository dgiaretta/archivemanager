<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                version="1.0">

  <xsl:output method="html"/>

  <xsl:template match="/">
    <html>
      <body>
       <table border="1" cellspacing="0" cellpadding="2">
         <tr>
           <td align="left" valign="top">
              <xsl:for-each select="part/chapter">
                 <font size="3px" color="#AA0000"><b><xsl:value-of select="./@title"/></b></font><br/>
                 <xsl:for-each select="./section">
                    <font size="2px"><xsl:value-of select="./@title"/></font><br/>
                 </xsl:for-each><br/>
              </xsl:for-each>
           </td>
           <td width="75%" align="left" cellspacing="20" cellpadding="20"><xsl:apply-templates/></td>
         </tr>
       </table>
      </body>
    </html>
  </xsl:template>

   <!-- Le template d'une partie -->
  <xsl:template match="part">
    <xsl:choose>
      <xsl:when test="./@src = 'fr/gael/drb/query/doc.xml'">
         <h2><a href="query/doc.xml">XQuery Engine</a></h2>
      </xsl:when>
      <xsl:when test="./@src = 'fr/gael/drb/xsd/doc.xml'">
         <h2><a href="xsd/doc.xml">XML-Schema processor</a></h2>
      </xsl:when>
      <xsl:when test="./@src = 'fr/gael/drb/impl/sds/doc.xml'">
         <h2><a href="impl/sds/doc.xml">Structured Data Format</a></h2>
      </xsl:when>
      <xsl:otherwise>
        <h2><xsl:value-of select="./@title"/></h2> 
         <xsl:apply-templates/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>
 
  <!-- Le template du chapitre -->
  <xsl:template match="part/chapter">
     <h2><xsl:value-of select="./@title"/></h2> 
     <xsl:apply-templates/>
  </xsl:template>

  

  <!-- Le template des sections principales -->
  <xsl:template match="section">
     <h3><xsl:value-of select="./@title"/></h3> 
     <xsl:apply-templates/>
  </xsl:template>
    


  <!-- Le template des sous sections -->  
  <xsl:template match="sub-section">
     <h4><xsl:value-of select="./@title"/></h4> 
     <xsl:apply-templates/>
  </xsl:template>
  

  <!-- Le template des paragraphes -->  
  <xsl:template match="paragraph">
    <p><xsl:apply-templates/></p>
  </xsl:template>

  <!-- Le template des list-item -->  
  <xsl:template match="list-item">
    <li><p><xsl:apply-templates/></p></li>
  </xsl:template>

  <!-- Le template d'un code -->  
  <xsl:template match="code">
    <p>
       <table width="100%" border="0" align="center" cellspacing="0" cellpadding="0"  bgcolor="#EEEEEE">
          <tr><td><pre><xsl:value-of select="."/></pre></td></tr>
      </table>
      <center><xsl:value-of select="./@title"/></center> 
    </p>
  </xsl:template>

  <!-- Le template d'un example -->  
  <xsl:template match="example">
    <p>
       <table width="90%" border="1" align="center">
          <tr><td><pre><xsl:value-of select="."/></pre></td></tr>
      </table>
      <center><xsl:value-of select="./@title"/></center> 
    </p>
  </xsl:template>

</xsl:stylesheet>
