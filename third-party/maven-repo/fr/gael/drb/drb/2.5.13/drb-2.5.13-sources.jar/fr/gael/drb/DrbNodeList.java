/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

/**
 * Collection of nodes. This interface provides primary operations to handle a
 * collection of DrbNode It is compliant to the NodeList interface specified by
 * W3C Document Object Model (<a
 * href="http://www.w3.org/TR/2001/WD-DOM-Level-3-Core/ 20010913/DOM3-Core.html"
 * DOM Level 3 - Core</a>)
 */
public interface DrbNodeList extends DrbSequence
{

   /**
    * Returns a specific item of the list. The item is identified by its
    * position (i.e. index or sequence number) in the list of nodes. The order
    * depends on the implementation as well as from the operation that created
    * the list. The index starts from 0 and shall not be greater or equal to the
    * item count of the list. A null reference is returned if the provided index
    * is outside the list bounds.
    * 
    * @param index The position of the item starting from 0 and not greater or
    *           equal to the item count in the list.
    * @return A reference to specified item or null if no such node.
    */
   public DrbNode item(int index);

   /**
    * Returns an occurence of item matching a specific name. The occurence
    * number starts from 1. The name is a local name without any prefix. A null
    * reference is returned if the provided occurrence is outside the list
    * bounds.
    * 
    * @param name The name to match.
    * @param occurence The occurence number of the desired child.
    * @return A reference to specified item or null if no such node.
    */
   public DrbNode getNamedItem(String name, int occurence);

   /**
    * Returns all the items matching a specific name. The name is a local name
    * without any prefix.
    * 
    * @param name The name to match.
    * @return A reference to specified items or null if no such nodes.
    */
   // public DrbNodeList items(String name);
   /**
    * The number of node in the list. This number can be 0 if the list is empty
    * but shall never be negative.
    * 
    * @return The number of nodes in the list.
    */
   public int getLength();

}// DrbNodeList
