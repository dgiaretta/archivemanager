/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sds;

/**
 * Dynamic exception of the SDF engine during evaluation phase.
 * <p>
 * A dynamic error is an error that must be detected during the evaluation
 * phase.
 * </p>
 */
public class DynamicException extends RuntimeException
{
   /**
    * Builds a dynamic exception with a message.
    * 
    * @param message the exception message should fit <error> in the sentence "<error>
    *           at node ...". It shall therefore be a single line message whith
    *           no trailing sign or symbol (e.g. no trailing point, comma or
    *           question mark).
    */
   protected DynamicException(final String message)
   {
      super(message);
   }
}
