/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.value.Value;

/**
 * Declaration of the XML-Schema value space.
 */
public interface XsdValueSpace
{
   // ==========================================
   // Static part.
   // ==========================================

   /**
    * Undefined value.
    */
   public final static int UNDEFINED = 0;

   /**
    * Partial order.
    */
   public final static int PARTIAL = 1;

   /**
    * Total order.
    */
   public final static int TOTAL = 2;

   /**
    * Finite cardinality.
    */
   public final static int FINITE = 1;

   /**
    * Countably infinite cardinality.
    */
   public final static int COUNTABLY_INFINITE = 2;

   /**
    * Un-countably infinite cardinality.
    */
   public final static int UNCOUNTABLY_INFINITE = 3;

   // ==================================================
   // Methods part.
   // ==================================================
   /**
    * A value space, is said to be ordered if there exists an order-relation
    * defined for that value space.
    * 
    * @return true if this value space is ordered and false otherwise.
    */
   public boolean isOrdered();

   /**
    * Returns the order-relation of this value space. An order relation on a
    * value space is a mathematical relation that imposes a total order or a
    * partial order on the members of the value space
    * 
    * @see fr.gael.drb.xsd.XsdValueSpace#PARTIAL
    * @see fr.gael.drb.xsd.XsdValueSpace#TOTAL
    * @return the order-relation defined on that value space
    */
   public int getOrderRelation();

   /**
    * A datatype is bounded if its value space has either an inclusive upper
    * bound or an exclusive upper bound and either an inclusive lower bound and
    * an exclusive lower bound.
    * 
    * @return true if this value space is bounded and false otherwise.
    */
   public boolean isBounded();

   /**
    * Returns the inclusive lower bound.
    * 
    * @return The inclusive lower bound or null if not defined.
    */
   public Value getInclusiveLowerBound();

   /**
    * Returns the inclusive upper bound.
    * 
    * @return The inclusive upper bound or null if not defined.
    */
   public Value getInclusiveUpperBound();

   /**
    * Returns the exclusive lower bound.
    * 
    * @return The exclusive lower bound or null if not defined.
    */
   public Value getExclusiveLowerBound();

   /**
    * Returns the exclusive upper bound.
    * 
    * @return The exclusive upper bound or null if not defined.
    */
   public Value getExclusiveUpperBound();

   /**
    * Returns the cardinality of this value space. Every value space has
    * associated with it the concept of cardinality. Some value spaces are
    * finite, some are countably infinite while still others could conceivably
    * be uncountably infinite (although no value space defined by the XML-Schema
    * specification is uncountable infinite). A datatype is said to have the
    * cardinality of its value space.
    * 
    * @return The cardinality of this value space.
    * @see fr.gael.drb.xsd.XsdValueSpace#FINITE
    * @see fr.gael.drb.xsd.XsdValueSpace#COUNTABLY_INFINITE
    * @see fr.gael.drb.xsd.XsdValueSpace#UNCOUNTABLY_INFINITE
    */
   public int getCardinality();

   /**
    * A datatype is said to be numeric if its values are conceptually quantities
    * (in some mathematical number system).
    * 
    * @return true if the datatype is numeric and false otherwise
    */
   public boolean isNumeric();

} // XsdValueSpace
