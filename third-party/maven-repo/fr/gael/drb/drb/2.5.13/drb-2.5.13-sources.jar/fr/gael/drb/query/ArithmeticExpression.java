/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.value.Arithmetic;
import fr.gael.drb.value.Value;
import fr.gael.drb.value.ValueArray;

/**
 * Wraps the arithmetic expression (i.e. "+", "-", "*", "div" and "mod") of
 * XQuery language.
 */
class ArithmeticExpression extends AbstractExpression
{
   /**
    * PLUS indicator.
    */
   protected static int PLUS = 0;

   /**
    * MINUS indicator.
    */
   protected static int MINUS = 1;

   /**
    * MULTIPLY indicator.
    */
   protected static int MULTIPLY = 2;

   /**
    * DIVIDE indicator.
    */
   protected static int DIVIDE = 3;

   /**
    * MODULO indicator.
    */
   protected static int MODULO = 4;

   /**
    * Expression wrapping the left operand.
    */
   private Expression leftOperand;

   /**
    * Expression wrapping the right operand.
    */
   private Expression rightOperand;

   /**
    * The the current instance operation type.
    */
   private int operation;

   /**
    * Builds an arithmetic expression.
    * 
    * @param token the token related to the current range expression.
    * @param left_operand the expression wrapping the left operand.
    * @param operation the operation to perform.
    * @param right_operand the expression wrapping the left operand.
    */
   public ArithmeticExpression(final Token token,
         final Expression left_operand, final int operation,
         final Expression right_operand)
   {
      super("Arithmetic", token);

      this.leftOperand = left_operand;
      this.operation = operation;
      this.rightOperand = right_operand;
   }

   /**
    * Returns a string decribing the arithmetic expression.
    * 
    * @return the description of the arithmetic expression.
    */
   public String toString()
   {
      String operation_string;

      if (this.operation == PLUS)
      {
         operation_string = "+";
      }
      else if (this.operation == MINUS)
      {
         operation_string = "-";
      }
      else if (this.operation == MULTIPLY)
      {
         operation_string = "*";
      }
      else if (this.operation == DIVIDE)
      {
         operation_string = "div";
      }
      else if (this.operation == MODULO)
      {
         operation_string = "mod";
      }
      else
      {
         operation_string =
            "(unkown arithmetic operation #" + this.operation + ")";
      }

      return "(" + this.leftOperand + " " + operation_string + " "
            + this.rightOperand + ")";
   }

   /**
    * Evaluate the operation.
    * 
    * @param context the outer-focus of the evalutation.
    * @return the sequence resulting from the dynamic evaluation.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {

      /**
       * Evaluates the left operand and extract its value.
       */
      final DrbSequence left_sequence = this.leftOperand.evaluate(context);

      if (left_sequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the left operand expression");
      }

      final ValueArray left_array = left_sequence.atomize();
      if (left_array.length() == 0)
      {
         return new DrbDefaultSequence();
      }

      if (left_array.length() > 1)
      {
         throw new TypeException(this,
               "The sequence length of left operand is greater than one");
      }

      final Value left_value = left_array.getElement(0);

      /**
       * Evaluates the right operand and extract its value.
       */
      final DrbSequence right_sequence = this.rightOperand.evaluate(context);

      if (right_sequence == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the right operand expression");
      }

      final ValueArray right_array = right_sequence.atomize();

      if (right_array.length() == 0)
      {
         return new DrbDefaultSequence();
      }

      if (right_array.length() > 1)
      {
         throw new TypeException(this,
               "The sequence length of right operand is greater than one");
      }

      final Value right_value = right_array.getElement(0);

      /**
       * Compute the operation result.
       */
      final DrbDefaultSequence ouput_sequence = new DrbDefaultSequence();
      Value result = null;

      if (left_value instanceof Arithmetic)
      {
         if (this.operation == PLUS)
         {
            result = ((Arithmetic) left_value).add(right_value);
         }
         else if (this.operation == MINUS)
         {
            result = ((Arithmetic) left_value).sub(right_value);
         }
         else if (this.operation == MULTIPLY)
         {
            result = ((Arithmetic) left_value).multiply(right_value);
         }
         else if (this.operation == DIVIDE)
         {
            try
            {
               result = ((Arithmetic) left_value).divide(right_value);
            }
            catch (final java.lang.ArithmeticException e)
            {
               throw new DynamicException(this, e.getMessage());
            }
         }

         else if (this.operation == MODULO)
         {
            result = ((Arithmetic) left_value).modulus(right_value);
         }

         if (result == null)
         {
            throw new TypeException(this, "Unable to perform operations.");
         }

         ouput_sequence.add(result);

         return ouput_sequence;
      }
      else
      {
         throw new TypeException(this, "Invalid type of left operand ("
               + left_value.getType() + ").");
      }
   }

   /**
    * A expression which is constant means that it need no context item to be
    * evaluate. The returned sequence from its evaluation will always be the
    * same along the query script
    * 
    * @return true if this expression is constant
    */
   public boolean isConstant()
   {
      return (this.leftOperand.isConstant() && this.rightOperand.isConstant());
   }
}
