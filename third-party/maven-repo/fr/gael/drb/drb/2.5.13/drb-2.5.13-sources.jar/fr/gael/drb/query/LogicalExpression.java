/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbSequence;

/**
 * Wraps Or, And logical expressions of XQuery anguage.
 */
class LogicalExpression extends AbstractExpression
{
   /**
    * OR indicator.
    */
   static int OR = 0;

   /**
    * AND indicator.
    */
   static int AND = 1;

   /**
    * Expression wrapping the left operand.
    */
   Expression leftOperand;

   /**
    * Expression wrapping the right operand.
    */
   Expression rightOperand;

   /**
    * Operation type of the current instance.
    */
   int operation;

   /**
    * Builds a logical expression.
    * 
    * @param token the token related to the current expression.
    * @param left_operand the left operand expression.
    * @param operation indicator of the type of logical expression.
    * @param right_operand the right operand expression.
    */
   public LogicalExpression(final Token token, final Expression left_operand,
         final int operation, final Expression right_operand)
   {
      super("Local", token);

      this.leftOperand = left_operand;
      this.operation = operation;
      this.rightOperand = right_operand;
   }

   /**
    * Returns a the logical expression as a convenient string.
    * 
    * @return the string detailing the logical operation.
    */
   public String toString()
   {
      String operation_string;

      if (this.operation == this.OR)
      {
         operation_string = "or";
      }
      else if (this.operation == this.AND)
      {
         operation_string = "and";
      }
      else
      {
         operation_string =
            "(unknown binary operation #" + this.operation + ")";
      }

      return this.leftOperand + " " + operation_string + " "
            + this.rightOperand;
   }

   /**
    * Evaluates the current operation.
    * 
    * @param context the outer-focus of the evaluation.
    * @return the sequence resulting from the dynamic evaluation.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {
      /**
       * Get the effective boolean value of the left operand.
       */
      final DrbSequence leftEval = this.leftOperand.evaluate(context);

      if (leftEval == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the left operand");
      }

      final boolean leftEbv = Query.getEffectiveBooleanValue(leftEval);
      
      /**
       * Return immediately if left operand is already true for OR expression
       * or if left operand is false for a AND expression
       */
      if ((this.operation == this.OR) && leftEbv)
      {
         return LiteralResult.TRUE;
      }
      
      if ((this.operation == this.AND) && !leftEbv)
      {
         return LiteralResult.FALSE;
      }

      /**
       * Get the effective boolean value of the right operand.
       */
      final DrbSequence rightEval = this.rightOperand.evaluate(context);

      if (rightEval == null)
      {
         throw new DynamicException(this,
               "Error while evaluating the right operand");
      }

      final boolean rightEbv = Query.getEffectiveBooleanValue(rightEval);

      /**
       * Process comparison.
       */
      boolean output_ebv;

      if (this.operation == this.OR)
      {
         output_ebv = leftEbv || rightEbv;
      }
      else
      {
         output_ebv = leftEbv && rightEbv;
      }

      return output_ebv ? LiteralResult.TRUE : LiteralResult.FALSE;
   }
}
