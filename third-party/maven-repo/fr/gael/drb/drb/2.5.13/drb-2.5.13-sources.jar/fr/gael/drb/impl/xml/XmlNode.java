/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.xml;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringReader;

import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultNodeList;
import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.DrbNodesChangeEvent;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.value.Value;
import fr.gael.drb.xsd.Namespace;

/**
 * XML node implementation. This implementation uses the DOM API provided by W3C
 * to comply the DrbNode interface. It allows to browse the XML documents with
 * the Data Request Broker API.
 * <p>
 * Note: the main difference between DRB API and the DOM provided by the W3C is
 * that the children of a node cannot be notations, PI, ENTITY, attributes, etc.
 * All the nodes corresponds to the XML markups and their content the text
 * embedded between the markups. Attributes are supported but processing
 * instructions, ENTITY, notation, etc. are discarded by the DRB.
 * </p>
 */
public class XmlNode extends DrbNodeImpl
{

   /**
    * XML Namespace
    */
   public final static String XML_NAMESPACE =
      "http://www.w3.org/XML/1998/namespace";

   /**
    * XML Prefix
    */
   public final static String XML_PREFIX = "xml";

   /**
    * XMLNS Namespace
    */
   public final static String XMLNS_NAMESPACE = "http://www.w3.org/2000/xmlns/";

   /**
    * XMLNS Prefix
    */
   public final static String XMLNS_PREFIX = "xmlns";

   /**
    * DOM element wrapped by this implementation. This reference is never null
    * and corresponds to the DOM ELEMENT node of the XML document. Only ELEMENT
    * nodes are represented here and all other types are discarded.
    */
   private Element node;

   /**
    * The XML document
    */
   private XmlDocument document;

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(XmlNode.class);

   /**
    * Builds a new XmlNode from a DOM element. This constructor set the
    * attribute reference to the passed DOM node. TODO : this operation shall
    * raise an exception in case of null parameter.
    * 
    * @param node The DOM element to be wrapped. This parameter shall never be
    *           null.
    * @deprecated As of DRB 2.2, added the XmlDocument class.
    * @see XmlDocument
    */
   public XmlNode(final Node node)
   {
      this(node, null);
   }

   /**
    * Builds a new XmlNode from an InputStream. This constructor initialises a
    * node based on the XML document encoded in the passed InputStream. TODO :
    * this operation shall raise an exception in case of null parameter.
    * 
    * @param input_stream The InputStream to build the DOM node.
    * @param base_node A reference to a the base node of an external
    *           implementation.
    * @deprecated As of DRB 2.2, added the XmlDocument class.
    * @see XmlDocument#XmlDocument(java.io.InputStream)
    */
   public XmlNode(final InputStream input_stream, final DrbNode base_node)
   {
      /**
       * Checks the InputStream.
       */
      if (input_stream == null)
      {
         throw new NullPointerException();
      }

      /**
       * Parse the input stream as an XML file.
       */
      final InputSource source = new InputSource(input_stream);
      this.document = new XmlDocument(source);
      this.document.baseNode = base_node;

      /**
       * Sets the XML node.
       */
      this.node = this.document.document.getDocumentElement();
      if (this.node == null)
      {
         throw new IllegalArgumentException("The document has no root element.");
      }
   }

   /**
    * Builds a new XmlNode from an reader. This constructor initialises a node
    * based on the XML document encoded in the passed InputStream. TODO : this
    * operation shall raise an exception in case of null parameter.
    * 
    * @param reader The reader to build the DOM node.
    * @param base_node A reference to a the base node of an external
    *           implementation.
    * @deprecated As of DRB 2.2, added the XmlDocument class.
    * @see XmlDocument#XmlDocument(java.io.Reader)
    */
   public XmlNode(final Reader reader, final DrbNode base_node)
   {
      /**
       * Checks the InputStream.
       */
      if (reader == null)
      {
         throw new NullPointerException();
      }

      /**
       * Parse the input stream as an XML file.
       */
      final InputSource source = new InputSource(reader);
      this.document = new XmlDocument(source);
      this.document.baseNode = base_node;

      /**
       * Sets the XML node.
       */
      this.node = this.document.document.getDocumentElement();
      if (this.node == null)
      {
         throw new IllegalArgumentException("The document has no root element.");
      }
   }

   /**
    * Builds a new XmlNode from a String. This constructor initialises a node
    * based on the XML document encoded in the passed string.
    * 
    * @param xml_string The XML string. This parameter shall never be null.
    * @deprecated As of DRB 2.2, added the XmlDocument class.
    * @see XmlDocument#XmlDocument(java.lang.String)
    */
   public XmlNode(final String xml_string)
   {
      this(new StringReader(xml_string), null);
   }

   /**
    * Builds a new XmlNode from a DOM node with a base node. This constructor
    * set the attribute reference to the passed DOM node.
    * 
    * @todo this operation shall raise an exception in case of null parameter.
    * @param node The DOM node to be wrapped. This parameter shall never be
    *           null.
    * @param base_node A reference to a the base node of an external
    *           implementation.
    * @deprecated As of DRB 2.2, added the XmlDocument class.
    * @see XmlDocument
    */
   public XmlNode(final Node node, final DrbNode base_node)
   {
      final Document doc_node = node.getOwnerDocument();
      if (doc_node != null)
      {
         this.document = new XmlDocument(doc_node);
         this.document.baseNode = base_node;
      }
      this.node = (Element) node;
   }

   /**
    * Builds a new XmlNode from a DOM node with a base node. This constructor
    * set the attribute reference to the passed DOM node. TODO : this operation
    * shall raise an exception in case of null parameter.
    * 
    * @param node The DOM element to be wrapped. This parameter shall never be
    *           null.
    * @param document The XML document.
    */
   private XmlNode(final Element node, final XmlDocument document)
   {
      this.node = node;
      this.document = document;
   }

   /**
    * Indicates whether this node is "equal to" to another node. See
    * Object.equals() for the general contract of this method.
    * 
    * @param obj another value.
    * @return true if this object is the same as the obj argument
    */
   public boolean equals(final Object obj)
   {
      // Check reference equality
      if (this == obj)
      {
         return true;
      }

      // Check DOM
      if (obj instanceof XmlNode)
      {
         final XmlNode xml_node = (XmlNode) obj;
         if (this.node == null)
         {
            return false;
         }
         return this.node == xml_node.node;
      }

      // Otherwise the object is different
      return false;
   } // equals

   /**
    * The name of the node. This name is never null and correspond to the markup
    * identifier in the XML document. For instance the markup <example>
    * </example> will provide a name equal to "example".This operation extracts
    * the name of the markup from the getLocalName() operation defined node
    * class of DOM.
    * 
    * @return The name of the markup node.
    */
   public String getName()
   {
      return this.node.getLocalName();
   }

   /**
    * The index of the node in the parent children list. This operation counts
    * the previous sibling to retreive the index of the current node.
    * 
    * @return The index of the current node.
    */
   public int getIndex()
   {

      int index = 0;

      Node current_node = this.node.getPreviousSibling();

      while (current_node != null)
      {
         if (current_node.getNodeType() == Node.ELEMENT_NODE)
         {
            index = index + 1;
         }
         current_node = current_node.getPreviousSibling();
      }

      return index;
   }

   /**
    * The root node of the XML node. The root node is the one of the underlying
    * implementation.If the node does not belongs to a parent node, the root may
    * not exists.
    * 
    * @return A reference to the root node or null if none.
    */
   public DrbNode getRoot()
   {
      if (this.document != null)
      {
         return this.document.getRoot();
      }
      else
      {
         return null;
      }
   }

   /**
    * Occurrence of the node. Returns the occurrence of the node in its parent
    * children list. If the node has not parent the occurrence may not be
    * available: the operation returns therefore a negative value.
    * 
    * @return The index of the node or negative value.
    */
   public int getOccurrence()
   {
      final String name = this.node.getLocalName();

      if (name == null)
      {
         return 1;
      }

      int occurence = 1;

      Node current_node = this.node.getPreviousSibling();

      while (current_node != null)
      {
         try
         {
            if ((current_node.getNodeType() == this.node.getNodeType())
                  && (name.compareTo(current_node.getLocalName()) == 0))
            {
               occurence = occurence + 1;
            }
         }
         catch (final NullPointerException e)
         {
            return -1;
         }

         current_node = current_node.getPreviousSibling();
      }

      return occurence;
   }

   /**
    * Check if this node may have multiple occurrence
    * 
    * @return true if the children may have a multiple occurrence and false
    *         otherwise.
    */
   public boolean allowsMultiOccurrence()
   {
      final String name = this.node.getLocalName();

      if (name == null)
      {
         return false;
      }

      Node current_node = this.node.getNextSibling();

      while (current_node != null)
      {
         if ((current_node.getNodeType() == this.node.getNodeType())
               && (name.compareTo(current_node.getLocalName()) == 0))
         {
            return true;
         }

         current_node = current_node.getNextSibling();
      }

      current_node = this.node.getPreviousSibling();

      while (current_node != null)
      {
         if ((current_node.getNodeType() == this.node.getNodeType())
               && (name.compareTo(current_node.getLocalName()) == 0))
         {
            return true;
         }

         current_node = current_node.getPreviousSibling();
      }

      return false;
   } // allowsMultiOccurrence

   /**
    * The namespace URI of the XML node. The namespace is extracted from the
    * wrapped XML node through the DOM API
    * 
    * @return The namespace URI or null if unspecified.
    */
   public String getNamespaceURI()
   {
      return this.node.getNamespaceURI();
   }

   /**
    * The content type of the node. The type of an XML element is yet a string.
    * See the getValue() operation for additional information about typing and
    * values.
    * 
    * @return fr.gael.drb.value.Value.STRING_ID.
    */
   public int getValueType()
   {
      return Value.STRING_ID;
   }

   /**
    * The contents of the current node. The value of the node is the
    * concatenation of the TEXT and CDATA nodes children of the current one.
    * Actually the wrapped nodes are only element and their contents corresponds
    * to their textual children. This operation catches all the DOM exceptions
    * and continue its processing with only few messages printed out the
    * standard error. Returned value are always identified by
    * fr.gael.drb.value.Value.STRING_ID.
    * 
    * @return The value of the current node or null if none.
    */
   public Value getValue()
   {
      String string = null; // value of the current node
      short node_type; // type of the current node

      /**
       * Look for the TEXT and CDATA nodes. Only the text nodes children of the
       * current nodes represent the contents of the current node.
       */
      Node child = this.node.getFirstChild();

      while (child != null)
      {
         try
         {
            String text = null;
            node_type = child.getNodeType();
            if (child.getNodeType() == Node.TEXT_NODE)
            {
               text = child.getNodeValue();
               if (text != null)
               {
                  text = text.trim();
                  if (text.length() == 0)
                  {
                     text = null;
                  }
               }
            }
            else if (node_type == Node.CDATA_SECTION_NODE)
            {
               text = child.getNodeValue();
            }
            if (string == null)
            {
               string = text;
            }
            else if (text != null)
            {
               string = string.concat(text);
            }
         }
         catch (final DOMException e)
         {
            logger.error("fr.gael.drb.impl.xml.XmlNode.getValue() : "
                  + "Cannot get node value.");
            logger.error("fr.gael.drb.impl.xml.XmlNode.getValue() : " + e);
         }

         child = child.getNextSibling();
      }

      if (string != null)
      {
         return new fr.gael.drb.value.String(string);
      }
      else
      {
         return null;
      }

   }

   /**
    * Get the namespace bindings.
    * 
    * @return The namespace bindings.
    */
   public Namespace getNamespaceBindings()
   {
      final Namespace namespace = new Namespace();
      namespace.bind(XmlNode.XML_PREFIX, XmlNode.XML_NAMESPACE);
      namespace.bind(XmlNode.XMLNS_PREFIX, XmlNode.XMLNS_NAMESPACE);
      /**
       * DOM attribute list. This list is composed of the attributes of the
       * current wrapped DOM node.
       */
      final NamedNodeMap dom_attr_list = this.node.getAttributes();

      /**
       * The DOM attribute. This attribute is the current one in the processing
       * loop.
       */
      Attr dom_attr = null;

      /**
       * Value of the DOM attribute. This value is a string that corresponds to
       * the value of the current DOM Attribute.
       */
      String dom_attr_value = null;

      /**
       * Name of the DOM attribute. This value is a string that corresponds to
       * the name of the current DOM Attribute.
       */
      String dom_attr_name = null;

      /**
       * Checks the current node has attributes. This checking will be
       * consolidated during the next processing loop. Yet may errors are
       * possible within this loop.Therefore even if the DOM attribute list is
       * not null and contains items, the ouput attribute list may remain null.
       */
      if ((dom_attr_list != null) && (dom_attr_list.getLength() > 0))
      {
         final int dom_attr_count = dom_attr_list.getLength();

         for (int iattr = 0; iattr < dom_attr_count; iattr++)
         {
            try
            {
               dom_attr = (Attr) dom_attr_list.item(iattr);

               if (dom_attr == null)
               {
                  logger.error("XmlNode.getNamespaceBindings() : Warning : "
                        + "cannot get attribute #" + (iattr + 1) + ".");
                  continue;
               }

               dom_attr_value = dom_attr.getNodeValue();

               if (dom_attr_value == null)
               {
                  logger
                        .error("XmlNode.getNamespaceBindings : Warning : "
                              + "cannot get value of attribute #" + (iattr + 1)
                              + ".");
                  continue;
               }

               dom_attr_name = dom_attr.getLocalName();

               if (dom_attr_name == null)
               {
                  logger.error("XmlNode.getNamespaceBindings() : Warning : "
                        + "cannot get name of attribute #" + (iattr + 1) + ".");
                  continue;
               }

               /**
                * Discards attributes named or prefixed by xmlns.
                */
               String attr_prefix =
                  fr.gael.drb.xsd.Namespace.toPrefix(dom_attr.getNodeName());

               if (attr_prefix == null)
               {
                  attr_prefix = dom_attr.getPrefix();
               }

               if (XMLNS_PREFIX.equals(dom_attr.getNodeName()))
               {
                  namespace.setDefaultNamespaceURI(dom_attr_value);
               }
               else if (XMLNS_PREFIX.equals(attr_prefix))
               {
                  namespace.bind(dom_attr_name, dom_attr_value);
               }
            }
            catch (final DOMException e)
            {
               logger.error("fr.gael.drb.impl.xml.XmlNode.getValue() : "
                     + "Cannot get attribute #" + iattr + "value.");
               logger.error("fr.gael.drb.impl.xml.XmlNode.getValue() : " + e);
            }
         }

      }

      return namespace;
   }

   /**
    * The attributes of the current node. Scope of this function is to extract
    * the attributes provided by the wrapped node (i.e. supported by DOM) and
    * transform them in some item and list compliant with DRB API. Because le
    * DOM nodes (i.e. the current is considered as an ELEMENT_NODE) have not
    * always attributes, or because of processing errors,the list may contain
    * less than the effective document node or this list may not exist. The
    * operation never returns empty list but null reference. All the exceptions
    * raised during the processing are catched but not propagated. The naming
    * convention wihtin this source code considers the dom_attr_xxx and the
    * attr_xxx variables. The dom_attr_xxx are the variables related to the
    * wrapped DOM node (i.e. the one handled by DOM) and the attr_xxx deal with
    * the DRB variable expected in output of this operation.
    * 
    * @return The list of attribute owned by the current node.
    */
   public final DrbAttributeList getAttributes()
   {

      /**
       * DOM attribute list. This list is composed of the attributes of the
       * current wrapped DOM node.
       */
      final NamedNodeMap dom_attr_list = this.node.getAttributes();

      /**
       * The DOM attribute. This attribute is the current one in the processing
       * loop.
       */
      Attr dom_attr = null;

      /**
       * Value of the DOM attribute. This value is a string that corresponds to
       * the value of the current DOM Attribute.
       */
      String dom_attr_value = null;

      /**
       * Name of the DOM attribute. This value is a string that corresponds to
       * the name of the current DOM Attribute.
       */
      String dom_attr_name = null;

      /**
       * The output attribute list. This list is the collection of DrbAttributes
       * in output. This list may remain null in the processing if no DOM
       * attribute is retreived.
       */
      DrbDefaultAttributeList attr_list = null;

      /**
       * Output attribute. A reference to one DrbAttriubte in output. This
       * object is used to create the collection of attributes in output.
       */
      DrbDefaultAttribute attr = null;

      /**
       * Value of the output attribute. This value correspond to the string
       * value of the curren DOM attribute. This object is used to create the
       * current DrbAttribute.
       */
      fr.gael.drb.value.String attr_value = null;

      /**
       * Checks the current node has attributes. This checking will be
       * consolidated during the next processing loop. Yet may errors are
       * possible within this loop.Therefore even if the DOM attribute list is
       * not null and contains items, the ouput attribute list may remain null.
       */
      if ((dom_attr_list != null) && (dom_attr_list.getLength() > 0))
      {
         final int dom_attr_count = dom_attr_list.getLength();

         for (int iattr = 0; iattr < dom_attr_count; iattr++)
         {
            try
            {
               dom_attr = (Attr) dom_attr_list.item(iattr);

               if (dom_attr == null)
               {
                  logger.error("XmlNode.getAttributes() : Warning : "
                        + "cannot get attribute #" + (iattr + 1) + ".");
                  continue;
               }

               dom_attr_value = dom_attr.getNodeValue();

               if (dom_attr_value == null)
               {
                  logger
                        .error("XmlNode.getAttributes() : Warning : "
                              + "cannot get value of attribute #" + (iattr + 1)
                              + ".");
                  continue;
               }

               dom_attr_name = dom_attr.getLocalName();

               if (dom_attr_name == null)
               {
                  logger.error("XmlNode.getAttributes() : Warning : "
                        + "cannot get name of attribute #" + (iattr + 1) + ".");
                  continue;
               }

               attr_value = new fr.gael.drb.value.String(dom_attr_value);

               if (attr_value == null)
               {
                  logger.error("XmlNode.getAttributes() : Warning : "
                        + "cannot build attribute #" + (iattr + 1)
                        + " value string.");
                  continue;
               }

               /**
                * Discards attributes named or prefixed by xmlns.
                */
               String attr_prefix =
                  fr.gael.drb.xsd.Namespace.toPrefix(dom_attr.getNodeName());

               if (attr_prefix == null)
               {
                  attr_prefix = dom_attr.getPrefix();
               }

               if ((XMLNS_PREFIX.equals(attr_prefix))
                     || (XMLNS_PREFIX.equals(dom_attr_name)))
               {
                  continue;
               }

               /**
                * Creates output attribute.
                */
               attr =
                  new DrbDefaultAttribute(dom_attr_name, attr_value, dom_attr
                        .getSpecified(), this);

               final String attr_uri = dom_attr.getNamespaceURI();
               attr.setNamespaceURI(attr_uri);

               if (attr_list == null)
               {
                  attr_list = new DrbDefaultAttributeList();
               }

               attr_list.add(attr);

            }
            catch (final DOMException e)
            {
               logger.error("fr.gael.drb.impl.xml.XmlNode.getValue() : "
                     + "Cannot get attribute #" + iattr + "value.");
               logger.error("fr.gael.drb.impl.xml.XmlNode.getValue() : " + e);
            }
         }

         return attr_list;
      }
      else
      {
         return null;
      }
   }

   /**
    * The parent of the current node. This operation uses the getParentNode()
    * provided by the DOM node. The parent may not exist for several reasons.
    * For instance root nodes as well as just created onces have no parent
    * node.If the current node is the root node of the XML document,the base
    * node (the one of the underlying implementation) is returned.
    * 
    * @return A reference to the parent node if any or null otherwise.
    */
   public DrbNode getParent()
   {
      final Node parent = this.node.getParentNode();

      if ((parent != null) && (parent.getNodeType() == Node.ELEMENT_NODE))
      {
         return new XmlNode((Element) parent, this.document);
      }
      else
      {
         return this.document;
      }
   }

   /**
    * The children of the current node. This operation filters all the DOM
    * children and selects only the XML ELEMENT ones. All other node types are
    * discarded.
    * 
    * @return The list of children if any or null otherwise.
    */
   public DrbNodeList getChildren()
   {
      final DrbDefaultNodeList list = new DrbDefaultNodeList();

      Node child = this.node.getFirstChild();

      while (child != null)
      {
         if (child.getNodeType() == Node.ELEMENT_NODE)
         {
            list.add(new XmlNode((Element) child, this.document));
         }

         child = child.getNextSibling();
      }

      if (list.size() == 0)
      {
         return null;
      }
      else
      {
         return list;
      }
   }

   /**
    * The content of the current node. Returns a sequence of nodes and atomic
    * values.
    * 
    * @return The content of this node.
    */
   public DrbSequence getContent()
   {
      final DrbDefaultSequence list = new DrbDefaultSequence();

      Node child = this.node.getFirstChild();

      while (child != null)
      {
         if (child.getNodeType() == Node.ELEMENT_NODE)
         {
            list.addItem(new XmlNode((Element) child, this.document));
         }
         else if (child.getNodeType() == Node.TEXT_NODE)
         {
            final String text = child.getNodeValue();
            if ((text != null) && (text.trim().length() > 0))
            {
               list.addItem(new fr.gael.drb.value.String(text.trim()));
            }
         }
         else
         {
            list.addItem(new XmlItem(child));
         }
         child = child.getNextSibling();
      }

      if (list.size() == 0)
      {
         return null;
      }
      else
      {
         return list;
      }
   }

   /**
    * Tests if the current node has any child. This operation cannot use
    * directly the hasChildNodes() specified by DOM because it has to count the
    * XML ELEMENT nodes and discard all others in is accounting. The operation
    * delegates the selection to the getChildren().
    * 
    * @return true if the node has at least one ELEMENT node and false
    *         otherwise.
    */
   public boolean hasChild()
   {
      if (this.getFirstChild() != null)
      {
         return true;
      }
      else
      {
         return false;
      }
   }

   /**
    * Returns an occurence of child matching a specific name. The occurence
    * number starts from 1.
    * 
    * @param name The name to match.
    * @param occurence The occurence number of the desired child.
    * @return A reference to the child or null is not found.
    */
   public DrbNode getNamedChild(final String name, final int occurence)
   {
      /**
       * Checks parameters.
       */
      if ((name == null) || (occurence <= 0))
      {
         logger.error("XmlNode.getNamedChild(): Invalid parameters.");
         return null;
      }

      /**
       * Loop for the occurence of a matching child.
       */
      Node child = this.node.getFirstChild();
      int current_occurence = 0;

      /**
       * Search forward the first child node of type ELEMENT.
       */
      while (child != null)
      {
         if ((child.getNodeType() == Node.ELEMENT_NODE)
               && name.equals(child.getLocalName()))
         {
            current_occurence = current_occurence + 1;

            if (current_occurence == occurence)
            {
               return new XmlNode((Element) child, this.document);
            }
         }

         child = child.getNextSibling();
      }

      return null;
   }

   /**
    * The first child of the current node. This operation looks for the first
    * occurence of ELEMENT node in the node and return it. It was not possible
    * to use directly the getFirstChild() operation specified by DOM because it
    * is necessary to filter the ELEMENT nodes and discard al other types.
    * 
    * @return A reference to the first child or null if none.
    */
   public DrbNode getFirstChild()
   {
      return this.getChildAt(0);
   }

   /**
    * The last child of the curren node. This operation looks for the last
    * occurence of ELEMENT node in the node and return it. It was not possible
    * to use directly the getLastChild() operation specified by DOM because it
    * is necessary to filter the ELEMENT nodes and discard al other types.
    * 
    * @return A reference to the last child or null is none.
    */
   public DrbNode getLastChild()
   {
      Node child = this.node.getLastChild();

      /**
       * Search backward the first child node of type ELEMENT.
       */
      while (child != null)
      {
         if (child.getNodeType() == Node.ELEMENT_NODE)
         {
            return new XmlNode((Element) child, this.document);
         }

         child = child.getPreviousSibling();
      }

      return null;
   }

   /**
    * The child located at a specific position. The provided position starts
    * from 0.It is important to consider the index as a counter among ELEMENT
    * nodes and not among the overall DOM nodes. All other types are not
    * accounted in the index.
    * 
    * @param index the index of the child node to find
    * @return A reference to the node at the given index if any and null
    *         oterwise.
    */
   public DrbNode getChildAt(final int index)
   {
      Node child = this.node.getFirstChild();

      int counter = 0;

      while (child != null)
      {
         if (child.getNodeType() == Node.ELEMENT_NODE)
         {
            if (counter == index)
            {
               return new XmlNode((Element) child, this.document);
            }

            counter += 1;
         }

         child = child.getNextSibling();
      }

      return null;
   }

   /**
    * Number of children. This operation counts the number of ELEMENT nodes
    * children of the current one. All other types are discarted in the
    * accounting.
    * 
    * @return The number of children.
    */
   public int getChildrenCount()
   {
      Node child = this.node.getFirstChild();

      int counter = 0;

      while (child != null)
      {
         if (child.getNodeType() == Node.ELEMENT_NODE)
         {
            counter += 1;
         }

         child = child.getNextSibling();
      }

      return counter;
   }

   /**
    * The previous sibling of the current node. The previous sibling is the
    * first one of type ELEMENT.
    * 
    * @return A reference to the previous sibling if any or null otherwise.
    */
   public DrbNode getPreviousSibling()
   {
      Node sibling = this.node.getPreviousSibling();

      /**
       * Looks backward for first occurence of ELEMENT node.
       */
      while (sibling != null)
      {
         if (sibling.getNodeType() == Node.ELEMENT_NODE)
         {
            return new XmlNode((Element) sibling, this.document);
         }
         sibling = sibling.getPreviousSibling();
      }

      return null;
   }

   /**
    * The next sibling of the current node. This sibling is the next one of type
    * ELEMENT. All other types are discarded during the search.
    * 
    * @return A reference to the next sibling if any and null otherwise.
    */
   public DrbNode getNextSibling()
   {
      Node sibling = this.node.getNextSibling();

      /**
       * Looks forward for first occurence of ELEMENT node.
       */
      while (sibling != null)
      {
         if (sibling.getNodeType() == Node.ELEMENT_NODE)
         {
            return new XmlNode((Element) sibling, this.document);
         }
         sibling = sibling.getNextSibling();
      }

      return null;
   }

   /**
    * Performs any pending changes. This methods forces the underlying
    * implementation to perform all changes. The current node may use a buffer
    * for caching input/output operations. In that case, this method will write
    * the node to the system ressource.
    */
   public void flush()
   {
      if (this.document != null)
      {
         final DrbNode root_node = this.document.getFirstChild();
         final OutputStream output_stream =
            (OutputStream) this.document.getImpl(OutputStream.class);
         if ((output_stream != null) && (root_node != null))
         {
            XmlWriter.writeXML(root_node, output_stream);
         }
      }
   }

   /**
    * String representqtion of the object. This operation overrides the default
    * one to set the string representation to the name of the node.
    * 
    * @return The name of the node.
    */
   public String toString()
   {
      final ByteArrayOutputStream stream = new ByteArrayOutputStream();

      XmlFactory.writeXML(this, stream);

      return stream.toString();
   }

   /**
    * Changes the value of the node. This operation sets a new value of the
    * current node. This value is converted to text through the toString()
    * method. If the cast is not possible the operation raises an
    * UnsupportedOperationException. If the document has write permission the
    * value is updated in the underlying file in order to persist among
    * sessions. It is therefore possible that this operation consumes a variable
    * amount of time.
    * <p>
    * <b>Important note:</b> The implementation will rewrite the entire file
    * with the default XmlWritter. Some formatting may be lost depending on the
    * capabilties of the encoder. It will support at least: Element, Attribute,
    * Text and Namespace information. The whitespace and data not exposed in
    * DrbNode will be definitly lost.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node changed event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node. The called operation is
    * the nodesChanged() of the listeners.
    * </p>
    * 
    * @param value The new value of the node.
    * @return The effectivelly assigned value.The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested assignment for
    *            any reason.
    */
   public Value setValue(final Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      final NodeList list_child = this.node.getChildNodes();

      if (list_child != null)
      {
         // Removed all text nodes
         for (int ichild = 0; ichild < list_child.getLength(); ichild++)
         {
            final Node nodeChild = list_child.item(ichild);

            if ((nodeChild.getNodeType() == Node.TEXT_NODE)
                  || (nodeChild.getNodeType() == Node.CDATA_SECTION_NODE))
            {
               this.node.removeChild(nodeChild);
            }
         }
      }

      // Replace by the new value
      if (value != null)
      {
         final Document doc = this.node.getOwnerDocument();
         Node text = null;
         final String val = value.toString();
         if (!val.trim().equals(val) || val.startsWith(" "))
         {
            text = doc.createCDATASection(val);
         }
         else
         {
            text = doc.createTextNode(val);
         }
         this.node.appendChild(text);
      }

      this.flush();
      this.nodesChanged(new DrbNodesChangeEvent(this));

      return value;
   }

   /**
    * Set the attribute list of a node. If some attributes are already attached
    * to the current node they are first removed and then replaced by the new
    * ones. However the operation checks the compatibility of the passed
    * attribute according to the current implementation. The operation does
    * nothing if the compatibility check fails.
    * <p>
    * <b>Warning:</b> The input attributes may be duplicated or re-instanciated
    * according to the targetted implementation. References to the effectively
    * inserted attributes can be reteived from the getAttributes() operation of
    * the DrbNode. It is highly recommended to discard the references to the
    * input attribuets if not mandatory.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept attribute changes. For instance it may not be possible to change
    * the size attribute of a file through this operation with would meant a
    * effective file resize that is not really relevant without additional data.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node.The called operation is the
    * nodesChanged() of the listeners.
    * </p>
    * 
    * @param attributes A reference to the new attribute list.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the attribute list is null. This exception may be
    *            overriden by an UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested attribute changes
    *            for any reason.
    */
   public void setAttributes(final DrbAttributeList attributes)
         throws NullPointerException, UnsupportedOperationException
   {

      if (attributes == null)
      {
         throw new NullPointerException("XmlNode.setAttributes: "
               + "null attribute list!");
      }

      if (!(this.node instanceof Element))
      {
         throw new UnsupportedOperationException("XmlNode.setAttributes "
               + ": not an element");
      }

      /**
       * DOM attribute list. This list is composed of the attributes of the
       * current wrapped DOM node.
       */
      final NamedNodeMap dom_attr_list = this.node.getAttributes();

      /**
       * The DOM attribute. This attribute is the current one in the processing
       * loop.
       */
      Attr dom_attr = null;

      /**
       * The new attribute
       */
      DrbAttribute new_attr = null;

      /**
       * The new string value to be set
       */
      String new_attr_value = null;

      /**
       * The DOM element
       */
      final Element element = this.node;

      /**
       * Checks the current node has attributes. This checking will be
       * consolidated during the next processing loop. Yet may errors are
       * possible within this loop.
       */
      if (dom_attr_list != null)
      {
         final int dom_attr_count = dom_attr_list.getLength();

         for (int iattr = 0; iattr < dom_attr_count; iattr++)
         {
            // Retreiving of old attribut
            dom_attr = (Attr) dom_attr_list.item(0);

            // Removing this attribut
            element.removeAttributeNode(dom_attr);
         } // loop on attributes : for (int iattr = 0; iattr < ...
      }

      for (int iattr = 0; iattr < attributes.getLength(); iattr++)
      {
         // Retreiving of new attribut
         new_attr = attributes.item(iattr);

         // Retreiving of the value of the new attribut
         new_attr_value = new_attr.getValue().toString();

         if (new_attr_value == null)
         {
            logger.error("XmlNode.getAttributes() : Warning : "
                  + "cannot get value of attribute #" + (iattr + 1) + ".");
            continue;
         }

         // Retreiving of the qualified name of the new attribut
         final String new_attr_qualifiedName = new_attr.getName();

         if (new_attr_qualifiedName == null)
         {
            logger.error("XmlNode.getAttributes() : Warning : "
                  + "cannot get qualified name of attribute #" + (iattr + 1)
                  + ".");
            continue;
         }

         // Retreiving of the name of the new attribut
         final String new_attr_name_space = new_attr.getNamespaceURI();

         // Inserting the new attribut
         element.setAttributeNS(new_attr_name_space, new_attr_qualifiedName,
               new_attr_value);
      }

      this.flush();
      this.nodesChanged(new DrbNodesChangeEvent(this));
   }

   /**
    * Changes the name of the node. The passed name may be an empty string but
    * never a null reference. The change is persistant such as further instance
    * of a same node (even in different sessions) will have this new name. If
    * the implementation does not suppot the rename operation it is supposerd to
    * throw a UnsupportedOperationException.
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current standing also as the source of the event. The called
    * opetation is the nodesChanged() of the listeners.
    * </p>
    * 
    * @param name Reference to the new name.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested rename for any
    *            reason (e.g. specific case or general incapability).
    * @throws NullPointerException This exception is raised when the passed name
    *            is a null reference.This exception may be overriden by an
    *            UnsupportedOperationException.
    */
   public void rename(final String name) throws NullPointerException,
         UnsupportedOperationException
   {

      /**
       * Checks the reference to the input name
       */
      if (name == null)
      {
         throw new NullPointerException("XmlNode.rename() : "
               + "The reference to the new name is null.");
      }

      final NodeList list_child = this.node.getChildNodes();

      final Document myDoc = this.node.getOwnerDocument();
      final Element newNode =
         myDoc.createElementNS(this.node.getNamespaceURI(), name);
      final NamedNodeMap dom_attr_list = this.node.getAttributes();

      final Node parent = this.node.getParentNode();
      parent.replaceChild(newNode, this.node);

      final int num_child = list_child.getLength();
      for (int ichild = 0; ichild < num_child; ichild++)
      {
         final Node nodeChild = list_child.item(0);
         newNode.appendChild(nodeChild);
      }

      this.node = newNode;

      if ((dom_attr_list != null) && (dom_attr_list.getLength() > 0))
      {
         final int dom_attr_count = dom_attr_list.getLength();

         for (int iattr = 0; iattr < dom_attr_count; iattr++)
         {
            final Attr dom_attr = (Attr) dom_attr_list.item(iattr);
            newNode.setAttributeNS(dom_attr.getNamespaceURI(), dom_attr
                  .getNodeName(), dom_attr.getNodeValue());
         }
      }

      this.flush();

      this.nodesChanged(new DrbNodesChangeEvent(this));
   }

   /**
    * Sets a namespace resource identifier. The new namespace identifier shall
    * not be null.
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept namespace changes. For instance it may not be possible to change
    * the namespace of a file that is basically fixed.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node.The called operation is the
    * nodesChanged() of the listeners.
    * </p>
    * 
    * @param namespace_uri A reference to the new namespace identifier.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the new namespace identifier is null.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested namespace change
    *            for any reason (e.g. by definition or in the specific case).
    */
   public void setNamespaceURI(final String namespace_uri)
         throws NullPointerException, UnsupportedOperationException
   {
      final NodeList list_child = this.node.getChildNodes();

      final Document myDoc = this.node.getOwnerDocument();
      final Element newNode =
         myDoc.createElementNS(namespace_uri, this.node.getNodeName());
      final NamedNodeMap dom_attr_list = this.node.getAttributes();

      final Node parent = this.node.getParentNode();
      parent.replaceChild(newNode, this.node);

      final int num_child = list_child.getLength();
      for (int ichild = 0; ichild < num_child; ichild++)
      {
         final Node nodeChild = list_child.item(0);
         newNode.appendChild(nodeChild);
      }

      this.node = newNode;

      if ((dom_attr_list != null) && (dom_attr_list.getLength() > 0))
      {
         final int dom_attr_count = dom_attr_list.getLength();

         for (int iattr = 0; iattr < dom_attr_count; iattr++)
         {
            final Attr dom_attr = (Attr) dom_attr_list.item(iattr);
            newNode.setAttributeNS(dom_attr.getNamespaceURI(), dom_attr
                  .getNodeName(), dom_attr.getNodeValue());
         }
      }

      this.flush();

      this.nodesChanged(new DrbNodesChangeEvent(this));
   }

   /**
    * Replaces a child of the current node. This operation replaces a child in
    * the current children list by a new one The operation aborts when the index
    * is out of bound (index < 0 || index > size). In case of error, the
    * implementation has to restore the initial situation. It is therefore
    * recommended for any implementation to check the consistency prior to
    * perform the replacement.
    * <p>
    * <b>Warning:</b> The replacing node may be duplicated or re-instanciated
    * according to the targetted implementation.A reference to the effectively
    * replacing node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned one.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to insert a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the new node and the source is the current node. The called operation
    * is the structureChanged() of the listeners.
    * </p>
    * 
    * @param index Index of the node to be replaced. This index starts at 0 and
    *           shall be less than the number of children.
    * @param new_node A reference to the node that replaces the old one.
    * @return A reference to the effectivelly replacing node.This reference may
    *         differ from the new_node parameter.
    * @throws NullPointerException This exception is raised when the reference
    *            to the new node is null. This exception may be overriden by a
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested replace for any
    *            reason. In addition if the old_node is not retreived in the
    *            current children list, this exception is also raised.
    */
   public DrbNode replaceChild(final int index, final DrbNode new_node)
         throws NullPointerException, IndexOutOfBoundsException,
         UnsupportedOperationException
   {

      if (new_node == null)
      {
         throw new NullPointerException("XmlNode.replaceChild() :"
               + " Reference to the node is null.");
      }

      /**
       * Checks the index is in bound.
       */
      if ((index < 0) || (index > this.getChildrenCount()))
      {
         throw new IndexOutOfBoundsException("XmlNode.replaceChild() : "
               + "Index #" + index);
      }

      // TODO attention ecriture dans le fichier
      // quand on fait removeChild --> a changer

      /**
       * Deletes file.
       */
      this.removeChild(index);

      final DrbNode replacing_node = this.insertChild(new_node, index);

      /**
       * Returns the replacing node.
       */
      return replacing_node;
   }

   /**
    * Format an XML string. All specific characters will be despecialized by
    * adding the specified notation.
    * 
    * @param str the string to format
    * @return a string suitable for XML queries.
    */
   public static String toXML(final String str)
   {
      if (str == null)
      {
         return null;
      }

      final char[] str_array = str.toCharArray();

      String xml_str = "";
      for (int index = 0; index < str_array.length; index++)
      {

         if ((str_array[index] == '&'))
         {
            xml_str = xml_str + "&amp;";
         }
         else if ((str_array[index] == '"'))
         {
            xml_str = xml_str + "&quot;";
         }
         else if ((str_array[index] == '\''))
         {
            xml_str = xml_str + "&apos;";
         }
         else if ((str_array[index] == '<'))
         {
            xml_str = xml_str + "&lt;";
         }
         else if ((str_array[index] == '>'))
         {
            xml_str = xml_str + "&gt;";
         }
         else if ((str_array[index] == '\n'))
         {
            xml_str = xml_str + "&#10;";
         }
         else
         {
            xml_str = xml_str + String.valueOf(str_array[index]);
         }

      }

      return xml_str;
   }

   /**
    * Removes an existing child. The child at the given index is removed from
    * the children list of the current node. The child is not modified by this
    * operation. At the child point of view it keeps the same parent or any
    * common association depending on the implementation. However at the parent
    * (i.e. the current node) point of view the removed node is completely
    * dismissed and will never be re-instaciated from constructor operations
    * (e.g. getFirstChild(), etc. ). The index of the child to be removed has to
    * correspond to an existing children index. If the index is less than zero
    * or greater or equal to the current number of children, an exception is
    * thrown.
    * <p>
    * This operation takes into account the removal by updating the sibling
    * associations of the children nodes prior and next to the removed one. The
    * indicies of the nodes next to the removed one are decresed of one. Their
    * parents as well as their contents are left unchanged.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the removed node and the source is the current node.The called
    * operation is the nodesRemoved() of the listeners.
    * </p>
    * 
    * @param index Index of the child to be removed.
    * @throws IndexOutOfBoundsException This exception is raised when the passed
    *            index is less than zero or greater or equal to the current
    *            number of children.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested removal for any
    *            reason.
    */
   public void removeChild(final int index) throws IndexOutOfBoundsException,
         UnsupportedOperationException
   {

      final int children_count = this.getChildrenCount();

      /**
       * Checks the index is in bound.
       */
      if ((index < 0) || (index > children_count))
      {
         throw new IndexOutOfBoundsException("XmlNode.removeChild(" + index
               + ") : " + "Index #" + index + " out of bound (children count ="
               + children_count + ")");
      }

      final NodeList list_child = this.node.getChildNodes();
      int index_child = -1;

      for (int ichild = 0; ichild < list_child.getLength(); ichild++)
      {
         final Node nodeChild = list_child.item(ichild);

         if (nodeChild.getNodeType() == Node.ELEMENT_NODE)
         {
            index_child++;
         }

         if (index_child == index)
         {
            this.node.removeChild(nodeChild);
         }
      }

      this.flush();

      this.nodesRemoved(new DrbNodesChangeEvent(this));
   }

   /**
    * Inserts a child at a given position. The passed node is inserted in the
    * list of children at the given position The position is the expected index
    * of the node after insertion. All the previous children from the aimed
    * position to the end of the list are shift to the end of the new children
    * list (i.e. their indices are shifted up of 1). If the given index is out
    * of the children bounds and therefore less than zero and greater or equal
    * to the current number of children,the operation raises an exception. An
    * index equal to the current number of children is allowed and the operation
    * is therefore equivalent to appendChild().
    * <p>
    * If the node has been inserted within the children list, the next sibling
    * indicies are increased of one. In addition the assiociations between the
    * inserted node and it previous and next siblings are updated (if any).
    * </p>
    * <p>
    * <b>Warning:</b> The inserted node may be duplicated or re-instanciated
    * according to the targetted implementation. A reference to the effectively
    * inserted node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned node.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to insert a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Case of unordered or specifically ordered implementations:</b> If the
    * implementation does not support ordered children or has specific ordering
    * rules, the node is inserted without taking into account the requested
    * index passed in parameter. For instance it may not be possible to impose
    * the file order in a directory: it generally depends on the lexicographical
    * order of the node names or their creation date.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the inserted node and the source is the current node. The called
    * operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param new_node A reference to the node to be inserted.
    * @param index The expected index of the node after the insertion.
    * @return A reference to the effectively inserted node. This reference may
    *         differ from the input one.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference. This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passe
    *            index is less than zero or if it is greater or equal to the
    *            number of children in the number of children prior the call
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested insertion for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbNode insertChild(final DrbNode new_node, final int index)
         throws NullPointerException, UnsupportedOperationException,
         IndexOutOfBoundsException
   {
      /**
       * Check parameters
       */
      final int children_count = this.getChildrenCount();
      if ((new_node == null) || (index < 0) || (index > children_count))
      {
         throw new IndexOutOfBoundsException("XmlNode.insertChild() : "
               + "Index #" + index);
      }

      /**
       * Search the node at the specified index
       */
      final NodeList dom_child = this.node.getChildNodes();

      int drbIndex = -1;
      int domIndex = -1;
      for (domIndex = 0; domIndex < dom_child.getLength(); domIndex++)
      {
         // We count only element nodes.
         if (dom_child.item(domIndex).getNodeType() == Node.ELEMENT_NODE)
         {
            drbIndex++;
         }
         if (drbIndex == index)
         {
            break;
         }
      }

      Node nodeAfter = null;
      if (domIndex < dom_child.getLength())
      {
         nodeAfter = dom_child.item(domIndex);
      }

      /**
       * Duplicate the provided node as a DOM element. Insert or Append this
       * node at the specified index.
       */

      final Document myDoc = this.node.getOwnerDocument();
      final String name = new_node.getName();
      final String ns_uri = new_node.getNamespaceURI();

      final Element new_dom_node = myDoc.createElementNS(ns_uri, name);

      if (nodeAfter != null)
      {
         this.node.insertBefore(new_dom_node, nodeAfter);
      }
      else
      {
         this.node.appendChild(new_dom_node);
      }

      final XmlNode new_drb_node = new XmlNode(new_dom_node, this.document);

      // Set Attributes
      final DrbAttributeList new_drb_attributes = new_node.getAttributes();
      if (new_drb_attributes != null)
      {
         new_drb_node.setAttributes(new_drb_attributes);
      }

      // Set value
      final Value new_drb_value = new_node.getValue();

      if (new_drb_value != null)
      {
         new_drb_node.setValue(new_drb_value);
      }

      // Set children
      final DrbNodeList new_drb_children = new_node.getChildren();
      if (new_drb_children != null)
      {
         for (int ichild = 0; ichild < new_drb_children.getLength(); ichild++)
         {
            new_drb_node.appendChild(new_drb_children.item(ichild));
         }
      }

      this.flush(); // TBC

      final DrbDefaultNodeList node_list = new DrbDefaultNodeList();
      node_list.add(new_drb_node);
      this.nodesInserted(new DrbNodesChangeEvent(this, node_list));

      return new_drb_node;
   }

   /**
    * Appends a child at the end of the children list. The passed node is
    * inserted in the list of children at the end of the current list.
    * <p>
    * <b>Warning:</b> The appended node may be duplicated or re-instanciated
    * according to the targetted implementation. A reference to the effectively
    * appended node is returned by the operation. It is highly recommended to
    * discard the reference to the input node if not mandatory and to reference
    * the returned node.
    * </p>
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept any kind of node For instance it may not be possible to append a
    * node wrapping a file in an XML document. The documentation of the
    * implementation shall describe its specific strategy.
    * </p>
    * <p>
    * <b>Case of unordered or specifically ordered implementations:</b> If the
    * implementation does not support ordered children or has specific ordering
    * rules, the node may not be appended but only inserted according to these
    * rules. For instance it may not be possible to impose the file order in a
    * directory: it generally depends on the lexicographical order of the node
    * names or their creation date.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node change event when the
    * implementation is a node change producer. The node affected by the change
    * is the appended node and the source is the current node. The called
    * operation is the nodesInserted() of the listeners.
    * </p>
    * 
    * @param nodes A reference to the node to be appended.
    * @return A reference to the effectivelly appended node. This reference may
    *         differ from the input one.
    * @throws NullPointerException This exception is raised when the passed node
    *            a null reference.This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested append for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbNode appendChild(final DrbNode nodes) throws NullPointerException,
         UnsupportedOperationException
   {
      final int child_count = this.getChildrenCount();
      return this.insertChild(nodes, child_count);
   } // appendChild
} // XmlNode
