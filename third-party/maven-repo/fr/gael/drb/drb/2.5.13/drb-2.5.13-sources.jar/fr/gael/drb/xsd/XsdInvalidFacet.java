/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.value.Value;

/**
 * Output of the XML-Schema facet validator.
 */
class XsdInvalidFacet extends XsdAbstractInvalid
{

   /**
    * The node value.
    */
   Value value;

   /**
    * The facet.
    */
   XsdFacet facet;

   /**
    * Build an XsdInvalidFacet
    * 
    * @param facet the facets
    * @param value the values
    */
   XsdInvalidFacet(final XsdFacet facet, final Value value)
   {
      this.facet = facet;
      this.value = value;
   } // XsdInvalidFacet

   /**
    * Returns a message describing the validation result.
    * 
    * @return a message describing the validation result.
    */
   public String getMessage()
   {
      String msg = "";

      if ((this.facet != null) && (this.value == null))
      {
         return "The value shall not be null";
      }
      else if (this.facet != null)
      {
         switch (this.facet.getId())
         {
            case XsdFacet.MIN_INCLUSIVE_ID:
               msg =
                  msg + "The value shall be greater than '"
                        + ((XsdMinInclusiveFacet) this.facet).getValue() + "'";
               break;
            case XsdFacet.MAX_INCLUSIVE_ID:
               msg =
                  msg + "The value shall be lower than '"
                        + ((XsdMaxInclusiveFacet) this.facet).getValue() + "'";
               break;
            case XsdFacet.MIN_EXCLUSIVE_ID:
               msg =
                  msg + "The value shall be strictly greater than '"
                        + ((XsdMinExclusiveFacet) this.facet).getValue() + "'";
               break;
            case XsdFacet.MAX_EXCLUSIVE_ID:
               msg =
                  msg + "The value shall be strictly lower than '"
                        + ((XsdMaxExclusiveFacet) this.facet).getValue() + "'";
               break;
            case XsdFacet.MIN_LENGTH_ID:
               msg =
                  msg + "The length of the value shall be greater than '"
                        + ((XsdMinLengthFacet) this.facet).getValue() + "'";
               break;
            case XsdFacet.MAX_LENGTH_ID:
               msg =
                  msg + "The length of the value shall be lower than '"
                        + ((XsdMaxLengthFacet) this.facet).getValue() + "'";
               break;
            case XsdFacet.LENGTH_ID:
               msg =
                  msg + "The length of the value shall equal to '"
                        + ((XsdLengthFacet) this.facet).getValue() + "'";
               break;
            case XsdFacet.PATTERN_ID:
               msg =
                  msg + "The value shall match the pattern '"
                        + ((XsdPatternFacet) this.facet).getValue() + "'";
               break;
            case XsdFacet.ENUMERATION_ID:
               msg =
                  msg + "The value shall be inside the enumeration "
                        + this.facet;
               break;
            default:
               msg = msg + "The value shall match the facet xs:"
                  + this.facet.getName();
               break;
         }
      }
      return msg;
   } // getMessage

   /**
    * Returns the component.
    * 
    * @return the component
    */
   public XsdComponent getComponent()
   {
      return this.facet;
   }

   /**
    * Replace the node value.
    * 
    * @param value The value
    */
   void setValue(final Value value)
   {
      this.value = value;
   }

} // XsdInvalidFacet
