/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import org.apache.log4j.Logger;

/**
 * Generic implementation of DrbAttributeList. This default implementation
 * extends an ArrayList provided by Java API. It is a generic mean to create a
 * list of attributes. If no specific operations are required to implement the
 * DrbAttributeList (e.g. filtering, caching, hashing, etc.). This class is a
 * simple way to handle a collection of attributes. Note : the add() or
 * equivalent operations of the ArrayList class have not been overrided to
 * insure they insert DrbAttribute intances. Some inconsistency may appear if no
 * care is taken while calling add() or equivalent operations.
 */
public class DrbDefaultAttributeList extends DrbDefaultSequence implements
      DrbAttributeList
{

   /**
    * Logger.
    */
   static private Logger logger =
      Logger.getLogger(DrbDefaultAttributeList.class);

   /**
    * Returns a specific item of the list. This operation wraps the
    * ArrayList.get() operation. The exception that ArrayList.get() can raise is
    * however traped and not propagated. In such case a message is written to
    * the error output and the operation returns null without throwing any
    * exception.
    * 
    * @param index The position of the item starting from 0 and not greater or
    *           equal to the item count in the list.
    * @return A reference to specified item or null if no such attribute.
    */
   public DrbAttribute item(final int index)
   {
      return (DrbAttribute) this.getItem(index);
   }

   /**
    * Returns the item matching a specific name. The name is a local name
    * without any prefix.
    * 
    * @param name The name to match.
    * @return A reference to specified items or null if no such attribute.
    */
   public DrbAttribute getNamedItem(final String name)
   {
      /**
       * Checks parameters.
       */
      if (name == null)
      {
         this.logger.error("DrbDefaultAttributeList.item(): "
               + "Invalid parameter (name=\"" + name + "\"");
         return null;
      }

      /**
       * Search the matching node.
       */
      String currentName = null;

      for (int iattr = 0; iattr < this.getLength(); iattr++)
      {
         final DrbAttribute currentAttribute =
            ((DrbAttribute) this.getItem(iattr));
         if (currentAttribute == null)
         {
            continue;
         }
         currentName = currentAttribute.getName();

         if ((currentName != null) && (currentName.equals(name)))
         {
            return currentAttribute;
         }
      }

      return null;
   }

   /**
    * Inserts a item at a given position. The passed item is inserted in the
    * list of children at the given position The position is the expected index
    * of the item after insertion. All the previous item from the aimed position
    * to the end of the list are shift to the end of the new sequence (i.e.
    * their indices are shifted up of 1). If the given index is out of the
    * sequence bounds and therefore less than zero and greater or equal to the
    * current number of items,the operation raises an exception. An index equal
    * to the current number of item is allowed and the operation is therefore
    * equivalent to an append.
    * 
    * @param index The expected index of the item after the insertion.
    * @param item A reference to the item to be inserted.
    * @return A reference to the a sequence containing the inserted node.
    * @throws NullPointerException This exception is raised when the passed item
    *            a null reference. This exception may be overriden by an
    *            UnsupportedOperationException.
    * @throws IndexOutOfBoundsException This exception is raised when the passe
    *            index is less than zero or if it is greater or equal to the
    *            number of item in the sequence prior the call
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested insertion for any
    *            reason (e.g. impossible in this current specific case or in
    *            general).
    */
   public DrbSequence addItem(final int index, final DrbItem item)
         throws NullPointerException, UnsupportedOperationException,
         IndexOutOfBoundsException
   {
      // Assuming that the specified item is a attribute, insert it into the
      // list
      try
      {
         super.addItem(index, item);
         return this;
      }
      // Otherwise we insert it into a default sequence
      catch (final ClassCastException e)
      {
         final DrbSequence newSequence = new DrbDefaultSequence(this);
         newSequence.addItem(index, item);
         return newSequence;
      }
   } // addItem

}// DrbDefaultAttributeList
