/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbItem;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbSequence;
import fr.gael.drb.impl.spi.DrbNodeSpi;

/**
 * Wraps a General Step expression of XQuery language.
 */
class GeneralStepExpression extends AbstractExpression
{
   /**
    * Logger
    */
   static private Logger logger = Logger.getLogger(GeneralStepExpression.class);

   /**
    * Child axis
    */
   static final short CHILD_AXIS = 1;

   /**
    * Descendant axis
    */
   static final short DESCENDANT_AXIS = 2;

   /**
    * Attribute axis
    */
   static final short ATTRIBUTE_AXIS = 3;

   /**
    * Self axis
    */
   static final short SELF_AXIS = 4;

   /**
    * Descendant or Self axis
    */
   static final short DESCENDANT_OR_SELF_AXIS = 5;

   /**
    * Following sibling axis
    */
   static final short FOLLOWING_SIBLING_AXIS = 6;

   /**
    * Following axis
    */
   static final short FOLLOWING_AXIS = 7;

   /**
    * Parent axis
    */
   static final short PARENT_AXIS = 8;

   /**
    * Ancestor axis
    */
   static final short ANCESTOR_AXIS = 9;

   /**
    * Preceding-sibling axis
    */
   static final short PRECEDING_SIBLING_AXIS = 10;

   /**
    * Preceding axis
    */
   static final short PRECEDING_AXIS = 11;

   /**
    * Ancestor or self axis
    */
   static final short ANCESTOR_OR_SELF_AXIS = 12;

   /**
    * The list of predicats to filter
    */
   private PredicatsListExpression predicatsList;

   /**
    * Axis of the step.
    */
   short axis;

   /**
    * Name of the step.
    */
   String name;

   /**
    * Filter of the step.
    */
   Expression filter = null;

   /**
    * Potential path to the schema. This path is used to retreive the XML Schema
    * to be loaded for accessing undescribed underlying data sources. As an
    * example, a binary data may, therefore not sef-described, requires external
    * description to be broken down in a DRB tree.
    */
   Expression schema;

   /**
    * Reference to the next General Step expression.
    */
   GeneralStepExpression nextStep = null;

   /**
    * Attribute indicator. This flag determine the type of step. Actually, in
    * the current implementation, most of the step are regarding nodes but
    * others may wrap attribute, as specified in the XQuery working draft.
    */
   boolean isAttributeStep = false;

   /**
    * Descendant indicator. This flag determine the presence of the descendant
    * step.
    */
   boolean isDescendantStep = false;

   /**
    * Builds a General Step expression with child axis.
    * 
    * @param token the token related to the current expression.
    * @param name node test name of the step.
    * @param schema potential expression locating a XML Schema attribute.
    */
   /*
    * public GeneralStepExpression(Token token, String name, Expression schema) {
    * this(token, name, CHILD_AXIS, schema); }
    */

   /**
    * Builds a General Step expression.
    * 
    * @param token the token related to the current expression.
    * @param name node test name of the step.
    * @param axis axis of the step.
    * @param schema potential expression locating a XML Schema attribute.
    */
   GeneralStepExpression(final Token token, final String name,
         final short axis, final Expression schema)
   {
      super("Axis Step", token);

      this.name = name;
      this.axis = axis;
      this.schema = schema;
      this.filter = null;
   }

   /**
    * Builds a General Spet expression.
    * 
    * @param filter the filter expression
    */
   public GeneralStepExpression(final Expression filter)
   {
      super("Filter Step", filter.getToken());

      this.name = null;
      this.schema = null;
      this.axis = CHILD_AXIS;
      this.filter = filter;
   }

   /**
    * Set the list of predicats
    * 
    * @param predicatsList The predicatsListExpression to set
    */
   public void setPredicatsList(final PredicatsListExpression predicatsList)
   {
      this.predicatsList = predicatsList;
   }

   /**
    * Asing a reference to the next step.
    * 
    * @param step reference to the next step.
    */
   public void setNextStep(final GeneralStepExpression step)
   {
      this.nextStep = step;
   }

   /**
    * Asign schema.
    * 
    * @param schema the schema to assign.
    */
   public void setSchema(final Expression schema)
   {
      this.schema = schema;
   }

   /**
    * Assign the type of general step.
    * 
    * @param flag true if the expression wraps an attrbite and false otherwise.
    */
   public void setIsAttributeStep(final boolean flag)
   {
      this.isAttributeStep = flag;
      if (flag)
      {
         this.axis = ATTRIBUTE_AXIS;
      }
   }

   /**
    * Assign the type of general step.
    * 
    * @param flag true if the expression wraps a descendant step and false
    *           otherwise.
    */
   public void setIsDescendantStep(final boolean flag)
   {
      this.isDescendantStep = flag;
   }

   /**
    * Get the descendant of a node
    * 
    * @param node an element
    * @return the descendant nodes.
    */
   private DrbSequence getDescendantOrSelf(final DrbNode node,
         final DrbDefaultSequence item_list)
   {
      item_list.addItem(node);

      final int count = node.getChildrenCount();
      for (int ichild = 0; ichild < count; ichild++)
      {
         this.getDescendantOrSelf(node.getChildAt(ichild), item_list);
      }
      return item_list;
   }

   /**
    * Evaluates the step.
    * 
    * @param context the dynamic evaluation context to consider.
    * @return the evaluated sequence.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {

      if (this.isDescendantStep)
      {
         /**
          * Matching node list.
          */
         final DrbDefaultSequence item_list = new DrbDefaultSequence();

         final DrbItem item = context.focus.getContextItem();
         if (item.getItemType() == DrbItem.NODE_ITEM)
         {
            final DrbDefaultSequence descendant_or_self =
               new DrbDefaultSequence();
            this.getDescendantOrSelf((DrbNode) item, descendant_or_self);
            final int descendant_count = descendant_or_self.getLength();

            for (int i = 0; i < descendant_count; i++)
            {
               /**
                * Creates an inner focus for child expression evaluation.
                */
               final DynamicContext inner_context = new DynamicContext(context);
               inner_context.focus
                     .setContextItem(descendant_or_self.getItem(i));
               inner_context.focus.setContextPosition(i + 1);
               inner_context.focus.setContextSize(descendant_count);

               final DrbSequence output_sequence =
                  this.evaluateStep(inner_context);
               for (int j = 0; j < output_sequence.getLength(); j++)
               {
                  item_list.addItem(output_sequence.getItem(j));
               }
            }
         }
         return item_list;
      }
      return this.evaluateStep(context);
   }

   /**
    * Evaluates the step.
    * 
    * @param context the dynamic evaluation context to consider.
    * @param item_list the output sequence
    * @return the evaluated sequence.
    */
   private DrbSequence evaluateStep(final DynamicContext context)
   {
      /**
       * Check the step has a name test.
       */
      if ((this.filter == null) && (this.name == null))
      {
         throw new DynamicException(this, "No name-test for general step");
      }

      /**
       * Creates an inner focus for schema expression evaluation.
       */
      final DynamicContext inner_context = new DynamicContext(context);

      /**
       * Detect wildcard name test.
       */
      boolean case_of_wildcard;

      if ("*".equals(this.name))
      {
         case_of_wildcard = true;
      }
      else
      {
         case_of_wildcard = false;
      }

      /**
       * Checks a context has been provided.
       */
      if (context == null)
      {
         throw new DynamicException(this, "Null dynamic context");
      }

      /**
       * Extract context node from the outer focus.
       */
      DrbItem item = context.focus.getContextItem();

      if (item == null)
      {
         throw new DynamicException(this, "Null context item");
      }

      if (item.getItemType() == DrbItem.VALUE_ITEM)
      {
         return new DrbDefaultSequence(item);
      }

      DrbNode base_node = null;
      if (item.getItemType() == DrbItem.NODE_ITEM)
      {
         base_node = (DrbNode) item;
      }

      /**
       * Initialize output sequence.
       */
      DrbDefaultSequence output_sequence = new DrbDefaultSequence();

      /**
       * Case of implementation change (schema provided).
       */
      if (this.schema != null)
      {
         if (item.getItemType() != DrbItem.NODE_ITEM)
         {
            throw new DynamicException(this,
                  "Cannot apply schema. The context item is not an element");
         }

         inner_context.focus.setContextItem(base_node.getParent());
         inner_context.focus.setContextPosition(1);
         inner_context.focus.setContextSize(1);

         /**
          * Evaluates schema expression and extract result node.
          */
         final DrbSequence schema_sequence =
            this.schema.evaluate(inner_context);

         if (schema_sequence == null)
         {
            throw new DynamicException(this,
                  "Error while evaluating the schema expression");
         }

         if (schema_sequence.getLength() > 1)
         {
            throw new DynamicException(this,
                  "The schema references to more than one item ("
                        + schema_sequence.getLength() + ")");
         }

         if (schema_sequence.getLength() < 1)
         {
            throw new DynamicException(this, "The schema references no element");
         }

         final DrbItem schema_item = schema_sequence.getItem(0);

         if (schema_item == null)
         {
            throw new DynamicException(this, "The schema item is null");
         }

         if (schema_item.getItemType() != DrbItem.NODE_ITEM)
         {
            throw new DynamicException(this,
                  "The schema item is not an element");
         }

         final DrbNode schema_node = (DrbNode) schema_item;

         /**
          * Opens the a new base node with respect to the provided schema.
          */
         try
         {
            final DrbNodeSpi spi_node = new DrbNodeSpi(base_node);
            spi_node.setSchema(schema_node);
            base_node = spi_node.getFirstChild();
            item = base_node;
         }
         catch (final Exception exception)
         {
            throw new DynamicException(this,
               "Error while openning node with respect to the schema \""
               + schema_node + "\" (" + exception.getMessage() + ")",
               exception);
         }
         /**
          * // The content of the schema-node is now filtered by the step
          * expression.
          */
      }

      /**
       * Matching node list.
       */
      DrbDefaultSequence item_list = new DrbDefaultSequence();

      /**
       * Case of attribute axis
       */
      if (this.isAttributeStep == true)
      {
         if (item.getItemType() == DrbItem.VALUE_ITEM)
         {
            throw new DynamicException(this,
                  "XP0020 - Context item is not a node");
         }

         // Returns the empty sequence if the context node is not an element
         if (item.getItemType() != DrbItem.NODE_ITEM)
         {
            return output_sequence;
         }

         if (case_of_wildcard)
         {
            final DrbAttributeList attribute_list = base_node.getAttributes();
            if (attribute_list != null)
            {
               for (int iattrb = 0; iattrb < attribute_list.getLength(); iattrb++)
               {
                  final DrbAttribute attribute = attribute_list.item(iattrb);
                  /**
                   * Verify attribute consistency.
                   */
                  if ((attribute == null) || (attribute.getName() == null))
                  {
                     logger.warn("The attribute #" + (iattrb + 1)
                           + " of context node (" + base_node
                           + ") is null or has  null name.");
                  }
                  output_sequence.add(attribute);
               }
            }
         }
         else
         {
            final DrbAttribute attribute = base_node.getAttribute(this.name);
            if (attribute != null)
            {
               output_sequence.add(attribute);
            }
         }
         // Apply predicates if any
         if (this.predicatsList.isEmpty())
         {
            item_list = output_sequence;
         }
         else
         {
            final int attr_count = output_sequence.getLength();
            for (int iattrb = 0; iattrb < attr_count; iattrb++)
            {
               final DrbItem attr = output_sequence.getItem(iattrb);
               // Set new context
               inner_context.focus.setContextItem(attr);
               inner_context.focus.setContextPosition(iattrb + 1);
               inner_context.focus.setContextSize(attr_count);

               // Test the predicates on this node
               if (Query.getEffectiveBooleanValue(this.predicatsList
                     .evaluate(inner_context)))
               {
                  item_list.addItem(attr);
               }
            }
         }
         output_sequence = new DrbDefaultSequence();
      }
      else
      /**
       * Case of axis step. The principle here is to first select the total list
       * of nodes regarded by the step, filtered by the predicates, and then to
       * propagate the evaluation to the sub-steps on a node per onde basis.
       */
      if (this.name != null)
      {
         if (item.getItemType() == DrbItem.VALUE_ITEM)
         {
            throw new DynamicException(this,
                  "XPTY0020 - Context item is not a node");
         }

         /**
          * Case of Self axis : ".".
          */
         // TODO: Qualifiers shall also be applied on "." and ".."
         if (this.axis == SELF_AXIS)
         {
            if (this.name.equals("."))
            {
               item_list.addItem(item);
            }
            else if (item.getItemType() == DrbItem.NODE_ITEM)
            {
               if (this.name.equals(((DrbNode) item).getName()))
               {
                  item_list.addItem(item);
               }
            }
            else if (item.getItemType() == DrbItem.ATTRIBUTE_ITEM)
            {
               if (this.name.equals(((DrbAttribute) item).getName()))
               {
                  item_list.addItem(item);
               }
            }
            else
            {
               throw new DynamicException(this,
                     "XPTY0020 - Context item is not an element nor an attribute");
            }

            if (this.nextStep == null)
            {
               return item_list;
            }
         }
         /**
          * Case Parent axis : ".."
          */
         else if (this.axis == PARENT_AXIS)
         {
            DrbNode parent_node = null;
            if (item.getItemType() == DrbItem.NODE_ITEM)
            {
               parent_node = base_node.getParent();
            }
            else if (item.getItemType() == DrbItem.ATTRIBUTE_ITEM)
            {
               parent_node = ((DrbAttribute) item).getOwner();
            }
            else if (item.getItemType() == DrbItem.VALUE_ITEM)
            {
               throw new DynamicException(this,
                     "XPTY0020 - Context item is not a node");
            }

            if ((parent_node != null) && (!case_of_wildcard)
                  && (!this.name.equals(parent_node.getName())))
            {
               parent_node = null;
            }
            if (this.nextStep != null)
            {
               inner_context.focus.setContextItem(parent_node);
               inner_context.focus.setContextPosition(1);
               inner_context.focus.setContextSize(1);

               return this.nextStep.evaluate(inner_context);
            }
            else
            {
               if (parent_node != null)
               {
                  item_list.addItem(parent_node);
               }

               return item_list;
            }
         }
         else
         /**
          * Case of child axis
          */
         if (base_node == null)
         {
            // return the empty sequence if the context item is not an element
            return output_sequence;
         }
         else
         {
            /**
             * Optimisation for range and literals expressions, getting the
             * limits for evaluation
             */
            final int positions[] = new int[2];
            // if positions are unrelevant , return an empty sequence
            if (!(this.predicatsList).getEvaluationLimit(context, positions))
            {
               return output_sequence;
            }
            Integer min_position = positions[0];
            Integer max_position = positions[1];

            if (min_position == java.lang.Integer.MAX_VALUE)
            {
               min_position = 1;
            }

            if (max_position == java.lang.Integer.MIN_VALUE)
            {
               max_position = java.lang.Integer.MAX_VALUE;
            }

            /**
             * Specific case of arrays
             */
            DrbNode test_node = null;

            try
            // To prevent any error during implementation changes
            {
               if (base_node != null)
               {
                  if (case_of_wildcard)
                  {
                     test_node = base_node.getChildAt(min_position - 1);
                  }
                  else
                  {
                     test_node = base_node.getNamedChild(this.name, 1);
                  }
               }
            }
            catch (final Exception exception)
            {
               throw new DynamicException(this, "Cannot assess if "
                     + "current child is an array (" + exception.getMessage()
                     + ")", exception);
            }

            /**
             * Loop on nodes matching the name.
             */
            DrbNode node = null;
            int position = min_position - 1;
            DynamicContext.Size children_count = new DynamicContext.Size(0);

            final DrbNode contextNode = base_node;

            try
            // To prevent any error during implementation changes
            {
               children_count = new DynamicContext.Size()
               {
                  protected int getSize()
                  {
                     return contextNode.getChildrenCount();
                  }
               };
            }
            catch (final Exception exception)
            {
               throw new DynamicException(this, "Cannot count children of "
                     + "node \"" + base_node + "\" (" + exception.getMessage()
                     + ")");
            }

            do
            {
               position = position + 1;

               // Check the position has no reached the maximum range
               if (position > max_position)
               {
                  break;
               }

               // Get next matching node
               if ((min_position == 1) && (test_node != null))
               {

                  node = test_node;
                  test_node = null;
               }
               else
               {
                  try
                  // To prevent any error during implementation changes
                  {
                     if (case_of_wildcard)
                     {
                        node = base_node.getChildAt(position - 1);
                     }
                     else
                     {
                        node = base_node.getNamedChild(this.name, position);
                     }
                  }
                  catch (final Exception exception)
                  {
                     throw new DynamicException(this, "Cannot get child of "
                           + "node \"" + base_node + "\" at position "
                           + position + " (" + exception.getMessage() + ")");
                  }
               }

               if (node == null)
               {
                  break;
               }

               // Set new context
               inner_context.focus.setContextItem(node);
               inner_context.focus.setContextPosition(position);
               inner_context.focus.setContextSize(children_count);

               // Test the predicates on this node
               if (Query.getEffectiveBooleanValue(this.predicatsList
                     .evaluate(inner_context)))
               {
                  item_list.addItem(node);
               }
            }
            while (node != null);
         }
      }
      if ((this.name != null) || (this.filter != null))
      {

         /**
          * Case of filter step
          */
         if (this.filter != null)
         {
            item_list = new DrbDefaultSequence(this.filter.evaluate(context));
         }

         if (this.nextStep != null)
         {
            final DefaultResult results = new DefaultResult();
            DrbSequence sub_result;

            for (int inode = 0; inode < item_list.getLength(); inode++)
            {
               inner_context.focus.setContextItem(item_list.getItem(inode));
               inner_context.focus.setContextPosition(inode + 1);
               inner_context.focus.setContextSize(item_list.getLength());

               sub_result = this.nextStep.evaluate(inner_context);

               if (sub_result == null)
               {
                  throw new DynamicException(this,
                        "Error while evaluating next step: " + this.nextStep);
               }

               results.append(sub_result);
            }

            return results;
         }
         else
         {
            output_sequence = item_list;
         }
      }

      return output_sequence;
   }

   /**
    * Returns a detailed description of the General Step.
    * 
    * @return the description of the expression.
    */
   public String toString()
   {
      String output = "";

      if (this.schema != null)
      {
         output = "(" + this.schema + ")";
      }

      if (this.name != null)
      {
         output = output + this.name + this.predicatsList;
      }
      else
      {
         output = output + this.filter;
      }

      return output;
   }
}
