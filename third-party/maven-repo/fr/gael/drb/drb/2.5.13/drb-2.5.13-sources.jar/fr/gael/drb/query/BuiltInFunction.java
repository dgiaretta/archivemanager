/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbSequence;

/**
 * Built-in function of XQuery language.
 */
class BuiltInFunction extends Function
{
   /**
    * Logger
    */
   static private Logger logger = Logger.getLogger(BuiltInFunction.class);
   
   /**
    * Built-in functions.
    */
   private static Map<QName, Function> builtInFunctions = 
      new HashMap<QName, Function>();

   /**
    * Function body.
    */
   private FunctionBody body;

   /**
    * Complete constructor of a built-in function.
    * 
    * @param body the function body.
    */
   protected BuiltInFunction(FunctionSignature signature,
                             FunctionBody body)
   {
      super(signature);
      if (body == null)
      {
         throw new NullPointerException("The function body cannot be null");
      }
      this.body = body;
   }

   /**
    * Returns the value of the function.
    * 
    * @param context a dynamic context not considered in this implementation.
    * @param values the values of the parameter list.
    * @return the value of the function.
    */
   public DrbSequence evaluate(final DynamicContext context,
                               final List<DrbSequence> values)
   {
      return this.body.evaluate(context, getSignature().convert(values));
   }
/*
   private BuiltInFunction(String local_name, String uri,
         String return_type_name, String[] parameter_type_names,
         FunctionBody body)
   {
      SequenceType return_type = new SequenceType();
      if (return_type_name != null)
      {
         return_type = new SequenceType(return_type_name);
      }
      QName name = new QName(local_name, uri);

      //Build function signature
      FunctionSignature signature = new FunctionSignature(name, return_type);
      for (String parameter_type_name: parameter_type_names)
      {
         SequenceType parameter_type = new SequenceType();
         if (parameter_type_name != null)
         {
            parameter_type = new SequenceType(parameter_type_name);            
         }
         QName parameter_name = new QName("arg" + signature.getArity());
         signature.addParameter(parameter_name, parameter_type);
      }
      
      return new BuiltInFunction(signature, body);
   }
*/

   static Function getBuiltInFunction(QName name, int arity)
   {
      Function function = BuiltInFunction.builtInFunctions.get(name);

      if ((function != null) && function.getSignature().matches(name, arity))
      {
         return function;
      }
      else
      {
         return null;
      }
   }
}
