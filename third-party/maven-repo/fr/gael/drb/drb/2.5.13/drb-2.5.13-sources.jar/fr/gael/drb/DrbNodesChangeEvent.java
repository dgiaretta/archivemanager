/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import java.util.EventObject;

import org.apache.log4j.Logger;

/**
 * Event reporting node changes. The event class gather all information or means
 * of information related to any node changes. This class has been designed in
 * particular to be used as parameter of the DrbNodesChangeListener triggers
 * (i.e. operations). Note: in the current implementation it is not possible to
 * change the affacted node list as well as the source after construction.
 */
public class DrbNodesChangeEvent extends EventObject
{

   /**
    * Collection of changed nodes. This collection is filled only if more than
    * one node is affected by the change. Otherwise the source attribute is
    * used.
    */
   DrbNodeList changedNodes;

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(DrbNodesChangeEvent.class);

   /**
    * Builds a node change event class with a single affected node. This
    * constructor is the simplest way to build an node change event. The event
    * is built from specified source and applies to this source. It is useful
    * tom implement mutable operations that affects only the current node.
    * 
    * @param source The affected node that raised the event.
    */
   public DrbNodesChangeEvent(final DrbNode source)
   {
      super(source);
   }

   /**
    * Builds a node change event with multiple affected nodes. The list of
    * affected nodes is passed in paramater. On call of this function, it is not
    * automatically considered that the source node is affected by the change.
    * In shuch case the source node shall be part of the passed node list.
    * 
    * @param source The node that raised the event.
    * @param changed_nodes The nodes affected by the change.
    */
   public DrbNodesChangeEvent(final DrbNode source,
         final DrbNodeList changed_nodes)
   {
      super(source);

      if (changed_nodes == null)
      {
         logger
               .error("DrbNodeChangeEvent : Warning : The node list shall not be null.");
      }

      this.changedNodes = changed_nodes;
   }

   /**
    * Returns the nodes that have been affected by the changes. This nodes may
    * have been modified, inserted, removed or the children list drastically
    * modified. The type of change is not directly hold by this event class but
    * can be identified if used through the calls of the triggers of the
    * DrbNodesChangeListener implementations.
    * 
    * @return The list of changed nodes.
    */
   public DrbNodeList getChangedNodes()
   {
      return this.changedNodes;
   }

} // DrbNodesChangeEvent
