/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbDefaultMutableNode;
import fr.gael.drb.DrbFactory;
import fr.gael.drb.DrbNode;
import fr.gael.drb.DrbNodeList;
import fr.gael.drb.impl.URLNode;
import fr.gael.drb.impl.file.FileFactory;
import fr.gael.drb.impl.xml.XmlFactory;
import fr.gael.drb.value.Value;

/**
 * Declaration of an XML-Schema.
 */
public class XmlSchema extends XsdComponent
{

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(XmlSchema.class);

   // ========================================================================
   // Static part.
   // ========================================================================

   /**
    * schema tag.
    */
   final static String TAG = "schema";

   /**
    * targetNamespace tag.
    */
   final static String TARGET_NAMESPACE_TAG = "targetNamespace";

   /**
    * include tag.
    */
   final static String INCLUDE_TAG = "include";

   /**
    * import tag.
    */
   final static String IMPORT_TAG = "import";

   /**
    * schema location tag.
    */
   final static String SCHEMA_LOCATION_TAG = "schemaLocation";

   // ========================================================================
   // Attributes part.
   // ========================================================================
   /**
    * Global type definition.
    */
   private XsdType[] globalTypes = null;

   /**
    * The global type derivations.
    */
   private Set<XsdType>[] derivationTypes = null;

   /**
    * The global type derivations map.
    */
   private Hashtable<XsdType, Set<XsdType>> derivationMap =
      new Hashtable<XsdType, Set<XsdType>>();

   /**
    * Root element definitions.
    */
   private XsdElement[] rootElements = null;

   /**
    * Namespace definition.
    */
   protected Namespace namespaces = null;

   // ========================================================================
   // Methods part.
   // ========================================================================
   /**
    * Build an XML-Schema
    * 
    * @param root_elements All the elements of the root
    * @param global_types The globals types
    * @param namespaces The name space
    */
   public XmlSchema(XsdElement[] root_elements, XsdType[] global_types,
         Namespace namespaces)
   {
      if (root_elements == null)
      {
         root_elements = new XsdElement[] {};
      }

      this.rootElements = root_elements;

      if (global_types == null)
      {
         global_types = new XsdType[] {};
      }

      this.globalTypes = global_types;

      if (namespaces == null)
      {
         namespaces = new Namespace();
      }
      this.namespaces = namespaces;

      // Create the hashset to save derivation
      this.derivationTypes = new Set[this.globalTypes.length];
      this.derivationMap = new Hashtable<XsdType, Set<XsdType>>();

      for (int i = 0; i < this.globalTypes.length; i++)
      {
         // if (globalTypes[i].getSchema() == null)
         this.globalTypes[i].setSchema(this);
         this.derivationTypes[i] = new HashSet<XsdType>();
         this.derivationMap.put(this.globalTypes[i], this.derivationTypes[i]);
      }

      for (int i = 0; i < this.globalTypes.length; i++)
      {
         final Set<XsdType> derivation_set =
            this.getDerivation(this.globalTypes[i].getBase());
         if (derivation_set != null)
         {
            derivation_set.add(this.globalTypes[i]);
         }
      }
   } // XmlSchema

   /**
    * Returns the default root element of this schema
    * 
    * @return Return the default root element
    */
   public final XsdElement getDefaultRootElement()
   {
      if ((this.rootElements != null) && (this.rootElements.length > 0))
      {
         return this.rootElements[0];
      }
      return null;
   } // getRootElements

   /**
    * Returns the root elements of this schema
    * 
    * @return Return all the root elements
    */
   public final XsdElement[] getRootElements()
   {
      return this.rootElements;
   } // getRootElements

   /**
    * Returns an element from its qualified name.
    * 
    * @param qname the name root
    * @return Return the element root with the specified name
    */
   public final XsdElement getRootElement(final String qname)
   {
      final String local_name = Namespace.toLocal(qname);
      final String prefix_name = Namespace.toPrefix(qname);
      String ns_name = this.namespaces.resolveNamespace(prefix_name);

      if (ns_name == null)
      {
         ns_name = prefix_name;
      }

      for (int i = 0; i < this.rootElements.length; i++)
      {
         final String elt_name = this.rootElements[i].getName();
         final String elt_ns = this.rootElements[i].getTargetNamespace();
         if ((elt_name != null) && elt_name.equals(local_name)
               && ((ns_name == null) || (ns_name.equals(elt_name))))
         {
            return this.rootElements[i];
         }
      }
      return null;
   }

   /**
    * Returns the global type of this schema.
    * 
    * @return Return the global types
    */
   public final XsdType[] getGlobalTypes()
   {
      return this.globalTypes;
   } // getGlobalTypes

   /**
    * Returns a type from its qualified name.
    * 
    * @param qname The qualified name
    * @return Return the type of the qualified name
    */
   public XsdType getType(final String qname)
   {
      final String local_name = Namespace.toLocal(qname);
      final String prefix_name = Namespace.toPrefix(qname);
      String ns_name = this.namespaces.resolveNamespace(prefix_name);

      if (ns_name == null)
      {
         ns_name = prefix_name;
      }

      for (int i = 0; i < this.globalTypes.length; i++)
      {
         final String type_name = this.globalTypes[i].getName();
         final String type_ns = this.globalTypes[i].getTargetNamespace();
         if ((type_name != null) && type_name.equals(local_name)
               && ((ns_name == null) || (ns_name.equals(type_ns))))
         {
            return this.globalTypes[i];
         }
      }
      return null;
   } // getType

   /**
    * Returns the local derivation of a global type.
    * 
    * @param global-type a global type definition
    * @return the set of derived
    */
   protected final Set<XsdType> getDerivation(final XsdType global_type)
   {
      if (global_type == null)
      {
         return new HashSet<XsdType>();
      }
      final Set<XsdType> derivation_set = this.derivationMap.get(global_type);
      return derivation_set;
   } // getDerivation

   /**
    * The default schema instance.
    */
   static XmlSchema xs_schema = null;

   /**
    * Returns the default schema including the standard types.
    * 
    * @return The Xml schema
    */
   public static synchronized XmlSchema getDefaultSchema()
   {
      if (xs_schema == null)
      {
         final XsdType[] base_type = new XsdType[1];
         base_type[0] = new XsdAtomicType(Value.UNKNOWN_ID);
         base_type[0].setTargetNamespace(Namespace.XML_SCHEMA_NAMESPACE);
         final XsdElement[] elements = new XsdElement[] {};

         final Namespace namespaces = new Namespace();
         namespaces.bind("xsd", Namespace.XML_SCHEMA_NAMESPACE);
         namespaces.bind("xs", Namespace.XML_SCHEMA_NAMESPACE);

         final XmlSchema base_schema =
            new XmlSchema(elements, base_type, namespaces);

         final java.net.URL datatype_url =
            XmlSchema.class.getClassLoader().getResource(
                  "fr/gael/drb/xsd/datatypes.xsd");
         
         XmlFactory xml_factory = new XmlFactory();
         
         DrbNode context_node = DrbFactory.openURI(".");
         DrbNode schema_node = xml_factory.open(new URLNode(datatype_url));
         
         xs_schema=new XsdFactory().open(context_node,schema_node,base_schema);
      }
      return xs_schema;
   } // getDefaultSchema

   /**
    * Format this component into a string.
    * 
    * @return the node
    */
   public DrbNode toNode()
   {
      final DrbDefaultMutableNode schema_node = new DrbDefaultMutableNode(TAG);
      schema_node.setNamespaceURI(Namespace.XML_SCHEMA_NAMESPACE);
      schema_node.setNamespaceBindings(this.namespaces);

      final DrbDefaultAttributeList attributes = new DrbDefaultAttributeList();

      // Target namespace
      if (this.getTargetNamespace() != null)
      {
         attributes.add(new DrbDefaultAttribute(TARGET_NAMESPACE_TAG,
               new fr.gael.drb.value.String(this.getTargetNamespace()),
               schema_node));
      }
      schema_node.setAttributes(attributes);

      // Root elements
      if (this.rootElements != null)
      {
         for (int i = 0; i < this.rootElements.length; i++)
         {
            final DrbNode elt_node = this.rootElements[i].toNode();
            if (elt_node != null)
            {
               schema_node.appendChild(elt_node);
            }
         }
      }

      // Global types
      if (this.globalTypes != null)
      {
         for (int i = 0; i < this.globalTypes.length; i++)
         {
            final DrbNode type_node = this.globalTypes[i].toNode();
            if (type_node != null)
            {
               schema_node.appendChild(type_node);
            }
         }
      }
      return schema_node;
   } // toNode

   /**
    * Allow to validate an xml file using an xml schema file.
    * 
    * @param xml_filename the xml filename to be validate
    * @param xsd_filename the xml schema file used for validation
    * @param deep true for deep validation and false otherwise
    * @return true if the xml file is valid regarding the schema, false
    *         otherwise.
    */
   public static XsdInvalid validate(final String xml_filename,
         final String xsd_filename, final boolean deep)
   {
      logger.debug("Try to validate: '" + xml_filename + "' with schema '"
            + xsd_filename + "'");

      // Get the xsd factory
      final XsdFactory xsdfactory = new XsdFactory();

      // Get the node representing the schema
      final DrbNode node_schema = DrbFactory.open(xsd_filename);
      if (node_schema == null)
      {
         logger.error("Cannot open schema file: " + xsd_filename);
         return null;
      }

      final XmlSchema xmlschema =
         xsdfactory.open(node_schema.getNamedChild("schema", 1));
      if (xmlschema == null)
      {
         logger.error("Cannot load schema file: " + xsd_filename);
         return null;
      }

      // Get the node representing the xml file
      final DrbNode node_xml = DrbFactory.open(xml_filename);
      if (node_xml == null)
      {
         logger.error("Cannot open xml file: " + xml_filename);
         return null;
      }

      final XsdElement xsd_root_element = xmlschema.getDefaultRootElement();
      final XsdType xsd_type = xsd_root_element.getType();

      // Get the validating node instance
      final XsdNodeImpl xsd_node =
         (XsdNodeImpl) XsdNodeImpl.getInstance(node_xml.getFirstChild(),
               xsd_type);

      if (deep)
      {
         return xsd_node.isDeepValid();
      }
      else
      {
         return xsd_node.isValid();
      }
   }

   // =====================================================================
   // Unitary test part.
   // =====================================================================
   /**
    * Makes this class runnable for testing.
    * 
    * @param args String[]
    */
   public static void main(final String[] args)
   {
      if (args.length == 0)
      {
         logger.error("Usage : XmlSchema <typename> [schema]");
         return;
      }
      /**
       * Create the default schema for the XSD datatypes.
       */
      final XmlSchema xsd_schema = XmlSchema.getDefaultSchema();
      /**
       * Opens a schema from an XML node if any.
       */
      XmlSchema schema = xsd_schema;
      if (args.length == 2)
      {
         final DrbNode file_node = DrbFactory.open(args[1]);
         final DrbNode schema_node = file_node.getFirstChild();
         final XsdFactory xsdfactory = new XsdFactory();
         schema = xsdfactory.open(file_node.getParent(), schema_node);
      }
      /**
       * Find the specified type from its qualified name.
       */
      for (int i = 0; i < 1; i++)
      {
         XsdType type = schema.getType(args[i]);
         if (type == null)
         {
            type = xsd_schema.getType(args[i]);
         }
         if (type == null)
         {
            System.out.println("'" + args[i] + "' not found.");
         }
         else
         {
            System.out.println("Name : " + type.getName());
            System.out.println("Target namespace : "
                  + type.getTargetNamespace());
            String prefix = null;
            if (xsd_schema.namespaces != null)
            {
               prefix =
                  xsd_schema.namespaces
                        .resolvePrefix(type.getTargetNamespace());
            }
            System.out.println("Prefix : " + prefix);

            final DrbNodeList ext_nodes = type.getExternalNodes();
            DrbNode annot = null;
            if (ext_nodes != null)
            {
               annot = ext_nodes.getNamedItem("annotation", 1);
            }
            DrbNode doc = null;
            if (annot != null)
            {
               doc = annot.getNamedChild("documentation", 1);
            }
            String doc_value = "";
            if ((doc != null) && (doc.getValue() != null))
            {
               doc_value = doc.getValue().toString();
            }
            System.out.println("documentation : " + doc_value);

            if (type.getBase() != null)
            {
               if (type.getBase().getName() == null)
               {
                  System.out.println("Base : anonymous");
               }
               System.out.println("Base : " + type.getBase().getName());
            }

            System.out.println("Derivation : ");
            final Object[] type_derivation = type.getDerivation().toArray();
            for (int ideriv = 0; ideriv < type_derivation.length; ideriv++)
            {
               System.out.println(type_derivation[ideriv] + " ");
            }

            if (type.getStructure() != null)
            {
               final XsdComplexType structure_type = type.getStructure();
               System.out.println("complexType : " + structure_type);
               fr.gael.drb.impl.xml.XmlWriter.writeXML(structure_type.toNode(),
                     System.out);
            }

            System.out.println("datatype : " + type.getDatatype());
            /* simpleType or complexType with simpleContent */

            if (type.getDatatype() != null)
            {
               System.out.println("valueType : "
                     + type.getDatatype().getTypeId());
               System.out.println("inclusive lower bound: "
                     + type.getDatatype().getInclusiveLowerBound());
               System.out.println("inclusive upper bound: "
                     + type.getDatatype().getInclusiveUpperBound());
            }
            System.out.println("\n\n");
         }
      }
   } // main

} // XmlSchema
