/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbDefaultSequence;
import fr.gael.drb.DrbSequence;

/**
 * Wraps a empty sequence expression () of XQuery language. The empty sequence
 * always returns a empty sequence at evaluation, whatever the dynamic context
 * is.
 */
class EmptySequenceExpression extends AbstractExpression
{
   /**
    * Constructor of the empty sequence expression.
    * 
    * @param token the token associated to the empty sequence expression.
    */
   public EmptySequenceExpression(final Token token)
   {
      super("Literal", token);
   }

   /**
    * Evaluates the empty sequence expression. Just return the an empty
    * sequence.
    * 
    * @param context the outer-focus of the evaluation.
    * @return the sequence resulting from the dynamic evaluation.
    */
   public DrbSequence evaluate(final DynamicContext context)
   {
      return new DrbDefaultSequence();
   }

   /**
    * Returns the empty sequence as a string.
    * 
    * @return the string reporting the syntax of the empty sequence.
    */
   public String toString()
   {
      return "()";
   }

   /**
    * A expression which is constant means that it need no context item to be
    * evaluate. The returned sequence from its evaluation will always be the
    * same along the query script
    * 
    * @return true if this expression is constant
    */
   public boolean isConstant()
   {
      return true;
   }
}
