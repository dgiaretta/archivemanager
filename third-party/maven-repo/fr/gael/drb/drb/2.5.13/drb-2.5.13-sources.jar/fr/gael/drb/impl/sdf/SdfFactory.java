/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.sdf;

import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.URL;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbFactoryImpl;
import fr.gael.drb.DrbNode;
import fr.gael.drb.impl.DrbNodeImpl;
import fr.gael.drb.xsd.XmlSchema;
import fr.gael.drb.xsd.XsdComplexType;
import fr.gael.drb.xsd.XsdElement;
import fr.gael.drb.xsd.XsdFactory;
import fr.gael.drb.xsd.XsdModelGroup;
import fr.gael.drb.xsd.XsdParticle;

/**
 * Factory for Structured Data Files.
 */
public final class SdfFactory implements DrbFactoryImpl
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(SdfFactory.class);

   /**
    * The scheme identifier of the implementation. Always returns "sdf" string,
    * which is defined as the scheme identifier of the implementation.
    * 
    * @return The "sdf" string.
    */
   public final String getIdentifier()
   {
      return "sdf";
   }

   /**
    * The name of the implementation. Always returns "Structured Data File"
    * string, which stands as the name of the implementation.
    * 
    * @return The "Structured Data File" string.
    */
   public final String getName()
   {
      return "Structured Data File";
   }

   /**
    * Opens the node matching a given URI. This implementation does not support
    * this operation and therefore always returns a null reference.
    * 
    * @param uri Unused.
    * @return null.
    */
   public final DrbNode open(final URL uri)
   {
      return null;
   }

   /**
    * Opens the node from an existing node. This implementation does not support
    * this operation and therefore always returns a null reference.
    * 
    * @param base_node Unused.
    * @return null.
    */
   public final DrbNode open(final DrbNode base_node)
   {
      return null;
   }

   /**
    * Opens the node matching a given URI from an existing node. This
    * implementation does not support this operation and therefore always
    * returns a null reference.
    * 
    * @param uri Unused.
    * @param base_node Unused.
    * @return null.
    */
   public final DrbNode open(final URL uri, final DrbNode base_node)
   {
      return null;
   }

   /**
    * Opens a node using the base node and associated the schema node. This
    * operation creates and returns a DrbNode using an existing node as base or
    * context. The input base node is asked for a RandomAccessFile
    * implementation in order to get data from associated file. The schema node
    * is used to describe the data structure of this file.<br>
    * The reference to the input nodes shall not be null.
    * 
    * @param base_node The input node to be used as RandomAccessFile.
    * @param schema_node The input node to be used as data description.
    * @return A root node or null if an error occured or if the implementation
    *         does not supports the input node.
    */
   public DrbNode open(final DrbNode base_node, final DrbNode schema_node)
   {
      // Local declarations
      XmlSchema schemaDesc; // The schema description
      XsdFactory descLoader; // The schema loader
      String descName; // The schema file name

      try
      {
         // Create schema loader
         descLoader = new XsdFactory();
         descName = schema_node.getName();

         // Load schema node descriptors
         schemaDesc = descLoader.open(schema_node);
         if ((schemaDesc == null) || (schemaDesc.getRootElements() == null))
         {
            this.logger.error("fr.gael.drb.impl.sdf.SdfFactory.open() : "
                  + "No element found in  \"" + descName + "\"");
            return null;
         }
      }
      catch (final Exception e)
      {
         this.logger.error("fr.gael.drb.impl.sdf.SdfFactory.open() : "
               + "Error while parsing XML-Schema.");
         this.logger.error("   " + e);
         return null;
      }
      return this
            .open(base_node, schemaDesc, schema_node.getParent().getPath());
   }

   /**
    * Opens a node using the base node and associated the XML-Schema. This
    * operation creates and returns a DrbNode using an existing node as base or
    * context. The input base node is asked for a RandomAccessFile
    * implementation in order to get data from associated file. The schema is
    * used to describe the data structure of this file.<br>
    * The reference to the input nodes shall not be null.
    * 
    * @param base_node The input node to be used as RandomAccessFile.
    * @param xml_schema The XML-Schema containing the SDF parameters.
    * @param schema_path The path of the XML-Schema file.
    * @return A root node or null if an error occured or if the implementation
    *         does not supports the input node.
    */
   public DrbNode open(final DrbNode base_node, final XmlSchema xml_schema,
         final String schema_path)
   {
      // Local declarations
      RandomAccessData fileData = null; // The file to use for data access
      boolean create_mode = false;
      XsdElement nodeDesc; // The root schema element
      XmlSchema schemaDesc; // The schema description
      Descriptor rootDesc; // The root block descriptor
      DrbNode rootBlock; // The root block node

      // long initTime = System.currentTimeMillis();

      // Check integrity
      if ((base_node == null) || (xml_schema == null))
      {
         this.logger.error("fr.gael.drb.impl.sdf.SdfFactory.open() : "
               + "null parameter.");
         this.logger
               .error("   base_node   = "
                     + (base_node == null ? null : "\"" + base_node.getName()
                           + "\""));
         return null;
      }

      if (!(base_node instanceof DrbNodeImpl))
      {
         this.logger
               .error("fr.gael.drb.impl.sdf.SdfFactory.open() : "
                     + "cannot retrieve a valid implementation."
                     + (base_node == null ? null : "\"" + base_node.getName()
                           + "\""));
         return null;
      }

      final DrbNodeImpl baseImpl = (DrbNodeImpl) base_node;
      // Get node name
      final String baseNodeName = base_node.getName();

      // Try to get the RandomAccessFile implementation of the base node
      if (fileData == null)
      {
         final RandomAccessFile file =
            (RandomAccessFile) baseImpl.getImpl(RandomAccessFile.class);
         if (file != null)
         {
            fileData = new RandomAccessFileData(file);
         }
      }
      if (fileData == null)
      {
         if (baseImpl.hasImpl(InputStream.class))
         {
            fileData = new RandomAccessStreamData(baseImpl);
         }
      }
      if (fileData == null)
      {
         this.logger.error("fr.gael.drb.impl.sdf.SdfFactory.open() : "
               + "Unable to get RandomAccessFile implementation from node \""
               + baseNodeName + "\"");
         return null;
      }

      try
      {
         // Load schema node descriptors
         schemaDesc = xml_schema;
         if ((schemaDesc == null) || (schemaDesc.getRootElements() == null))
         {
            this.logger.error("fr.gael.drb.impl.sdf.SdfFactory.open() : "
                  + "No element found in  \"" + schema_path + "\"");
            return null;
         }

         // Test if schema root node is unique
         if (schemaDesc.getRootElements().length != 1)
         {
            this.logger.error("fr.gael.drb.impl.sdf.SdfFactory.open() : "
                  + "Node descriptor is not unique (nb="
                  + schemaDesc.getRootElements().length + ") from schema \""
                  + schema_path + "\"");
            return null;
         }
         // Get schema root node descriptor
         nodeDesc = schemaDesc.getDefaultRootElement();

         // Get file size
         // fileSize = fileData.length();
         create_mode = (fileData.available() <= 0);

         // Parse schema in order to build block descriptors and set root
         // block descriptor properties
         rootDesc =
            this.parseNodeDescriptor(fileData, create_mode, nodeDesc, null, 0);
         rootDesc.setParent(null);
         rootDesc.setOffsetType(PhysicalAttribute.FIXED);
         rootDesc.setOffset(null, 0);
         rootDesc.setOccurrenceCountType(PhysicalAttribute.FIXED);
         rootDesc.setOccurrenceCount(null, 1);

         // Start recursive solving of root, base node and single ancestors flag
         rootDesc.setAsRoot(base_node, schema_path);
      }
      catch (final Exception e)
      {
         this.logger.error("fr.gael.drb.impl.sdf.SdfFactory.open() : "
               + "Error while parsing node descriptors.");
         this.logger.error("   " + e);
         return null;
      }

      // Creates root block
      rootBlock = new DefaultBlock(rootDesc, new int[] {});

      // returns root block
      // System.out.println(" SDF Factory loading time = "+
      // ((System.currentTimeMillis()-initTime)/1000.0)+" sec.");
      return rootBlock;
   }

   /**
    * Parse the schema descriptors tree to build block descriptors. This
    * implementation is recursive, the operation calls itself for the children
    * of the current schema nodelist. The root block descriptor is returned to
    * the caller.
    * 
    * @param file the file to pass as a reference for the block descritor.
    * @param create_mode the creation mode.
    * @param particle The particle
    * @param parent_descriptor the block descriptor to reference as parent for
    *           the block descriptor of the current schema node list.
    * @param depth the depth in the tree.
    * @return The DrbNode corresponding to the current schema node list.
    */
   private Descriptor parseNodeDescriptor(final RandomAccessData file,
         final boolean create_mode, final XsdParticle particle,
         final Descriptor parent_descriptor, final int depth)
   {
      // Check particle
      if (particle == null)
      {
         return null;
      }

      // If the particle is an instance of element
      Descriptor currentDescriptor = null;
      XsdModelGroup complex_content = null;
      if (particle instanceof XsdElement)
      {
         // Create block Descriptor from current element
         final XsdElement element = (XsdElement) particle;
         currentDescriptor = new Descriptor(file, create_mode, element, depth);
         // Retrieve complex content (if any)
         if ((element.getType() == null)
               || (element.getType().getStructure() == null))
         {
            return currentDescriptor;
         }
         final XsdComplexType structureType = element.getType().getStructure();
         complex_content = structureType.getComplexContent();
      }
      // Else the model group has to be "transparent"
      else if (particle instanceof XsdModelGroup)
      {
         // logger.debug("particle is not instance of XsdElement : "+
         // "Wrap to parent_descriptor "+parent_descriptor.getName());
         // Wrap parent block Descriptor
         complex_content = (XsdModelGroup) particle;
         currentDescriptor = parent_descriptor;
      }
      // Case of Wildcard not supported
      else
      {
         this.logger
               .error("fr.gael.drb.impl.sdf.SdfFactory.parseNodeDescriptor() : "
                     + "Only ELEMENT_TERM is implemented at this time.");
         return null;
      }

      if (complex_content == null)
      {
         return currentDescriptor;
      }

      // Loop on list children
      Descriptor prevDescriptor = null;
      Descriptor nextDescriptor = null;
      final int length = complex_content.getLength();
      for (int i = 0; i < length; i++)
      {
         // Parse sub-particle
         prevDescriptor = nextDescriptor;
         nextDescriptor =
            this.parseNodeDescriptor(file, create_mode, complex_content
                  .getParticle(i), currentDescriptor, depth + 1);

         // If child descriptor is not null add tree cross references
         if (nextDescriptor != null)
         {
            // TBC !!?? filtrage etonnant, verifier les conditions de
            // recursivite lorsque les fils sont rattaches au parent au lieu
            // du noeud lui-meme (transparent) !
            if (currentDescriptor != nextDescriptor)
            {
               currentDescriptor.addChild(nextDescriptor);
               nextDescriptor.setParent(currentDescriptor);
            }
            if (prevDescriptor != null)
            {
               prevDescriptor.setNextSibling(nextDescriptor);
               nextDescriptor.setPreviousSibling(prevDescriptor);
            }
         }
      }
      return currentDescriptor;
   }
} // SdfFactory
