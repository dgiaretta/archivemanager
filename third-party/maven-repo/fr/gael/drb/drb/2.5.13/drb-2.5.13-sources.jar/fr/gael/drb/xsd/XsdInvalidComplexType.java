/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbNode;

/**
 * Output of the XML-Schema complex content validator.
 */
class XsdInvalidComplexType extends XsdInvalidType
{

   /**
    * The simple content report
    */
   XsdInvalid simpleContent = null;

   /**
    * The complex content report
    */
   XsdInvalid complexContent = null;

   /**
    * The attribute group report
    */
   XsdInvalid attributeGroup = null;

   /**
    * Build an XsdInvalidComplexType
    * 
    * @param node the node
    * @param type the complex type
    */
   XsdInvalidComplexType(final DrbNode node, final XsdComplexType type)
   {
      super(node, type);
   } // XsdInvalidComplexType

   /**
    * Returns a message describing the validation result.
    * 
    * @return a message describing the validation result.
    */
   public String getMessage()
   {
      if (this.type == null)
      {
         return "Unknown type";
      }
      else if (this.simpleContent != null)
      {
         return this.simpleContent.getMessage();
      }
      else if (this.complexContent != null)
      {
         return this.complexContent.getMessage();
      }
      else if (this.attributeGroup != null)
      {
         return this.attributeGroup.getMessage();
      }
      else
      {
         return "Invalid content";
      }
   } // getMessage

   /**
    * Replace the simple content result.
    * 
    * @param simple_content the simple content result to be replaced
    */
   void setSimpleContent(final XsdInvalid simple_content)
   {
      if (this.simpleContent != null)
      {
         this.remove(this.simpleContent);
      }
      this.simpleContent = simple_content;
      if (this.simpleContent != null)
      {
         this.add(this.simpleContent);
      }
   } // setSimpleContent

   /**
    * Replace the complex content result.
    * 
    * @param complex_content the complex content result to be replaced
    */
   void setComplexContent(final XsdInvalid complex_content)
   {
      if (this.complexContent != null)
      {
         this.remove(this.complexContent);
      }
      this.complexContent = complex_content;
      if (this.complexContent != null)
      {
         this.add(this.complexContent);
      }
   }

   /**
    * Replace the attribute group result.
    * 
    * @param attrib_group the attribute group result
    */
   void setAttributeGroup(final XsdInvalid attrib_group)
   {
      if (this.attributeGroup != null)
      {
         this.remove(this.attributeGroup);
      }
      this.attributeGroup = attrib_group;
      if (this.attributeGroup != null)
      {
         this.add(this.attributeGroup);
      }
   }

} // XsdInvalidComplexType
