/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import org.apache.log4j.Logger;

import fr.gael.drb.DrbAttribute;
import fr.gael.drb.DrbAttributeList;
import fr.gael.drb.DrbDefaultAttribute;
import fr.gael.drb.DrbDefaultAttributeList;
import fr.gael.drb.DrbFactory;
import fr.gael.drb.DrbNode;
import fr.gael.drb.query.Query;
import fr.gael.drb.value.Value;

/**
 * A XML-Schema validator wrapper for DrbNodes.
 */
public class XsdNodeImpl extends DrbNodeFilter implements XsdNode
{

   /**
    * The base node type.
    */
   private XsdType type;

   /**
    * The parent of this node.
    */
   private XsdNodeImpl parent = null;

   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(XsdNodeImpl.class);

   /**
    * Build an DrbNodeFilter instance.
    * 
    * @param parent the parent node
    * @param base the base node
    * @param type XsdType
    */
   protected XsdNodeImpl(final XsdNodeImpl parent, final DrbNode base,
         final XsdType type)
   {
      super(base);
      this.type = type;
      this.parent = parent;
   } // XsdNodeImpl

   /**
    * Create an XsdNode instance.
    * 
    * @param base the base node
    * @param type XsdType
    * @return XsdNode
    */
   public static XsdNode getInstance(final DrbNode base, final XsdType type)
   {
      if (base == null)
      {
         return null;
      }
      return new XsdNodeImpl(null, base, type);
   } // getInstance

   /**
    * Returns the type of this node or null if it is unknown.
    * 
    * @return XsdType
    */
   public XsdType getType()
   {
      return this.type;
   } // getType

   /**
    * Check the conformance of a node to its type.
    * 
    * @return an object describing the errors encoutered or null if there are no
    *         errors.
    */
   public XsdInvalid isValid()
   {
      if (this.type == null)
      {
         return new XsdInvalidElement(this.baseNode, null);
      }
      else
      {
         return this.type.isValid(this.baseNode);
      }
   } // isValid

   /**
    * Check the conformance of a node and its children to its type.
    * 
    * @return an object describing the errors encoutered or null if there are no
    *         errors.
    */
   public XsdInvalid isDeepValid()
   {
      XsdInvalid invalid = this.isValid();
      if (invalid == null)
      {
         final int count = this.getChildrenCount();
         for (int i = 0; i < count; i++)
         {
            final XsdNodeImpl child = (XsdNodeImpl) this.getChildAt(i);
            if (child != null)
            {
               invalid = child.isDeepValid();
            }
            if (invalid != null)
            {
               break;
            }
         }
      }
      return invalid;
   } // isValid

   /**
    * The attributes of the nodes. This operation returns a list of attribute
    * owned by the current node is any.
    * 
    * @return The list attributes of the current node.
    */
   public DrbAttributeList getAttributes()
   {
      final DrbAttributeList attribs = this.baseNode.getAttributes();

      final DrbDefaultAttributeList xsdattribs = new DrbDefaultAttributeList();
      if (attribs != null)
      {
         for (int i = 0; i < attribs.getLength(); i++)
         {
            xsdattribs.add(attribs.item(i));
         }
      }
      String typename = "anyType";
      // Get the type name if any.
      // Otherwise, get the base type name.
      XsdType base_type = this.type;
      while ((base_type != null) && (base_type.getName() == null))
      {
         base_type = base_type.getBase();
      }
      if ((base_type != null) && (base_type.getName() != null))
      {
         typename = base_type.getName();
      }
      final DrbDefaultAttribute xsitype =
         new DrbDefaultAttribute("type", new fr.gael.drb.value.String(typename));
      xsitype.setNamespaceURI(Namespace.XML_SCHEMA_INSTANCE);
      xsdattribs.add(xsitype);

      final XsdInvalid invalid = this.isValid();
      if (invalid != null)
      {
         final DrbAttribute xsivalid =
            new DrbDefaultAttribute("error", new fr.gael.drb.value.String(
                  invalid.getMessage()));
         xsdattribs.add(xsivalid);
      }
      return xsdattribs;
   } // getAttributes

   /**
    * The parent of this node. Returns a reference to the parent node of the
    * current node according to the curren implementation. Most of the nodes
    * have a parent exept root nodes or if they have just been removed, etc. If
    * the node has no parent the operation returns null.
    * 
    * @return The parent of this node or null.
    */
   public DrbNode getParent()
   {
      if (this.parent == null)
      {
         return this.baseNode.getParent();
      }
      else
      {
         return this.parent;
      }
   } // getParent

   /**
    * Builds a XSD implementation from a base node.
    * 
    * @param node the node
    * @return DrbNode
    */
   protected DrbNodeFilter getInstance(final DrbNode node)
   {
      if (node != null)
      {
         XsdType childtype = null;
         if ((this.type != null) && this.type.isComplex())
         {
            final XsdComplexType cpxtype = (XsdComplexType) this.type;
            childtype = cpxtype.getElementType(node.getName());
         }
         return new XsdNodeImpl(this, node, childtype);
      }

      return null;
   } // getInstance

   /**
    * Previous sibling of the current file or directory. The sibling is
    * retreived from the parent children list. The previous sibling may not
    * exist if the current node is the root or if it is the first file or
    * directory.
    * 
    * @return A reference to the previous sibling or null if no such node.
    */
   public final DrbNode getPreviousSibling()
   {
      if (this.parent == null)
      {
         return this.baseNode.getPreviousSibling();
      }
      else
      {
         return this.parent.getInstance(this.baseNode.getPreviousSibling());
      }
   }

   /**
    * Next sibling of the current file or directory. The sibling is retreived
    * from the parent children list. The next sibling may not exist if the
    * current node is the root or if it is the last file or directory.
    * 
    * @return A reference to the next sibling or null if no such node.
    */
   public final DrbNode getNextSibling()
   {
      if (this.parent == null)
      {
         return this.baseNode.getNextSibling();
      }
      else
      {
         return this.parent.getInstance(this.baseNode.getNextSibling());
      }
   }

   /**
    * This object (which is already a string!) is itself returned.
    * 
    * @return String
    */
   public String toString()
   {
      return this.baseNode.toString() + " xsi:type='"
            + ((this.type == null) ? "null" : this.type.getName()) + "'";
   }

   // ===============================================
   // Mutable operations part.
   // ===============================================
   /**
    * Changes the value of the node. This operation sets a new value of the
    * current node.The value type of the node shall be compatible with the node
    * implementation. If the type does not match exactly it is casted to a
    * compatible one based on the the fr.gael.drb.value capabilities. A
    * reference to the effectivelly assigned value is returned by the operation
    * so it is possible to check if a cast has been performed and therefore
    * assess the accuracy of the assignement. If the cast is not possible the
    * operation raises an UnsupportedOperationException. If the assignment is
    * possible and the node implementation has a physical representation the
    * value is updated in the physical source in order to persist among
    * sessions. It therefore possible that this operation consumes an variable
    * time.
    * <p>
    * <b>Important note:</b> The implementation of the node is not supposed to
    * accept value changes. For instance it may not be possible to change the
    * value of a file directory that has no immediate signification.
    * </p>
    * <p>
    * <b>Events:</b> This operation fires a node changed event when the
    * implementation is a node change producer. The node affected by the change
    * is the current node as well as the source node. The called operation is
    * the nodesChanged() of the listeners.
    * </p>
    * 
    * @param value The new value of the node. This value shall not be null.
    * @return The effectivelly assigned value. The type of this value may differ
    *         from the input one.
    * @throws NullPointerException This exception is raised when the passed
    *            reference to the value is null. This exception may be overriden
    *            by an UnsupportedOperationException.
    * @throws ClassCastException This exception is raised when the
    *            implementation has not succeeded to cast the input value in a
    *            type compatible with the current node.
    * @throws UnsupportedOperationException This exception is raised when the
    *            implementation does not support the requested assignment for
    *            any reason.
    */
   public Value setValue(final Value value) throws NullPointerException,
         ClassCastException, UnsupportedOperationException
   {
      XsdInvalid invalid = null;
      if ((this.type != null) && (this.type.getDatatype() != null))
      {
         invalid = this.type.getDatatype().validate(value);
         if (invalid == null)
         {
            return this.baseNode.setValue(value);
         }
      }
      else
      {
         invalid = new XsdInvalidElement(this.baseNode, null);
      }
      throw new UnsupportedOperationException(invalid.getMessage());

   }

   // ===============================================
   // Unitary test part.
   // ===============================================
   /**
    * Makes this class runnable for testing.
    * 
    * @param args String[]
    */
   public static void main(final String[] args) throws Exception
   {
      if ((args.length == 0) || (args[0].equals("--help"))
            || (args[0].equals("-help")))
      {
         System.out
               .println("Usage: fr.gael.drb.xsd.XsdNodeImpl [options] file");
         System.out.println("Options are:");
         System.out
               .println("-xquery <xquery_file> Path to a file containing an XQuery script.");
         System.out
               .println("-schema <schema> Use schema <schema> to validate documents.");
         System.out
               .println("-append <xpath> <node> Append a node the specified path.");
         System.out
               .println("-replace <xpath> <node> Replace the node at the specified path.");
         System.out
               .println("-insert <xpath> <node> Insert a node at the specified path.");
         System.out
               .println("-remove <xpath> <node> Remove the node at the specified path.");
         System.out
               .println("-value <xpath> <value> Set the value at the specified path.");
         System.out.println("-out <output_file> Set the output file.");
      }

      DrbNode node = null;
      XsdNodeImpl product_1 = null;

      java.io.OutputStream xml_output = null;

      String xpath = null;
      DrbNode append_node = null;
      DrbNode replace_node = null;
      DrbNode insert_node = null;
      Value value_item = null;
      DrbNode schema_node = null;
      final DrbNode context_node = DrbFactory.open(".");

      for (int i = 0; i < args.length; i++)
      {
         if (args[i].length() == 0)
         {
            continue;
         }
         if (args[i].equals("-schema"))
         {
            schema_node =
               (DrbNode) new Query(args[++i]).evaluate(context_node).getItem(0);
         }
         else if (args[i].equals("-value"))
         {
            xpath = args[++i];
            value_item =
               new Query(args[++i]).evaluate(context_node).getItem(0)
                     .getValue();
         }
         else if (args[i].equals("-append"))
         {
            xpath = args[++i];
            append_node =
               (DrbNode) new Query(args[++i]).evaluate(context_node).getItem(0);
         }
         else if (args[i].equals("-replace"))
         {
            xpath = args[++i];
            replace_node =
               (DrbNode) new Query(args[++i]).evaluate(context_node).getItem(0);
         }
         else if (args[i].equals("-insert"))
         {
            xpath = args[++i];
            insert_node =
               (DrbNode) new Query(args[++i]).evaluate(context_node).getItem(0);
         }
         else if (args[i].equals("-remove"))
         {
            xpath = args[++i];
         }
         else if (args[i].equals("-out"))
         {
            xml_output = new java.io.FileOutputStream(args[++i]);
         }
         else if (args[i].equals("-xquery"))
         {
            final java.io.InputStream xquery_file =
               new java.io.FileInputStream(args[++i]);
            node =
               (DrbNode) new Query(xquery_file).evaluate(context_node).getItem(
                     0);
         }
         else
         {
            node = DrbFactory.open(args[i]);
         }
      }

      if (node == null)
      {
         System.err.println("ERROR: No document specified!");
         return;
      }
      XsdType type = null;
      if (schema_node == null)
      {
         System.err.println("WARNING: No schema specified!");
      }
      else
      {
         XmlSchema schema = null;
         if (schema_node.getName().equals("schema"))
         {
            schema = new XsdFactory().open(schema_node);
         }
         else
         {
            schema =
               new XsdFactory().open(schema_node.getParent(), schema_node
                     .getNamedChild("schema", 1));
         }
         final XsdElement element = schema.getRootElement(node.getName());
         if (element != null)
         {
            type = element.getType();
         }
      }
      product_1 = (XsdNodeImpl) XsdNodeImpl.getInstance(node, type);

      if (value_item != null)
      {
         System.err.println("##########Setting value...");
         final DrbNode base =
            (DrbNode) new Query(xpath).evaluate(product_1).getItem(0);
         base.setValue(value_item.getValue());
      }
      else if (append_node != null)
      {
         System.err.println("##########Appending data...");
         final DrbNode base =
            (DrbNode) new Query(xpath).evaluate(product_1).getItem(0);
         base.appendChild(append_node);
      }
      else if (replace_node != null)
      {
         System.err.println("##########Replacing data...");
         final DrbNode base =
            (DrbNode) new Query(xpath).evaluate(product_1).getItem(0);
         final int index = base.getIndex();
         base.getParent().replaceChild(index, replace_node);
      }
      else if (insert_node != null)
      {
         System.err.println("##########Inserting data...");
         final DrbNode base =
            (DrbNode) new Query(xpath).evaluate(product_1).getItem(0);
         final int index = base.getIndex();
         base.getParent().insertChild(insert_node, index);
      }
      else if (xpath != null)
      {
         System.err.println("##########Removing data...");
         final DrbNode base =
            (DrbNode) new Query(xpath).evaluate(product_1).getItem(0);
         final int index = base.getIndex();
         base.getParent().removeChild(index);
      }

      if (xml_output != null)
      {
         System.err.println("##########Writing XML product...");
         final fr.gael.drb.impl.xml.XmlWriter.Context writer_context =
            new fr.gael.drb.impl.xml.XmlWriter.Context();
         writer_context.setFilter(fr.gael.drb.impl.xml.XmlWriter.SHOW_ALL
               ^ fr.gael.drb.impl.xml.XmlWriter.SHOW_ATTRIBUTE);
         writer_context.setPreserveSpace(true);
         fr.gael.drb.impl.xml.XmlWriter.writeXML(product_1, xml_output,
               writer_context, false);
      }
      else
      {
         final XsdInvalid invalid = product_1.isDeepValid();
         if (invalid != null)
         {
            System.out.println(invalid.getMessage());
         }
      }
   } // main

} // XsdNodeImpl
