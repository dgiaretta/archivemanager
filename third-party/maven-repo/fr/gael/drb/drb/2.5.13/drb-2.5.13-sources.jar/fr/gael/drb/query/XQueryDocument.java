/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.Timer;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.Element;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import org.apache.log4j.Logger;

/**
 * XQuery document class.
 */
public class XQueryDocument extends DefaultStyledDocument
{
   /**
    * Logger of this class.
    */
   private Logger logger = Logger.getLogger(XQueryDocument.class);

   /**
    * Comment style.
    */
   protected MutableAttributeSet commentStyle = null;

   /**
    * Style of a type exception.
    */
   protected MutableAttributeSet typeExceptionStyle = null;

   /**
    * Style of a static exception.
    */
   protected MutableAttributeSet staticExceptionStyle = null;

   /**
    * Base style.
    */
   protected MutableAttributeSet baseStyle = null;

   /**
    * Document context to be used.
    */
   private GrammarContext context = new GrammarContext();

   /**
    * Comment on the text (errors to be displayed on a tooltip.
    */
   private String commentText = null;

   /**
    * Timer to update the document.
    */
   protected Timer timer = null;

   /**
    * Document syntax updater.
    */
   protected DocumentUpdater updater = new DocumentUpdater();

   /**
    * builds an empty XQueryDocument with default styles.
    */
   public XQueryDocument()
   {
      super();
      this.initFont();
   }

   /**
    * Initializes the font.
    */
   public void initFont()
   {
      // create default style
      this.baseStyle = new SimpleAttributeSet();

      final Color darkBlue = new Color(0, 0, 139);
      final Color darkGreen = new Color(0, 115, 0);
      final Color darkRed = new Color(139, 0, 0);

      // Comment
      StyleConstants.setFontFamily(this.baseStyle, this.context
            .getDefaultFont().getFamily());
      StyleConstants.setFontSize(this.baseStyle, this.context.getDefaultFont()
            .getSize());
      this.commentStyle = new SimpleAttributeSet(this.baseStyle);
      StyleConstants.setForeground(this.commentStyle, darkGreen);

      final MutableAttributeSet typeStyle = new SimpleAttributeSet();
      StyleConstants.setUnderline(typeStyle, true);
      this.typeExceptionStyle = new SimpleAttributeSet(typeStyle);

      final MutableAttributeSet staticStyle = new SimpleAttributeSet();
      // TBD the underline color.
      // StyleConstants.setForeground(staticStyle, Color.red);
      StyleConstants.setItalic(staticStyle, true);
      StyleConstants.setUnderline(staticStyle, true);
      this.staticExceptionStyle = new SimpleAttributeSet(staticStyle);
   }

   /**
    * Base style accessor.
    * 
    * @return the base style (font with size);
    */
   public MutableAttributeSet getBaseStyle()
   {
      return this.baseStyle;
   }

   /**
    * Sets the default font size.
    * 
    * @param font_size the default font size to be used.
    */
   public void setDefaultFontSize(final float font_size)
   {
      this.context.setDefaultFontSize(font_size);
      this.initFont();
   }

   /**
    * Updates document structure as a result of text insertion.
    * 
    * @param offs insertion offset.
    * @param str string to be inserted.
    * @param attr the attribute set.
    * @throws BadLocationException in case of error.
    */
   public void insertString(final int offs, final String str,
         final AttributeSet attr) throws BadLocationException
   {
      super.insertString(offs, str, this.commentStyle);
      // super.insertString(offs,str,attr);
      // parseUpdate(offs, str.length());

      /*
       * if ((str == null) || (str.equals(""))) return;
       */

      try
      {
         if (this.timer != null)
         {
            this.timer.restart();
         }
         else
         {
            this.timer = new Timer(2000, this.updater);
            this.timer.setRepeats(false);
            this.timer.start();
         }
      }
      catch (final Exception exception)
      {
         System.err.println(exception.getMessage());
      }
   }

   /**
    * Updates document structure as a result of text removal.
    * 
    * @param offs remove offset.
    * @param len the length to be removed.
    * @throws BadLocationException in case of error.
    */
   public void remove(final int offs, final int len)
         throws BadLocationException
   {
      super.remove(offs, len);
      // parseUpdate(offs, 1);
      // parseUpdate(offs, len);

      /*
       * if (len <=0) return;
       */

      try
      {
         if (this.timer != null)
         {
            this.timer.restart();
         }
         else
         {
            this.timer = new Timer(2000, this.updater);
            this.timer.setRepeats(false);
            this.timer.start();
         }
      }
      catch (final Exception exception)
      {
         System.err.println(exception.getMessage());
      }
   }

   /**
    * Updates document structure as a result of text change.
    * 
    * @param offs the offset.
    * @param len the length.
    * @todo This method shall be optimized : update by range ?
    */
   protected void parseUpdate(final int offs, final int len)
   {
      // TODO this method shall be optimized : update by range ?
      // TODO this method shall be interrupted.
      String text = "";
      final int text_length = this.getLength();
      try
      {
         text = this.getText(0, text_length);
      }
      catch (final javax.swing.text.BadLocationException bad_loc)
      {
         this.logger.warn("Cannot retrieve the text.");
         return;
      }

      // Loop on the tokens and update the document colors.
      final QueryParser parser =
         new QueryParser(new java.io.StringReader(text));
      Token current_token = null;
      try
      {
         // TODO TBD
         current_token = parser.getNextToken();
      }
      catch (final TokenMgrError token_manager_error)
      {
         // setCharacterAttributes(0,text_length,commentStyle,true);
         // System.err.println("TokenMgrError: Repaint ALL the text #1 "+
         // token_manager_error.getMessage()+
         // " from 0 to "+text_length);
      }

      int i_token = 0;
      int stop = 0;

      while (current_token != null)
      {
         if (current_token.toString() != null)
         {
            // Fill the characters between token with the comment style.
            this.setCharacterAttributes(stop, current_token.beginOffset,
                  this.commentStyle, true);
            if (this.context.getStyleForScanValue(current_token.kind) != null)
            {
               this.setCharacterAttributes(current_token.beginOffset,
                     current_token.endOffset + 1, this.context
                           .getStyleForScanValue(current_token.kind), true);
               stop = current_token.endOffset + 1;
            }
         }

         try
         {
            current_token = parser.getNextToken();
         }
         catch (final TokenMgrError token_manager_error)
         {
            // setCharacterAttributes(stop+1,text_length,commentStyle,true);
            /*
             * System.err.println("????? TokenMgrError: Shall Repaint ALL the
             * text #2 "+ token_manager_error.getMessage()+ " from "+(stop+1)+"
             * to "+text_length);
             */
            break;
         }

         if ((current_token.toString() != null)
               && (current_token.toString().equals("")))
         {
            current_token = null;
         }
         i_token++;
      }

      // From the last token to the end of the document.
      this.setCharacterAttributes(stop, text_length, this.commentStyle, true);

      // Try to parse the query and retrieve exceptions to update the style.
      // typeExceptionStyle.
      boolean has_static_exception = false;
      boolean has_type_exception = false;
      int exception_start = 0;
      int exception_stop = 0;
      this.commentText = null;
      try
      {
         try
         {
            final java.io.Reader query_reader = new java.io.StringReader(text);
            parser.parse(query_reader, new StaticContext(new Environment()));
         }
         catch (final StaticException static_exception)
         {
            // System.err.println("StaticException :
            // "+static_exception.getMessage()
            // +" beginColumn=" +static_exception.getBeginColumn()
            // +" endColumn=" +static_exception.getEndColumn()
            // +" beginLine=" +static_exception.getBeginLine()
            // +" endLine=" +static_exception.getEndLine());
            has_static_exception = true;

            if ((static_exception.getBeginLine() == 0)
                  || (static_exception.getBeginColumn() == 0)
                  || (static_exception.getEndLine() == 0)
                  || (static_exception.getEndColumn() == 0))
            {
               exception_start = 0;
               exception_stop = text_length - 1;
            }
            else
            {
               final Element root = this.getDefaultRootElement();
               exception_start =
                  root.getElement(static_exception.getBeginLine() - 1)
                        .getStartOffset()
                        + static_exception.getBeginColumn() - 1;
               exception_stop =
                  root.getElement(static_exception.getEndLine() - 1)
                        .getStartOffset()
                        + static_exception.getEndColumn() - 1;
            }

            // Update the comment.
            this.commentText = static_exception.getMessage();
         }
         catch (final TypeException type_exception)
         {
            // System.err.println("TypeException : "+type_exception.getMessage()
            // +" beginColumn=" +type_exception.getBeginColumn()
            // +" endColumn=" +type_exception.getEndColumn()
            // +" beginLine=" +type_exception.getBeginLine()
            // +" endLine=" +type_exception.getEndLine());
            has_type_exception = true;
            final Element root = this.getDefaultRootElement();
            exception_start =
               root.getElement(type_exception.getBeginLine() - 1)
                     .getStartOffset()
                     + type_exception.getBeginColumn() - 1;
            exception_stop =
               root.getElement(type_exception.getEndLine() - 1)
                     .getStartOffset()
                     + type_exception.getEndColumn() - 1;

            // Update the comment.
            this.commentText = type_exception.getMessage();
         }
         catch (final TokenMgrError token_manager_error)
         {
            // Do nothing.
         }
      }
      catch (final Throwable throwable)
      {
         return;
      }

      if (has_static_exception)
      {
         // System.err.println("StaticException : start="+exception_start+
         // ", stop="+exception_stop);
         this.setCharacterAttributes(exception_start, exception_stop,
               this.staticExceptionStyle, false);
      }
      else if (has_type_exception)
      {
         // System.err.println("TypeException : start="+exception_start+
         // ", stop="+exception_stop);
         this.setCharacterAttributes(exception_start, exception_stop,
               this.typeExceptionStyle, false);
      }
   }

   /**
    * Updates document structure as a result of text change.
    * 
    * @param offs the offset.
    * @param len the length.
    * @todo This method shall be optimized : update by range ?
    */
   protected void parseUpdateOld(final int offs, final int len)
   {
      // TODO this method shall be optimized : update by range ?
      String text = "";
      try
      {
         text = this.getText(0, this.getLength());
      }
      catch (final javax.swing.text.BadLocationException bad_loc)
      {
         this.logger.warn("Cannot retrieve the text.");
         return;
      }

      final Element root = this.getDefaultRootElement();

      // Loop on the tokens and update the document colors.
      final QueryParser parser =
         new QueryParser(new java.io.StringReader(text));
      Token current_token = null;
      try
      {
         current_token = parser.getNextToken();
      }
      catch (final TokenMgrError token_manager_error)
      {
         this.setCharacterAttributes(0, this.getLength(), this.commentStyle,
               true);
         /*
          * System.err.println("TokenMgrError: Repaint ALL the text #1 "+
          * token_manager_error.getMessage()+ " from 0 to "+getLength());
          */
      }

      int i_token = 0;
      int start = 0;
      int stop = 0;

      while (current_token != null)
      {
         // System.err.println("Token #"+i_token+" : \'"+current_token+"\'"
         // +" beginColumn=" +current_token.beginColumn
         // +" endColumn=" +current_token.endColumn
         // +" beginLine=" +current_token.beginLine
         // +" endLine=" +current_token.endLine
         // );

         if (current_token.toString() != null)
         {
            // Fill the characters between token with the comment style.
            start = stop;
            stop =
               root.getElement(current_token.endLine - 1).getStartOffset()
                     + current_token.endColumn - 1;
            this.setCharacterAttributes(start, stop, this.commentStyle, true);
            // System.err.println(" Fill ---> start = "+start+", stop ="+stop);

            start =
               root.getElement(current_token.beginLine - 1).getStartOffset()
                     + current_token.beginColumn - 1;
            stop =
               root.getElement(current_token.endLine - 1).getStartOffset()
                     + current_token.endColumn; // -1;
            // System.err.println(" Update ---> start = "+start+", stop
            // ="+stop);

            if (this.context.getStyleForScanValue(current_token.kind) != null)
            {
               this.setCharacterAttributes(start, stop, this.context
                     .getStyleForScanValue(current_token.kind), true);
            }
            else
            {
               this
                     .setCharacterAttributes(start, stop, this.commentStyle,
                           true);
            }
         }

         try
         {
            current_token = parser.getNextToken();
         }
         catch (final TokenMgrError token_manager_error)
         {
            // setCharacterAttributes(stop+1,getLength(),commentStyle,true);
            /*
             * System.err.println("????? TokenMgrError: Shall Repaint ALL the
             * text #2 "+ token_manager_error.getMessage()+ " from "+(stop+1)+"
             * to "+getLength());
             */
            break;
         }

         if ((current_token.toString() != null)
               && (current_token.toString().equals("")))
         {
            current_token = null;
         }
         i_token++;
      }

      // From the last token to the end of the document.
      this.setCharacterAttributes(stop + 1, this.getLength(),
            this.commentStyle, true);

      // Try to parse the query and retrieve exceptions to update the style.
      // typeExceptionStyle.
      boolean has_static_exception = false;
      boolean has_type_exception = false;
      int exception_start = 0;
      int exception_stop = 0;
      this.commentText = null;
      try
      {
         try
         {
            final java.io.Reader query_reader = new java.io.StringReader(text);
            parser.parse(query_reader, new StaticContext(new Environment()));
         }
         catch (final StaticException static_exception)
         {
            // System.err.println("StaticException :
            // "+static_exception.getMessage()
            // +" beginColumn=" +static_exception.getBeginColumn()
            // +" endColumn=" +static_exception.getEndColumn()
            // +" beginLine=" +static_exception.getBeginLine()
            // +" endLine=" +static_exception.getEndLine());
            has_static_exception = true;

            if ((static_exception.getBeginLine() == 0)
                  || (static_exception.getBeginColumn() == 0)
                  || (static_exception.getEndLine() == 0)
                  || (static_exception.getEndColumn() == 0))
            {
               exception_start = 0;
               exception_stop = this.getLength() - 1;
            }
            else
            {
               exception_start =
                  root.getElement(static_exception.getBeginLine() - 1)
                        .getStartOffset()
                        + static_exception.getBeginColumn() - 1;
               exception_stop =
                  root.getElement(static_exception.getEndLine() - 1)
                        .getStartOffset()
                        + static_exception.getEndColumn() - 1;
            }

            // Update the comment.
            this.commentText = static_exception.getMessage();
         }
         catch (final TypeException type_exception)
         {
            // System.err.println("TypeException : "+type_exception.getMessage()
            // +" beginColumn=" +type_exception.getBeginColumn()
            // +" endColumn=" +type_exception.getEndColumn()
            // +" beginLine=" +type_exception.getBeginLine()
            // +" endLine=" +type_exception.getEndLine());
            has_type_exception = true;
            exception_start =
               root.getElement(type_exception.getBeginLine() - 1)
                     .getStartOffset()
                     + type_exception.getBeginColumn() - 1;
            exception_stop =
               root.getElement(type_exception.getEndLine() - 1)
                     .getStartOffset()
                     + type_exception.getEndColumn() - 1;

            // Update the comment.
            this.commentText = type_exception.getMessage();
         }
         catch (final TokenMgrError token_manager_error)
         {
            // Do nothing.
         }
      }
      catch (final Throwable throwable)
      {
         return;
      }

      if (has_static_exception)
      {
         // System.err.println("StaticException : start="+exception_start+
         // ", stop="+exception_stop);
         this.setCharacterAttributes(exception_start, exception_stop,
               this.staticExceptionStyle, false);
      }
      else if (has_type_exception)
      {
         // System.err.println("TypeException : start="+exception_start+
         // ", stop="+exception_stop);
         this.setCharacterAttributes(exception_start, exception_stop,
               this.typeExceptionStyle, false);
      }
   }

   /**
    * Accessor of a comment on the current text.
    * 
    * @return the comment (maybe null).
    */
   public String getComment()
   {
      return this.commentText;
   }

   /**
    * Builds the completion item array with the allowed item just after the
    * specified offset in the text.
    * 
    * @param offset the insertion offset.
    * @return A vector of completion item array. A couple of (String,boolean).
    *         The String is the text that can be inserted. The boolean indicates
    *         if the item is insertable.
    */
   public Vector getCompletion(final int offset)
   {
      // TODO This method shall be updated with more completion feature.

      String text = "";
      Vector items = null;

      try
      {
         text = this.getText(0, offset);
      }
      catch (final javax.swing.text.BadLocationException exception)
      {
         return items;
      }

      try
      {
         final QueryParser parser =
            new QueryParser(new java.io.StringReader(text));

         items = new Vector();

         try
         {
            final java.io.Reader query_reader = new java.io.StringReader(text);
            parser.parse(query_reader, new StaticContext(new Environment()));
         }
         catch (final StaticException static_exception)
         {
            // System.err.println("XQueryEditor.StaticException : "+
            // static_exception.getMessage());

            // Builds the menu.
            final ParseException parse_exception =
               static_exception.getParseException();
            if (parse_exception == null)
            {
               return null;
            }

            final Token token = parse_exception.currentToken.next;
            if (token == null)
            {
               return null;
            }

            // End of file i.e. can insert something.
            if (token.kind == QueryParserConstants.EOF)
            {
               for (int i = 0; i < parse_exception.expectedTokenSequences.length; i++)
               {
                  if (parse_exception.expectedTokenSequences[i].length == 1)
                  {
                     String current =
                        parse_exception.tokenImage[parse_exception.expectedTokenSequences[i][0]];

                     // remove the double-quotes from the token.
                     current = current.replaceAll("\"", "");
                     // System.err.print("current = \'"+current+"\'");
                     boolean enabled = true;
                     if (current.startsWith("<"))
                     {
                        if (current.equals("<Slash>"))
                        {
                           current = "/";
                        }
                        else if (current.equals("<Variable>"))
                        {
                           current = "$";
                        }
                        else
                        {
                           enabled = false;
                        }
                     }

                     // System.err.print(" --- > current = \'"+current+"\'\n");
                     if (!current.equals(""))
                     {
                        items.add(new Object[] { current,
                              Boolean.valueOf(enabled) });
                     }
                  }
               }
            }
            // Display user help i.e disable completion sub-menu.
            else
            {
               int maxSize = 0;
               for (int i = 0; i < parse_exception.expectedTokenSequences.length; i++)
               {
                  String expected = "";
                  if (maxSize < parse_exception.expectedTokenSequences[i].length)
                  {
                     maxSize = parse_exception.expectedTokenSequences[i].length;
                  }
                  for (int j = 0; j < parse_exception.expectedTokenSequences[i].length; j++)
                  {
                     expected +=
                        parse_exception.tokenImage[parse_exception.expectedTokenSequences[i][j]]
                              + " ";
                  }
                  if (parse_exception.expectedTokenSequences[i][parse_exception.expectedTokenSequences[i].length - 1] != 0)
                  {
                     expected += "...";
                  }
                  expected = expected.replaceAll("\"", " ");
                  items.add(new Object[] { expected, Boolean.valueOf(false) });
               }
            }
         }
         catch (final TypeException type_exception)
         {
            // System.err.println(
            // "XQueryEditor.TypeException : "+type_exception.getMessage());
         }
         catch (final TokenMgrError token_manager_error)
         {
            // Do nothing.
         }
      }
      catch (final Throwable throwable)
      {
         return null;
      }

      return items;
   }

   /**
    * This class updates the document style.
    */
   private class DocumentUpdater implements ActionListener
   {
      /**
       * Update the document.
       * 
       * @param event the document event.
       */
      public void actionPerformed(final ActionEvent event)
      {
         XQueryDocument.this.parseUpdate(0, XQueryDocument.this.getLength());
      }
   }
}
