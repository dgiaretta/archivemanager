/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbNode;

/**
 * Output of the XML-Schema type validator.
 */
class XsdInvalidType extends XsdAbstractInvalid
{

   /**
    * The node type.
    */
   XsdType type;

   /**
    * The validated node.
    */
   DrbNode node;

   /**
    * Build an XsdInvalidType
    * 
    * @param node the node
    * @param type the type
    */
   XsdInvalidType(final DrbNode node, final XsdType type)
   {
      super();
      this.node = node;
      this.type = type;
   } // XsdInvalidType

   /**
    * Returns a message describing the validation result.
    * 
    * @return a message describing the validation result.
    */
   public String getMessage()
   {
      if (this.type == null)
      {
         return "Unknown type.";
      }
      else
      {
         return "Unexpected type : it should be an instance of "
               + this.type.getName() + ".";
      }
   } // getMessage

   /**
    * Returns the component.
    * 
    * @return the component.
    */
   public XsdComponent getComponent()
   {
      return this.type;
   } // getComponent

} // XsdInvalidType
