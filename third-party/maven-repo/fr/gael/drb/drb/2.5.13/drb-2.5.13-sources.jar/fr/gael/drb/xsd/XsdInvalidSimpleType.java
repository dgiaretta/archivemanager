/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbNode;
import fr.gael.drb.value.Value;

/**
 * Output of the XML-Schema simple content validator.
 */
class XsdInvalidSimpleType extends XsdInvalidType
{

   /**
    * The node value.
    */
   Value value;

   /**
    * Build an XsdInvalidSimpleType
    * 
    * @param node the node
    * @param type the type
    * @param value the value
    */
   XsdInvalidSimpleType(final DrbNode node, final XsdSimpleType type,
         final Value value)
   {
      super(node, type);
      this.value = value;
   } // XsdInvalidSimpleType

   /**
    * Returns a message describing the validation result.
    * 
    * @return a message describing the validation result.
    */
   public String getMessage()
   {
      // Case of null type
      if (this.type == null)
      {
         if (this.value != null)
         {
            return "The value shall be null.";
         }
         else
         {
            return "Invalid value";
         }
      }
      // Case of invalid type
      if (this.value == null)
      {
         return "The value shall not be null.";
      }
      else
      {
         final XsdSimpleType targetType =
            new XsdAtomicType(((XsdSimpleType) this.type).getTypeId());
         return "The value is not a valid instance of 'xs:"
               + targetType.getName() + "'.";
      }
   } // getMessage

   /**
    * Replace the node value.
    * 
    * @param value the value
    */
   void setValue(final Value value)
   {
      this.value = value;
   }

} // XsdInvalidSimpleType
