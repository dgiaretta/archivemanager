/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import fr.gael.drb.DrbSequence;

/**
 * XQuery variable.
 * <p>
 * This interface defines the interaction available to any variable state of any
 * phase of the processing an XQuery. Therefore, this interface may regard an
 * external variable, a variable reference, a variable declaration.
 * </p>
 * <p>
 * This common interface allows to manipulate any kind of variable with in the
 * same way.
 * </p>
 */
interface Variable
{
   /**
    * Returns the string form of the qualified name of the variable. The string
    * form of a qualified name is the concatenation of the namespace prefix, if
    * any, and its local part, separated by a colon ":" (e.g.
    * 
    * <pre>
    * Prefix &quot;:&quot; LocalPart
    * </pre>).
    * 
    * @return the string form of the qualified name.
    */
   public String getName();

   /**
    * Returns the string form of the qualified name of the variable. The string
    * form of a qualified name is the concatenation of the namespace prefix, if
    * any, and its local part, separated by a colon ":" (e.g.
    * 
    * <pre>
    * Prefix &quot;:&quot; LocalPart
    * </pre>).
    * 
    * @return the string form of the qualified name.
    */
   public QName getQName();

   /**
    * Returns the string form of the qualified name of the sequence type of the
    * variable. The string form of a qualified name is the concatenation of the
    * namespace prefix, if any, and its local part, separated by a colon ":"
    * (e.g.
    * 
    * <pre>
    * Prefix &quot;:&quot; LocalPart
    * </pre>). The name SequenceType suggests that this syntax is used to
    * describe the type of an XQuery value, which is always a sequence. The name
    * of the sequence type does not include the occurrence indicator.
    * 
    * @return the string form of the qualified name of the static type.
    */
   public String getSequenceTypeName();

   /**
    * Returns the value of the variable.
    * 
    * @return the value of the variable if any, or null otherwise.
    */
   public DrbSequence getValue();

   /**
    * Checks if this variable is declared as external. External variables are
    * declared in the prolog and are initialized through the query environment.
    * 
    * @return true if this variable is external and false otherwise.
    */
   public boolean isExternal();

   /**
    * Initializes the value of a variable according to a specified dynamic
    * context. If the variable has no value, an empty sequence is returned
    * instead of a null reference.
    * 
    * @param context the dynamic context to consider.
    */
   public void initialize(DynamicContext context);

   /**
    * Duplicate the current instance of variable. The all reference to value or
    * related material shall be duplicated to prevent alteration using the
    * present interface. It is however not necessary to duplicate the referenced
    * values themselves. As far as possible, the returned instance should have
    * the same class as the original. This is not a committment.
    * 
    * @return the duplicated instance of the variable.
    */
   public Object clone();
}
