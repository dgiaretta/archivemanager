/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.xsd;

import fr.gael.drb.DrbNode;

/**
 * Declaration of the XML-Schema wildcard.
 */
public class XsdWildcard extends XsdComponent
{

   // ==========================================
   // Static part.
   // ==========================================
   /**
    * namespace tag.
    */
   final static String NAMESPACE_TAG = "namespace";

   /**
    * processContents tag.
    */
   final static String PROCESS_CONTENTS_TAG = "processContents";

   /**
    * use tag.
    */
   final static String USE_TAG = "use";

   /**
    * any namespace tag.
    */
   final static String ANY_NAMESPACE_TAG = "##any";

   /**
    * other namespace tag.
    */
   final static String OTHER_NAMESPACE_TAG = "##other";

   // ==================================================
   // Attributes part.
   // ==================================================

   // ==================================================
   // Methods part.
   // ==================================================
   /**
    * Build an XML-Schema wildcard.
    */
   XsdWildcard()
   {
   } // XsdWildcard

   // -------------------------------------------------------
   // XsdComponent class overloading
   // ------------------------------------------------------
   /**
    * Format this component into a string.
    * 
    * @return the node
    */
   DrbNode toNode()
   {
      return null;
   } // toNode

   // ==================================================
   // Unitary test part.
   // =================================================
   /**
    * Makes this class runnable for testing.
    * 
    * @param args String[]
    */
   public static void main(final String[] args)
   {
   } // main

} // XsdWildcard
