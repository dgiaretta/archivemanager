/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.value;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * The Double class is a generic wrapper for double values.
 */
public class Double extends AbstractNumeric implements ValueFormat
{
   // ==========================================
   // Attributes part.
   // ==========================================
   /**
    * The Double priority.
    */
   public final static int PRIORITY = 7;

   /**
    * The Double value.
    */
   double value;

   // ============================================
   // Methods part.
   // ============================================
   /**
    * Constructs an Double object initialized to the specified double value.
    * 
    * @param v the value of the Double.
    */
   public Double(final double v)
   {
      this.value = v;
   }

   /**
    * Returns a new String object representing this Integer.
    * 
    * @return a string representation of the object.
    */
   public java.lang.String toString()
   {
      return java.lang.Double.toString(this.value);
   }

   // -----------------------------------------------------
   // ValueFormat interface implementation
   // -----------------------------------------------------
   // see interface ValueFormat for more information.

   /**
    * Return a string containing the value with a fixed format.
    * 
    * @param length The expected length of the output string
    * @return The formatted string.
    */
   public java.lang.String getFormattedString(final int length)
   {
      switch (length)
      {
         case 8:
            return new java.lang.String(new java.text.DecimalFormat(
                  "+.000000;-.000000").format(this.value));

         case 12:
            return new java.lang.String(new java.text.DecimalFormat(
                  "+0000.000000;-0000.000000").format(this.value));

         case 25:
            return new java.lang.String(new java.text.DecimalFormat(
                  "+0.00000000000000000E000;" + "-0.00000000000000000E000")
                  .format(this.value));

         default:
            return this.toString();
      }
   }

   /**
    * Return a byte buffer containing the value in a fixed format.
    * 
    * @return The formatted buffer.
    */
   public byte[] getFormattedBuffer()
   {
      final byte[] buffer = new byte[8];
      final long longValue = java.lang.Double.doubleToRawLongBits(this.value);

      buffer[0] = (byte) (longValue >>> 56);
      buffer[1] = (byte) (longValue >>> 48);
      buffer[2] = (byte) (longValue >>> 40);
      buffer[3] = (byte) (longValue >>> 32);
      buffer[4] = (byte) (longValue >>> 24);
      buffer[5] = (byte) (longValue >>> 16);
      buffer[6] = (byte) (longValue >>> 8);
      buffer[7] = (byte) (longValue);

      return buffer;
   }

   // -------------------------------------------------------
   // Value interface implementation
   // -------------------------------------------------------
   /**
    * The type identifier of this Double value.
    * 
    * @return an identifier of the Double type.
    */
   public final int getType()
   {
      return Value.DOUBLE_ID;
   }

   /**
    * Returns the Double priority
    * 
    * @return the Double priority
    */
   public final int getPriority()
   {
      return this.PRIORITY;
   }

   /**
    * Convert the value into the specified type. In case of identity conversion
    * the value itself is returned. If the conversion is not allowed a
    * ClassCastException is thrown.
    * 
    * @param type The target type.
    * @return The converted value.
    * @throws ClassCastException is the convertion is impossible
    */
   public final Value convertTo(final int type) throws ClassCastException
   {
      switch (type)
      {
         // Double -> Double conversion
         case Value.DOUBLE_ID:
         case Value.NUMERIC_ID:
            return this;

            // Double -> DoubleArray conversion
         case ARRAY_ID:
            final DoubleArray doubleArray = new DoubleArray(1);
            doubleArray.assign(0, this.doubleValue());
            return doubleArray;

            // Double -> Unknown
         default:
            return super.convertTo(type);
      }
   }

   /**
    * Assign a new Value. An implicit conversion may be performed to make the
    * assignment. This assignment may result in a loss of precision (ex : int to
    * double).
    * 
    * @param v the value to be assigned.
    */
   public void assign(final Value v)
   {
      final Double vs = (Double) v.convertTo(Value.DOUBLE_ID);
      this.value = vs.doubleValue();
   }

   // ------------------------------------------------
   // Arithmetic interface implementation
   // -------------------------------------------------
   /**
    * Compute the unary minus of this value.
    * 
    * @return The unary minus of this value.
    */
   public Value unaryMinus()
   {
      return new Double(-this.value);
   }

   /**
    * Compute an addition.
    * 
    * @param x another value.
    * @return the sum of the two values.
    */
   public Value add(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).add(x);
      }
      return new Double(this.doubleValue() + ((Numeric) x).doubleValue());
   }

   /**
    * Compute a substraction.
    * 
    * @param x another value.
    * @return the difference between the two values.
    */
   public Value sub(final Value x)
   {
      // Check if self priority is lower than the operand priority
      //
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).sub(x);
      }
      return new Double(this.doubleValue() - ((Numeric) x).doubleValue());
   }

   /**
    * Compute a multiplication.
    * 
    * @param x another value.
    * @return the product of the two values.
    */
   public Value multiply(final Value x)
   {
      // Check if self priority is lower than the operand priority
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).multiply(x);
      }
      return new Double(this.doubleValue() * ((Numeric) x).doubleValue());
   }

   /**
    * Compute a division.
    * 
    * @param x another value.
    * @return the ratio of the two values.
    */
   public final Value divide(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).divide(x);
      }
      return new Double(this.doubleValue() / ((Numeric) x).doubleValue());
   }

   /**
    * Compute a modulus.
    * 
    * @param x another value.
    * @return the modulus of the values.
    */
   public Value modulus(final Value x)
   {
      if (this.getPriority() < x.getPriority())
      {
         return ((Numeric) this.convertTo(x.getType())).modulus(x);
      }
      return new Double(this.doubleValue() % ((Numeric) x).doubleValue());
   }

   // ---------------------------------------------------
   // Comparison interface implementation
   // ---------------------------------------------------
   /**
    * Compare this value with another value.
    * 
    * @param x another value.
    * @return The returned value is :
    *         <ul>
    *         <li>negative if this value is lower than another value</li>
    *         <li>zero if the two values are equal</li>
    *         <li>positive if this value is greater than another value</li>
    *         </ul>
    */
   public int compareTo(final Value x)
   {
      if (this.getPriority() >= x.getPriority())
      {
         final double cmp = this.doubleValue() - ((Numeric) x).doubleValue();
         if (cmp == 0.0)
         {
            return 0;
         }
         else if (cmp < 0.0)
         {
            return -1;
         }
         else
         {
            return +1;
         }
      }
      return -((Comparison) x).compareTo(this);
   }

   // ---------------------------------------------
   // Logic interface implementation
   // ---------------------------------------------

   /**
    * Returns this value as a boolean
    * 
    * @return the numeric value represented by this object after conversion to
    *         type boolean.
    */
   public final boolean booleanValue()
   {
      if (java.lang.Double.isNaN(this.value) || (this.value == 0.0))
      {
         return false;
      }
      return true;
   }

   // -----------------------------------------------
   // Numeric interface implementation
   // -----------------------------------------------
   /**
    * Returns this value as a byte (signed 8 bits). The conversion may result in
    * a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type byte.
    */
   public final byte byteValue()
   {
      return (byte) this.value;
   }

   /**
    * Returns this value as a integer (signed 32 bits). The conversion may
    * result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type int.
    */
   public final int intValue()
   {
      return (int) this.value;
   }

   /**
    * Returns this value as a short integer (signed 16 bits). The conversion may
    * result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type short.
    */
   public final short shortValue()
   {
      return (short) this.value;
   }

   /**
    * Returns this value as a long integer (signed 64 bits). The conversion may
    * result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type long.
    */
   public final long longValue()
   {
      return (long) this.value;
   }

   /**
    * Returns this value as a float (signed 32 bits IEEE 754). The conversion
    * may result in a loss of precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type float.
    */
   public final float floatValue()
   {
      return (float) this.value;
   }

   /**
    * Returns this value as a BigInteger. The conversion may result in a loss of
    * precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type BigInteger.
    */
   protected BigInteger integerValue()
   {
      return new BigDecimal(this.toString()).toBigInteger();
   }

   /**
    * Returns this value as a BigDecimal. The conversion may result in a loss of
    * precision.
    * 
    * @return the numeric value represented by this object after conversion to
    *         type BigDecimal.
    */
   protected BigDecimal decimalValue()
   {
      return new BigDecimal(this.toString());
   }

   /**
    * Returns this value as a double (signed 64 bits IEEE 754).
    * 
    * @return the numeric value represented by this object after conversion to
    *         type double.
    */
   public final double doubleValue()
   {
      return this.value;
   }

   /**
    * Assign a boolean value.
    * 
    * @param value another value.
    */
   public final void assign(final boolean value)
   {
      this.value = (value ? (double) 1 : (double) 0);
   }

   /**
    * Assign a byte value. The conversion may result in a loss of precision.
    * 
    * @param value another value.
    */
   public final void assign(final byte value)
   {
      this.value = value;
   }

   /**
    * Assign an int value. The conversion may result in a loss of precision.
    * 
    * @param value another value.
    */
   public final void assign(final int value)
   {
      this.value = value;
   }

   /**
    * Assign a long value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final long value)
   {
      this.value = value;
   }

   /**
    * Assign a short value.
    * 
    * @param value another value. The conversion may result in a loss of
    *           precision.
    */
   public final void assign(final short value)
   {
      this.value = value;
   }

   /**
    * Assign a float value.
    * 
    * @param value another value.
    */
   public final void assign(final float value)
   {
      this.value = value;
   }

   /**
    * Assign a double value.
    * 
    * @param value another value.
    */
   public final void assign(final double value)
   {
      this.value = value;
   }

   /*
    * public static void main(java.lang.String[] args) {
    * System.out.println("Double(" + java.lang.Double.toString(1.13256789e+71) + ") ->
    * Integer=" + new Double(113.256789e+69).convertTo(INTEGER_ID));
    * System.out.println("-0.57 getFormattedString() : [" + new Double(-0.57) +
    * "]"); System.out.println("-0.57 getFormattedString(8) : [" + new
    * Double(-0.57).getFormattedString(8) + "]"); System.out.println(" 0.57
    * getFormattedString(12) : [" + new Double(0.57).getFormattedString(12) +
    * "]"); System.out.println("020912.061 getFormattedString(12) : [" + new
    * Double(020912.061).getFormattedString(12) + "]");
    * System.out.println("123.4567e6 getFormattedString(12) : [" + new
    * Double(123.4567e6).getFormattedString(12) + "]");
    * System.out.println("123.4567e6 getFormattedString(25) : [" + new
    * Double(123.4567e6).getFormattedString(25) + "]"); System.out.println("
    * 6543 getFormattedString(25) : [" + new Double(6543).getFormattedString(25) +
    * "]"); System.out.println("-6543 getFormattedString(25) : [" + new
    * Double(-6543).getFormattedString(25) + "]"); System.out.println(" 0.6543
    * getFormattedString(25) : [" + new Double(0.6543).getFormattedString(25) +
    * "]"); System.out.println("-0.6543 getFormattedString(25) : [" + new
    * Double(-0.6543).getFormattedString(25) + "]"); }
    */

}
