/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.query;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import fr.gael.drb.xsd.Namespace;

/**
 * Context during the static analysis phase of an XQuery.
 * <p>
 * The <b>static context</b> of an expression is the information that is
 * available during static analysis of the expression, prior to its evaluation.
 * This information can be used to decide whether the expression contains a
 * static error. If analysis of an expression relies on some component of the
 * static context that has not been assigned a value, a static error is raised.
 * </p>
 * <p>
 * The individual components of the static context are summarized in the XQuery
 * specifications <a href="http://www.w3.org/TR/xquery">
 * http://www.w3.org/TR/xquery</a>
 * </p>
 * <p>
 * A special attention has been paid in this class to inherit from the
 * vocabulary of the XQuery specifications. It is therefore strongly encouraged
 * to refer to the XQuery specificatios regarding to static contexts for a
 * complete definition of its role during the static analysis phase.
 * </p>
 */
class StaticContext extends Environment
{
   /**
    * Logger
    */
   Logger logger = Logger.getLogger(StaticContext.class);

   /**
    * In-scope variables.
    */
   private Map<QName, Variable> inScopeVariable =
      new HashMap<QName, Variable>();

   /**
    * In-scope functions.
    */
   private Map<QName, Function> inScopeFunction =
      new HashMap<QName, Function>();

   /**
    * Builds a static context from a default environment. Refer to the
    * Environment class for information about the default environment.
    */
   StaticContext()
   {
      this(new Environment());
   }

   /**
    * Builds a static context from an environment.
    * <p>
    * The principle of the initialisation of a static context from an enviroment
    * is to clone it and inparticular its external references but without
    * duplicating the referenced elements. As an example, the list of namespaces
    * is duplicated but the namespaces it refer to are not. Therefore, the lists
    * are independent and the static context may augment the list without
    * modifying the originating enviroment. However, the caller shall be careful
    * while modifying the referenced elements. This may alter the active or
    * further processing of an XQuery.
    * </p>
    * <p>
    * If the provided reference to the environment is null, the static context
    * is built with a default environment. Refer to the Environment class for
    * information about the default environment.
    * </p>
    * 
    * @param env the environment to be considered.
    */
   StaticContext(Environment env)
   {
      /**
       * Create a default environment if the provided parameter is null.
       */
      if (env == null)
      {
         env = new Environment();
      }

      /**
       * Duplicate the namespace.
       */
      this.setNamespace(env.getNamespace().cloneNamespace());

      /**
       * Reference the default namespace URIs of element/type and functions.
       */
      this.setDefaultElementNamespaceURI(env.getDefaultElementNamespaceURI());
      this.setDefaultFunctionNamespaceURI(env.getDefaultFunctionNamespaceURI());

      /**
       * Reference the base URI.
       */
      this.setBaseURI(env.getBaseURI());

      /**
       * External variables. Because the external variables are supposed to
       * augment independently from the static scope, the list of out-scope
       * external variable is referenced and not duplicated.
       */
      this.setExternalVariableMap(env.getExternalVariableMap());

      /**
       * Reference the former resolver.
       */
      // TODO: Remove the former resolver.
      this.resolver = env.resolver;
      
      /**
       * Copy backward compatibility mode.
       */
      if(env.isBackwardCompatibilityModeSet)
      {
         this.setBackwardCompatibilityMode(env.isBackwardCompatibilityMode());
      }
   }

   /**
    * Builds a context from another static context. This constructor is mainly
    * dedicated to derivate a new scope of context. It performs the same tasks
    * as the constructor from an environment. In addition it duplicates the list
    * of in-scope variables and the variable themselves to avoid conflict.
    * 
    * @param context the out-scope context to derivate.
    */
   StaticContext(final StaticContext context)
   {
      this((Environment) context);

      /**
       * Duplicate in-scope variable list. The variables are duplicated in order
       * to prevent alterations of their values.
       */
      final Set<QName> varnameSet = context.inScopeVariable.keySet();

      for (final Iterator<QName> iterator = varnameSet.iterator(); iterator
            .hasNext();)
      {
         final QName varName = iterator.next();

         final Variable variable =
            (Variable) (context.inScopeVariable.get(varName)).clone();

         this.inScopeVariable.put(varName, variable);
      }

      /**
       * Duplicate in-scope function list.
       */
      this.inScopeFunction.putAll(context.inScopeFunction);
   }

   /**
    * Add in-scope variable. If the list of in-scope variable previously
    * contained a variable with the same qualified name, the old entry is
    * replaced.
    * 
    * @param variable the reference to the variable to put in-scope.
    */
   public void addInScopeVariable(final Variable variable)
   {
      this.inScopeVariable.put(variable.getQName(), variable);
   }

   /**
    * Check if a variable is in-scope.
    * 
    * @param name string form of the qualified name of the variable.
    * @return true if the variable is in-scope, false otherwise.
    * @deprecated Uses containsInScopeVariable(QName)
    */
   public boolean containsInScopeVariable(final String name)
   {
      // Contextual namespaces.
      final Namespace namespaces = this.getNamespace();

      // Extracts input variable name local name
      final String localName = Namespace.toLocal(name);

      // Extracts input variable name prefix
      final String prefix = Namespace.toPrefix(name);

      // Resolve corresponding namespace URI or default it to the default
      // element namespace URI.
      String namespace = null;
      if (prefix == null)
      {
         namespace = this.getDefaultElementNamespaceURI();
      }
      else
      {
         namespace = namespaces.resolveNamespace(prefix);
      }

      return this.containsInScopeVariable(new QName(localName, namespace));
   }

   /**
    * Check if a variable is in-scope.
    * 
    * @param name string form of the qualified name of the variable.
    * @return true if the variable is in-scope, false otherwise.
    */
   public boolean containsInScopeVariable(final QName name)
   {
      return this.inScopeVariable.containsKey(name);
   }

   /**
    * Returns a in-scope variable.
    * 
    * @param name string form of the qualified name of the variable.
    * @return the variable if in-scope, null otherwise.
    * @deprecated Use getInScopeVariable(QName)
    */
   public Variable getInScopeVariable(final String name)
   {
      // Contextual namespaces.
      final Namespace namespaces = this.getNamespace();

      // Extracts input variable name prefix
      final String prefix = Namespace.toPrefix(name);

      // Resolve corresponding namespace URI or default it to the default
      // element namespace URI.
      String namespace = null;
      if (prefix != null)
      {
         namespace = namespaces.resolveNamespace(prefix);
      }

      return this.getInScopeVariable(new QName(name, namespace));
   } // getInScopeVariable

   /**
    * Returns a in-scope variable.
    * 
    * @param name string form of the qualified name of the variable.
    * @return the variable if in-scope, null otherwise.
    */
   public Variable getInScopeVariable(final QName name)
   {
      // Prepare output variable reference.
      Variable variable = this.inScopeVariable.get(name);

      /**
       * If not retrieved, look in the environment external variables.
       */
      if (variable == null)
      {
         variable = this.getExternalVariable(name.toString());
      }

      return variable;
   }

   /**
    * Returns the all the "in scope" variables of the context. The returned
    * collection shall never be null reference but may contain no variable at
    * all. The reference corresponds to the map used by the current static
    * context. Modifying it without a priori knowledge of the current class
    * behavior may affect dramatically the current context. Basically, this
    * operation should be used in read only mode.
    * 
    * @return the map containing the in scope variables.
    */
   protected Collection<Variable> getInScopeVariables()
   {
      return this.inScopeVariable.values();
   }

   /**
    * Add in-scope function. If the list of in-scope function previously
    * contained a function with the same qualified name, the old entry is
    * replaced.
    * 
    * @param function the reference to the function to put in-scope.
    */
   public void addInScopeFunction(final Function function)
   {
      this.inScopeFunction.put(function.getQName(), function);
   }

   /**
    * Check if a function is in-scope.
    * 
    * @param name string form of the qualified name of the function.
    * @return true if the function is in-scope, false otherwise.
    * @deprecated Use containsInScopeFunction(QName) instead
    */
   public boolean containsInScopeFunction(final String name)
   {
      // Contextual namespaces.
      final Namespace namespaces = this.getNamespace();

      // Extracts input function name local name
      final String localName = Namespace.toLocal(name);

      // Extracts input function name prefix
      final String prefix = Namespace.toPrefix(name);

      // Resolve corresponding namespace URI or default it to the default
      // element namespace URI.
      String namespace = null;
      if (prefix == null)
      {
         namespace = this.getDefaultFunctionNamespaceURI();
      }
      else
      {
         namespace = namespaces.resolveNamespace(prefix);
      }

      return this.containsInScopeFunction(new QName(localName, namespace));
   }

   /**
    * Check if a function is in-scope.
    * 
    * @param name string form of the qualified name of the function.
    * @return true if the function is in-scope, false otherwise.
    */
   public boolean containsInScopeFunction(final QName name)
   {
      return this.inScopeFunction.containsKey(name);
   }

   /**
    * Returns a in-scope function.
    * 
    * @param name string form of the qualified name of the function.
    * @return the function if in-scope, null otherwise.
    * @deprecated
    */
   public Function getInScopeFunction(final String name)
   {
      // Contextual namespaces.
      final Namespace namespaces = this.getNamespace();

      // Extracts input function name local name
      final String localName = Namespace.toLocal(name);

      // Extracts input function name prefix
      final String prefix = Namespace.toPrefix(name);

      // Resolve corresponding namespace URI or default it to the default
      // element namespace URI.
      String namespace = null;
      if (prefix == null)
      {
         namespace = this.getDefaultFunctionNamespaceURI();
      }
      else
      {
         namespace = namespaces.resolveNamespace(prefix);
      }

      return this.getInScopeFunction(new QName(localName, namespace), -1);
   }

   /**
    * Returns an in-scope function.
    * 
    * @param name the qualified name of the function.
    * @return the function if in-scope, null otherwise.
    */
   public Function getInScopeFunction(final QName name)
   {
      return this.inScopeFunction.get(name);
   }

   /**
    * Returns an in-scope function.
    * 
    * @param name the qualified name of the function.
    * @param arity the arity of the function (i.e. number of parameters).
    * @return the function if in-scope, null otherwise.
    */
   public Function getInScopeFunction(final QName name, final int arity)
   {
      final Function function = this.inScopeFunction.get(name);

      /**
       * Check arity of the function.
       */
      if ((function == null) || (arity == function.getArity()))
      {
         return function;
      }

      /**
       * Returns null, if no function matches the specified signature
       */
      return null;
   }

   /**
    * Returns the all the "in scope" functions of the context. The returned map
    * shall never be null reference but may contain no function at all. The
    * reference corresponds to the map used by the current static context.
    * Modifying it without a priori knowledge of the current class behavior may
    * affect dramatically the current context. Basically, this operation should
    * be used in read only mode.
    * 
    * @return the map containing the in scope functions.
    */
   protected Map<QName, Function> getInScopeFunctions()
   {
      return this.inScopeFunction;
   }
}
