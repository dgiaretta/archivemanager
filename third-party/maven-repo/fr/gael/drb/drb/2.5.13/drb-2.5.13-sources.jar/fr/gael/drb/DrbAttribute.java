/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb;

import fr.gael.drb.value.Value;

/**
 * Generic attribute interface. The attributes are information related to a
 * specific node (i.e. the owner). Any attribute has a name and corresponding
 * value. This last value can be set from the owner node or hinerited from a
 * default value. This ambiguity is important to consider while using attribute
 * values. For instance the attribute "length"of a specific node, may be equal
 * to 123 from a default value (i.e. defined by the implementation of the node)
 * or because it was effectively embedded in the supported data source (e.g. the
 * XML document). The name of the attribute is unique in the set of attributes
 * of the same node. No specific contrainst is imposed for the order of
 * attributes.
 */
public interface DrbAttribute extends DrbItem
{

   /**
    * Name of the attribute. Returns the name of the attribute. This name does
    * not contain any prefix, path nor any other location or identification
    * part. This name clearly identfies the attibute in the set of attribute of
    * the same node. This name is unique is this set. The attribute name is
    * never an empty string and always exists.
    * 
    * @return The name of the attribute.
    */
   public String getName();

   /**
    * The node the owning the current attribute. Returns a reference to the node
    * to which belongs this attribute. Because the attribute may have just been
    * created it may have no owner. This operation is similar to a getParent().
    * 
    * @return The owner of the attribute.
    */
   public DrbNode getOwner();

   /**
    * The value type of the attribute. All node have a value according to the
    * fr.gael.drb.value package. This operation returns the type identifier of
    * the content of the current attribute. The value of the attribute depends
    * on the implementation as well as on the attribute itself. This operation
    * never returns a fr.gael.drb.value.Value.NULL_ID identifier.
    * 
    * @return The type of the attribute.
    */
   public int getValueType();

   /**
    * Get namespace URI. The namespace URI of this attribute, or null if it is
    * unspecified. This is not a computed value that is the result of a
    * namespace lookup based on an examination of the namespace declarations in
    * scope. It is merely the namespace URI given at creation time. The
    * Namespaces on an attribute does not inherit its namespace from the element
    * it is attached to. If an attribute is not explicitly given a namespace, it
    * simply has no namespace
    * 
    * @return The namspace URI or null if unspecified.
    */
   public String getNamespaceURI();

   /**
    * The value of the attribute. The value is expressed accoring to one of the
    * types supported by the fr.gael.drb.value package. Generally these types
    * correspond to primitive types (e.g. integer, floatting points, etc.) or
    * very low level types (e.g. string, date, etc.). On the contrary to DOM
    * implementation all the types are allowed even the arrays, date etc. Only
    * the Value.NULL_ID type is forbidden.
    * 
    * @return The value of the attribute.
    */
   public Value getValue();

   /**
    * The attribute was explicitly given a value. This operation returns true if
    * the attribute was explicitly given an value in the data source handled by
    * the current implementation (e.g. a node of an XML document). Otherwise the
    * value is inherited from a default value.
    * 
    * @return false is a defaulted value or true otherwise.
    */
   public boolean isSpecified();
}
