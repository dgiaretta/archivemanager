/*
 * Data Request Broker - DRB API
 * Copyright (C) 2001,2002,2003,2004,2005,2006,2007,2008,2009 GAEL Consultant
 * GNU Lesser General Public License (LGPL)
 * 
 * This file is part of Data Request Broker
 * 
 * Data Request Broker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Data Request Broker is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fr.gael.drb.impl.xml;

import org.apache.log4j.Logger;

/**
 * SAX Element Tag implementation.
 */
class SaxElementTag extends SaxTag
{
   /**
    * Logger.
    */
   static private Logger logger = Logger.getLogger(SaxElementTag.class);

   /**
    * The parent tag.
    */
   protected SaxElementTag parent;

   /**
    * The children count.
    */
   protected int childrenCount = 0;

   /**
    * The tag name.
    */
   protected String name;

   /**
    * The node namespace URI.
    */
   protected String namespaceURI;

   /**
    * The end offset of the open tag in the input stream.
    */
   protected long endOpenOffset = -1;

   /**
    * The start offset of the close tag in the input stream.
    */
   protected long startCloseOffset = -1;

   /**
    * The referenced node.
    */
   private java.lang.ref.Reference refNode = null;

   /**
    * Move the tag to a position.
    * 
    * @param pos the absolute offset in bytes.
    */
   protected void moveTo(final long pos)
   {
      final long diffOffset = pos - this.startOffset;
      this.startOffset += diffOffset;
      this.endOffset += diffOffset;
      this.startCloseOffset += diffOffset;
      this.endOpenOffset += diffOffset;

      // Perform deep move.
      final SaxNode node = this.getNodeReference();
      if ((node != null) && (node.getTagCount() == this.childrenCount))
      {
         for (int i = 0; i < this.childrenCount; i++)
         {
            final SaxTag childTag = node.getTagAt(i);
            childTag.moveTo(childTag.startOffset + diffOffset);
         }
      }
   }

   /**
    * Retrieve the referenced node or null.
    * 
    * @return refNode
    */
   protected final SaxNode getNodeReference()
   {
      if (this.refNode != null)
      {
         return (SaxNode) this.refNode.get();
      }
      else
      {
         return null;
      }
   }

   /**
    * Set the node reference.
    * 
    * @param node node
    */
   protected final void setNodeReference(final SaxNode node)
   {
      if (this.refNode != null)
      {
         this.refNode.clear();
      }
      this.refNode = new java.lang.ref.WeakReference(node);
   }

   /**
    * Set the node reference.
    * 
    * @param node node
    * @param weak weak
    */
   protected final void setNodeReference(final SaxNode node, final boolean weak)
   {
      if (this.refNode != null)
      {
         this.refNode.clear();
      }
      if (weak)
      {
         this.refNode = new java.lang.ref.WeakReference(node);
      }
      else
      {
         this.refNode = new java.lang.ref.SoftReference(node);
      }
   }
} // SaxElementTag
